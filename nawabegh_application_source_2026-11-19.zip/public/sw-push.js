// Custom Service Worker Push & Background Notification Handler for Nawabegh / LearnNova PWA
self.addEventListener('push', (event) => {
  let payload = {
    title: 'منصة نوابغ التعليمية',
    body: 'لديك إشعار أكاديمي جديد',
    url: '/',
    tag: 'nawabegh-notification',
  };

  if (event.data) {
    try {
      const parsed = event.data.json();
      payload = { ...payload, ...parsed };
    } catch {
      try {
        payload.body = event.data.text();
      } catch {
        // fallback to default
      }
    }
  }

  const options = {
    body: payload.body,
    icon: payload.icon || '/pwa-192x192.png',
    badge: payload.badge || '/pwa-192x192.png',
    dir: 'rtl',
    lang: 'ar',
    tag: payload.tag || 'nawabegh-notification',
    renotify: true,
    requireInteraction: false,
    vibrate: [150, 75, 150],
    data: {
      url: payload.url || '/',
      timestamp: Date.now(),
    },
    actions: [
      {
        action: 'open',
        title: 'عرض الآن',
      },
    ],
  };

  event.waitUntil(self.registration.showNotification(payload.title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = (event.notification.data && event.notification.data.url) || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({
            type: 'PWA_NOTIFICATION_CLICK',
            url: targetUrl,
          });
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SHOW_LOCAL_NOTIFICATION') {
    const p = event.data.payload || {};
    event.waitUntil(
      self.registration.showNotification(p.title || 'منصة نوابغ التعليمية', {
        body: p.body || '',
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        dir: 'rtl',
        lang: 'ar',
        tag: p.tag || 'nawabegh-local',
        data: { url: p.url || '/' },
      })
    );
  }
});
