import { AccessToken } from 'livekit-server-sdk';
import { classroomConfig, isLiveKitConfigured } from './config.ts';
import type { ClassroomRole } from '../../src/types/classroom.ts';

export interface LiveKitMediaAllocation {
  mode: 'livekit' | 'webrtc-p2p';
  livekitUrl: string | null;
  livekitToken: string | null;
  hlsStreamUrl: string | null;
  simulcastEnabled: boolean;
}

export async function generateLiveKitParticipantToken(opts: {
  roomCode: string;
  userId: string;
  userName: string;
  role: ClassroomRole;
}): Promise<string | null> {
  if (!isLiveKitConfigured()) {
    return null;
  }

  const isHost = opts.role === 'teacher' || opts.role === 'admin' || opts.role === 'assistant';
  const at = new AccessToken(classroomConfig.livekitApiKey, classroomConfig.livekitApiSecret, {
    identity: opts.userId,
    name: opts.userName,
    metadata: JSON.stringify({ role: opts.role }),
    ttl: '6h',
  });

  at.addGrant({
    roomJoin: true,
    room: opts.roomCode,
    canPublish: isHost || opts.role === 'student', // Student publish controlled dynamically + host moderation
    canSubscribe: true,
    canPublishData: true,
    roomAdmin: opts.role === 'teacher' || opts.role === 'admin',
  });

  return await at.toJwt();
}

export async function allocateRoomMediaSession(opts: {
  roomCode: string;
  userId: string;
  userName: string;
  role: ClassroomRole;
  hlsStreamUrl?: string | null;
}): Promise<LiveKitMediaAllocation> {
  const token = await generateLiveKitParticipantToken(opts);
  if (token && classroomConfig.livekitUrl) {
    return {
      mode: 'livekit',
      livekitUrl: classroomConfig.livekitUrl,
      livekitToken: token,
      hlsStreamUrl: opts.hlsStreamUrl || null,
      simulcastEnabled: true,
    };
  }

  return {
    mode: 'webrtc-p2p',
    livekitUrl: null,
    livekitToken: null,
    hlsStreamUrl: opts.hlsStreamUrl || null,
    simulcastEnabled: true,
  };
}
