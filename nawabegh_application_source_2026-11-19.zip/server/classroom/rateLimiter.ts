import type { Request, Response, NextFunction } from 'express';

interface BucketRecord {
  timestamps: number[];
}

export class SlidingWindowRateLimiter {
  private readonly buckets = new Map<string, BucketRecord>();
  private readonly windowMs: number;
  private readonly maxRequests: number;

  constructor(maxRequests: number, windowMs: number) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
  }

  public check(key: string, now = Date.now()): { allowed: boolean; remaining: number; retryAfterMs: number } {
    const cutoff = now - this.windowMs;
    const existing = this.buckets.get(key);
    const recent = existing ? existing.timestamps.filter((t) => t > cutoff) : [];

    if (recent.length >= this.maxRequests) {
      const oldest = recent[0];
      const retryAfterMs = Math.max(0, oldest + this.windowMs - now);
      this.buckets.set(key, { timestamps: recent });
      return { allowed: false, remaining: 0, retryAfterMs };
    }

    recent.push(now);
    this.buckets.set(key, { timestamps: recent });
    return {
      allowed: true,
      remaining: Math.max(0, this.maxRequests - recent.length),
      retryAfterMs: 0,
    };
  }

  public reset(key?: string) {
    if (key) {
      this.buckets.delete(key);
    } else {
      this.buckets.clear();
    }
  }
}

export function createExpressRateLimiter(opts: { maxRequests: number; windowMs: number; keyPrefix?: string }) {
  const limiter = new SlidingWindowRateLimiter(opts.maxRequests, opts.windowMs);
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userId = String(req.headers['x-user-id'] || '').trim();
    const key = `${opts.keyPrefix || 'api'}:${ip}:${userId}`;
    const result = limiter.check(key);

    res.setHeader('X-RateLimit-Remaining', String(result.remaining));
    if (!result.allowed) {
      return res.status(429).json({
        error: 'تم تجاوز الحد المسموح من الطلبات مؤقتاً، يرجى المحاولة بعد قليل.',
        retryAfterMs: result.retryAfterMs,
      });
    }
    next();
  };
}
