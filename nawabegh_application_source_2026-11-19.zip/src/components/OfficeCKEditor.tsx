import React, { useState, useRef, useEffect } from 'react';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Subscript,
  Superscript,
  Undo2,
  Redo2,
  RemoveFormatting,
  Code,
  AlignRight,
  AlignCenter,
  AlignLeft,
  AlignJustify,
  Indent,
  Outdent,
  List,
  ListOrdered,
  Quote,
  Table as TableIcon,
  Image as ImageIcon,
  Link2,
  Unlink,
  Sparkles,
  Minus,
  SeparatorHorizontal,
  Search,
  Sigma,
  ZoomIn,
  FileDown,
  Printer,
  CheckSquare,
  Columns,
  Video as VideoIcon,
  FileText,
  Layers,
  LayoutTemplate,
  BookOpen,
  Maximize2,
  Minimize2,
  Plus,
  Trash2,
  FileCode2,
  X,
} from 'lucide-react';
import { Language } from '../types';
import { AlSharifWatermark } from './ScreenProtectionGuard';

export interface OfficeCKEditorProps {
  value: string;
  onChange: (html: string) => void;
  language: Language;
  placeholderAr?: string;
  placeholderEn?: string;
  documentTitle?: string;
  documentMeta?: string;
  teacherName?: string;
  onAttachCurrentInfographic?: () => string | null;
  minHeight?: number;
}

const MATH_SYMBOLS = [
  '∑', '∫', '√', 'π', 'θ', 'Δ', '∞', '≤',
  '≥', '≠', '±', '×', '÷', '°', '→', '⇒',
  '⇔', '∈', '∉', '∪', '∩', 'α', 'β', 'γ',
  'Ω', 'λ', 'μ', '≈', '∝', '∠', '⊥', '∥',
];

const FONT_FAMILIES = [
  { label: 'Tajawal (الافتراضي)', value: 'Tajawal, sans-serif' },
  { label: 'Cairo (عناوين)', value: 'Cairo, sans-serif' },
  { label: 'Arial', value: 'Arial, sans-serif' },
  { label: 'Tahoma', value: 'Tahoma, sans-serif' },
  { label: 'Times New Roman', value: 'Times New Roman, serif' },
  { label: 'Georgia (أدبي)', value: 'Georgia, serif' },
  { label: 'Courier New (كود)', value: 'Courier New, monospace' },
];

const FONT_SIZES = [
  { label: '10 pt', value: '1' },
  { label: '12 pt', value: '2' },
  { label: '14 pt (قياسي)', value: '3' },
  { label: '16 pt', value: '4' },
  { label: '18 pt', value: '5' },
  { label: '24 pt', value: '6' },
  { label: '32 pt', value: '7' },
];

const QUICK_TEXT_COLORS = ['#0f172a', '#0c3d36', '#059669', '#2563eb', '#7c3aed', '#e11d48', '#d97706', '#475569'];
const QUICK_HIGHLIGHTS = ['#fef08a', '#bbf7d0', '#bfdbfe', '#fbcfe8', '#fde68a', 'transparent'];

const BUILTIN_INFOGRAPHIC_SNIPPETS: Array<{
  id: string;
  labelAr: string;
  labelEn: string;
  descAr: string;
  color: string;
  html: string;
}> = [
  {
    id: 'steps4',
    labelAr: 'مسار 4 خطوات مرقم',
    labelEn: '4-Step Process',
    descAr: 'تسلسل خطوات مترابطة لخوارزمية أو قاعدة',
    color: '#059669',
    html: `<div style="margin:16px 0;padding:16px;border-radius:16px;border:1px solid #cbd5e1;background:#f8fafc;">
      <div style="font-weight:900;font-size:15px;color:#0c3d36;margin-bottom:10px;">📌 مسار الخطوات المتسلسل لحل المفهوم</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;">
        <div style="background:#fff;border:1px solid #e2e8f0;border-top:4px solid #059669;border-radius:12px;padding:10px;"><strong style="color:#059669;">1. تحديد المعطيات</strong><p style="margin:4px 0 0;font-size:12px;color:#475569;">قراءة السؤال واستخراج القيم والثوابت.</p></div>
        <div style="background:#fff;border:1px solid #e2e8f0;border-top:4px solid #2563eb;border-radius:12px;padding:10px;"><strong style="color:#2563eb;">2. اختيار القانون</strong><p style="margin:4px 0 0;font-size:12px;color:#475569;">ربط المطلوب بالعلاقة الرياضية المناسبة.</p></div>
        <div style="background:#fff;border:1px solid #e2e8f0;border-top:4px solid #d97706;border-radius:12px;padding:10px;"><strong style="color:#d97706;">3. التعويض والحساب</strong><p style="margin:4px 0 0;font-size:12px;color:#475569;">إجراء العمليات مع توحيد الوحدات.</p></div>
        <div style="background:#fff;border:1px solid #e2e8f0;border-top:4px solid #7c3aed;border-radius:12px;padding:10px;"><strong style="color:#7c3aed;">4. التحقق النهائي</strong><p style="margin:4px 0 0;font-size:12px;color:#475569;">مراجعة منطقية الناتج ووحدة القياس.</p></div>
      </div>
    </div><p><br/></p>`,
  },
  {
    id: 'compareVS',
    labelAr: 'مقارنة ثنائية (VS)',
    labelEn: 'VS Comparison',
    descAr: 'جدول بطاقتين متقابلتين للمقارنة السريعة',
    color: '#2563eb',
    html: `<div style="margin:16px 0;padding:16px;border-radius:16px;border:1px solid #cbd5e1;background:#ffffff;">
      <div style="text-align:center;font-weight:900;font-size:15px;color:#0f172a;margin-bottom:12px;">⚖️ مقارنة تحليلية شاملة (المفهوم أ 🆚 المفهوم ب)</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:14px;padding:14px;"><h4 style="margin:0 0 6px;color:#065f46;font-weight:800;">الجانب الأول (أ)</h4><ul style="margin:0;padding-right:18px;font-size:13px;color:#064e3b;"><li>الخاصية الأساسية الأولى</li><li>المعادلة أو القانون المميز</li><li>مثال تطبيقي مباشر</li></ul></div>
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:14px;padding:14px;"><h4 style="margin:0 0 6px;color:#1e40af;font-weight:800;">الجانب المقابل (ب)</h4><ul style="margin:0;padding-right:18px;font-size:13px;color:#1e3a8a;"><li>الخاصية الأساسية المقابلة</li><li>المعادلة أو القانون البديل</li><li>مثال تطبيقي مقارنةً بالأول</li></ul></div>
      </div>
    </div><p><br/></p>`,
  },
  {
    id: 'kpiBars',
    labelAr: 'لوحة مؤشرات ونسب تقدم',
    labelEn: 'KPI Progress Bars',
    descAr: 'شرائط نسب مئوية لأوزان المحاور والاختبار',
    color: '#0d9488',
    html: `<div style="margin:16px 0;padding:16px;border-radius:16px;border:1px solid #cbd5e1;background:#f8fafc;">
      <div style="font-weight:900;font-size:15px;color:#0f172a;margin-bottom:10px;">📊 الوزن النسبي وأهمية المحاور في الاختبار</div>
      <div style="space-y:8px;">
        <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;"><span>المفاهيم والقوانين الأساسية</span><span style="color:#059669;">85%</span></div><div style="height:10px;background:#e2e8f0;border-radius:99px;overflow:hidden;"><div style="width:85%;height:100%;background:#059669;"></div></div></div>
        <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;"><span>المسائل التطبيقية والرسوم البيانية</span><span style="color:#2563eb;">70%</span></div><div style="height:10px;background:#e2e8f0;border-radius:99px;overflow:hidden;"><div style="width:70%;height:100%;background:#2563eb;"></div></div></div>
        <div><div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;"><span>مسائل مهارات التفكير العليا</span><span style="color:#d97706;">55%</span></div><div style="height:10px;background:#e2e8f0;border-radius:99px;overflow:hidden;"><div style="width:55%;height:100%;background:#d97706;"></div></div></div>
      </div>
    </div><p><br/></p>`,
  },
  {
    id: 'swot2x2',
    labelAr: 'مصفوفة تحليل رباعية 2×2',
    labelEn: '2x2 Matrix',
    descAr: 'شبكة 4 مربعات لتحليل النقاط والتحديات',
    color: '#7c3aed',
    html: `<div style="margin:16px 0;padding:16px;border-radius:16px;border:1px solid #cbd5e1;background:#ffffff;">
      <div style="font-weight:900;font-size:15px;color:#0f172a;margin-bottom:10px;">🧩 مصفوفة التحليل الشامل (4 محاور)</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;">
        <div style="padding:12px;border-radius:12px;background:#ecfdf5;border:1px solid #6ee7b7;"><strong style="color:#047857;">1. نقاط القوة والمفاتيح</strong><p style="margin:4px 0 0;font-size:12px;color:#065f46;">أبرز القواعد الثابتة التي تسهل الحل السريع.</p></div>
        <div style="padding:12px;border-radius:12px;background:#eff6ff;border:1px solid #93c5fd;"><strong style="color:#1d4ed8;">2. الفرص والتطبيقات</strong><p style="margin:4px 0 0;font-size:12px;color:#1e3a8a;">أين يُستخدم هذا المفهوم في الحياة والاختبار؟</p></div>
        <div style="padding:12px;border-radius:12px;background:#fffbeb;border:1px solid #fcd34d;"><strong style="color:#b45309;">3. التحديات الصعبة</strong><p style="margin:4px 0 0;font-size:12px;color:#78350f;">نقاط تستلزم تركيزاً إضافياً وتمريناً متكرراً.</p></div>
        <div style="padding:12px;border-radius:12px;background:#fff1f2;border:1px solid #fda4af;"><strong style="color:#be123c;">4. أخطاء شائعة تجنبها</strong><p style="margin:4px 0 0;font-size:12px;color:#881337;">إشارات سالبة أو تحويل وحدات يخطئ فيها الطلاب.</p></div>
      </div>
    </div><p><br/></p>`,
  },
  {
    id: 'timeline',
    labelAr: 'خط زمني للمراحل',
    labelEn: 'Timeline',
    descAr: 'تدرج زمني أو مرحلي منظم',
    color: '#d97706',
    html: `<div style="margin:16px 0;padding:16px;border-radius:16px;border:1px solid #cbd5e1;background:#f8fafc;">
      <div style="font-weight:900;font-size:15px;color:#0f172a;margin-bottom:10px;">⏳ التسلسل الزمني / المرحلي للدرس</div>
      <div style="border-right:3px solid #059669;padding-right:14px;">
        <div style="margin-bottom:10px;"><strong style="color:#059669;">المرحلة الأولى — التمهيد التاريخي والمفهوم:</strong><div style="font-size:12px;color:#475569;">نشأة القاعدة أو الظاهرة العلمية وأهميتها.</div></div>
        <div style="margin-bottom:10px;"><strong style="color:#2563eb;">المرحلة الثانية — الصياغة الرياضية والعلمية:</strong><div style="font-size:12px;color:#475569;">استنتاج القانون العام وتفسير كل رمز فيه.</div></div>
        <div><strong style="color:#7c3aed;">المرحلة الثالثة — التطبيقات والنماذج المتقدمة:</strong><div style="font-size:12px;color:#475569;">توظيف القاعدة في مسائل متنوعة واختبارات قياسية.</div></div>
      </div>
    </div><p><br/></p>`,
  },
  {
    id: 'pyramid',
    labelAr: 'الهرم المعرفي المتدرج',
    labelEn: 'Pyramid Tiers',
    descAr: 'هرم مستويات متدرجة من القاعدة للقمة',
    color: '#e11d48',
    html: `<div style="margin:16px 0;padding:16px;border-radius:16px;border:1px solid #cbd5e1;background:#ffffff;text-align:center;">
      <div style="font-weight:900;font-size:15px;color:#0f172a;margin-bottom:12px;">🔺 الهرم المعرفي لتدرج استيعاب الدرس</div>
      <div style="width:55%;margin:0 auto 6px;padding:8px 12px;border-radius:10px;background:#7c3aed;color:#fff;font-size:12px;font-weight:700;">القمة: الإبداع وحل مسائل التحدي</div>
      <div style="width:72%;margin:0 auto 6px;padding:8px 12px;border-radius:10px;background:#2563eb;color:#fff;font-size:12px;font-weight:700;">الوسط: التحليل والربط بين القوانين</div>
      <div style="width:88%;margin:0 auto;padding:8px 12px;border-radius:10px;background:#059669;color:#fff;font-size:12px;font-weight:700;">القاعدة: الفهم الأساسي وحفظ التعريفات والرموز</div>
    </div><p><br/></p>`,
  },
];

export const OfficeCKEditor: React.FC<OfficeCKEditorProps> = ({
  value,
  onChange,
  language,
  placeholderAr = 'ابدأ الكتابة هنا... شاشة كتابة الدرس بأدوات تنسيق متكاملة + إدراج الانفوجرافيك مباشرة في الدرس.',
  placeholderEn = 'Start writing here... Full lesson writing tools + built-in Infographic blocks.',
  documentTitle = 'مستند درس تعليمي',
  documentMeta = '',
  teacherName = 'مدرس المادة',
  onAttachCurrentInfographic,
  minHeight = 540,
}) => {
  const isAr = language === 'ar';

  const [ribbonTab, setRibbonTab] = useState<'home' | 'insert' | 'layout' | 'infographic' | 'view'>('home');
  const [textColor, setTextColor] = useState('#0c3d36');
  const [highlightColor, setHighlightColor] = useState('#fef08a');
  const [selectedFont, setSelectedFont] = useState('Tajawal, sans-serif');
  const [selectedSize, setSelectedSize] = useState('3');
  const [lineHeight, setLineHeight] = useState('1.85');
  const [zoom, setZoom] = useState<number>(100);
  const [paperMode, setPaperMode] = useState<'standard' | 'a4' | 'lined' | 'dark'>('standard');
  const [paperPadding, setPaperPadding] = useState<'narrow' | 'normal' | 'wide'>('normal');
  const [widePaper, setWidePaper] = useState(true);

  const editorRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const isInternalChangeRef = useRef(false);

  // Popovers
  const [showTablePopover, setShowTablePopover] = useState(false);
  const [tableRows, setTableRows] = useState(4);
  const [tableCols, setTableCols] = useState(3);
  const [hoverCell, setHoverCell] = useState<{ r: number; c: number }>({ r: 0, c: 0 });
  const [tableHeaderTheme, setTableHeaderTheme] = useState<'emerald' | 'indigo' | 'amber' | 'slate'>('emerald');
  const [tableStriped, setTableStriped] = useState(true);

  const [showLinkPopover, setShowLinkPopover] = useState(false);
  const [linkUrl, setLinkUrl] = useState('https://');
  const [linkText, setLinkText] = useState('');

  const [showImagePopover, setShowImagePopover] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [imageWidth, setImageWidth] = useState<'25%' | '50%' | '75%' | '100%'>('100%');
  const [imageAlign, setImageAlign] = useState<'center' | 'right' | 'left'>('center');

  const [showVideoPopover, setShowVideoPopover] = useState(false);
  const [videoEmbedInput, setVideoEmbedInput] = useState('');

  const [showSymbolsPopover, setShowSymbolsPopover] = useState(false);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [findQuery, setFindQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');

  const [isPdfPrintPreviewOpen, setIsPdfPrintPreviewOpen] = useState(false);

  // Synchronize external value updates into contentEditable without breaking user cursor
  useEffect(() => {
    if (!editorRef.current) return;
    if (isInternalChangeRef.current) {
      isInternalChangeRef.current = false;
      return;
    }
    if (editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value || '';
    }
  }, [value]);

  const syncFromDom = () => {
    if (editorRef.current) {
      isInternalChangeRef.current = true;
      onChange(editorRef.current.innerHTML);
    }
  };

  const focusEditor = () => {
    editorRef.current?.focus();
  };

  const executeCommand = (command: string, val: string | undefined = undefined) => {
    focusEditor();
    document.execCommand(command, false, val);
    syncFromDom();
  };

  const insertCustomBlock = (htmlBlock: string) => {
    focusEditor();
    if (document.queryCommandSupported('insertHTML')) {
      document.execCommand('insertHTML', false, htmlBlock);
    } else if (editorRef.current) {
      editorRef.current.innerHTML += htmlBlock;
    }
    syncFromDom();
  };

  const toggleTextDirection = (dir: 'rtl' | 'ltr') => {
    focusEditor();
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      let node: Node | null = sel.anchorNode;
      while (node && node !== editorRef.current) {
        if (
          node instanceof HTMLElement &&
          ['P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'LI', 'BLOCKQUOTE'].includes(node.tagName)
        ) {
          node.setAttribute('dir', dir);
          node.style.textAlign = dir === 'rtl' ? 'right' : 'left';
          syncFromDom();
          return;
        }
        node = node.parentNode;
      }
    }
    if (editorRef.current) {
      editorRef.current.setAttribute('dir', dir);
    }
    syncFromDom();
  };

  // Advanced Table Builder & Live Cell Manipulation
  const handleInsertTable = (rOverride?: number, cOverride?: number) => {
    const rCount = Math.min(12, Math.max(2, rOverride ?? tableRows));
    const cCount = Math.min(8, Math.max(1, cOverride ?? tableCols));
    const themeHex =
      tableHeaderTheme === 'indigo'
        ? '#312e81'
        : tableHeaderTheme === 'amber'
        ? '#b45309'
        : tableHeaderTheme === 'slate'
        ? '#1e293b'
        : '#0c3d36';

    let html = `<table style="width: 100%; border-collapse: collapse; margin: 14px 0; font-size: 14px;"><thead><tr style="background-color: ${themeHex}; color: #ffffff;">`;
    for (let c = 0; c < cCount; c++) {
      html += `<th style="padding: 9px 12px; border: 1px solid #cbd5e1; text-align: ${isAr ? 'right' : 'left'};">${
        isAr ? `العمود ${c + 1}` : `Column ${c + 1}`
      }</th>`;
    }
    html += `</tr></thead><tbody>`;
    for (let r = 0; r < rCount - 1; r++) {
      const bg = tableStriped && r % 2 === 1 ? '#f8fafc' : '#ffffff';
      html += `<tr style="background-color: ${bg};">`;
      for (let c = 0; c < cCount; c++) {
        html += `<td style="padding: 8px 12px; border: 1px solid #cbd5e1;">&nbsp;</td>`;
      }
      html += `</tr>`;
    }
    html += `</tbody></table><p><br/></p>`;
    insertCustomBlock(html);
    setShowTablePopover(false);
  };

  const findActiveTableContext = () => {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    let node: Node | null = sel.anchorNode;
    let cell: HTMLTableCellElement | null = null;
    let row: HTMLTableRowElement | null = null;
    let table: HTMLTableElement | null = null;
    while (node && node !== editorRef.current) {
      if (node instanceof HTMLTableCellElement && !cell) cell = node;
      if (node instanceof HTMLTableRowElement && !row) row = node;
      if (node instanceof HTMLTableElement && !table) table = node;
      node = node.parentNode;
    }
    if (!table && editorRef.current) {
      const firstTable = editorRef.current.querySelector('table');
      if (firstTable) table = firstTable;
    }
    return { cell, row, table };
  };

  const handleTableAddRow = () => {
    const ctx = findActiveTableContext();
    if (!ctx?.table) return;
    const targetBody = ctx.table.tBodies[0] || ctx.table;
    const refRow = ctx.row || targetBody.rows[targetBody.rows.length - 1];
    const colLen = refRow ? refRow.cells.length : 3;
    const newRow = document.createElement('tr');
    for (let i = 0; i < colLen; i++) {
      const td = document.createElement('td');
      td.style.cssText = 'padding: 8px 12px; border: 1px solid #cbd5e1;';
      td.innerHTML = '&nbsp;';
      newRow.appendChild(td);
    }
    if (ctx.row && ctx.row.parentElement === targetBody) {
      ctx.row.after(newRow);
    } else {
      targetBody.appendChild(newRow);
    }
    syncFromDom();
  };

  const handleTableDeleteRow = () => {
    const ctx = findActiveTableContext();
    if (!ctx?.table) return;
    if (ctx.row && ctx.row.parentElement?.tagName !== 'THEAD') {
      ctx.row.remove();
      syncFromDom();
    } else if (ctx.table.tBodies[0]?.rows.length) {
      ctx.table.tBodies[0].rows[ctx.table.tBodies[0].rows.length - 1].remove();
      syncFromDom();
    }
  };

  const handleTableAddCol = () => {
    const ctx = findActiveTableContext();
    if (!ctx?.table) return;
    Array.from(ctx.table.rows).forEach((r, rIdx) => {
      const isHead = r.parentElement?.tagName === 'THEAD' || rIdx === 0;
      const cell = document.createElement(isHead ? 'th' : 'td');
      cell.style.cssText = isHead
        ? 'padding: 9px 12px; border: 1px solid #cbd5e1; text-align: right;'
        : 'padding: 8px 12px; border: 1px solid #cbd5e1;';
      cell.innerHTML = isHead ? `عمود ${r.cells.length + 1}` : '&nbsp;';
      r.appendChild(cell);
    });
    syncFromDom();
  };

  const handleTableDeleteCol = () => {
    const ctx = findActiveTableContext();
    if (!ctx?.table) return;
    const colIdx = ctx.cell ? ctx.cell.cellIndex : -1;
    Array.from(ctx.table.rows).forEach((r) => {
      if (r.cells.length <= 1) return;
      const idxToRemove = colIdx >= 0 && colIdx < r.cells.length ? colIdx : r.cells.length - 1;
      r.deleteCell(idxToRemove);
    });
    syncFromDom();
  };

  const handleInsertLink = () => {
    if (!linkUrl.trim() || linkUrl.trim() === 'https://') return;
    const safeUrl = linkUrl.trim();
    if (linkText.trim()) {
      insertCustomBlock(
        `<a href="${safeUrl}" target="_blank" rel="noopener noreferrer" style="color: #0284c7; text-decoration: underline; font-weight: 600;">${linkText.trim()}</a>`
      );
    } else {
      executeCommand('createLink', safeUrl);
    }
    setLinkUrl('https://');
    setLinkText('');
    setShowLinkPopover(false);
  };

  const buildImageBlock = (src: string, alt: string) =>
    `<div style="margin: 14px 0; text-align: ${imageAlign};"><img src="${src}" alt="${alt}" style="width: ${imageWidth}; max-width: 100%; border-radius: 12px; border: 1px solid #e2e8f0; display: inline-block;" /></div><p><br/></p>`;

  const handleInsertImageUrl = () => {
    if (!imageUrl.trim()) return;
    insertCustomBlock(buildImageBlock(imageUrl.trim(), 'صورة تعليمية'));
    setImageUrl('');
    setShowImagePopover(false);
  };

  const handleUploadImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        insertCustomBlock(buildImageBlock(reader.result, file.name));
        setShowImagePopover(false);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleInsertVideo = () => {
    const raw = videoEmbedInput.trim();
    if (!raw) return;
    let embedUrl = raw;
    const ytMatch = raw.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([A-Za-z0-9_-]{6,})/);
    if (ytMatch) {
      embedUrl = `https://www.youtube.com/embed/${ytMatch[1]}`;
      insertCustomBlock(
        `<div style="margin: 16px 0; border-radius: 14px; overflow: hidden; border: 1px solid #cbd5e1; background: #000;"><iframe src="${embedUrl}" style="width: 100%; height: 320px; border: 0;" allowfullscreen></iframe></div><p><br/></p>`
      );
    } else {
      insertCustomBlock(
        `<div style="margin: 16px 0; border-radius: 14px; overflow: hidden; border: 1px solid #cbd5e1; background: #000;"><video src="${raw}" controls style="width: 100%; max-height: 360px;"></video></div><p><br/></p>`
      );
    }
    setVideoEmbedInput('');
    setShowVideoPopover(false);
  };

  const handleReplaceAll = () => {
    if (!findQuery || !editorRef.current) return;
    const escaped = findQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(escaped, 'g');
    const updated = editorRef.current.innerHTML.replace(regex, replaceQuery);
    editorRef.current.innerHTML = updated;
    isInternalChangeRef.current = true;
    onChange(updated);
  };

  const handleExportToWord = () => {
    const htmlContent = editorRef.current ? editorRef.current.innerHTML : value;
    const htmlDoc = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset="utf-8" />
        <title>${documentTitle} - منصة الشريف</title>
        <style>
          body { font-family: 'Tajawal', 'Cairo', Arial, sans-serif; direction: ${isAr ? 'rtl' : 'ltr'}; line-height: 1.85; color: #1e293b; }
          h1, h2, h3, h4 { font-family: 'Cairo', Arial, sans-serif; color: #0c3d36; }
          table { width: 100%; border-collapse: collapse; margin: 12px 0; }
          th, td { border: 1px solid #cbd5e1; padding: 8px; }
          .watermark-banner { text-align: center; padding: 8px; background: #ecfdf5; border: 1px dashed #059669; color: #065f46; font-weight: bold; margin-bottom: 14px; }
          .watermark-center { text-align: center; color: rgba(6, 95, 70, 0.22); font-size: 26pt; font-weight: 900; margin: 16px 0; }
        </style>
      </head>
      <body>
        <div class="watermark-banner">علامة مائية رسمية: منصة الشريف — الدروس والمذكرات المعتمدة</div>
        <h1>${documentTitle}</h1>
        ${documentMeta ? `<p><strong>المنصة:</strong> منصة الشريف | <strong>${documentMeta}</strong> | <strong>المعلم:</strong> ${teacherName}</p>` : '<p><strong>المنصة:</strong> منصة الشريف</p>'}
        <hr/>
        <div class="watermark-center">منصة الشريف</div>
        ${htmlContent}
        <div class="watermark-center">منصة الشريف</div>
      </body>
      </html>
    `;
    const blob = new Blob(['\ufeff', htmlDoc], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(documentTitle || 'lesson').replace(/\s+/g, '_')}_منصة_الشريف.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExportHtml = () => {
    const htmlContent = editorRef.current ? editorRef.current.innerHTML : value;
    const doc = `<!DOCTYPE html><html lang="${isAr ? 'ar' : 'en'}" dir="${isAr ? 'rtl' : 'ltr'}"><head><meta charset="utf-8" /><title>${documentTitle} - منصة الشريف</title></head><body style="max-width:900px;margin:28px auto;padding:24px;font-family:'Tajawal',Arial,sans-serif;line-height:1.85;color:#0f172a;position:relative;"><div style="text-align:center;padding:8px;background:#ecfdf5;border:1px dashed #059669;color:#065f46;font-weight:bold;margin-bottom:14px;">علامة مائية: منصة الشريف</div><h1>${documentTitle}</h1>${documentMeta ? `<p style="color:#475569;">${documentMeta} • منصة الشريف</p>` : ''}<hr/>${htmlContent}<hr/><p style="text-align:center;font-weight:bold;color:#065f46;">منصة الشريف — جميع الحقوق محفوظة</p></body></html>`;
    const blob = new Blob(['\ufeff', doc], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(documentTitle || 'lesson').replace(/\s+/g, '_')}_منصة_الشريف.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Document live statistics
  const plainText = (value || '')
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .trim();
  const wordsCount = plainText ? plainText.split(/\s+/).filter(Boolean).length : 0;
  const charsCount = plainText.replace(/\s+/g, '').length;
  const readingTimeMin = wordsCount === 0 ? 0 : Math.max(1, Math.ceil(wordsCount / 180));
  const isSheetVisuallyEmpty =
    wordsCount === 0 && !/<(table|img|hr|ul|ol|div|iframe|video)/i.test(value || '');

  const closeAllPopovers = () => {
    setShowTablePopover(false);
    setShowImagePopover(false);
    setShowLinkPopover(false);
    setShowVideoPopover(false);
    setShowSymbolsPopover(false);
  };

  const paperBgClass =
    paperMode === 'dark'
      ? 'bg-slate-900 text-slate-100 border-slate-700'
      : paperMode === 'lined'
      ? 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border-slate-200 dark:border-slate-800 ck-lined-paper'
      : paperMode === 'a4'
      ? 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border-2 border-emerald-700/30 ring-4 ring-slate-200/60 dark:ring-slate-800/60'
      : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border-slate-200 dark:border-slate-800';

  const paperPaddingClass =
    paperPadding === 'narrow'
      ? 'p-3 md:p-4'
      : paperPadding === 'wide'
      ? 'p-8 md:p-12'
      : 'p-4 md:p-6';

  return (
    <div className="flex flex-col flex-1 min-h-0 bg-slate-100 dark:bg-slate-950 font-tajawal">
      {/* OFFICE RIBBON TABS BAR */}
      <div className="bg-slate-200/70 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-2.5 pt-2 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1 font-cairo text-xs shrink-0">
          {[
            { id: 'home', ar: 'الشريط الرئيسي', en: 'Home' },
            { id: 'insert', ar: 'إدراج وجداول', en: 'Insert & Tables' },
            { id: 'layout', ar: 'تخطيط الورقة', en: 'Page Layout' },
            { id: 'infographic', ar: 'انفوجرافيك داخل الدرس', en: 'Infographics' },
            { id: 'view', ar: 'مراجعة وتصدير', en: 'View & Export' },
          ].map((tab) => {
            const active = ribbonTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setRibbonTab(tab.id as typeof ribbonTab)}
                className={`px-3 py-1.5 rounded-t-xl font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                  active
                    ? 'bg-slate-100 dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 border-t-2 border-emerald-600 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.id === 'infographic' && <Sparkles className="w-3.5 h-3.5 text-amber-500" />}
                <span>{isAr ? tab.ar : tab.en}</span>
              </button>
            );
          })}
        </div>

        <div className="hidden md:flex items-center gap-1.5 pb-1 shrink-0 text-[11px] font-cairo">
          <button
            type="button"
            onClick={handleExportToWord}
            className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1 cursor-pointer"
          >
            <FileDown className="w-3 h-3" />
            <span>Word</span>
          </button>
          <button
            type="button"
            onClick={() => setIsPdfPrintPreviewOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold flex items-center gap-1 cursor-pointer"
          >
            <Printer className="w-3 h-3" />
            <span>PDF</span>
          </button>
        </div>
      </div>

      {/* OFFICE RIBBON CONTENT PANEL */}
      <div className="p-2 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 space-y-2 text-slate-700 dark:text-slate-200">
        {/* TAB 1: HOME */}
        {ribbonTab === 'home' && (
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-1.5">
              {/* Undo / Redo / Clear Format */}
              <div className="flex items-center gap-0.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => executeCommand('undo')}
                  className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                  title="تراجع (Undo)"
                >
                  <Undo2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => executeCommand('redo')}
                  className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                  title="إعادة (Redo)"
                >
                  <Redo2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => executeCommand('removeFormat')}
                  className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-rose-600 cursor-pointer"
                  title="مسح التنسيق"
                >
                  <RemoveFormatting className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Font Family, Size, Line Height, Headings */}
              <div className="flex flex-wrap items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
                <select
                  value={selectedFont}
                  onChange={(e) => {
                    setSelectedFont(e.target.value);
                    executeCommand('fontName', e.target.value);
                  }}
                  className="px-1.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-tajawal cursor-pointer"
                  title="نوع الخط"
                >
                  {FONT_FAMILIES.map((f) => (
                    <option key={f.value} value={f.value}>
                      {f.label}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedSize}
                  onChange={(e) => {
                    setSelectedSize(e.target.value);
                    executeCommand('fontSize', e.target.value);
                  }}
                  className="px-1.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers cursor-pointer"
                  title="حجم الخط"
                >
                  {FONT_SIZES.map((s) => (
                    <option key={s.value} value={s.value}>
                      {s.label}
                    </option>
                  ))}
                </select>

                <select
                  defaultValue="<p>"
                  onChange={(e) => executeCommand('formatBlock', e.target.value)}
                  className="px-1.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo font-bold cursor-pointer"
                  title="نمط الفقرة والعناوين"
                >
                  <option value="<p>">فقرة عادية (P)</option>
                  <option value="<h1>">عنوان رئيسي (H1)</option>
                  <option value="<h2>">عنوان فرعي (H2)</option>
                  <option value="<h3>">عنوان قسم (H3)</option>
                  <option value="<h4>">عنوان مصغر (H4)</option>
                  <option value="<blockquote>">اقتباس (Quote)</option>
                  <option value="<pre>">صندوق كود (Code)</option>
                </select>

                <select
                  value={lineHeight}
                  onChange={(e) => setLineHeight(e.target.value)}
                  className="px-1.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers cursor-pointer"
                  title="تباعد الأسطر"
                >
                  <option value="1.3">سطر 1.3</option>
                  <option value="1.6">سطر 1.6</option>
                  <option value="1.85">سطر 1.85</option>
                  <option value="2.2">سطر 2.2</option>
                </select>
              </div>

              {/* Character Styling */}
              <div className="flex items-center gap-0.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                <button type="button" onClick={() => executeCommand('bold')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="عريض (Bold)">
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('italic')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="مائل (Italic)">
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('underline')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="تسطير (Underline)">
                  <Underline className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('strikeThrough')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="يتوسطه خط">
                  <Strikethrough className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('subscript')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="منخفض (Subscript)">
                  <Subscript className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('superscript')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="مرتفع / أس (Superscript)">
                  <Superscript className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Row 2: Colors, Align, Direction, Lists & Checklist */}
            <div className="flex flex-wrap items-center gap-1.5">
              {/* Quick Fore & Highlight Swatches */}
              <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 px-2 py-1 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px]">
                <span className="font-bold opacity-70">A</span>
                {QUICK_TEXT_COLORS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    onClick={() => {
                      setTextColor(hex);
                      executeCommand('foreColor', hex);
                    }}
                    className="w-4 h-4 rounded-full border border-slate-300 cursor-pointer hover:scale-110 transition-transform"
                    style={{ backgroundColor: hex }}
                    title={`لون النص ${hex}`}
                  />
                ))}
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => {
                    setTextColor(e.target.value);
                    executeCommand('foreColor', e.target.value);
                  }}
                  className="w-5 h-5 rounded border-0 cursor-pointer bg-transparent"
                  title="لون خط مخصص"
                />
                <span className="w-px h-4 bg-slate-200 dark:bg-slate-700" />
                <span className="px-1 rounded bg-amber-200 text-slate-900 text-[10px] font-bold">ab</span>
                {QUICK_HIGHLIGHTS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    onClick={() => {
                      setHighlightColor(hex);
                      executeCommand('hiliteColor', hex);
                    }}
                    className="w-4 h-4 rounded border border-slate-300 cursor-pointer hover:scale-110 transition-transform"
                    style={{ backgroundColor: hex === 'transparent' ? '#ffffff' : hex }}
                    title={hex === 'transparent' ? 'إزالة التمييز' : `تمييز ${hex}`}
                  />
                ))}
              </div>

              {/* Alignment */}
              <div className="flex items-center gap-0.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                <button type="button" onClick={() => executeCommand('justifyRight')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="محاذاة يمين">
                  <AlignRight className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('justifyCenter')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="توسيط">
                  <AlignCenter className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('justifyLeft')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="محاذاة يسار">
                  <AlignLeft className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('justifyFull')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="ضبط متساوي">
                  <AlignJustify className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Direction & Indent */}
              <div className="flex items-center gap-0.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] font-bold">
                <button type="button" onClick={() => toggleTextDirection('rtl')} className="px-1.5 py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="اتجاه عربي RTL">
                  RTL
                </button>
                <button type="button" onClick={() => toggleTextDirection('ltr')} className="px-1.5 py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="اتجاه إنجليزي LTR">
                  LTR
                </button>
                <button type="button" onClick={() => executeCommand('indent')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="مسافة بادئة">
                  <Indent className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('outdent')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="إنقاص المسافة">
                  <Outdent className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Lists, Quote & Checklist */}
              <div className="flex items-center gap-0.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] font-bold">
                <button type="button" onClick={() => executeCommand('insertUnorderedList')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="قائمة نقطية">
                  <List className="w-3.5 h-3.5" />
                </button>
                <button type="button" onClick={() => executeCommand('insertOrderedList')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="قائمة رقمية">
                  <ListOrdered className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    insertCustomBlock(
                      `<div style="margin:8px 0;padding:8px 12px;border-radius:10px;background:#f8fafc;border:1px solid #e2e8f0;">
                        <div>☑ نقطة المراجعة الأولى</div>
                        <div>☑ نقطة المراجعة الثانية</div>
                        <div>☐ مهمة تطبيقية للطالب</div>
                      </div><p><br/></p>`
                    )
                  }
                  className="px-2 py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg flex items-center gap-1 cursor-pointer"
                  title="قائمة مهام تفاعلية"
                >
                  <CheckSquare className="w-3.5 h-3.5 text-emerald-600" />
                  <span>قائمة مهام</span>
                </button>
                <button type="button" onClick={() => executeCommand('formatBlock', '<blockquote>')} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer" title="اقتباس">
                  <Quote className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: INSERT & TABLES */}
        {ribbonTab === 'insert' && (
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
              {/* Media & Table Triggers */}
              <div className="flex flex-wrap items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => {
                    const next = !showTablePopover;
                    closeAllPopovers();
                    setShowTablePopover(next);
                  }}
                  className="px-2.5 py-1 rounded-lg hover:bg-emerald-50 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <TableIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isAr ? 'إدراج جدول' : 'Insert Table'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const next = !showImagePopover;
                    closeAllPopovers();
                    setShowImagePopover(next);
                  }}
                  className="px-2.5 py-1 rounded-lg hover:bg-blue-50 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>{isAr ? 'صورة / رسم' : 'Image'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const next = !showVideoPopover;
                    closeAllPopovers();
                    setShowVideoPopover(next);
                  }}
                  className="px-2.5 py-1 rounded-lg hover:bg-indigo-50 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <VideoIcon className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{isAr ? 'تضمين فيديو' : 'Embed Video'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const next = !showLinkPopover;
                    closeAllPopovers();
                    setShowLinkPopover(next);
                  }}
                  className="px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <Link2 className="w-3.5 h-3.5 text-sky-600" />
                  <span>{isAr ? 'رابط' : 'Link'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => executeCommand('unlink')}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  title="فك الرابط"
                >
                  <Unlink className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const next = !showSymbolsPopover;
                    closeAllPopovers();
                    setShowSymbolsPopover(next);
                  }}
                  className="px-2.5 py-1 rounded-lg hover:bg-purple-50 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <Sigma className="w-3.5 h-3.5 text-purple-600" />
                  <span>{isAr ? 'رموز ومعادلات' : 'Symbols'}</span>
                </button>
              </div>

              {/* Live Table Row/Column Quick Tools */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px]">
                <span className="px-1.5 opacity-60">{isAr ? 'تعديل الجدول:' : 'Table:'}</span>
                <button type="button" onClick={handleTableAddRow} className="px-2 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 cursor-pointer flex items-center gap-0.5">
                  <Plus className="w-3 h-3" /> <span>صف</span>
                </button>
                <button type="button" onClick={handleTableAddCol} className="px-2 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 hover:bg-blue-100 cursor-pointer flex items-center gap-0.5">
                  <Plus className="w-3 h-3" /> <span>عمود</span>
                </button>
                <button type="button" onClick={handleTableDeleteRow} className="px-2 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300 hover:bg-rose-100 cursor-pointer flex items-center gap-0.5">
                  <Trash2 className="w-3 h-3" /> <span>صف</span>
                </button>
                <button type="button" onClick={handleTableDeleteCol} className="px-2 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300 hover:bg-rose-100 cursor-pointer flex items-center gap-0.5">
                  <Trash2 className="w-3 h-3" /> <span>عمود</span>
                </button>
              </div>

              {/* Columns & Separators */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px]">
                <button
                  type="button"
                  onClick={() =>
                    insertCustomBlock(
                      `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:12px 0;">
                        <div style="padding:12px;border-radius:12px;border:1px solid #cbd5e1;background:#f8fafc;"><strong>العمود الأول</strong><p>اكتب محتوى العمود هنا...</p></div>
                        <div style="padding:12px;border-radius:12px;border:1px solid #cbd5e1;background:#f8fafc;"><strong>العمود الثاني</strong><p>اكتب محتوى العمود المقابل هنا...</p></div>
                      </div><p><br/></p>`
                    )
                  }
                  className="px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <Columns className="w-3.5 h-3.5 text-amber-600" />
                  <span>عمودان</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    insertCustomBlock(
                      `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:12px 0;">
                        <div style="padding:10px;border-radius:12px;border:1px solid #cbd5e1;background:#f8fafc;"><strong>محور 1</strong><p>تفاصيل...</p></div>
                        <div style="padding:10px;border-radius:12px;border:1px solid #cbd5e1;background:#f8fafc;"><strong>محور 2</strong><p>تفاصيل...</p></div>
                        <div style="padding:10px;border-radius:12px;border:1px solid #cbd5e1;background:#f8fafc;"><strong>محور 3</strong><p>تفاصيل...</p></div>
                      </div><p><br/></p>`
                    )
                  }
                  className="px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                >
                  <Columns className="w-3.5 h-3.5 text-emerald-600" />
                  <span>3 أعمدة</span>
                </button>
                <button type="button" onClick={() => executeCommand('insertHorizontalRule')} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer" title="خط أفقي فاصل">
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    insertCustomBlock(
                      `<div style="page-break-after: always; border-top: 2px dashed #cbd5e1; margin: 16px 0; text-align: center; font-size: 11px; color: #94a3b8; padding-top: 4px;">--- فاصل صفحة للطباعة ---</div><p><br/></p>`
                    )
                  }
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  title="فاصل صفحة للطباعة"
                >
                  <SeparatorHorizontal className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Academic Callout Templates Strip */}
            <div className="flex flex-wrap items-center gap-1 bg-white dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] font-bold">
              <span className="px-1.5 opacity-65">{isAr ? 'صناديق تعليمية جاهزة:' : 'Callouts:'}</span>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="background-color: #ecfdf5; border: 1px solid #a7f3d0; padding: 12px 16px; border-radius: 12px; margin: 12px 0; color: #065f46;"><strong>💡 ملاحظة ذهبية:</strong> اكتب الملاحظة المهمة للطالب هنا...</div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 cursor-pointer"
              >
                💡 ملاحظة ذهبية
              </button>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="background-color: #eff6ff; border: 1px solid #bfdbfe; padding: 12px 16px; border-radius: 12px; margin: 12px 0; color: #1e3a8a;"><strong>📐 قاعدة / قانون أساسي:</strong> اكتب نص النظرية أو المعادلة القياسية هنا...</div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 hover:bg-blue-100 cursor-pointer"
              >
                📐 قاعدة / قانون
              </button>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="background-color: #f0fdf4; border: 1px solid #86efac; padding: 12px 16px; border-radius: 12px; margin: 12px 0; color: #14532d;"><strong>✅ مثال محلول خطوة بخطوة:</strong><br/>المعطيات: ...<br/>الحل النموذجي: ...</div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg bg-green-50 text-green-800 hover:bg-green-100 cursor-pointer"
              >
                ✅ مثال محلول
              </button>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="background-color: #fffbeb; border: 1px solid #fde68a; padding: 12px 16px; border-radius: 12px; margin: 12px 0; color: #78350f;"><strong>⚠️ تنبيه هام (أخطاء شائعة):</strong> انتبه عند التحويل أو تطبيق هذا الشرط...</div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 hover:bg-amber-100 cursor-pointer"
              >
                ⚠️ تنبيه هام
              </button>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="background-color: #faf5ff; border: 1px solid #d8b4fe; padding: 12px 16px; border-radius: 12px; margin: 12px 0; color: #581c87;"><strong>❓ سؤال تقويمي للطالب:</strong> اختبر فهمك عبر حل التمرين التالي...</div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg bg-purple-50 text-purple-800 hover:bg-purple-100 cursor-pointer"
              >
                ❓ سؤال تقويمي
              </button>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="background-color: #1e293b; color: #38bdf8; padding: 12px 16px; border-radius: 12px; font-family: monospace; direction: ltr; text-align: left; margin: 12px 0;">f'(x) = lim(h→0) [f(x+h) - f(x)] / h</div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-sky-300 hover:bg-slate-700 cursor-pointer flex items-center gap-1"
              >
                <Code className="w-3 h-3" />
                <span>معادلة / كود</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: PAGE LAYOUT */}
        {ribbonTab === 'layout' && (
          <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
            <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <span className="px-2 opacity-65">{isAr ? 'نمط الورقة:' : 'Paper:'}</span>
              {[
                { id: 'standard', label: 'أبيض قياسي' },
                { id: 'a4', label: 'ورقة A4 رسمية' },
                { id: 'lined', label: 'دفتر مسطر' },
                { id: 'dark', label: 'لوح داكن' },
              ].map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPaperMode(p.id as typeof paperMode)}
                  className={`px-2.5 py-1 rounded-lg cursor-pointer ${
                    paperMode === p.id
                      ? 'bg-emerald-700 text-white'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <span className="px-2 opacity-65">{isAr ? 'الهوامش:' : 'Margins:'}</span>
              {[
                { id: 'narrow', label: 'ضيق' },
                { id: 'normal', label: 'عادي' },
                { id: 'wide', label: 'واسع' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaperPadding(m.id as typeof paperPadding)}
                  className={`px-2.5 py-1 rounded-lg cursor-pointer ${
                    paperPadding === m.id
                      ? 'bg-blue-700 text-white'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="padding:14px 18px;border-radius:14px;background:linear-gradient(135deg,#0c3d36,#0f766e);color:#fff;margin-bottom:14px;">
                      <div style="font-size:11px;opacity:0.85;">${documentMeta || 'أكاديمية نوابغ التعليمية'}</div>
                      <h2 style="margin:4px 0;color:#fff;">${documentTitle || 'عنوان الدرس'}</h2>
                      <div style="font-size:12px;opacity:0.9;">إعداد المعلم: ${teacherName}</div>
                    </div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg hover:bg-emerald-50 text-emerald-700 dark:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                <LayoutTemplate className="w-3.5 h-3.5" />
                <span>ترويسة درس رسمية</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  insertCustomBlock(
                    `<div style="margin-top:18px;padding:12px 16px;border-top:2px solid #0c3d36;display:flex;justify-content:space-between;font-size:12px;color:#475569;">
                      <span><strong>إعداد:</strong> ${teacherName}</span>
                      <span><strong>منصة نوابغ التعليمية</strong> ✓</span>
                    </div><p><br/></p>`
                  )
                }
                className="px-2.5 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                <span>تذييل وتوقيع</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 4: INFOGRAPHICS INSIDE DOCUMENT */}
        {ribbonTab === 'infographic' && (
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>
                  {isAr
                    ? 'أدرج بلوكات انفوجرافيك احترافية جاهزة التعديل مباشرة في موضع المؤشر:'
                    : 'Insert editable Infographic Blocks at cursor position:'}
                </span>
              </span>

              {onAttachCurrentInfographic && (
                <button
                  type="button"
                  onClick={() => {
                    const html = onAttachCurrentInfographic();
                    if (html) insertCustomBlock(html);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-800 hover:to-teal-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>{isAr ? 'إدراج الانفوجرافيك المصمم في الاستوديو الآن' : 'Insert Studio Infographic Now'}</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5 text-[11px]">
              {BUILTIN_INFOGRAPHIC_SNIPPETS.map((snip) => (
                <button
                  key={snip.id}
                  type="button"
                  onClick={() => insertCustomBlock(snip.html)}
                  className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 text-start transition-all cursor-pointer flex flex-col gap-0.5"
                >
                  <span className="font-cairo font-bold text-slate-900 dark:text-white flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: snip.color }} />
                    <span className="truncate">{isAr ? snip.labelAr : snip.labelEn}</span>
                  </span>
                  <span className="text-[10px] text-slate-500 line-clamp-1">{snip.descAr}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: VIEW, FIND/REPLACE & EXPORT */}
        {ribbonTab === 'view' && (
          <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
            <button
              type="button"
              onClick={() => setShowFindReplace((v) => !v)}
              className={`px-3 py-1.5 rounded-xl border cursor-pointer flex items-center gap-1.5 ${
                showFindReplace
                  ? 'bg-amber-100 border-amber-400 text-amber-950'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>{isAr ? 'بحث واستبدال' : 'Find & Replace'}</span>
            </button>

            <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <ZoomIn className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={zoom}
                onChange={(e) => setZoom(Number(e.target.value))}
                className="bg-transparent font-mono-numbers font-bold cursor-pointer"
              >
                <option value={75}>75%</option>
                <option value={90}>90%</option>
                <option value={100}>100%</option>
                <option value={125}>125%</option>
                <option value={150}>150%</option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => setWidePaper((v) => !v)}
              className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              {widePaper ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              <span>{widePaper ? (isAr ? 'عرض صفحة A4' : 'A4 Page') : isAr ? 'توسيع العرض الكامل' : 'Full Width'}</span>
            </button>

            <button
              type="button"
              onClick={handleExportToWord}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1.5 cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>{isAr ? 'تنزيل Word (.doc)' : 'Export .doc'}</span>
            </button>

            <button
              type="button"
              onClick={handleExportHtml}
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white flex items-center gap-1.5 cursor-pointer"
            >
              <FileCode2 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تنزيل صفحة HTML' : 'Export HTML'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsPdfPrintPreviewOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isAr ? 'معاينة وطباعة PDF' : 'Print PDF'}</span>
            </button>
          </div>
        )}

        {/* POPOVER: VISUAL TABLE BUILDER */}
        {showTablePopover && (
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 shadow-lg flex flex-col sm:flex-row sm:items-center gap-4 text-xs">
            <div className="space-y-1.5">
              <div className="font-bold text-slate-700 dark:text-slate-200">
                {isAr
                  ? `تحديد سريع بالشبكة (${hoverCell.r || tableRows} × ${hoverCell.c || tableCols}):`
                  : `Quick Grid (${hoverCell.r || tableRows} × ${hoverCell.c || tableCols}):`}
              </div>
              <div
                className="grid grid-cols-6 gap-1 w-fit"
                onMouseLeave={() => setHoverCell({ r: 0, c: 0 })}
              >
                {Array.from({ length: 6 }).map((_, rIdx) =>
                  Array.from({ length: 6 }).map((__, cIdx) => {
                    const active = rIdx < hoverCell.r && cIdx < hoverCell.c;
                    return (
                      <button
                        key={`${rIdx}-${cIdx}`}
                        type="button"
                        onMouseEnter={() => setHoverCell({ r: rIdx + 1, c: cIdx + 1 })}
                        onClick={() => handleInsertTable(Math.max(2, rIdx + 1), cIdx + 1)}
                        className={`w-5 h-5 rounded border cursor-pointer transition-colors ${
                          active
                            ? 'bg-emerald-600 border-emerald-700'
                            : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600'
                        }`}
                      />
                    );
                  })
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <label className="flex items-center gap-1">
                <span>صفوف:</span>
                <input
                  type="number"
                  min={2}
                  max={12}
                  value={tableRows}
                  onChange={(e) => setTableRows(Number(e.target.value))}
                  className="w-14 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono-numbers"
                />
              </label>
              <label className="flex items-center gap-1">
                <span>أعمدة:</span>
                <input
                  type="number"
                  min={1}
                  max={8}
                  value={tableCols}
                  onChange={(e) => setTableCols(Number(e.target.value))}
                  className="w-14 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono-numbers"
                />
              </label>
              <select
                value={tableHeaderTheme}
                onChange={(e) => setTableHeaderTheme(e.target.value as typeof tableHeaderTheme)}
                className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
              >
                <option value="emerald">رأس زمردي</option>
                <option value="indigo">رأس نيلي</option>
                <option value="amber">رأس ذهبي</option>
                <option value="slate">رأس داكن</option>
              </select>
              <label className="flex items-center gap-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={tableStriped}
                  onChange={(e) => setTableStriped(e.target.checked)}
                />
                <span>صفوف مخططة</span>
              </label>
              <button
                type="button"
                onClick={() => handleInsertTable()}
                className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-bold cursor-pointer"
              >
                إدراج الجدول
              </button>
              <button
                type="button"
                onClick={() => setShowTablePopover(false)}
                className="px-2 py-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        )}

        {/* POPOVER: IMAGE INSERT */}
        {showImagePopover && (
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 shadow-lg flex flex-wrap items-center gap-2 text-xs">
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="الصق رابط الصورة المباشر (https://...)"
              className="flex-1 min-w-[180px] px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
            <select
              value={imageWidth}
              onChange={(e) => setImageWidth(e.target.value as typeof imageWidth)}
              className="px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono-numbers font-bold"
              title="حجم الصورة"
            >
              <option value="25%">عرض 25%</option>
              <option value="50%">عرض 50%</option>
              <option value="75%">عرض 75%</option>
              <option value="100%">عرض 100%</option>
            </select>
            <select
              value={imageAlign}
              onChange={(e) => setImageAlign(e.target.value as typeof imageAlign)}
              className="px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
            >
              <option value="center">توسيط</option>
              <option value="right">يمين</option>
              <option value="left">يسار</option>
            </select>
            <button
              type="button"
              onClick={handleInsertImageUrl}
              className="px-3 py-1.5 rounded-lg bg-blue-600 text-white font-bold cursor-pointer"
            >
              إدراج بالرابط
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleUploadImageFile}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-bold cursor-pointer"
            >
              رفع صورة من الجهاز
            </button>
            <button
              type="button"
              onClick={() => setShowImagePopover(false)}
              className="px-2 py-1 text-slate-400 cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* POPOVER: VIDEO EMBED */}
        {showVideoPopover && (
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 shadow-lg flex flex-wrap items-center gap-2 text-xs">
            <input
              type="url"
              value={videoEmbedInput}
              onChange={(e) => setVideoEmbedInput(e.target.value)}
              placeholder="رابط فيديو YouTube أو رابط MP4 مباشر..."
              className="flex-1 min-w-[220px] px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
            />
            <button
              type="button"
              onClick={handleInsertVideo}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold cursor-pointer"
            >
              تضمين الفيديو داخل النص
            </button>
            <button
              type="button"
              onClick={() => setShowVideoPopover(false)}
              className="px-2 py-1 text-slate-400 cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        )}

        {/* POPOVER: LINK INSERT */}
        {showLinkPopover && (
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 shadow-lg flex flex-wrap items-center gap-2 text-xs">
            <input
              type="text"
              value={linkText}
              onChange={(e) => setLinkText(e.target.value)}
              placeholder="نص الرابط (اختياري)"
              className="w-40 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
            <input
              type="url"
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              placeholder="https://example.com"
              className="flex-1 min-w-[180px] px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
            />
            <button
              type="button"
              onClick={handleInsertLink}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold cursor-pointer"
            >
              تطبيق الرابط
            </button>
            <button
              type="button"
              onClick={() => setShowLinkPopover(false)}
              className="px-2 py-1 text-slate-400 cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        )}

        {/* POPOVER: MATH SYMBOLS */}
        {showSymbolsPopover && (
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 shadow-lg flex flex-wrap items-center gap-1.5 text-sm">
            {MATH_SYMBOLS.map((sym) => (
              <button
                key={sym}
                type="button"
                onClick={() => insertCustomBlock(`<span>${sym}</span>`)}
                className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-emerald-100 dark:bg-slate-800 dark:hover:bg-emerald-900 font-mono font-bold flex items-center justify-center cursor-pointer"
              >
                {sym}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setShowSymbolsPopover(false)}
              className="px-2 py-1 text-xs text-slate-400 cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* FIND & REPLACE BAR */}
        {showFindReplace && (
          <div className="p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-800 flex flex-wrap items-center gap-2 text-xs">
            <input
              type="text"
              value={findQuery}
              onChange={(e) => setFindQuery(e.target.value)}
              placeholder="البحث عن..."
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
            <input
              type="text"
              value={replaceQuery}
              onChange={(e) => setReplaceQuery(e.target.value)}
              placeholder="استبدال بـ..."
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
            <button
              type="button"
              onClick={handleReplaceAll}
              className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold cursor-pointer"
            >
              استبدال الكل
            </button>
            <button
              type="button"
              onClick={() => setShowFindReplace(false)}
              className="px-2 py-1 text-slate-400 cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}
      </div>

      {/* LIVE OFFICE WRITING PAPER CANVAS */}
      <div className="flex-1 p-2 md:p-3 overflow-y-auto bg-slate-100 dark:bg-slate-950 flex justify-center items-start">
        <div
          style={{
            transform: `scale(${zoom / 100})`,
            transformOrigin: 'top center',
            lineHeight,
          }}
          className={`w-full min-h-full ${
            widePaper ? 'max-w-full' : 'max-w-4xl'
          } rounded-2xl shadow-md border ${paperBgClass} ${paperPaddingClass} transition-all relative flex flex-col`}
        >
          <AlSharifWatermark extraLabel={documentTitle} opacity="light" />
          {isSheetVisuallyEmpty && (
            <div className="pointer-events-none select-none opacity-50 font-tajawal text-sm md:text-base mb-[-28px] relative z-30">
              {isAr ? placeholderAr : placeholderEn}
            </div>
          )}

          <div
            ref={editorRef}
            contentEditable
            suppressContentEditableWarning
            onInput={syncFromDom}
            className="flex-1 w-full outline-hidden ck-rich-content font-tajawal text-sm md:text-base focus:ring-0 relative z-30"
            style={{ minHeight: `${minHeight}px`, lineHeight }}
          />
        </div>
      </div>

      {/* WORD-STYLE STATUS BAR */}
      <div className="px-3 py-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 font-mono-numbers">
        <div className="flex flex-wrap items-center gap-3 md:gap-4">
          <span>
            {isAr ? 'الكلمات:' : 'Words:'} <strong>{wordsCount}</strong>
          </span>
          <span>
            {isAr ? 'الأحرف:' : 'Chars:'} <strong>{charsCount}</strong>
          </span>
          <span>
            {isAr ? 'وقت القراءة:' : 'Read time:'}{' '}
            <strong>
              {readingTimeMin} {isAr ? 'دقيقة' : 'min'}
            </strong>
          </span>
        </div>

        <div className="flex items-center gap-2 font-cairo">
          <div className="flex items-center gap-1 text-[11px] bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-lg">
            <ZoomIn className="w-3 h-3" />
            <select
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="bg-transparent font-mono-numbers font-bold cursor-pointer"
            >
              <option value={75}>75%</option>
              <option value={90}>90%</option>
              <option value={100}>100%</option>
              <option value={125}>125%</option>
              <option value={150}>150%</option>
            </select>
          </div>

          <button
            type="button"
            onClick={handleExportToWord}
            className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer md:hidden"
          >
            <FileDown className="w-3 h-3" />
            <span>Word</span>
          </button>
          <button
            type="button"
            onClick={() => setIsPdfPrintPreviewOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-[11px] flex items-center gap-1 cursor-pointer md:hidden"
          >
            <Printer className="w-3 h-3" />
            <span>PDF</span>
          </button>
        </div>
      </div>

      {/* PRINT-READY PDF PREVIEW MODAL */}
      {isPdfPrintPreviewOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-3xl bg-white text-slate-900 rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col font-cairo">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-emerald-950 text-white">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <h4 className="font-bold text-sm md:text-base">
                  {isAr ? 'معاينة وتصدير المستند بصيغة PDF الرسمية' : 'Official PDF Document Preview'}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setIsPdfPrintPreviewOpen(false)}
                className="p-1 rounded text-white/80 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-8 md:p-12 overflow-y-auto space-y-6 relative">
              <AlSharifWatermark extraLabel={documentTitle} opacity="medium" />
              <div className="border-b-2 border-emerald-900 pb-4 flex items-center justify-between relative z-30">
                <div>
                  <h2 className="text-xl font-black text-emerald-950">
                    {documentTitle || 'وثيقة درس ومذكرة تعليمية'}
                  </h2>
                  {documentMeta && <p className="text-xs text-slate-500 font-tajawal">{documentMeta}</p>}
                </div>
                <div className="text-left font-mono-numbers text-xs text-slate-500">
                  <p>
                    <strong>المنصة:</strong> منصة الشريف
                  </p>
                  <p>
                    <strong>تاريخ الإصدار:</strong> {new Date().toLocaleDateString('ar-SA')}
                  </p>
                  <p>
                    <strong>المعلم:</strong> {teacherName}
                  </p>
                </div>
              </div>

              <div
                dangerouslySetInnerHTML={{
                  __html: editorRef.current ? editorRef.current.innerHTML : value,
                }}
                className="ck-rich-content font-tajawal text-sm leading-relaxed min-h-[200px] relative z-30"
              />

              <div className="pt-8 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 font-tajawal relative z-30">
                <div>
                  <p className="font-bold text-emerald-950">منصة الشريف التعليمية</p>
                  <p>مذكرة ووثيقة تعليمية محررة ومحمية بعلامة مائية عبر منصة الشريف</p>
                </div>
                <div className="w-28 h-10 border border-dashed border-emerald-600 rounded flex items-center justify-center text-[10px] text-emerald-800 font-bold">
                  علامة مائية: منصة الشريف ✓
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 flex items-center justify-between bg-slate-50">
              <span className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? 'اختر "حفظ كـ PDF" من نافذة الطباعة لتنزيل الملف'
                  : 'Choose "Save as PDF" in your print dialog'}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPdfPrintPreviewOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{isAr ? 'طباعة وتنزيل PDF' : 'Print / Save PDF'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
