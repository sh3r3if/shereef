import React, { useState, useEffect } from 'react';
import {
  Users,
  ShieldCheck,
  UserPlus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
  KeyRound,
  Mail,
  Phone,
  ShieldAlert,
  X,
  RefreshCw,
  HelpCircle,
  Lock,
  User,
  AlertCircle,
  Clock,
  Power,
} from 'lucide-react';
import { Language, CurrentUser } from '../types';
import { getAuthHeaders } from '../utils/rbac';

export interface MemberRecord {
  id: number;
  uid: string;
  email: string;
  username?: string | null;
  displayName: string;
  displayNameEn?: string | null;
  password?: string | null;
  securityQuestion?: string | null;
  securityAnswer?: string | null;
  role: 'admin' | 'secretary' | 'supervisor' | 'teacher' | 'student' | 'female_student' | 'parent';
  roleTitle?: string | null;
  phone?: string | null;
  permissions: string; // JSON string of granted permission keys
  isActive: boolean | null;
  avatar?: string | null;
  notes?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
}

const AVAILABLE_PERMISSIONS = [
  { key: 'manage_students', labelAr: 'إدارة شؤون الطلاب والدرجات', labelEn: 'Manage Students & Grades' },
  { key: 'manage_teachers', labelAr: 'إدارة ملفات المدرسين', labelEn: 'Manage Teachers Directory' },
  { key: 'manage_lessons', labelAr: 'إدارة الدروس والمكتبة الرقمية', labelEn: 'Manage Lessons & Library' },
  { key: 'manage_quizzes', labelAr: 'إنشاء وتصحيح الاختبارات', labelEn: 'Manage Quizzes & Exams' },
  { key: 'manage_certificates', labelAr: 'إصدار شهادات التقدير والدرجات', labelEn: 'Manage Certificates' },
  { key: 'manage_finances', labelAr: 'إدارة الرسوم والفواتير المالية', labelEn: 'Manage Finances & Tuition' },
  { key: 'manage_whiteboard', labelAr: 'التحكم بالسبورة التفاعلية والبث', labelEn: 'Control Interactive Whiteboard' },
  { key: 'manage_triage', labelAr: 'متابعة الجرد الأسبوعي للمستويات', labelEn: 'Manage Weekly Triage' },
  { key: 'manage_timetable', labelAr: 'تنظيم جدول الحصص والمقررات', labelEn: 'Manage Timetable & Schedule' },
  { key: 'manage_faqs', labelAr: 'إدارة مركز الاستفسارات والإشعارات', labelEn: 'Manage Inquiries & Notifications' },
  { key: 'manage_members', labelAr: 'تسجيل الأعضاء وتفعيل الحسابات', labelEn: 'Manage Members & Activation' },
  { key: 'manage_backups', labelAr: 'إنشاء وتصدير النسخ الاحتياطية', labelEn: 'Manage Database Backups' },
  { key: 'manage_settings', labelAr: 'تخصيص هوية المدرسة والإعدادات', labelEn: 'Manage School Settings' },
];

const PRESET_SECURITY_QUESTIONS = [
  'ما هو اسم مدرستك الابتدائية الأولى؟',
  'ما هو اسم أول معلم درّسك في الصغر؟',
  'ما هو كتابك أو مقررك المفضل؟',
  'ما هو اسم المدينة التي ولدت بها؟',
  'ما هو اسم صديق طفولتك المفضل؟',
  'سؤال سري مخصص...',
];

interface Props {
  language: Language;
  currentUser: CurrentUser;
  onLogAction: (actionAr: string, type: string, name: string, details: string) => void;
}

export const MembersAndRolesManager: React.FC<Props> = ({
  language,
  currentUser,
  onLogAction,
}) => {
  const isAr = language === 'ar';
  const [members, setMembers] = useState<MemberRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<MemberRecord | null>(null);
  const [viewingMember, setViewingMember] = useState<MemberRecord | null>(null);
  const [deletingMember, setDeletingMember] = useState<MemberRecord | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    displayName: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    selectedQuestionPreset: PRESET_SECURITY_QUESTIONS[0],
    customQuestion: '',
    securityAnswer: '',
    phone: '',
    role: 'supervisor' as MemberRecord['role'],
    roleTitle: '',
    permissions: [] as string[],
    isActive: true,
    notes: '',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showViewingSecret, setShowViewingSecret] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Load members from real Cloud SQL backend API
  const fetchMembers = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/members');
      if (res.ok) {
        const data = await res.json();
        setMembers(data);
      }
    } catch (err) {
      console.error('Failed to fetch members:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, []);

  // Filtered members list
  const filteredMembers = members.filter((m) => {
    const matchesSearch =
      m.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.username && m.username.toLowerCase().includes(searchQuery.toLowerCase())) ||
      m.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.roleTitle && m.roleTitle.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (m.phone && m.phone.includes(searchQuery));

    const matchesRole = roleFilter === 'all' || m.role === roleFilter;
    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'active' && m.isActive) ||
      (statusFilter === 'inactive' && !m.isActive);

    return matchesSearch && matchesRole && matchesStatus;
  });

  // Open modal for Create
  const handleOpenCreate = () => {
    setValidationError(null);
    setShowPassword(false);
    setShowConfirmPassword(false);
    setFormData({
      displayName: '',
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      selectedQuestionPreset: PRESET_SECURITY_QUESTIONS[0],
      customQuestion: '',
      securityAnswer: '',
      phone: '',
      role: 'supervisor',
      roleTitle: isAr ? 'مشرف أكاديمي' : 'Academic Supervisor',
      permissions: ['manage_students', 'manage_lessons', 'manage_quizzes'],
      isActive: true,
      notes: '',
    });
    setIsAddModalOpen(true);
  };

  // Open modal for Edit
  const handleOpenEdit = (member: MemberRecord) => {
    setValidationError(null);
    setShowPassword(false);
    setShowConfirmPassword(false);
    let parsedPerms: string[] = [];
    try {
      parsedPerms = JSON.parse(member.permissions || '[]');
    } catch {
      parsedPerms = [];
    }

    const currentQ = member.securityQuestion || PRESET_SECURITY_QUESTIONS[0];
    const isPreset = PRESET_SECURITY_QUESTIONS.includes(currentQ);

    setEditingMember(member);
    setFormData({
      displayName: member.displayName,
      username: member.username || member.email.split('@')[0],
      email: member.email,
      password: member.password || '',
      confirmPassword: member.password || '',
      selectedQuestionPreset: isPreset ? currentQ : 'سؤال سري مخصص...',
      customQuestion: isPreset ? '' : currentQ,
      securityAnswer: member.securityAnswer || '',
      phone: member.phone || '',
      role: member.role,
      roleTitle: member.roleTitle || '',
      permissions: parsedPerms,
      isActive: member.isActive ?? true,
      notes: member.notes || '',
    });
  };

  // Save (Create or Update)
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // Validate Password matching
    if (formData.password !== formData.confirmPassword) {
      setValidationError(
        isAr
          ? 'عذراً، كلمتا المرور غير متطابقتين! يرجى التأكد من تطابق كلمة المرور وتأكيدها.'
          : 'Passwords do not match! Please check and confirm your password.'
      );
      return;
    }

    if (!formData.password || formData.password.length < 4) {
      setValidationError(
        isAr
          ? 'يجب أن تتكون كلمة المرور من 4 خانات على الأقل.'
          : 'Password must be at least 4 characters long.'
      );
      return;
    }

    const finalQuestion =
      formData.selectedQuestionPreset === 'سؤال سري مخصص...'
        ? formData.customQuestion.trim()
        : formData.selectedQuestionPreset;

    if (!finalQuestion) {
      setValidationError(isAr ? 'يرجى كتابة أو اختيار السؤال السري.' : 'Please specify a security question.');
      return;
    }

    if (!formData.securityAnswer.trim()) {
      setValidationError(isAr ? 'يرجى كتابة الإجابة على السؤال السري.' : 'Please enter security answer.');
      return;
    }

    try {
      if (editingMember) {
        // UPDATE
        const res = await fetch(`/api/members/${editingMember.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
          body: JSON.stringify({
            displayName: formData.displayName,
            username: formData.username.trim(),
            password: formData.password.trim(),
            securityQuestion: finalQuestion,
            securityAnswer: formData.securityAnswer.trim(),
            email: formData.email,
            phone: formData.phone,
            role: formData.role,
            roleTitle: formData.roleTitle,
            permissions: JSON.stringify(formData.permissions),
            isActive: formData.isActive,
            notes: formData.notes,
          }),
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          setValidationError(data.error || (isAr ? 'تعذر تحديث بيانات العضو في قاعدة البيانات' : 'Update failed'));
          return;
        }
        setMembers((prev) => prev.map((m) => (m.id === data.id ? data : m)));
        setEditingMember(null);
      } else {
        // CREATE
        const newUid = `usr-${Date.now()}`;
        const res = await fetch('/api/members', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
          body: JSON.stringify({
            uid: newUid,
            displayName: formData.displayName,
            username: formData.username.trim() || formData.email.split('@')[0],
            password: formData.password.trim(),
            securityQuestion: finalQuestion,
            securityAnswer: formData.securityAnswer.trim(),
            email: formData.email,
            phone: formData.phone,
            role: formData.role,
            roleTitle: formData.roleTitle,
            permissions: JSON.stringify(formData.permissions),
            isActive: formData.isActive,
            notes: formData.notes,
          }),
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          setValidationError(data.error || (isAr ? 'تعذر تسجيل العضو في قاعدة البيانات' : 'Registration failed'));
          return;
        }
        setMembers((prev) => [data, ...prev]);
        onLogAction(
          'تسجيل عضو جديد مع كلمة المرور والسؤال السري',
          'member',
          formData.displayName,
          `تم قيد العضو باسم مستخدم (${formData.username}) ودور (${formData.roleTitle})`
        );
        setIsAddModalOpen(false);
      }
    } catch (err: any) {
      setValidationError(err?.message || (isAr ? 'حدث خطأ أثناء الاتصال بالخادم' : 'Network error'));
    }
  };

  // 1-Click Activate / Deactivate Account by Admin
  const handleToggleActive = async (member: MemberRecord) => {
    const nextActive = !member.isActive;
    try {
      const res = await fetch(`/api/members/${member.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify({ isActive: nextActive }),
      });
      if (res.ok) {
        const updated = await res.json();
        setMembers((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
      }
    } catch (err) {
      console.error('Failed to toggle member activation:', err);
    }
  };

  // Delete
  const handleDeleteConfirm = async () => {
    if (!deletingMember) return;
    try {
      const res = await fetch(`/api/members/${deletingMember.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser),
      });
      if (res.ok) {
        setMembers((prev) => prev.filter((m) => m.id !== deletingMember.id));
      }
      setDeletingMember(null);
    } catch (err) {
      console.error('Failed to delete member:', err);
    }
  };

  // Permission checkbox toggle helper
  const handleTogglePermission = (key: string) => {
    if (formData.permissions.includes(key)) {
      setFormData({
        ...formData,
        permissions: formData.permissions.filter((p) => p !== key),
      });
    } else {
      setFormData({
        ...formData,
        permissions: [...formData.permissions, key],
      });
    }
  };

  // Quick preset buttons for role-based permissions
  const handleApplyRoleDefaults = (role: MemberRecord['role']) => {
    if (role === 'admin') {
      setFormData((prev) => ({
        ...prev,
        role,
        roleTitle: prev.roleTitle || (isAr ? 'مدير عام' : 'General Admin'),
        permissions: AVAILABLE_PERMISSIONS.map((p) => p.key),
      }));
    } else if (role === 'secretary') {
      setFormData((prev) => ({
        ...prev,
        role,
        roleTitle: isAr ? 'سكرتارية' : 'Secretary',
        permissions: [
          'manage_students',
          'manage_certificates',
          'manage_finances',
          'manage_timetable',
          'manage_faqs',
        ],
      }));
    } else if (role === 'supervisor') {
      setFormData((prev) => ({
        ...prev,
        role,
        roleTitle: isAr ? 'مشرف أكاديمي' : 'Supervisor',
        permissions: [
          'manage_students',
          'manage_teachers',
          'manage_lessons',
          'manage_quizzes',
          'manage_certificates',
          'manage_whiteboard',
          'manage_triage',
          'manage_timetable',
          'manage_faqs',
        ],
      }));
    } else if (role === 'teacher') {
      setFormData((prev) => ({
        ...prev,
        role,
        roleTitle: isAr ? 'معلم' : 'Teacher',
        permissions: ['manage_lessons', 'manage_quizzes', 'manage_whiteboard'],
      }));
    } else {
      const titles: Record<string, string> = {
        student: isAr ? 'طالب' : 'Student',
        female_student: isAr ? 'طالبة' : 'Female Student',
        parent: isAr ? 'ولي أمر' : 'Parent',
      };
      setFormData((prev) => ({
        ...prev,
        role,
        roleTitle: titles[role] || '',
        permissions: [],
      }));
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin':
        return isAr ? 'مدير عام' : 'Admin';
      case 'secretary':
        return isAr ? 'سكرتارية' : 'Secretary';
      case 'supervisor':
        return isAr ? 'مشرفين' : 'Supervisor';
      case 'teacher':
        return isAr ? 'معلم' : 'Teacher';
      case 'student':
        return isAr ? 'طالب' : 'Student';
      case 'female_student':
        return isAr ? 'طالبة' : 'Female Student';
      case 'parent':
        return isAr ? 'ولي أمر' : 'Parent';
      default:
        return role.toUpperCase();
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border-purple-200';
      case 'secretary':
        return 'bg-pink-100 text-pink-800 dark:bg-pink-950 dark:text-pink-300 border-pink-200';
      case 'supervisor':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border-blue-200';
      case 'teacher':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200';
      case 'student':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-200';
      case 'female_student':
        return 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 border-teal-200';
      case 'parent':
        return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200';
      default:
        return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-200';
    }
  };

  const pendingApprovalCount = members.filter((m) => !m.isActive).length;

  const isPasswordMatch =
    Boolean(formData.confirmPassword) && formData.password === formData.confirmPassword;
  const isPasswordMismatch =
    Boolean(formData.confirmPassword) && formData.password !== formData.confirmPassword;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="space-y-1.5 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
            <ShieldCheck className="w-4 h-4" />
            <span>{isAr ? 'منظومة إدارة الأعضاء والصلاحيات' : 'RBAC Access Management'}</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black font-cairo">
            {isAr ? 'تسجيل الأعضاء وتحديد الصلاحيات' : 'Members & Permissions Manager'}
          </h2>
          <p className="text-xs md:text-sm text-slate-300 max-w-2xl font-tajawal">
            {isAr
              ? 'تسجيل الأعضاء بالاسم العربي الكامل، تعيين كلمة المرور مع التحقق من التطابق، السؤال السري والإجابة، وتحديد الصلاحيات الجزئية متزامنة مع قاعدة بيانات Cloud SQL.'
              : 'Register members with full Arabic name, verified password, secret security question & answer, and granular permissions.'}
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <button
            onClick={handleOpenCreate}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-cairo font-bold text-xs md:text-sm shadow-lg transition-all cursor-pointer transform hover:-translate-y-0.5"
          >
            <UserPlus className="w-4 h-4 text-slate-950" />
            <span>{isAr ? 'تسجيل عضو جديد' : 'Add New Member'}</span>
          </button>
        </div>
      </div>

      {/* Pending Activation Alert Banner */}
      {pendingApprovalCount > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border-2 border-amber-300 dark:border-amber-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-cairo font-bold text-sm text-amber-950 dark:text-amber-200">
                {isAr
                  ? `يوجد ${pendingApprovalCount} حساب بانتظار التفعيل من الأدمن`
                  : `${pendingApprovalCount} account(s) pending Admin activation`}
              </h4>
              <p className="text-xs text-amber-800 dark:text-amber-300 font-tajawal">
                {isAr
                  ? 'لا يستطيع أصحاب هذه الحسابات تسجيل الدخول حتى تقوم بالضغط على زر "تفعيل" بجانب كل حساب.'
                  : 'These users cannot sign in until you activate their accounts.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setStatusFilter(statusFilter === 'inactive' ? 'all' : 'inactive')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-cairo font-bold text-xs shadow-xs cursor-pointer shrink-0"
          >
            {statusFilter === 'inactive'
              ? isAr
                ? 'عرض جميع الحسابات'
                : 'Show All Accounts'
              : isAr
              ? 'عرض الحسابات المنتظرة للتفعيل'
              : 'Filter Pending Accounts'}
          </button>
        </div>
      )}

      {/* Search and Filters Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 right-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isAr
                ? 'البحث بالاسم، اسم المستخدم، البريد، أو المسمى الوظيفي...'
                : 'Search by name, username, email, title...'
            }
            className="w-full pr-10 pl-4 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-tajawal"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 rounded-xl text-xs font-cairo bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
          >
            <option value="all">{isAr ? 'كافة الأدوار' : 'All Roles'}</option>
            <option value="admin">{isAr ? 'مدير عام' : 'Admin'}</option>
            <option value="secretary">{isAr ? 'سكرتارية' : 'Secretary'}</option>
            <option value="supervisor">{isAr ? 'مشرفين' : 'Supervisor'}</option>
            <option value="teacher">{isAr ? 'معلم' : 'Teacher'}</option>
            <option value="student">{isAr ? 'طالب' : 'Student'}</option>
            <option value="female_student">{isAr ? 'طالبة' : 'Female Student'}</option>
            <option value="parent">{isAr ? 'ولي أمر' : 'Parent'}</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl text-xs font-cairo bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
          >
            <option value="all">{isAr ? 'كافة الحالات' : 'All Status'}</option>
            <option value="active">{isAr ? 'مفعّل ونشط' : 'Active Only'}</option>
            <option value="inactive">{isAr ? 'بانتظار التفعيل / معطل' : 'Pending / Inactive'}</option>
          </select>

          <button
            onClick={fetchMembers}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
            title={isAr ? 'تحديث السجلات من قاعدة البيانات' : 'Refresh'}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Members Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs md:text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 text-xs font-cairo">
              <tr>
                <th className="py-3 px-4 font-bold">{isAr ? 'العضو / اسم المستخدم' : 'Member / Username'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'الدور والمسمى' : 'Role & Title'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'الصلاحيات المخصصة' : 'Permissions'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'السؤال السري' : 'Security Question'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'الحالة' : 'Status'}</th>
                <th className="py-3 px-4 font-bold text-center">{isAr ? 'الإجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-tajawal">
              {filteredMembers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    <Users className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                    <p className="font-cairo font-bold">
                      {isAr ? 'لم يتم العثور على أعضاء مطابقين للبحث' : 'No members found'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredMembers.map((member) => {
                  let permsList: string[] = [];
                  try {
                    permsList = JSON.parse(member.permissions || '[]');
                  } catch {
                    permsList = [];
                  }

                  const isSuperAdmin = permsList.includes('all') || member.role === 'admin';

                  return (
                    <tr
                      key={member.id}
                      className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      {/* Name & Username */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-700 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                            {member.displayName.slice(0, 2)}
                          </div>
                          <div>
                            <p className="font-bold font-cairo text-slate-900 dark:text-white">
                              {member.displayName}
                            </p>
                            <p className="text-xs text-indigo-600 dark:text-indigo-400 font-mono-numbers">
                              @{member.username || member.email.split('@')[0]}
                            </p>
                            <p className="text-[11px] text-slate-400 font-mono-numbers">
                              {member.email}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Role & Title */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold border ${getRoleBadgeColor(
                              member.role
                            )}`}
                          >
                            {getRoleLabel(member.role)}
                          </span>
                          <p className="text-xs text-slate-600 dark:text-slate-300 font-semibold truncate">
                            {member.roleTitle || getRoleLabel(member.role)}
                          </p>
                        </div>
                      </td>

                      {/* Permissions */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1">
                          {isSuperAdmin ? (
                            <span className="px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 text-[11px] font-bold border border-purple-200 dark:border-purple-800">
                              ⚡ {isAr ? 'كافة الصلاحيات (Admin Full)' : 'All Privileges'}
                            </span>
                          ) : permsList.length > 0 ? (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold border border-emerald-200 dark:border-emerald-800">
                              {permsList.length} {isAr ? 'صلاحيات مخصصة' : 'custom permissions'}
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400">
                              {isAr ? 'صلاحيات الدور القياسية' : 'Standard role access'}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Security Question */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 truncate max-w-xs">
                          <HelpCircle className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                          <span className="truncate" title={member.securityQuestion || 'ما هو اسم مدرستك الابتدائية؟'}>
                            {member.securityQuestion || (isAr ? 'ما هو اسم مدرستك الابتدائية؟' : 'Primary school?')}
                          </span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {member.isActive ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {isAr ? 'مفعّل' : 'Active'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-[11px] font-bold text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                            <Clock className="w-3 h-3" />
                            {isAr ? 'بانتظار التفعيل' : 'Pending Approval'}
                          </span>
                        )}
                      </td>

                      {/* CRUD & Activation Actions */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Quick 1-click Activate / Deactivate */}
                          {member.uid !== 'usr-super-admin' && (
                            <button
                              onClick={() => handleToggleActive(member)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                                member.isActive
                                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-amber-100 hover:text-amber-800'
                                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                              }`}
                              title={member.isActive ? (isAr ? 'إيقاف الحساب' : 'Deactivate') : (isAr ? 'تفعيل الحساب الآن' : 'Activate Now')}
                            >
                              <Power className="w-3 h-3" />
                              <span>{member.isActive ? (isAr ? 'تعطيل' : 'Disable') : (isAr ? 'تفعيل' : 'Activate')}</span>
                            </button>
                          )}

                          {/* View Details */}
                          <button
                            onClick={() => {
                              setShowViewingSecret(false);
                              setViewingMember(member);
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 transition-colors cursor-pointer"
                            title={isAr ? 'مشاهدة التفاصيل' : 'View Details'}
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Edit */}
                          <button
                            onClick={() => handleOpenEdit(member)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/60 transition-colors cursor-pointer"
                            title={isAr ? 'تعديل الصلاحيات والباسورد' : 'Edit Member'}
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {/* Delete */}
                          {member.uid !== 'usr-super-admin' && (
                            <button
                              onClick={() => setDeletingMember(member)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors cursor-pointer"
                              title={isAr ? 'حذف العضو' : 'Delete Member'}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: ADD / EDIT MEMBER (Single Arabic Name, Password, Matching, Security Question & Answer) */}
      {(isAddModalOpen || editingMember) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-5 my-8 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300 flex items-center justify-center font-bold">
                  <KeyRound className="w-4 h-4" />
                </div>
                <h3 className="font-cairo font-bold text-lg text-slate-900 dark:text-white">
                  {editingMember
                    ? isAr
                      ? 'تعديل بيانات وصلاحيات العضو'
                      : 'Edit Member & Permissions'
                    : isAr
                    ? 'تسجيل عضو جديد وتحديد صلاحياته'
                    : 'Register Member & Set Permissions'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingMember(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Validation Error Banner */}
            {validationError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{validationError}</span>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4 font-tajawal">
              {/* 1. Name and Username */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Single Arabic Full Name Field */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'اسم العضو الكامل (بالعربية) *' : 'Member Full Name (Arabic) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.displayName}
                    onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                    placeholder={isAr ? 'مثال: أ. د. عبد الله الشهراني' : 'e.g. Abdullah Al-Shahrani'}
                    className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                {/* Username */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'اسم المستخدم للدخول (Username) *' : 'Username for Login *'}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                      placeholder="e.g. abdullah2026"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* 2. Password and Confirm Password with Matching Verification */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/80">
                {/* Password */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 font-cairo">
                      {isAr ? 'كلمة المرور *' : 'Password *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[11px] text-slate-500 hover:text-emerald-600 flex items-center gap-1 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showPassword ? (isAr ? 'إخفاء' : 'Hide') : (isAr ? 'إظهار' : 'Show')}</span>
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="••••••••"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Confirm Password & Matching Indicator */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 font-cairo">
                      {isAr ? 'تأكيد كلمة المرور *' : 'Confirm Password *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="text-[11px] text-slate-500 hover:text-emerald-600 flex items-center gap-1 cursor-pointer"
                    >
                      {showConfirmPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showConfirmPassword ? (isAr ? 'إخفاء' : 'Hide') : (isAr ? 'إظهار' : 'Show')}</span>
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      required
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      placeholder="••••••••"
                      className={`w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-white dark:bg-slate-800 border text-slate-800 dark:text-white focus:outline-none ${
                        isPasswordMatch
                          ? 'border-emerald-500 ring-1 ring-emerald-500'
                          : isPasswordMismatch
                          ? 'border-rose-500 ring-1 ring-rose-500'
                          : 'border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-emerald-500'
                      }`}
                    />
                  </div>

                  {/* Real-time Match Validation Badge */}
                  <div className="mt-1.5 flex items-center">
                    {isPasswordMatch ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        <span>{isAr ? 'كلمتا المرور متطابقتان ✓' : 'Passwords match ✓'}</span>
                      </span>
                    ) : isPasswordMismatch ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-500">
                        <XCircle className="w-3 h-3 text-rose-500" />
                        <span>{isAr ? 'كلمتا المرور غير متطابقتين ✗' : 'Passwords do not match ✗'}</span>
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400">
                        {isAr ? 'أدخل كلمة المرور مجدداً للتأكيد' : 'Re-enter password to match'}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* 3. Security Question and Answer for Forgot Password */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/60 space-y-3">
                <div className="flex items-center gap-2 text-indigo-900 dark:text-indigo-200">
                  <HelpCircle className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                  <span className="font-cairo font-bold text-xs">
                    {isAr
                      ? 'إعدادات السؤال السري (لاستعادة كلمة المرور عند النسيان)'
                      : 'Security Question (For Password Recovery)'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Select Secret Question */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                      {isAr ? 'السؤال السري *' : 'Security Question *'}
                    </label>
                    <select
                      value={formData.selectedQuestionPreset}
                      onChange={(e) => setFormData({ ...formData, selectedQuestionPreset: e.target.value })}
                      className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
                    >
                      {PRESET_SECURITY_QUESTIONS.map((q) => (
                        <option key={q} value={q}>
                          {q}
                        </option>
                      ))}
                    </select>

                    {formData.selectedQuestionPreset === 'سؤال سري مخصص...' && (
                      <input
                        type="text"
                        required
                        value={formData.customQuestion}
                        onChange={(e) => setFormData({ ...formData, customQuestion: e.target.value })}
                        placeholder={isAr ? 'اكتب سؤالك السري المخصص هنا...' : 'Type custom question...'}
                        className="w-full mt-2 px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-700 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    )}
                  </div>

                  {/* Secret Answer */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                      {isAr ? 'الإجابة على السؤال السري *' : 'Security Answer *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.securityAnswer}
                      onChange={(e) => setFormData({ ...formData, securityAnswer: e.target.value })}
                      placeholder={isAr ? 'مثال: مدرسة اليرموك' : 'e.g. Al-Yarmouk'}
                      className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">
                      {isAr
                        ? 'سيُطلب من العضو كتابة هذه الإجابة في حال نسيان كلمة المرور.'
                        : 'User will be prompted for this answer if password is forgotten.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* 4. Email, Phone, Role, Role Title */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Email */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'البريد الإلكتروني *' : 'Email Address *'}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="member@nawabegh.edu"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'رقم الهاتف' : 'Phone Number'}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type="text"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+966 50 123 4567"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                {/* Primary Role */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'الدور الأساسي (Role) *' : 'Primary Role *'}
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => {
                      const r = e.target.value as MemberRecord['role'];
                      handleApplyRoleDefaults(r);
                    }}
                    className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
                  >
                    <option value="admin">{isAr ? 'مدير عام (Admin)' : 'General Admin'}</option>
                    <option value="secretary">{isAr ? 'سكرتارية (Secretary)' : 'Secretary'}</option>
                    <option value="supervisor">{isAr ? 'مشرفين (Supervisor)' : 'Supervisor'}</option>
                    <option value="teacher">{isAr ? 'معلم (Teacher)' : 'Teacher'}</option>
                    <option value="student">{isAr ? 'طالب (Student)' : 'Student'}</option>
                    <option value="female_student">{isAr ? 'طالبة (Female Student)' : 'Female Student'}</option>
                    <option value="parent">{isAr ? 'ولي أمر (Parent)' : 'Parent'}</option>
                  </select>
                </div>

                {/* Display Role Title */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'المسمى الوظيفي الظاهر' : 'Display Title'}
                  </label>
                  <input
                    type="text"
                    value={formData.roleTitle}
                    onChange={(e) => setFormData({ ...formData, roleTitle: e.target.value })}
                    placeholder={isAr ? 'مثال: مشرف الشؤون التعليمية' : 'e.g. Academic Supervisor'}
                    className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Status active checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="isActiveToggle"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                />
                <label
                  htmlFor="isActiveToggle"
                  className="text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer font-cairo"
                >
                  {isAr ? 'تفعيل الحساب والسماح بتسجيل الدخول فوراً' : 'Active Account (Allow login)'}
                </label>
              </div>

              {/* Granular Permissions Section */}
              <div className="space-y-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <h4 className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-emerald-600" />
                    <span>{isAr ? 'تحديد الصلاحيات المخصصة (Granular Permissions)' : 'Granular Permissions'}</span>
                  </h4>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setFormData({
                          ...formData,
                          permissions: AVAILABLE_PERMISSIONS.map((p) => p.key),
                        })
                      }
                      className="text-[11px] font-cairo font-bold text-emerald-600 hover:underline cursor-pointer"
                    >
                      {isAr ? 'منح الكل' : 'Grant All'}
                    </button>
                    <span className="text-slate-300">·</span>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, permissions: [] })}
                      className="text-[11px] font-cairo font-bold text-slate-500 hover:underline cursor-pointer"
                    >
                      {isAr ? 'إلغاء الكل' : 'Clear All'}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700">
                  {AVAILABLE_PERMISSIONS.map((perm) => {
                    const isChecked = formData.permissions.includes(perm.key);
                    return (
                      <label
                        key={perm.key}
                        className={`flex items-center gap-2.5 p-2 rounded-xl text-xs cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 font-bold border border-emerald-200 dark:border-emerald-800'
                            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleTogglePermission(perm.key)}
                          className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5 cursor-pointer"
                        />
                        <span className="truncate">{isAr ? perm.labelAr : perm.labelEn}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800 font-cairo">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingMember(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs md:text-sm shadow-md transition-colors cursor-pointer"
                >
                  {editingMember
                    ? isAr
                      ? 'حفظ التعديلات'
                      : 'Save Changes'
                    : isAr
                    ? 'تسجيل العضو'
                    : 'Register Member'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: VIEW DETAILS (With Security Credentials View) */}
      {viewingMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-800 text-white flex items-center justify-center font-bold text-sm">
                  {viewingMember.displayName.slice(0, 2)}
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                    {viewingMember.displayName}
                  </h3>
                  <p className="text-xs text-indigo-600 font-mono">@{viewingMember.username || viewingMember.email.split('@')[0]}</p>
                </div>
              </div>
              <button
                onClick={() => setViewingMember(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm font-tajawal">
              <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'الدور الأساسي:' : 'Role:'}</span>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getRoleBadgeColor(
                    viewingMember.role
                  )}`}
                >
                  {getRoleLabel(viewingMember.role)}
                </span>
              </div>

              {viewingMember.roleTitle && (
                <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">{isAr ? 'المسمى الوظيفي:' : 'Title:'}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {viewingMember.roleTitle}
                  </span>
                </div>
              )}

              {/* Login Credentials Box */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{isAr ? 'بيانات الاعتماد والدخول:' : 'Login Credentials:'}</span>
                  </span>
                  <button
                    onClick={() => setShowViewingSecret(!showViewingSecret)}
                    className="text-[11px] text-indigo-600 font-bold hover:underline cursor-pointer flex items-center gap-1"
                  >
                    {showViewingSecret ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showViewingSecret ? (isAr ? 'حجب البيانات' : 'Mask') : (isAr ? 'كشف البيانات' : 'Reveal')}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div>
                    <span className="text-slate-400 block font-sans text-[11px]">{isAr ? 'اسم المستخدم:' : 'Username:'}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {viewingMember.username || viewingMember.email}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-sans text-[11px]">{isAr ? 'كلمة المرور:' : 'Password:'}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {showViewingSecret ? viewingMember.password || '123456' : '••••••••'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-slate-400 block text-[11px]">{isAr ? 'السؤال السري المسجل:' : 'Secret Question:'}</span>
                  <span className="font-bold text-indigo-700 dark:text-indigo-300 text-xs">
                    {viewingMember.securityQuestion || (isAr ? 'ما هو اسم مدرستك الابتدائية؟' : 'Default school?')}
                  </span>
                  <div className="mt-1">
                    <span className="text-slate-400 text-[11px]">{isAr ? 'الإجابة السرية: ' : 'Answer: '}</span>
                    <span className="font-bold text-slate-700 dark:text-slate-200 font-mono">
                      {showViewingSecret ? viewingMember.securityAnswer || 'نوابغ' : '••••••'}
                    </span>
                  </div>
                </div>
              </div>

              {viewingMember.phone && (
                <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">{isAr ? 'رقم الهاتف:' : 'Phone:'}</span>
                  <span className="font-mono-numbers text-slate-800 dark:text-slate-200" dir="ltr">
                    {viewingMember.phone}
                  </span>
                </div>
              )}

              <div className="py-2 border-b border-slate-100 dark:border-slate-800 space-y-1.5">
                <span className="text-slate-500 font-cairo font-bold block">
                  {isAr ? 'الصلاحيات الممنوحة:' : 'Granted Permissions:'}
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto">
                  {(() => {
                    let perms: string[] = [];
                    try {
                      perms = JSON.parse(viewingMember.permissions || '[]');
                    } catch {
                      perms = [];
                    }
                    if (perms.includes('all')) {
                      return (
                        <span className="px-2.5 py-1 rounded-lg bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-xs font-bold border border-purple-200">
                          ⚡ {isAr ? 'كافة الصلاحيات الكاملة (Super Admin)' : 'All Super Privileges'}
                        </span>
                      );
                    }
                    if (perms.length === 0) {
                      return (
                        <span className="text-xs text-slate-400">
                          {isAr ? 'لا توجد صلاحيات استثنائية (صلاحيات أساسية فقط)' : 'Standard permissions only'}
                        </span>
                      );
                    }
                    return perms.map((p) => {
                      const matched = AVAILABLE_PERMISSIONS.find((x) => x.key === p);
                      return (
                        <span
                          key={p}
                          className="px-2 py-0.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-semibold border border-emerald-200 dark:border-emerald-800"
                        >
                          {matched ? (isAr ? matched.labelAr : matched.labelEn) : p}
                        </span>
                      );
                    });
                  })()}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewingMember(null)}
                className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs hover:bg-slate-200 cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: DELETE CONFIRMATION */}
      {deletingMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف العضو' : 'Confirm Delete Member'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? `هل أنت متأكد من رغبتك في حذف حساب (${deletingMember.displayName}) نهائياً وسحب كافة صلاحياته؟`
                  : `Are you sure you want to permanently delete (${deletingMember.displayName})?`}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2 font-cairo">
              <button
                onClick={() => setDeletingMember(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                {isAr ? 'نعم، حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
