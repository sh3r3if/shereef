import React, { useState, useEffect, useMemo } from 'react';
import {
  KeyRound,
  ShieldCheck,
  Smartphone,
  Volume2,
  Printer,
  Copy,
  Check,
  Trash2,
  Plus,
  RefreshCw,
  Lock,
  Unlock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Search,
  Download,
  Phone,
  BookOpen,
  Layers,
  Award,
  Clock,
  Sliders,
  Monitor,
  RotateCcw,
  Share2,
  XCircle,
  Tag,
} from 'lucide-react';
import {
  ActivationCodeCard,
  ActivationCodeScope,
  ContentSecurityConfig,
  CurrentUser,
  DEFAULT_CONTENT_SECURITY_CONFIG,
  Language,
  LessonItem,
  StudentCodeRedemption,
  StudentDeviceRecord,
} from '../types';
import {
  AlSharifWatermark,
  getOrCreateClientDeviceInfo,
  playAudioWatermarkSample,
} from './ScreenProtectionGuard';
import { getAuthHeaders } from '../utils/rbac';

interface ContentSecurityAndCodesHubProps {
  currentUser: CurrentUser;
  language: Language;
  lessons: LessonItem[];
}

export const ContentSecurityAndCodesHub: React.FC<ContentSecurityAndCodesHubProps> = ({
  currentUser,
  language,
  lessons,
}) => {
  const isAr = language === 'ar';
  const isAdminOrStaff =
    Boolean(currentUser.isSuperAdmin) ||
    currentUser.role === 'admin' ||
    currentUser.role === 'supervisor' ||
    currentUser.role === 'secretary' ||
    currentUser.role === 'teacher';

  const [activeSubTab, setActiveSubTab] = useState<
    'codes' | 'print_cards' | 'devices' | 'watermark_gating'
  >('codes');

  const [config, setConfig] = useState<ContentSecurityConfig>(DEFAULT_CONTENT_SECURITY_CONFIG);
  const [cards, setCards] = useState<ActivationCodeCard[]>([]);
  const [redemptions, setRedemptions] = useState<StudentCodeRedemption[]>([]);
  const [deviceRecords, setDeviceRecords] = useState<StudentDeviceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingConfig, setSavingConfig] = useState(false);

  // Code Generator Form State
  const [genCount, setGenCount] = useState<number>(6);
  const [genScope, setGenScope] = useState<ActivationCodeScope>('monthly');
  const [genSubjectName, setGenSubjectName] = useState<string>('');
  const [genLessonId, setGenLessonId] = useState<string>('');
  const [genDurationDays, setGenDurationDays] = useState<number>(30);
  const [genDurationHours, setGenDurationHours] = useState<number>(48);
  const [genDiscountPercent, setGenDiscountPercent] = useState<number>(20);
  const [genMaxUses, setGenMaxUses] = useState<number>(1);
  const [genPrice, setGenPrice] = useState<number>(150);
  const [genCurrency, setGenCurrency] = useState<string>('ج.م');
  const [genTitle, setGenTitle] = useState<string>('بطاقة تفعيل منصة الشريف التعليمية');
  const [isGenerating, setIsGenerating] = useState(false);

  // Student Code Redemption State
  const [redeemInput, setRedeemInput] = useState('');
  const [isRedeeming, setIsRedeeming] = useState(false);

  // Filters & Feedback
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'available' | 'redeemed'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [bannerMessage, setBannerMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Preview Watermark Phone
  const [previewPhone, setPreviewPhone] = useState(
    currentUser.phone || '01012345678'
  );

  const uniqueSubjects = useMemo(() => {
    const set = new Set<string>();
    lessons.forEach((l) => {
      if (l.subject) set.add(l.subject);
    });
    return Array.from(set);
  }, [lessons]);

  const showNotice = (type: 'success' | 'error', text: string) => {
    setBannerMessage({ type, text });
    window.setTimeout(() => {
      setBannerMessage((prev) => (prev?.text === text ? null : prev));
    }, 5000);
  };

  const fetchSecurityState = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/content-security/state');
      if (res.ok) {
        const data = await res.json();
        if (data.config) setConfig({ ...DEFAULT_CONTENT_SECURITY_CONFIG, ...data.config });
        if (Array.isArray(data.cards)) setCards(data.cards);
        if (Array.isArray(data.redemptions)) setRedemptions(data.redemptions);
        if (Array.isArray(data.deviceRecords)) setDeviceRecords(data.deviceRecords);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSecurityState();
  }, []);

  // Automatically adjust default duration when scope changes
  useEffect(() => {
    if (genScope === 'monthly') {
      setGenDurationDays(30);
      setGenTitle('كارت اشتراك شهري — منصة الشريف');
    } else if (genScope === 'semester') {
      setGenDurationDays(120);
      setGenTitle('كارت اشتراك فصلي (ترم كامل) — منصة الشريف');
    } else if (genScope === 'subject') {
      setGenDurationDays(90);
      setGenTitle(`كارت تفعيل مادة ${genSubjectName || 'دراسية'} — منصة الشريف`);
    } else if (genScope === 'lesson') {
      setGenDurationDays(30);
      const foundLesson = lessons.find((l) => l.id === genLessonId);
      setGenTitle(`كارت فتح درس: ${foundLesson?.title || 'درس محدد'}`);
    } else if (genScope === 'full_vip') {
      setGenDurationDays(365);
      setGenTitle('بطاقة VIP الشاملة لكل مواد ودروس منصة الشريف');
    } else if (genScope === 'promo_discount') {
      setGenDurationDays(30);
      setGenMaxUses(20);
      setGenTitle(`كود خصم ${genDiscountPercent}% على باقات منصة الشريف`);
    } else if (genScope === 'trial_48h') {
      setGenDurationDays(2);
      setGenDurationHours(48);
      setGenPrice(0);
      setGenTitle(
        `تجربة مجانية ${genDurationHours} ساعة (أول فصل${genSubjectName ? ` - ${genSubjectName}` : ''})`
      );
    }
  }, [genScope, genSubjectName, genLessonId, genDiscountPercent, genDurationHours, lessons]);

  const handleSaveConfig = async (nextConfig: ContentSecurityConfig) => {
    setSavingConfig(true);
    setConfig(nextConfig);
    try {
      const res = await fetch('/api/content-security/config', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser),
        },
        body: JSON.stringify({ config: nextConfig }),
      });
      if (res.ok) {
        showNotice('success', 'تم حفظ إعدادات أمان المحتوى والاشتراكات في قاعدة البيانات بنجاح!');
      } else {
        showNotice('error', 'تعذر حفظ الإعدادات في قاعدة البيانات');
      }
    } catch {
      showNotice('error', 'فشل الاتصال بالخادم أثناء حفظ الإعدادات');
    } finally {
      setSavingConfig(false);
    }
  };

  const handleGenerateCodes = async (e: React.FormEvent) => {
    e.preventDefault();
    if (genScope === 'subject' && !genSubjectName.trim()) {
      showNotice('error', 'يرجى اختيار أو كتابة اسم المادة الدراسية المراد إصدار أكواد لها');
      return;
    }
    if (genScope === 'lesson' && !genLessonId) {
      showNotice('error', 'يرجى اختيار الدرس المحدد من القائمة');
      return;
    }

    setIsGenerating(true);
    try {
      const foundLesson = lessons.find((l) => l.id === genLessonId);
      const res = await fetch('/api/content-security/generate-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          count: genCount,
          scope: genScope,
          title: genTitle,
          targetSubject: genScope === 'subject' || genScope === 'trial_48h' ? genSubjectName : undefined,
          targetLessonId: genScope === 'lesson' ? genLessonId : undefined,
          targetLessonTitle: genScope === 'lesson' ? foundLesson?.title : undefined,
          durationDays: genDurationDays,
          durationHours: genScope === 'trial_48h' ? genDurationHours : undefined,
          discountPercent: genScope === 'promo_discount' ? genDiscountPercent : undefined,
          firstUnitOnly: genScope === 'trial_48h',
          maxUses: genMaxUses,
          price: genScope === 'trial_48h' ? 0 : genPrice,
          currency: genCurrency,
          createdBy: currentUser.name,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setCards(data.allCards || []);
        showNotice(
          'success',
          `تم توليد ${data.generated?.length || genCount} كود تفعيل جديد في قاعدة البيانات بنجاح!`
        );
      } else {
        showNotice('error', data.error || 'تعذر توليد الأكواد');
      }
    } catch {
      showNotice('error', 'حدث خطأ أثناء الاتصال بالخادم');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeleteCard = async (id: string) => {
    try {
      const res = await fetch(`/api/content-security/codes/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setCards((prev) => prev.filter((c) => c.id !== id));
        showNotice('success', 'تم حذف كود التفعيل من قاعدة البيانات');
      }
    } catch {
      showNotice('error', 'فشل حذف الكود');
    }
  };

  const handleRedeemCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!redeemInput.trim()) {
      showNotice('error', 'يرجى كتابة كود التفعيل (مثال: SHARIF-XXXX-XXXX)');
      return;
    }
    setIsRedeeming(true);
    try {
      const res = await fetch('/api/content-security/redeem-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: redeemInput.trim().toUpperCase(),
          studentId: currentUser.studentId || currentUser.id,
          studentName: currentUser.name,
          studentPhone: currentUser.phone || '',
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setRedeemInput('');
        await fetchSecurityState();
        showNotice(
          'success',
          data.message || 'تم شحن وتفعيل الكود بنجاح! يمكنك الآن الدخول للدروس المشمولة.'
        );
      } else {
        showNotice('error', data.error || 'كود التفعيل غير صحيح أو مستخدم من قبل');
      }
    } catch {
      showNotice('error', 'تعذر التحقق من الكود، يرجى المحاولة مرة أخرى');
    } finally {
      setIsRedeeming(false);
    }
  };

  const handleCheckPromoCode = async () => {
    if (!redeemInput.trim()) {
      showNotice('error', 'أدخل كود الخصم أولاً للتحقق منه');
      return;
    }
    setIsRedeeming(true);
    try {
      const res = await fetch('/api/content-security/apply-promo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: redeemInput.trim().toUpperCase(),
          amount: 200,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showNotice(
          'success',
          `كود الخصم «${data.code}» صالح ويمنح خصم ${data.discountPercent}% (${data.title}) ✓`
        );
      } else {
        showNotice('error', data.error || 'كود الخصم غير صالح');
      }
    } catch {
      showNotice('error', 'تعذر التحقق من كود الخصم حالياً');
    } finally {
      setIsRedeeming(false);
    }
  };

  const handleResetStudentDevices = async (userKey: string, deviceId?: string) => {
    try {
      const res = await fetch('/api/content-security/reset-devices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser),
        },
        body: JSON.stringify({
          userKey,
          studentId: userKey,
          deviceIdToRemove: deviceId,
          deviceId,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setDeviceRecords(data.deviceRecords || []);
        showNotice(
          'success',
          deviceId
            ? 'تم إلغاء ربط الجهاز المحدد بنجاح!'
            : 'تم تصفير وفك ارتباط جميع أجهزة والـ IP الخاص بالحساب بنجاح!'
        );
      } else {
        showNotice('error', data.error || 'تعذر تحديث أجهزة الحساب');
      }
    } catch {
      showNotice('error', 'تعذر تحديث أجهزة الطالب');
    }
  };

  const handleApproveDeviceOrGeo = async (
    userKey: string,
    mode: 'approve_pending_device' | 'approve_ip_or_geo',
    deviceId?: string
  ) => {
    try {
      const res = await fetch('/api/content-security/approve-access', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser),
        },
        body: JSON.stringify({ userKey, studentId: userKey, mode, deviceId }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setDeviceRecords(data.deviceRecords || []);
        showNotice(
          'success',
          mode === 'approve_ip_or_geo'
            ? 'تم تفعيل واعتماد عنوان الـ IP والموقع الجغرافي الجديد بواسطة الأدمن!'
            : 'تم تفعيل واعتماد الجهاز الإضافي للحساب بواسطة الأدمن بنجاح!'
        );
      } else {
        showNotice('error', data.error || 'تعذر تفعيل الجهاز أو الموقع');
      }
    } catch {
      showNotice('error', 'فشل الاتصال بالخادم أثناء تفعيل الوصول');
    }
  };

  const handleRejectPendingRequest = async (userKey: string) => {
    try {
      const res = await fetch('/api/content-security/reject-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser),
        },
        body: JSON.stringify({ userKey, studentId: userKey }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setDeviceRecords(data.deviceRecords || []);
        showNotice('success', 'تم رفض طلب فك الحظر وتوثيق القرار في سجل التدقيق');
      } else {
        showNotice('error', data.error || 'تعذر رفض الطلب');
      }
    } catch {
      showNotice('error', 'فشل الاتصال بالخادم أثناء رفض الطلب');
    }
  };

  const copyText = (id: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    window.setTimeout(() => setCopiedId(null), 2000);
  };

  const exportCodesCSV = () => {
    const headers = ['Code', 'Title', 'Scope', 'Subject/Lesson', 'DurationDays', 'Price', 'Status', 'RedeemedBy'];
    const rows = cards.map((c) => [
      c.code,
      `"${(c.title || '').replace(/"/g, '""')}"`,
      c.scope,
      `"${c.targetSubject || c.targetLessonTitle || 'All'}"`,
      c.durationDays,
      `${c.price} ${c.currency}`,
      c.status,
      `"${c.redeemedByStudentName || ''}"`,
    ]);
    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `alsharif-activation-codes-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredCards = useMemo(() => {
    return cards.filter((c) => {
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        c.code.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        (c.targetSubject || '').toLowerCase().includes(q) ||
        (c.targetLessonTitle || '').toLowerCase().includes(q) ||
        (c.redeemedByStudentName || '').toLowerCase().includes(q)
      );
    });
  }, [cards, statusFilter, searchQuery]);

  const studentIdKey = currentUser.studentId || currentUser.id;
  const myRedemptions = useMemo(
    () => redemptions.filter((r) => r.studentId === studentIdKey || r.studentName === currentUser.name),
    [redemptions, studentIdKey, currentUser.name]
  );

  const myDeviceRecord = useMemo(
    () =>
      deviceRecords.find(
        (r) => r.studentId === studentIdKey || r.studentUsername === currentUser.username
      ),
    [deviceRecords, studentIdKey, currentUser.username]
  );

  const getScopeBadgeLabel = (card: ActivationCodeCard) => {
    switch (card.scope) {
      case 'monthly':
        return 'اشتراك شهري (كل المواد)';
      case 'semester':
        return 'اشتراك فصلي (ترم كامل)';
      case 'subject':
        return `مادة: ${card.targetSubject || 'محددة'}`;
      case 'lesson':
        return `درس: ${card.targetLessonTitle || 'محدد'}`;
      case 'full_vip':
        return 'باقة VIP شاملة';
      case 'promo_discount':
        return `كود خصم ${card.discountPercent || 20}%`;
      case 'trial_48h':
        return `تجربة ${card.durationHours || 48} ساعة (أول فصل)`;
      default:
        return 'اشتراك عام';
    }
  };

  const clientDevice = getOrCreateClientDeviceInfo();

  return (
    <div className="space-y-6 font-tajawal">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-emerald-950 via-slate-900 to-emerald-900 text-white p-6 md:p-8 border border-emerald-700/40 shadow-xl print:hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-cairo font-black">
              <ShieldCheck className="w-4 h-4" />
              <span>أمان المحتوى والاشتراكات — حماية الدروس وتفعيل الدخل</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-cairo font-black leading-tight">
              {isAdminOrStaff
                ? 'مركز بطاقات التفعيل، ربط الأجهزة (Device Binding)، والعلامة المائية الصوتية والمتحركة'
                : 'شحن كود التفعيل واشتراكاتي والأجهزة المرتبطة بحسابي'}
            </h1>
            <p className="text-xs md:text-sm text-emerald-100/85 leading-relaxed">
              {isAdminOrStaff
                ? 'ولّد أكواد التفعيل والبطاقات المدفوعة بضغطة زر واطبعها للطلاب، حدد أقصى عدد أجهزة مسموح لكل طالب لمنع مشاركة الحسابات، وتحكم في العلامة المائية المتحركة والصوتية برقم هاتف الطالب.'
                : 'أدخل كود بطاقة التفعيل الخاصة بك لفتح الدروس والمواد الدراسية فوراً، وتابع أجهزتك المسموحة.'}
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 text-center">
              <div className="text-xl font-black font-mono-numbers text-amber-300">
                {cards.filter((c) => c.status === 'available').length}
              </div>
              <div className="text-[11px] font-cairo text-emerald-100">بطاقات جاهزة للشحن</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 text-center">
              <div className="text-xl font-black font-mono-numbers text-emerald-300">
                {cards.filter((c) => c.status === 'redeemed').length}
              </div>
              <div className="text-[11px] font-cairo text-emerald-100">أكواد مفعّلة للطلاب</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 text-center col-span-2 sm:col-span-1">
              <div className="text-xl font-black font-mono-numbers text-cyan-300">
                {config.maxDevicesPerStudent === 1 ? '1 جهاز' : `${config.maxDevicesPerStudent} أجهزة`}
              </div>
              <div className="text-[11px] font-cairo text-emerald-100">الحد الافتراضي للحساب</div>
            </div>
          </div>
        </div>
      </div>

      {/* Feedback Banner */}
      {bannerMessage && (
        <div
          className={`p-4 rounded-2xl border flex items-center justify-between gap-3 print:hidden ${
            bannerMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2.5 text-xs md:text-sm font-cairo font-bold">
            {bannerMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            )}
            <span>{bannerMessage.text}</span>
          </div>
        </div>
      )}

      {/* STUDENT CODE REDEMPTION CARD (Always visible for Students, and available for Admin to test) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm print:hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-cairo font-black text-sm">
              <KeyRound className="w-4 h-4" />
              <span>شحن وتفعيل كود بطاقة منصة الشريف (Scratch Card / Promo Code)</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              أدخل الكود المكون من الحروف والأرقام (مثال: <code className="font-mono font-bold text-amber-600">SHARIF-XXXX-XXXX</code>) لفتح الدرس أو المادة أو الاشتراك الشهري فوراً.
            </p>
          </div>

          <form onSubmit={handleRedeemCode} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full lg:w-auto">
            <input
              type="text"
              value={redeemInput}
              onChange={(e) => setRedeemInput(e.target.value.toUpperCase())}
              placeholder="SHARIF-XXXX-XXXX"
              dir="ltr"
              className="px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm tracking-wider uppercase focus:border-emerald-600 focus:outline-hidden sm:w-64 text-center"
            />
            <button
              type="submit"
              disabled={isRedeeming}
              className="px-6 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-cairo font-black text-xs md:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isRedeeming ? 'جارِ التفعيل...' : 'تفعيل الكود الآن'}</span>
            </button>
            <button
              type="button"
              disabled={isRedeeming}
              onClick={handleCheckPromoCode}
              className="px-4 py-3 rounded-2xl bg-amber-100 hover:bg-amber-200 dark:bg-amber-950/60 dark:hover:bg-amber-900 text-amber-900 dark:text-amber-200 font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
              title="التحقق من نسبة الخصم إذا كان الكود كود خصم مالي"
            >
              <Tag className="w-3.5 h-3.5" />
              <span>فحص خصم</span>
            </button>
          </form>
        </div>

        {/* Active Student Subscriptions List */}
        {myRedemptions.length > 0 && (
          <div className="mt-5 pt-5 border-t border-slate-100 dark:border-slate-800">
            <h4 className="font-cairo font-bold text-xs text-slate-600 dark:text-slate-300 mb-3">
              اشتراكاتك وأكوادك المفعّلة حالياً ({myRedemptions.length}):
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {myRedemptions.map((r) => {
                const isExpired = new Date(r.expiresAt).getTime() < Date.now();
                return (
                  <div
                    key={r.id}
                    className={`p-3.5 rounded-2xl border flex flex-col justify-between gap-2 ${
                      isExpired
                        ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 opacity-70'
                        : 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/70'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-numbers font-black text-xs text-emerald-800 dark:text-emerald-300">
                        {r.code}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold ${
                          isExpired
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-emerald-600 text-white'
                        }`}
                      >
                        {isExpired ? 'منتهي' : 'ساري ومفعّل'}
                      </span>
                    </div>
                    <p className="text-xs font-cairo font-bold text-slate-800 dark:text-slate-200">
                      {r.targetSubject
                        ? `مادة: ${r.targetSubject}`
                        : r.targetLessonTitle
                        ? `درس: ${r.targetLessonTitle}`
                        : r.scope === 'semester'
                        ? 'اشتراك فصلي شامل'
                        : r.scope === 'full_vip'
                        ? 'اشتراك VIP شامل'
                        : 'اشتراك شهري شامل'}
                    </p>
                    <div className="text-[11px] text-slate-500 flex items-center justify-between">
                      <span>ينتهي في:</span>
                      <span className="font-mono-numbers font-bold">
                        {new Date(r.expiresAt).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Student Bound Devices Summary if logged in as Student */}
        {!isAdminOrStaff && (
          <div className="mt-5 pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <p className="font-cairo font-bold text-xs text-slate-900 dark:text-white">
                  أجهزتك المرتبطة بالحساب: ({myDeviceRecord?.devices?.length || 1} من {myDeviceRecord?.maxAllowedDevices || config.maxDevicesPerStudent} أجهزة مسموحة)
                </p>
                <p className="text-[11px] text-slate-500 font-mono-numbers">
                  بصمة جهازك الحالي: {clientDevice.deviceId} — {clientDevice.deviceLabel}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ADMIN & STAFF MANAGEMENT TABS */}
      {isAdminOrStaff && (
        <>
          <div className="flex flex-wrap items-center gap-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 print:hidden">
            <button
              type="button"
              onClick={() => setActiveSubTab('codes')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-bold text-xs md:text-sm transition-all cursor-pointer ${
                activeSubTab === 'codes'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>1. توليد وإدارة أكواد التفعيل ({cards.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubTab('print_cards')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-bold text-xs md:text-sm transition-all cursor-pointer ${
                activeSubTab === 'print_cards'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Printer className="w-4 h-4" />
              <span>2. طباعة كروت الشحن المدفوعة (Scratch Cards)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubTab('devices')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-bold text-xs md:text-sm transition-all cursor-pointer ${
                activeSubTab === 'devices'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>3. تحديد عدد الأجهزة لكل طالب (Device Binding)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubTab('watermark_gating')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-bold text-xs md:text-sm transition-all cursor-pointer ${
                activeSubTab === 'watermark_gating'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              <span>4. العلامة المائية الصوتية والمتحركة وقفل الدروس</span>
            </button>
          </div>

          {/* ================= SUB-TAB 1: GENERATE & MANAGE CODES ================= */}
          {activeSubTab === 'codes' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Generator Form */}
              <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5 h-fit">
                <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-700 text-white flex items-center justify-center">
                    <Plus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                      توليد دفعة أكواد تفعيل بضغطة زر
                    </h3>
                    <p className="text-xs text-slate-500">
                      أكواد شهرية / فصلية / لمادة محددة / لدرس معين
                    </p>
                  </div>
                </div>

                <form onSubmit={handleGenerateCodes} className="space-y-4">
                  {/* Scope Selection */}
                  <div>
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                      نوع باقة الكود (نطاق الصلاحية) *
                    </label>
                    <select
                      value={genScope}
                      onChange={(e) => setGenScope(e.target.value as ActivationCodeScope)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo font-bold text-xs cursor-pointer"
                    >
                      <option value="monthly">📅 اشتراك شهري (يفتح جميع الدروس لمدة 30 يوماً)</option>
                      <option value="semester">🎓 باقة الترم كامل (120 يوماً)</option>
                      <option value="subject">📚 باقة مادة واحدة محددة فقط</option>
                      <option value="lesson">🎬 كود لدرس / محاضرة معينة فقط</option>
                      <option value="full_vip">👑 باقة VIP شاملة (عام دراسي كامل 365 يوماً)</option>
                      <option value="promo_discount">🏷️ كود خصم نسبة مئوية (Promo Code)</option>
                      <option value="trial_48h">⏱️ تجربة مجانية 48 ساعة (أول فصل فقط)</option>
                    </select>
                  </div>

                  {/* Target Subject if scope === 'subject' or 'trial_48h' */}
                  {(genScope === 'subject' || genScope === 'trial_48h') && (
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {genScope === 'trial_48h'
                          ? 'المادة المستهدفة للتجربة المجانية (اختياري)'
                          : 'اختر أو اكتب اسم المادة الدراسية *'}
                      </label>
                      {uniqueSubjects.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {uniqueSubjects.map((subj) => (
                            <button
                              key={subj}
                              type="button"
                              onClick={() => setGenSubjectName(subj)}
                              className={`px-2.5 py-1 rounded-lg text-xs font-cairo font-bold border cursor-pointer ${
                                genSubjectName === subj
                                  ? 'bg-emerald-700 text-white border-emerald-700'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              {subj}
                            </button>
                          ))}
                        </div>
                      )}
                      <input
                        type="text"
                        required={genScope === 'subject'}
                        value={genSubjectName}
                        onChange={(e) => setGenSubjectName(e.target.value)}
                        placeholder="مثال: الفيزياء / اللغة العربية / الرياضيات"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs font-bold"
                      />
                    </div>
                  )}

                  {genScope === 'promo_discount' && (
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                          نسبة الخصم (%)
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={100}
                          value={genDiscountPercent}
                          onChange={(e) => setGenDiscountPercent(Number(e.target.value) || 10)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                          أقصى عدد استخدامات للكود
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={500}
                          value={genMaxUses}
                          onChange={(e) => setGenMaxUses(Number(e.target.value) || 1)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm"
                        />
                      </div>
                    </div>
                  )}

                  {genScope === 'trial_48h' && (
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        مدة التجربة المجانية (بالساعات — لأول فصل)
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={168}
                        value={genDurationHours}
                        onChange={(e) => setGenDurationHours(Number(e.target.value) || 48)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm"
                      />
                    </div>
                  )}

                  {/* Target Lesson if scope === 'lesson' */}
                  {genScope === 'lesson' && (
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        اختر الدرس المحدد من قاعدة البيانات *
                      </label>
                      <select
                        required
                        value={genLessonId}
                        onChange={(e) => setGenLessonId(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs font-bold cursor-pointer"
                      >
                        <option value="">-- اختر الدرس --</option>
                        {lessons.map((lesson) => (
                          <option key={lesson.id} value={lesson.id}>
                            {lesson.title} ({lesson.subject} - {lesson.grade})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Batch Title */}
                  <div>
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                      عنوان البطاقة المطبوع على الكارت
                    </label>
                    <input
                      type="text"
                      value={genTitle}
                      onChange={(e) => setGenTitle(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs font-bold"
                    />
                  </div>

                  {/* Count & Duration */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        عدد الكروت المطلوب توليدها
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={genCount}
                        onChange={(e) => setGenCount(Number(e.target.value))}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        صلاحية الكود (بالأيام)
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={730}
                        value={genDurationDays}
                        onChange={(e) => setGenDurationDays(Number(e.target.value))}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm"
                      />
                    </div>
                  </div>

                  {/* Price & Currency */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        سعر البطاقة (للطباعة والتقارير)
                      </label>
                      <input
                        type="number"
                        min={0}
                        value={genPrice}
                        onChange={(e) => setGenPrice(Number(e.target.value))}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-black text-sm"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        العملة
                      </label>
                      <input
                        type="text"
                        value={genCurrency}
                        onChange={(e) => setGenCurrency(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo font-bold text-xs"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isGenerating}
                    className="w-full py-3.5 px-6 rounded-2xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-cairo font-black text-sm shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>
                      {isGenerating
                        ? 'جارِ توليد الأكواد...'
                        : `توليد ${genCount} كود تفعيل فوراً بضغطة زر`}
                    </span>
                  </button>
                </form>
              </div>

              {/* Generated Codes List */}
              <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                      سجل أكواد التفعيل والبطاقات المصدرة ({filteredCards.length})
                    </h3>
                    <p className="text-xs text-slate-500">
                      انسخ الكود أو أرسله للطالب عبر واتساب أو اطبع الكروت الجاهزة
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('print_cards')}
                      className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>طباعة الكروت</span>
                    </button>
                    <button
                      type="button"
                      onClick={exportCodesCSV}
                      className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>تصدير CSV</span>
                    </button>
                  </div>
                </div>

                {/* Search & Status Filter */}
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute top-3 right-3.5 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="ابحث بالكود أو اسم المادة أو اسم الطالب الذي شحن الكود..."
                      className="w-full pr-10 pl-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    {(['all', 'available', 'redeemed'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setStatusFilter(st)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold cursor-pointer ${
                          statusFilter === st
                            ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-2xs'
                            : 'text-slate-500'
                        }`}
                      >
                        {st === 'all' ? 'الكل' : st === 'available' ? 'متاح للشحن' : 'تم استخدامه'}
                      </button>
                    ))}
                  </div>
                </div>

                {loading ? (
                  <div className="py-12 text-center text-xs text-slate-400">
                    جارِ تحميل أكواد التفعيل من قاعدة البيانات...
                  </div>
                ) : filteredCards.length === 0 ? (
                  <div className="py-12 text-center space-y-2 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
                    <KeyRound className="w-8 h-8 text-slate-400 mx-auto" />
                    <p className="font-cairo font-bold text-sm text-slate-600 dark:text-slate-300">
                      لا توجد أكواد تفعيل مطابقة حالياً
                    </p>
                    <p className="text-xs text-slate-400">
                      استخدم النموذج الجانبي لتوليد دفعة أكواد جديدة بضغطة زر.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[540px] overflow-y-auto pr-1">
                    {filteredCards.map((card) => {
                      const whatsappText = `مرحباً بك في *منصة الشريف التعليمية* 🎓\nكود التفعيل الخاص بك هو:\n*${card.code}*\nالباقة: ${card.title} (${getScopeBadgeLabel(card)})\nالمدة: ${card.durationDays} يوماً.`;
                      return (
                        <div
                          key={card.id}
                          className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                            card.status === 'redeemed'
                              ? 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                              : 'bg-white dark:bg-slate-900 border-emerald-200/80 dark:border-emerald-900/50 hover:border-emerald-500'
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                dir="ltr"
                                className="px-3 py-1 rounded-xl bg-slate-900 text-amber-300 font-mono-numbers font-black text-sm tracking-wider"
                              >
                                {card.code}
                              </span>
                              <span
                                className={`px-2.5 py-0.5 rounded-lg text-[11px] font-cairo font-bold ${
                                  card.status === 'available'
                                    ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300'
                                    : 'bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300'
                                }`}
                              >
                                {card.status === 'available' ? 'متاح للشحن' : `مفعّل بواسطة: ${card.redeemedByStudentName}`}
                              </span>
                              <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-cairo font-bold">
                                {getScopeBadgeLabel(card)}
                              </span>
                            </div>
                            <p className="text-xs font-cairo font-bold text-slate-700 dark:text-slate-300">
                              {card.title} • المدة: {card.durationDays} يوم • السعر: {card.price} {card.currency}
                            </p>
                            {card.redeemedAt && (
                              <p className="text-[11px] text-slate-500">
                                تاريخ التفعيل: {new Date(card.redeemedAt).toLocaleString('ar-EG')} • ينتهي:{' '}
                                {card.expiresAt ? new Date(card.expiresAt).toLocaleDateString('ar-EG') : '-'}
                              </p>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => copyText(card.id, card.code)}
                              title="نسخ الكود"
                              className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-700 dark:text-slate-200 text-xs font-cairo font-bold flex items-center gap-1 cursor-pointer transition-all"
                            >
                              {copiedId === card.id ? (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>تم النسخ</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>نسخ الكود</span>
                                </>
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => copyText(`wa-${card.id}`, whatsappText)}
                              title="نسخ رسالة واتساب جاهزة لإرسالها للطالب"
                              className="px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-600 hover:text-white text-emerald-700 dark:text-emerald-300 text-xs font-cairo font-bold flex items-center gap-1 cursor-pointer transition-all"
                            >
                              {copiedId === `wa-${card.id}` ? (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>نسخت الرسالة</span>
                                </>
                              ) : (
                                <>
                                  <Share2 className="w-3.5 h-3.5" />
                                  <span>رسالة للطالب</span>
                                </>
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDeleteCard(card.id)}
                              title="حذف / إلغاء الكود"
                              className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-600 hover:text-white text-rose-600 transition-all cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= SUB-TAB 2: PRINTABLE SCRATCH CARDS ================= */}
          {activeSubTab === 'print_cards' && (
            <div className="space-y-5">
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 flex flex-wrap items-center justify-between gap-4 print:hidden">
                <div>
                  <h3 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                    طباعة بطاقات الشحن المدفوعة (Scratch Cards) — جاهزة للطباعة والتسليم للطلاب
                  </h3>
                  <p className="text-xs text-slate-500">
                    يتم عرض البطاقات المتاحة غير المستخدمة ({cards.filter((c) => c.status === 'available').length} بطاقة) بتصميم رسمي يحمل شعار «منصة الشريف».
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-6 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-black text-xs md:text-sm shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الكروت الآن (Print Cards)</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 print:grid-cols-2 print:gap-4">
                {cards
                  .filter((c) => c.status === 'available')
                  .map((card, idx) => (
                    <div
                      key={card.id}
                      className="relative overflow-hidden rounded-3xl border-2 border-emerald-800 bg-gradient-to-br from-emerald-950 via-slate-900 to-emerald-900 text-white p-5 shadow-md break-inside-avoid"
                    >
                      <div className="flex items-center justify-between border-b border-emerald-700/50 pb-3 mb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 font-cairo font-black flex items-center justify-center text-sm">
                            ش
                          </div>
                          <div>
                            <h4 className="font-cairo font-black text-sm text-amber-300">
                              منصة الشريف التعليمية
                            </h4>
                            <p className="text-[10px] text-emerald-200">{card.title}</p>
                          </div>
                        </div>
                        <div className="text-left">
                          <span className="px-2.5 py-1 rounded-xl bg-amber-400 text-slate-950 font-mono-numbers font-black text-xs">
                            {card.price} {card.currency}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-2 text-center my-3">
                        <p className="text-[11px] text-emerald-200 font-cairo font-bold">
                          {getScopeBadgeLabel(card)} • صالحة لمدة {card.durationDays} يوماً
                        </p>
                        <div
                          dir="ltr"
                          className="py-2.5 px-4 rounded-2xl bg-black/70 border-2 border-dashed border-amber-400 font-mono-numbers font-black text-lg tracking-widest text-amber-300 select-all"
                        >
                          {card.code}
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-emerald-200/80 pt-2 border-t border-emerald-800/60">
                        <span>اشحن الكود من داخل تبويب الدروس بالمنصة</span>
                        <span className="font-mono-numbers">SN #{1000 + idx + 1}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ================= SUB-TAB 3: DEVICE, IP & GEO BINDING MANAGER ================= */}
          {activeSubTab === 'devices' && (
            <div className="space-y-6">
              {/* Device, IP & Geo Limit Policy Controls */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div className="space-y-1">
                    <h3 className="font-cairo font-black text-base md:text-lg text-slate-900 dark:text-white flex items-center gap-2">
                      <Smartphone className="w-5 h-5 text-emerald-600" />
                      <span>قفل الجهاز الواحد والـ IP والنطاق الجغرافي (Device + IP + Geo Lock)</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      لا يُسمح بفتح نفس الحساب على أكثر من جهاز، ولا يُسمح بفتحه من نفس الجهاز عند تغيير الـ IP أو الانتقال بين قرية أو مدينة أو محافظة أو دولة إلا بتفعيل الأدمن.
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={config.enableDeviceBinding}
                        onChange={(e) =>
                          handleSaveConfig({
                            ...config,
                            enableDeviceBinding: e.target.checked,
                          })
                        }
                        className="w-4 h-4 accent-emerald-600 rounded"
                      />
                      <span className="font-cairo font-bold text-xs text-slate-800 dark:text-slate-200">
                        تفعيل الحماية الصارمة للأجهزة والموقع
                      </span>
                    </label>
                  </div>
                </div>

                {/* Strict IP & Geo Binding Toggles */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <label className="flex items-start gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.enforceStrictIpBinding !== false}
                      onChange={(e) =>
                        handleSaveConfig({
                          ...config,
                          enforceStrictIpBinding: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-emerald-600 mt-0.5"
                    />
                    <div className="space-y-0.5">
                      <span className="font-cairo font-bold text-xs text-slate-900 dark:text-white block">
                        منع فتح الحساب من نفس الجهاز عند تغيّر الـ IP
                      </span>
                      <span className="text-[11px] text-slate-500 block">
                        يتم إيقاف الحساب فوراً إذا تغير عنوان IP الاتصال حتى لو كان من نفس الجهاز، ولا يُعاد الفتح إلا باعتماد الأدمن.
                      </span>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.enforceStrictGeoBinding !== false}
                      onChange={(e) =>
                        handleSaveConfig({
                          ...config,
                          enforceStrictGeoBinding: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-emerald-600 mt-0.5"
                    />
                    <div className="space-y-0.5">
                      <span className="font-cairo font-bold text-xs text-slate-900 dark:text-white block">
                        منع الانتقال الجغرافي (قرية / مدينة / محافظة / دولة)
                      </span>
                      <span className="text-[11px] text-slate-500 block">
                        يمنع فتح الحساب في حال الانتقال من قرية لأخرى أو مدينة لأخرى أو محافظة لأخرى أو دولة لأخرى بدون تفعيل الأدمن.
                      </span>
                    </div>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      الحد الافتراضي للأجهزة بدون تفعيل إضافي:
                    </label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() =>
                            handleSaveConfig({
                              ...config,
                              maxDevicesPerStudent: num,
                            })
                          }
                          className={`flex-1 py-2.5 rounded-xl font-mono-numbers font-black text-sm border cursor-pointer transition-all ${
                            config.maxDevicesPerStudent === num
                              ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm'
                              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {num} {num === 1 ? 'جهاز' : 'أجهزة'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="md:col-span-2 p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-950 dark:text-emerald-200 space-y-1.5">
                    <div className="font-cairo font-black flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
                      <ShieldCheck className="w-4 h-4" />
                      <span>سياسة التفعيل والصلاحية:</span>
                    </div>
                    <p className="leading-relaxed">
                      حساب المدير العام <strong>Mo-NewFolder (الأدمن العام)</strong> معفى تماماً لإدارة النظام، بينما تخضع جميع الحسابات الأخرى لقيد <strong>جهاز واحد فقط + IP ثابت + نطاق جغرافي ثابت</strong>، ولا يُفتح أي جهاز جديد أو موقع جديد إلا بالتفعيل المباشر من الأدمن.
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick Device & IP Unlock Queue */}
              {(() => {
                const unlockQueue = deviceRecords.filter(
                  (r) => Boolean(r.pendingDeviceRequest) || r.lockStatus === 'locked'
                );
                if (unlockQueue.length === 0) return null;
                return (
                  <div className="bg-rose-50/70 dark:bg-rose-950/25 rounded-3xl border-2 border-rose-300 dark:border-rose-800 p-5 space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5 text-rose-600" />
                        <h4 className="font-cairo font-black text-sm md:text-base text-rose-900 dark:text-rose-200">
                          قائمة طلبات فك الحظر والأجهزة السريعة ({unlockQueue.length})
                        </h4>
                      </div>
                      <span className="text-[11px] font-bold text-rose-700 dark:text-rose-300">
                        قبول أو رفض بضغطة واحدة
                      </span>
                    </div>
                    <div className="space-y-2">
                      {unlockQueue.map((reqItem) => {
                        const tKey = reqItem.userKey || reqItem.studentId || '';
                        const pReq = reqItem.pendingDeviceRequest;
                        return (
                          <div
                            key={`uq-${tKey}`}
                            className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-800 flex flex-wrap items-center justify-between gap-3"
                          >
                            <div className="space-y-0.5 text-xs">
                              <p className="font-cairo font-black text-slate-900 dark:text-white">
                                {reqItem.studentName}{' '}
                                <span className="text-slate-400 font-mono">
                                  ({reqItem.studentUsername || reqItem.username || tKey})
                                </span>
                              </p>
                              <p className="text-rose-700 dark:text-rose-300 font-bold">
                                سبب الحظر: {pReq?.reasonMessageAr || reqItem.lockReasonMessageAr || 'تغيّر الجهاز أو الموقع / IP'}
                              </p>
                              {pReq && (
                                <p className="text-[11px] text-slate-500 font-mono-numbers">
                                  {pReq.deviceLabel} • IP: {pReq.ip} {pReq.geoLabel ? `• ${pReq.geoLabel}` : ''}
                                </p>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() =>
                                  handleApproveDeviceOrGeo(
                                    tKey,
                                    pReq?.reasonCode === 'device_limit_exceeded'
                                      ? 'approve_pending_device'
                                      : 'approve_ip_or_geo',
                                    pReq?.deviceId
                                  )
                                }
                                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-black text-xs flex items-center gap-1 cursor-pointer"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>قبول وفك الحظر</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRejectPendingRequest(tKey)}
                                className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-black text-xs flex items-center gap-1 cursor-pointer"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>رفض الطلب</span>
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {/* Bound Accounts Table */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h4 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                      سجل الأجهزة وعناوين الـ IP والمواقع المرتبطة ({deviceRecords.length} حساب)
                    </h4>
                    <p className="text-xs text-slate-500">
                      يمكنك مراجعة الأجهزة والـ IP والموقع المعتمد وتفعيل الأجهزة أو المواقع الجديدة بضغطة زر
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={fetchSecurityState}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>تحديث السجل</span>
                  </button>
                </div>

                {deviceRecords.length === 0 ? (
                  <div className="py-10 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl text-xs text-slate-400">
                    لم يتم تسجيل أجهزة بعد. بمجرد دخول أي حساب سيتم ربط بصمة جهازه وعنوان الـ IP والموقع الجغرافي تلقائياً هنا.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {deviceRecords.map((rec) => {
                      const targetKey = rec.userKey || rec.studentId || '';
                      const blockedCount = rec.blockedAttempts ?? rec.blockedAttemptsCount ?? 0;
                      const isLocked = rec.lockStatus === 'locked' || Boolean(rec.pendingDeviceRequest);
                      const pendingReq = rec.pendingDeviceRequest;
                      return (
                        <div
                          key={targetKey}
                          className={`p-4 rounded-2xl border space-y-3 ${
                            isLocked
                              ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-300 dark:border-rose-800'
                              : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <div
                                className={`w-10 h-10 rounded-xl text-white font-cairo font-black flex items-center justify-center ${
                                  isLocked ? 'bg-rose-600' : 'bg-emerald-700'
                                }`}
                              >
                                {rec.studentName.slice(0, 1)}
                              </div>
                              <div>
                                <h5 className="font-cairo font-black text-sm text-slate-900 dark:text-white flex flex-wrap items-center gap-2">
                                  <span>{rec.studentName}</span>
                                  <span className="text-xs font-mono text-slate-400">
                                    ({rec.studentUsername || rec.username || targetKey})
                                  </span>
                                  {isLocked && (
                                    <span className="px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-bold">
                                      مقيد — بانتظار تفعيل الأدمن
                                    </span>
                                  )}
                                </h5>
                                <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                                  <span>
                                    الأجهزة المرتبطة:{' '}
                                    <strong className="text-emerald-600 font-mono-numbers">
                                      {rec.devices.length} / {rec.maxAllowedDevices || config.maxDevicesPerStudent}
                                    </strong>
                                  </span>
                                  {blockedCount > 0 && (
                                    <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 font-bold">
                                      محاولات مرفوضة: {blockedCount}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-wrap items-center gap-2">
                              {pendingReq && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleApproveDeviceOrGeo(
                                        targetKey,
                                        pendingReq.reasonCode === 'device_limit_exceeded'
                                          ? 'approve_pending_device'
                                          : 'approve_ip_or_geo',
                                        pendingReq.deviceId
                                      )
                                    }
                                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>
                                      {pendingReq.reasonCode === 'device_limit_exceeded'
                                        ? 'تفعيل واعتماد الجهاز الإضافي'
                                        : 'تفعيل واعتماد الـ IP / الموقع الجديد'}
                                    </span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleRejectPendingRequest(targetKey)}
                                    className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                                  >
                                    <XCircle className="w-3.5 h-3.5" />
                                    <span>رفض الطلب</span>
                                  </button>
                                </>
                              )}

                              <button
                                type="button"
                                onClick={() => handleResetStudentDevices(targetKey)}
                                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>تصفير وفك ربط كل الأجهزة والـ IP</span>
                              </button>
                            </div>
                          </div>

                          {/* Pending Security Alert / Blocked Request Banner */}
                          {pendingReq && (
                            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 text-xs text-amber-950 dark:text-amber-200 space-y-1">
                              <div className="font-cairo font-black flex items-center gap-1.5 text-rose-700 dark:text-rose-400">
                                <AlertTriangle className="w-4 h-4 shrink-0" />
                                <span>{pendingReq.reasonMessageAr}</span>
                              </div>
                              <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono-numbers text-slate-600 dark:text-slate-300">
                                <span>الجهاز: {pendingReq.deviceLabel} ({pendingReq.deviceId})</span>
                                <span dir="ltr">IP: {pendingReq.ip}</span>
                                {pendingReq.geoLabel && <span>الموقع: {pendingReq.geoLabel}</span>}
                                <span>الوقت: {pendingReq.requestedAt}</span>
                              </div>
                            </div>
                          )}

                          {/* Individual Devices */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            {rec.devices.map((dev) => (
                              <div
                                key={dev.deviceId}
                                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs"
                              >
                                <div className="space-y-1 min-w-0">
                                  <div className="font-cairo font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                                    <Monitor className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                                    <span className="truncate">{dev.deviceLabel}</span>
                                    {dev.adminApproved && (
                                      <span className="px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold shrink-0">
                                        مفعّل
                                      </span>
                                    )}
                                  </div>
                                  <div className="font-mono-numbers text-[10px] text-slate-500 truncate">
                                    ID: {dev.deviceId} {dev.boundIp ? `• IP: ${dev.boundIp}` : ''}
                                  </div>
                                  <div className="text-[10px] text-slate-400 truncate">
                                    {dev.boundGeoLabel ? `الموقع المعتمد: ${dev.boundGeoLabel} • ` : ''}
                                    آخر نشاط: {dev.lastActiveAt}
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleResetStudentDevices(targetKey, dev.deviceId)}
                                  className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-600 hover:text-white text-rose-600 text-[11px] font-cairo font-bold cursor-pointer shrink-0"
                                >
                                  إلغاء الجهاز
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= SUB-TAB 4: JUMPING & AUDIO WATERMARK + LESSON LOCKING ================= */}
          {activeSubTab === 'watermark_gating' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Controls */}
              <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5">
                <h3 className="font-cairo font-black text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-emerald-600" />
                  <span>إعدادات العلامة المائية المتحركة والصوتية وقفل الدروس</span>
                </h3>

                <div className="space-y-3">
                  <label className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.enableJumpingWatermark}
                      onChange={(e) =>
                        handleSaveConfig({
                          ...config,
                          enableJumpingWatermark: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-emerald-600 mt-1"
                    />
                    <div>
                      <p className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                        تفعيل العلامة المائية القافزة برقم هاتف الطالب وكوده في زوايا الفيديو
                      </p>
                      <p className="text-[11px] text-slate-500">
                        تتحرك تلقائياً بين زوايا الفيديو والدرس كل عدة ثوانٍ لمنع قص الفيديو أو إخفاء صاحب الحساب.
                      </p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.enableAudioWatermark}
                      onChange={(e) =>
                        handleSaveConfig({
                          ...config,
                          enableAudioWatermark: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-emerald-600 mt-1"
                    />
                    <div>
                      <p className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                        تفعيل العلامة المائية الصوتية المتقطعة (Audio Watermark)
                      </p>
                      <p className="text-[11px] text-slate-500">
                        تصدر بصمة صوتية خفيفة متقطعة باسم «منصة الشريف» وأرقام كود/هاتف الطالب أثناء تشغيل الدرس.
                      </p>
                    </div>
                  </label>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        سرعة قفز العلامة البصرية (بالثواني)
                      </label>
                      <input
                        type="number"
                        min={2}
                        max={20}
                        value={config.watermarkJumpingIntervalSec}
                        onChange={(e) =>
                          handleSaveConfig({
                            ...config,
                            watermarkJumpingIntervalSec: Number(e.target.value),
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers font-bold text-sm"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        تكرار البصمة الصوتية (بالثواني)
                      </label>
                      <input
                        type="number"
                        min={15}
                        max={120}
                        value={config.audioWatermarkIntervalSec}
                        onChange={(e) =>
                          handleSaveConfig({
                            ...config,
                            audioWatermarkIntervalSec: Number(e.target.value),
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers font-bold text-sm"
                      />
                    </div>
                  </div>
                </div>

                {/* Lesson Locking Policy */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <label className="flex items-start gap-3 p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.requireActivationCodeForStudents}
                      onChange={(e) =>
                        handleSaveConfig({
                          ...config,
                          requireActivationCodeForStudents: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-amber-600 mt-1"
                    />
                    <div>
                      <p className="font-cairo font-bold text-xs md:text-sm text-amber-950 dark:text-amber-200">
                        قفل جميع الدروس على الطلاب إلا لمن يشحن كود تفعيل ساري
                      </p>
                      <p className="text-[11px] text-amber-800 dark:text-amber-300/80">
                        عند تفعيل هذا الخيار، لن يفتح أي درس للطالب إلا إذا كان لديه اشتراك شهري/فصلي أو كود للمادة أو الدرس.
                      </p>
                    </div>
                  </label>

                  {lessons.length > 0 && (
                    <div className="space-y-2">
                      <p className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                        أو اختر دروساً محددة لقفلها بكود تفعيل (حتى لو كانت باقي الدروس مفتوحة):
                      </p>
                      <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                        {lessons.map((lesson) => {
                          const isLocked =
                            config.requireActivationCodeForStudents ||
                            config.lockedLessonIds.includes(lesson.id);
                          return (
                            <div
                              key={lesson.id}
                              className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs"
                            >
                              <span className="font-cairo font-bold text-slate-800 dark:text-slate-200">
                                {lesson.title} ({lesson.subject})
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  const exists = config.lockedLessonIds.includes(lesson.id);
                                  const nextLocked = exists
                                    ? config.lockedLessonIds.filter((id) => id !== lesson.id)
                                    : [...config.lockedLessonIds, lesson.id];
                                  handleSaveConfig({
                                    ...config,
                                    lockedLessonIds: nextLocked,
                                  });
                                }}
                                className={`px-3 py-1 rounded-lg font-cairo font-bold flex items-center gap-1 cursor-pointer ${
                                  isLocked
                                    ? 'bg-amber-500 text-slate-950'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {isLocked ? (
                                  <>
                                    <Lock className="w-3 h-3" />
                                    <span>محمي بكود</span>
                                  </>
                                ) : (
                                  <>
                                    <Unlock className="w-3 h-3" />
                                    <span>مفتوح مجاناً</span>
                                  </>
                                )}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Live Interactive Watermark Simulator */}
              <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                      معاينة حية للعلامة المائية القافزة والصوتية على الفيديو
                    </h3>
                    <p className="text-xs text-slate-500">
                      لاحظ كيف يقفز رقم هاتف الطالب وكوده في زوايا الفيديو كل {config.watermarkJumpingIntervalSec} ثوانٍ
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => playAudioWatermarkSample(previewPhone, currentUser.name)}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>اختبار سماع البصمة الصوتية الآن</span>
                  </button>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    جرب تغيير رقم هاتف الطالب في المعاينة الحية:
                  </label>
                  <input
                    type="text"
                    value={previewPhone}
                    onChange={(e) => setPreviewPhone(e.target.value)}
                    placeholder="01012345678"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers font-bold text-xs"
                  />
                </div>

                {/* Simulated Video Player Container with AlSharifWatermark */}
                <div className="relative h-72 rounded-2xl overflow-hidden bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-900 border-2 border-emerald-700/50 flex flex-col items-center justify-center text-white p-6">
                  <AlSharifWatermark
                    studentName={currentUser.name}
                    studentCode={currentUser.studentId || currentUser.id}
                    studentPhone={previewPhone}
                    extraLabel="حماية الفيديو والملكية الفكرية"
                    opacity="strong"
                    enableJumpingWatermark={config.enableJumpingWatermark}
                    jumpingIntervalSec={config.watermarkJumpingIntervalSec}
                    enableAudioWatermark={config.enableAudioWatermark}
                    audioIntervalSec={config.audioWatermarkIntervalSec}
                  />

                  <div className="relative z-10 text-center space-y-2 pointer-events-none">
                    <div className="w-14 h-14 rounded-full bg-white/10 border border-white/20 flex items-center justify-center mx-auto">
                      <BookOpen className="w-7 h-7 text-amber-300" />
                    </div>
                    <h4 className="font-cairo font-black text-lg text-white">
                      مشغل محاضرات منصة الشريف المحمي
                    </h4>
                    <p className="text-xs text-emerald-200 max-w-sm">
                      العلامة المائية القافزة تعرض اسم الطالب ورقم هاتفه ({previewPhone}) وتتحرك بين الزوايا تلقائياً.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
