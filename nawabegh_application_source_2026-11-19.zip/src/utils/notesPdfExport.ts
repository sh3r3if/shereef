import type { TimestampedLessonNote } from '../types';

export interface ExportNotesPdfParams {
  lessonTitle: string;
  subject: string;
  grade?: string;
  studentName: string;
  summaryHtml?: string;
  notes: TimestampedLessonNote[];
}

function escapeHtml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Exports timestamped lesson notes and summary to a clean A4 RTL printable PDF
 * using a hidden iframe (never triggers window.open popups).
 */
export function exportLessonNotesToPdf(params: ExportNotesPdfParams): void {
  const { lessonTitle, subject, grade, studentName, summaryHtml, notes } = params;
  const dateLabel = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const notesRows =
    notes.length > 0
      ? notes
          .map(
            (n, i) => `
          <tr>
            <td style="text-align:center;font-weight:700;color:#065f46;">${i + 1}</td>
            <td style="text-align:center;font-family:monospace;font-weight:700;color:#0f766e;">${escapeHtml(n.formattedTime || '00:00')}</td>
            <td style="line-height:1.7;">${escapeHtml(n.noteText)}</td>
            <td style="text-align:center;color:#64748b;font-size:11px;">${escapeHtml(n.createdAt)}</td>
          </tr>`
          )
          .join('')
      : `<tr><td colspan="4" style="text-align:center;padding:18px;color:#64748b;">لا توجد ملاحظات مسجلة بالثانية لهذا الدرس بعد.</td></tr>`;

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <title>مذكرة ملاحظات الدرس — ${escapeHtml(lessonTitle)}</title>
  <style>
    @page { size: A4; margin: 16mm; }
    body {
      font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
      color: #0f172a;
      margin: 0;
      padding: 0;
      direction: rtl;
      background: #ffffff;
    }
    .header {
      border-bottom: 3px solid #059669;
      padding-bottom: 12px;
      margin-bottom: 18px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
    }
    .brand { color: #059669; font-weight: 800; font-size: 13px; margin-bottom: 4px; }
    h1 { margin: 0 0 6px; font-size: 20px; color: #0f172a; }
    .meta { font-size: 12px; color: #475569; }
    .summary-box {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      padding: 12px 16px;
      margin-bottom: 18px;
      font-size: 13px;
      line-height: 1.75;
    }
    .summary-title { font-weight: 800; font-size: 14px; color: #065f46; margin-bottom: 6px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th {
      background: #ecfdf5;
      color: #065f46;
      border: 1px solid #a7f3d0;
      padding: 8px 10px;
      text-align: right;
    }
    td {
      border: 1px solid #e2e8f0;
      padding: 8px 10px;
      vertical-align: top;
    }
    .footer {
      margin-top: 22px;
      padding-top: 10px;
      border-top: 1px dashed #cbd5e1;
      font-size: 11px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
    }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="brand">منصة الشريف التعليمية — دفتر الملاحظات الشخصية</div>
      <h1>${escapeHtml(lessonTitle)}</h1>
      <div class="meta">المادة: <strong>${escapeHtml(subject)}</strong>${grade ? ` | الصف: <strong>${escapeHtml(grade)}</strong>` : ''}</div>
    </div>
    <div style="text-align:left;font-size:12px;color:#475569;">
      <div>الطالب: <strong>${escapeHtml(studentName)}</strong></div>
      <div>تاريخ التصدير: ${escapeHtml(dateLabel)}</div>
    </div>
  </div>
  ${
    summaryHtml
      ? `<div class="summary-box"><div class="summary-title">ملخص الدرس والأهداف التعليمية</div><div>${summaryHtml}</div></div>`
      : ''
  }
  <table>
    <thead>
      <tr>
        <th style="width:42px;text-align:center;">#</th>
        <th style="width:85px;text-align:center;">التوقيت</th>
        <th>الملاحظة الشخصية</th>
        <th style="width:120px;text-align:center;">التاريخ</th>
      </tr>
    </thead>
    <tbody>
      ${notesRows}
    </tbody>
  </table>
  <div class="footer">
    <span>تم التصدير من منصة الشريف التعليمية للمذاكرة والمراجعة الورقية</span>
    <span>عدد الملاحظات: ${notes.length}</span>
  </div>
</body>
</html>`;

  const existing = document.getElementById('alsharif-notes-print-frame');
  if (existing) existing.remove();

  const iframe = document.createElement('iframe');
  iframe.id = 'alsharif-notes-print-frame';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument || iframe.contentWindow?.document;
  if (!doc) return;
  doc.open();
  doc.write(html);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      // Fallback: download HTML if browser print is blocked
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `notes-${lessonTitle.slice(0, 30)}.html`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }
  }, 250);
}
