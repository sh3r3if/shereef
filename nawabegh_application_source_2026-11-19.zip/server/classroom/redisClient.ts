import Redis from 'ioredis';
import { classroomConfig } from './config.ts';

class ClassroomRedisService {
  private pubClient: Redis | null = null;
  private subClient: Redis | null = null;
  private connected = false;
  private readonly memoryStore = new Map<string, { value: string; expiresAt?: number }>();

  public async initialize(): Promise<boolean> {
    if (!classroomConfig.redisUrl || classroomConfig.redisUrl.trim() === '') {
      console.log('ℹ️ [LiveClassroom] REDIS_URL not set; using in-memory room state adapter.');
      return false;
    }

    try {
      const pub = new Redis(classroomConfig.redisUrl, {
        maxRetriesPerRequest: 1,
        lazyConnect: true,
        retryStrategy: () => null,
      });
      pub.on('error', () => {
        // Silence noisy reconnect spam in sandbox environments without Redis
      });

      await pub.connect();
      await pub.ping();

      const sub = pub.duplicate();
      sub.on('error', () => {});
      await sub.connect();

      this.pubClient = pub;
      this.subClient = sub;
      this.connected = true;
      console.log('✅ [LiveClassroom] Connected to Redis for room state & Socket.IO Pub/Sub.');
      return true;
    } catch {
      console.log('ℹ️ [LiveClassroom] Redis unavailable; falling back cleanly to single-node memory store.');
      this.pubClient = null;
      this.subClient = null;
      this.connected = false;
      return false;
    }
  }

  public isRedisConnected(): boolean {
    return this.connected && Boolean(this.pubClient) && Boolean(this.subClient);
  }

  public getAdapterClients(): { pubClient: Redis; subClient: Redis } | null {
    if (this.connected && this.pubClient && this.subClient) {
      return { pubClient: this.pubClient, subClient: this.subClient };
    }
    return null;
  }

  public async setRoomCache(key: string, value: string, ttlSeconds = 3600): Promise<void> {
    if (this.connected && this.pubClient) {
      await this.pubClient.set(key, value, 'EX', ttlSeconds);
      return;
    }
    this.memoryStore.set(key, {
      value,
      expiresAt: Date.now() + ttlSeconds * 1000,
    });
  }

  public async getRoomCache(key: string): Promise<string | null> {
    if (this.connected && this.pubClient) {
      return this.pubClient.get(key);
    }
    const entry = this.memoryStore.get(key);
    if (!entry) return null;
    if (entry.expiresAt && entry.expiresAt < Date.now()) {
      this.memoryStore.delete(key);
      return null;
    }
    return entry.value;
  }
}

export const classroomRedis = new ClassroomRedisService();
