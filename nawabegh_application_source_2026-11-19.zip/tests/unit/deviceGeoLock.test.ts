import { describe, expect, it } from 'vitest';
import {
  applyAdminDeviceApproval,
  evaluateDeviceAndNetworkAccess,
  isAccountExemptFromDeviceLock,
  normalizeIpAddress,
  type ClientNetworkContext,
  type StudentDeviceRecord,
} from '../../server/security/deviceGeoLockService';

function makeCtx(overrides: Partial<ClientNetworkContext> & { geo?: ClientNetworkContext['geo'] } = {}): ClientNetworkContext {
  const geo = {
    country: 'Egypt',
    countryCode: 'EG',
    governorate: 'Dakahlia',
    city: 'Mansoura',
    village: 'Mit Khamis',
    lat: 31.0409,
    lon: 31.3785,
    timezone: 'Africa/Cairo',
    ...(overrides.geo || {}),
  };
  return {
    ip: overrides.ip || '156.200.10.10',
    geo,
    geoLabelAr: overrides.geoLabelAr || `${geo.country} • ${geo.governorate} • ${geo.city} • ${geo.village}`,
  };
}

const BASE_USER = {
  userKey: 'stu-100',
  studentId: 'stu-100',
  studentName: 'أحمد محمد',
  username: 'ahmed100',
  role: 'student',
};

const STRICT_CONFIG = {
  enableDeviceBinding: true,
  maxDevicesPerStudent: 1,
  enforceStrictIpBinding: true,
  enforceStrictGeoBinding: true,
};

describe('Strict 1-Device + IP + Geographic Lock Service', () => {
  it('binds the first device with its IP and geographic location and rejects a second device until Admin activates', () => {
    const firstCtx = makeCtx();
    const bind1 = evaluateDeviceAndNetworkAccess({
      records: [],
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-1111',
      deviceLabel: 'Chrome (Windows)',
      networkCtx: firstCtx,
    });

    expect(bind1.allowed).toBe(true);
    expect(bind1.status).toBe('bound_new');
    expect(bind1.record.devices).toHaveLength(1);
    expect(bind1.record.devices[0].boundIp).toBe('156.200.10.10');

    // Attempt from a second device on the same IP & location -> must be blocked
    const secondDeviceAttempt = evaluateDeviceAndNetworkAccess({
      records: bind1.records,
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-2222',
      deviceLabel: 'Safari (iPhone)',
      networkCtx: firstCtx,
    });

    expect(secondDeviceAttempt.allowed).toBe(false);
    expect(secondDeviceAttempt.status).toBe('device_limit_blocked');
    expect(secondDeviceAttempt.blockReasonCode).toBe('device_limit_exceeded');
    expect(secondDeviceAttempt.requiresAdminActivation).toBe(true);
    expect(secondDeviceAttempt.record.pendingDeviceRequest?.deviceId).toBe('DEV-2222');

    // Admin explicitly activates the pending second device
    const approved = applyAdminDeviceApproval({
      records: secondDeviceAttempt.records,
      userKey: 'stu-100',
      mode: 'approve_pending_device',
      adminName: 'Mo-NewFolder',
    });

    expect(approved.updated).toBe(true);
    expect(approved.target?.devices).toHaveLength(2);
    expect(approved.target?.maxAllowedDevices).toBe(2);

    // Second device is now allowed after Admin activation
    const afterApproval = evaluateDeviceAndNetworkAccess({
      records: approved.records,
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-2222',
      deviceLabel: 'Safari (iPhone)',
      networkCtx: firstCtx,
    });

    expect(afterApproval.allowed).toBe(true);
  });

  it('blocks the same device when IP address changes until Admin reactivates', () => {
    const initialCtx = makeCtx({ ip: '156.200.10.10' });
    const bind1 = evaluateDeviceAndNetworkAccess({
      records: [],
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-1111',
      networkCtx: initialCtx,
    });
    expect(bind1.allowed).toBe(true);

    const changedIpCtx = makeCtx({ ip: '197.45.88.21' });
    const ipChangedAttempt = evaluateDeviceAndNetworkAccess({
      records: bind1.records,
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-1111',
      networkCtx: changedIpCtx,
    });

    expect(ipChangedAttempt.allowed).toBe(false);
    expect(ipChangedAttempt.blockReasonCode).toBe('ip_changed');
    expect(ipChangedAttempt.requiresAdminActivation).toBe(true);
    expect(ipChangedAttempt.record.lockStatus).toBe('locked');

    // Even reverting back stays locked until Admin approves/unlocks
    const lockedCheck = evaluateDeviceAndNetworkAccess({
      records: ipChangedAttempt.records,
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-1111',
      networkCtx: initialCtx,
    });
    expect(lockedCheck.allowed).toBe(false);
    expect(lockedCheck.status).toBe('account_locked_blocked');

    // Admin activates new IP
    const adminUnlock = applyAdminDeviceApproval({
      records: ipChangedAttempt.records,
      userKey: 'stu-100',
      mode: 'approve_ip_or_geo',
    });
    expect(adminUnlock.updated).toBe(true);

    const afterUnlock = evaluateDeviceAndNetworkAccess({
      records: adminUnlock.records,
      config: STRICT_CONFIG,
      user: BASE_USER,
      deviceId: 'DEV-1111',
      networkCtx: changedIpCtx,
    });
    expect(afterUnlock.allowed).toBe(true);
  });

  it('blocks same device when moving between villages, cities, governorates, or countries', () => {
    const baseCtx = makeCtx();
    const scenarios: Array<{ label: string; geo: ClientNetworkContext['geo'] }> = [
      { label: 'village change', geo: { village: 'Sandoub' } },
      { label: 'city change', geo: { city: 'Talkha' } },
      { label: 'governorate change', geo: { governorate: 'Cairo', city: 'Nasr City' } },
      { label: 'country change', geo: { country: 'Saudi Arabia', countryCode: 'SA', governorate: 'Riyadh', city: 'Riyadh' } },
    ];

    for (const sc of scenarios) {
      const bind1 = evaluateDeviceAndNetworkAccess({
        records: [] as StudentDeviceRecord[],
        config: STRICT_CONFIG,
        user: BASE_USER,
        deviceId: 'DEV-1111',
        networkCtx: baseCtx,
      });

      const movedCtx = makeCtx({ geo: sc.geo });
      const attempt = evaluateDeviceAndNetworkAccess({
        records: bind1.records,
        config: STRICT_CONFIG,
        user: BASE_USER,
        deviceId: 'DEV-1111',
        networkCtx: movedCtx,
      });

      expect(attempt.allowed, sc.label).toBe(false);
      expect(attempt.blockReasonCode, sc.label).toBe('geo_changed');
      expect(attempt.requiresAdminActivation, sc.label).toBe(true);
    }
  });

  it('exempts Super Admin and Admin accounts and normalizes IP addresses cleanly', () => {
    expect(
      isAccountExemptFromDeviceLock({
        uid: 'usr-super-admin',
        role: 'admin',
        username: 'Mo-NewFolder',
        isSuperAdmin: true,
      })
    ).toBe(true);
    expect(
      isAccountExemptFromDeviceLock({
        uid: 'stu-1',
        role: 'student',
        username: 'student1',
      })
    ).toBe(false);

    expect(normalizeIpAddress('::ffff:192.168.1.5')).toBe('192.168.1.5');
    expect(normalizeIpAddress('::1')).toBe('127.0.0.1');
    expect(normalizeIpAddress('156.200.1.2, 10.0.0.1')).toBe('156.200.1.2');
  });
});
