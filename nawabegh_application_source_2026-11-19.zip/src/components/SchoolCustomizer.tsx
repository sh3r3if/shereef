import React, { useState, useRef, useEffect } from 'react';
import {
  Palette,
  Check,
  Building,
  Sparkles,
  Save,
  CheckCircle2,
  Bell,
  RefreshCw,
  Eye,
  RotateCcw,
  X,
  Shield,
  Layers,
  Image as ImageIcon,
  Link as LinkIcon,
  Upload,
} from 'lucide-react';
import {
  SchoolSettings,
  Language,
  HeroSliderConfig,
  DEFAULT_HERO_SLIDER_CONFIG,
} from '../types';

interface SchoolCustomizerProps {
  settings: SchoolSettings;
  onUpdateSettings: (newSettings: SchoolSettings) => void;
  language: Language;
}

export const SchoolCustomizer: React.FC<SchoolCustomizerProps> = ({
  settings,
  onUpdateSettings,
  language,
}) => {
  const isAr = language === 'ar';

  const [schoolName, setSchoolName] = useState(settings.schoolName);
  const [schoolNameEn, setSchoolNameEn] = useState(settings.schoolNameEn);
  const [tagline, setTagline] = useState(settings.tagline);
  const [primaryColor, setPrimaryColor] = useState(settings.primaryColor);
  const [academicYear, setAcademicYear] = useState(settings.academicYear);
  const [enableInstantNotifications, setEnableInstantNotifications] = useState(
    settings.enableInstantNotifications
  );
  const [enableRealtimeSync, setEnableRealtimeSync] = useState(
    settings.enableRealtimeSync
  );
  const [heroSlider, setHeroSlider] = useState<HeroSliderConfig>({
    ...DEFAULT_HERO_SLIDER_CONFIG,
    ...(settings.heroSlider || {}),
  });
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const sliderFileRef = useRef<HTMLInputElement | null>(null);
  const whyFileRef = useRef<HTMLInputElement | null>(null);
  const testimonialFileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setHeroSlider({
      ...DEFAULT_HERO_SLIDER_CONFIG,
      ...(settings.heroSlider || {}),
    });
  }, [settings.heroSlider]);

  const handleSliderImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setHeroSlider((prev) => ({ ...prev, sliderImageUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleWhyImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setHeroSlider((prev) => ({ ...prev, whyImageUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleTestimonialImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setHeroSlider((prev) => ({ ...prev, testimonialAvatarUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const brandColors = [
    { label: 'الكحلي الأكاديمي (Navy)', hex: '#1e3a8a' },
    { label: 'الأزرق الملكي (Sapphire)', hex: '#2563eb' },
    { label: 'الزمردي التعليمي (Emerald)', hex: '#059669' },
    { label: 'الذهبي الفخري (Scholastic Gold)', hex: '#d97706' },
    { label: 'العنابي الأكاديمي (Maroon)', hex: '#991b1b' },
    { label: 'النيلي الذكي (Academic Indigo)', hex: '#4f46e5' },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: SchoolSettings = {
      ...settings,
      schoolName,
      schoolNameEn,
      tagline,
      primaryColor,
      academicYear,
      enableInstantNotifications,
      enableRealtimeSync,
      heroSlider,
    };
    onUpdateSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDefaults = () => {
    const defaultSettings: SchoolSettings = {
      schoolName: 'منصة الشريف',
      schoolNameEn: 'Al-Sharif Edu Platform',
      tagline:
        'منصة رائدة تدمج التعليم الإلكتروني التفاعلي ومراكز التدريب الحضورية بأعلى معايير الجودة',
      logoUrl: '/assets/images/certificate_crest_gold_1794403367581.jpg',
      primaryColor: '#059669',
      academicYear: '2026 - 2027',
      enableInstantNotifications: true,
      enableRealtimeSync: true,
      heroSlider: DEFAULT_HERO_SLIDER_CONFIG,
    };
    setSchoolName(defaultSettings.schoolName);
    setSchoolNameEn(defaultSettings.schoolNameEn);
    setTagline(defaultSettings.tagline);
    setPrimaryColor(defaultSettings.primaryColor);
    setAcademicYear(defaultSettings.academicYear);
    setEnableInstantNotifications(defaultSettings.enableInstantNotifications);
    setEnableRealtimeSync(defaultSettings.enableRealtimeSync);
    setHeroSlider(DEFAULT_HERO_SLIDER_CONFIG);
    onUpdateSettings(defaultSettings);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Palette className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>
              {isAr
                ? 'تخصيص هوية منصة الشريف وسلايدر الصفحة الرئيسية'
                : 'Platform Identity & Hero Slider Customization'}
            </span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 font-tajawal">
            {isAr
              ? 'تحكم كامل للأدمن في المسمى الرسمي، نصوص السلايدر، نصوص وروابط الأزرار، وصورة السلايدر الرئيسية'
              : 'Full admin control over brand identity, hero slider texts, button texts & links, and slider image'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDetailsOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Eye className="w-4 h-4 text-indigo-500" />
            <span>{isAr ? 'معاينة بطاقة الهوية' : 'View Identity'}</span>
          </button>

          <button
            type="button"
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title={isAr ? 'استعادة الافتراضي' : 'Reset'}
          >
            <RotateCcw className="w-4 h-4 text-slate-400" />
            <span>{isAr ? 'استعادة الافتراضي' : 'Reset'}</span>
          </button>

          {savedSuccess && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>{isAr ? 'تم حفظ التعديلات في قاعدة البيانات' : 'Saved to Database'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-6 text-xs md:text-sm shadow-xs font-tajawal">
        {/* School Names */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 font-cairo">
              {isAr ? 'اسم المنصة / الأكاديمية (باللغة العربية) *' : 'School Name (Arabic) *'}
            </label>
            <input
              type="text"
              required
              value={schoolName}
              onChange={(e) => setSchoolName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 font-cairo">
              {isAr ? 'اسم المنصة (باللغة الإنجليزية) *' : 'School Name (English) *'}
            </label>
            <input
              type="text"
              required
              value={schoolNameEn}
              onChange={(e) => setSchoolNameEn(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold font-sans"
            />
          </div>
        </div>

        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 font-cairo">
            {isAr ? 'الشعار اللفظي والرؤية التعليمية' : 'Slogan & Educational Vision'}
          </label>
          <input
            type="text"
            value={tagline}
            onChange={(e) => setTagline(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
          />
        </div>

        {/* HERO SLIDER CUSTOMIZATION SECTION */}
        <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base md:text-lg font-cairo font-black text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                <span>
                  {isAr
                    ? 'تخصيص سلايدر الصفحة الرئيسية (النصوص · الأزرار والروابط · الصورة)'
                    : 'Homepage Hero Slider Customization'}
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {isAr
                  ? 'تحكم في كل ما يظهر في السلايدر الرئيسي بالصفحة الرئيسية للمنصة'
                  : 'Control all texts, buttons, links, and image in the homepage hero slider'}
              </p>
            </div>
          </div>

          {/* 1. Slider Texts */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr ? '1. نصوص وعناوين السلايدر' : '1. Slider Texts & Headlines'}
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'نص الشارة العلوية للسلايدر' : 'Top Kicker Badge'}
                </label>
                <input
                  type="text"
                  value={heroSlider.badgeTextAr}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, badgeTextAr: e.target.value }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'العنوان الرئيسي (السطر الأول)' : 'Headline Line 1'}
                </label>
                <input
                  type="text"
                  value={heroSlider.headlineLine1Ar}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, headlineLine1Ar: e.target.value }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                />
              </div>

              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'العنوان الرئيسي (السطر الثاني)' : 'Headline Line 2'}
                </label>
                <input
                  type="text"
                  value={heroSlider.headlineLine2Ar}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, headlineLine2Ar: e.target.value }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                {isAr ? 'النص الوصفي الفرعي للسلايدر' : 'Slider Subtitle'}
              </label>
              <textarea
                rows={2}
                value={heroSlider.subtitleAr}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, subtitleAr: e.target.value }))
                }
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'نص مربع البحث في السلايدر' : 'Search Input Placeholder'}
                </label>
                <input
                  type="text"
                  value={heroSlider.searchPlaceholderAr}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, searchPlaceholderAr: e.target.value }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'نص زر البحث' : 'Search Button Text'}
                </label>
                <input
                  type="text"
                  value={heroSlider.searchButtonTextAr}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, searchButtonTextAr: e.target.value }))
                  }
                  className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
            </div>
          </div>

          {/* 2. Slider Buttons & Links */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
              <LinkIcon className="w-4 h-4 text-emerald-600" />
              <span>{isAr ? '2. نصوص وروابط أزرار السلايدر' : '2. Slider Buttons & Links'}</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Button 1 */}
              <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-xs">
                    {isAr ? 'الزر الأول (الرئيسي)' : 'Primary Button'}
                  </span>
                  <label className="flex items-center gap-1.5 text-xs font-cairo cursor-pointer">
                    <input
                      type="checkbox"
                      checked={heroSlider.showPrimaryBtn !== false}
                      onChange={(e) =>
                        setHeroSlider((p) => ({ ...p, showPrimaryBtn: e.target.checked }))
                      }
                      className="accent-emerald-600"
                    />
                    <span>{isAr ? 'مفعل' : 'Visible'}</span>
                  </label>
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'نص الزر الأول' : 'Button 1 Text'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.primaryBtnTextAr}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, primaryBtnTextAr: e.target.value }))
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'رابط الزر الأول (URL أو #courses-section أو #auth)' : 'Button 1 Link'}
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={heroSlider.primaryBtnLink}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, primaryBtnLink: e.target.value }))
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs"
                  />
                </div>
              </div>

              {/* Button 2 */}
              <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-xs">
                    {isAr ? 'الزر الثاني (الثانوي)' : 'Secondary Button'}
                  </span>
                  <label className="flex items-center gap-1.5 text-xs font-cairo cursor-pointer">
                    <input
                      type="checkbox"
                      checked={heroSlider.showSecondaryBtn !== false}
                      onChange={(e) =>
                        setHeroSlider((p) => ({ ...p, showSecondaryBtn: e.target.checked }))
                      }
                      className="accent-emerald-600"
                    />
                    <span>{isAr ? 'مفعل' : 'Visible'}</span>
                  </label>
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'نص الزر الثاني' : 'Button 2 Text'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.secondaryBtnTextAr}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, secondaryBtnTextAr: e.target.value }))
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'رابط الزر الثاني (URL أو #auth أو #tab:lessons)' : 'Button 2 Link'}
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={heroSlider.secondaryBtnLink}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, secondaryBtnLink: e.target.value }))
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 3. Slider Image */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
              <ImageIcon className="w-4 h-4 text-emerald-600" />
              <span>{isAr ? '3. صورة السلايدر والبطاقات العائمة' : '3. Slider Image & Floating Badges'}</span>
            </h4>

            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-28 h-36 rounded-t-[48px] rounded-b-xl overflow-hidden border-2 border-emerald-500 shrink-0 bg-slate-100">
                <img
                  src={
                    heroSlider.sliderImageUrl ||
                    '/assets/images/hero_school_platform_1794403365692.jpg'
                  }
                  alt="Slider preview"
                  className="w-full h-full object-cover object-top"
                />
              </div>

              <div className="flex-1 w-full space-y-3">
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    dir="ltr"
                    value={heroSlider.sliderImageUrl}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, sliderImageUrl: e.target.value }))
                    }
                    placeholder="/assets/images/... or https://..."
                    className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-xs"
                  />
                  <input
                    ref={sliderFileRef}
                    type="file"
                    accept="image/*"
                    onChange={handleSliderImageFile}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => sliderFileRef.current?.click()}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{isAr ? 'رفع صورة من جهازك' : 'Upload Image'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                      {isAr ? 'تقييم البطاقة العائمة' : 'Rating Badge'}
                    </label>
                    <input
                      type="text"
                      value={heroSlider.ratingBadgeScore}
                      onChange={(e) =>
                        setHeroSlider((p) => ({ ...p, ratingBadgeScore: e.target.value }))
                      }
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                      {isAr ? 'عنوان البطاقة السفلية' : 'Bottom Card Kicker'}
                    </label>
                    <input
                      type="text"
                      value={heroSlider.floatingCardKickerAr}
                      onChange={(e) =>
                        setHeroSlider((p) => ({ ...p, floatingCardKickerAr: e.target.value }))
                      }
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                      {isAr ? 'النص الرئيسي للبطاقة السفلية' : 'Bottom Card Title'}
                    </label>
                    <input
                      type="text"
                      value={heroSlider.floatingCardTitleAr}
                      onChange={(e) =>
                        setHeroSlider((p) => ({ ...p, floatingCardTitleAr: e.target.value }))
                      }
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 4. Stats Strip (4 Numbers & Labels) */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-emerald-600" />
                <span>
                  {isAr
                    ? '4. شريط الإحصائيات الرباعي (الأرقام والنصوص تحت السلايدر)'
                    : '4. Stats Strip Numbers & Labels'}
                </span>
              </h4>
              <span className="text-[11px] text-slate-500">
                {isAr
                  ? 'اترك حقل الرقم فارغاً ليقرأ العدد الفعلي تلقائياً من قاعدة البيانات'
                  : 'Leave number empty to use live DB count'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Stat 1 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'رقم الخانة الأولى (الطلاب)' : 'Stat 1 Value'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat1Value ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat1Value: e.target.value }))
                    }
                    placeholder={isAr ? 'تلقائي من الداتا بيز' : 'Auto from DB'}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'عنوان الخانة الأولى' : 'Stat 1 Label'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat1LabelAr ?? 'طالب مسجل في قاعدة البيانات'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat1LabelAr: e.target.value }))
                    }
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              {/* Stat 2 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'رقم الخانة الثانية (الدروس)' : 'Stat 2 Value'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat2Value ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat2Value: e.target.value }))
                    }
                    placeholder={isAr ? 'تلقائي من الداتا بيز' : 'Auto from DB'}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'عنوان الخانة الثانية' : 'Stat 2 Label'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat2LabelAr ?? 'درس ومحاضرة في قاعدة البيانات'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat2LabelAr: e.target.value }))
                    }
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              {/* Stat 3 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'رقم الخانة الثالثة (المعلمون)' : 'Stat 3 Value'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat3Value ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat3Value: e.target.value }))
                    }
                    placeholder={isAr ? 'تلقائي من الداتا بيز' : 'Auto from DB'}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'عنوان الخانة الثالثة' : 'Stat 3 Label'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat3LabelAr ?? 'معلم وخبير معتمد'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat3LabelAr: e.target.value }))
                    }
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              {/* Stat 4 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'رقم الخانة الرابعة (الاختبارات)' : 'Stat 4 Value'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat4Value ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat4Value: e.target.value }))
                    }
                    placeholder={isAr ? 'تلقائي من الداتا بيز' : 'Auto from DB'}
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                    {isAr ? 'عنوان الخانة الرابعة' : 'Stat 4 Label'}
                  </label>
                  <input
                    type="text"
                    value={heroSlider.stat4LabelAr ?? 'اختبار ومسابقة تفاعلية'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, stat4LabelAr: e.target.value }))
                    }
                    className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 5. Featured Courses Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr
                ? '5. قسم دورات ودروس منصة الشريف (العناوين وحالة عدم وجود دورات)'
                : '5. Featured Courses Section'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'الشارة العلوية لقسم الدورات' : 'Courses Kicker'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesKickerAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesKickerAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'العنوان الرئيسي لقسم الدورات' : 'Courses Title'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesTitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesTitleAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'الوصف الفرعي لقسم الدورات' : 'Courses Subtitle'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesSubtitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesSubtitleAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'نص زر عرض الكل' : 'View All Button Text'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesViewAllBtnAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesViewAllBtnAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'عنوان عدم وجود دورات مطابقة' : 'Empty Courses Title'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesEmptyTitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesEmptyTitleAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'نص زر دخول البوابة لإضافة دروس' : 'Empty Courses Button Text'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesEmptyBtnTextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesEmptyBtnTextAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'وصف عدم وجود دورات مطابقة' : 'Empty Courses Description'}
                </label>
                <input
                  type="text"
                  value={heroSlider.coursesEmptyDescAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, coursesEmptyDescAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
            </div>
          </div>

          {/* 6. Tracks Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr ? '6. قسم اكتشف المواد الدراسية والمسارات' : '6. Subject Tracks Section'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'الشارة العلوية للمسارات' : 'Tracks Kicker'}
                </label>
                <input
                  type="text"
                  value={heroSlider.tracksKickerAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, tracksKickerAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'العنوان الرئيسي للمسارات' : 'Tracks Title'}
                </label>
                <input
                  type="text"
                  value={heroSlider.tracksTitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, tracksTitleAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                  {isAr ? 'النص عند عدم وجود مسارات حالياً' : 'Empty Tracks Description'}
                </label>
                <input
                  type="text"
                  value={heroSlider.tracksEmptyDescAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, tracksEmptyDescAr: e.target.value }))
                  }
                  className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                />
              </div>
            </div>
          </div>

          {/* 7. Why Al-Sharif Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr
                ? '7. قسم لماذا منصة الشريف؟ (المميزات الأربعة · الصورة · بطاقة أحسنت!)'
                : '7. Why Al-Sharif Section'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input
                type="text"
                value={heroSlider.whyKickerAr ?? ''}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whyKickerAr: e.target.value }))}
                placeholder="لماذا منصة الشريف؟"
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <input
                type="text"
                value={heroSlider.whyTitleAr ?? ''}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whyTitleAr: e.target.value }))}
                placeholder="كل ما تحتاجه لتستمر في التقدّم"
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
              <input
                type="text"
                value={heroSlider.whySubtitleAr ?? ''}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whySubtitleAr: e.target.value }))}
                placeholder="نبني تجربة التعلّم حول وقتك وأهدافك، لا العكس."
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Feature 1 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={heroSlider.whyFeature1Icon ?? '📅'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature1Icon: e.target.value }))
                    }
                    className="w-12 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center"
                  />
                  <input
                    type="text"
                    value={heroSlider.whyFeature1TitleAr ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature1TitleAr: e.target.value }))
                    }
                    className="flex-1 px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <input
                  type="text"
                  value={heroSlider.whyFeature1DescAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, whyFeature1DescAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              {/* Feature 2 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={heroSlider.whyFeature2Icon ?? '🎓'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature2Icon: e.target.value }))
                    }
                    className="w-12 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center"
                  />
                  <input
                    type="text"
                    value={heroSlider.whyFeature2TitleAr ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature2TitleAr: e.target.value }))
                    }
                    className="flex-1 px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <input
                  type="text"
                  value={heroSlider.whyFeature2DescAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, whyFeature2DescAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              {/* Feature 3 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={heroSlider.whyFeature3Icon ?? '⚡'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature3Icon: e.target.value }))
                    }
                    className="w-12 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center"
                  />
                  <input
                    type="text"
                    value={heroSlider.whyFeature3TitleAr ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature3TitleAr: e.target.value }))
                    }
                    className="flex-1 px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <input
                  type="text"
                  value={heroSlider.whyFeature3DescAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, whyFeature3DescAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              {/* Feature 4 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={heroSlider.whyFeature4Icon ?? '📊'}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature4Icon: e.target.value }))
                    }
                    className="w-12 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center"
                  />
                  <input
                    type="text"
                    value={heroSlider.whyFeature4TitleAr ?? ''}
                    onChange={(e) =>
                      setHeroSlider((p) => ({ ...p, whyFeature4TitleAr: e.target.value }))
                    }
                    className="flex-1 px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                  />
                </div>
                <input
                  type="text"
                  value={heroSlider.whyFeature4DescAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, whyFeature4DescAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                dir="ltr"
                value={heroSlider.whyImageUrl ?? ''}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whyImageUrl: e.target.value }))}
                placeholder="رابط صورة قسم لماذا منصة الشريف؟"
                className="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-xs"
              />
              <input
                ref={whyFileRef}
                type="file"
                accept="image/*"
                onChange={handleWhyImageFile}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => whyFileRef.current?.click()}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{isAr ? 'رفع صورة القسم' : 'Upload'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                value={heroSlider.whyTrophyIcon ?? '🏆'}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whyTrophyIcon: e.target.value }))}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center"
              />
              <input
                type="text"
                value={heroSlider.whyTrophyTitleAr ?? 'أحسنت!'}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whyTrophyTitleAr: e.target.value }))}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
              <input
                type="text"
                value={heroSlider.whyTrophyDescAr ?? 'حققت هدفك الأسبوعي'}
                onChange={(e) => setHeroSlider((p) => ({ ...p, whyTrophyDescAr: e.target.value }))}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
            </div>
          </div>

          {/* 8. Testimonial Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr ? '8. قسم قصص من مجتمعنا (الاقتباس وسارة خالد)' : '8. Testimonial Section'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={heroSlider.testimonialKickerAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, testimonialKickerAr: e.target.value }))
                }
                placeholder="قصص من مجتمعنا"
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <input
                type="text"
                value={heroSlider.testimonialTitleAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, testimonialTitleAr: e.target.value }))
                }
                placeholder="حين يتحوّل التعلّم إلى فرصة"
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
              <textarea
                rows={2}
                value={heroSlider.testimonialQuoteAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, testimonialQuoteAr: e.target.value }))
                }
                className="md:col-span-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <input
                type="text"
                value={heroSlider.testimonialAuthorNameAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, testimonialAuthorNameAr: e.target.value }))
                }
                placeholder="سارة خالد"
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
              <input
                type="text"
                value={heroSlider.testimonialAuthorRoleAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, testimonialAuthorRoleAr: e.target.value }))
                }
                placeholder="مصممة منتجات رقمية"
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <div className="md:col-span-2 flex gap-2">
                <input
                  type="text"
                  dir="ltr"
                  value={heroSlider.testimonialAvatarUrl ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, testimonialAvatarUrl: e.target.value }))
                  }
                  className="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-xs"
                />
                <input
                  ref={testimonialFileRef}
                  type="file"
                  accept="image/*"
                  onChange={handleTestimonialImageFile}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => testimonialFileRef.current?.click()}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-600 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isAr ? 'رفع صورة' : 'Upload'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* 9. Newsletter Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr ? '9. قسم النشرة البريدية (خطوتك القادمة تبدأ من بريدك)' : '9. Newsletter Section'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={heroSlider.newsletterTitleAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, newsletterTitleAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
              <input
                type="text"
                value={heroSlider.newsletterSubtitleAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, newsletterSubtitleAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <input
                type="text"
                value={heroSlider.newsletterPlaceholderAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, newsletterPlaceholderAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <input
                type="text"
                value={heroSlider.newsletterBtnTextAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, newsletterBtnTextAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
            </div>
          </div>

          {/* 10. Footer Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
              {isAr ? '10. قسم الفوتر السفلي بالكامل' : '10. Footer Section'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input
                type="text"
                value={heroSlider.footerBrandNameAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, footerBrandNameAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
              />
              <input
                type="text"
                value={heroSlider.footerBrandDescAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, footerBrandDescAr: e.target.value }))
                }
                className="md:col-span-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Col 1 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1.5">
                <input
                  type="text"
                  value={heroSlider.footerCol1TitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol1TitleAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol1Link1TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol1Link1TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol1Link2TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol1Link2TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol1Link3TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol1Link3TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              {/* Col 2 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1.5">
                <input
                  type="text"
                  value={heroSlider.footerCol2TitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol2TitleAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol2Link1TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol2Link1TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol2Link2TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol2Link2TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol2Link3TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol2Link3TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              {/* Col 3 */}
              <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1.5">
                <input
                  type="text"
                  value={heroSlider.footerCol3TitleAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol3TitleAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol3Link1TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol3Link1TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol3Link2TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol3Link2TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
                <input
                  type="text"
                  value={heroSlider.footerCol3Link3TextAr ?? ''}
                  onChange={(e) =>
                    setHeroSlider((p) => ({ ...p, footerCol3Link3TextAr: e.target.value }))
                  }
                  className="w-full px-2.5 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input
                type="text"
                value={heroSlider.footerCopyrightAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, footerCopyrightAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
              <input
                type="text"
                value={heroSlider.footerTaglineAr ?? ''}
                onChange={(e) =>
                  setHeroSlider((p) => ({ ...p, footerTaglineAr: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              />
            </div>
          </div>
        </div>

        {/* Primary Color Customizer */}
        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-2 font-cairo">
            {isAr ? 'اللون الرئيسي لهوية المنصة (Primary Brand Color)' : 'Primary Theme Accent'}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {brandColors.map((color) => {
              const isSelected = primaryColor === color.hex;

              return (
                <button
                  key={color.hex}
                  type="button"
                  onClick={() => setPrimaryColor(color.hex)}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 dark:border-white ring-2 ring-indigo-500/30 shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div
                    className="w-8 h-8 rounded-full shadow-inner flex items-center justify-center text-white"
                    style={{ backgroundColor: color.hex }}
                  >
                    {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                  </div>
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 truncate w-full text-center font-cairo">
                    {color.label.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Academic Year */}
        <div className="max-w-xs font-mono-numbers">
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 font-cairo">
            {isAr ? 'العام الدراسي النشط' : 'Active Academic Year'}
          </label>
          <input
            type="text"
            value={academicYear}
            onChange={(e) => setAcademicYear(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
          />
        </div>

        {/* System Features Toggles */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
          <h4 className="font-bold text-slate-800 dark:text-slate-200 text-sm font-cairo">
            {isAr ? 'خصائص التزامن اللحظي والإشعارات' : 'Real-time & Sync Features'}
          </h4>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-indigo-500" />
              <div>
                <p className="font-bold text-slate-900 dark:text-white font-cairo">
                  {isAr ? 'تفعيل الإشعارات الفورية التلقائية لأولياء الأمور' : 'Automated Instant Parent Alerts'}
                </p>
                <p className="text-xs text-slate-500">
                  {isAr
                    ? 'إرسال تنبيه آلي عند رصد الغياب أو تسجيل درجات ضعيفة أو تفوق'
                    : 'Auto trigger SMS and push alerts on attendance issues or honor scores'}
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={enableInstantNotifications}
              onChange={(e) => setEnableInstantNotifications(e.target.checked)}
              className="w-5 h-5 accent-indigo-600 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <RefreshCw className="w-5 h-5 text-emerald-500" />
              <div>
                <p className="font-bold text-slate-900 dark:text-white font-cairo">
                  {isAr ? 'ضمان التزامن اللحظي بين كافة الأجهزة وتطبيق الموبايل' : 'Real-time Cross-Device Sync'}
                </p>
                <p className="text-xs text-slate-500">
                  {isAr
                    ? 'مزامنة فورية للدروس، الواجبات، والحصص بين أجهزة أندرويد وiOS وسطح المكتب'
                    : 'Instant data synchronisation across iOS, Android, and Web'}
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={enableRealtimeSync}
              onChange={(e) => setEnableRealtimeSync(e.target.checked)}
              className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Save button */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs md:text-sm shadow-sm transition-colors cursor-pointer font-cairo"
          >
            <Save className="w-4 h-4" />
            <span>{isAr ? 'حفظ إعدادات الهوية والسلايدر في قاعدة البيانات' : 'Save Brand & Slider Settings'}</span>
          </button>
        </div>
      </form>

      {/* VIEW IDENTITY DETAILS MODAL */}
      {isDetailsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-600" />
                <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                  {isAr ? 'وثيقة وبيانات الهوية المعتمدة للأكاديمية' : 'Academy Brand Passport'}
                </h3>
              </div>
              <button
                onClick={() => setIsDetailsOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm font-tajawal">
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 flex items-center gap-4">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-md shrink-0"
                  style={{ backgroundColor: primaryColor }}
                >
                  <Building className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-slate-900 dark:text-white font-cairo">{schoolName}</h4>
                  <p className="text-xs text-slate-500 font-sans">{schoolNameEn}</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">{isAr ? 'الرؤية والشعار:' : 'Tagline:'}</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 text-right">{tagline}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{isAr ? 'كود اللون الأساسي:' : 'Color Hex:'}</span>
                  <span className="font-bold font-mono-numbers px-2 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                    {primaryColor}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{isAr ? 'العام الدراسي:' : 'Academic Year:'}</span>
                  <span className="font-bold font-mono-numbers text-slate-800 dark:text-slate-200">{academicYear}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{isAr ? 'تنبيهات أولياء الأمور:' : 'Alerts:'}</span>
                  <span className="font-bold text-emerald-600">
                    {enableInstantNotifications ? (isAr ? 'مفعلة' : 'Active') : (isAr ? 'معطلة' : 'Disabled')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">{isAr ? 'التزامن اللحظي WebSocket:' : 'Realtime WS:'}</span>
                  <span className="font-bold text-emerald-600">
                    {enableRealtimeSync ? (isAr ? 'مفعل نشط' : 'Active') : (isAr ? 'معطل' : 'Disabled')}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setIsDetailsOpen(false)}
                className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs font-cairo cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
