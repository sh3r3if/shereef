import React, { useMemo, useState } from 'react';
import {
  Camera,
  CameraOff,
  Check,
  Copy,
  LayoutGrid,
  Lock,
  Mic,
  MicOff,
  MonitorUp,
  MonitorX,
  PanelLeftClose,
  PanelLeftOpen,
  PhoneOff,
  Radio,
  Unlock,
  Users,
  AlertTriangle,
} from 'lucide-react';
import { useClassroomSocket } from '../hooks/useClassroomSocket';
import { useLiveKitMedia } from '../hooks/useLiveKitMedia';
import {
  QualityBadge,
  StreamVideo,
  VideoStageFloating,
} from './VideoStageFloating';
import type { PreJoinSettings } from './PreJoinCheckModal';
import type {
  ClassroomJoinResponse,
  ClassroomRole,
  LiveRoomInfo,
} from '../../types/classroom';

interface ClassroomShellProps {
  session: ClassroomJoinResponse & {
    user: { userId: string; userName: string; role: ClassroomRole };
  };
  preJoinSettings: PreJoinSettings;
  onGenerateInviteLink: (
    roomId: string,
    role: ClassroomRole,
    ttlMinutes: number
  ) => Promise<string | null>;
  onToggleLockRoom: (room: LiveRoomInfo) => Promise<void>;
  onEndRoomForAll: (roomId: string) => Promise<void>;
  onLeave: () => void;
}

function getClassroomRoleLabelAr(role: string): string {
  switch (role) {
    case 'teacher':
      return 'المعلم';
    case 'assistant':
      return 'المساعد';
    case 'admin':
      return 'الإشراف';
    default:
      return 'طالب';
  }
}

export const ClassroomShell: React.FC<ClassroomShellProps> = ({
  session,
  preJoinSettings,
  onGenerateInviteLink,
  onToggleLockRoom,
  onEndRoomForAll,
  onLeave,
}) => {
  const {
    socket,
    status: socketStatus,
    errorMessage: socketError,
    room: liveRoomState,
    self,
    participants,
    emitMediaState,
    emitQualityReport,
  } = useClassroomSocket({
    roomToken: session.roomToken,
    enabled: true,
  });

  const activeRoom = liveRoomState || session.room;
  const isModerator =
    session.role === 'teacher' ||
    session.role === 'assistant' ||
    session.role === 'admin';

  const {
    localStream,
    localScreenStream,
    remoteTiles,
    isMicEnabled,
    isCamEnabled,
    isScreenSharing,
    localQuality,
    mediaError,
    toggleMic,
    toggleCam,
    toggleScreenShare,
    leaveMedia,
  } = useLiveKitMedia({
    mode: session.mediaConfig.mode,
    livekitUrl: session.mediaConfig.livekitUrl,
    livekitToken: session.mediaConfig.livekitToken,
    socket,
    selfSocketId: self?.socketId,
    userRole: session.role,
    initialMicEnabled: preJoinSettings.micEnabled,
    initialCamEnabled: preJoinSettings.camEnabled,
    selectedAudioDeviceId: preJoinSettings.audioDeviceId,
    selectedVideoDeviceId: preJoinSettings.videoDeviceId,
    onMediaStateChange: emitMediaState,
    onQualityChange: emitQualityReport,
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [layoutMode, setLayoutMode] = useState<'stage' | 'grid'>('stage');
  const [copiedInvite, setCopiedInvite] = useState(false);

  // Determine active Screen Share stream (either local or remote host)
  const activeScreenTile = useMemo(
    () => remoteTiles.find((t) => Boolean(t.screenStream)),
    [remoteTiles]
  );

  // Primary host / teacher video stream for floating PiP
  const hostTile = useMemo(() => {
    if (isModerator) return null; // Local user is host -> show localStream
    return (
      remoteTiles.find((t) => t.role === 'teacher' || t.role === 'admin') ||
      remoteTiles[0] ||
      null
    );
  }, [isModerator, remoteTiles]);

  const floatingStream = isModerator ? localStream : hostTile?.cameraStream || null;
  const floatingName = isModerator
    ? session.user.userName
    : hostTile?.userName || activeRoom.hostName;
  const floatingRoleLabel = isModerator
    ? getClassroomRoleLabelAr(session.role)
    : getClassroomRoleLabelAr(hostTile?.role || 'teacher');
  const floatingMic = isModerator
    ? isMicEnabled
    : participants.find((p) => p.userName === floatingName)?.isMicEnabled ?? true;
  const floatingCam = isModerator
    ? isCamEnabled
    : Boolean(hostTile?.cameraStream);
  const floatingQuality = isModerator
    ? localQuality
    : hostTile?.connectionQuality || 'good';

  const handleCopyStudentInvite = async () => {
    const url = await onGenerateInviteLink(activeRoom.id, 'student', 240);
    if (url) {
      await navigator.clipboard.writeText(url);
      setCopiedInvite(true);
      window.setTimeout(() => setCopiedInvite(false), 2500);
    }
  };

  const handleExit = () => {
    leaveMedia();
    onLeave();
  };

  return (
    <div
      className="flex flex-col h-[calc(100vh-110px)] min-h-[600px] rounded-2xl overflow-hidden bg-slate-950 text-white border border-slate-800 shadow-2xl font-tajawal"
      dir="rtl"
    >
      {/* Top Studio Header Bar */}
      <header className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
            <Radio className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="font-cairo font-bold text-sm sm:text-base truncate">
                {activeRoom.title}
              </h2>
              <span className="font-mono text-[11px] px-2 py-0.5 rounded-md bg-slate-800 text-emerald-400 border border-slate-700 shrink-0">
                {activeRoom.roomCode}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              {activeRoom.subject} • {activeRoom.grade} •{' '}
              {session.mediaConfig.mode === 'livekit' ? 'LiveKit SFU' : 'WebRTC Direct'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <QualityBadge quality={localQuality} />

          <span
            className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold border ${
              socketStatus === 'connected'
                ? 'bg-emerald-950/70 text-emerald-300 border-emerald-800'
                : socketStatus === 'reconnecting'
                ? 'bg-amber-950/70 text-amber-300 border-amber-800'
                : 'bg-rose-950/70 text-rose-300 border-rose-800'
            }`}
          >
            {socketStatus === 'connected'
              ? 'متصل لحظياً'
              : socketStatus === 'reconnecting'
              ? 'جارِ إعادة الاتصال...'
              : 'جاري المزامنة'}
          </span>

          {isModerator && (
            <>
              <button
                type="button"
                onClick={handleCopyStudentInvite}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
              >
                {copiedInvite ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-sky-400" />
                )}
                <span>{copiedInvite ? 'تم النسخ' : 'نسخ رابط الدعوة'}</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleLockRoom(activeRoom)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer ${
                  activeRoom.isLocked
                    ? 'bg-rose-950/80 border-rose-700 text-rose-200 hover:bg-rose-900'
                    : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                }`}
              >
                {activeRoom.isLocked ? (
                  <Lock className="w-3.5 h-3.5" />
                ) : (
                  <Unlock className="w-3.5 h-3.5" />
                )}
                <span>{activeRoom.isLocked ? 'الغرفة مقفلة' : 'قفل الغرفة'}</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => setIsSidebarOpen((v) => !v)}
            aria-label={isSidebarOpen ? 'إخفاء قائمة الحضور' : 'عرض قائمة الحضور'}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 cursor-pointer"
          >
            {isSidebarOpen ? (
              <PanelLeftClose className="w-4 h-4" />
            ) : (
              <PanelLeftOpen className="w-4 h-4" />
            )}
          </button>
        </div>
      </header>

      {/* Main Split Workspace */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        {/* Central Stage Zone */}
        <section className="flex-1 relative flex flex-col min-w-0 bg-slate-950 p-3 sm:p-4 overflow-hidden">
          {(mediaError || socketError) && (
            <div className="mb-3 px-3.5 py-2 rounded-xl bg-amber-950/80 border border-amber-700/70 text-amber-200 text-xs flex items-center gap-2 shrink-0">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{socketError || mediaError}</span>
            </div>
          )}

          {layoutMode === 'grid' ? (
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 overflow-y-auto">
              {/* Self Tile */}
              <div className="relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden min-h-[190px] flex items-center justify-center">
                {isCamEnabled && localStream ? (
                  <StreamVideo stream={localStream} muted mirror />
                ) : (
                  <div className="text-center space-y-1.5">
                    <div className="w-12 h-12 mx-auto rounded-full bg-emerald-900/50 border border-emerald-700 flex items-center justify-center font-cairo font-bold text-emerald-300">
                      {session.user.userName.slice(0, 2)}
                    </div>
                    <p className="text-xs text-slate-400">أنت (الكاميرا مغلقة)</p>
                  </div>
                )}
                <div className="absolute bottom-2 inset-x-2 flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-md bg-slate-950/85 text-xs font-cairo font-bold">
                    {session.user.userName} ({getClassroomRoleLabelAr(session.role)})
                  </span>
                  <QualityBadge quality={localQuality} />
                </div>
              </div>

              {/* Remote Participant Video Tiles */}
              {remoteTiles.map((tile) => (
                <div
                  key={tile.participantId}
                  className="relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden min-h-[190px] flex items-center justify-center"
                >
                  {tile.screenStream || tile.cameraStream ? (
                    <StreamVideo stream={tile.screenStream || tile.cameraStream} />
                  ) : (
                    <div className="text-center space-y-1.5">
                      <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-cairo font-bold text-slate-200">
                        {tile.userName.slice(0, 2)}
                      </div>
                      <p className="text-xs text-slate-400">متصل بالصوت فقط</p>
                    </div>
                  )}
                  <div className="absolute bottom-2 inset-x-2 flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md bg-slate-950/85 text-xs font-cairo font-bold">
                      {tile.userName} ({getClassroomRoleLabelAr(tile.role)})
                    </span>
                    <QualityBadge quality={tile.connectionQuality} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden flex items-center justify-center">
              {/* Screen Share Full Stage if Active */}
              {localScreenStream || activeScreenTile?.screenStream ? (
                <div className="w-full h-full relative bg-black flex items-center justify-center">
                  <StreamVideo
                    stream={localScreenStream || activeScreenTile?.screenStream || null}
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute top-3 right-3 px-3 py-1 rounded-lg bg-emerald-900/90 border border-emerald-500/50 text-xs font-cairo font-bold">
                    بث مشاركة الشاشة المباشر
                  </div>
                </div>
              ) : (
                /* Main Architectural Stage Ready for Phase 2 Konva + Yjs Synchronized Whiteboard */
                <div
                  className="w-full h-full flex flex-col items-center justify-center p-6 text-center"
                  style={{
                    backgroundImage:
                      'radial-gradient(rgba(148, 163, 184, 0.16) 1px, transparent 1px)',
                    backgroundSize: '24px 24px',
                  }}
                >
                  <div className="max-w-lg space-y-3 bg-slate-950/85 p-6 rounded-2xl border border-slate-800">
                    <span className="inline-block px-3 py-1 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-800 text-[11px] font-cairo font-bold">
                      قاعة البث المباشر — المرحلة الأولى مفعّلة
                    </span>
                    <h3 className="font-cairo font-bold text-lg text-white">
                      {activeRoom.title}
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      البث الصوتي والمرئي ومشاركة الشاشة تعمل الآن عبر{' '}
                      {session.mediaConfig.mode === 'livekit' ? 'LiveKit SFU (Simulcast)' : 'WebRTC Direct'}،
                      ويمكنك تحريك نافذة فيديو المعلم العائمة بحرية في أي زاوية من المنصة.
                    </p>
                  </div>
                </div>
              )}

              {/* Draggable Floating Teacher Camera */}
              <VideoStageFloating
                stream={floatingStream}
                userName={floatingName}
                roleLabel={floatingRoleLabel}
                isMicEnabled={floatingMic}
                isCamEnabled={floatingCam}
                quality={floatingQuality}
                isSelf={isModerator}
              />
            </div>
          )}
        </section>

        {/* Collapsible Right/Left Roster Sidebar */}
        {isSidebarOpen && (
          <aside className="w-72 sm:w-80 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <h3 className="font-cairo font-bold text-xs text-white">
                  المتصلون في الغرفة ({participants.length})
                </h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Max {activeRoom.maxParticipants}
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {participants.map((p) => (
                <div
                  key={p.socketId}
                  className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-cairo font-bold text-white truncate">
                      {p.userName}{' '}
                      {p.userId === session.user.userId && (
                        <span className="text-emerald-400">(أنت)</span>
                      )}
                    </p>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[10px] font-cairo text-slate-400">
                        {getClassroomRoleLabelAr(p.role)}
                      </span>
                      <QualityBadge quality={p.connectionQuality} />
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {p.isMicEnabled ? (
                      <Mic className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <MicOff className="w-3.5 h-3.5 text-rose-400" />
                    )}
                    {p.isCamEnabled ? (
                      <Camera className="w-3.5 h-3.5 text-sky-400" />
                    ) : (
                      <CameraOff className="w-3.5 h-3.5 text-slate-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </aside>
        )}
      </div>

      {/* Bottom Media Control Dock */}
      <footer className="px-4 py-3 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="font-cairo font-bold text-slate-200">
            الدور: {getClassroomRoleLabelAr(session.role)}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={toggleMic}
            className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isMicEnabled
                ? 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                : 'bg-rose-600 hover:bg-rose-700 text-white'
            }`}
          >
            {isMicEnabled ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4" />}
            <span>{isMicEnabled ? 'كتم المايك' : 'تشغيل المايك'}</span>
          </button>

          <button
            type="button"
            onClick={toggleCam}
            className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isCamEnabled
                ? 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                : 'bg-rose-600 hover:bg-rose-700 text-white'
            }`}
          >
            {isCamEnabled ? (
              <Camera className="w-4 h-4 text-emerald-400" />
            ) : (
              <CameraOff className="w-4 h-4" />
            )}
            <span>{isCamEnabled ? 'إيقاف الكاميرا' : 'فتح الكاميرا'}</span>
          </button>

          {isModerator && (
            <button
              type="button"
              onClick={toggleScreenShare}
              className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isScreenSharing
                  ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
              }`}
            >
              {isScreenSharing ? (
                <MonitorX className="w-4 h-4" />
              ) : (
                <MonitorUp className="w-4 h-4 text-sky-400" />
              )}
              <span>{isScreenSharing ? 'إيقاف المشاركة' : 'مشاركة الشاشة'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setLayoutMode((m) => (m === 'stage' ? 'grid' : 'stage'))}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <LayoutGrid className="w-4 h-4 text-amber-400" />
            <span>{layoutMode === 'stage' ? 'عرض الشبكة' : 'عرض المنصة'}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {isModerator && (
            <button
              type="button"
              onClick={() => {
                leaveMedia();
                onEndRoomForAll(activeRoom.id);
              }}
              className="px-3.5 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 border border-rose-700 text-rose-200 text-xs font-cairo font-bold cursor-pointer"
            >
              إنهاء الحصة للجميع
            </button>
          )}

          <button
            type="button"
            onClick={handleExit}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            <span>مغادرة</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
