import React, { useState, useMemo, useEffect } from 'react';
import {
  Users,
  GraduationCap,
  Award,
  TrendingUp,
  BookOpen,
  BarChart3,
  Wifi,
  Building2,
  ShieldCheck,
  UserPlus,
  Database,
  Download,
  UploadCloud,
  Bell,
  Check,
  X,
  Shield,
  RefreshCw,
  Trash2,
  Calendar,
  FileCheck2,
  MessageSquare,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Search,
  Star,
  AlertTriangle,
  ShieldAlert,
  Activity,
  Wallet,
  Send,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  Student,
  Teacher,
  Lesson,
  LessonRating,
  Quiz,
  QuizAttempt,
  Certificate,
  TuitionInvoice,
  Language,
  CurrentUser,
  AssistantAdmin,
  SystemAuditLog,
  AtRiskStudentAlert,
  TeacherRevenueBreakdownItem,
} from '../types';
import { getAuthHeaders } from '../utils/rbac';

interface AdminDashboardProps {
  students: Student[];
  teachers: Teacher[];
  lessons: Lesson[];
  lessonRatings?: LessonRating[];
  quizzes: Quiz[];
  quizAttempts?: QuizAttempt[];
  certificates: Certificate[];
  invoices: TuitionInvoice[];
  timetableCount?: number;
  inquiriesCount?: number;
  pendingUsersCount?: number;
  onNavigateTab: (tab: string) => void;
  language: Language;
  currentUser?: CurrentUser;
  assistants: AssistantAdmin[];
  onAddAssistant: (assistant: AssistantAdmin) => Promise<any> | any;
  onDeleteAssistant: (id: string) => Promise<any> | any;
  onToggleAssistantActive: (id: string) => Promise<any> | any;
  onCreateBackup: () => void;
  onRestoreBackup: (jsonContent: string) => void;
  auditLogs: SystemAuditLog[];
  onDeleteAuditLog?: (id: string) => Promise<any> | any;
  onClearAuditLogs?: () => Promise<any> | any;
  onDeleteLessonRating?: (id: string) => Promise<any> | any;
  onRefreshDashboard?: () => Promise<void>;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  students,
  teachers,
  lessons,
  lessonRatings = [],
  quizzes,
  quizAttempts = [],
  certificates,
  invoices,
  timetableCount = 0,
  inquiriesCount = 0,
  pendingUsersCount = 0,
  onNavigateTab,
  language,
  currentUser,
  assistants,
  onAddAssistant,
  onDeleteAssistant,
  onToggleAssistantActive,
  onCreateBackup,
  onRestoreBackup,
  auditLogs,
  onDeleteAuditLog,
  onClearAuditLogs,
  onDeleteLessonRating,
  onRefreshDashboard,
}) => {
  const isAr = language === 'ar';

  const onlineStudentsCount = students.filter((s) => s.type === 'online').length;
  const offlineStudentsCount = students.filter((s) => s.type === 'offline').length;
  const weakCount = students.filter((s) => s.status === 'weak' || s.overallScore < 60).length;
  const topCount = students.filter((s) => s.status === 'top' || s.overallScore >= 90).length;

  const totalScore = students.reduce((acc, s) => acc + Number(s.overallScore || 0), 0);
  const avgAcademyScore = students.length ? Math.round(totalScore / students.length) : 0;

  const avgExamAttemptScore = useMemo(() => {
    if (quizAttempts.length === 0) return null;
    const sum = quizAttempts.reduce((acc, a) => acc + Number(a.percentage || 0), 0);
    return Math.round(sum / quizAttempts.length);
  }, [quizAttempts]);

  const paidInvoicesTotal = useMemo(
    () =>
      invoices
        .filter((inv) => inv.status === 'paid')
        .reduce((sum, inv) => sum + Number(inv.amount || 0), 0),
    [invoices]
  );

  const videoLessons = lessons.filter((l) => l.format === 'video').length;
  const infographicLessons = lessons.filter((l) => l.format === 'infographic').length;
  const docLessons = lessons.filter((l) => l.format !== 'video' && l.format !== 'infographic').length;

  // Dynamic grade performance distribution strictly from real DB students & quizAttempts
  const gradeDistribution = useMemo(() => {
    if (students.length === 0) return [];
    const grouped = new Map<
      string,
      { grade: string; scoreSum: number; attSum: number; count: number; attemptsCount: number }
    >();

    for (const s of students) {
      const g = (s.grade || (isAr ? 'غير محدد' : 'Unassigned')).trim();
      const existing = grouped.get(g) || { grade: g, scoreSum: 0, attSum: 0, count: 0, attemptsCount: 0 };
      existing.scoreSum += Number(s.overallScore || 0);
      existing.attSum += Number(s.attendanceRate || 0);
      existing.count += 1;
      grouped.set(g, existing);
    }

    for (const att of quizAttempts) {
      const g = (att.grade || '').trim();
      if (g && grouped.has(g)) {
        grouped.get(g)!.attemptsCount += 1;
      }
    }

    return Array.from(grouped.values()).map((item) => ({
      grade: item.grade,
      avgScore: Math.round(item.scoreSum / item.count),
      attendance: Math.round(item.attSum / item.count),
      studentsCount: item.count,
      attemptsCount: item.attemptsCount,
    }));
  }, [students, quizAttempts, isAr]);

  // Modals & UI feedback state
  const [isAssistantModalOpen, setIsAssistantModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [deletingAssistant, setDeletingAssistant] = useState<AssistantAdmin | null>(null);
  const [isClearLogsConfirmOpen, setIsClearLogsConfirmOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Early-Warning At-Risk Student Radar State
  const [atRiskAlerts, setAtRiskAlerts] = useState<AtRiskStudentAlert[]>([]);
  const [loadingRadar, setLoadingRadar] = useState(false);
  const [notifyingStudentId, setNotifyingStudentId] = useState<string | null>(null);
  const [notifiedStudentIds, setNotifiedStudentIds] = useState<string[]>([]);

  // Financial Revenue & Teacher Splits State
  const [revenueSummary, setRevenueSummary] = useState<{
    totalCodesRevenue: number;
    totalInvoicesPaidRevenue: number;
    totalGrossRevenue: number;
    totalTeacherShares: number;
    platformNetTotal: number;
    totalPendingInvoicesAmount: number;
    redeemedCodesCount: number;
    paidInvoicesCount: number;
  } | null>(null);
  const [revenueBreakdown, setRevenueBreakdown] = useState<TeacherRevenueBreakdownItem[]>([]);
  const [splitEdits, setSplitEdits] = useState<Record<string, number>>({});
  const [savingSplitId, setSavingSplitId] = useState<string | null>(null);
  const [loadingFinance, setLoadingFinance] = useState(false);

  const loadAnalyticsAndFinance = async () => {
    const headers = getAuthHeaders(currentUser, teachers);
    setLoadingRadar(true);
    setLoadingFinance(true);
    try {
      const [radarRes, finRes] = await Promise.all([
        fetch('/api/analytics/at-risk-students', { headers }),
        fetch('/api/finance/revenue-analytics', { headers }),
      ]);
      if (radarRes.ok) {
        const radarData = await radarRes.json();
        setAtRiskAlerts(Array.isArray(radarData.alerts) ? radarData.alerts : []);
      }
      if (finRes.ok) {
        const finData = await finRes.json();
        setRevenueSummary(finData.summary || null);
        const list: TeacherRevenueBreakdownItem[] = Array.isArray(finData.breakdown) ? finData.breakdown : [];
        setRevenueBreakdown(list);
        const map: Record<string, number> = {};
        list.forEach((b) => {
          map[b.teacherId] = b.sharePercent;
        });
        setSplitEdits(map);
      }
    } catch {
      // ignore transient network errors
    } finally {
      setLoadingRadar(false);
      setLoadingFinance(false);
    }
  };

  useEffect(() => {
    loadAnalyticsAndFinance();
  }, [currentUser?.id, students.length, teachers.length, invoices.length]);

  // Audit Log Filtering State (Sensitive Operations Tracking)
  const [auditCategoryFilter, setAuditCategoryFilter] = useState<
    'all' | 'sensitive' | 'account_status' | 'permission' | 'deletions' | 'grade'
  >('all');
  const [auditSeverityFilter, setAuditSeverityFilter] = useState<'all' | 'critical' | 'warning' | 'info'>('all');
  const [auditSearch, setAuditSearch] = useState('');

  const isSensitiveAuditEntry = (log: SystemAuditLog) => {
    const t = (log.entityType || '').toLowerCase();
    const a = (log.action || '').toLowerCase();
    return (
      t === 'account_status' ||
      t === 'permission' ||
      t === 'grade' ||
      a.includes('delete') ||
      a.includes('account_') ||
      a.includes('permission') ||
      a.includes('grade') ||
      log.severity === 'critical' ||
      log.severity === 'warning'
    );
  };

  const filteredAuditLogs = useMemo(() => {
    const q = auditSearch.trim().toLowerCase();
    return auditLogs.filter((log) => {
      const t = (log.entityType || '').toLowerCase();
      const a = (log.action || '').toLowerCase();
      if (auditCategoryFilter === 'sensitive' && !isSensitiveAuditEntry(log)) return false;
      if (auditCategoryFilter === 'account_status' && t !== 'account_status' && !a.includes('account_')) return false;
      if (auditCategoryFilter === 'permission' && t !== 'permission' && !a.includes('permission')) return false;
      if (
        auditCategoryFilter === 'deletions' &&
        !a.includes('delete') &&
        !((t === 'lesson' || t === 'quiz') && log.actionAr?.includes('حذف'))
      ) {
        return false;
      }
      if (auditCategoryFilter === 'grade' && t !== 'grade' && !a.includes('grade')) return false;
      if (auditSeverityFilter !== 'all' && log.severity !== auditSeverityFilter) return false;
      if (q) {
        const hay = `${log.actionAr} ${log.entityName} ${log.entityType} ${log.performedBy} ${log.details}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [auditLogs, auditCategoryFilter, auditSeverityFilter, auditSearch]);

  const handleExportAuditLogsCsv = () => {
    const headers = ['ID', 'العملية', 'النوع', 'العنصر', 'اسم المستخدم', 'الوقت', 'الأهمية', 'التفاصيل'];
    const rows = filteredAuditLogs.map((l) => [
      l.id,
      `"${(l.actionAr || '').replace(/"/g, '""')}"`,
      l.entityType || '',
      `"${(l.entityName || '').replace(/"/g, '""')}"`,
      `"${(l.performedBy || '').replace(/"/g, '""')}"`,
      `"${(l.timestamp || '').replace(/"/g, '""')}"`,
      l.severity || 'info',
      `"${(l.details || '').replace(/"/g, '""')}"`,
    ]);
    const csv = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit_logs_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  // Lesson Ratings Quality Analytics
  const lessonQualitySummary = useMemo(() => {
    if (!lessonRatings.length) {
      return {
        avgRating: 0,
        clarityAvg: 0,
        benefitAvg: 0,
        totalVotes: 0,
        topLessons: [] as Array<{ lessonId: string; title: string; subject: string; avg: number; count: number }>,
        needsAttentionCount: 0,
      };
    }
    const avgRating = Number(
      (lessonRatings.reduce((s, r) => s + Number(r.rating || 0), 0) / lessonRatings.length).toFixed(1)
    );
    const clarityAvg = Number(
      (lessonRatings.reduce((s, r) => s + Number(r.clarityRating || r.rating || 0), 0) / lessonRatings.length).toFixed(1)
    );
    const benefitAvg = Number(
      (lessonRatings.reduce((s, r) => s + Number(r.benefitRating || r.rating || 0), 0) / lessonRatings.length).toFixed(1)
    );
    const byLesson = new Map<
      string,
      { lessonId: string; title: string; subject: string; sum: number; count: number }
    >();
    for (const r of lessonRatings) {
      const cur = byLesson.get(r.lessonId) || {
        lessonId: r.lessonId,
        title: r.lessonTitle || r.lessonId,
        subject: r.subject || '',
        sum: 0,
        count: 0,
      };
      cur.sum += Number(r.rating || 0);
      cur.count += 1;
      byLesson.set(r.lessonId, cur);
    }
    const aggregated = Array.from(byLesson.values()).map((x) => ({
      lessonId: x.lessonId,
      title: x.title,
      subject: x.subject,
      avg: Number((x.sum / x.count).toFixed(1)),
      count: x.count,
    }));
    const topLessons = [...aggregated].sort((a, b) => b.avg - a.avg || b.count - a.count).slice(0, 5);
    const needsAttentionCount = aggregated.filter((x) => x.avg < 3.5).length;
    return {
      avgRating,
      clarityAvg,
      benefitAvg,
      totalVotes: lessonRatings.length,
      topLessons,
      needsAttentionCount,
    };
  }, [lessonRatings]);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    setTimeout(() => {
      setToast((prev) => (prev?.text === text ? null : prev));
    }, 4500);
  };

  const handleAlertParentFromRadar = async (alert: AtRiskStudentAlert) => {
    setNotifyingStudentId(alert.studentId);
    try {
      const res = await fetch('/api/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          id: `notif-radar-${Date.now()}`,
          title: `تنبيه إنذار مبكر: متابعة مستوى الطالب ${alert.studentName}`,
          message: `نحيط سيادتكم بمؤشرات تستدعي المتابعة للطالب (${alert.studentName} - ${alert.grade}): ${alert.reasons.join(' • ')}. نسبة الحضور: ${alert.attendanceRate}%، المعدل العام: ${alert.overallScore}%.`,
          target: 'parents',
          category: 'academic',
          createdAt: new Date().toLocaleString('ar-EG'),
          read: false,
          relatedType: 'student',
          relatedId: alert.studentId,
        }),
      });
      if (!res.ok) throw new Error('تعذر إرسال التنبيه');
      setNotifiedStudentIds((prev) => Array.from(new Set([...prev, alert.studentId])));
      showToast('success', `تم إرسال تنبيه فوري لولي أمر الطالب (${alert.studentName}) وحفظه في المنظومة ✓`);
    } catch (err: any) {
      showToast('error', err.message || 'تعذر إرسال التنبيه');
    } finally {
      setNotifyingStudentId(null);
    }
  };

  const handleSaveTeacherSplit = async (teacherId: string) => {
    const sharePercent = Number(splitEdits[teacherId] ?? 70);
    setSavingSplitId(teacherId);
    try {
      const res = await fetch('/api/finance/teacher-splits', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({ teacherId, sharePercent }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تحديث النسبة');
      await loadAnalyticsAndFinance();
      showToast('success', `تم تحديث نسبة توزيع أرباح المعلم إلى ${sharePercent}% وإعادة احتساب الصافي ✓`);
    } catch (err: any) {
      showToast('error', err.message || 'تعذر حفظ نسبة المعلم');
    } finally {
      setSavingSplitId(null);
    }
  };

  // New Assistant Form State
  const [asstName, setAsstName] = useState('');
  const [asstUsername, setAsstUsername] = useState('');
  const [asstPassword, setAsstPassword] = useState('');
  const [asstEmail, setAsstEmail] = useState('');
  const [asstPhone, setAsstPhone] = useState('');
  const [asstRoleTitle, setAsstRoleTitle] = useState('مساعد إدارة وشؤون المتابعة');
  const [asstPermissions, setAsstPermissions] = useState<string[]>([
    'manage_lessons',
    'manage_students',
  ]);

  const availablePermissions: { id: string; labelAr: string; labelEn: string; desc: string }[] = [
    {
      id: 'manage_lessons',
      labelAr: 'إدارة وتحرير الدروس والانفوجرافيك',
      labelEn: 'Manage Lessons & Infographics',
      desc: 'إضافة وتعديل وحذف الدروس بالفيديو، الدروس المكتوبة، وتصميم الانفوجرافيك',
    },
    {
      id: 'manage_teachers',
      labelAr: 'إدارة شؤون المعلمين وهيئة التدريس',
      labelEn: 'Manage Teachers Directory',
      desc: 'إضافة المعلمين، تعديل التخصصات، ومتابعة التقييمات والحصص',
    },
    {
      id: 'manage_students',
      labelAr: 'إدارة شؤون الطلاب (أونلاين وسنتر)',
      labelEn: 'Manage Students & Enrollment',
      desc: 'تسجيل الطلاب، متابعة الحضور والغياب، وتحديث الدرجات الدورية',
    },
    {
      id: 'manage_quizzes',
      labelAr: 'إدارة بنك الاختبارات ومناهج PDF',
      labelEn: 'Manage Quizzes & PDF Curricula',
      desc: 'استخراج الأسئلة عشوائياً، نشر الاختبارات الدورية، وتعديل نماذج الإجابات',
    },
    {
      id: 'manage_certificates',
      labelAr: 'إصدار شهادات التقدير والدرجات',
      labelEn: 'Issue Certificates',
      desc: 'إصدار وتوثيق شهادات التفوق بختم الأكاديمية الذهبي',
    },
    {
      id: 'manage_finances',
      labelAr: 'الاطلاع على الاشتراكات والرسوم الدراسية',
      labelEn: 'Tuition & Payment Records',
      desc: 'مراجعة فواتير السداد ومدفوعات مدى وأبل باي والتحصيل النقدي',
    },
    {
      id: 'manage_triage',
      labelAr: 'متابعة الجرد الأسبوعي للضعاف والفائقين',
      labelEn: 'Weekly Triage Management',
      desc: 'فرز مستويات الطلاب وإرسال الإشعارات التلقائية لأولياء الأمور',
    },
    {
      id: 'manage_whiteboard',
      labelAr: 'إدارة جلسات البث المباشر للسبورة التفاعلية',
      labelEn: 'Live Whiteboard Sessions',
      desc: 'جدولة البثوث التفاعلية والمشاركة في إدارة الحصص المباشرة',
    },
  ];

  const handleTogglePermission = (permId: string) => {
    setAsstPermissions((prev) =>
      prev.includes(permId) ? prev.filter((p) => p !== permId) : [...prev, permId]
    );
  };

  const handleSyncDashboard = async () => {
    if (!onRefreshDashboard) return;
    setIsRefreshing(true);
    try {
      await onRefreshDashboard();
      showToast('success', isAr ? 'تمت مزامنة كافة إحصائيات لوحة القيادة من قاعدة البيانات' : 'Dashboard synced from DB');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر تحديث البيانات' : 'Sync failed'));
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleSaveAssistant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!asstName.trim() || !asstUsername.trim()) return;
    setIsSubmitting(true);
    try {
      await onAddAssistant({
        id: `asst-${Date.now()}`,
        name: asstName.trim(),
        nameEn: asstName.trim(),
        username: asstUsername.trim(),
        password: asstPassword.trim() || '123456',
        email: asstEmail.trim() || `${asstUsername.trim()}@nawabegh.edu`,
        phone: asstPhone.trim() || '',
        roleTitle: asstRoleTitle.trim() || 'مساعد إداري',
        permissions: asstPermissions,
        createdAt: new Date().toISOString().split('T')[0],
        isActive: true,
      });

      setAsstName('');
      setAsstUsername('');
      setAsstPassword('');
      setAsstEmail('');
      setAsstPhone('');
      setIsAssistantModalOpen(false);
      showToast('success', isAr ? 'تم حفظ المساعد الإداري وتفعيل صلاحياته في قاعدة البيانات' : 'Assistant saved to DB');

      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حفظ المساعد في قاعدة البيانات' : 'Save failed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDeleteAssistant = async () => {
    if (!deletingAssistant) return;
    setIsSubmitting(true);
    try {
      await onDeleteAssistant(deletingAssistant.id);
      setDeletingAssistant(null);
      showToast('success', isAr ? 'تم حذف حساب المساعد من قاعدة البيانات' : 'Assistant removed from DB');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حذف المساعد' : 'Delete failed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleAssistant = async (id: string) => {
    try {
      await onToggleAssistantActive(id);
      showToast('success', isAr ? 'تم تحديث حالة تفعيل المساعد في قاعدة البيانات' : 'Assistant status updated');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر تحديث الحالة' : 'Toggle failed'));
    }
  };

  const handleConfirmClearAuditLogs = async () => {
    if (!onClearAuditLogs) return;
    setIsSubmitting(true);
    try {
      await onClearAuditLogs();
      setIsClearLogsConfirmOpen(false);
      showToast('success', isAr ? 'تم تفريغ سجل الرقابة من قاعدة البيانات' : 'Audit logs cleared');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر مسح سجل الرقابة' : 'Clear failed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        onRestoreBackup(content);
        setIsBackupModalOpen(false);
        showToast(
          'success',
          isAr
            ? `تمت قراءة واستعادة ملف النسخة الاحتياطية (${file.name}) بنجاح!`
            : `System backup (${file.name}) successfully restored!`
        );
      }
    };
    reader.readAsText(file);
  };

  const adminDisplayName = currentUser?.name || (isAr ? 'المدير العام للمنصة' : 'Super Admin');
  const adminIdentifier = currentUser?.username || currentUser?.email || 'admin';

  return (
    <div className="space-y-6 font-cairo">
      {/* Executive Identity & Live DB Ribbon */}
      <div className="p-5 md:p-6 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-800 text-white shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-bold text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-950" />
              <span>
                {isAr ? `المدير العام للنظام: ${adminDisplayName}` : `Executive Admin: ${adminDisplayName}`}
              </span>
            </div>

            <h2 className="text-xl md:text-2xl font-black leading-snug">
              {isAr
                ? 'لوحة القيادة الإدارية والتحكم الشامل للمدير العام'
                : 'Executive Administration & Live Database Hub'}
            </h2>

            <p className="text-xs md:text-sm text-emerald-100/90 font-tajawal leading-relaxed">
              {isAr
                ? 'كافة الأرقام ومؤشرات الأداء وسجلات الرقابة والمساعدين في هذه اللوحة تُجلب وتُحسب مباشرة من قاعدة البيانات الفعلية بدون أي بيانات وهمية.'
                : 'All metrics, performance analytics, audit logs, and assistants here are computed directly from the live database.'}
            </p>

            {/* Logged-in Admin Session Info (No hardcoded secrets) */}
            <div className="inline-flex flex-wrap items-center gap-3 pt-1 text-[11px] font-mono-numbers text-amber-300 bg-black/40 px-3 py-1.5 rounded-xl border border-white/10">
              <span><strong>الحساب:</strong> {adminIdentifier}</span>
              <span className="text-white/40">|</span>
              <span className="text-emerald-300">✓ متصل بقاعدة البيانات المباشرة</span>
            </div>
          </div>

          {/* Executive Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {onRefreshDashboard && (
              <button
                onClick={handleSyncDashboard}
                disabled={isRefreshing}
                className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs md:text-sm bg-emerald-800/80 hover:bg-emerald-700 text-white border border-emerald-600/50 transition-all cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>{isAr ? 'تحديث من الداتا بيز' : 'Sync DB'}</span>
              </button>
            )}

            <button
              onClick={() => onNavigateTab('members')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm bg-amber-400 hover:bg-amber-300 text-slate-950 transition-all shadow-md transform hover:-translate-y-0.5 cursor-pointer"
            >
              <UserPlus className="w-4 h-4 text-slate-950" />
              <span>{isAr ? 'الأعضاء وتفعيل الحسابات' : 'Members & Activation'}</span>
              {pendingUsersCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-black font-mono-numbers">
                  {pendingUsersCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onNavigateTab('backups')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all backdrop-blur-xs cursor-pointer"
            >
              <Database className="w-4 h-4 text-emerald-300" />
              <span>{isAr ? 'النسخ الاحتياطي وتصدير SQL' : 'Backups & SQL Export'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Live Toast Feedback Banner */}
      {toast && (
        <div
          className={`p-3.5 rounded-xl border text-xs md:text-sm flex items-center justify-between gap-3 shadow-sm font-cairo font-bold ${
            toast.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/80 border-rose-300 dark:border-rose-700 text-rose-900 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            )}
            <span>{toast.text}</span>
          </div>
          <button onClick={() => setToast(null)} className="p-1 opacity-75 hover:opacity-100 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Primary KPI Grid (100% real DB records) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono-numbers">
        {/* KPI 1: Students */}
        <div
          onClick={() => onNavigateTab('students')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-sans">
              {isAr ? 'إجمالي الطلاب المسجلين' : 'Registered Students'}
            </span>
            <GraduationCap className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex flex-wrap items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              {students.length}
            </span>
            <span className="text-[11px] text-slate-400 font-sans">
              {onlineStudentsCount} {isAr ? 'أونلاين' : 'online'} · {offlineStudentsCount} {isAr ? 'سنتر' : 'center'}
            </span>
          </div>
        </div>

        {/* KPI 2: Academy Average Score */}
        <div
          onClick={() => onNavigateTab('quizzes')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-sans">
              {isAr ? 'المعدل العام للأكاديمية' : 'Academy Avg Score'}
            </span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex flex-col gap-0.5">
            <span className="text-2xl md:text-3xl font-black text-emerald-600 dark:text-emerald-400">
              {students.length > 0 ? `${avgAcademyScore}%` : avgExamAttemptScore !== null ? `${avgExamAttemptScore}%` : '0%'}
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-sans">
              {quizAttempts.length > 0
                ? isAr
                  ? `من ${quizAttempts.length} نتيجة اختبار مسجلة`
                  : `From ${quizAttempts.length} recorded attempts`
                : students.length > 0
                ? isAr
                  ? `محسوب من ${students.length} طالب في الداتا بيز`
                  : `Computed from ${students.length} students`
                : isAr
                ? 'لا توجد درجات مسجلة بعد'
                : 'No grades recorded yet'}
            </span>
          </div>
        </div>

        {/* KPI 3: Weekly Triage Breakdown */}
        <div
          onClick={() => onNavigateTab('triage')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-sans">
              {isAr ? 'جرد المستويات من الداتا بيز' : 'Students Triage'}
            </span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-center gap-3">
            <div className="flex items-center gap-1 text-amber-600 font-black text-xl">
              <span>{topCount}</span>
              <span className="text-[11px] font-sans font-bold">{isAr ? 'فائقين' : 'honors'}</span>
            </div>
            <span className="text-slate-300">/</span>
            <div className="flex items-center gap-1 text-rose-600 font-black text-xl">
              <span>{weakCount}</span>
              <span className="text-[11px] font-sans font-bold">{isAr ? 'متابعة' : 'support'}</span>
            </div>
          </div>
        </div>

        {/* KPI 4: Lessons & Infographics */}
        <div
          onClick={() => onNavigateTab('lessons')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 transition-all cursor-pointer shadow-xs"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-sans">
              {isAr ? 'المحتوى والدروس المرفوعة' : 'Uploaded Lessons'}
            </span>
            <BookOpen className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 flex flex-wrap items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              {lessons.length}
            </span>
            <span className="text-[11px] text-slate-400 font-sans">
              {infographicLessons} {isAr ? 'انفوجرافيك' : 'info'} · {videoLessons} {isAr ? 'فيديو' : 'video'} · {docLessons} {isAr ? 'مستند' : 'doc'}
            </span>
          </div>
        </div>
      </div>

      {/* Real Database Module Totals Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-cairo">
        <button
          onClick={() => onNavigateTab('teachers')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 text-right transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isAr ? 'المعلمون' : 'Teachers'}</span>
            <Users className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1 font-mono">{teachers.length}</p>
        </button>

        <button
          onClick={() => onNavigateTab('quizzes')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 text-right transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isAr ? 'الاختبارات' : 'Quizzes'}</span>
            <FileCheck2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1 font-mono">{quizzes.length}</p>
        </button>

        <button
          onClick={() => onNavigateTab('certificates')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 text-right transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isAr ? 'الشهادات' : 'Certificates'}</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1 font-mono">{certificates.length}</p>
        </button>

        <button
          onClick={() => onNavigateTab('timetable')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 text-right transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isAr ? 'الحصص المجدولة' : 'Schedule'}</span>
            <Calendar className="w-4 h-4 text-sky-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1 font-mono">{timetableCount}</p>
        </button>

        <button
          onClick={() => onNavigateTab('faqs')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 text-right transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isAr ? 'الاستفسارات' : 'Inquiries'}</span>
            <MessageSquare className="w-4 h-4 text-violet-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1 font-mono">{inquiriesCount}</p>
        </button>

        <button
          onClick={() => onNavigateTab('payments')}
          className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 text-right transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isAr ? 'المحصّل المالي' : 'Paid Revenue'}</span>
            <CreditCard className="w-4 h-4 text-teal-500" />
          </div>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-1 font-mono">
            {paidInvoicesTotal.toLocaleString()} <span className="text-[10px] font-sans text-slate-400">ر.س</span>
          </p>
        </button>
      </div>

      {/* Super Admin Assistants & RBAC Section (Backed by Cloud SQL users table) */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 flex items-center justify-center font-bold">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm md:text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'مساعدو المدير العام وصلاحياتهم من قاعدة البيانات' : 'Assistant Admins & RBAC (Database)'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? 'يتم حفظ جميع المساعدين والمشرفين وصلاحياتهم مباشرة في جدول الأعضاء بقاعدة البيانات'
                  : 'All appointed assistants and permissions are persisted directly in the database'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAssistantModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>{isAr ? 'تعيين مساعد جديد' : 'Add New Assistant'}</span>
          </button>
        </div>

        {assistants.length === 0 ? (
          <div className="p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
            <Shield className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto" />
            <p className="text-xs md:text-sm font-bold text-slate-600 dark:text-slate-300">
              {isAr
                ? 'لا يوجد مساعدون أو مشرفون معيّنون في قاعدة البيانات حالياً'
                : 'No assistants or supervisors assigned in the database yet'}
            </p>
            <p className="text-[11px] text-slate-400 font-tajawal">
              {isAr
                ? 'استخدم زر "تعيين مساعد جديد" أو انتقل إلى إدارة الأعضاء لإضافة مساعدين فعليين'
                : 'Use "Add New Assistant" to create a real database account'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {assistants.map((asst) => (
              <div
                key={asst.id}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{asst.name}</h4>
                      <span className="text-xs text-slate-500 font-tajawal block">{asst.roleTitle}</span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        asst.isActive
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {asst.isActive ? (isAr ? 'نشط' : 'Active') : isAr ? 'معطل' : 'Disabled'}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-500 font-mono-numbers space-y-0.5">
                    <p>
                      اسم المستخدم: <strong>{asst.username}</strong>
                      {asst.phone ? ` · هاتف: ${asst.phone}` : ''}
                    </p>
                    <p>البريد: {asst.email}</p>
                  </div>

                  {/* Permissions Tags */}
                  <div className="mt-3">
                    <span className="text-[10px] text-slate-400 font-bold block mb-1">
                      {isAr ? 'الصلاحيات الممنوحة:' : 'Granted Permissions:'}
                    </span>
                    {asst.permissions.length === 0 ? (
                      <span className="text-[11px] text-slate-400 font-tajawal">
                        {isAr ? 'لم تُحدد صلاحيات تفصيلية بعد' : 'No specific permissions'}
                      </span>
                    ) : (
                      <div className="flex flex-wrap gap-1">
                        {asst.permissions.map((p) => {
                          const permObj = availablePermissions.find((x) => x.id === p);
                          return (
                            <span
                              key={p}
                              className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[10px] font-bold text-slate-700 dark:text-slate-200 font-tajawal"
                            >
                              ✓ {permObj ? (isAr ? permObj.labelAr : permObj.labelEn) : p}
                            </span>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs font-tajawal">
                  <button
                    onClick={() => handleToggleAssistant(asst.id)}
                    className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer"
                  >
                    {asst.isActive ? (isAr ? 'تعطيل الحساب مؤقتاً' : 'Disable') : isAr ? 'تفعيل الحساب' : 'Enable'}
                  </button>

                  <button
                    onClick={() => setDeletingAssistant(asst)}
                    className="text-rose-600 hover:underline font-bold cursor-pointer"
                  >
                    {isAr ? 'إلغاء التعيين' : 'Remove'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Real-time Super Admin Sensitive Audit Log (Backed by Cloud SQL audit_logs table) */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 font-tajawal">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold font-cairo text-sm md:text-base text-slate-900 dark:text-white flex items-center gap-2">
                <span>{isAr ? 'سجل مراجعة المدير العام (تتبع العمليات الحساسة)' : 'Super Admin Sensitive Audit Log'}</span>
              </h3>
              <p className="text-xs text-slate-500">
                {isAr
                  ? 'تتبع دقيق لتفعيل/إيقاف الحسابات، تغيير الصلاحيات، حذف الدروس أو الاختبارات، وتعديل الدرجات مع الوقت واسم المستخدم'
                  : 'Tracks account activations, permission changes, lesson/quiz deletions, and grade edits with user and timestamp'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono-numbers font-bold text-slate-600 dark:text-slate-300">
              {filteredAuditLogs.length} / {auditLogs.length} {isAr ? 'سجل' : 'logs'}
            </span>
            {filteredAuditLogs.length > 0 && (
              <button
                type="button"
                onClick={handleExportAuditLogsCsv}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-xs font-bold font-cairo flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isAr ? 'تصدير CSV' : 'Export CSV'}</span>
              </button>
            )}
            {auditLogs.length > 0 && onClearAuditLogs && (
              <button
                type="button"
                onClick={() => setIsClearLogsConfirmOpen(true)}
                className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 text-xs font-bold font-cairo hover:bg-rose-100 cursor-pointer whitespace-nowrap"
              >
                {isAr ? 'تفريغ السجل' : 'Clear'}
              </button>
            )}
          </div>
        </div>

        {/* Sensitive Operation Filters + Search */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-1.5 font-cairo text-xs">
            {[
              { id: 'all', ar: 'الكل', en: 'All' },
              { id: 'sensitive', ar: 'العمليات الحساسة', en: 'Sensitive Only' },
              { id: 'account_status', ar: 'تفعيل/إيقاف حساب', en: 'Account Status' },
              { id: 'permission', ar: 'تغيير صلاحية', en: 'Permissions' },
              { id: 'deletions', ar: 'حذف درس/اختبار', en: 'Lesson/Quiz Deletes' },
              { id: 'grade', ar: 'تعديل درجة', en: 'Grade Edits' },
            ].map((chip) => (
              <button
                key={chip.id}
                type="button"
                onClick={() => setAuditCategoryFilter(chip.id as any)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  auditCategoryFilter === chip.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {isAr ? chip.ar : chip.en}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={auditSeverityFilter}
              onChange={(e) => setAuditSeverityFilter(e.target.value as any)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              <option value="all">{isAr ? 'كل مستويات الأهمية' : 'All Severities'}</option>
              <option value="critical">{isAr ? 'حرج (حذف / صلاحيات)' : 'Critical'}</option>
              <option value="warning">{isAr ? 'تنبيه (درجات / حسابات)' : 'Warning'}</option>
              <option value="info">{isAr ? 'عام (إضافة / تحديث)' : 'Info'}</option>
            </select>

            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 absolute top-2.5 right-3 text-slate-400" />
              <input
                type="text"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                placeholder={isAr ? 'بحث باسم المستخدم، العملية، العنصر...' : 'Search user, action...'}
                className="w-full pr-8 pl-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {filteredAuditLogs.length === 0 ? (
          <div className="p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/30 text-slate-400 text-xs">
            {auditLogs.length === 0
              ? isAr
                ? 'سجل المراجعة فارغ حالياً — سيُوثق هنا تلقائياً كل تفعيل/إيقاف حساب، حذف درس أو اختبار، تعديل درجة، أو تغيير صلاحية.'
                : 'No audit events recorded yet.'
              : isAr
              ? 'لا توجد سجلات مطابقة لعوامل التصفية المختارة.'
              : 'No matching audit logs found.'}
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {filteredAuditLogs.map((log) => {
              const sevLabel =
                log.severity === 'critical'
                  ? isAr
                    ? 'حرج'
                    : 'Critical'
                  : log.severity === 'warning'
                  ? isAr
                    ? 'حساس'
                    : 'Sensitive'
                  : isAr
                  ? 'معلومة'
                  : 'Info';
              const sevStyle =
                log.severity === 'critical'
                  ? 'border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200'
                  : log.severity === 'warning'
                  ? 'border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300';

              return (
                <div
                  key={log.id}
                  className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 text-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[10px] font-cairo font-bold ${sevStyle}`}>
                        {log.severity === 'critical' && <AlertTriangle className="w-3 h-3" />}
                        <span>{sevLabel}</span>
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white font-cairo">{log.actionAr}</span>
                      {log.entityName && (
                        <>
                          <span className="text-slate-400">·</span>
                          <span className="font-bold text-emerald-800 dark:text-emerald-300">{log.entityName}</span>
                        </>
                      )}
                      <span className="text-[10px] text-slate-400 font-mono-numbers">
                        ({log.entityType})
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">{log.details}</p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-left font-mono-numbers text-[11px] text-slate-500 dark:text-slate-400">
                      <span className="block">{log.timestamp}</span>
                      <span className="font-cairo font-bold text-emerald-700 dark:text-emerald-400">
                        {log.performedBy}
                      </span>
                    </div>
                    {onDeleteAuditLog && (
                      <button
                        type="button"
                        onClick={() => onDeleteAuditLog(log.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                        title={isAr ? 'حذف السجل' : 'Delete log'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Lesson Quality Ratings Analytics Section (استبيانات تقييم الدروس) */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 font-tajawal">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
              <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
            </div>
            <div>
              <h3 className="font-bold font-cairo text-sm md:text-base text-slate-900 dark:text-white">
                {isAr ? 'مؤشرات جودة المحتوى واستبيانات تقييم الدروس' : 'Content Quality & Lesson Ratings'}
              </h3>
              <p className="text-xs text-slate-500">
                {isAr
                  ? 'تقييمات النجوم المباشرة من الطلاب والطالبات لقياس وضوح الشرح والفائدة العلمية للدروس'
                  : 'Direct star surveys submitted by students to help supervisors evaluate content quality'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('lessons')}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs cursor-pointer whitespace-nowrap"
          >
            {isAr ? 'استعراض الدروس ←' : 'Open Lessons →'}
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-numbers">
          <div className="p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-900/50">
            <span className="text-[11px] font-cairo text-slate-500 block">
              {isAr ? 'المتوسط العام للدروس' : 'Overall Avg'}
            </span>
            <p className="text-xl font-black text-amber-600 dark:text-amber-400 mt-0.5">
              ★ {lessonQualitySummary.totalVotes > 0 ? lessonQualitySummary.avgRating : '—'}
              <span className="text-xs font-normal text-slate-400"> / 5</span>
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-[11px] font-cairo text-slate-500 block">
              {isAr ? 'وضوح الشرح' : 'Clarity Avg'}
            </span>
            <p className="text-xl font-black text-emerald-700 dark:text-emerald-400 mt-0.5">
              ★ {lessonQualitySummary.totalVotes > 0 ? lessonQualitySummary.clarityAvg : '—'}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-[11px] font-cairo text-slate-500 block">
              {isAr ? 'الفائدة العلمية' : 'Benefit Avg'}
            </span>
            <p className="text-xl font-black text-blue-700 dark:text-blue-400 mt-0.5">
              ★ {lessonQualitySummary.totalVotes > 0 ? lessonQualitySummary.benefitAvg : '—'}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-[11px] font-cairo text-slate-500 block">
              {isAr ? 'إجمالي الاستبيانات' : 'Total Surveys'}
            </span>
            <p className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
              {lessonQualitySummary.totalVotes}
            </p>
          </div>
        </div>

        {lessonRatings.length === 0 ? (
          <div className="p-6 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400">
            {isAr
              ? 'لا توجد استبيانات تقييم دروس مسجلة بعد — ستظهر هنا تلقائياً فور تقييم الطلاب للدروس.'
              : 'No lesson ratings recorded yet.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                {isAr ? 'أعلى الدروس تقييماً:' : 'Top Rated Lessons:'}
              </h4>
              <div className="space-y-1.5">
                {lessonQualitySummary.topLessons.map((item) => (
                  <div
                    key={item.lessonId}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="font-cairo font-bold text-slate-900 dark:text-white truncate">{item.title}</p>
                      <span className="text-[11px] text-slate-500">{item.subject}</span>
                    </div>
                    <div className="text-left font-mono-numbers shrink-0">
                      <span className="font-black text-amber-600 dark:text-amber-400">★ {item.avg}</span>
                      <span className="text-[10px] text-slate-400 block">
                        {item.count} {isAr ? 'تقييم' : 'votes'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                {isAr ? 'أحدث تعليقات الطلاب:' : 'Recent Student Comments:'}
              </h4>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {lessonRatings.slice(0, 6).map((rev) => (
                  <div
                    key={rev.id}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-cairo font-bold text-slate-900 dark:text-white">{rev.lessonTitle}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-emerald-700 dark:text-emerald-400 font-bold">{rev.studentName}</span>
                        <span className="font-mono-numbers font-bold text-amber-600">★ {rev.rating}</span>
                      </div>
                      {rev.comment && <p className="text-[11px] text-slate-500 mt-0.5">{rev.comment}</p>}
                    </div>
                    {onDeleteLessonRating && (
                      <button
                        type="button"
                        onClick={() => onDeleteLessonRating(rev.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer shrink-0"
                        title={isAr ? 'حذف التقييم' : 'Delete rating'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Grade Performance & Enrollment Channels (100% computed from DB) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {isAr ? 'مؤشرات الأداء والتحصيل حسب الصفوف (من الداتا بيز)' : 'Grade Performance Matrix (Live DB)'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {isAr
                  ? 'يتم حساب متوسط الدرجات ونسب الحضور آلياً من بيانات الطلاب المسجلين'
                  : 'Calculated automatically from registered students and exam records'}
              </p>
            </div>
            <BarChart3 className="w-5 h-5 text-emerald-600" />
          </div>

          {gradeDistribution.length === 0 ? (
            <div className="p-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
              <p className="text-xs md:text-sm font-bold text-slate-600 dark:text-slate-300">
                {isAr ? 'لا توجد بيانات طلاب مسجلة في قاعدة البيانات بعد' : 'No student records in database yet'}
              </p>
              <button
                onClick={() => onNavigateTab('students')}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
              >
                <span>{isAr ? 'إضافة طلاب الآن' : 'Add Students'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3.5 pt-2">
              {gradeDistribution.map((item) => (
                <div
                  key={item.grade}
                  className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-2 font-mono-numbers"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-sans">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 dark:text-slate-200">{item.grade}</span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-500 font-mono">
                        {item.studentsCount} {isAr ? 'طالب' : 'students'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-500 text-xs font-mono-numbers">
                      <span>
                        {isAr ? 'المعدل:' : 'Score:'} <strong className="text-emerald-600">{item.avgScore}%</strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {isAr ? 'الحضور:' : 'Att:'} <strong className="text-teal-600">{item.attendance}%</strong>
                      </span>
                    </div>
                  </div>

                  <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-emerald-600" style={{ width: `${item.avgScore}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Enrollment Channels */}
        <div className="lg:col-span-4 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h4 className="font-bold text-slate-900 dark:text-white text-sm">
            {isAr ? 'توزيع قنوات التعليم (أونلاين / سنتر)' : 'Enrollment Channels'}
          </h4>

          <div className="grid grid-cols-2 gap-3 text-center font-mono-numbers">
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/60">
              <Wifi className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
              <span className="text-xs text-slate-500 font-sans block">{isAr ? 'أونلاين' : 'Online'}</span>
              <span className="text-xl font-black text-emerald-700 dark:text-emerald-300">
                {onlineStudentsCount}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/60">
              <Building2 className="w-5 h-5 text-blue-600 mx-auto mb-1" />
              <span className="text-xs text-slate-500 font-sans block">{isAr ? 'سنتر' : 'Center'}</span>
              <span className="text-xl font-black text-blue-700 dark:text-blue-300">
                {offlineStudentsCount}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-500 font-tajawal leading-relaxed">
            {students.length > 0
              ? isAr
                ? `إجمالي ${students.length} طالب مرتبطين فعلياً بقواعد بيانات الدروس والاختبارات والشهادات.`
                : `${students.length} registered students connected to live lessons, quizzes, and certificates.`
              : isAr
              ? 'ستظهر إحصائيات التوزيع الحقيقية هنا فور تسجيل الطلاب في المنظومة.'
              : 'Live distribution metrics will appear automatically once students are added.'}
          </p>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* EARLY-WARNING AT-RISK STUDENT RADAR (رادار الإنذار المبكر لتراجع الطلاب) */}
      {/* ========================================================================= */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 font-tajawal">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 flex items-center justify-center shrink-0">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold font-cairo text-sm md:text-base text-slate-900 dark:text-white flex items-center gap-2">
                <span>{isAr ? 'رادار الإنذار المبكر لتراجع الطلاب' : 'Early-Warning At-Risk Student Radar'}</span>
                {atRiskAlerts.length > 0 && (
                  <span className="px-2 py-0.5 rounded-lg bg-rose-600 text-white text-[11px] font-mono-numbers">
                    {atRiskAlerts.length}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-500">
                {isAr
                  ? 'رصد ذكي للطلاب المعرضين للتراجع (انخفاض آخر اختبارين، غياب متكرر، أو انقطاع >= 5 أيام) مع تنبيه فوري لولي الأمر'
                  : 'Detects attendance drops, declining scores, or >=5 days inactivity with 1-click parent alert'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={loadAnalyticsAndFinance}
            disabled={loadingRadar}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingRadar ? 'animate-spin' : ''}`} />
            <span>{isAr ? 'تحديث المسح' : 'Scan Now'}</span>
          </button>
        </div>

        {loadingRadar && atRiskAlerts.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 font-cairo">
            {isAr ? 'جاري فحص سجلات الاختبارات والحضور والنشاط...' : 'Scanning student records...'}
          </div>
        ) : atRiskAlerts.length === 0 ? (
          <div className="p-6 text-center rounded-xl border border-dashed border-emerald-200 dark:border-emerald-800 bg-emerald-50/40 dark:bg-emerald-950/20 text-xs text-emerald-800 dark:text-emerald-300 font-cairo font-bold">
            {isAr
              ? '✓ ممتاز! لا توجد مؤشرات تراجع أو انقطاع حرجة لدى الطلاب المسجلين حالياً.'
              : 'All students are on track with no critical risk alerts.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
            {atRiskAlerts.map((alert) => {
              const isSent = notifiedStudentIds.includes(alert.studentId);
              return (
                <div
                  key={alert.studentId}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                          {alert.studentName}{' '}
                          <span className="text-[11px] font-mono-numbers text-slate-500">({alert.studentCode})</span>
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          {alert.grade} · {alert.type === 'online' ? 'أونلاين' : 'سنتر'}
                          {alert.parentName ? ` · ولي الأمر: ${alert.parentName}` : ''}
                        </p>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold shrink-0 ${
                          alert.riskLevel === 'high'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200'
                        }`}
                      >
                        {alert.riskLevel === 'high' ? 'خطر مرتفع' : 'متابعة وقائية'} ({alert.riskScore}%)
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1.5 text-[11px]">
                      {alert.reasons.map((r, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded-lg bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300"
                        >
                          {r}
                        </span>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono-numbers text-slate-600 dark:text-slate-300">
                      <span>الحضور: <strong>{alert.attendanceRate}%</strong></span>
                      <span>·</span>
                      <span>المعدل: <strong>{alert.overallScore}%</strong></span>
                      {alert.lastTwoScores.length > 0 && (
                        <>
                          <span>·</span>
                          <span>آخر اختبارين: <strong>{alert.lastTwoScores.join('% ، ')}%</strong></span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200/70 dark:border-slate-700/70">
                    <span className="text-[11px] text-slate-500 font-mono-numbers">
                      {alert.parentPhone || (isAr ? 'بدون رقم مسجل' : 'No phone')}
                    </span>
                    <button
                      type="button"
                      disabled={notifyingStudentId === alert.studentId || isSent}
                      onClick={() => handleAlertParentFromRadar(alert)}
                      className={`px-3 py-1.5 rounded-xl font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
                        isSent
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-rose-600 hover:bg-rose-700 text-white'
                      }`}
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>
                        {isSent
                          ? isAr
                            ? 'تم إرسال التنبيه ✓'
                            : 'Alert Sent ✓'
                          : notifyingStudentId === alert.studentId
                          ? isAr
                            ? 'جاري الإرسال...'
                            : 'Sending...'
                          : isAr
                          ? 'تنبيه فوري لولي الأمر'
                          : 'Alert Parent Now'}
                      </span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* REVENUE & TEACHER SPLIT ANALYTICS (تقارير الأرباح وتوزيع نسب المعلمين) */}
      {/* ========================================================================= */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 font-tajawal">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold font-cairo text-sm md:text-base text-slate-900 dark:text-white">
                {isAr ? 'تقارير الأرباح وتوزيع نسب المعلمين' : 'Revenue & Teacher Split Analytics'}
              </h3>
              <p className="text-xs text-slate-500">
                {isAr
                  ? 'حساب صافي إيرادات أكواد التفعيل واشتراكات السنتر وتوزيع حصص كل معلم تلقائياً مع إمكانية تعديل النسبة'
                  : 'Calculates activation code & tuition revenues and splits teacher shares dynamically'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('payments')}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs cursor-pointer"
          >
            {isAr ? 'إدارة الفواتير ←' : 'Payments →'}
          </button>
        </div>

        {loadingFinance && !revenueSummary ? (
          <div className="p-6 text-center text-xs text-slate-500 font-cairo">
            {isAr ? 'جاري احتساب الإيرادات وحصص المعلمين...' : 'Calculating financial breakdown...'}
          </div>
        ) : revenueSummary && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-numbers">
              <div className="p-3.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/70 dark:border-emerald-900/50">
                <span className="text-[11px] font-cairo text-slate-500 block">
                  {isAr ? 'إجمالي الإيراد المحصّل' : 'Total Gross'}
                </span>
                <p className="text-lg font-black text-emerald-700 dark:text-emerald-300 mt-0.5">
                  {revenueSummary.totalGrossRevenue.toLocaleString()} <span className="text-xs font-normal">ج.م</span>
                </p>
                <span className="text-[10px] text-slate-500 font-tajawal">
                  أكواد: {revenueSummary.totalCodesRevenue.toLocaleString()} | فواتير: {revenueSummary.totalInvoicesPaidRevenue.toLocaleString()}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/70 dark:border-indigo-900/50">
                <span className="text-[11px] font-cairo text-slate-500 block">
                  {isAr ? 'مستحقات وحصص المعلمين' : 'Teacher Shares'}
                </span>
                <p className="text-lg font-black text-indigo-700 dark:text-indigo-300 mt-0.5">
                  {revenueSummary.totalTeacherShares.toLocaleString()} <span className="text-xs font-normal">ج.م</span>
                </p>
                <span className="text-[10px] text-slate-500 font-tajawal">
                  عدد الأكواد المفعلة: {revenueSummary.redeemedCodesCount}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-900/50">
                <span className="text-[11px] font-cairo text-slate-500 block">
                  {isAr ? 'صافي ربح المنصة' : 'Platform Net'}
                </span>
                <p className="text-lg font-black text-amber-700 dark:text-amber-300 mt-0.5">
                  {revenueSummary.platformNetTotal.toLocaleString()} <span className="text-xs font-normal">ج.م</span>
                </p>
                <span className="text-[10px] text-slate-500 font-tajawal">
                  بعد خصم نسبة المعلمين
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] font-cairo text-slate-500 block">
                  {isAr ? 'فواتير قيد التحصيل' : 'Pending Invoices'}
                </span>
                <p className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                  {revenueSummary.totalPendingInvoicesAmount.toLocaleString()} <span className="text-xs font-normal">ج.م</span>
                </p>
                <span className="text-[10px] text-slate-500 font-tajawal">
                  فواتير مدفوعة: {revenueSummary.paidInvoicesCount}
                </span>
              </div>
            </div>

            {revenueBreakdown.length > 0 && (
              <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 font-cairo text-slate-600 dark:text-slate-300">
                    <tr>
                      <th className="p-3">{isAr ? 'المعلم والتخصص' : 'Teacher'}</th>
                      <th className="p-3">{isAr ? 'الأكواد / الدروس' : 'Codes / Lessons'}</th>
                      <th className="p-3">{isAr ? 'إجمالي المبيعات' : 'Gross'}</th>
                      <th className="p-3">{isAr ? 'نسبة المعلم %' : 'Share %'}</th>
                      <th className="p-3">{isAr ? 'صافي المعلم' : 'Teacher Payout'}</th>
                      <th className="p-3">{isAr ? 'حصة المنصة' : 'Platform Net'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono-numbers">
                    {revenueBreakdown.map((item) => (
                      <tr key={item.teacherId} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/30">
                        <td className="p-3 font-cairo">
                          <p className="font-bold text-slate-900 dark:text-white">{item.teacherName}</p>
                          <span className="text-[11px] text-slate-500">{item.specialty}</span>
                        </td>
                        <td className="p-3 text-slate-600 dark:text-slate-300">
                          {item.codesSoldCount} كود · {item.lessonsCount} درس
                        </td>
                        <td className="p-3 font-bold text-slate-900 dark:text-white">
                          {item.grossRevenue.toLocaleString()} ج.م
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={splitEdits[item.teacherId] ?? item.sharePercent}
                              onChange={(e) =>
                                setSplitEdits((prev) => ({
                                  ...prev,
                                  [item.teacherId]: Math.min(100, Math.max(0, Number(e.target.value) || 0)),
                                }))
                              }
                              className="w-16 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                            />
                            <button
                              type="button"
                              disabled={savingSplitId === item.teacherId}
                              onClick={() => handleSaveTeacherSplit(item.teacherId)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-[11px] cursor-pointer disabled:opacity-50"
                            >
                              {savingSplitId === item.teacherId ? '...' : isAr ? 'حفظ' : 'Save'}
                            </button>
                          </div>
                        </td>
                        <td className="p-3 font-black text-indigo-700 dark:text-indigo-300">
                          {item.teacherShareAmount.toLocaleString()} ج.م
                        </td>
                        <td className="p-3 font-bold text-emerald-700 dark:text-emerald-300">
                          {item.platformNetAmount.toLocaleString()} ج.م
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: ASSIGN ASSISTANT & RBAC PERMISSIONS */}
      {/* ========================================================================= */}
      {isAssistantModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-4 md:p-5 bg-gradient-to-r from-emerald-950 to-teal-950 text-white border-b border-emerald-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                  <UserPlus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base">
                    {isAr ? 'تعيين مساعد جديد وحفظه في قاعدة البيانات' : 'Assign Assistant Admin & RBAC'}
                  </h3>
                  <p className="text-xs text-emerald-200 font-tajawal">
                    {isAr
                      ? 'حدد بيانات الدخول والصلاحيات الدقيقة الممنوحة للمساعد'
                      : 'Configure login credentials and modular access rights'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAssistantModalOpen(false)}
                className="p-1 rounded text-emerald-200 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAssistant} className="p-5 overflow-y-auto space-y-4 text-xs md:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم المساعد *' : 'Assistant Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={asstName}
                    onChange={(e) => setAsstName(e.target.value)}
                    placeholder={isAr ? 'الاسم الكامل' : 'Full name'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم المستخدم للدخول *' : 'Username *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={asstUsername}
                    onChange={(e) => setAsstUsername(e.target.value)}
                    placeholder="assistant_user"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'البريد الإلكتروني' : 'Email'}
                  </label>
                  <input
                    type="email"
                    value={asstEmail}
                    onChange={(e) => setAsstEmail(e.target.value)}
                    placeholder="assistant@domain.com"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'رقم الجوال' : 'Phone'}
                  </label>
                  <input
                    type="text"
                    value={asstPhone}
                    onChange={(e) => setAsstPhone(e.target.value)}
                    placeholder="05xxxxxxxx"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المسمى الإداري' : 'Role Title'}
                  </label>
                  <input
                    type="text"
                    value={asstRoleTitle}
                    onChange={(e) => setAsstRoleTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'كلمة المرور للدخول' : 'Password'}
                  </label>
                  <input
                    type="text"
                    value={asstPassword}
                    onChange={(e) => setAsstPassword(e.target.value)}
                    placeholder="123456"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              {/* Granular Permissions Checkboxes */}
              <div>
                <label className="block font-bold text-slate-800 dark:text-slate-200 mb-2">
                  {isAr ? 'الصلاحيات المحددة للمساعد (RBAC Permissions):' : 'Modular Permissions:'}
                </label>
                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {availablePermissions.map((perm) => {
                    const isChecked = asstPermissions.includes(perm.id);

                    return (
                      <div
                        key={perm.id}
                        onClick={() => handleTogglePermission(perm.id)}
                        className={`p-3 rounded-xl border text-right cursor-pointer transition-all flex items-start justify-between gap-3 ${
                          isChecked
                            ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-100'
                            : 'border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/30 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div>
                          <h5 className="font-bold text-xs">{isAr ? perm.labelAr : perm.labelEn}</h5>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 font-tajawal mt-0.5">{perm.desc}</p>
                        </div>

                        <div
                          className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 ${
                            isChecked
                              ? 'border-emerald-600 bg-emerald-600 text-white'
                              : 'border-slate-300 dark:border-slate-600'
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAssistantModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm cursor-pointer disabled:opacity-60"
                >
                  {isAr ? 'حفظ وتعيين المساعد' : 'Confirm Assignment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: CONFIRM DELETE ASSISTANT */}
      {/* ========================================================================= */}
      {deletingAssistant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد إلغاء تعيين المساعد' : 'Remove Assistant'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? `هل أنت متأكد من حذف حساب المساعد "${deletingAssistant.name}" من قاعدة البيانات؟`
                  : `Remove "${deletingAssistant.name}" from database?`}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingAssistant(null)}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmDeleteAssistant}
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
              >
                {isAr ? 'نعم، حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CONFIRM CLEAR AUDIT LOGS */}
      {/* ========================================================================= */}
      {isClearLogsConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد تفريغ سجل الرقابة' : 'Clear Audit Logs'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? 'سيتم حذف كافة سجلات الرقابة المسجلة حالياً من قاعدة البيانات.'
                  : 'All recorded audit logs will be cleared from the database.'}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setIsClearLogsConfirmOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmClearAuditLogs}
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
              >
                {isAr ? 'نعم، تفريغ السجل' : 'Clear All'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: BACKUP & RESTORATION */}
      {/* ========================================================================= */}
      {isBackupModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="p-4 md:p-5 bg-gradient-to-r from-emerald-950 to-teal-950 text-white border-b border-emerald-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base">
                    {isAr ? 'النسخ الاحتياطي والاستعادة الشاملة' : 'Backup & Restore'}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setIsBackupModalOpen(false)}
                className="p-1 rounded text-emerald-200 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs md:text-sm font-tajawal">
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-2">
                <div className="flex items-center gap-2">
                  <Download className="w-5 h-5 text-emerald-700 dark:text-emerald-300" />
                  <h4 className="font-bold font-cairo text-sm text-emerald-950 dark:text-emerald-100">
                    {isAr ? 'إنشاء وتنزيل نسخة احتياطية فورية (JSON)' : 'Create & Download JSON Backup'}
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onCreateBackup();
                    setIsBackupModalOpen(false);
                  }}
                  className="mt-2 w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{isAr ? 'تنزيل ملف النسخة الاحتياطية الآن' : 'Download Backup JSON File'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 space-y-2">
                <div className="flex items-center gap-2">
                  <UploadCloud className="w-5 h-5 text-blue-700 dark:text-blue-300" />
                  <h4 className="font-bold font-cairo text-sm text-blue-950 dark:text-blue-100">
                    {isAr ? 'استعادة نسخة احتياطية سابقة من ملف' : 'Restore System from Backup File'}
                  </h4>
                </div>
                <div className="pt-1">
                  <input
                    type="file"
                    accept=".json"
                    id="restore-backup-input"
                    onChange={handleRestoreFile}
                    className="hidden"
                  />
                  <label
                    htmlFor="restore-backup-input"
                    className="w-full py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm text-center"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>{isAr ? 'تصفح واختيار ملف النسخة الاحتياطية' : 'Browse Backup File (.json)'}</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setIsBackupModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 text-white font-bold text-xs cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
