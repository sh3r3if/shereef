import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  Coffee,
  Flame,
  Trophy,
  Plus,
  Trash2,
  CheckCircle2,
  Circle,
  CalendarDays,
  BookOpen,
  Bookmark,
  PlayCircle,
  Search,
  Sparkles,
  Award,
  Clock,
  Check,
  RefreshCw,
  Snowflake,
} from 'lucide-react';
import {
  CurrentUser,
  Language,
  Lesson,
  PersonalStudyPlanItem,
  PomodoroStudySession,
  Student,
  Teacher,
  TimestampedLessonNote,
  WeeklyStudyLeaderboardEntry,
  ExamSprintPlan,
  ExamSprintTask,
  StudentStreakRecord,
} from '../types';
import { getAuthHeaders, isParentRole, isStudentRole, resolveMatchedStudent } from '../utils/rbac';
import { getSafeAvatarUrl, handleImageErrorToTeacherAvatar } from '../utils/avatarFallback';

interface StudentStudyAndPomodoroHubProps {
  students: Student[];
  lessons: Lesson[];
  teachers?: Teacher[];
  currentUser: CurrentUser;
  language: Language;
  onNavigateToLessons?: () => void;
}

const WEEK_DAYS = [
  'السبت',
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
];

const SUBJECT_OPTIONS = [
  'الرياضيات',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'اللغة العربية',
  'اللغة الإنجليزية',
  'الحاسب الآلي',
  'التربية الإسلامية',
];

type TimerPresetKey = 'classic_25_5' | 'deep_50_10' | 'sprint_15_5';

const TIMER_PRESETS: Record<
  TimerPresetKey,
  { label: string; focusMins: number; breakMins: number }
> = {
  classic_25_5: { label: 'بومودورو قياسي (25د تركيز + 5د راحة)', focusMins: 25, breakMins: 5 },
  deep_50_10: { label: 'مذاكرة مكثفة (50د تركيز + 10د راحة)', focusMins: 50, breakMins: 10 },
  sprint_15_5: { label: 'مراجعة سريعة (15د تركيز + 5د راحة)', focusMins: 15, breakMins: 5 },
};

export const StudentStudyAndPomodoroHub: React.FC<StudentStudyAndPomodoroHubProps> = ({
  students,
  lessons,
  teachers = [],
  currentUser,
  language,
  onNavigateToLessons,
}) => {
  const isAr = language === 'ar';
  const isStudent = isStudentRole(currentUser.role);
  const isParent = isParentRole(currentUser.role);

  const matchedStudent = useMemo(
    () => resolveMatchedStudent(currentUser, students),
    [currentUser, students]
  );

  const activeStudentKey = String(
    matchedStudent?.id || currentUser.studentId || currentUser.id || 'guest'
  ).trim();
  const activeStudentCode = matchedStudent?.code || currentUser.studentId || currentUser.username || '';
  const activeStudentName = matchedStudent?.name || currentUser.name;

  // Hub State from PostgreSQL
  const [plans, setPlans] = useState<PersonalStudyPlanItem[]>([]);
  const [sessions, setSessions] = useState<PomodoroStudySession[]>([]);
  const [notes, setNotes] = useState<TimestampedLessonNote[]>([]);
  const [leaderboard, setLeaderboard] = useState<WeeklyStudyLeaderboardEntry[]>([]);
  const [myWeeklyMinutes, setMyWeeklyMinutes] = useState<number>(0);
  const [myWeeklyHours, setMyWeeklyHours] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Pomodoro Timer State
  const [preset, setPreset] = useState<TimerPresetKey>('classic_25_5');
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [secondsLeft, setSecondsLeft] = useState<number>(25 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [selectedSubject, setSelectedSubject] = useState<string>(SUBJECT_OPTIONS[0]);
  const [selectedLessonId, setSelectedLessonId] = useState<string>('');
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [isLoggingSession, setIsLoggingSession] = useState<boolean>(false);

  // Personal Study Schedule Form State
  const [planDay, setPlanDay] = useState<string>('السبت');
  const [planTime, setPlanTime] = useState<string>('05:00 م');
  const [planSubject, setPlanSubject] = useState<string>(SUBJECT_OPTIONS[0]);
  const [planTitle, setPlanTitle] = useState<string>('');
  const [planTargetPomodoros, setPlanTargetPomodoros] = useState<number>(2);
  const [isAddingPlan, setIsAddingPlan] = useState<boolean>(false);
  const [selectedDayFilter, setSelectedDayFilter] = useState<string>('all');

  // Notes Search
  const [notesSearch, setNotesSearch] = useState<string>('');

  // 7-Day Exam Sprint State
  const [sprintPlans, setSprintPlans] = useState<ExamSprintPlan[]>([]);
  const [sprintSubject, setSprintSubject] = useState<string>('جميع المواد');
  const [sprintExamDate, setSprintExamDate] = useState<string>(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );
  const [sprintHoursPerDay, setSprintHoursPerDay] = useState<number>(3);
  const [isGeneratingSprint, setIsGeneratingSprint] = useState<boolean>(false);

  const [toast, setToast] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(
    null
  );

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 4000);
  };

  const playChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      [523.25, 659.25, 783.99].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.value = 0.08;
        osc.connect(gain);
        gain.connect(ctx.destination);
        const start = ctx.currentTime + idx * 0.14;
        osc.start(start);
        osc.stop(start + 0.18);
      });
    } catch {
      // ignore Web Audio failure
    }
  };

  const fetchStudyHubState = async () => {
    setIsLoading(true);
    try {
      const query =
        isStudent || isParent
          ? `?studentId=${encodeURIComponent(activeStudentKey)}`
          : '';
      const res = await fetch(`/api/study-hub/state${query}`);
      if (res.ok) {
        const data = await res.json();
        setPlans(Array.isArray(data.plans) ? data.plans : []);
        setSessions(Array.isArray(data.sessions) ? data.sessions : []);
        setNotes(Array.isArray(data.notes) ? data.notes : []);
        setLeaderboard(Array.isArray(data.weeklyLeaderboard) ? data.weeklyLeaderboard : []);
        setMyWeeklyMinutes(Number(data.myWeeklyFocusMinutes || 0));
        setMyWeeklyHours(Number(data.myWeeklyFocusHours || 0));
      }
    } catch (err) {
      console.warn('Study Hub fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchExamSprints = async () => {
    try {
      const qs = activeStudentKey ? `?studentId=${encodeURIComponent(activeStudentKey)}` : '';
      const res = await fetch(`/api/study-hub/exam-sprint${qs}`, {
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        const data = await res.json();
        setSprintPlans(Array.isArray(data.plans) ? data.plans : []);
      }
    } catch {
      // silent
    }
  };

  const [streakRecord, setStreakRecord] = useState<StudentStreakRecord | null>(null);
  const [isUpdatingStreak, setIsUpdatingStreak] = useState(false);

  const fetchStudyStreak = async () => {
    if (!activeStudentKey) return;
    try {
      const res = await fetch(`/api/study-streaks?studentId=${encodeURIComponent(activeStudentKey)}`);
      if (res.ok) {
        const d = await res.json();
        setStreakRecord(d.streak || null);
      }
    } catch {
      // silent
    }
  };

  useEffect(() => {
    fetchStudyHubState();
    fetchExamSprints();
    fetchStudyStreak();
  }, [activeStudentKey]);

  const handleManualStreakCheckin = async () => {
    if (!activeStudentKey || isParent) return;
    setIsUpdatingStreak(true);
    try {
      const res = await fetch('/api/study-streaks/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({ studentId: activeStudentKey, studentName: activeStudentName, points: 15 }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تسجيل الالتزام');
      setStreakRecord(data.streak);
      showToast(`تم تسجيل التزام اليوم! سلسلتك الحالية: ${data.streak?.currentStreak || 1} يوم 🔥`, 'success');
    } catch (err: any) {
      showToast(err.message || 'تعذر التسجيل', 'error');
    } finally {
      setIsUpdatingStreak(false);
    }
  };

  const handleFreezeStreak = async () => {
    if (!activeStudentKey || isParent) return;
    setIsUpdatingStreak(true);
    try {
      const res = await fetch('/api/study-streaks/freeze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({ studentId: activeStudentKey, studentName: activeStudentName }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تجميد السلسلة');
      setStreakRecord(data.streak);
      showToast('تم تفعيل درع تجميد السلسلة لليوم لحماية رصيد أيامك المتتالية ❄️', 'info');
    } catch (err: any) {
      showToast(err.message || 'تعذر التجميد', 'error');
    } finally {
      setIsUpdatingStreak(false);
    }
  };

  const handleGenerateExamSprint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isGeneratingSprint || isParent) return;
    setIsGeneratingSprint(true);
    try {
      const targetDateMs = new Date(sprintExamDate).getTime();
      const nowMs = Date.now();
      const rawDays = Math.max(1, Math.min(7, Math.ceil((targetDateMs - nowMs) / 86400000)));
      const totalDays = Number.isFinite(rawDays) ? rawDays : 7;

      const filteredLessons = lessons.filter((l) =>
        sprintSubject === 'جميع المواد' ? true : l.subject === sprintSubject
      );

      // Fetch quizzes & flashcards optionally for richer tasks
      const [qzRes, fcRes] = await Promise.all([
        fetch('/api/quizzes').catch(() => null),
        fetch('/api/flashcards-competitions').catch(() => null),
      ]);
      const quizzesList: any[] = qzRes && qzRes.ok ? await qzRes.json() : [];
      const fcData: any = fcRes && fcRes.ok ? await fcRes.json() : {};
      const flashcardsList: any[] = Array.isArray(fcData?.flashcards) ? fcData.flashcards : [];

      const relevantQuizzes = quizzesList.filter((q) =>
        sprintSubject === 'جميع المواد' ? true : q.subject === sprintSubject
      );
      const relevantCards = flashcardsList.filter((c) =>
        sprintSubject === 'جميع المواد' ? true : c.subject === sprintSubject
      );

      const tasks: ExamSprintTask[] = [];
      const lessonChunk = Math.max(1, Math.ceil(filteredLessons.length / totalDays));

      for (let day = 1; day <= totalDays; day++) {
        const dayLabel = `اليوم ${day}`;
        const startIdx = (day - 1) * lessonChunk;
        const dayLessons = filteredLessons.slice(startIdx, startIdx + lessonChunk);
        if (dayLessons.length > 0) {
          dayLessons.forEach((l, idx) => {
            tasks.push({
              id: `sp-task-l-${day}-${idx}-${Date.now()}`,
              dayNumber: day,
              dayLabel,
              taskType: 'lesson',
              title: `مذاكرة وتلخيص درس: ${l.title}`,
              subject: l.subject,
              targetId: l.id,
              estimatedMinutes: 40,
              isCompleted: false,
            });
          });
        } else {
          tasks.push({
            id: `sp-task-rev-${day}-${Date.now()}`,
            dayNumber: day,
            dayLabel,
            taskType: 'mistakes_review',
            title:
              day === totalDays
                ? `المراجعة النهائية الشاملة وليلة الامتحان (${sprintSubject})`
                : `مراجعة المفاهيم الأساسية والأخطاء (${sprintSubject})`,
            subject: sprintSubject,
            estimatedMinutes: 45,
            isCompleted: false,
          });
        }

        if (relevantCards.length > 0 || day % 2 === 1) {
          tasks.push({
            id: `sp-task-fc-${day}-${Date.now()}`,
            dayNumber: day,
            dayLabel,
            taskType: 'flashcards',
            title:
              relevantCards.length > 0
                ? `مراجعة ${Math.min(10, relevantCards.length)} بطاقات فلاش كارد (${sprintSubject})`
                : `استرجاع سريع بالمفكرة والبطاقات (${sprintSubject})`,
            subject: sprintSubject,
            estimatedMinutes: 25,
            isCompleted: false,
          });
        }

        const dayQuiz = relevantQuizzes[(day - 1) % Math.max(1, relevantQuizzes.length)];
        tasks.push({
          id: `sp-task-q-${day}-${Date.now()}`,
          dayNumber: day,
          dayLabel,
          taskType: 'quiz',
          title: dayQuiz
            ? `حل اختبار قصير: ${dayQuiz.title}`
            : `تطبيق وحل نموذج اختبار تفاعلي لليوم ${day}`,
          subject: dayQuiz?.subject || sprintSubject,
          targetId: dayQuiz?.id,
          estimatedMinutes: 30,
          isCompleted: false,
        });
      }

      const res = await fetch('/api/study-hub/exam-sprint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          studentId: activeStudentKey,
          studentName: activeStudentName,
          subject: sprintSubject,
          examDate: sprintExamDate,
          dailyHours: sprintHoursPerDay,
          tasks,
        }),
      });
      if (!res.ok) throw new Error('تعذر حفظ خطة المراجعة');
      const data = await res.json();
      if (data.plan) {
        setSprintPlans((prev) => [data.plan, ...prev]);
      } else {
        await fetchExamSprints();
      }
      showToast(`تم توليد وحفظ خطة «سباق الامتحان» لـ ${totalDays} أيام بـ ${tasks.length} مهام مركّزة ✓`, 'success');
    } catch (err: any) {
      showToast(err.message || 'حدث خطأ أثناء توليد الخطة', 'error');
    } finally {
      setIsGeneratingSprint(false);
    }
  };

  const handleToggleSprintTask = async (plan: ExamSprintPlan, taskId: string) => {
    if (isParent) return;
    const targetTask = plan.tasks.find((t) => t.id === taskId);
    const nextCompleted = targetTask ? !targetTask.isCompleted : true;
    const updatedTasks = plan.tasks.map((t) =>
      t.id === taskId ? { ...t, isCompleted: nextCompleted } : t
    );
    setSprintPlans((prev) =>
      prev.map((p) => (p.id === plan.id ? { ...p, tasks: updatedTasks } : p))
    );
    try {
      const res = await fetch(`/api/study-hub/exam-sprint/${plan.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({ taskId, isCompleted: nextCompleted }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.plan) {
          setSprintPlans((prev) => prev.map((p) => (p.id === plan.id ? data.plan : p)));
        }
      }
    } catch {
      fetchExamSprints();
    }
  };

  const handleDeleteSprintPlan = async (planId: string) => {
    if (isParent) return;
    try {
      const res = await fetch(`/api/study-hub/exam-sprint/${planId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setSprintPlans((prev) => prev.filter((p) => p.id !== planId));
        showToast('تم حذف خطة المراجعة من السجل', 'info');
      }
    } catch {
      // silent
    }
  };

  const totalModeSeconds = useMemo(() => {
    const cfg = TIMER_PRESETS[preset];
    return (mode === 'focus' ? cfg.focusMins : cfg.breakMins) * 60;
  }, [preset, mode]);

  const completeSessionRef = useRef<(customMinutes?: number) => void>(() => {});

  const handleLogPomodoroSession = async (customMinutes?: number) => {
    if (isLoggingSession) return;
    setIsLoggingSession(true);
    const cfg = TIMER_PRESETS[preset];
    const defaultMins = mode === 'focus' ? cfg.focusMins : cfg.breakMins;
    const minsToSave =
      typeof customMinutes === 'number' && customMinutes > 0 ? customMinutes : defaultMins;

    const linkedLesson = lessons.find((l) => l.id === selectedLessonId);
    const linkedPlan = plans.find((p) => p.id === selectedPlanId);

    try {
      const res = await fetch('/api/study-hub/pomodoro/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          studentId: activeStudentKey,
          studentCode: activeStudentCode,
          studentName: activeStudentName,
          subject: linkedLesson?.subject || linkedPlan?.subject || selectedSubject,
          lessonId: linkedLesson?.id,
          lessonTitle: linkedLesson?.title,
          taskTitle: linkedPlan?.title,
          planId: linkedPlan?.id,
          durationMinutes: minsToSave,
          mode,
        }),
      });
      if (!res.ok) throw new Error('تعذر حفظ جلسة المذاكرة في قاعدة البيانات');
      playChime();
      await fetchStudyHubState();
      if (mode === 'focus') {
        fetch('/api/study-streaks/checkin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({ studentId: activeStudentKey, studentName: activeStudentName, points: 25 }),
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (d?.streak) setStreakRecord(d.streak);
          })
          .catch(() => {});

        showToast(
          `أحسنت! تم احتساب ${minsToSave} دقيقة مذاكرة فعلية وتحديث لوحة «أكثر الطلاب مذاكرة هذا الأسبوع» ✓`,
          'success'
        );
        // Auto-switch to break after focus
        setMode('break');
        setSecondsLeft(cfg.breakMins * 60);
      } else {
        showToast(`انتهت فترة الراحة (${minsToSave}د) — جاهز لجلسة تركيز جديدة!`, 'info');
        setMode('focus');
        setSecondsLeft(cfg.focusMins * 60);
      }
      setIsRunning(false);
    } catch (err: any) {
      showToast(err.message || 'خطأ في حفظ جلسة البومودورو', 'error');
    } finally {
      setIsLoggingSession(false);
    }
  };

  completeSessionRef.current = handleLogPomodoroSession;

  // Countdown tick
  useEffect(() => {
    if (!isRunning) return;
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(timer);
          setIsRunning(false);
          completeSessionRef.current();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [isRunning]);

  const switchPreset = (nextPreset: TimerPresetKey) => {
    setIsRunning(false);
    setPreset(nextPreset);
    const cfg = TIMER_PRESETS[nextPreset];
    setSecondsLeft((mode === 'focus' ? cfg.focusMins : cfg.breakMins) * 60);
  };

  const switchMode = (nextMode: 'focus' | 'break') => {
    setIsRunning(false);
    setMode(nextMode);
    const cfg = TIMER_PRESETS[preset];
    setSecondsLeft((nextMode === 'focus' ? cfg.focusMins : cfg.breakMins) * 60);
  };

  const handleResetTimer = () => {
    setIsRunning(false);
    setSecondsLeft(totalModeSeconds);
  };

  const handleCompleteEarly = () => {
    const elapsedMins = Math.max(1, Math.round((totalModeSeconds - secondsLeft) / 60));
    handleLogPomodoroSession(elapsedMins);
  };

  const formattedClock = useMemo(() => {
    const m = Math.floor(secondsLeft / 60);
    const s = secondsLeft % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }, [secondsLeft]);

  const ringProgressPct =
    totalModeSeconds > 0
      ? Math.min(100, Math.max(0, ((totalModeSeconds - secondsLeft) / totalModeSeconds) * 100))
      : 0;

  // Personal Study Plan CRUD
  const handleAddStudyPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planTitle.trim()) return;
    setIsAddingPlan(true);
    try {
      const res = await fetch('/api/study-hub/plans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          studentId: activeStudentKey,
          studentName: activeStudentName,
          dayOfWeek: planDay,
          timeSlot: planTime,
          subject: planSubject,
          title: planTitle.trim(),
          targetPomodoros: planTargetPomodoros,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر إضافة المهمة');
      if (data.plan) {
        setPlans((prev) => [data.plan, ...prev]);
      }
      setPlanTitle('');
      showToast('تمت إضافة المهمة لجدول المذاكرة الشخصي ✓', 'success');
    } catch (err: any) {
      showToast(err.message || 'تعذر الحفظ', 'error');
    } finally {
      setIsAddingPlan(false);
    }
  };

  const handleTogglePlanComplete = async (item: PersonalStudyPlanItem) => {
    const nextDone = !item.isCompleted;
    setPlans((prev) =>
      prev.map((p) => (p.id === item.id ? { ...p, isCompleted: nextDone } : p))
    );
    try {
      await fetch(`/api/study-hub/plans/${encodeURIComponent(item.id)}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({ isCompleted: nextDone }),
      });
    } catch {
      // ignore
    }
  };

  const handleDeletePlan = async (id: string) => {
    setPlans((prev) => prev.filter((p) => p.id !== id));
    try {
      await fetch(`/api/study-hub/plans/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
    } catch {
      // ignore
    }
  };

  const handleDeleteNote = async (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    try {
      await fetch(`/api/lesson-notes/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      showToast('تم حذف الملاحظة', 'info');
    } catch {
      // ignore
    }
  };

  const filteredPlans = useMemo(() => {
    return plans.filter((p) => selectedDayFilter === 'all' || p.dayOfWeek === selectedDayFilter);
  }, [plans, selectedDayFilter]);

  const filteredNotes = useMemo(() => {
    const q = notesSearch.trim().toLowerCase();
    if (!q) return notes;
    return notes.filter(
      (n) =>
        n.noteText.toLowerCase().includes(q) ||
        n.lessonTitle.toLowerCase().includes(q) ||
        n.subject.toLowerCase().includes(q)
    );
  }, [notes, notesSearch]);

  const strokeRadius = 86;
  const circumference = 2 * Math.PI * strokeRadius;
  const strokeDashoffset = circumference - (ringProgressPct / 100) * circumference;

  return (
    <div className="space-y-6 font-tajawal animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-5 left-5 z-50 px-4 py-3 rounded-2xl shadow-2xl border text-xs font-cairo font-bold flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-3 ${
            toast.type === 'success'
              ? 'bg-emerald-900 text-white border-emerald-500'
              : toast.type === 'error'
              ? 'bg-rose-900 text-white border-rose-500'
              : 'bg-slate-900 text-white border-indigo-500'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 text-amber-300 shrink-0" />
          <span>{toast.text}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="rounded-3xl bg-gradient-to-l from-indigo-950 via-slate-900 to-emerald-950 text-white p-6 md:p-7 shadow-xl border border-indigo-700/40">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-amber-300 text-[11px] font-cairo font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                {isAr
                  ? 'القسم 5 · تجربة الطالب والمذاكرة الذكية'
                  : 'Student Study Experience & Pomodoro Hub'}
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-black font-cairo text-white">
              {isAr
                ? 'جدول المذاكرة الشخصي ومؤقت بومودورو + مفكرة ملاحظات الفيديو'
                : 'Personal Study Schedule, Pomodoro Timer & Timestamped Notes'}
            </h1>
            <p className="text-xs md:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {isAr
                ? 'نظّم يومك بمؤقت بومودورو (25 دقيقة تركيز + 5 دقائق راحة) ليحسب ساعات المذاكرة الفعلية تلقائياً وينافس في قائمة «أكثر الطلاب مذاكرة هذا الأسبوع»، مع مراجعة كافة ملاحظاتك المرتبطة بدقائق الفيديو.'
                : 'Track real focus hours with a 25/5 Pomodoro timer, manage your weekly study schedule, compete on the weekly leaderboard, and review timestamped video notes.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="px-4 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-center">
              <span className="text-[10px] text-emerald-200 block font-cairo">
                مذاكرتي هذا الأسبوع
              </span>
              <strong className="text-lg font-black font-mono-numbers text-amber-300">
                {myWeeklyHours} ساعة{' '}
                <span className="text-[11px] font-normal text-white/80">
                  ({myWeeklyMinutes}د)
                </span>
              </strong>
            </div>

            <button
              type="button"
              onClick={fetchStudyHubState}
              className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white cursor-pointer"
              title="تحديث من قاعدة البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Daily Study Streak, Rank Progression & Emergency Freeze Card */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-600 flex items-center justify-center shrink-0">
            <Flame className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                {isAr ? 'سلسلة الالتزام اليومي والرتب التحفيزية' : 'Daily Study Streak & Rank'}
              </h3>
              <span className="px-2.5 py-0.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-[11px] font-cairo font-bold">
                {streakRecord?.rankTitle || 'مبتدئ طموح'}
              </span>
            </div>
            <div className="text-xs text-slate-500 font-mono-numbers flex flex-wrap items-center gap-3">
              <span>
                {isAr ? 'السلسلة الحالية:' : 'Current:'}{' '}
                <strong className="text-amber-600 dark:text-amber-400 font-black">
                  {streakRecord?.currentStreak || 0} {isAr ? 'يوم متتالي' : 'days'}
                </strong>
              </span>
              <span>·</span>
              <span>
                {isAr ? 'أطول سلسلة:' : 'Best:'} <strong>{streakRecord?.longestStreak || 0}</strong>
              </span>
              <span>·</span>
              <span>
                {isAr ? 'أوسمة التدرج:' : 'Progression:'}{' '}
                <span className="font-cairo text-slate-600 dark:text-slate-300">
                  مبتدئ ← مثابر (5د) ← متفوق (14د) ← بطل الشريف (30د)
                </span>
              </span>
            </div>
          </div>
        </div>

        {!isParent && (
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={isUpdatingStreak}
              onClick={handleManualStreakCheckin}
              className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isAr ? 'تسجيل مذاكرة اليوم' : 'Check In Today'}</span>
            </button>
            <button
              type="button"
              disabled={isUpdatingStreak || (streakRecord?.freezeTokens ?? 2) <= 0}
              onClick={handleFreezeStreak}
              className="px-3.5 py-2 rounded-xl bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 hover:bg-sky-100 disabled:opacity-50 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Snowflake className="w-4 h-4" />
              <span>
                {isAr
                  ? `تجميد السلسلة ليوم (${streakRecord?.freezeTokens ?? 2} متاح)`
                  : `Freeze Day (${streakRecord?.freezeTokens ?? 2})`}
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Main Grid: Pomodoro Timer (5 cols) + Personal Study Schedule (7 cols) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* ================= POMODORO TIMER CARD ================= */}
        <div className="xl:col-span-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs ${
                  mode === 'focus' ? 'bg-rose-600' : 'bg-emerald-600'
                }`}
              >
                {mode === 'focus' ? <Timer className="w-5 h-5" /> : <Coffee className="w-5 h-5" />}
              </div>
              <div>
                <h2 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                  مؤقت المذاكرة (Pomodoro Timer)
                </h2>
                <p className="text-[11px] text-slate-500">
                  {mode === 'focus'
                    ? 'وضع التركيز الفعلي — يُحتسب في ساعات المذاكرة'
                    : 'استراحة قصيرة لتجديد النشاط'}
                </p>
              </div>
            </div>
          </div>

          {/* Mode Toggle + Preset */}
          <div className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => switchMode('focus')}
                className={`py-2 rounded-xl font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  mode === 'focus'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>جلسة تركيز ({TIMER_PRESETS[preset].focusMins}د)</span>
              </button>
              <button
                type="button"
                onClick={() => switchMode('break')}
                className={`py-2 rounded-xl font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  mode === 'break'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <Coffee className="w-3.5 h-3.5" />
                <span>استراحة ({TIMER_PRESETS[preset].breakMins}د)</span>
              </button>
            </div>

            <select
              value={preset}
              onChange={(e) => switchPreset(e.target.value as TimerPresetKey)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-cairo font-bold"
            >
              {Object.entries(TIMER_PRESETS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v.label}
                </option>
              ))}
            </select>
          </div>

          {/* Circular Progress Countdown */}
          <div className="flex flex-col items-center justify-center py-2">
            <div className="relative w-52 h-52 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 200 200">
                <circle
                  cx="100"
                  cy="100"
                  r={strokeRadius}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="12"
                  className="text-slate-100 dark:text-slate-800"
                />
                <circle
                  cx="100"
                  cy="100"
                  r={strokeRadius}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  className={`transition-all duration-500 ${
                    mode === 'focus' ? 'text-rose-600' : 'text-emerald-500'
                  }`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-black font-mono-numbers text-slate-900 dark:text-white tracking-wider">
                  {formattedClock}
                </span>
                <span className="text-[11px] font-cairo font-bold text-slate-500 mt-1">
                  {mode === 'focus' ? 'تركيز عميق' : 'وقت الراحة'}
                </span>
              </div>
            </div>
          </div>

          {/* Subject & Task Binding */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-500 block mb-1">
                المادة الدراسية
              </label>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-cairo font-bold"
              >
                {SUBJECT_OPTIONS.map((subj) => (
                  <option key={subj} value={subj}>
                    {subj}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-500 block mb-1">
                ربط بدرس (اختياري)
              </label>
              <select
                value={selectedLessonId}
                onChange={(e) => setSelectedLessonId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-cairo"
              >
                <option value="">-- مذاكرة حرة --</option>
                {lessons.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Timer Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setIsRunning((r) => !r)}
              className={`flex-1 py-3 px-4 rounded-2xl font-cairo font-black text-xs text-white flex items-center justify-center gap-2 shadow-md cursor-pointer ${
                isRunning
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : mode === 'focus'
                  ? 'bg-rose-600 hover:bg-rose-700'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              {isRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  <span>إيقاف مؤقت</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>بدء المؤقت</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleResetTimer}
              className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              title="إعادة ضبط"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {!isParent && (
              <button
                type="button"
                disabled={isLoggingSession}
                onClick={handleCompleteEarly}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Check className="w-4 h-4 text-emerald-400" />
                <span>
                  {isLoggingSession
                    ? 'جارِ التوثيق...'
                    : 'إتمام وحفظ الجلسة الآن في سجل ساعات المذاكرة'}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* ================= PERSONAL STUDY SCHEDULE ================= */}
        <div className="xl:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center">
                <CalendarDays className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                  جدول المذاكرة الشخصي ومهامي الأسبوعية
                </h2>
                <p className="text-[11px] text-slate-500">
                  خطط حصص المذاكرة الذاتية واربط كل مهمة بجلسات البومودورو الفعلية
                </p>
              </div>
            </div>

            <select
              value={selectedDayFilter}
              onChange={(e) => setSelectedDayFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-cairo font-bold"
            >
              <option value="all">كل أيام الأسبوع</option>
              {WEEK_DAYS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          {!isParent && (
            <form
              onSubmit={handleAddStudyPlan}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5"
            >
              <select
                value={planDay}
                onChange={(e) => setPlanDay(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-cairo font-bold"
              >
                {WEEK_DAYS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>

              <input
                type="text"
                value={planTime}
                onChange={(e) => setPlanTime(e.target.value)}
                placeholder="الساعة (05:00 م)"
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers"
              />

              <select
                value={planSubject}
                onChange={(e) => setPlanSubject(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-cairo font-bold"
              >
                {SUBJECT_OPTIONS.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>

              <input
                type="text"
                required
                value={planTitle}
                onChange={(e) => setPlanTitle(e.target.value)}
                placeholder="المهمة (مثال: حل 20 مسألة تفاضل)"
                className="sm:col-span-2 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />

              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min={1}
                  max={12}
                  value={planTargetPomodoros}
                  onChange={(e) => setPlanTargetPomodoros(Number(e.target.value) || 1)}
                  title="عدد جلسات البومودورو المستهدفة"
                  className="w-14 px-2 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers text-center"
                />
                <button
                  type="submit"
                  disabled={isAddingPlan}
                  className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة</span>
                </button>
              </div>
            </form>
          )}

          {filteredPlans.length > 0 ? (
            <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-0.5">
              {filteredPlans.map((item) => {
                const isBound = selectedPlanId === item.id;
                return (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-wrap items-center justify-between gap-3 ${
                      item.isCompleted
                        ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800'
                        : isBound
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-300 dark:border-rose-800'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <button
                        type="button"
                        onClick={() => handleTogglePlanComplete(item)}
                        className="text-emerald-600 shrink-0 cursor-pointer"
                        title="تحديد كمكتمل"
                      >
                        {item.isCompleted ? (
                          <CheckCircle2 className="w-5 h-5 fill-emerald-100 text-emerald-600" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-300 hover:text-emerald-500" />
                        )}
                      </button>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="px-2 py-0.5 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-200 text-[10px] font-cairo font-bold">
                            {item.dayOfWeek} · {item.timeSlot}
                          </span>
                          <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-cairo font-bold">
                            {item.subject}
                          </span>
                          <span className="text-[10px] font-mono-numbers text-rose-600 font-bold">
                            🍅 {item.completedPomodoros}/{item.targetPomodoros}
                          </span>
                        </div>
                        <p
                          className={`font-cairo font-bold text-xs md:text-sm mt-1 ${
                            item.isCompleted
                              ? 'line-through text-slate-400'
                              : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {item.title}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {!isParent && !item.isCompleted && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedPlanId(item.id);
                            setSelectedSubject(item.subject);
                            switchMode('focus');
                            setIsRunning(true);
                            showToast(`تم ربط المؤقت بمهمة (${item.title}) وبدء التركيز!`, 'info');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                        >
                          <Play className="w-3 h-3 fill-white" />
                          <span>ابدأ المؤقت</span>
                        </button>
                      )}
                      {!isParent && (
                        <button
                          type="button"
                          onClick={() => handleDeletePlan(item.id)}
                          className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-1">
              <CalendarDays className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-cairo font-bold text-xs text-slate-600 dark:text-slate-300">
                جدول المذاكرة الشخصي فارغ حالياً
              </p>
              <p className="text-[11px] text-slate-400">
                أضف أول مهمة مذاكرة من النموذج أعلاه وابدأ بتشغيل مؤقت بومودورو عليها.
              </p>
            </div>
          )}

          {/* Recent Completed Pomodoro Sessions */}
          {sessions.length > 0 && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <h3 className="text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>أحدث جلسات المذاكرة المسجلة ({sessions.length})</span>
              </h3>
              <div className="flex flex-wrap gap-2">
                {sessions.slice(0, 6).map((sess) => (
                  <span
                    key={sess.id}
                    className="px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-[11px] font-cairo text-emerald-800 dark:text-emerald-200"
                  >
                    {sess.mode === 'focus' ? '🔥' : '☕'} {sess.subject} ({sess.durationMinutes}د)
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Grid: Weekly Top Studiers Leaderboard (6 cols) + All Timestamped Video Notes (6 cols) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* ================= LEADERBOARD: أكثر الطلاب مذاكرة هذا الأسبوع ================= */}
        <div className="xl:col-span-6 bg-white dark:bg-slate-900 rounded-3xl border-2 border-amber-400/40 p-5 md:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-xs">
                <Trophy className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                  قائمة «أكثر الطلاب مذاكرة هذا الأسبوع»
                </h2>
                <p className="text-[11px] text-slate-500">
                  تصنيف أسبوعي مباشر بناءً على دقائق التركيز الموثقة بمؤقت بومودورو
                </p>
              </div>
            </div>
          </div>

          {leaderboard.length > 0 ? (
            <div className="space-y-2.5">
              {leaderboard.map((entry) => (
                <div
                  key={entry.studentId}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                    entry.rank === 1
                      ? 'bg-gradient-to-l from-amber-50 to-yellow-50 dark:from-amber-950/40 dark:to-yellow-950/20 border-amber-300 dark:border-amber-700'
                      : entry.rank === 2
                      ? 'bg-slate-50 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700'
                      : entry.rank === 3
                      ? 'bg-orange-50/60 dark:bg-orange-950/20 border-orange-200 dark:border-orange-800'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center font-mono-numbers font-black text-xs shrink-0 ${
                        entry.rank === 1
                          ? 'bg-amber-400 text-slate-950'
                          : entry.rank === 2
                          ? 'bg-slate-300 text-slate-900'
                          : entry.rank === 3
                          ? 'bg-amber-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      #{entry.rank}
                    </div>

                    <img
                      src={getSafeAvatarUrl(entry.studentAvatar)}
                      alt={entry.studentName}
                      onError={handleImageErrorToTeacherAvatar}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
                    />

                    <div className="min-w-0">
                      <p className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white truncate">
                        {entry.studentName}
                      </p>
                      <p className="text-[11px] text-slate-500 truncate">
                        {entry.studentGrade} · {entry.sessionsCount} جلسة تركيز
                      </p>
                    </div>
                  </div>

                  <div className="text-left shrink-0">
                    <span className="font-mono-numbers font-black text-sm text-emerald-700 dark:text-emerald-400 block">
                      {entry.totalHours} ساعة
                    </span>
                    <span className="text-[10px] font-mono-numbers text-slate-400">
                      ({entry.totalMinutes} دقيقة)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-1.5">
              <Award className="w-8 h-8 text-amber-400 mx-auto" />
              <p className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-200">
                لا توجد جلسات مذاكرة مسجلة هذا الأسبوع بعد
              </p>
              <p className="text-[11px] text-slate-500">
                كن أول من يبدأ مؤقت بومودورو أعلاه ويحتل المركز #1 في قائمة أكثر الطلاب مذاكرة!
              </p>
            </div>
          )}
        </div>

        {/* ================= ALL TIMESTAMPED VIDEO NOTES SUMMARY ================= */}
        <div className="xl:col-span-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 md:p-6 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center">
                <Bookmark className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                  أرشيف مفكرة ملاحظات الفيديو (Timestamped Notes)
                </h2>
                <p className="text-[11px] text-slate-500">
                  كل الملاحظات التي سجلتها مع الدقيقة والثانية أثناء مشاهدة الدروس
                </p>
              </div>
            </div>

            {onNavigateToLessons && (
              <button
                type="button"
                onClick={onNavigateToLessons}
                className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>الذهاب للدروس</span>
              </button>
            )}
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={notesSearch}
              onChange={(e) => setNotesSearch(e.target.value)}
              placeholder="ابحث داخل ملاحظاتك أو باسم الدرس..."
              className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
            />
          </div>

          {filteredNotes.length > 0 ? (
            <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-0.5">
              {filteredNotes.map((note) => (
                <div
                  key={note.id}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-start justify-between gap-2.5"
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded-lg bg-indigo-600 text-white font-mono-numbers font-bold text-[11px] inline-flex items-center gap-1">
                        <PlayCircle className="w-3 h-3" />
                        <span>{note.formattedTime}</span>
                      </span>
                      <span className="font-cairo font-bold text-xs text-slate-800 dark:text-slate-100 truncate">
                        {note.lessonTitle}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-cairo font-bold">
                        {note.subject}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                      {note.noteText}
                    </p>
                  </div>

                  {!isParent && (
                    <button
                      type="button"
                      onClick={() => handleDeleteNote(note.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-1">
              <Bookmark className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-cairo font-bold text-xs text-slate-600 dark:text-slate-300">
                لا توجد ملاحظات فيديو محفوظة بعد
              </p>
              <p className="text-[11px] text-slate-400">
                افتح أي درس فيديو من «الدروس التعليمية» وسجّل ملاحظاتك المرتبطة بدقيقة الشرح.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ================= 7-DAY EXAM SPRINT GENERATOR & CHECKLIST ================= */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/30 p-5 md:p-6 shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center shadow-sm">
              <Flame className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="font-cairo font-black text-base md:text-lg text-slate-900 dark:text-white">
                خطة مراجعة ليلة الامتحان (7-Day Exam Sprint)
              </h2>
              <p className="text-[11px] text-slate-500">
                مولّد خطة مراجعة سريعة يحسب الأيام المتبقية على الامتحان ويوزع الدروس والفلاش كارد والاختبارات القصيرة يومياً
              </p>
            </div>
          </div>
        </div>

        {!isParent && (
          <form
            onSubmit={handleGenerateExamSprint}
            className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end"
          >
            <div>
              <label className="block text-[11px] font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                المادة المستهدفة
              </label>
              <select
                value={sprintSubject}
                onChange={(e) => setSprintSubject(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-cairo font-bold"
              >
                <option value="جميع المواد">جميع المواد</option>
                {Array.from(new Set([...SUBJECT_OPTIONS, ...lessons.map((l) => l.subject)])).map((sub) => (
                  <option key={sub} value={sub}>
                    {sub}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                تاريخ الامتحان
              </label>
              <input
                type="date"
                required
                value={sprintExamDate}
                onChange={(e) => setSprintExamDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers"
              />
            </div>

            <div>
              <label className="block text-[11px] font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                ساعات المذاكرة اليومية
              </label>
              <input
                type="number"
                min={1}
                max={12}
                value={sprintHoursPerDay}
                onChange={(e) => setSprintHoursPerDay(Number(e.target.value) || 2)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers"
              />
            </div>

            <button
              type="submit"
              disabled={isGeneratingSprint}
              className="py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-black text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isGeneratingSprint ? 'جاري التوليد...' : 'توليد خطة السباق الآن'}</span>
            </button>
          </form>
        )}

        {sprintPlans.length > 0 ? (
          <div className="space-y-4">
            {sprintPlans.map((plan) => {
              const completedCount = plan.tasks.filter((t) => t.isCompleted).length;
              const totalTasks = Math.max(1, plan.tasks.length);
              const pct = Math.round((completedCount / totalTasks) * 100);
              const daysRemaining = Math.max(
                0,
                Math.ceil((new Date(plan.examDate).getTime() - Date.now()) / 86400000)
              );
              const groupedByDay = plan.tasks.reduce<Record<number, ExamSprintTask[]>>((acc, task) => {
                if (!acc[task.dayNumber]) acc[task.dayNumber] = [];
                acc[task.dayNumber].push(task);
                return acc;
              }, {});

              return (
                <div
                  key={plan.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/40 space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2.5 py-0.5 rounded-lg bg-emerald-700 text-white text-xs font-cairo font-bold">
                          {plan.subject}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-mono-numbers font-bold">
                          موعد الامتحان: {plan.examDate} (متبقي {daysRemaining} يوم)
                        </span>
                        <span className="text-xs font-mono-numbers font-bold text-slate-600 dark:text-slate-300">
                          {plan.dailyHours} ساعات/يوم
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono-numbers font-black text-sm text-emerald-700 dark:text-emerald-400">
                        {completedCount}/{plan.tasks.length} ({pct}%)
                      </span>
                      {!isParent && (
                        <button
                          type="button"
                          onClick={() => handleDeleteSprintPlan(plan.id)}
                          className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                          title="حذف الخطة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-600 to-teal-500 rounded-full transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {Object.entries(groupedByDay)
                      .sort(([a], [b]) => Number(a) - Number(b))
                      .map(([dayNum, dayTasks]) => (
                        <div
                          key={dayNum}
                          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2"
                        >
                          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-1.5">
                            <span className="font-cairo font-black text-xs text-emerald-800 dark:text-emerald-300">
                              اليوم {dayNum}
                            </span>
                            <span className="text-[10px] font-mono-numbers text-slate-400">
                              {dayTasks.filter((t) => t.isCompleted).length}/{dayTasks.length}
                            </span>
                          </div>
                          <div className="space-y-1.5">
                            {dayTasks.map((task) => (
                              <button
                                key={task.id}
                                type="button"
                                disabled={isParent}
                                onClick={() => handleToggleSprintTask(plan, task.id)}
                                className="w-full text-right flex items-start gap-2 p-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                              >
                                {task.isCompleted ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                                ) : (
                                  <Circle className="w-4 h-4 text-slate-300 shrink-0 mt-0.5" />
                                )}
                                <div className="min-w-0 flex-1">
                                  <p
                                    className={`text-xs font-cairo leading-snug ${
                                      task.isCompleted
                                        ? 'line-through text-slate-400'
                                        : 'text-slate-800 dark:text-slate-200 font-semibold'
                                    }`}
                                  >
                                    {task.title}
                                  </p>
                                  <span className="text-[10px] text-slate-400">
                                    {task.taskType === 'lesson'
                                      ? '📘 درس'
                                      : task.taskType === 'flashcards'
                                      ? '🗂️ فلاش كارد'
                                      : task.taskType === 'quiz'
                                      ? '📝 اختبار قصير'
                                      : '✨ مراجعة الأخطاء'}
                                  </span>
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-1">
            <Flame className="w-8 h-8 text-amber-400 mx-auto" />
            <p className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-200">
              لم تقم بتوليد خطة «سباق الامتحان» بعد
            </p>
            <p className="text-[11px] text-slate-500">
              حدد المادة وموعد الامتحان أعلاه لتوليد جدول مراجعة يومي ذكي تلقائياً.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
