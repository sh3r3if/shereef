import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Database,
  Edit,
  Filter,
  Layers,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import {
  CurrentUser,
  Language,
  Lesson,
  QuestionBankItem,
  QuestionDifficulty,
  Teacher,
} from '../types';
import { getAuthHeaders, isAdminStaffRole, isTeacherRole } from '../utils/rbac';

interface QuestionBankPanelProps {
  lessons: Lesson[];
  teachers: Teacher[];
  currentUser: CurrentUser | null;
  language: Language;
  onCreateQuizWithQuestions?: (questions: QuestionBankItem[], subject: string, grade: string) => void;
}

const DIFFICULTY_META: Record<
  QuestionDifficulty,
  { ar: string; en: string; cls: string }
> = {
  easy: {
    ar: 'سهل',
    en: 'Easy',
    cls: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
  },
  medium: {
    ar: 'متوسط',
    en: 'Medium',
    cls: 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800',
  },
  advanced: {
    ar: 'متقدم',
    en: 'Advanced',
    cls: 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
  },
  gifted: {
    ar: 'متفوقين',
    en: 'Gifted',
    cls: 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800',
  },
};

const SUBJECTS = [
  'الرياضيات',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'اللغة العربية',
  'اللغة الإنجليزية',
  'الحاسب الآلي',
  'العلوم الإسلامية',
  'الدراسات الاجتماعية',
];

const GRADES = [
  'الصف الثالث الثانوي',
  'الصف الثاني الثانوي',
  'الصف الأول الثانوي',
  'الصف الثالث المتوسط',
  'الصف الثاني المتوسط',
  'الصف الأول المتوسط',
];

export const QuestionBankPanel: React.FC<QuestionBankPanelProps> = ({
  lessons,
  teachers,
  currentUser,
  language,
  onCreateQuizWithQuestions,
}) => {
  const isAr = language === 'ar';
  const canEdit =
    Boolean(currentUser?.isSuperAdmin) ||
    isAdminStaffRole(currentUser?.role) ||
    isTeacherRole(currentUser?.role);

  const [items, setItems] = useState<QuestionBankItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [gradeFilter, setGradeFilter] = useState('all');
  const [difficultyFilter, setDifficultyFilter] = useState<'all' | QuestionDifficulty>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Modal Form
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<QuestionBankItem | null>(null);
  const [fSubject, setFSubject] = useState(SUBJECTS[0]);
  const [fGrade, setFGrade] = useState(GRADES[0]);
  const [fUnit, setFUnit] = useState('الوحدة الأولى');
  const [fLessonId, setFLessonId] = useState('');
  const [fDifficulty, setFDifficulty] = useState<QuestionDifficulty>('medium');
  const [fType, setFType] = useState<'mcq' | 'true_false'>('mcq');
  const [fQuestion, setFQuestion] = useState('');
  const [fOptions, setFOptions] = useState<string[]>(['', '', '', '']);
  const [fCorrectIdx, setFCorrectIdx] = useState(0);
  const [fExplanation, setFExplanation] = useState('');
  const [fPoints, setFPoints] = useState(2);
  const [isSaving, setIsSaving] = useState(false);

  const showMsg = (type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchBank = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/question-bank');
      const data = await res.json();
      setItems(Array.isArray(data) ? data : []);
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBank();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((item) => {
      if (subjectFilter !== 'all' && item.subject !== subjectFilter) return false;
      if (gradeFilter !== 'all' && item.grade !== gradeFilter) return false;
      if (difficultyFilter !== 'all' && item.difficulty !== difficultyFilter) return false;
      if (q) {
        const hay = `${item.question} ${item.unit} ${item.lessonTitle || ''} ${item.subject}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [items, search, subjectFilter, gradeFilter, difficultyFilter]);

  const countsByDiff = useMemo(() => {
    const counts: Record<QuestionDifficulty, number> = { easy: 0, medium: 0, advanced: 0, gifted: 0 };
    items.forEach((i) => {
      if (counts[i.difficulty] !== undefined) counts[i.difficulty] += 1;
    });
    return counts;
  }, [items]);

  const openAdd = () => {
    setEditingItem(null);
    setFSubject(subjectFilter !== 'all' ? subjectFilter : SUBJECTS[0]);
    setFGrade(gradeFilter !== 'all' ? gradeFilter : GRADES[0]);
    setFUnit('الوحدة الأولى');
    setFLessonId('');
    setFDifficulty('medium');
    setFType('mcq');
    setFQuestion('');
    setFOptions(['', '', '', '']);
    setFCorrectIdx(0);
    setFExplanation('');
    setFPoints(2);
    setIsModalOpen(true);
  };

  const openEdit = (item: QuestionBankItem) => {
    setEditingItem(item);
    setFSubject(item.subject);
    setFGrade(item.grade);
    setFUnit(item.unit || 'الوحدة الأولى');
    setFLessonId(item.lessonId || '');
    setFDifficulty(item.difficulty || 'medium');
    setFType(item.questionType || 'mcq');
    setFQuestion(item.question);
    setFOptions(
      item.questionType === 'true_false'
        ? ['صح', 'خطأ']
        : [...(item.options || ['', '', '', '']), '', '', '', ''].slice(0, 4)
    );
    setFCorrectIdx(item.correctOptionIndex || 0);
    setFExplanation(item.explanation || '');
    setFPoints(item.points || 2);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fQuestion.trim()) {
      showMsg('error', isAr ? 'يرجى كتابة نص السؤال' : 'Question text required');
      return;
    }
    const cleanOptions =
      fType === 'true_false'
        ? ['صح', 'خطأ']
        : fOptions.map((o) => o.trim()).filter(Boolean);
    if (cleanOptions.length < 2) {
      showMsg('error', isAr ? 'أدخل خيارين على الأقل' : 'At least 2 options required');
      return;
    }

    setIsSaving(true);
    try {
      const matchedLesson = lessons.find((l) => l.id === fLessonId);
      const payload = {
        subject: fSubject,
        grade: fGrade,
        unit: fUnit.trim() || 'الوحدة الأولى',
        lessonId: fLessonId || undefined,
        lessonTitle: matchedLesson?.title,
        difficulty: fDifficulty,
        questionType: fType,
        question: fQuestion.trim(),
        options: cleanOptions,
        correctOptionIndex: Math.min(fCorrectIdx, cleanOptions.length - 1),
        explanation: fExplanation.trim(),
        points: fPoints,
      };
      const url = editingItem
        ? `/api/question-bank/${encodeURIComponent(editingItem.id)}`
        : '/api/question-bank';
      const res = await fetch(url, {
        method: editingItem ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر الحفظ');
      if (editingItem) {
        setItems((prev) => prev.map((x) => (x.id === data.id ? data : x)));
      } else {
        setItems((prev) => [data, ...prev]);
      }
      setIsModalOpen(false);
      showMsg('success', isAr ? 'تم حفظ السؤال في البنك بنجاح' : 'Question saved to bank');
    } catch (err: any) {
      showMsg('error', err.message || 'تعذر الحفظ');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/question-bank/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setItems((prev) => prev.filter((x) => x.id !== id));
        setSelectedIds((prev) => prev.filter((x) => x !== id));
        showMsg('success', isAr ? 'تم حذف السؤال من البنك' : 'Deleted');
      }
    } catch {
      showMsg('error', 'تعذر الحذف');
    }
  };

  const handleSyncFromQuizzes = async () => {
    setSyncing(true);
    try {
      const res = await fetch('/api/question-bank/sync-from-quizzes', {
        method: 'POST',
        headers: getAuthHeaders(currentUser, teachers),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل المزامنة');
      if (Array.isArray(data.items)) setItems(data.items);
      showMsg(
        'success',
        isAr
          ? `تمت مزامنة ${data.addedCount || 0} سؤال جديد من الاختبارات الحالية بدون تكرار`
          : `Synced ${data.addedCount || 0} new questions`
      );
    } catch (err: any) {
      showMsg('error', err.message || 'تعذر المزامنة');
    } finally {
      setSyncing(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="space-y-5 font-tajawal">
      {toast && (
        <div
          className={`p-3 rounded-xl border text-xs font-cairo font-bold flex items-center justify-between ${
            toast.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/60 dark:border-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 border-rose-200 text-rose-800 dark:bg-rose-950/60 dark:border-rose-800 dark:text-rose-200'
          }`}
        >
          <span>{toast.text}</span>
          <button onClick={() => setToast(null)} className="cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-base md:text-lg font-black font-cairo text-slate-900 dark:text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" />
            <span>{isAr ? 'بنك الأسئلة المركزي والتصنيف بالصعوبة' : 'Central Smart Question Bank'}</span>
          </h3>
          <p className="text-xs text-slate-500">
            {isAr
              ? 'مكتبة مستقلة مصنّفة حسب المادة والوحدة ومستوى الصعوبة لبناء الاختبارات بالسحب التلقائي دون تكرار.'
              : 'Tagged central question library by subject, unit, lesson and difficulty.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {selectedIds.length > 0 && onCreateQuizWithQuestions && canEdit && (
            <button
              type="button"
              onClick={() => {
                const chosen = items.filter((i) => selectedIds.includes(i.id));
                onCreateQuizWithQuestions(
                  chosen,
                  chosen[0]?.subject || SUBJECTS[0],
                  chosen[0]?.grade || GRADES[0]
                );
              }}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>
                {isAr
                  ? `إنشاء اختبار من المحدد (${selectedIds.length})`
                  : `Build Quiz (${selectedIds.length})`}
              </span>
            </button>
          )}

          {canEdit && (
            <>
              <button
                type="button"
                onClick={handleSyncFromQuizzes}
                disabled={syncing}
                className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
                <span>{isAr ? 'استيراد من الاختبارات الحالية' : 'Sync From Quizzes'}</span>
              </button>

              <button
                type="button"
                onClick={openAdd}
                className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إضافة سؤال للبنك' : 'Add Question'}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono-numbers">
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-cairo text-slate-500 block">
            {isAr ? 'إجمالي الأسئلة' : 'Total'}
          </span>
          <strong className="text-xl font-black text-slate-900 dark:text-white">{items.length}</strong>
        </div>
        {(['easy', 'medium', 'advanced', 'gifted'] as QuestionDifficulty[]).map((diff) => (
          <button
            key={diff}
            type="button"
            onClick={() => setDifficultyFilter(difficultyFilter === diff ? 'all' : diff)}
            className={`p-3.5 rounded-xl border text-right transition-colors cursor-pointer ${
              difficultyFilter === diff
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50'
            }`}
          >
            <span className="text-[11px] font-cairo text-slate-500 block">
              {isAr ? DIFFICULTY_META[diff].ar : DIFFICULTY_META[diff].en}
            </span>
            <strong className="text-xl font-black text-slate-900 dark:text-white">
              {countsByDiff[diff]}
            </strong>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={isAr ? 'ابحث في نص السؤال أو الوحدة...' : 'Search question or unit...'}
            className="w-full pr-9 pl-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
          />
        </div>
        <select
          value={subjectFilter}
          onChange={(e) => setSubjectFilter(e.target.value)}
          className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo"
        >
          <option value="all">{isAr ? 'كل المواد' : 'All Subjects'}</option>
          {SUBJECTS.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <select
          value={gradeFilter}
          onChange={(e) => setGradeFilter(e.target.value)}
          className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo"
        >
          <option value="all">{isAr ? 'كل المراحل' : 'All Grades'}</option>
          {GRADES.map((g) => (
            <option key={g} value={g}>{g}</option>
          ))}
        </select>
        <select
          value={difficultyFilter}
          onChange={(e) => setDifficultyFilter(e.target.value as any)}
          className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo"
        >
          <option value="all">{isAr ? 'كل مستويات الصعوبة' : 'All Difficulties'}</option>
          {(['easy', 'medium', 'advanced', 'gifted'] as QuestionDifficulty[]).map((d) => (
            <option key={d} value={d}>
              {isAr ? DIFFICULTY_META[d].ar : DIFFICULTY_META[d].en}
            </option>
          ))}
        </select>
      </div>

      {/* Question Cards */}
      {loading ? (
        <div className="p-10 text-center text-xs text-slate-400">
          {isAr ? 'جاري تحميل بنك الأسئلة...' : 'Loading question bank...'}
        </div>
      ) : filtered.length === 0 ? (
        <div className="p-10 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 space-y-2">
          <Filter className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-sm font-cairo font-bold text-slate-600 dark:text-slate-300">
            {isAr ? 'لا توجد أسئلة مطابقة في البنك حالياً' : 'No matching questions'}
          </p>
          <p className="text-xs text-slate-400">
            {isAr
              ? 'اضغط على "إضافة سؤال للبنك" أو "استيراد من الاختبارات الحالية" لبدء تعبئة المكتبة.'
              : 'Add a question or sync from existing quizzes.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const diffMeta = DIFFICULTY_META[item.difficulty || 'medium'];
            const isSelected = selectedIds.includes(item.id);
            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition-colors ${
                  isSelected
                    ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-400'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    {canEdit && (
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(item.id)}
                        className="mt-1 w-4 h-4 accent-emerald-600 cursor-pointer shrink-0"
                      />
                    )}
                    <div className="space-y-1.5 min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-[11px]">
                        <span className={`px-2 py-0.5 rounded-md border font-cairo font-bold ${diffMeta.cls}`}>
                          {isAr ? diffMeta.ar : diffMeta.en}
                        </span>
                        <span className="font-cairo font-bold text-slate-600 dark:text-slate-300">
                          {item.subject} · {item.grade}
                        </span>
                        {item.unit && (
                          <span className="text-slate-500 flex items-center gap-1">
                            <Layers className="w-3 h-3" /> {item.unit}
                          </span>
                        )}
                        {item.lessonTitle && (
                          <span className="text-slate-500 flex items-center gap-1">
                            <BookOpen className="w-3 h-3" /> {item.lessonTitle}
                          </span>
                        )}
                        <span className="font-mono-numbers text-slate-400">
                          {item.points} {isAr ? 'درجات' : 'pts'} · {isAr ? `استُخدم ${item.usageCount || 0} مرة` : `Used ${item.usageCount || 0}x`}
                        </span>
                      </div>

                      <p className="text-sm font-cairo font-bold text-slate-900 dark:text-white leading-relaxed">
                        {item.question}
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                        {(item.options || []).map((opt, idx) => (
                          <div
                            key={idx}
                            className={`px-3 py-1.5 rounded-lg text-xs border flex items-center gap-2 ${
                              idx === item.correctOptionIndex
                                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 font-bold'
                                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                            }`}
                          >
                            {idx === item.correctOptionIndex && <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />}
                            <span>{opt}</span>
                          </div>
                        ))}
                      </div>

                      {item.explanation && (
                        <p className="text-[11px] text-slate-500 pt-1">
                          <strong className="font-cairo">{isAr ? 'التفسير:' : 'Explanation:'}</strong> {item.explanation}
                        </p>
                      )}
                    </div>
                  </div>

                  {canEdit && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => openEdit(item)}
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 cursor-pointer"
                        title={isAr ? 'تعديل' : 'Edit'}
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(item.id)}
                        className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                        title={isAr ? 'حذف' : 'Delete'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl p-5 space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {editingItem
                  ? isAr ? 'تعديل سؤال في البنك' : 'Edit Bank Question'
                  : isAr ? 'إضافة سؤال جديد لبنك الأسئلة' : 'Add Question to Bank'}
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'المادة' : 'Subject'}</label>
                  <select
                    value={fSubject}
                    onChange={(e) => setFSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'المرحلة' : 'Grade'}</label>
                  <select
                    value={fGrade}
                    onChange={(e) => setFGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'مستوى الصعوبة' : 'Difficulty'}</label>
                  <select
                    value={fDifficulty}
                    onChange={(e) => setFDifficulty(e.target.value as QuestionDifficulty)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    {(['easy', 'medium', 'advanced', 'gifted'] as QuestionDifficulty[]).map((d) => (
                      <option key={d} value={d}>{isAr ? DIFFICULTY_META[d].ar : DIFFICULTY_META[d].en}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'الوحدة / الفصل' : 'Unit'}</label>
                  <input
                    type="text"
                    value={fUnit}
                    onChange={(e) => setFUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'الدرس المرتبط' : 'Lesson'}</label>
                  <select
                    value={fLessonId}
                    onChange={(e) => setFLessonId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    <option value="">{isAr ? '-- اختياري --' : '-- Optional --'}</option>
                    {lessons.map((l) => <option key={l.id} value={l.id}>{l.title}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-cairo font-bold block mb-1">{isAr ? 'النوع' : 'Type'}</label>
                    <select
                      value={fType}
                      onChange={(e) => setFType(e.target.value as any)}
                      className="w-full px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                    >
                      <option value="mcq">{isAr ? 'اختيارات' : 'MCQ'}</option>
                      <option value="true_false">{isAr ? 'صح/خطأ' : 'T/F'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-cairo font-bold block mb-1">{isAr ? 'الدرجة' : 'Pts'}</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={fPoints}
                      onChange={(e) => setFPoints(Number(e.target.value) || 1)}
                      className="w-full px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'نص السؤال' : 'Question Text'}</label>
                <textarea
                  rows={2}
                  value={fQuestion}
                  onChange={(e) => setFQuestion(e.target.value)}
                  placeholder={isAr ? 'اكتب السؤال بوضوح...' : 'Enter question...'}
                  className="w-full px-3 py-2 rounded-xl bg-sky-50/60 dark:bg-slate-800 border border-sky-200 dark:border-slate-700"
                />
              </div>

              {fType === 'mcq' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {fOptions.map((opt, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="qb_correct"
                        checked={fCorrectIdx === idx}
                        onChange={() => setFCorrectIdx(idx)}
                        className="accent-emerald-600 cursor-pointer"
                      />
                      <input
                        type="text"
                        value={opt}
                        onChange={(e) => {
                          const next = [...fOptions];
                          next[idx] = e.target.value;
                          setFOptions(next);
                        }}
                        placeholder={`${isAr ? 'الاختيار' : 'Option'} ${idx + 1}`}
                        className="flex-1 px-3 py-1.5 rounded-xl bg-emerald-50/40 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center gap-4">
                  {['صح', 'خطأ'].map((label, idx) => (
                    <label key={label} className="flex items-center gap-2 cursor-pointer font-cairo font-bold">
                      <input
                        type="radio"
                        name="qb_tf"
                        checked={fCorrectIdx === idx}
                        onChange={() => setFCorrectIdx(idx)}
                        className="accent-emerald-600"
                      />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              )}

              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'التفسير العلمي للإجابة (اختياري)' : 'Explanation'}</label>
                <input
                  type="text"
                  value={fExplanation}
                  onChange={(e) => setFExplanation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 font-cairo font-bold cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold cursor-pointer"
                >
                  {isSaving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : (isAr ? 'حفظ في البنك' : 'Save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
