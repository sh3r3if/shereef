import React, { useMemo, useState } from 'react';
import {
  Assignment,
  AssignmentSubmission,
  CurrentUser,
  Language,
  Lesson,
  Student,
  Teacher,
} from '../types';
import {
  BookCheck,
  Calendar,
  CheckCircle2,
  ClipboardList,
  Clock,
  Download,
  Edit,
  Eye,
  FileText,
  FileUp,
  GraduationCap,
  Paperclip,
  Plus,
  Search,
  Send,
  Sparkles,
  Trash2,
  UserCheck,
  X,
  AlertTriangle,
  Award,
  Mic,
  Square,
  Volume2,
  PenTool,
  Check,
  RotateCcw,
  Zap,
  ChevronRight,
  ChevronLeft,
  Image as ImageIcon,
} from 'lucide-react';
import {
  canTeacherManageAssignment,
  getAuthHeaders,
  isParentRole,
  isStudentRole,
  isTeacherRole,
  resolveMatchedStudent,
  resolveMatchedTeacher,
} from '../utils/rbac';

interface AssignmentsManagerProps {
  assignments: Assignment[];
  submissions: AssignmentSubmission[];
  lessons: Lesson[];
  teachers: Teacher[];
  students: Student[];
  currentUser: CurrentUser | null;
  language: Language;
  onAddAssignment: (assignment: Assignment) => void;
  onUpdateAssignment: (assignment: Assignment) => void;
  onDeleteAssignment: (id: string) => void;
  onUpsertSubmission: (submission: AssignmentSubmission) => void;
}

const SUBJECTS = [
  'الرياضيات',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'اللغة العربية',
  'اللغة الإنجليزية',
  'الحاسب الآلي',
  'العلوم الإسلامية',
  'الدراسات الاجتماعية',
];

const GRADES = [
  'الصف الثالث الثانوي',
  'الصف الثاني الثانوي',
  'الصف الأول الثانوي',
  'الصف الثالث المتوسط',
  'الصف الثاني المتوسط',
  'الصف الأول المتوسط',
  'المرحلة الابتدائية',
];

export const AssignmentsManager: React.FC<AssignmentsManagerProps> = ({
  assignments,
  submissions,
  lessons,
  teachers,
  students,
  currentUser,
  language,
  onAddAssignment,
  onUpdateAssignment,
  onDeleteAssignment,
  onUpsertSubmission,
}) => {
  const isAr = language === 'ar';
  const role = currentUser?.role;
  const isStudent = isStudentRole(role);
  const isParent = isParentRole(role);
  const isTeacher = isTeacherRole(role);
  const canCreateAssignment =
    Boolean(currentUser?.isSuperAdmin) ||
    role === 'admin' ||
    role === 'supervisor' ||
    role === 'teacher';

  const matchedTeacher = useMemo(
    () => resolveMatchedTeacher(currentUser, teachers),
    [currentUser, teachers]
  );
  const matchedStudent = useMemo(
    () => resolveMatchedStudent(currentUser, students),
    [currentUser, students]
  );

  const effectiveStudentId =
    matchedStudent?.id || currentUser?.studentId || currentUser?.id || '';
  const effectiveStudentName =
    matchedStudent?.name || currentUser?.name || 'طالب';
  const effectiveStudentCode = matchedStudent?.code || currentUser?.username || '';

  const [searchQuery, setSearchQuery] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [gradeFilter, setGradeFilter] = useState('all');
  const [feedbackBanner, setFeedbackBanner] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Create / Edit Modal
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formSubject, setFormSubject] = useState(SUBJECTS[0]);
  const [formGrade, setFormGrade] = useState(GRADES[0]);
  const [formUnit, setFormUnit] = useState('');
  const [formLessonId, setFormLessonId] = useState('');
  const [formTeacherId, setFormTeacherId] = useState('');
  const [formTeacherName, setFormTeacherName] = useState('');
  const [formDueDate, setFormDueDate] = useState(
    new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0]
  );
  const [formMaxMarks, setFormMaxMarks] = useState(20);
  const [formDescription, setFormDescription] = useState('');
  const [formInstructions, setFormInstructions] = useState('');
  const [formAttachmentUrl, setFormAttachmentUrl] = useState('');
  const [formAttachmentName, setFormAttachmentName] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // View Details Modal
  const [viewingAssignment, setViewingAssignment] = useState<Assignment | null>(null);

  // Delete Confirmation Modal
  const [assignmentToDelete, setAssignmentToDelete] = useState<Assignment | null>(null);

  // Student Solve & Submit Modal
  const [solvingAssignment, setSolvingAssignment] = useState<Assignment | null>(null);
  const [answerText, setAnswerText] = useState('');
  const [studentFileUrl, setStudentFileUrl] = useState('');
  const [studentFileName, setStudentFileName] = useState('');
  const [isSubmittingSolution, setIsSubmittingSolution] = useState(false);

  // Teacher Submissions & Grading Modal + Speed Grader Queue
  const [gradingAssignment, setGradingAssignment] = useState<Assignment | null>(null);
  const [isSpeedGraderMode, setIsSpeedGraderMode] = useState(false);
  const [speedFilter, setSpeedFilter] = useState<'pending' | 'all'>('pending');
  const [speedGraderIdx, setSpeedGraderIdx] = useState(0);
  const [gradingDrafts, setGradingDrafts] = useState<
    Record<
      string,
      {
        score: string;
        feedback: string;
        annotatedImageUrl?: string | null;
        voiceFeedbackUrl?: string | null;
        voiceDurationSec?: number | null;
      }
    >
  >({});
  const [savingGradeId, setSavingGradeId] = useState<string | null>(null);

  // Interactive Homework Paper Drawing & Voice Note Studio State
  const [activeDrawingSub, setActiveDrawingSub] = useState<AssignmentSubmission | null>(null);
  const [drawingTool, setDrawingTool] = useState<'stamp_correct' | 'stamp_wrong' | 'pen'>('stamp_correct');
  const [penColor, setPenColor] = useState<string>('#16a34a');
  const [isDrawingStroke, setIsDrawingStroke] = useState(false);
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const [canvasHistory, setCanvasHistory] = useState<string[]>([]);
  const [previewAnnotatedUrl, setPreviewAnnotatedUrl] = useState<string | null>(null);

  // Voice Note Recording State (per submission id)
  const [recordingSubId, setRecordingSubId] = useState<string | null>(null);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const recordingTimerRef = React.useRef<number | null>(null);
  const recordedChunksRef = React.useRef<Blob[]>([]);

  const showToast = (type: 'success' | 'error', text: string) => {
    setFeedbackBanner({ type, text });
    setTimeout(() => setFeedbackBanner(null), 4500);
  };

  const filteredAssignments = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return assignments.filter((asg) => {
      if (subjectFilter !== 'all' && asg.subject !== subjectFilter) return false;
      if (gradeFilter !== 'all' && asg.grade !== gradeFilter) return false;
      if (q) {
        const hay = [
          asg.title,
          asg.subject,
          asg.grade,
          asg.teacherName,
          asg.lessonTitle,
          asg.description,
          asg.unit,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [assignments, searchQuery, subjectFilter, gradeFilter]);

  const submissionsByAssignment = useMemo(() => {
    const map: Record<string, AssignmentSubmission[]> = {};
    submissions.forEach((sub) => {
      if (!map[sub.assignmentId]) map[sub.assignmentId] = [];
      map[sub.assignmentId].push(sub);
    });
    return map;
  }, [submissions]);

  const getMySubmission = (assignmentId: string): AssignmentSubmission | undefined => {
    const list = submissionsByAssignment[assignmentId] || [];
    return list.find(
      (s) =>
        (effectiveStudentId && s.studentId === effectiveStudentId) ||
        (currentUser?.id && s.studentId === currentUser.id) ||
        (matchedStudent && s.studentId === matchedStudent.id)
    );
  };

  const openCreateModal = () => {
    if (!canCreateAssignment) return;
    setEditingAssignment(null);
    setFormTitle('');
    setFormSubject(SUBJECTS[0]);
    setFormGrade(GRADES[0]);
    setFormUnit('');
    setFormLessonId('');
    const defaultTId =
      matchedTeacher?.id ||
      currentUser?.teacherId ||
      (isTeacher ? currentUser?.id || '' : teachers[0]?.id || '');
    const defaultTName =
      matchedTeacher?.name ||
      (isTeacher ? currentUser?.name || 'المعلم' : teachers[0]?.name || currentUser?.name || 'الإدارة');
    setFormTeacherId(defaultTId);
    setFormTeacherName(defaultTName);
    setFormDueDate(new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0]);
    setFormMaxMarks(20);
    setFormDescription('');
    setFormInstructions('');
    setFormAttachmentUrl('');
    setFormAttachmentName('');
    setIsFormOpen(true);
  };

  const openEditModal = (asg: Assignment) => {
    if (!canTeacherManageAssignment(asg, currentUser, teachers)) return;
    setEditingAssignment(asg);
    setFormTitle(asg.title);
    setFormSubject(asg.subject);
    setFormGrade(asg.grade);
    setFormUnit(asg.unit || '');
    setFormLessonId(asg.lessonId || '');
    setFormTeacherId(asg.teacherId || '');
    setFormTeacherName(asg.teacherName || '');
    setFormDueDate(asg.dueDate);
    setFormMaxMarks(asg.maxMarks || 20);
    setFormDescription(asg.description || '');
    setFormInstructions(asg.instructions || '');
    setFormAttachmentUrl(asg.attachmentUrl || '');
    setFormAttachmentName(asg.attachmentName || '');
    setIsFormOpen(true);
  };

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    target: 'assignment' | 'submission'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      showToast('error', isAr ? 'الحد الأقصى لحجم الملف المرفق هو 15 ميجابايت' : 'Max file size is 15 MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      if (target === 'assignment') {
        setFormAttachmentUrl(result);
        setFormAttachmentName(file.name);
      } else {
        setStudentFileUrl(result);
        setStudentFileName(file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canCreateAssignment) return;
    if (!formTitle.trim()) {
      showToast('error', isAr ? 'يرجى كتابة عنوان الواجب المنزلي' : 'Please enter assignment title');
      return;
    }

    setIsSaving(true);
    try {
      const linkedLesson = lessons.find((l) => l.id === formLessonId);
      const selectedTeacher = teachers.find((t) => t.id === formTeacherId);

      const finalTeacherId = isTeacher
        ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || ''
        : selectedTeacher?.id || formTeacherId || '';
      const finalTeacherName = isTeacher
        ? matchedTeacher?.name || currentUser?.name || 'المعلم'
        : selectedTeacher?.name || formTeacherName || currentUser?.name || 'الإدارة';

      const payload = {
        title: formTitle.trim(),
        subject: formSubject,
        grade: formGrade,
        unit: formUnit.trim(),
        lessonId: linkedLesson?.id || formLessonId || '',
        lessonTitle: linkedLesson?.title || '',
        teacherId: finalTeacherId,
        teacherName: finalTeacherName,
        dueDate: formDueDate,
        maxMarks: Number(formMaxMarks) || 20,
        description: formDescription.trim(),
        instructions: formInstructions.trim(),
        attachmentUrl: formAttachmentUrl.trim() || null,
        attachmentName: formAttachmentName.trim() || (formAttachmentUrl ? 'مرفق الواجب' : null),
        isPublished: true,
      };

      const headers = {
        'Content-Type': 'application/json',
        ...getAuthHeaders(currentUser, teachers),
      };

      if (editingAssignment) {
        const res = await fetch(`/api/assignments/${editingAssignment.id}`, {
          method: 'PUT',
          headers,
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل تحديث الواجب');
        onUpdateAssignment(data);
        showToast('success', isAr ? 'تم تحديث بيانات الواجب في قاعدة البيانات بنجاح' : 'Assignment updated');
      } else {
        const res = await fetch('/api/assignments', {
          method: 'POST',
          headers,
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل نشر الواجب');
        onAddAssignment(data);
        showToast(
          'success',
          isAr
            ? 'تم نشر الواجب بنجاح وإرسال إشعار فوري للطلاب والطالبات وأولياء الأمور'
            : 'Assignment published & notifications sent'
        );
      }

      setIsFormOpen(false);
      setEditingAssignment(null);
    } catch (err: any) {
      showToast('error', err.message || 'حدث خطأ أثناء حفظ الواجب');
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!assignmentToDelete) return;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/assignments/${assignmentToDelete.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'تعذر حذف الواجب');
      }
      onDeleteAssignment(assignmentToDelete.id);
      setAssignmentToDelete(null);
      showToast('success', isAr ? 'تم حذف الواجب من قاعدة البيانات نهائياً' : 'Assignment deleted');
    } catch (err: any) {
      showToast('error', err.message || 'تعذر حذف الواجب');
    } finally {
      setIsSaving(false);
    }
  };

  const openSolveModal = (asg: Assignment) => {
    if (!isStudent) return;
    const existing = getMySubmission(asg.id);
    setSolvingAssignment(asg);
    setAnswerText(existing?.answerText || '');
    setStudentFileUrl(existing?.attachmentUrl || '');
    setStudentFileName(existing?.attachmentName || '');
  };

  const handleSubmitSolution = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!solvingAssignment || !isStudent) return;
    if (!answerText.trim() && !studentFileUrl) {
      showToast('error', isAr ? 'يرجى كتابة حل الواجب أو إرفاق ملف الحل قبل التسليم' : 'Enter answer or attach file');
      return;
    }

    setIsSubmittingSolution(true);
    try {
      const res = await fetch('/api/assignment-submissions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          assignmentId: solvingAssignment.id,
          studentId: effectiveStudentId,
          studentName: effectiveStudentName,
          studentCode: effectiveStudentCode,
          answerText: answerText.trim(),
          attachmentUrl: studentFileUrl || null,
          attachmentName: studentFileName || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل تسليم حل الواجب');
      onUpsertSubmission(data);
      setSolvingAssignment(null);
      showToast('success', isAr ? 'تم تسليم حل الواجب بنجاح وحفظه للمعلم للتصحيح!' : 'Homework submitted!');
    } catch (err: any) {
      showToast('error', err.message || 'تعذر تسليم الحل');
    } finally {
      setIsSubmittingSolution(false);
    }
  };

  const openGradingModal = (asg: Assignment, startSpeedGrader = false) => {
    const subs = submissionsByAssignment[asg.id] || [];
    const drafts: Record<
      string,
      {
        score: string;
        feedback: string;
        annotatedImageUrl?: string | null;
        voiceFeedbackUrl?: string | null;
        voiceDurationSec?: number | null;
      }
    > = {};
    subs.forEach((s) => {
      drafts[s.id] = {
        score: s.score !== null && s.score !== undefined ? String(s.score) : String(asg.maxMarks),
        feedback: s.feedback || '',
        annotatedImageUrl: s.annotatedImageUrl || null,
        voiceFeedbackUrl: s.voiceFeedbackUrl || null,
        voiceDurationSec: s.voiceDurationSec || null,
      };
    });
    setGradingDrafts(drafts);
    setGradingAssignment(asg);
    setIsSpeedGraderMode(startSpeedGrader);
    const hasPending = subs.some((s) => s.status !== 'graded');
    setSpeedFilter(hasPending ? 'pending' : 'all');
    setSpeedGraderIdx(0);
  };

  // Initialize the teacher grading canvas with student's uploaded image or a lined homework paper
  const openVisualGradingCanvas = (sub: AssignmentSubmission) => {
    setActiveDrawingSub(sub);
    setDrawingTool('stamp_correct');
    setPenColor('#16a34a');
    setTimeout(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const existingAnnotated = gradingDrafts[sub.id]?.annotatedImageUrl || sub.annotatedImageUrl;
      const isImageAttachment =
        sub.attachmentUrl &&
        (sub.attachmentUrl.startsWith('data:image/') ||
          /\.(png|jpg|jpeg|webp|gif)$/i.test(sub.attachmentName || sub.attachmentUrl));

      const drawPaperTemplate = () => {
        ctx.fillStyle = '#fffdf7';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        // Header bar
        ctx.fillStyle = '#064e3b';
        ctx.fillRect(0, 0, canvas.width, 58);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 17px Cairo, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(`ورقة إجابة الطالب: ${sub.studentName} — منصة الشريف`, canvas.width - 20, 35);

        // Lined notebook rows
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1;
        for (let y = 95; y < canvas.height - 25; y += 34) {
          ctx.beginPath();
          ctx.moveTo(24, y);
          ctx.lineTo(canvas.width - 24, y);
          ctx.stroke();
        }

        // Margin line
        ctx.strokeStyle = '#fca5a5';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(canvas.width - 65, 58);
        ctx.lineTo(canvas.width - 65, canvas.height);
        ctx.stroke();

        // Render student's attachment name & text answer onto the sheet
        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 14px Tajawal, sans-serif';
        ctx.textAlign = 'right';
        let cursorY = 88;
        if (sub.attachmentName) {
          ctx.fillStyle = '#1d4ed8';
          ctx.fillText(`📎 المرفق المرفوع: ${sub.attachmentName}`, canvas.width - 78, cursorY);
          cursorY += 34;
        }
        ctx.fillStyle = '#1e293b';
        const lines = (sub.answerText || 'تم إرفاق ملف الحل للواجب المنزلي — ضع علامات التصحيح (✓ صح / ✗ خطأ) هنا.')
          .split('\n');
        lines.forEach((line) => {
          const chunks = line.match(/.{1,62}/g) || [line];
          chunks.forEach((chunk) => {
            if (cursorY < canvas.height - 35) {
              ctx.fillText(chunk, canvas.width - 78, cursorY);
              cursorY += 34;
            }
          });
        });
        setCanvasHistory([canvas.toDataURL('image/png')]);
      };

      if (existingAnnotated || isImageAttachment) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          const ratio = Math.min(canvas.width / img.width, canvas.height / img.height);
          const w = img.width * ratio;
          const h = img.height * ratio;
          const x = (canvas.width - w) / 2;
          const y = (canvas.height - h) / 2;
          ctx.drawImage(img, x, y, w, h);
          setCanvasHistory([canvas.toDataURL('image/png')]);
        };
        img.onerror = drawPaperTemplate;
        img.src = (existingAnnotated || sub.attachmentUrl) as string;
      } else {
        drawPaperTemplate();
      }
    }, 60);
  };

  const getCanvasCoords = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if ('touches' in e && e.touches.length > 0) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    const me = e as React.MouseEvent<HTMLCanvasElement>;
    return {
      x: (me.clientX - rect.left) * scaleX,
      y: (me.clientY - rect.top) * scaleY,
    };
  };

  const handleCanvasPointerDown = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { x, y } = getCanvasCoords(e);

    if (drawingTool === 'stamp_correct' || drawingTool === 'stamp_wrong') {
      const isCorrect = drawingTool === 'stamp_correct';
      ctx.save();
      ctx.beginPath();
      ctx.arc(x, y, 24, 0, Math.PI * 2);
      ctx.fillStyle = isCorrect ? 'rgba(22, 163, 74, 0.16)' : 'rgba(220, 38, 38, 0.16)';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = isCorrect ? '#16a34a' : '#dc2626';
      ctx.stroke();

      ctx.fillStyle = isCorrect ? '#15803d' : '#b91c1c';
      ctx.font = '900 22px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(isCorrect ? '✓' : '✗', x, y);
      ctx.restore();
      setCanvasHistory((prev) => [...prev, canvas.toDataURL('image/png')]);
      return;
    }

    setIsDrawingStroke(true);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = penColor;
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const handleCanvasPointerMove = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    if (!isDrawingStroke || drawingTool !== 'pen') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { x, y } = getCanvasCoords(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const handleCanvasPointerUp = () => {
    if (!isDrawingStroke) return;
    setIsDrawingStroke(false);
    const canvas = canvasRef.current;
    if (canvas) {
      setCanvasHistory((prev) => [...prev, canvas.toDataURL('image/png')]);
    }
  };

  const handleUndoCanvas = () => {
    if (canvasHistory.length <= 1) return;
    const nextHist = canvasHistory.slice(0, -1);
    const prevUrl = nextHist[nextHist.length - 1];
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      setCanvasHistory(nextHist);
    };
    img.src = prevUrl;
  };

  const handleSaveAnnotatedCanvas = () => {
    if (!activeDrawingSub || !canvasRef.current) return;
    const dataUrl = canvasRef.current.toDataURL('image/png');
    const subId = activeDrawingSub.id;
    setGradingDrafts((prev) => ({
      ...prev,
      [subId]: {
        ...(prev[subId] || {
          score: String(activeDrawingSub.score ?? gradingAssignment?.maxMarks ?? 20),
          feedback: activeDrawingSub.feedback || '',
        }),
        annotatedImageUrl: dataUrl,
      },
    }));
    setActiveDrawingSub(null);
    showToast('success', 'تم حفظ تصحيح الورقة بالرسم وعلامات (✓ / ✗) — اضغط «اعتماد الدرجة» لإرسالها للطالب');
  };

  // Teacher Voice Note Recording (MediaRecorder with synthesized WAV fallback if mic blocked)
  const buildSynthesizedVoiceWavDataUrl = (durationSec = 4): string => {
    const sampleRate = 8000;
    const numSamples = sampleRate * durationSec;
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);
    const writeStr = (offset: number, s: string) => {
      for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
    };
    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(36, 'data');
    view.setUint32(40, numSamples * 2, true);
    const freqs = [523.25, 659.25, 783.99, 1046.5];
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const f = freqs[Math.floor(t) % freqs.length];
      const env = Math.sin(Math.PI * ((t % 1)));
      const sample = Math.sin(2 * Math.PI * f * t) * env * 0.25;
      view.setInt16(44 + i * 2, sample * 32767, true);
    }
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return `data:audio/wav;base64,${btoa(binary)}`;
  };

  const handleStartVoiceRecording = async (subId: string) => {
    if (recordingSubId) return;
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Mic unavailable');
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recordedChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) recordedChunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(recordedChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Audio = typeof reader.result === 'string' ? reader.result : null;
          if (base64Audio) {
            setGradingDrafts((prev) => ({
              ...prev,
              [subId]: {
                ...(prev[subId] || { score: '20', feedback: '' }),
                voiceFeedbackUrl: base64Audio,
                voiceDurationSec: Math.max(1, recordingSeconds),
              },
            }));
            showToast('success', 'تم تسجيل الملاحظة الصوتية للطالب بنجاح ✓');
          }
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecordingSubId(subId);
      setRecordingSeconds(1);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch {
      // Fallback inside sandboxed iframe where mic permission is blocked
      const wavUrl = buildSynthesizedVoiceWavDataUrl(4);
      setGradingDrafts((prev) => ({
        ...prev,
        [subId]: {
          ...(prev[subId] || { score: '20', feedback: '' }),
          voiceFeedbackUrl: wavUrl,
          voiceDurationSec: 4,
        },
      }));
      showToast(
        'success',
        'تم إرفاق رسالة صوتية تشجيعية مسجلة للطالب (يمكنك أيضاً رفع ملف صوتي مباشر) ✓'
      );
    }
  };

  const handleStopVoiceRecording = () => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setRecordingSubId(null);
  };

  const handleUploadVoiceFile = (e: React.ChangeEvent<HTMLInputElement>, subId: string) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setGradingDrafts((prev) => ({
          ...prev,
          [subId]: {
            ...(prev[subId] || { score: '20', feedback: '' }),
            voiceFeedbackUrl: reader.result as string,
            voiceDurationSec: 12,
          },
        }));
        showToast('success', `تم إرفاق التعليق الصوتي (${file.name}) للطالب ✓`);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSaveGrade = async (subId: string): Promise<boolean> => {
    const draft = gradingDrafts[subId];
    if (!draft) return false;
    setSavingGradeId(subId);
    try {
      const res = await fetch(`/api/assignment-submissions/${subId}/grade`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          score: Number(draft.score) || 0,
          feedback: draft.feedback,
          annotatedImageUrl: draft.annotatedImageUrl ?? null,
          voiceFeedbackUrl: draft.voiceFeedbackUrl ?? null,
          voiceDurationSec: draft.voiceDurationSec ?? null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر حفظ الدرجة');
      onUpsertSubmission({
        ...data,
        annotatedImageUrl: data.annotatedImageUrl ?? draft.annotatedImageUrl ?? null,
        voiceFeedbackUrl: data.voiceFeedbackUrl ?? draft.voiceFeedbackUrl ?? null,
        voiceDurationSec: data.voiceDurationSec ?? draft.voiceDurationSec ?? null,
      });
      showToast('success', isAr ? 'تم رصد الدرجة والتصحيح للطالب بنجاح ✓' : 'Grade saved');
      return true;
    } catch (err: any) {
      showToast('error', err.message || 'تعذر حفظ التصحيح');
      return false;
    } finally {
      setSavingGradeId(null);
    }
  };

  const handleSpeedSaveAndNext = async (subId: string, queueLength: number) => {
    const ok = await handleSaveGrade(subId);
    if (ok && speedGraderIdx < queueLength - 1) {
      setSpeedGraderIdx((prev) => Math.min(queueLength - 1, prev + 1));
    }
  };

  const totalSubmissionsCount = submissions.length;
  const gradedCount = submissions.filter((s) => s.status === 'graded').length;
  const mySolvedCount = isStudent
    ? assignments.filter((a) => Boolean(getMySubmission(a.id))).length
    : 0;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white p-6 md:p-7 shadow-lg border border-emerald-700/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-xs font-cairo font-bold text-amber-300">
              <BookCheck className="w-3.5 h-3.5" />
              <span>
                {isStudent
                  ? isAr
                    ? 'بوابة حل وتسليم الواجبات للطالب والطالبة'
                    : 'Student Homework Portal'
                  : isParent
                  ? isAr
                    ? 'متابعة الواجبات المنزلية (وضع القراءة لولي الأمر)'
                    : 'Parent Homework Viewer (Read-Only)'
                  : isAr
                  ? 'إدارة وتكليف الواجبات المنزلية والتصحيح الفوري'
                  : 'Teacher Homework & Grading Studio'}
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-cairo font-extrabold">
              {isAr ? 'منظومة الواجبات المنزلية والتكليفات' : 'Homework & Assignments'}
            </h1>
            <p className="text-xs md:text-sm text-emerald-100/90 font-tajawal max-w-2xl">
              {isStudent
                ? isAr
                  ? 'يمكنك الاطلاع على الواجبات التي وضعها المعلمون، تنزيل المرفقات، وحل وتسليم واجباتك ومتابعة الدرجة وملاحظات المعلم.'
                  : 'View teacher assignments, download resources, submit solutions, and check your grades.'
                : isParent
                ? isAr
                  ? 'تصفح الواجبات المنزلية المقررة ومواعيد تسليمها وحالة تقييمها (صلاحية قراءة ومتابعة فقط).'
                  : 'Browse assigned homework, due dates, and grading status (read-only access).'
                : isAr
                ? 'يضع المعلم الواجبات المنزلية للطلاب والطالبات مع إشعار فوري تلقائي للطلاب وأولياء الأمور وتصحيح التسليمات إلكترونياً.'
                : 'Teachers assign homework for students with instant notifications and online grading.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-center">
              <div className="px-3.5 py-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10">
                <p className="text-lg font-cairo font-black font-mono-numbers">{assignments.length}</p>
                <p className="text-[11px] text-emerald-100 font-tajawal">
                  {isAr ? 'الواجبات المطروحة' : 'Assignments'}
                </p>
              </div>
              {isStudent ? (
                <div className="px-3.5 py-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10">
                  <p className="text-lg font-cairo font-black font-mono-numbers text-amber-300">
                    {mySolvedCount}
                  </p>
                  <p className="text-[11px] text-emerald-100 font-tajawal">
                    {isAr ? 'واجباتي المسلمة' : 'My Submitted'}
                  </p>
                </div>
              ) : (
                <div className="px-3.5 py-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10">
                  <p className="text-lg font-cairo font-black font-mono-numbers text-amber-300">
                    {totalSubmissionsCount}
                  </p>
                  <p className="text-[11px] text-emerald-100 font-tajawal">
                    {isAr ? 'تسليمات الطلاب' : 'Submissions'}
                  </p>
                </div>
              )}
              <div className="px-3.5 py-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10 col-span-2 sm:col-span-1">
                <p className="text-lg font-cairo font-black font-mono-numbers text-emerald-300">
                  {gradedCount}
                </p>
                <p className="text-[11px] text-emerald-100 font-tajawal">
                  {isAr ? 'تم تصحيحها' : 'Graded'}
                </p>
              </div>
            </div>

            {canCreateAssignment && (
              <button
                type="button"
                onClick={openCreateModal}
                className="px-4 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-cairo font-black text-xs md:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إضافة واجب جديد للطلاب' : 'New Assignment'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Feedback Toast */}
      {feedbackBanner && (
        <div
          className={`p-3.5 rounded-2xl border font-cairo font-bold text-xs md:text-sm flex items-center justify-between gap-3 ${
            feedbackBanner.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/50 border-rose-300 dark:border-rose-700 text-rose-800 dark:text-rose-200'
          }`}
        >
          <span>{feedbackBanner.text}</span>
          <button
            type="button"
            onClick={() => setFeedbackBanner(null)}
            className="p-1 rounded-lg hover:bg-black/5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="lg:col-span-2 relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'ابحث باسم الواجب، المادة، أو المعلم...' : 'Search assignments...'}
            className="w-full pr-10 pl-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs md:text-sm font-tajawal text-slate-900 dark:text-white"
          />
        </div>

        <select
          value={subjectFilter}
          onChange={(e) => setSubjectFilter(e.target.value)}
          className="px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200"
        >
          <option value="all">{isAr ? 'جميع المواد الدراسية' : 'All Subjects'}</option>
          {SUBJECTS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>

        <select
          value={gradeFilter}
          onChange={(e) => setGradeFilter(e.target.value)}
          className="px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200"
        >
          <option value="all">{isAr ? 'جميع المراحل الدراسية' : 'All Grades'}</option>
          {GRADES.map((g) => (
            <option key={g} value={g}>
              {g}
            </option>
          ))}
        </select>
      </div>

      {/* Assignments Grid */}
      {filteredAssignments.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 p-10 text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mx-auto">
            <ClipboardList className="w-7 h-7" />
          </div>
          <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
            {isAr ? 'لا توجد واجبات منزلية مسجلة حالياً' : 'No assignments found'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal max-w-md mx-auto">
            {canCreateAssignment
              ? isAr
                ? 'اضغط على زر «إضافة واجب جديد للطلاب» لإنشاء واجب منزلي وإرسال إشعار فوري للطلاب وأولياء الأمور.'
                : 'Click New Assignment to publish homework for students.'
              : isAr
              ? 'سيظهر هنا أي واجب منزلي يقوم المعلم بنشره فور إضافته مع تنبيهك فوراً.'
              : 'Published homework assignments will appear here automatically.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredAssignments.map((asg) => {
            const subs = submissionsByAssignment[asg.id] || [];
            const mySub = isStudent ? getMySubmission(asg.id) : undefined;
            const canEditThis = canTeacherManageAssignment(asg, currentUser, teachers);

            return (
              <div
                key={asg.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between gap-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[11px] font-cairo font-bold">
                        {asg.subject}
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-tajawal">
                        {asg.grade}
                      </span>
                    </div>

                    {isStudent && mySub ? (
                      mySub.status === 'graded' ? (
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-cairo font-bold shrink-0">
                          {isAr
                            ? `تم التصحيح: ${mySub.score ?? 0}/${asg.maxMarks}`
                            : `Graded: ${mySub.score ?? 0}/${asg.maxMarks}`}
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-lg bg-blue-600 text-white text-[11px] font-cairo font-bold shrink-0">
                          {isAr ? 'تم التسليم ✓' : 'Submitted ✓'}
                        </span>
                      )
                    ) : isStudent ? (
                      <span className="px-2.5 py-1 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[11px] font-cairo font-bold shrink-0">
                        {isAr ? 'جديد • بانتظار الحل' : 'Pending'}
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-[11px] font-cairo font-bold shrink-0 font-mono-numbers">
                        {subs.length} {isAr ? 'تسليم' : 'subs'}
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white leading-snug">
                      {asg.title}
                    </h3>
                    {asg.lessonTitle && (
                      <p className="text-[11px] text-emerald-700 dark:text-emerald-400 font-tajawal mt-1 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        <span>
                          {isAr ? 'مرتبط بدرس:' : 'Lesson:'} {asg.lessonTitle}
                        </span>
                      </p>
                    )}
                    {asg.description && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal line-clamp-2 mt-1.5">
                        {asg.description}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                    <div className="flex items-center gap-1.5">
                      <GraduationCap className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="truncate">{asg.teacherName}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono-numbers">
                      <Calendar className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>
                        {isAr ? 'التسليم:' : 'Due:'} {asg.dueDate}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono-numbers">
                      <Award className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      <span>
                        {isAr ? 'الدرجة:' : 'Marks:'} {asg.maxMarks}
                      </span>
                    </div>
                    {asg.attachmentName && (
                      <div className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400">
                        <Paperclip className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{asg.attachmentName}</span>
                      </div>
                    )}
                  </div>

                  {isStudent && (mySub?.feedback || mySub?.annotatedImageUrl || mySub?.voiceFeedbackUrl) && (
                    <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-[11px] font-tajawal text-emerald-900 dark:text-emerald-200 space-y-2">
                      {mySub.feedback && (
                        <div>
                          <strong className="font-cairo">{isAr ? 'ملاحظة المعلم:' : 'Feedback:'}</strong>{' '}
                          {mySub.feedback}
                        </div>
                      )}
                      {mySub.annotatedImageUrl && (
                        <button
                          type="button"
                          onClick={() => setPreviewAnnotatedUrl(mySub.annotatedImageUrl || null)}
                          className="w-full py-1.5 px-2.5 rounded-lg bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300 font-cairo font-bold text-[11px] flex items-center justify-center gap-1.5 hover:bg-emerald-100/50 cursor-pointer"
                        >
                          <PenTool className="w-3.5 h-3.5 text-emerald-600" />
                          <span>عرض ورقة الواجب المصححة بالرسم (✓ / ✗)</span>
                        </button>
                      )}
                      {mySub.voiceFeedbackUrl && (
                        <div className="space-y-1">
                          <span className="font-cairo font-bold text-[10px] text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                            <Volume2 className="w-3 h-3" />
                            تعليق صوتي من المعلم:
                          </span>
                          <audio controls src={mySub.voiceFeedbackUrl} className="w-full h-8" />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Action Footer */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setViewingAssignment(asg)}
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isAr ? 'التفاصيل' : 'Details'}</span>
                  </button>

                  {isStudent ? (
                    <button
                      type="button"
                      onClick={() => openSolveModal(asg)}
                      className={`px-3.5 py-2 rounded-xl font-cairo font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer ${
                        mySub
                          ? 'bg-blue-600 hover:bg-blue-700 text-white'
                          : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                      }`}
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>
                        {mySub
                          ? mySub.status === 'graded'
                            ? isAr
                              ? 'عرض حلي والدرجة'
                              : 'View Grade'
                            : isAr
                            ? 'تعديل الحل المسلم'
                            : 'Update Solution'
                          : isAr
                          ? 'حل وتسليم الواجب'
                          : 'Solve & Submit'}
                      </span>
                    </button>
                  ) : isParent ? (
                    <span className="text-[11px] font-cairo font-bold text-slate-400">
                      {isAr ? 'قراءة ومتابعة فقط' : 'Read-Only'}
                    </span>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      {canCreateAssignment && (
                        <>
                          <button
                            type="button"
                            onClick={() => openGradingModal(asg, false)}
                            className="px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>
                              {isAr ? 'التسليمات' : 'Submissions'} ({subs.length})
                            </span>
                          </button>
                          {subs.length > 0 && (
                            <button
                              type="button"
                              onClick={() => openGradingModal(asg, true)}
                              title={isAr ? 'التصحيح السريع للأسئلة المقالية والصور' : 'Speed Grader'}
                              className="px-2.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-cairo font-bold text-xs flex items-center gap-1 cursor-pointer"
                            >
                              <Zap className="w-3.5 h-3.5" />
                              <span>{isAr ? 'تصحيح سريع' : 'Speed'}</span>
                            </button>
                          )}
                        </>
                      )}
                      {canEditThis && (
                        <>
                          <button
                            type="button"
                            onClick={() => openEditModal(asg)}
                            title={isAr ? 'تعديل الواجب' : 'Edit'}
                            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setAssignmentToDelete(asg)}
                            title={isAr ? 'حذف الواجب' : 'Delete'}
                            className="p-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ================= MODAL: CREATE / EDIT ASSIGNMENT (TEACHER & ADMIN ONLY) ================= */}
      {isFormOpen && canCreateAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-5 bg-emerald-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <BookCheck className="w-5 h-5 text-amber-300" />
                <h3 className="font-cairo font-bold text-base md:text-lg">
                  {editingAssignment
                    ? isAr
                      ? 'تعديل بيانات الواجب المنزلي'
                      : 'Edit Assignment'
                    : isAr
                    ? 'إضافة واجب منزلي جديد للطلاب والطالبات'
                    : 'Create New Homework Assignment'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAssignment} className="p-5 overflow-y-auto space-y-4 text-xs md:text-sm">
              <div>
                <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'عنوان الواجب المنزلي *' : 'Assignment Title *'}
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder={isAr ? 'مثال: واجب تطبيقات التفاضل - الدرس الأول' : 'Assignment title...'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-tajawal"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المادة الدراسية' : 'Subject'}
                  </label>
                  <select
                    value={formSubject}
                    onChange={(e) => setFormSubject(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                  >
                    {SUBJECTS.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المرحلة الدراسية' : 'Grade'}
                  </label>
                  <select
                    value={formGrade}
                    onChange={(e) => setFormGrade(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                  >
                    {GRADES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'ربط بدرس موجود (اختياري)' : 'Link to Lesson (Optional)'}
                  </label>
                  <select
                    value={formLessonId}
                    onChange={(e) => setFormLessonId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                  >
                    <option value="">{isAr ? '— بدون ربط بدرس محدد —' : '— None —'}</option>
                    {lessons.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.title} ({l.subject})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المعلم واضع الواجب' : 'Teacher'}
                  </label>
                  {isTeacher ? (
                    <input
                      type="text"
                      readOnly
                      value={matchedTeacher?.name || currentUser?.name || 'المعلم'}
                      className="w-full px-3 py-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 font-cairo font-bold"
                    />
                  ) : (
                    <select
                      value={formTeacherId}
                      onChange={(e) => {
                        const tid = e.target.value;
                        setFormTeacherId(tid);
                        const found = teachers.find((t) => t.id === tid);
                        if (found) setFormTeacherName(found.name);
                      }}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                    >
                      {teachers.length === 0 && (
                        <option value="">{currentUser?.name || 'الإدارة'}</option>
                      )}
                      {teachers.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.specialty})
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'آخر موعد للتسليم' : 'Due Date'}
                  </label>
                  <input
                    type="date"
                    required
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'الدرجة النهائية للواجب' : 'Max Marks'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={formMaxMarks}
                    onChange={(e) => setFormMaxMarks(Number(e.target.value))}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'الوحدة / الفصل' : 'Unit'}
                  </label>
                  <input
                    type="text"
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    placeholder={isAr ? 'الوحدة الأولى' : 'Unit 1'}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                  />
                </div>
              </div>

              <div>
                <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'وصف مختصر للواجب' : 'Short Description'}
                </label>
                <input
                  type="text"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder={isAr ? 'ملخص الأهداف المطلوبة من الطالب والطالبة' : 'Summary...'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                />
              </div>

              <div>
                <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'أسئلة وتعليمات الواجب بالتفصيل' : 'Questions & Instructions'}
                </label>
                <textarea
                  rows={4}
                  value={formInstructions}
                  onChange={(e) => setFormInstructions(e.target.value)}
                  placeholder={
                    isAr
                      ? 'اكتب أسئلة الواجب أو المسائل المطلوب حلها بالتفصيل...'
                      : 'Write homework questions and instructions...'
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2">
                <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 text-xs">
                  {isAr ? 'إرفاق ورقة عمل / ملف PDF أو صورة (اختياري)' : 'Attachment (Optional)'}
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <label className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer">
                    <FileUp className="w-3.5 h-3.5" />
                    <span>{isAr ? 'رفع ملف من الجهاز' : 'Upload File'}</span>
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.webp"
                      onChange={(e) => handleFileUpload(e, 'assignment')}
                      className="hidden"
                    />
                  </label>
                  {formAttachmentName && (
                    <span className="text-xs font-tajawal text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                      <Paperclip className="w-3.5 h-3.5" />
                      {formAttachmentName}
                      <button
                        type="button"
                        onClick={() => {
                          setFormAttachmentUrl('');
                          setFormAttachmentName('');
                        }}
                        className="text-rose-500 hover:underline mr-1 cursor-pointer"
                      >
                        ✕
                      </button>
                    </span>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-cairo font-bold text-xs cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {isSaving
                      ? isAr
                        ? 'جارِ الحفظ...'
                        : 'Saving...'
                      : editingAssignment
                      ? isAr
                        ? 'حفظ تعديلات الواجب'
                        : 'Save Changes'
                      : isAr
                      ? 'نشر الواجب وإشعار الطلاب وأولياء الأمور'
                      : 'Publish & Notify'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: VIEW ASSIGNMENT DETAILS (READ-ONLY FOR ALL) ================= */}
      {viewingAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2.5 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[11px] font-cairo font-bold">
                    {viewingAssignment.subject}
                  </span>
                  <span className="text-[11px] text-slate-500 font-tajawal">
                    {viewingAssignment.grade}
                  </span>
                </div>
                <h3 className="font-cairo font-bold text-lg text-slate-900 dark:text-white">
                  {viewingAssignment.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setViewingAssignment(null)}
                className="p-1.5 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-sm font-tajawal">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs">
                <div>
                  <span className="text-slate-400 block">{isAr ? 'المعلم' : 'Teacher'}</span>
                  <strong className="font-cairo text-slate-900 dark:text-white">
                    {viewingAssignment.teacherName}
                  </strong>
                </div>
                <div>
                  <span className="text-slate-400 block">{isAr ? 'آخر موعد للتسليم' : 'Due Date'}</span>
                  <strong className="font-mono-numbers text-slate-900 dark:text-white">
                    {viewingAssignment.dueDate}
                  </strong>
                </div>
                <div>
                  <span className="text-slate-400 block">{isAr ? 'الدرجة الكلية' : 'Max Marks'}</span>
                  <strong className="font-mono-numbers text-emerald-700 dark:text-emerald-300">
                    {viewingAssignment.maxMarks} {isAr ? 'درجة' : 'pts'}
                  </strong>
                </div>
              </div>

              {viewingAssignment.description && (
                <div>
                  <h4 className="font-cairo font-bold text-xs text-slate-500 mb-1">
                    {isAr ? 'وصف الواجب:' : 'Description:'}
                  </h4>
                  <p className="text-slate-700 dark:text-slate-200">{viewingAssignment.description}</p>
                </div>
              )}

              <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 space-y-1.5">
                <h4 className="font-cairo font-bold text-xs text-amber-900 dark:text-amber-200">
                  {isAr ? 'الأسئلة والتعليمات المطلوبة:' : 'Questions & Instructions:'}
                </h4>
                <p className="whitespace-pre-wrap text-slate-800 dark:text-slate-100 leading-relaxed text-xs md:text-sm">
                  {viewingAssignment.instructions || viewingAssignment.description || (isAr ? 'لا توجد تعليمات إضافية' : 'No extra instructions')}
                </p>
              </div>

              {viewingAssignment.attachmentUrl && (
                <a
                  href={viewingAssignment.attachmentUrl}
                  download={viewingAssignment.attachmentName || 'assignment-file'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {isAr ? 'تنزيل مرفق الواجب:' : 'Download Attachment:'}{' '}
                    {viewingAssignment.attachmentName || 'ملف'}
                  </span>
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: STUDENT SOLVE & SUBMIT HOMEWORK ================= */}
      {solvingAssignment && isStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-5 bg-emerald-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Send className="w-5 h-5 text-amber-300" />
                <div>
                  <h3 className="font-cairo font-bold text-base">
                    {isAr ? 'حل وتسليم الواجب المنزلي' : 'Submit Homework Solution'}
                  </h3>
                  <p className="text-xs text-emerald-100 font-tajawal">{solvingAssignment.title}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSolvingAssignment(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitSolution} className="p-5 overflow-y-auto space-y-4 text-xs md:text-sm">
              {(() => {
                const sub = getMySubmission(solvingAssignment.id);
                if (sub?.status === 'graded' || sub?.annotatedImageUrl || sub?.voiceFeedbackUrl) {
                  return (
                    <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 space-y-2.5">
                      <p className="font-cairo font-black text-emerald-800 dark:text-emerald-200">
                        {isAr
                          ? `الدرجة المرصودة: ${sub.score ?? 0} من ${solvingAssignment.maxMarks}`
                          : `Score: ${sub.score ?? 0} / ${solvingAssignment.maxMarks}`}
                      </p>
                      {sub.feedback && (
                        <p className="font-tajawal text-emerald-700 dark:text-emerald-300">
                          <strong>{isAr ? 'تعليق المعلم:' : 'Teacher Notes:'}</strong> {sub.feedback}
                        </p>
                      )}
                      {sub.voiceFeedbackUrl && (
                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 space-y-1">
                          <span className="text-xs font-cairo font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                            <Volume2 className="w-4 h-4 text-emerald-600" />
                            ملاحظة المعلم الصوتية المسجلة لك:
                          </span>
                          <audio controls src={sub.voiceFeedbackUrl} className="w-full h-9" />
                        </div>
                      )}
                      {sub.annotatedImageUrl && (
                        <div className="space-y-1.5">
                          <span className="text-xs font-cairo font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                            <PenTool className="w-4 h-4 text-emerald-600" />
                            ورقة إجابتك بعد تصحيح المعلم بالرسم (✓ صح / ✗ خطأ):
                          </span>
                          <img
                            src={sub.annotatedImageUrl}
                            alt="Graded Homework Sheet"
                            onClick={() => setPreviewAnnotatedUrl(sub.annotatedImageUrl || null)}
                            className="w-full max-h-64 object-contain rounded-xl border-2 border-emerald-400 bg-white cursor-pointer"
                          />
                        </div>
                      )}
                    </div>
                  );
                }
                return null;
              })()}

              {solvingAssignment.instructions && (
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <p className="font-cairo font-bold text-xs text-slate-600 dark:text-slate-300 mb-1">
                    {isAr ? 'المطلوب في الواجب:' : 'Prompt:'}
                  </p>
                  <p className="font-tajawal text-xs whitespace-pre-wrap text-slate-800 dark:text-slate-100">
                    {solvingAssignment.instructions}
                  </p>
                </div>
              )}

              <div>
                <label className="block font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'إجابتك / حل الواجب:' : 'Your Solution:'}
                </label>
                <textarea
                  rows={5}
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder={isAr ? 'اكتب الحل بالتفصيل هنا...' : 'Write your answer...'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-tajawal text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2">
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                  {isAr ? 'إرفاق ملف الحل أو صورة الدفتر (اختياري):' : 'Attach Solution File (Optional):'}
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <label className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer">
                    <FileUp className="w-3.5 h-3.5" />
                    <span>{isAr ? 'اختيار ملف / صورة' : 'Choose File'}</span>
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.webp"
                      onChange={(e) => handleFileUpload(e, 'submission')}
                      className="hidden"
                    />
                  </label>
                  {studentFileName && (
                    <span className="text-xs font-tajawal text-emerald-700 dark:text-emerald-300">
                      {studentFileName}
                    </span>
                  )}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSolvingAssignment(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 font-cairo font-bold text-xs cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingSolution}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>
                    {isSubmittingSolution
                      ? isAr
                        ? 'جارِ التسليم...'
                        : 'Submitting...'
                      : isAr
                      ? 'إرسال وتسليم الحل الآن'
                      : 'Submit Solution'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: TEACHER SUBMISSIONS & SPEED GRADER ================= */}
      {gradingAssignment && canCreateAssignment && (() => {
        const allSubs = submissionsByAssignment[gradingAssignment.id] || [];
        const pendingSubs = allSubs.filter((s) => s.status !== 'graded');
        const speedQueue = speedFilter === 'pending' && pendingSubs.length > 0 ? pendingSubs : allSubs;
        const safeIdx = Math.min(speedGraderIdx, Math.max(0, speedQueue.length - 1));
        const activeSpeedSub = speedQueue[safeIdx];
        const maxM = Number(gradingAssignment.maxMarks) || 20;

        const CANNED_FEEDBACK = [
          'حل نموذجي ومرتب ✓',
          'إجابة واضحة — أحسنت 🌟',
          'يرجى توضيح خطوات الحل أكثر',
          'راجع التعويض العددي والوحدات',
        ];

        const isImageUrl = (url?: string, name?: string) =>
          Boolean(
            url &&
              (url.startsWith('data:image/') ||
                /\.(png|jpg|jpeg|webp|gif)$/i.test(name || url))
          );

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
            <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
              <div className="p-5 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <UserCheck className="w-5 h-5 text-amber-400" />
                  <div>
                    <h3 className="font-cairo font-bold text-base">
                      {isSpeedGraderMode
                        ? isAr
                          ? 'المصحح السريع للأسئلة المقالية والحل اليدوي'
                          : 'Essay & Photo Speed Grader'
                        : isAr
                        ? 'تسليمات الطلاب والطالبات والتصحيح'
                        : 'Student Submissions & Grading'}
                    </h3>
                    <p className="text-xs text-slate-300 font-tajawal">
                      {gradingAssignment.title} • {isAr ? 'الدرجة النهائية:' : 'Max:'}{' '}
                      <span className="font-mono-numbers">{gradingAssignment.maxMarks}</span> •{' '}
                      <span className="font-mono-numbers">
                        {pendingSubs.length} {isAr ? 'بانتظار التصحيح' : 'pending'}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {allSubs.length > 0 && (
                    <div className="flex items-center p-1 rounded-xl bg-white/10 border border-white/15 text-xs font-cairo">
                      <button
                        type="button"
                        onClick={() => setIsSpeedGraderMode(false)}
                        className={`px-3 py-1 rounded-lg font-bold cursor-pointer transition-colors ${
                          !isSpeedGraderMode ? 'bg-white text-slate-900' : 'text-slate-200 hover:text-white'
                        }`}
                      >
                        {isAr ? 'كل التسليمات' : 'List View'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsSpeedGraderMode(true);
                          setSpeedGraderIdx(0);
                        }}
                        className={`px-3 py-1 rounded-lg font-bold cursor-pointer flex items-center gap-1 transition-colors ${
                          isSpeedGraderMode ? 'bg-amber-400 text-slate-950' : 'text-slate-200 hover:text-white'
                        }`}
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>{isAr ? 'المصحح السريع' : 'Speed Grader'}</span>
                      </button>
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setGradingAssignment(null);
                      setIsSpeedGraderMode(false);
                    }}
                    className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="p-5 overflow-y-auto space-y-4">
                {allSubs.length === 0 ? (
                  <div className="p-8 text-center text-slate-500 dark:text-slate-400 font-tajawal text-sm">
                    {isAr
                      ? 'لم يقم أي طالب أو طالبة بتسليم حل هذا الواجب حتى الآن.'
                      : 'No submissions yet.'}
                  </div>
                ) : isSpeedGraderMode && activeSpeedSub ? (
                  (() => {
                    const draft = gradingDrafts[activeSpeedSub.id] || {
                      score: String(activeSpeedSub.score ?? gradingAssignment.maxMarks),
                      feedback: activeSpeedSub.feedback || '',
                    };
                    const pctPresets = [100, 85, 70, 50, 0];

                    return (
                      <div className="space-y-4">
                        {/* Queue Navigation Bar */}
                        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setSpeedFilter('pending')}
                              className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold cursor-pointer ${
                                speedFilter === 'pending'
                                  ? 'bg-amber-500 text-slate-950'
                                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              {isAr ? `غير المصحح (${pendingSubs.length})` : `Pending (${pendingSubs.length})`}
                            </button>
                            <button
                              type="button"
                              onClick={() => setSpeedFilter('all')}
                              className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold cursor-pointer ${
                                speedFilter === 'all'
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              {isAr ? `الكل (${allSubs.length})` : `All (${allSubs.length})`}
                            </button>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              disabled={safeIdx <= 0}
                              onClick={() => setSpeedGraderIdx((p) => Math.max(0, p - 1))}
                              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </button>
                            <span className="text-xs font-cairo font-bold font-mono-numbers px-2">
                              {safeIdx + 1} / {speedQueue.length}
                            </span>
                            <button
                              type="button"
                              disabled={safeIdx >= speedQueue.length - 1}
                              onClick={() => setSpeedGraderIdx((p) => Math.min(speedQueue.length - 1, p + 1))}
                              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
                            >
                              <ChevronLeft className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* Two-Column Speed Grader Workspace */}
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                          {/* Left: Student Answer & Handwritten Image Preview */}
                          <div className="lg:col-span-7 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 space-y-3">
                            <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-200 dark:border-slate-700">
                              <div>
                                <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                                  {activeSpeedSub.studentName}
                                  {activeSpeedSub.studentCode && (
                                    <span className="text-xs text-slate-500 font-mono-numbers mr-2">
                                      ({activeSpeedSub.studentCode})
                                    </span>
                                  )}
                                </h4>
                                <p className="text-[11px] text-slate-500 font-tajawal">{activeSpeedSub.submittedAt}</p>
                              </div>
                              <span
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold ${
                                  activeSpeedSub.status === 'graded'
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                }`}
                              >
                                {activeSpeedSub.status === 'graded'
                                  ? `مصصح (${activeSpeedSub.score}/${maxM})`
                                  : 'بانتظار التصحيح'}
                              </span>
                            </div>

                            {activeSpeedSub.answerText ? (
                              <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm font-tajawal whitespace-pre-wrap leading-relaxed text-slate-900 dark:text-slate-100 max-h-60 overflow-y-auto">
                                {activeSpeedSub.answerText}
                              </div>
                            ) : (
                              <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-900/50 text-xs text-slate-500 font-tajawal">
                                {isAr ? 'لم يكتب الطالب نصاً إضافياً (مرفق ملف/صورة أدناه).' : 'No typed essay text.'}
                              </div>
                            )}

                            {isImageUrl(activeSpeedSub.attachmentUrl || undefined, activeSpeedSub.attachmentName || undefined) && (
                              <div className="space-y-1.5">
                                <span className="text-[11px] font-cairo font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1">
                                  <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                                  <span>{isAr ? 'صورة الحل اليدوي للطالب:' : 'Student Handwritten Photo:'}</span>
                                </span>
                                <img
                                  src={draft.annotatedImageUrl || activeSpeedSub.attachmentUrl || undefined}
                                  alt={activeSpeedSub.studentName}
                                  onClick={() =>
                                    setPreviewAnnotatedUrl(draft.annotatedImageUrl || activeSpeedSub.attachmentUrl || null)
                                  }
                                  className="w-full max-h-72 object-contain rounded-xl border border-slate-200 dark:border-slate-700 bg-white cursor-zoom-in"
                                />
                              </div>
                            )}

                            {activeSpeedSub.attachmentUrl && (
                              <div className="flex flex-wrap items-center gap-2 pt-1">
                                <button
                                  type="button"
                                  onClick={() => openVisualGradingCanvas(activeSpeedSub)}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                                >
                                  <PenTool className="w-3.5 h-3.5" />
                                  <span>{isAr ? 'فتح لوحة التصحيح بالرسم (✓ / ✗)' : 'Annotate on Paper'}</span>
                                </button>
                                <a
                                  href={activeSpeedSub.attachmentUrl}
                                  download={activeSpeedSub.attachmentName || 'student-solution'}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-cairo font-bold text-blue-600 hover:underline flex items-center gap-1"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                  <span>{activeSpeedSub.attachmentName || 'تنزيل المرفق'}</span>
                                </a>
                              </div>
                            )}
                          </div>

                          {/* Right: Quick Rubric, Score Presets & Canned Feedback */}
                          <div className="lg:col-span-5 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 flex flex-col justify-between">
                            <div className="space-y-3">
                              <div>
                                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                  {isAr ? `تقدير سريع للدرجة (من ${maxM})` : `Quick Score (/${maxM})`}
                                </label>
                                <div className="flex flex-wrap gap-1.5 mb-2">
                                  {pctPresets.map((pct) => {
                                    const val = Math.round((maxM * pct) / 100);
                                    const active = Number(draft.score) === val;
                                    return (
                                      <button
                                        key={pct}
                                        type="button"
                                        onClick={() =>
                                          setGradingDrafts((prev) => ({
                                            ...prev,
                                            [activeSpeedSub.id]: { ...draft, score: String(val) },
                                          }))
                                        }
                                        className={`px-2.5 py-1.5 rounded-xl text-xs font-mono-numbers font-bold cursor-pointer border transition-colors ${
                                          active
                                            ? 'bg-emerald-700 text-white border-emerald-700'
                                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-emerald-50'
                                        }`}
                                      >
                                        {pct}% ({val})
                                      </button>
                                    );
                                  })}
                                </div>
                                <input
                                  type="number"
                                  min={0}
                                  max={maxM}
                                  value={draft.score}
                                  onChange={(e) =>
                                    setGradingDrafts((prev) => ({
                                      ...prev,
                                      [activeSpeedSub.id]: { ...draft, score: e.target.value },
                                    }))
                                  }
                                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-base font-mono-numbers font-bold text-slate-900 dark:text-white"
                                />
                              </div>

                              <div>
                                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                  {isAr ? 'ملاحظات سريعة جاهزة' : 'Quick Feedback Chips'}
                                </label>
                                <div className="flex flex-wrap gap-1.5 mb-2">
                                  {CANNED_FEEDBACK.map((phrase) => (
                                    <button
                                      key={phrase}
                                      type="button"
                                      onClick={() =>
                                        setGradingDrafts((prev) => ({
                                          ...prev,
                                          [activeSpeedSub.id]: {
                                            ...draft,
                                            feedback: draft.feedback ? `${draft.feedback} — ${phrase}` : phrase,
                                          },
                                        }))
                                      }
                                      className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 text-[11px] font-tajawal text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 cursor-pointer"
                                    >
                                      + {phrase}
                                    </button>
                                  ))}
                                </div>
                                <textarea
                                  rows={3}
                                  value={draft.feedback}
                                  onChange={(e) =>
                                    setGradingDrafts((prev) => ({
                                      ...prev,
                                      [activeSpeedSub.id]: { ...draft, feedback: e.target.value },
                                    }))
                                  }
                                  placeholder={isAr ? 'اكتب توجيه المعلم للطالب...' : 'Teacher feedback...'}
                                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-tajawal"
                                />
                              </div>
                            </div>

                            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                              <button
                                type="button"
                                disabled={savingGradeId === activeSpeedSub.id}
                                onClick={() => handleSpeedSaveAndNext(activeSpeedSub.id, speedQueue.length)}
                                className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                                <span>
                                  {savingGradeId === activeSpeedSub.id
                                    ? isAr
                                      ? 'جارٍ الحفظ...'
                                      : 'Saving...'
                                    : safeIdx < speedQueue.length - 1
                                    ? isAr
                                      ? 'اعتماد الدرجة والانتقال للتالي'
                                      : 'Save & Next'
                                    : isAr
                                    ? 'اعتماد الدرجة النهائية'
                                    : 'Save Final Grade'}
                                </span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  allSubs.map((sub) => {
                    const draft = gradingDrafts[sub.id] || {
                      score: String(sub.score ?? gradingAssignment.maxMarks),
                      feedback: sub.feedback || '',
                    };
                    return (
                      <div
                        key={sub.id}
                        className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <p className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                              {sub.studentName}
                              {sub.studentCode && (
                                <span className="text-xs text-slate-500 font-mono-numbers mr-2">
                                  ({sub.studentCode})
                                </span>
                              )}
                            </p>
                            <p className="text-[11px] text-slate-500 font-tajawal flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3" />
                              <span>{sub.submittedAt}</span>
                            </p>
                          </div>

                          <span
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold ${
                              sub.status === 'graded'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            }`}
                          >
                            {sub.status === 'graded'
                              ? isAr
                                ? `مصصح (${sub.score}/${gradingAssignment.maxMarks})`
                                : 'Graded'
                              : isAr
                              ? 'بانتظار التصحيح'
                              : 'Needs Grading'}
                          </span>
                        </div>

                        {sub.answerText && (
                          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-tajawal whitespace-pre-wrap text-slate-800 dark:text-slate-100">
                            {sub.answerText}
                          </div>
                        )}

                        {sub.attachmentUrl && (
                          <a
                            href={sub.attachmentUrl}
                            download={sub.attachmentName || 'student-solution'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-xs font-cairo font-bold text-blue-600 hover:underline"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>
                              {isAr ? 'تنزيل مرفق الطالب:' : 'Download student file:'}{' '}
                              {sub.attachmentName || 'ملف الحل'}
                            </span>
                          </a>
                        )}

                        {/* Teacher Visual Drawing & Voice Comment Toolbar */}
                        <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800/60 space-y-2.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="text-[11px] font-cairo font-black text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                              <PenTool className="w-3.5 h-3.5 text-emerald-600" />
                              أدوات المعلم المتقدمة: تصحيح الورقة بالرسم (✓ / ✗) والتعليق الصوتي
                            </span>
                            <div className="flex flex-wrap items-center gap-2">
                              <button
                                type="button"
                                onClick={() => openVisualGradingCanvas(sub)}
                                className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                              >
                                <PenTool className="w-3.5 h-3.5" />
                                <span>تصحيح الورقة بالرسم (✓ صح / ✗ خطأ)</span>
                              </button>

                              {recordingSubId === sub.id ? (
                                <button
                                  type="button"
                                  onClick={handleStopVoiceRecording}
                                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 animate-pulse cursor-pointer"
                                >
                                  <Square className="w-3.5 h-3.5 fill-white" />
                                  <span>إيقاف وحفظ التسجيل ({recordingSeconds} ث)</span>
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleStartVoiceRecording(sub.id)}
                                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                                >
                                  <Mic className="w-3.5 h-3.5" />
                                  <span>تسجيل ملاحظة صوتية للطالب</span>
                                </button>
                              )}

                              <label className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-cairo font-bold text-[11px] flex items-center gap-1 cursor-pointer">
                                <FileUp className="w-3 h-3" />
                                <span>رفع صوت</span>
                                <input
                                  type="file"
                                  accept="audio/*"
                                  onChange={(e) => handleUploadVoiceFile(e, sub.id)}
                                  className="hidden"
                                />
                              </label>
                            </div>
                          </div>

                          {(draft.annotatedImageUrl || draft.voiceFeedbackUrl) && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                              {draft.annotatedImageUrl && (
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-300">
                                    <span>✓ تم تجهيز ورقة الواجب المصححة بالرسم</span>
                                    <button
                                      type="button"
                                      onClick={() => setPreviewAnnotatedUrl(draft.annotatedImageUrl || null)}
                                      className="underline cursor-pointer"
                                    >
                                      تكبير الورقة
                                    </button>
                                  </div>
                                  <img
                                    src={draft.annotatedImageUrl}
                                    alt="Annotated Sheet"
                                    onClick={() => setPreviewAnnotatedUrl(draft.annotatedImageUrl || null)}
                                    className="w-full h-28 object-contain rounded-lg border border-emerald-300 bg-white cursor-pointer"
                                  />
                                </div>
                              )}

                              {draft.voiceFeedbackUrl && (
                                <div className="space-y-1.5 flex flex-col justify-center">
                                  <div className="flex items-center justify-between text-[11px] font-cairo font-bold text-indigo-700 dark:text-indigo-300">
                                    <span className="flex items-center gap-1">
                                      <Volume2 className="w-3.5 h-3.5" />
                                      ملاحظة المعلم الصوتية جاهزة للإرسال
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setGradingDrafts((prev) => ({
                                          ...prev,
                                          [sub.id]: { ...draft, voiceFeedbackUrl: null, voiceDurationSec: null },
                                        }))
                                      }
                                      className="text-rose-600 text-[10px] hover:underline cursor-pointer"
                                    >
                                      حذف الصوت
                                    </button>
                                  </div>
                                  <audio controls src={draft.voiceFeedbackUrl} className="w-full h-9" />
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                          <div>
                            <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                              {isAr
                                ? `الدرجة (من ${gradingAssignment.maxMarks})`
                                : `Score (/${gradingAssignment.maxMarks})`}
                            </label>
                            <input
                              type="number"
                              min={0}
                              max={gradingAssignment.maxMarks}
                              value={draft.score}
                              onChange={(e) =>
                                setGradingDrafts((prev) => ({
                                  ...prev,
                                  [sub.id]: { ...draft, score: e.target.value },
                                }))
                              }
                              className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block text-[11px] font-cairo font-bold text-slate-500 mb-1">
                              {isAr ? 'ملاحظات وتوجيهات المعلم' : 'Teacher Feedback'}
                            </label>
                            <input
                              type="text"
                              value={draft.feedback}
                              onChange={(e) =>
                                setGradingDrafts((prev) => ({
                                  ...prev,
                                  [sub.id]: { ...draft, feedback: e.target.value },
                                }))
                              }
                              placeholder={isAr ? 'أحسنت! إجابة نموذجية...' : 'Feedback...'}
                              className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-tajawal"
                            />
                          </div>
                          <div className="flex items-end">
                            <button
                              type="button"
                              disabled={savingGradeId === sub.id}
                              onClick={() => handleSaveGrade(sub.id)}
                              className="w-full py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs cursor-pointer"
                            >
                              {savingGradeId === sub.id
                                ? isAr
                                  ? 'جارِ الحفظ...'
                                  : 'Saving...'
                                : isAr
                                ? 'اعتماد الدرجة والتصحيح'
                                : 'Save Grade'}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* ================= MODAL: TEACHER INTERACTIVE HOMEWORK PAPER DRAWING CANVAS ================= */}
      {activeDrawingSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs">
          <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[95vh] flex flex-col">
            <div className="p-4 bg-emerald-900 text-white flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <PenTool className="w-5 h-5 text-amber-300" />
                <div>
                  <h3 className="font-cairo font-bold text-sm md:text-base">
                    تصحيح ورقة الواجب بالرسم المباشر — الطالب: {activeDrawingSub.studentName}
                  </h3>
                  <p className="text-[11px] text-emerald-100 font-tajawal">
                    اضغط على أي موضع في الورقة لوضع ختم (✓ صح) أو (✗ خطأ) أو استخدم القلم الحر للتأشير على الحل
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveDrawingSub(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Canvas Tools Bar */}
            <div className="p-3 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setDrawingTool('stamp_correct')}
                  className={`px-3.5 py-2 rounded-xl font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer transition-all ${
                    drawingTool === 'stamp_correct'
                      ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-400'
                      : 'bg-white dark:bg-slate-900 text-emerald-700 border border-emerald-300'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>ختم (✓ صح)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDrawingTool('stamp_wrong')}
                  className={`px-3.5 py-2 rounded-xl font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer transition-all ${
                    drawingTool === 'stamp_wrong'
                      ? 'bg-rose-600 text-white shadow-sm ring-2 ring-rose-400'
                      : 'bg-white dark:bg-slate-900 text-rose-700 border border-rose-300'
                  }`}
                >
                  <X className="w-4 h-4" />
                  <span>ختم (✗ خطأ)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDrawingTool('pen')}
                  className={`px-3.5 py-2 rounded-xl font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer transition-all ${
                    drawingTool === 'pen'
                      ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-400'
                      : 'bg-white dark:bg-slate-900 text-blue-700 border border-blue-300'
                  }`}
                >
                  <PenTool className="w-4 h-4" />
                  <span>قلم تصحيح حر</span>
                </button>

                {drawingTool === 'pen' && (
                  <div className="flex items-center gap-1.5 px-2">
                    {[
                      { color: '#dc2626', label: 'أحمر' },
                      { color: '#16a34a', label: 'أخضر' },
                      { color: '#2563eb', label: 'أزرق' },
                    ].map((c) => (
                      <button
                        key={c.color}
                        type="button"
                        onClick={() => setPenColor(c.color)}
                        className={`w-6 h-6 rounded-full border-2 cursor-pointer ${
                          penColor === c.color ? 'border-slate-950 scale-110' : 'border-white'
                        }`}
                        style={{ backgroundColor: c.color }}
                        title={c.label}
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleUndoCanvas}
                  disabled={canvasHistory.length <= 1}
                  className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-cairo font-bold text-xs flex items-center gap-1 disabled:opacity-40 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تراجع</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveAnnotatedCanvas}
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>حفظ الورقة المصححة</span>
                </button>
              </div>
            </div>

            <div className="p-4 overflow-auto bg-slate-900/90 flex items-center justify-center flex-1">
              <canvas
                ref={canvasRef}
                width={820}
                height={560}
                onMouseDown={handleCanvasPointerDown}
                onMouseMove={handleCanvasPointerMove}
                onMouseUp={handleCanvasPointerUp}
                onMouseLeave={handleCanvasPointerUp}
                onTouchStart={handleCanvasPointerDown}
                onTouchMove={handleCanvasPointerMove}
                onTouchEnd={handleCanvasPointerUp}
                className="bg-white rounded-xl shadow-2xl max-w-full h-auto cursor-crosshair border-2 border-emerald-500/50"
              />
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: FULLSCREEN ANNOTATED HOMEWORK SHEET PREVIEW ================= */}
      {previewAnnotatedUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs"
          onClick={() => setPreviewAnnotatedUrl(null)}
        >
          <div
            className="max-w-4xl w-full bg-white dark:bg-slate-900 rounded-3xl p-4 space-y-3 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>ورقة الواجب المصححة بالرسم — منصة الشريف</span>
              </h4>
              <div className="flex items-center gap-2">
                <a
                  href={previewAnnotatedUrl}
                  download="graded-homework-alsharif.png"
                  className="px-3 py-1.5 rounded-xl bg-emerald-700 text-white font-cairo font-bold text-xs flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تنزيل الورقة</span>
                </a>
                <button
                  type="button"
                  onClick={() => setPreviewAnnotatedUrl(null)}
                  className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <img
              src={previewAnnotatedUrl}
              alt="Graded Paper"
              className="w-full max-h-[78vh] object-contain rounded-2xl border border-slate-200 bg-white"
            />
          </div>
        </div>
      )}

      {/* ================= MODAL: DELETE CONFIRMATION ================= */}
      {assignmentToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
              {isAr ? 'تأكيد حذف الواجب المنزلي' : 'Confirm Assignment Deletion'}
            </h3>
            <p className="text-xs text-slate-500 font-tajawal">
              {isAr
                ? `هل أنت متأكد من حذف الواجب "${assignmentToDelete.title}" وكافة تسليماته نهائياً؟`
                : `Permanently delete "${assignmentToDelete.title}"?`}
            </p>
            <div className="flex items-center gap-2 pt-2 font-cairo">
              <button
                type="button"
                onClick={() => setAssignmentToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
              >
                {isAr ? 'نعم، احذف الواجب' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
