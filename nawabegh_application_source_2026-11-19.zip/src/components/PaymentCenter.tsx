import React, { useState, useMemo } from 'react';
import {
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Clock,
  Plus,
  Receipt,
  Download,
  Printer,
  ShieldCheck,
  X,
  Wallet,
  Smartphone,
  Banknote,
  Search,
  Edit,
  Trash2,
  Eye,
  Filter,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { TuitionInvoice, Language } from '../types';

interface PaymentCenterProps {
  invoices: TuitionInvoice[];
  onPayInvoice: (invoiceId: string, method: 'mada' | 'visa' | 'apple_pay' | 'cash') => void;
  onAddInvoice: (invoice: Omit<TuitionInvoice, 'id' | 'status'>) => void;
  onUpdateInvoice?: (invoice: TuitionInvoice) => void;
  onDeleteInvoice?: (id: string) => void;
  language: Language;
  readOnly?: boolean;
}

export const PaymentCenter: React.FC<PaymentCenterProps> = ({
  invoices,
  onPayInvoice,
  onAddInvoice,
  onUpdateInvoice,
  onDeleteInvoice,
  language,
  readOnly = false,
}) => {
  const isAr = language === 'ar';

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'overdue' | 'pending'>('all');
  const [activeInvoiceToPay, setActiveInvoiceToPay] = useState<TuitionInvoice | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<TuitionInvoice | null>(null);
  const [isAddInvoiceOpen, setIsAddInvoiceOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<TuitionInvoice | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<TuitionInvoice | null>(null);
  const [deletingInvoiceId, setDeletingInvoiceId] = useState<string | null>(null);

  // Payment form states
  const [paymentMethod, setPaymentMethod] = useState<'apple_pay' | 'mada' | 'visa' | 'cash'>('mada');
  const [cardNumber, setCardNumber] = useState('4123 4567 8901 2345');
  const [cardHolder, setCardHolder] = useState('عبد العزيز الشمري');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('421');
  const [isProcessing, setIsProcessing] = useState(false);

  // Invoice Form (Add / Edit)
  const [formStudentName, setFormStudentName] = useState('');
  const [formGrade, setFormGrade] = useState('الصف الثالث الثانوي');
  const [formAmount, setFormAmount] = useState(800);
  const [formDueDate, setFormDueDate] = useState('2026-11-30');
  const [formDescription, setFormDescription] = useState('رسوم المقررات والدروس الشهرية');
  const [formStatus, setFormStatus] = useState<'pending' | 'paid' | 'overdue'>('pending');

  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const matchFilter = filterStatus === 'all' || inv.status === filterStatus;
      const matchSearch =
        inv.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inv.grade.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inv.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchFilter && matchSearch;
    });
  }, [invoices, filterStatus, searchQuery]);

  const totalCollected = invoices
    .filter((inv) => inv.status === 'paid')
    .reduce((sum, inv) => sum + inv.amount, 0);

  const totalOutstanding = invoices
    .filter((inv) => inv.status !== 'paid')
    .reduce((sum, inv) => sum + inv.amount, 0);

  const handleOpenAdd = () => {
    setEditingInvoice(null);
    setFormStudentName('');
    setFormGrade('الصف الثالث الثانوي');
    setFormAmount(800);
    setFormDueDate('2026-11-30');
    setFormDescription('رسوم المقررات والدروس الشهرية');
    setFormStatus('pending');
    setIsAddInvoiceOpen(true);
  };

  const handleOpenEdit = (inv: TuitionInvoice) => {
    setEditingInvoice(inv);
    setFormStudentName(inv.studentName);
    setFormGrade(inv.grade);
    setFormAmount(inv.amount);
    setFormDueDate(inv.dueDate);
    setFormDescription(inv.description);
    setFormStatus(inv.status);
    setIsAddInvoiceOpen(true);
  };

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeInvoiceToPay) return;

    setIsProcessing(true);
    setTimeout(() => {
      onPayInvoice(activeInvoiceToPay.id, paymentMethod);
      setIsProcessing(false);
      const paidInv = {
        ...activeInvoiceToPay,
        status: 'paid' as const,
        paymentMethod,
        paidDate: new Date().toISOString().split('T')[0],
      };
      setActiveInvoiceToPay(null);
      setSelectedReceipt(paidInv);

      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }, 1200);
  };

  const handleSaveInvoice = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingInvoice && onUpdateInvoice) {
      onUpdateInvoice({
        ...editingInvoice,
        studentName: formStudentName || editingInvoice.studentName,
        grade: formGrade,
        amount: Number(formAmount),
        dueDate: formDueDate,
        description: formDescription,
        status: formStatus,
      });
    } else {
      const num = `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      onAddInvoice({
        invoiceNumber: num,
        studentId: 'stu-gen',
        studentName: formStudentName || 'طالب مسجل',
        grade: formGrade,
        amount: Number(formAmount),
        currency: 'SAR',
        dueDate: formDueDate,
        description: formDescription,
      });
    }

    setIsAddInvoiceOpen(false);
    setEditingInvoice(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>{isAr ? 'منظومة الدفع الإلكتروني والرسوم الدراسية' : 'Tuition & Online Payments'}</span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 font-tajawal">
            {isAr
              ? 'إدارة كاملة للفواتير والمطالبات المالية (إضافة، تعديل، حذف، بحث، وعرض تفاصيل) متصلة بقاعدة بيانات Cloud SQL'
              : 'Full CRUD invoice management, payment gateways, and instant digital receipts synced with Cloud SQL'}
          </p>
        </div>

        {!readOnly && (
          <button
            onClick={handleOpenAdd}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm self-start md:self-auto cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'إصدار مطالبة مالية جديدة' : 'Create Invoice'}</span>
          </button>
        )}
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono-numbers">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xs">
          <div>
            <span className="text-xs text-slate-400 block font-sans">
              {isAr ? 'إجمالي المحصل الفعلي' : 'Collected Tuition'}
            </span>
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1 block">
              {totalCollected.toLocaleString()} SAR
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xs">
          <div>
            <span className="text-xs text-slate-400 block font-sans">
              {isAr ? 'المطالبات المستحقة والمتأخرة' : 'Outstanding / Due'}
            </span>
            <span className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-1 block">
              {totalOutstanding.toLocaleString()} SAR
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between shadow-xs">
          <div>
            <span className="text-xs text-slate-400 block font-sans">
              {isAr ? 'بوابات الدفع النشطة' : 'Active Gateways'}
            </span>
            <span className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-1 block font-sans">
              Mada · Apple Pay · Visa · Cash
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Search and Filter Tabs */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 right-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'ابحث برقم الفاتورة، اسم الطالب، أو بيان المطالبة...' : 'Search invoice, student name, description...'}
            className="w-full pr-9 pl-3 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-tajawal"
          />
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-x-auto">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'كافة الفواتير' : 'All'}
          </button>
          <button
            onClick={() => setFilterStatus('paid')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterStatus === 'paid'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'مسددة بنجاح' : 'Paid'}
          </button>
          <button
            onClick={() => setFilterStatus('overdue')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterStatus === 'overdue'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'متأخرة' : 'Overdue'}
          </button>
          <button
            onClick={() => setFilterStatus('pending')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterStatus === 'pending'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'مستحقة' : 'Pending'}
          </button>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs md:text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 text-xs font-cairo">
              <tr>
                <th className="py-3 px-4 font-bold">{isAr ? 'رقم الفاتورة' : 'Invoice #'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'اسم الطالب والمرحلة' : 'Student & Grade'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'المبلغ المستحق' : 'Amount'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'تاريخ الاستحقاق' : 'Due Date'}</th>
                <th className="py-3 px-4 font-bold">{isAr ? 'حالة السداد' : 'Status'}</th>
                <th className="py-3 px-4 font-bold text-center">{isAr ? 'الإجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 font-tajawal">
                    {isAr ? 'لم يتم العثور على فواتير مطابقة' : 'No matching invoices found'}
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const isPaid = inv.status === 'paid';
                  const isOverdue = inv.status === 'overdue';

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-white font-mono-numbers">
                        {inv.invoiceNumber}
                      </td>

                      <td className="py-3 px-4">
                        <p className="font-bold text-slate-800 dark:text-slate-200">{inv.studentName}</p>
                        <span className="text-[11px] text-slate-400">{inv.grade}</span>
                      </td>

                      <td className="py-3 px-4 font-mono-numbers font-black text-sm text-slate-900 dark:text-white">
                        {inv.amount} {inv.currency}
                      </td>

                      <td className="py-3 px-4 text-slate-500 font-mono-numbers">
                        {inv.dueDate}
                      </td>

                      <td className="py-3 px-4">
                        {isPaid ? (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-bold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {isAr ? 'تم السداد' : 'Paid'}
                          </span>
                        ) : isOverdue ? (
                          <span className="inline-flex items-center gap-1 text-xs text-rose-600 dark:text-rose-400 font-bold">
                            <AlertCircle className="w-3.5 h-3.5" />
                            {isAr ? 'متأخر' : 'Overdue'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 font-bold">
                            <Clock className="w-3.5 h-3.5" />
                            {isAr ? 'مستحق' : 'Pending'}
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* View Details Button */}
                          <button
                            onClick={() => setViewingInvoice(inv)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors cursor-pointer"
                            title={isAr ? 'مشاهدة تفاصيل الفاتورة' : 'View Details'}
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Quick Pay or View Receipt */}
                          {isPaid ? (
                            <button
                              onClick={() => setSelectedReceipt(inv)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                              title={isAr ? 'عرض الإيصال' : 'Receipt'}
                            >
                              <Receipt className="w-3.5 h-3.5 text-indigo-500" />
                              <span className="hidden sm:inline">{isAr ? 'الإيصال' : 'Receipt'}</span>
                            </button>
                          ) : !readOnly ? (
                            <button
                              onClick={() => setActiveInvoiceToPay(inv)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
                              title={isAr ? 'دفع إلكتروني الآن' : 'Pay Now'}
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">{isAr ? 'سداد' : 'Pay'}</span>
                            </button>
                          ) : null}

                          {/* Edit Button */}
                          {!readOnly && onUpdateInvoice && (
                            <button
                              onClick={() => handleOpenEdit(inv)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors cursor-pointer"
                              title={isAr ? 'تعديل الفاتورة' : 'Edit'}
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}

                          {/* Delete Button */}
                          {!readOnly && onDeleteInvoice && (
                            <button
                              onClick={() => setDeletingInvoiceId(inv.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                              title={isAr ? 'حذف الفاتورة' : 'Delete'}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Online Payment Checkout Modal */}
      {activeInvoiceToPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-cairo">
                  {isAr ? 'بوابة الدفع الإلكتروني الموحدة' : 'Unified Payment Checkout'}
                </h3>
                <span className="text-xs text-slate-500 font-mono-numbers">
                  {activeInvoiceToPay.invoiceNumber}
                </span>
              </div>
              <button
                onClick={() => setActiveInvoiceToPay(null)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleProcessPayment} className="p-5 overflow-y-auto space-y-4 text-xs md:text-sm">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between font-mono-numbers">
                <div>
                  <span className="text-xs text-slate-400 block font-sans">
                    {isAr ? 'المستفيد:' : 'Beneficiary:'} {activeInvoiceToPay.studentName}
                  </span>
                  <span className="text-xs text-slate-500 font-sans block mt-0.5">
                    {activeInvoiceToPay.description}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 block font-sans">
                    {isAr ? 'المبلغ' : 'Amount'}
                  </span>
                  <span className="text-xl font-black text-indigo-600 dark:text-indigo-400">
                    {activeInvoiceToPay.amount} {activeInvoiceToPay.currency}
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-2 font-cairo">
                  {isAr ? 'اختر طريقة السداد' : 'Select Payment Method'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('mada')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'mada'
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/60 text-indigo-900 dark:text-indigo-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-emerald-600" />
                    <span>Mada</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('apple_pay')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'apple_pay'
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/60 text-indigo-900 dark:text-indigo-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-slate-900 dark:text-white" />
                    <span>Apple Pay</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('visa')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'visa'
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/60 text-indigo-900 dark:text-indigo-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Wallet className="w-5 h-5 text-blue-600" />
                    <span>Visa / MC</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'cash'
                        ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/60 text-indigo-900 dark:text-indigo-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Banknote className="w-5 h-5 text-amber-600" />
                    <span>{isAr ? 'نقدي سنتر' : 'Center Cash'}</span>
                  </button>
                </div>
              </div>

              {(paymentMethod === 'mada' || paymentMethod === 'visa') && (
                <div className="space-y-3 pt-2 font-mono-numbers">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1 text-xs font-sans">
                      {isAr ? 'رقم البطاقة الائتمانية / مدى' : 'Card Number'}
                    </label>
                    <input
                      type="text"
                      required
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 mb-1 text-xs font-sans">
                        {isAr ? 'تاريخ الانتهاء' : 'Expiry'}
                      </label>
                      <input
                        type="text"
                        required
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 mb-1 text-xs font-sans">
                        CVV
                      </label>
                      <input
                        type="password"
                        required
                        maxLength={4}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'apple_pay' && (
                <div className="p-6 rounded-xl bg-black text-white text-center space-y-2">
                  <p className="font-bold text-sm">
                    {isAr ? 'الدفع بضغطة واحدة عبر Apple Pay' : 'Pay with Touch ID / Face ID'}
                  </p>
                  <p className="text-xs text-slate-400">
                    {isAr ? 'معاملة بنكية مشفرة وآمنة بنسبة 100%' : 'Encrypted with 256-bit bank security'}
                  </p>
                </div>
              )}

              {paymentMethod === 'cash' && (
                <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs leading-relaxed">
                  {isAr
                    ? 'سيتم تسجيل السداد كمدفوع نقداً في مقر المركز التعليمي (السنتر) وإصدار سند قبض إلكتروني فوري.'
                    : 'Payment will be registered as cash received at the center front desk with instant receipt.'}
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveInvoiceToPay(null)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-6 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  {isProcessing ? (
                    <span>{isAr ? 'جاري معالجة الدفع...' : 'Processing...'}</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>
                        {isAr
                          ? `تأكيد وسداد ${activeInvoiceToPay.amount} ${activeInvoiceToPay.currency}`
                          : `Confirm Pay ${activeInvoiceToPay.amount} ${activeInvoiceToPay.currency}`}
                      </span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Payment Receipt Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950/80 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white font-cairo">
                {isAr ? 'إيصال سداد إلكتروني معتمد' : 'Payment Receipt'}
              </h3>
              <p className="text-xs text-slate-500 font-mono-numbers mt-0.5">
                {selectedReceipt.invoiceNumber}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-right text-xs space-y-2 font-tajawal">
              <div className="flex justify-between">
                <span className="text-slate-400">{isAr ? 'اسم الطالب:' : 'Student:'}</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{selectedReceipt.studentName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{isAr ? 'المرحلة:' : 'Grade:'}</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{selectedReceipt.grade}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{isAr ? 'طريقة الدفع:' : 'Method:'}</span>
                <span className="font-bold text-indigo-600 uppercase font-mono-numbers">{selectedReceipt.paymentMethod || 'Online'}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 dark:border-slate-700 font-mono-numbers">
                <span className="text-slate-400 font-sans">{isAr ? 'المبلغ المسدد:' : 'Amount Paid:'}</span>
                <span className="font-black text-sm text-emerald-600">
                  {selectedReceipt.amount} {selectedReceipt.currency}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{isAr ? 'طباعة الإيصال' : 'Print'}</span>
              </button>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="flex-1 py-2 rounded-lg bg-slate-900 dark:bg-slate-800 text-white text-xs font-bold cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW DETAILS MODAL */}
      {viewingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                  {isAr ? 'تفاصيل الفاتورة والمطالبة المالية' : 'Invoice Details'}
                </h3>
                <span className="text-xs text-indigo-600 dark:text-indigo-400 font-mono-numbers font-bold">
                  {viewingInvoice.invoiceNumber}
                </span>
              </div>
              <button
                onClick={() => setViewingInvoice(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm font-tajawal">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">{isAr ? 'اسم الطالب:' : 'Student Name:'}</span>
                  <span className="font-bold text-slate-900 dark:text-white">{viewingInvoice.studentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isAr ? 'المرحلة الدراسية:' : 'Grade:'}</span>
                  <span className="text-slate-800 dark:text-slate-200">{viewingInvoice.grade}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isAr ? 'بيان المطالبة:' : 'Description:'}</span>
                  <span className="text-slate-800 dark:text-slate-200">{viewingInvoice.description}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono-numbers">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-sans">{isAr ? 'المبلغ المستحق:' : 'Amount:'}</span>
                  <span className="text-lg font-black text-indigo-600 dark:text-indigo-400">
                    {viewingInvoice.amount} {viewingInvoice.currency}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-sans">{isAr ? 'تاريخ الاستحقاق:' : 'Due Date:'}</span>
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {viewingInvoice.dueDate}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-500 font-cairo">{isAr ? 'حالة السداد:' : 'Payment Status:'}</span>
                <span>
                  {viewingInvoice.status === 'paid' ? (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-xs flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {isAr ? 'مسددة بنجاح' : 'Paid'}
                    </span>
                  ) : viewingInvoice.status === 'overdue' ? (
                    <span className="px-2.5 py-1 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 font-bold text-xs flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {isAr ? 'متأخرة السداد' : 'Overdue'}
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold text-xs flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {isAr ? 'بانتظار السداد' : 'Pending'}
                    </span>
                  )}
                </span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setViewingInvoice(null)}
                className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-cairo font-bold hover:bg-slate-200 cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EDIT INVOICE MODAL */}
      {isAddInvoiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden p-6 space-y-4 text-xs md:text-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white font-cairo text-base">
                {editingInvoice
                  ? isAr
                    ? 'تعديل بيانات المطالبة المالية'
                    : 'Edit Invoice'
                  : isAr
                  ? 'إصدار مطالبة مالية جديدة'
                  : 'Create Tuition Invoice'}
              </h3>
              <button
                onClick={() => {
                  setIsAddInvoiceOpen(false);
                  setEditingInvoice(null);
                }}
                className="cursor-pointer"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSaveInvoice} className="space-y-3 font-tajawal">
              <div>
                <label className="block font-semibold mb-1 font-cairo">{isAr ? 'اسم الطالب' : 'Student Name'}</label>
                <input
                  type="text"
                  required
                  value={formStudentName}
                  onChange={(e) => setFormStudentName(e.target.value)}
                  placeholder="مثال: عبد العزيز الشمري"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">{isAr ? 'المرحلة الدراسية' : 'Grade'}</label>
                <select
                  value={formGrade}
                  onChange={(e) => setFormGrade(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                >
                  <option value="الصف الأول الثانوي">الصف الأول الثانوي</option>
                  <option value="الصف الثاني الثانوي">الصف الثاني الثانوي</option>
                  <option value="الصف الثالث الثانوي">الصف الثالث الثانوي</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono-numbers">
                <div>
                  <label className="block font-semibold mb-1 font-sans">{isAr ? 'المبلغ (SAR)' : 'Amount'}</label>
                  <input
                    type="number"
                    required
                    value={formAmount}
                    onChange={(e) => setFormAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 font-sans">{isAr ? 'تاريخ الاستحقاق' : 'Due Date'}</label>
                  <input
                    type="date"
                    required
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">{isAr ? 'بيان المطالبة' : 'Description'}</label>
                <input
                  type="text"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="رسوم المقررات والدروس الشهرية"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>

              {editingInvoice && (
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'حالة السداد' : 'Payment Status'}</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  >
                    <option value="pending">{isAr ? 'مستحق (Pending)' : 'Pending'}</option>
                    <option value="paid">{isAr ? 'تم السداد (Paid)' : 'Paid'}</option>
                    <option value="overdue">{isAr ? 'متأخر (Overdue)' : 'Overdue'}</option>
                  </select>
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddInvoiceOpen(false);
                    setEditingInvoice(null);
                  }}
                  className="px-4 py-2 border rounded-xl text-slate-600 dark:text-slate-300 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold font-cairo cursor-pointer"
                >
                  {editingInvoice ? (isAr ? 'حفظ التعديل' : 'Save Changes') : isAr ? 'إصدار الفاتورة' : 'Issue Invoice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRM MODAL */}
      {deletingInvoiceId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف الفاتورة' : 'Delete Invoice'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr ? 'هل أنت متأكد من رغبتك في حذف هذه المطالبة المالية نهائياً؟' : 'Are you sure you want to permanently delete this invoice?'}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingInvoiceId(null)}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  if (onDeleteInvoice) onDeleteInvoice(deletingInvoiceId);
                  setDeletingInvoiceId(null);
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs cursor-pointer"
              >
                {isAr ? 'نعم، حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
