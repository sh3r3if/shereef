import React, { useState } from 'react';
import {
  Download,
  BellRing,
  BellOff,
  CheckCircle2,
  Smartphone,
  Share2,
  X,
  Send,
  ExternalLink,
} from 'lucide-react';
import { CurrentUser, Language } from '../types';
import { usePWAInstall, useOnlineStatus, usePushNotifications } from '../hooks/usePWA';

interface PWAInstallButtonProps {
  language: Language;
  currentUser?: CurrentUser | null;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  language,
  currentUser,
}) => {
  const isAr = language === 'ar';
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const {
    isSupported,
    permission,
    isSubscribed,
    isBusy,
    statusMessage,
    enablePushNotifications,
    disablePushNotifications,
    sendTestNotification,
  } = usePushNotifications(currentUser);

  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className="flex items-center gap-1.5 shrink-0">
        {/* Direct 1-click Install CTA when browser exposes beforeinstallprompt and app is not yet installed */}
        {!isInstalled && isInstallable && (
          <button
            type="button"
            onClick={install}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-[11px] sm:text-xs shadow-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
            title={isAr ? 'تثبيت المنصة كتطبيق على جهازك' : 'Install App'}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">{isAr ? 'تثبيت التطبيق' : 'Install App'}</span>
          </button>
        )}

        {/* PWA & Push Notifications Hub Button */}
        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[11px] sm:text-xs font-cairo font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            isSubscribed || permission === 'granted'
              ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
          title={isAr ? 'تطبيق الويب وإشعارات المتصفح' : 'PWA App & Push Alerts'}
        >
          {isSubscribed || permission === 'granted' ? (
            <BellRing className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          ) : (
            <Smartphone className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          )}
          <span className="hidden xl:inline">
            {isSubscribed || permission === 'granted'
              ? isAr
                ? 'التنبيهات مفعّلة'
                : 'Push Active'
              : isAr
              ? 'التطبيق والإشعارات'
              : 'App & Push'}
          </span>
        </button>
      </div>

      {/* PWA & Browser Push Notifications Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 bg-[#0c3d36] text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <img
                  src="/pwa-192x192.png"
                  alt="Nawabegh App"
                  className="w-9 h-9 rounded-xl border border-white/20 object-cover"
                />
                <div>
                  <h3 className="font-cairo font-bold text-sm sm:text-base">
                    {isAr ? 'تثبيت التطبيق وإشعارات المتصفح الفورية' : 'Install App & Browser Push'}
                  </h3>
                  <p className="text-[11px] text-emerald-100/80">
                    {isAr
                      ? 'تصفح أسرع على الجوال والكمبيوتر مع تنبيهات تعمل حتى عند إغلاق التطبيق'
                      : 'Install on mobile & desktop with background notifications'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-emerald-100 hover:text-white hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-5 max-h-[80vh] overflow-y-auto">
              {/* Section 1: App Installation Status */}
              <div className="space-y-2.5 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                    <span>{isAr ? '1. تثبيت المنصة كتطبيق مستقل (PWA)' : '1. Install Application (PWA)'}</span>
                  </h4>
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    {isInstalled
                      ? isAr
                        ? '✓ مثبّت ويعمل كتطبيق'
                        : '✓ Installed'
                      : isInstallable
                      ? isAr
                        ? 'جاهز للتثبيت الآن'
                        : 'Ready to install'
                      : isAr
                      ? 'متاح عبر المتصفح'
                      : 'Browser Ready'}
                  </span>
                </div>

                {isInstalled ? (
                  <p className="text-xs text-emerald-700 dark:text-emerald-300 leading-relaxed">
                    {isAr
                      ? 'أنت تستخدم الآن نسخة التطبيق المثبّتة بنجاح مع دعم العمل السريع وتخزين الواجهة.'
                      : 'You are currently running the installed standalone PWA.'}
                  </p>
                ) : isInstallable ? (
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <p className="text-xs text-slate-600 dark:text-slate-300 flex-1">
                      {isAr
                        ? 'أضف منصة نوابغ للشاشة الرئيسية في هاتفك أو سطح المكتب بضغطة واحدة.'
                        : 'Add the platform to your home screen or desktop in one click.'}
                    </p>
                    <button
                      type="button"
                      onClick={install}
                      className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <Download className="w-4 h-4" />
                      <span>{isAr ? 'تثبيت الآن' : 'Install Now'}</span>
                    </button>
                  </div>
                ) : isIOS ? (
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 space-y-1.5">
                    <p className="font-cairo font-bold flex items-center gap-1.5">
                      <Share2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>{isAr ? 'خطوات التثبيت على أجهزة iPhone و iPad:' : 'How to install on iOS Safari:'}</span>
                    </p>
                    <p>1. {isAr ? 'افتح المنصة في متصفح Safari واضغط على زر المشاركة (Share).' : 'Tap the Share button in Safari.'}</p>
                    <p>2. {isAr ? 'اختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen).' : 'Tap Add to Home Screen.'}</p>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-2">
                    <p>
                      {isAr
                        ? 'للتثبيت على سطح المكتب أو أندرويد، افتح المنصة في تبويب متصفح مستقل ثم اضغط أيقونة التثبيت في شريط العنوان أو قائمة المتصفح (تثبيت التطبيق).'
                        : 'Open in a standalone browser tab and click the install icon in the address bar.'}
                    </p>
                    {window.self !== window.top && (
                      <a
                        href={window.location.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-cairo font-bold hover:underline"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{isAr ? 'فتح في نافذة مستقلة للتثبيت' : 'Open in new tab to install'}</span>
                      </a>
                    )}
                  </div>
                )}
              </div>

              {/* Section 2: Browser Background Push Notifications */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <BellRing className="w-4 h-4 text-amber-600" />
                    <span>{isAr ? '2. إشعارات المتصفح في الخلفية (Web Push)' : '2. Background Browser Notifications'}</span>
                  </h4>
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    {!isSupported
                      ? isAr
                        ? 'غير مدعوم'
                        : 'Unsupported'
                      : isSubscribed || permission === 'granted'
                      ? isAr
                        ? '✓ مفعّل'
                        : '✓ Enabled'
                      : permission === 'denied'
                      ? isAr
                        ? 'مرفوض من المتصفح'
                        : 'Blocked'
                      : isAr
                      ? 'غير مفعّل بعد'
                      : 'Not Enabled'}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {isAr
                    ? 'استلم إشعارات فورية على جهازك فور نشر درس جديد، واجب منزلي، اختبار أسبوعي أو شهري، أو رسالة جديدة في الشات حتى لو كان المتصفح مغلقاً.'
                    : 'Receive instant notifications on your device for new lessons, homework, quizzes, and chat messages even when closed.'}
                </p>

                <div className="flex flex-wrap items-center gap-2 pt-1 font-cairo">
                  {!(isSubscribed || permission === 'granted') ? (
                    <button
                      type="button"
                      disabled={isBusy || !isSupported}
                      onClick={enablePushNotifications}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <BellRing className="w-4 h-4" />
                      <span>{isAr ? 'تفعيل الإشعارات الفورية' : 'Enable Push Alerts'}</span>
                    </button>
                  ) : (
                    <>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={sendTestNotification}
                        className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{isAr ? 'إرسال إشعار تجريبي الآن' : 'Send Test Notification'}</span>
                      </button>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={disablePushNotifications}
                        className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold text-xs flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                      >
                        <BellOff className="w-3.5 h-3.5" />
                        <span>{isAr ? 'إيقاف الإشعارات' : 'Disable'}</span>
                      </button>
                    </>
                  )}
                </div>

                {statusMessage && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{statusMessage}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC<{ language: Language }> = ({ language }) => {
  const isOnline = useOnlineStatus();
  const isAr = language === 'ar';

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-cairo font-bold text-white shadow-lg">
      <span>
        {isAr
          ? 'وضع عدم الاتصال — يتم عرض البيانات المخزنة مؤقتاً'
          : 'Offline Mode — Cached content active'}
      </span>
    </div>
  );
};
