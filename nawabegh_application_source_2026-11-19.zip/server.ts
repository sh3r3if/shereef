import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const archiver = require('archiver');
import * as webpush from 'web-push';
import * as repo from './src/db/repository.ts';
import { classroomRouter } from './server/classroom/classroomRoutes.ts';
import { initClassroomSocketGateway } from './server/classroom/socketGateway.ts';
import { curriculumRouter } from './server/curriculum/curriculumRoutes.ts';
import { createTeacherPdfRouter } from './server/teachers/teacherPdfRoutes.ts';
import {
  applyAdminDeviceApproval,
  evaluateDeviceAndNetworkAccess,
  extractClientNetworkContext,
  isAccountExemptFromDeviceLock,
} from './server/security/deviceGeoLockService.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use('/api', (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  next();
});

// Optional header-based RBAC guard for defense-in-depth when client sends x-user-role
function getRequestRole(req: express.Request): string {
  return String(req.headers['x-user-role'] || '').trim().toLowerCase();
}

function getRequestActor(req: express.Request) {
  return {
    role: getRequestRole(req),
    userId: decodeURIComponent(String(req.headers['x-user-id'] || '')).trim(),
    userName: decodeURIComponent(String(req.headers['x-user-name'] || '')).trim(),
    teacherId: decodeURIComponent(String(req.headers['x-teacher-id'] || '')).trim(),
  };
}

function rejectIfRole(req: express.Request, res: express.Response, forbiddenRoles: string[], messageAr: string): boolean {
  const role = getRequestRole(req);
  if (role && forbiddenRoles.includes(role)) {
    res.status(403).json({ error: messageAr });
    return true;
  }
  return false;
}

const ROLE_LABELS_AR: Record<string, string> = {
  admin: 'المدير العام',
  secretary: 'السكرتارية',
  supervisor: 'مشرف أكاديمي',
  teacher: 'معلم',
  student: 'طالب',
  female_student: 'طالبة',
  parent: 'ولي أمر',
  visitor: 'زائر',
};

async function recordSensitiveAuditLog(
  req: express.Request,
  opts: {
    action: string;
    actionAr: string;
    entityType: string;
    entityName: string;
    details: string;
    severity?: 'info' | 'warning' | 'critical';
  }
) {
  try {
    const actor = getRequestActor(req);
    const roleLabel = ROLE_LABELS_AR[actor.role] || actor.role || 'النظام';
    const performedBy = actor.userName
      ? `${actor.userName} (${roleLabel})`
      : `المدير العام (${roleLabel})`;
    const created = await repo.createAuditLog({
      action: opts.action,
      actionAr: opts.actionAr,
      entityType: opts.entityType,
      entityName: opts.entityName,
      performedBy,
      details: opts.details,
      severity: opts.severity || 'warning',
    });
    broadcastAll({ type: 'audit_log:created', log: created });
    return created;
  } catch (err) {
    console.warn('Sensitive audit log warning:', err);
    return null;
  }
}

let cachedVapidKeys: { publicKey: string; privateKey: string } | null = null;
async function ensureVapidConfig() {
  if (cachedVapidKeys) return cachedVapidKeys;
  try {
    let pub = await repo.getSystemSetting('vapid_public_key');
    let priv = await repo.getSystemSetting('vapid_private_key');
    if (!pub || !priv) {
      const generated = webpush.generateVAPIDKeys();
      pub = generated.publicKey;
      priv = generated.privateKey;
      await repo.setSystemSetting('vapid_public_key', pub);
      await repo.setSystemSetting('vapid_private_key', priv);
    }
    webpush.setVapidDetails('mailto:admin@nawabegh.edu', pub, priv);
    cachedVapidKeys = { publicKey: pub, privateKey: priv };
    return cachedVapidKeys;
  } catch (err) {
    console.warn('VAPID initialization warning:', err);
    const fallback = webpush.generateVAPIDKeys();
    webpush.setVapidDetails('mailto:admin@nawabegh.edu', fallback.publicKey, fallback.privateKey);
    cachedVapidKeys = fallback;
    return fallback;
  }
}

function doesSubMatchTarget(userRole: string, target: string): boolean {
  if (!target || target === 'all') return true;
  if (target === 'students' || target === 'weak_students' || target === 'top_students') {
    return userRole === 'student' || userRole === 'female_student';
  }
  if (target === 'parents') return userRole === 'parent';
  if (target === 'students_parents') {
    return userRole === 'student' || userRole === 'female_student' || userRole === 'parent';
  }
  if (target === 'teachers') return userRole === 'teacher';
  if (target === 'admin') {
    return userRole === 'admin' || userRole === 'supervisor' || userRole === 'secretary';
  }
  return true;
}

async function dispatchWebPushNotification(opts: {
  title: string;
  body: string;
  url?: string;
  target?: string;
  tag?: string;
}) {
  try {
    await ensureVapidConfig();
    const subs = await repo.getAllPushSubscriptions();
    if (!subs.length) return { sent: 0, failed: 0 };

    const matching = subs.filter((s) =>
      doesSubMatchTarget(String(s.userRole || 'visitor'), opts.target || 'all')
    );
    const payload = JSON.stringify({
      title: opts.title,
      body: opts.body,
      url: opts.url || '/',
      tag: opts.tag || `nw-${Date.now()}`,
      icon: '/pwa-192x192.png',
      badge: '/pwa-192x192.png',
    });

    let sent = 0;
    let failed = 0;
    await Promise.all(
      matching.map(async (sub) => {
        try {
          await webpush.sendNotification(
            {
              endpoint: sub.endpoint,
              keys: { p256dh: sub.p256dh, auth: sub.auth },
            },
            payload
          );
          sent += 1;
        } catch (err: any) {
          failed += 1;
          if (err?.statusCode === 404 || err?.statusCode === 410) {
            await repo.deletePushSubscriptionByEndpoint(sub.endpoint);
          }
        }
      })
    );
    return { sent, failed };
  } catch (err) {
    console.warn('Web Push dispatch warning:', err);
    return { sent: 0, failed: 0 };
  }
}

// Server-authoritative in-memory state for real-time synchronization
interface ServerStroke {
  id: string;
  tool: string;
  color: string;
  size: number;
  points: { x: number; y: number }[];
  text?: string;
  timestamp: number;
}

interface ServerState {
  whiteboardCode: string;
  strokes: ServerStroke[];
  timer: {
    sessionSeconds: number;
    isRunning: boolean;
    mode: 'elapsed' | 'countdown';
  };
  raisedHands: Array<{
    studentId: string;
    studentName: string;
    topic: string;
    timestamp: number;
  }>;
  studentGradeUpdates: Record<string, {
    studentId: string;
    overallScore: number;
    notes?: string;
    updatedAt: string;
    updatedBy: string;
  }>;
  chatMessages: Array<{
    id: string;
    sender: string;
    text: string;
    time: string;
  }>;
}

const realtimeState: ServerState = {
  whiteboardCode: 'NW-2026',
  strokes: [],
  timer: {
    sessionSeconds: 34 * 60 + 20,
    isRunning: true,
    mode: 'elapsed',
  },
  raisedHands: [],
  studentGradeUpdates: {},
  chatMessages: [],
};

// Periodic server-authoritative timer tick
setInterval(() => {
  if (realtimeState.timer.isRunning) {
    realtimeState.timer.sessionSeconds += 1;
  }
}, 1000);

// Attach WebSocket Server on /ws using noServer so Vite HMR upgrades on /__vite_hmr are never aborted
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (req, socket, head) => {
  try {
    const pathname = new URL(req.url || '/', 'http://localhost').pathname;
    if (pathname === '/ws') {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    }
  } catch {
    socket.destroy();
  }
});

function broadcast(message: object, senderWs?: WebSocket) {
  const payload = JSON.stringify(message);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN && client !== senderWs) {
      try {
        client.send(payload);
      } catch (err) {
        console.error('Failed to send WS message', err);
      }
    }
  });
}

function broadcastAll(message: object) {
  const payload = JSON.stringify(message);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(payload);
      } catch (err) {
        console.error('Failed to send WS message to all', err);
      }
    }
  });
}

wss.on('connection', (ws: WebSocket, req) => {
  const clientCount = wss.clients.size;
  console.log(`[WebSocket] Client connected. Total active connections: ${clientCount}`);

  // Send initial authoritative state immediately upon connection
  const initPayload = {
    type: 'init:state',
    data: {
      whiteboardCode: realtimeState.whiteboardCode,
      strokes: realtimeState.strokes,
      timer: realtimeState.timer,
      raisedHands: realtimeState.raisedHands,
      studentGradeUpdates: realtimeState.studentGradeUpdates,
      chatMessages: realtimeState.chatMessages,
      connectedClients: clientCount,
    },
  };
  ws.send(JSON.stringify(initPayload));

  // Notify everyone of updated connection count
  broadcastAll({
    type: 'presence:update',
    data: { connectedClients: clientCount },
  });

  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());
      if (!msg || !msg.type) return;

      switch (msg.type) {
        // --- 1. WHITEBOARD SYNCHRONIZATION ---
        case 'whiteboard:stroke': {
          const stroke: ServerStroke = {
            id: msg.stroke.id || `strk-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            tool: msg.stroke.tool,
            color: msg.stroke.color,
            size: msg.stroke.size,
            points: msg.stroke.points || [],
            text: msg.stroke.text,
            timestamp: Date.now(),
          };
          realtimeState.strokes.push(stroke);
          // Keep stroke limit to avoid memory bloat
          if (realtimeState.strokes.length > 500) {
            realtimeState.strokes = realtimeState.strokes.slice(-400);
          }
          broadcast({ type: 'whiteboard:stroke', stroke }, ws);
          break;
        }

        case 'whiteboard:clear': {
          realtimeState.strokes = [];
          broadcast({ type: 'whiteboard:clear' }, ws);
          break;
        }

        case 'whiteboard:undo': {
          if (realtimeState.strokes.length > 0) {
            realtimeState.strokes.pop();
          }
          broadcast({ type: 'whiteboard:undo', strokes: realtimeState.strokes }, ws);
          break;
        }

        case 'whiteboard:code_update': {
          if (msg.code) {
            realtimeState.whiteboardCode = msg.code.trim().toUpperCase();
            broadcastAll({
              type: 'whiteboard:code_update',
              code: realtimeState.whiteboardCode,
              updatedBy: msg.updatedBy || 'Mo-NewFolder',
            });
          }
          break;
        }

        case 'whiteboard:timer_update': {
          if (msg.timer) {
            realtimeState.timer = { ...realtimeState.timer, ...msg.timer };
            broadcast({ type: 'whiteboard:timer_update', timer: realtimeState.timer }, ws);
          }
          break;
        }

        // --- 2. STUDENT RAISE HAND & ATTENDEE EVENTS ---
        case 'whiteboard:hand_raise': {
          const handData = {
            studentId: msg.studentId || 'p-me',
            studentName: msg.studentName,
            topic: msg.topic || 'استفسار عام',
            timestamp: Date.now(),
          };
          // Idempotent add
          if (!realtimeState.raisedHands.find((h) => h.studentId === handData.studentId)) {
            realtimeState.raisedHands.unshift(handData);
          }
          broadcastAll({ type: 'whiteboard:hand_raise', hand: handData });
          break;
        }

        case 'whiteboard:hand_lower': {
          realtimeState.raisedHands = realtimeState.raisedHands.filter(
            (h) => h.studentId !== msg.studentId
          );
          broadcastAll({ type: 'whiteboard:hand_lower', studentId: msg.studentId });
          break;
        }

        case 'whiteboard:hand_lower_all': {
          realtimeState.raisedHands = [];
          broadcastAll({ type: 'whiteboard:hand_lower_all' });
          break;
        }

        case 'whiteboard:hand_permit': {
          realtimeState.raisedHands = realtimeState.raisedHands.filter(
            (h) => h.studentId !== msg.studentId
          );
          broadcastAll({
            type: 'whiteboard:hand_permit',
            studentId: msg.studentId,
            studentName: msg.studentName,
          });
          break;
        }

        case 'whiteboard:chat': {
          const chatMsg = {
            id: `c-${Date.now()}`,
            sender: msg.sender || 'مستخدم',
            text: msg.text,
            time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
          };
          realtimeState.chatMessages.push(chatMsg);
          if (realtimeState.chatMessages.length > 100) {
            realtimeState.chatMessages = realtimeState.chatMessages.slice(-80);
          }
          broadcastAll({ type: 'whiteboard:chat', message: chatMsg });
          break;
        }

        // --- 3. STUDENT GRADES & RECORDS SYNCHRONIZATION ---
        case 'grade:update': {
          const { studentId, overallScore, notes, updatedBy, studentName } = msg;
          realtimeState.studentGradeUpdates[studentId] = {
            studentId,
            overallScore,
            notes,
            updatedAt: new Date().toISOString(),
            updatedBy: updatedBy || 'المعلم / الإدارة',
          };
          // Broadcast to ALL other connected devices
          broadcast({
            type: 'grade:update',
            studentId,
            overallScore,
            notes,
            updatedBy: updatedBy || 'المعلم / الإدارة',
            studentName,
          }, ws);
          break;
        }

        case 'student:full_update': {
          // Broadcast full student record mutation (grades, status, contact, attendance)
          broadcast({
            type: 'student:full_update',
            student: msg.student,
            updatedBy: msg.updatedBy || 'الإدارة الأكاديمية',
          }, ws);
          break;
        }

        // --- 4. PARENT COMMUNICATION: LIVE TYPING & REAL WEBRTC VOICE CALL SIGNALING ---
        case 'parent_chat:typing': {
          broadcast({
            type: 'parent_chat:typing',
            conversationId: msg.conversationId,
            senderName: msg.senderName,
            senderRole: msg.senderRole,
            isTyping: Boolean(msg.isTyping),
          }, ws);
          break;
        }

        case 'parent_call:offer': {
          broadcast({
            type: 'parent_call:offer',
            conversationId: msg.conversationId,
            callId: msg.callId,
            callerName: msg.callerName,
            callerRole: msg.callerRole,
            sdp: msg.sdp,
          }, ws);
          break;
        }

        case 'parent_call:answer': {
          broadcast({
            type: 'parent_call:answer',
            conversationId: msg.conversationId,
            callId: msg.callId,
            calleeName: msg.calleeName,
            sdp: msg.sdp,
          }, ws);
          break;
        }

        case 'parent_call:ice': {
          broadcast({
            type: 'parent_call:ice',
            conversationId: msg.conversationId,
            callId: msg.callId,
            candidate: msg.candidate,
          }, ws);
          break;
        }

        case 'parent_call:reject': {
          broadcast({
            type: 'parent_call:reject',
            conversationId: msg.conversationId,
            callId: msg.callId,
            reason: msg.reason || 'declined',
          }, ws);
          break;
        }

        case 'parent_call:end': {
          broadcast({
            type: 'parent_call:end',
            conversationId: msg.conversationId,
            callId: msg.callId,
            durationSeconds: msg.durationSeconds || 0,
            endedBy: msg.endedBy,
          }, ws);
          break;
        }

        default:
          console.log(`[WebSocket] Unknown message type: ${msg.type}`);
      }
    } catch (err) {
      console.error('[WebSocket] Failed to parse message', err);
    }
  });

  ws.on('close', () => {
    const remaining = wss.clients.size;
    console.log(`[WebSocket] Client disconnected. Remaining: ${remaining}`);
    broadcastAll({
      type: 'presence:update',
      data: { connectedClients: remaining },
    });
  });
});

// REST Healthcheck endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    wsClients: wss.clients.size,
    whiteboardCode: realtimeState.whiteboardCode,
    activeStrokes: realtimeState.strokes.length,
    timestamp: new Date().toISOString(),
  });
});

// Database Status & Diagnostics
app.get('/api/db/status', async (req, res) => {
  try {
    const [
      studentsList,
      teachersList,
      lessonsList,
      quizzesList,
      attemptsList,
      assignmentsList,
      submissionsList,
      certsList,
      parentConvsList,
      timetableList,
      notificationsList,
      faqsList,
      inquiriesList,
      usersList,
      backupsList,
      auditLogsList,
      lessonRatingsList,
      pushSubsList,
    ] = await Promise.all([
      repo.getAllStudents(),
      repo.getAllTeachers(),
      repo.getAllLessons(),
      repo.getAllQuizzes(),
      repo.getAllQuizAttempts(),
      repo.getAllAssignments(),
      repo.getAllAssignmentSubmissions(),
      repo.getAllCertificates(),
      repo.getAllParentConversations(),
      repo.getAllTimetable(),
      repo.getAllNotifications(),
      repo.getAllFaqs(),
      repo.getAllInquiries(),
      repo.getAllUsers(),
      repo.getAllBackups(),
      repo.getAllAuditLogs(),
      repo.getAllLessonRatings(),
      repo.getAllPushSubscriptions(),
    ]);

    const parentMessagesCount = parentConvsList.reduce(
      (sum, c) => sum + (Array.isArray(c.messages) ? c.messages.length : 0),
      0
    );

    res.json({
      status: 'connected',
      dialect: 'PostgreSQL / Cloud SQL',
      counts: {
        students: studentsList.length,
        teachers: teachersList.length,
        lessons: lessonsList.length,
        quizzes: quizzesList.length,
        quizAttempts: attemptsList.length,
        assignments: assignmentsList.length,
        assignmentSubmissions: submissionsList.length,
        certificates: certsList.length,
        parentConversations: parentConvsList.length,
        parentMessages: parentMessagesCount,
        timetable: timetableList.length,
        notifications: notificationsList.length,
        faqs: faqsList.length,
        inquiries: inquiriesList.length,
        users: usersList.length,
        backups: backupsList.length,
        auditLogs: auditLogsList.length,
        lessonRatings: lessonRatingsList.length,
        pushSubscriptions: pushSubsList.length,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Database status error:', err);
    res.status(500).json({ status: 'error', error: err.message });
  }
});

// Seed endpoint
app.post('/api/db/seed', async (req, res) => {
  try {
    await repo.seedInitialDataIfEmpty();
    res.json({ success: true, message: 'Database seeded successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: STUDENTS =================
app.get('/api/students', async (req, res) => {
  try {
    const data = await repo.getAllStudents();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/students', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح لهذا الحساب بإضافة طلاب')) return;
  try {
    const student = await repo.createStudent(req.body);
    broadcastAll({ type: 'student:created', student });
    res.json(student);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/students/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح لهذا الحساب بتعديل بيانات الطلاب')) return;
  try {
    const beforeList = await repo.getAllStudents();
    const prevStu = beforeList.find((s: any) => s.id === req.params.id);
    const updated = await repo.updateStudent(req.params.id, req.body);
    broadcastAll({ type: 'student:updated', student: updated });
    if (prevStu && req.body?.overallScore !== undefined && Number(prevStu.overallScore) !== Number(req.body.overallScore)) {
      await recordSensitiveAuditLog(req, {
        action: 'grade_edit',
        actionAr: 'تعديل درجة طالب',
        entityType: 'grade',
        entityName: updated?.name || prevStu.name,
        details: `تم تعديل التقدير العام للطالب (${prevStu.name}) من ${prevStu.overallScore}% إلى ${updated?.overallScore}%`,
        severity: 'warning',
      });
    }
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/students/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح لهذا الحساب بحذف الطلاب')) return;
  try {
    const result = await repo.deleteStudent(req.params.id);
    broadcastAll({ type: 'student:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: TEACHERS & TEACHER PDF LIBRARY =================
app.use('/api/teachers', createTeacherPdfRouter({ broadcastAll, dispatchWebPushNotification }));
app.get('/api/teachers', async (req, res) => {
  try {
    const data = await repo.getAllTeachers();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/teachers', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح لهذا الحساب بإضافة معلمين')) return;
  try {
    const teacher = await repo.createTeacher(req.body);
    broadcastAll({ type: 'teacher:created', teacher });
    res.json(teacher);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/teachers/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح لهذا الحساب بتعديل بيانات المعلمين')) return;
  try {
    const updated = await repo.updateTeacher(req.params.id, req.body);
    broadcastAll({ type: 'teacher:updated', teacher: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/teachers/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح لهذا الحساب بحذف المعلمين')) return;
  try {
    const result = await repo.deleteTeacher(req.params.id);
    broadcastAll({ type: 'teacher:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: LESSONS =================
app.get('/api/lessons', async (req, res) => {
  try {
    const data = await repo.getAllLessons();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/lessons', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'صلاحية إضافة الدروس متاحة للمعلم أو الإدارة فقط')) return;
  try {
    const lesson = await repo.createLesson(req.body);
    broadcastAll({ type: 'lesson:created', lesson });

    // Auto-create and broadcast notification for Students, Female Students & Parents
    try {
      const autoNotif = await repo.createNotification({
        title: `📚 درس جديد: ${lesson.title}`,
        message: `أضاف المعلم (${lesson.teacherName || 'هيئة التدريس'}) درساً جديداً في مادة (${lesson.subject}) لمرحلة (${lesson.grade}).`,
        target: 'students_parents',
        category: 'academic',
        relatedType: 'lesson',
        relatedId: lesson.id,
      });
      broadcastAll({ type: 'notification:created', notification: autoNotif });
      dispatchWebPushNotification({
        title: autoNotif.title,
        body: autoNotif.message,
        target: 'students_parents',
        url: '/',
        tag: `lesson-${lesson.id}`,
      });
    } catch (notifErr) {
      console.warn('Auto lesson notification warning:', notifErr);
    }

    res.json(lesson);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/lessons/:id', async (req, res) => {
  const actor = getRequestActor(req);
  if (actor.role && ['student', 'female_student', 'parent', 'visitor'].includes(actor.role)) {
    // Allow students only to increment view/like counts if body has ONLY viewsCount/likesCount
    const keys = Object.keys(req.body || {});
    const isEngagementOnly =
      ['student', 'female_student'].includes(actor.role) &&
      keys.length > 0 &&
      keys.every((k) => k === 'viewsCount' || k === 'likesCount');
    if (!isEngagementOnly) {
      return res.status(403).json({ error: 'غير مصرح للطالب أو ولي الأمر بتعديل الدروس' });
    }
  }
  if (actor.role === 'teacher') {
    const all = await repo.getAllLessons();
    const target = all.find((l: any) => l.id === req.params.id);
    if (target) {
      const ownsById =
        (actor.teacherId && target.teacherId === actor.teacherId) ||
        (actor.userId && target.teacherId === actor.userId);
      const ownsByName =
        actor.userName && String(target.teacherName || '').trim() === actor.userName;
      if (!ownsById && !ownsByName) {
        return res.status(403).json({ error: 'يمكن للمعلم تعديل الدروس الخاصة به فقط' });
      }
    }
  }
  try {
    const updated = await repo.updateLesson(req.params.id, req.body);
    broadcastAll({ type: 'lesson:updated', lesson: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/lessons/:id', async (req, res) => {
  const actor = getRequestActor(req);
  if (actor.role && ['student', 'female_student', 'parent', 'visitor'].includes(actor.role)) {
    return res.status(403).json({ error: 'غير مصرح للطالب أو ولي الأمر بحذف الدروس' });
  }
  if (actor.role === 'teacher') {
    const all = await repo.getAllLessons();
    const target = all.find((l: any) => l.id === req.params.id);
    if (target) {
      const ownsById =
        (actor.teacherId && target.teacherId === actor.teacherId) ||
        (actor.userId && target.teacherId === actor.userId);
      const ownsByName =
        actor.userName && String(target.teacherName || '').trim() === actor.userName;
      if (!ownsById && !ownsByName) {
        return res.status(403).json({ error: 'يمكن للمعلم حذف الدروس الخاصة به فقط' });
      }
    }
  }
  try {
    const allBefore = await repo.getAllLessons();
    const deletedTarget = allBefore.find((l: any) => l.id === req.params.id);
    const result = await repo.deleteLesson(req.params.id);
    broadcastAll({ type: 'lesson:deleted', id: req.params.id });
    await recordSensitiveAuditLog(req, {
      action: 'lesson_delete',
      actionAr: 'حذف درس من المنصة',
      entityType: 'lesson',
      entityName: deletedTarget?.title || req.params.id,
      details: `تم حذف الدرس (${deletedTarget?.title || req.params.id}) — المادة: ${deletedTarget?.subject || '-'}`,
      severity: 'critical',
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: QUIZZES (الاختبارات الأسبوعية والشهرية) =================
app.get('/api/quizzes', async (req, res) => {
  try {
    const data = await repo.getAllQuizzes();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/quizzes', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'صلاحية إنشاء الاختبارات متاحة للمعلم أو الإدارة فقط')) return;
  try {
    const quiz = await repo.createQuiz(req.body);
    broadcastAll({ type: 'quiz:created', quiz });

    // Auto-create and broadcast Weekly / Monthly Quiz notification for Students & Parents
    try {
      const isMonthly = quiz.type === 'monthly';
      const typeLabelAr = isMonthly ? 'اختبار شهري جديد' : 'اختبار أسبوعي جديد';
      const autoNotif = await repo.createNotification({
        title: `📝 ${typeLabelAr}: ${quiz.title}`,
        message: `تم طرح ${isMonthly ? 'اختبار شهري' : 'اختبار أسبوعي'} جديد في مادة (${quiz.subject}) لمرحلة (${quiz.grade}) — المدة ${quiz.durationMinutes} دقيقة • الدرجة الكلية: ${quiz.totalMarks}.`,
        target: 'students_parents',
        category: 'academic',
        relatedType: isMonthly ? 'quiz_monthly' : 'quiz_weekly',
        relatedId: quiz.id,
      });
      broadcastAll({ type: 'notification:created', notification: autoNotif });
      dispatchWebPushNotification({
        title: autoNotif.title,
        body: autoNotif.message,
        target: 'students_parents',
        url: '/',
        tag: `quiz-${quiz.id}`,
      });
    } catch (notifErr) {
      console.warn('Auto quiz notification warning:', notifErr);
    }

    res.json(quiz);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/quizzes/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'غير مصرح للطالب أو ولي الأمر بتعديل الاختبارات')) return;
  try {
    const updated = await repo.updateQuiz(req.params.id, req.body);
    broadcastAll({ type: 'quiz:updated', quiz: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/quizzes/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'غير مصرح للطالب أو ولي الأمر بحذف الاختبارات')) return;
  try {
    const allBefore = await repo.getAllQuizzes();
    const deletedQuiz = allBefore.find((q: any) => q.id === req.params.id);
    const result = await repo.deleteQuiz(req.params.id);
    broadcastAll({ type: 'quiz:deleted', id: req.params.id });
    await recordSensitiveAuditLog(req, {
      action: 'quiz_delete',
      actionAr: 'حذف اختبار من المنصة',
      entityType: 'quiz',
      entityName: deletedQuiz?.title || req.params.id,
      details: `تم حذف الاختبار (${deletedQuiz?.title || req.params.id}) — المادة: ${deletedQuiz?.subject || '-'}`,
      severity: 'critical',
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/quizzes/generate-from-lessons', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'غير مصرح بتوليد الاختبارات لهذا الحساب')) return;
  try {
    const result = await repo.generateQuizQuestionsFromDbLessons(req.body || {});
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: ASSIGNMENTS & SUBMISSIONS (الواجبات المنزلية) =================
app.get('/api/assignments', async (req, res) => {
  try {
    const data = await repo.getAllAssignments({
      search: typeof req.query.search === 'string' ? req.query.search : undefined,
      subject: typeof req.query.subject === 'string' ? req.query.subject : undefined,
      grade: typeof req.query.grade === 'string' ? req.query.grade : undefined,
      teacherId: typeof req.query.teacherId === 'string' ? req.query.teacherId : undefined,
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/assignments', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'صلاحية وضع الواجبات متاحة للمعلم أو الإدارة فقط')) return;
  try {
    const { title, subject, grade } = req.body || {};
    if (!title?.trim() || !subject?.trim() || !grade?.trim()) {
      return res.status(400).json({ error: 'يرجى إدخال عنوان الواجب والمادة والمرحلة الدراسية' });
    }
    const assignment = await repo.createAssignment(req.body);
    broadcastAll({ type: 'assignment:created', assignment });

    // Auto-create and broadcast notification for Students, Female Students & Parents
    try {
      const autoNotif = await repo.createNotification({
        title: `✍️ واجب منزلي جديد: ${assignment.title}`,
        message: `أضاف المعلم (${assignment.teacherName || 'هيئة التدريس'}) واجباً منزلياً جديداً في مادة (${assignment.subject}) لمرحلة (${assignment.grade}) — موعد التسليم: ${assignment.dueDate}.`,
        target: 'students_parents',
        category: 'academic',
        relatedType: 'assignment',
        relatedId: assignment.id,
      });
      broadcastAll({ type: 'notification:created', notification: autoNotif });
      dispatchWebPushNotification({
        title: autoNotif.title,
        body: autoNotif.message,
        target: 'students_parents',
        url: '/',
        tag: `assignment-${assignment.id}`,
      });
    } catch (notifErr) {
      console.warn('Auto assignment notification warning:', notifErr);
    }

    res.status(201).json(assignment);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/assignments/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'غير مصرح للطالب أو ولي الأمر بتعديل الواجبات')) return;
  try {
    const updated = await repo.updateAssignment(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'الواجب غير موجود في قاعدة البيانات' });
    }
    broadcastAll({ type: 'assignment:updated', assignment: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/assignments/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'غير مصرح للطالب أو ولي الأمر بحذف الواجبات')) return;
  try {
    const result = await repo.deleteAssignment(req.params.id);
    broadcastAll({ type: 'assignment:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/assignment-submissions', async (req, res) => {
  try {
    const [data, rawAnnotations] = await Promise.all([
      repo.getAllAssignmentSubmissions({
        assignmentId: typeof req.query.assignmentId === 'string' ? req.query.assignmentId : undefined,
        studentId: typeof req.query.studentId === 'string' ? req.query.studentId : undefined,
      }),
      repo.getSystemSetting('alsharif_homework_annotations_v1'),
    ]);
    let annotationsMap: Record<
      string,
      { annotatedImageUrl?: string | null; voiceFeedbackUrl?: string | null; voiceDurationSec?: number | null }
    > = {};
    if (rawAnnotations) {
      try {
        annotationsMap = JSON.parse(rawAnnotations);
      } catch {
        annotationsMap = {};
      }
    }
    const enriched = data.map((sub: any) => ({
      ...sub,
      annotatedImageUrl: annotationsMap[sub.id]?.annotatedImageUrl ?? sub.annotatedImageUrl ?? null,
      voiceFeedbackUrl: annotationsMap[sub.id]?.voiceFeedbackUrl ?? sub.voiceFeedbackUrl ?? null,
      voiceDurationSec: annotationsMap[sub.id]?.voiceDurationSec ?? sub.voiceDurationSec ?? null,
    }));
    res.json(enriched);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/assignment-submissions', async (req, res) => {
  if (rejectIfRole(req, res, ['parent', 'visitor'], 'تسليم حل الواجب متاح للطالب والطالبة فقط')) return;
  try {
    const submission = await repo.createAssignmentSubmission(req.body || {});
    broadcastAll({ type: 'assignment_submission:created', submission });
    res.status(201).json(submission);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/assignment-submissions/:id/grade', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'تصحيح الواجب متاح للمعلم أو الإدارة فقط')) return;
  try {
    const beforeSubs = await repo.getAllAssignmentSubmissions();
    const prevSub = beforeSubs.find((s: any) => s.id === req.params.id);
    const updated = await repo.gradeAssignmentSubmission(req.params.id, req.body || {});
    if (!updated) {
      return res.status(404).json({ error: 'تسليم الواجب غير موجود في قاعدة البيانات' });
    }

    // Persist teacher visual canvas annotations (✓ / ✗ / pen drawing) & voice note feedback in DB
    const { annotatedImageUrl, voiceFeedbackUrl, voiceDurationSec } = req.body || {};
    const rawAnnotations = await repo.getSystemSetting('alsharif_homework_annotations_v1');
    let annotationsMap: Record<string, any> = {};
    if (rawAnnotations) {
      try {
        annotationsMap = JSON.parse(rawAnnotations);
      } catch {
        annotationsMap = {};
      }
    }
    const existingExtra = annotationsMap[req.params.id] || {};
    const nextExtra = {
      annotatedImageUrl:
        annotatedImageUrl !== undefined ? annotatedImageUrl : existingExtra.annotatedImageUrl ?? null,
      voiceFeedbackUrl:
        voiceFeedbackUrl !== undefined ? voiceFeedbackUrl : existingExtra.voiceFeedbackUrl ?? null,
      voiceDurationSec:
        voiceDurationSec !== undefined ? voiceDurationSec : existingExtra.voiceDurationSec ?? null,
    };
    annotationsMap[req.params.id] = nextExtra;
    await repo.setSystemSetting('alsharif_homework_annotations_v1', JSON.stringify(annotationsMap));

    const enrichedUpdated = {
      ...updated,
      ...nextExtra,
    };

    broadcastAll({ type: 'assignment_submission:updated', submission: enrichedUpdated });
    await recordSensitiveAuditLog(req, {
      action: 'grade_edit',
      actionAr: prevSub?.status === 'graded' ? 'تعديل درجة واجب' : 'رصد درجة واجب',
      entityType: 'grade',
      entityName: updated.studentName,
      details: `تم ${prevSub?.status === 'graded' ? 'تعديل' : 'رصد'} درجة الواجب للطالب (${updated.studentName}) إلى ${updated.score ?? 0}${nextExtra.annotatedImageUrl ? ' (مع تصحيح بالرسم على الورقة)' : ''}${nextExtra.voiceFeedbackUrl ? ' (مع تعليق صوتي للمعلم)' : ''}`,
      severity: 'warning',
    });
    res.json(enrichedUpdated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/assignment-submissions/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'غير مصرح بحذف تسليمات الواجب')) return;
  try {
    const result = await repo.deleteAssignmentSubmission(req.params.id);
    broadcastAll({ type: 'assignment_submission:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= QUIZ ATTEMPTS (درجات الامتحانات الأسبوعية والشهرية المسجلة) =================
app.get('/api/quiz-attempts', async (req, res) => {
  try {
    const studentId = typeof req.query.studentId === 'string' ? req.query.studentId : undefined;
    const quizType = typeof req.query.quizType === 'string' ? req.query.quizType : undefined;
    const data = await repo.getAllQuizAttempts({ studentId, quizType });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/quiz-attempts', async (req, res) => {
  try {
    const result = await repo.recordQuizAttemptAndSyncCertificates(req.body || {});
    broadcastAll({ type: 'quiz_attempt:created', attempt: result.attempt });
    if (result.updatedQuiz) {
      broadcastAll({ type: 'quiz:updated', quiz: result.updatedQuiz });
    }
    if (result.updatedStudent) {
      broadcastAll({ type: 'student:updated', student: result.updatedStudent });
    }
    if (Array.isArray(result.autoCertificates) && result.autoCertificates.length > 0) {
      broadcastAll({ type: 'certificates:synced', certificates: result.autoCertificates });
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/quiz-attempts/:id', async (req, res) => {
  try {
    const beforeList = await repo.getAllQuizAttempts();
    const prevAttempt = beforeList.find((a: any) => a.id === req.params.id);
    const result = await repo.updateQuizAttempt(req.params.id, req.body || {});
    broadcastAll({ type: 'quiz_attempt:updated', attempt: result.attempt });
    if (result.updatedQuiz) {
      broadcastAll({ type: 'quiz:updated', quiz: result.updatedQuiz });
    }
    if (result.updatedStudent) {
      broadcastAll({ type: 'student:updated', student: result.updatedStudent });
    }
    const allCerts = await repo.getAllCertificates();
    broadcastAll({ type: 'certificates:synced', certificates: allCerts });
    if (result.attempt) {
      await recordSensitiveAuditLog(req, {
        action: 'grade_edit',
        actionAr: 'تعديل درجة اختبار',
        entityType: 'grade',
        entityName: `${result.attempt.studentName} — ${result.attempt.quizTitle}`,
        details: `تم تعديل درجة (${result.attempt.studentName}) في اختبار (${result.attempt.quizTitle}) من ${prevAttempt?.earnedMarks ?? '-'}/${prevAttempt?.totalMarks ?? '-'} إلى ${result.attempt.earnedMarks}/${result.attempt.totalMarks} (${result.attempt.percentage}%)`,
        severity: 'warning',
      });
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/quiz-attempts/:id', async (req, res) => {
  try {
    const beforeList = await repo.getAllQuizAttempts();
    const prevAttempt = beforeList.find((a: any) => a.id === req.params.id);
    const result = await repo.deleteQuizAttempt(req.params.id);
    broadcastAll({ type: 'quiz_attempt:deleted', id: req.params.id });
    if (result.updatedQuiz) {
      broadcastAll({ type: 'quiz:updated', quiz: result.updatedQuiz });
    }
    if (result.updatedStudent) {
      broadcastAll({ type: 'student:updated', student: result.updatedStudent });
    }
    const allCerts = await repo.getAllCertificates();
    broadcastAll({ type: 'certificates:synced', certificates: allCerts });
    await recordSensitiveAuditLog(req, {
      action: 'grade_delete',
      actionAr: 'حذف درجة / محاولة اختبار',
      entityType: 'grade',
      entityName: prevAttempt ? `${prevAttempt.studentName} — ${prevAttempt.quizTitle}` : req.params.id,
      details: prevAttempt
        ? `تم حذف نتيجة اختبار (${prevAttempt.quizTitle}) للطالب (${prevAttempt.studentName})`
        : `تم حذف نتيجة اختبار رقم ${req.params.id}`,
      severity: 'critical',
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CERTIFICATES & AUTO GRADE REPORTS =================
app.get('/api/certificates', async (req, res) => {
  try {
    const data = await repo.getAllCertificates();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/certificates', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بإصدار الشهادات لهذا الحساب')) return;
  try {
    const cert = await repo.createCertificate(req.body || {});
    broadcastAll({ type: 'certificate:created', certificate: cert });
    res.json(cert);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/certificates/auto-generate', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتوليد الشهادات لهذا الحساب')) return;
  try {
    const result = await repo.autoGenerateCertificatesFromExamAttempts(req.body || {});
    const allCerts = await repo.getAllCertificates();
    broadcastAll({ type: 'certificates:synced', certificates: allCerts });
    res.json({ ...result, allCertificates: allCerts });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/certificates/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل الشهادات لهذا الحساب')) return;
  try {
    const updated = await repo.updateCertificate(req.params.id, req.body || {});
    if (!updated) return res.status(404).json({ error: 'Certificate not found' });
    broadcastAll({ type: 'certificate:updated', certificate: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/certificates/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف الشهادات لهذا الحساب')) return;
  try {
    const result = await repo.deleteCertificate(req.params.id);
    broadcastAll({ type: 'certificate:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Verify Official Certificate by Serial Number or ID (QR Code Camera Scan Verification from PostgreSQL)
app.get('/api/certificates/verify/:serialOrId', async (req, res) => {
  try {
    const queryKey = decodeURIComponent(String(req.params.serialOrId || '')).trim().toLowerCase();
    if (!queryKey) {
      return res.status(400).json({ verified: false, error: 'يرجى تمرير الرقم التسلسلي للشهادة' });
    }
    const [certs, students, attempts] = await Promise.all([
      repo.getAllCertificates(),
      repo.getAllStudents(),
      repo.getAllQuizAttempts(),
    ]);
    const matchedCert = certs.find(
      (c: any) =>
        String(c.serialNumber || '').trim().toLowerCase() === queryKey ||
        String(c.id || '').trim().toLowerCase() === queryKey
    );
    if (!matchedCert) {
      return res.status(404).json({
        verified: false,
        error: 'لم يتم العثور على شهادة مطابقة لهذا الرقم التسلسلي في قاعدة بيانات منصة الشريف.',
      });
    }
    const matchedStudent = students.find((s: any) => s.id === matchedCert.studentId) || null;
    const studentAttempts = attempts.filter(
      (a: any) =>
        a.studentId === matchedCert.studentId ||
        String(a.studentName || '').trim() === String(matchedCert.studentName || '').trim()
    );
    res.json({
      verified: true,
      platform: 'منصة الشريف التعليمية',
      verifiedAt: new Date().toISOString(),
      certificate: matchedCert,
      student: matchedStudent,
      examAttemptsCount: studentAttempts.length,
    });
  } catch (err: any) {
    res.status(500).json({ verified: false, error: err.message });
  }
});

// ================= SEQUENTIAL LESSON LOCKING (شرط اجتياز الاختبار لفتح الدرس التالي) =================
const DEFAULT_SEQUENTIAL_LESSON_CONFIG = {
  enabled: true,
  minimumPassPercentage: 70,
};

app.get('/api/sequential-lessons/state', async (req, res) => {
  try {
    const [rawCfg, rawProgress] = await Promise.all([
      repo.getSystemSetting('alsharif_sequential_lesson_config_v1'),
      repo.getSystemSetting('alsharif_sequential_lesson_progress_v1'),
    ]);
    const config = rawCfg
      ? { ...DEFAULT_SEQUENTIAL_LESSON_CONFIG, ...JSON.parse(rawCfg) }
      : DEFAULT_SEQUENTIAL_LESSON_CONFIG;
    const progressMap = rawProgress ? JSON.parse(rawProgress) : {};
    res.json({ config, progressMap });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/sequential-lessons/config', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'إعدادات قفل الدروس المتسلسل متاحة للمعلم أو الإدارة فقط')) return;
  try {
    const rawCfg = await repo.getSystemSetting('alsharif_sequential_lesson_config_v1');
    const prev = rawCfg
      ? { ...DEFAULT_SEQUENTIAL_LESSON_CONFIG, ...JSON.parse(rawCfg) }
      : DEFAULT_SEQUENTIAL_LESSON_CONFIG;
    const next = {
      enabled: req.body?.enabled !== undefined ? Boolean(req.body.enabled) : prev.enabled,
      minimumPassPercentage: Math.max(
        50,
        Math.min(100, Number(req.body?.minimumPassPercentage) || prev.minimumPassPercentage || 70)
      ),
    };
    await repo.setSystemSetting('alsharif_sequential_lesson_config_v1', JSON.stringify(next));
    broadcastAll({ type: 'sequential_lessons:config_updated', config: next });
    res.json({ ok: true, config: next });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/sequential-lessons/record-progress', async (req, res) => {
  try {
    const {
      studentKey,
      studentId,
      studentName,
      grade,
      watchedLessonId,
      passedLessonId,
      lessonTitle,
      subject,
      scorePercentage,
      earnedMarks,
      totalMarks,
    } = req.body || {};

    const cleanKey = String(studentKey || studentId || studentName || 'default').trim();
    const [rawCfg, rawProgress] = await Promise.all([
      repo.getSystemSetting('alsharif_sequential_lesson_config_v1'),
      repo.getSystemSetting('alsharif_sequential_lesson_progress_v1'),
    ]);
    const config = rawCfg
      ? { ...DEFAULT_SEQUENTIAL_LESSON_CONFIG, ...JSON.parse(rawCfg) }
      : DEFAULT_SEQUENTIAL_LESSON_CONFIG;
    const progressMap: Record<string, any> = rawProgress ? JSON.parse(rawProgress) : {};

    const current = progressMap[cleanKey] || {
      studentKey: cleanKey,
      studentName: studentName || 'طالب',
      watchedLessonIds: [],
      passedLessonScores: {},
      updatedAt: new Date().toISOString(),
    };

    if (watchedLessonId && !current.watchedLessonIds.includes(watchedLessonId)) {
      current.watchedLessonIds.push(watchedLessonId);
    }

    if (passedLessonId && scorePercentage !== undefined) {
      const pct = Math.round(Number(scorePercentage) || 0);
      if (!current.watchedLessonIds.includes(passedLessonId)) {
        current.watchedLessonIds.push(passedLessonId);
      }
      const prevBest = Number(current.passedLessonScores[passedLessonId] || 0);
      current.passedLessonScores[passedLessonId] = Math.max(prevBest, pct);

      // Also record an official quiz attempt in PostgreSQL if passed
      if (pct >= (config.minimumPassPercentage || 70) && studentId) {
        try {
          await repo.recordQuizAttemptAndSyncCertificates({
            quizId: `seq-gate-${passedLessonId}`,
            quizTitle: `اختبار اجتياز الدرس: ${lessonTitle || passedLessonId}`,
            quizType: 'weekly',
            subject: subject || 'عام',
            grade: grade || 'الصف الثالث الثانوي',
            studentId,
            studentName: studentName || 'طالب',
            earnedMarks: Number(earnedMarks) || pct,
            totalMarks: Number(totalMarks) || 100,
            percentage: pct,
            correctCount: Number(earnedMarks) || 1,
            totalQuestions: Number(totalMarks) || 1,
            takenDate: new Date().toISOString().split('T')[0],
          });
        } catch {
          // ignore if studentId is temporary
        }
      }
    }

    current.updatedAt = new Date().toISOString();
    progressMap[cleanKey] = current;
    await repo.setSystemSetting('alsharif_sequential_lesson_progress_v1', JSON.stringify(progressMap));
    broadcastAll({
      type: 'sequential_lessons:progress_updated',
      studentKey: cleanKey,
      progress: current,
    });
    res.json({ ok: true, config, progress: current, progressMap });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= PARENT SMART WEEKLY REPORTS & WHATSAPP DISPATCH =================
function parseLessonMinutes(durationOrPages?: string | null): number {
  const txt = String(durationOrPages || '').trim();
  const numMatch = txt.match(/(\d+(?:\.\d+)?)/);
  if (!numMatch) return 40;
  const val = Number(numMatch[1]);
  if (txt.includes('ساع') || txt.toLowerCase().includes('hr') || txt.toLowerCase().includes('hour')) {
    return Math.round(val * 60);
  }
  if (txt.includes('صفح') || txt.toLowerCase().includes('page')) {
    return Math.max(20, Math.min(90, Math.round(val * 2)));
  }
  return Math.max(15, Math.min(180, Math.round(val)));
}

app.get('/api/parent-reports/weekly', async (_req, res) => {
  try {
    const [
      allStudents,
      allLessons,
      allAttempts,
      allSubmissions,
      rawSeqProgress,
      rawQrAttendance,
      rawReportLogs,
      rawPomodoroSessions,
    ] = await Promise.all([
      repo.getAllStudents(),
      repo.getAllLessons(),
      repo.getAllQuizAttempts(),
      repo.getAllAssignmentSubmissions(),
      repo.getSystemSetting('alsharif_sequential_lesson_progress_v1'),
      repo.getSystemSetting('alsharif_qr_attendance_records_v1'),
      repo.getSystemSetting('alsharif_weekly_parent_reports_v1'),
      repo.getSystemSetting('alsharif_pomodoro_sessions_v1'),
    ]);

    const progressMap: Record<string, any> = rawSeqProgress ? JSON.parse(rawSeqProgress) : {};
    const qrRecords: any[] = rawQrAttendance ? JSON.parse(rawQrAttendance) : [];
    const reportLogs: Record<string, any> = rawReportLogs ? JSON.parse(rawReportLogs) : {};
    const pomodoroSessions: any[] = rawPomodoroSessions ? JSON.parse(rawPomodoroSessions) : [];

    const now = new Date();
    const weekStart = new Date(now.getTime() - 6 * 86400000);
    const weekStartMs = Date.now() - 7 * 86400000;
    const weekLabel = `${weekStart.toLocaleDateString('ar-EG', {
      month: 'short',
      day: 'numeric',
    })} — ${now.toLocaleDateString('ar-EG', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })}`;

    const reports = allStudents.map((stu: any) => {
      const stuProg =
        progressMap[stu.id] ||
        progressMap[stu.code] ||
        progressMap[stu.name] ||
        Object.values(progressMap).find(
          (p: any) =>
            p.studentKey === stu.id ||
            p.studentKey === stu.code ||
            (p.studentName && p.studentName.trim() === String(stu.name || '').trim())
        );

      const watchedIds: string[] = Array.isArray(stuProg?.watchedLessonIds)
        ? stuProg.watchedLessonIds
        : [];
      const passedScores: Record<string, number> = stuProg?.passedLessonScores || {};
      const completedIds = Array.from(new Set([...watchedIds, ...Object.keys(passedScores)]));

      const completedLessons = allLessons.filter((l: any) => completedIds.includes(l.id));
      const completedLessonTitles = completedLessons.map((l: any) => l.title);

      const stuAttempts = allAttempts.filter(
        (a: any) =>
          a.studentId === stu.id ||
          (a.studentCode && a.studentCode === stu.code) ||
          (a.studentName && a.studentName.trim() === String(stu.name || '').trim())
      );

      const stuSubmissions = allSubmissions.filter(
        (sub: any) =>
          sub.studentId === stu.id ||
          (sub.studentCode && sub.studentCode === stu.code) ||
          (sub.studentName && sub.studentName.trim() === String(stu.name || '').trim())
      );

      const lessonMinutes = completedLessons.reduce(
        (sum: number, l: any) => sum + parseLessonMinutes(l.durationOrPages),
        0
      );
      const quizMinutes = stuAttempts.length * 25;
      const assignmentMinutes = stuSubmissions.length * 20;
      const pomodoroMinutes = pomodoroSessions
        .filter(
          (ps: any) =>
            ps.mode !== 'break' &&
            new Date(ps.completedAt || 0).getTime() >= weekStartMs &&
            (ps.studentId === stu.id ||
              (ps.studentCode && ps.studentCode === stu.code) ||
              (ps.studentName && ps.studentName.trim() === String(stu.name || '').trim()))
        )
        .reduce((acc: number, ps: any) => acc + Number(ps.durationMinutes || 0), 0);

      const logOverride = reportLogs[stu.id] || {};
      const computedHours = Number(
        ((lessonMinutes + quizMinutes + assignmentMinutes + pomodoroMinutes) / 60).toFixed(1)
      );
      const studyHours =
        typeof logOverride.manualStudyHours === 'number'
          ? logOverride.manualStudyHours
          : computedHours;

      const avgExamScore =
        stuAttempts.length > 0
          ? Math.round(
              stuAttempts.reduce((acc: number, a: any) => acc + Number(a.percentage || 0), 0) /
                stuAttempts.length
            )
          : Number(stu.overallScore || 0);

      // Determine weakest subject from real quiz attempts
      let weakestSubject: string | null = null;
      let weakestSubjectScore: number | null = null;
      if (stuAttempts.length > 0) {
        const subjectScores: Record<string, number[]> = {};
        for (const a of stuAttempts) {
          const subj = String(a.subject || '').trim();
          if (!subj) continue;
          if (!subjectScores[subj]) subjectScores[subj] = [];
          subjectScores[subj].push(Number(a.percentage || 0));
        }
        let minAvg = Infinity;
        for (const [subj, scores] of Object.entries(subjectScores)) {
          const avg = Math.round(scores.reduce((x, y) => x + y, 0) / scores.length);
          if (avg < minAvg) {
            minAvg = avg;
            weakestSubject = subj;
            weakestSubjectScore = avg;
          }
        }
      }

      const examDetails = stuAttempts.slice(0, 6).map((a: any) => ({
        title: a.quizTitle,
        subject: a.subject,
        scoreText: `${a.earnedMarks}/${a.totalMarks}`,
        percentage: Number(a.percentage || 0),
        date: a.takenDate || '',
      }));

      const stuAttendanceRecs = qrRecords.filter(
        (r: any) => r.studentId === stu.id || (r.studentCode && r.studentCode === stu.code)
      );
      const presentCount = stuAttendanceRecs.filter(
        (r: any) => r.status === 'present' || r.status === 'late'
      ).length;
      const explicitAbsentCount = stuAttendanceRecs.filter((r: any) => r.status === 'absent').length;
      const derivedAbsentFromRate =
        stuAttendanceRecs.length === 0
          ? Math.max(0, Math.round(((100 - Number(stu.attendanceRate ?? 100)) / 100) * 5))
          : explicitAbsentCount;

      const absenceDays =
        typeof logOverride.manualAbsenceDays === 'number'
          ? logOverride.manualAbsenceDays
          : derivedAbsentFromRate;

      return {
        studentId: stu.id,
        studentCode: stu.code,
        studentName: stu.name,
        studentGrade: stu.grade,
        studentType: stu.type === 'offline' ? 'offline' : 'online',
        studentAvatar: stu.avatar || null,
        parentName: stu.parentName || 'ولي الأمر',
        parentPhone: stu.parentPhone || '',
        parentEmail: stu.parentEmail || '',
        weekLabel,
        studyHours,
        completedLessonsCount: completedLessons.length,
        completedLessonTitles,
        examsCount: stuAttempts.length,
        averageExamScore: avgExamScore,
        weakestSubject,
        weakestSubjectScore,
        examDetails,
        absenceDays,
        attendanceDays: presentCount,
        attendanceRate: Number(stu.attendanceRate ?? 100),
        assignmentsSubmittedCount: stuSubmissions.length,
        customTeacherNote: logOverride.customTeacherNote || '',
        lastSentViaWhatsappAt: logOverride.lastSentViaWhatsappAt || null,
        lastSentBy: logOverride.lastSentBy || null,
      };
    });

    res.json({ weekLabel, reports });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/parent-reports/weekly/log', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'visitor'],
      'غير مصرح بتسجيل أو تعديل تقارير أولياء الأمور'
    )
  ) {
    return;
  }
  try {
    const {
      studentId,
      customTeacherNote,
      manualStudyHours,
      manualAbsenceDays,
      markSentViaWhatsapp,
    } = req.body || {};
    if (!studentId) return res.status(400).json({ error: 'studentId is required' });

    const actor = getRequestActor(req);
    const rawLogs = await repo.getSystemSetting('alsharif_weekly_parent_reports_v1');
    const logsMap: Record<string, any> = rawLogs ? JSON.parse(rawLogs) : {};
    const prev = logsMap[studentId] || {};

    logsMap[studentId] = {
      ...prev,
      customTeacherNote:
        customTeacherNote !== undefined ? String(customTeacherNote) : prev.customTeacherNote || '',
      manualStudyHours:
        manualStudyHours !== undefined && manualStudyHours !== null && manualStudyHours !== ''
          ? Math.max(0, Number(manualStudyHours))
          : prev.manualStudyHours,
      manualAbsenceDays:
        manualAbsenceDays !== undefined && manualAbsenceDays !== null && manualAbsenceDays !== ''
          ? Math.max(0, Number(manualAbsenceDays))
          : prev.manualAbsenceDays,
      lastSentViaWhatsappAt: markSentViaWhatsapp
        ? new Date().toLocaleString('ar-EG')
        : prev.lastSentViaWhatsappAt || null,
      lastSentBy: markSentViaWhatsapp
        ? actor.userName || 'الإدارة'
        : prev.lastSentBy || null,
    };

    await repo.setSystemSetting('alsharif_weekly_parent_reports_v1', JSON.stringify(logsMap));

    if (markSentViaWhatsapp) {
      await recordSensitiveAuditLog(req, {
        action: 'parent_whatsapp_report',
        actionAr: 'إرسال بطاقة التقرير الأسبوعي لولي الأمر عبر واتساب',
        entityType: 'parent_report',
        entityName: String(req.body?.studentName || studentId),
        details: `تم إرسال ملخص الساعات والدروس والاختبارات والغياب إلى واتساب ولي الأمر.`,
        severity: 'info',
      });
    }

    broadcastAll({ type: 'parent_reports:updated', studentId });
    res.json({ ok: true, log: logsMap[studentId] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CENTER QR CODE ATTENDANCE SYSTEM (الحضور بالـ QR للمجموعات الحضورية) =================
app.get('/api/attendance/qr-state', async (_req, res) => {
  try {
    const [rawSessions, rawRecords, students] = await Promise.all([
      repo.getSystemSetting('alsharif_center_sessions_v1'),
      repo.getSystemSetting('alsharif_qr_attendance_records_v1'),
      repo.getAllStudents(),
    ]);
    const sessions = rawSessions ? JSON.parse(rawSessions) : [];
    const records = rawRecords ? JSON.parse(rawRecords) : [];
    res.json({
      sessions: Array.isArray(sessions) ? sessions : [],
      records: Array.isArray(records) ? records : [],
      students,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/attendance/sessions', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'parent', 'visitor'],
      'إنشاء جلسات الحضور الحضورية متاح للمعلم والمشرف والإدارة فقط'
    )
  ) {
    return;
  }
  try {
    const { title, subject, grade, hallName, sessionDate } = req.body || {};
    if (!title?.trim()) {
      return res.status(400).json({ error: 'يرجى إدخال اسم المجموعة الحضورية / الحصة' });
    }
    const actor = getRequestActor(req);
    const rawSessions = await repo.getSystemSetting('alsharif_center_sessions_v1');
    const sessions: any[] = rawSessions ? JSON.parse(rawSessions) : [];
    const newSession = {
      id: `sess-${Date.now()}`,
      title: title.trim(),
      subject: String(subject || 'عام').trim(),
      grade: String(grade || 'الصف الثالث الثانوي').trim(),
      hallName: String(hallName || 'قاعة السنتر الرئيسية').trim(),
      sessionDate: String(sessionDate || new Date().toISOString().split('T')[0]),
      createdBy: actor.userName || 'المعلم / المشرف',
      createdAt: new Date().toISOString(),
    };
    const nextSessions = [newSession, ...sessions].slice(0, 100);
    await repo.setSystemSetting('alsharif_center_sessions_v1', JSON.stringify(nextSessions));
    broadcastAll({ type: 'attendance:session_created', session: newSession });
    res.status(201).json({ ok: true, session: newSession, sessions: nextSessions });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/attendance/qr-checkin', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'parent', 'visitor'],
      'تسجيل الحضور بماسح QR متاح للمعلم أو المشرف أو الإدارة فقط'
    )
  ) {
    return;
  }
  try {
    const {
      qrPayloadOrCode,
      sessionId,
      sessionTitle,
      sessionDate,
      status = 'present',
      method = 'qr_camera',
    } = req.body || {};

    let rawToken = String(qrPayloadOrCode || '').trim();
    if (!rawToken) {
      return res.status(400).json({ error: 'يرجى مسح رمز QR الخاص بالطالب أو إدخال كوده' });
    }

    // Parse URL (?attendStudent=...) or formatted QR payload (ALSHARIF-ATTEND:<id>:<code>)
    try {
      if (rawToken.includes('attendStudent=')) {
        const u = new URL(rawToken.startsWith('http') ? rawToken : `https://alsharif.edu/${rawToken.replace(/^\/+/, '')}`);
        rawToken = u.searchParams.get('attendStudent') || rawToken;
      }
    } catch {
      // ignore URL parse error
    }

    let tokenId = '';
    let tokenCode = rawToken;
    if (rawToken.startsWith('ALSHARIF-ATTEND:')) {
      const parts = rawToken.split(':');
      tokenId = parts[1] || '';
      tokenCode = parts[2] || parts[1] || rawToken;
    }

    const allStudents = await repo.getAllStudents();
    const matchedStudent = allStudents.find(
      (s: any) =>
        (tokenId && String(s.id).toLowerCase() === tokenId.toLowerCase()) ||
        String(s.id).toLowerCase() === tokenCode.toLowerCase() ||
        String(s.code || '').toLowerCase() === tokenCode.toLowerCase() ||
        String(s.name || '').trim().toLowerCase() === tokenCode.toLowerCase()
    );

    if (!matchedStudent) {
      return res.status(404).json({
        error: `لم يتم العثور على طالب مطابق للكود (${tokenCode}) في قاعدة البيانات.`,
      });
    }

    const actor = getRequestActor(req);
    const todayStr = String(sessionDate || new Date().toISOString().split('T')[0]);
    const effectiveSessionId = String(sessionId || `daily-${todayStr}`);
    const effectiveSessionTitle = String(
      sessionTitle || `مجموعة السنتر الحضورية (${todayStr})`
    );

    const rawRecords = await repo.getSystemSetting('alsharif_qr_attendance_records_v1');
    const records: any[] = rawRecords ? JSON.parse(rawRecords) : [];

    const existingIdx = records.findIndex(
      (r) => r.sessionId === effectiveSessionId && r.studentId === matchedStudent.id
    );
    const cleanStatus: 'present' | 'absent' | 'late' =
      status === 'absent' ? 'absent' : status === 'late' ? 'late' : 'present';

    const newRecord = {
      id: existingIdx >= 0 ? records[existingIdx].id : `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      sessionId: effectiveSessionId,
      sessionTitle: effectiveSessionTitle,
      sessionDate: todayStr,
      studentId: matchedStudent.id,
      studentCode: matchedStudent.code,
      studentName: matchedStudent.name,
      studentGrade: matchedStudent.grade,
      status: cleanStatus,
      checkedInAt: new Date().toLocaleString('ar-EG'),
      scannedBy: actor.userName || 'المعلم / المشرف',
      method: method === 'qr_manual' || method === 'quick_roster' ? method : 'qr_camera',
    };

    if (existingIdx >= 0) {
      records[existingIdx] = newRecord;
    } else {
      records.unshift(newRecord);
    }

    const trimmedRecords = records.slice(0, 1000);
    await repo.setSystemSetting('alsharif_qr_attendance_records_v1', JSON.stringify(trimmedRecords));

    // Recompute student's real attendanceRate in PostgreSQL
    const studentRecs = trimmedRecords.filter((r) => r.studentId === matchedStudent.id);
    const attendedCount = studentRecs.filter(
      (r) => r.status === 'present' || r.status === 'late'
    ).length;
    const computedRate: number =
      studentRecs.length > 0
        ? Math.min(100, Math.max(0, Math.round((attendedCount / studentRecs.length) * 100)))
        : Number(matchedStudent.attendanceRate ?? 100);

    const updatedStudent = await repo.updateStudent(matchedStudent.id, {
      attendanceRate: computedRate,
      status:
        Number(matchedStudent.overallScore || 0) >= 90
          ? 'top'
          : Number(matchedStudent.overallScore || 0) < 60 || computedRate < 70
          ? 'weak'
          : 'regular',
    });

    broadcastAll({ type: 'attendance:recorded', record: newRecord, student: updatedStudent });
    if (updatedStudent) {
      broadcastAll({ type: 'student:updated', student: updatedStudent });
    }

    res.json({
      ok: true,
      record: newRecord,
      records: trimmedRecords,
      updatedStudent,
      message:
        cleanStatus === 'absent'
          ? `تم تسجيل غياب الطالب (${matchedStudent.name}) في قاعدة البيانات.`
          : `✓ تم تسجيل حضور الطالب (${matchedStudent.name}) بالـ QR Code في قاعدة البيانات فوراً!`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= ORGANIZED CHAT & GROUP COMMUNICATION CRUD & RICH MESSAGING =================
app.get('/api/parent-conversations', async (req, res) => {
  try {
    const data = await repo.getAllParentConversations();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/parent-conversations', async (req, res) => {
  const actor = getRequestActor(req);
  const channelType = String(req.body?.channelType || 'parent_teacher');

  if (actor.role === 'visitor') {
    return res.status(403).json({ error: 'غير مصرح للزائر بإنشاء محادثات.' });
  }
  if (actor.role === 'student' || actor.role === 'female_student') {
    if (channelType !== 'student_teacher') {
      return res.status(403).json({
        error: 'صلاحية الطالب تسمح فقط ببدء محادثة (من الطالب إلى المعلم)، ولا تشمل إنشاء مجموعات أو قنوات أخرى.',
      });
    }
  }
  if (actor.role === 'parent') {
    if (channelType !== 'parent_teacher') {
      return res.status(403).json({
        error: 'صلاحية ولي الأمر تسمح فقط ببدء محادثة (من ولي الأمر إلى المعلم)، ولا تشمل إنشاء مجموعات أو قنوات أخرى.',
      });
    }
  }

  try {
    const body = { ...(req.body || {}) };
    if (actor.userId && !body.createdById) body.createdById = actor.userId;
    if (actor.userName && !body.createdByName) body.createdByName = actor.userName;
    if (actor.role && !body.createdByRole) body.createdByRole = actor.role;
    if (actor.role === 'teacher') {
      if (!body.teacherId && actor.teacherId) body.teacherId = actor.teacherId;
      if (!body.teacherName && actor.userName) body.teacherName = actor.userName;
    }

    const conv = await repo.createParentConversation(body);
    broadcastAll({ type: 'parent_conv:created', conversation: conv });
    res.json(conv);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/parent-conversations/:id', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'parent', 'visitor'],
      'غير مصرح للطالب أو ولي الأمر بتعديل بيانات المحادثات أو المجموعات'
    )
  ) {
    return;
  }
  try {
    const existing = await repo.getParentConversationById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Conversation not found' });

    const actor = getRequestActor(req);
    if (actor.role === 'teacher') {
      const ownsConv =
        (existing.createdById && existing.createdById === actor.userId) ||
        (existing.teacherId &&
          (existing.teacherId === actor.teacherId || existing.teacherId === actor.userId)) ||
        (existing.teacherName &&
          actor.userName &&
          existing.teacherName.trim().toLowerCase() === actor.userName.trim().toLowerCase());
      if (!ownsConv) {
        return res.status(403).json({ error: 'يمكن للمعلم تعديل محادثاته أو مجموعاته الخاصة فقط.' });
      }
    }

    const updated = await repo.updateParentConversation(req.params.id, req.body || {});
    if (!updated) return res.status(404).json({ error: 'Conversation not found' });
    broadcastAll({ type: 'parent_conv:updated', conversation: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/parent-conversations/:id', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'parent', 'visitor'],
      'غير مصرح للطالب أو ولي الأمر بحذف المحادثات أو المجموعات'
    )
  ) {
    return;
  }
  try {
    const existing = await repo.getParentConversationById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Conversation not found' });

    const actor = getRequestActor(req);
    if (actor.role === 'teacher') {
      const ownsConv =
        (existing.createdById && existing.createdById === actor.userId) ||
        (existing.teacherId &&
          (existing.teacherId === actor.teacherId || existing.teacherId === actor.userId));
      if (!ownsConv) {
        return res.status(403).json({ error: 'يمكن للمعلم حذف المجموعات أو المحادثات التي أنشأها فقط.' });
      }
    }

    const result = await repo.deleteParentConversation(req.params.id);
    broadcastAll({ type: 'parent_conv:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/parent-conversations/:id/messages', async (req, res) => {
  const actor = getRequestActor(req);
  if (actor.role === 'visitor') {
    return res.status(403).json({ error: 'غير مصرح للزائر بإرسال رسائل.' });
  }
  try {
    const conv = await repo.getParentConversationById(req.params.id);
    if (!conv) return res.status(404).json({ error: 'Conversation not found' });

    if (actor.role === 'student' || actor.role === 'female_student') {
      const allowedPublic =
        conv.channelType === 'public_group' &&
        (conv.targetAudience === 'all' || conv.targetAudience === 'students');
      const allowedPrivate =
        conv.channelType === 'private_group' &&
        (conv.createdById === actor.userId ||
          conv.memberIds.includes(actor.userId) ||
          (actor.userName && conv.memberNames.includes(actor.userName)));
      if (conv.channelType !== 'student_teacher' && !allowedPublic && !allowedPrivate) {
        return res.status(403).json({
          error: 'غير مصرح للطالب بالمشاركة في هذه القناة.',
        });
      }
    }

    if (actor.role === 'parent') {
      const allowedPublic =
        conv.channelType === 'public_group' &&
        (conv.targetAudience === 'all' || conv.targetAudience === 'parents');
      const allowedPrivate =
        conv.channelType === 'private_group' &&
        (conv.createdById === actor.userId ||
          conv.memberIds.includes(actor.userId) ||
          (actor.userName && conv.memberNames.includes(actor.userName)));
      if (conv.channelType !== 'parent_teacher' && !allowedPublic && !allowedPrivate) {
        return res.status(403).json({
          error: 'غير مصرح لولي الأمر بالمشاركة في هذه القناة.',
        });
      }
    }

    const result = await repo.createParentMessage(req.params.id, req.body || {});
    broadcastAll({
      type: 'parent_msg:created',
      conversationId: req.params.id,
      message: result.message,
      conversation: result.conversation,
    });
    dispatchWebPushNotification({
      title: `💬 رسالة جديدة من ${result.message?.senderName || 'مشارك'}`,
      body: result.message?.text || conv.title || 'رسالة جديدة في الشات المنظم',
      target: 'all',
      url: '/',
      tag: `chat-${req.params.id}`,
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/parent-conversations/:id/read', async (req, res) => {
  try {
    const updated = await repo.markParentConversationRead(req.params.id);
    if (updated) {
      broadcastAll({ type: 'parent_conv:updated', conversation: updated });
    }
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/parent-messages/:msgId', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'parent', 'visitor'],
      'غير مصرح بتعديل الرسائل المحفوظة'
    )
  ) {
    return;
  }
  try {
    const result = await repo.updateParentMessage(req.params.msgId, req.body || {});
    broadcastAll({
      type: 'parent_msg:updated',
      message: result.message,
      conversation: result.conversation,
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/parent-messages/:msgId', async (req, res) => {
  if (
    rejectIfRole(
      req,
      res,
      ['student', 'female_student', 'parent', 'visitor'],
      'غير مصرح بحذف الرسائل المحفوظة'
    )
  ) {
    return;
  }
  try {
    const result = await repo.deleteParentMessage(req.params.msgId);
    broadcastAll({
      type: 'parent_msg:deleted',
      id: req.params.msgId,
      conversation: result.conversation,
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= MEMBERS & ROLES / PERMISSIONS =================
app.get('/api/members', async (req, res) => {
  try {
    const data = await repo.getAllUsers();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/members', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بإدارة الأعضاء والصلاحيات')) return;
  try {
    const user = await repo.createUser(req.body);
    await recordSensitiveAuditLog(req, {
      action: 'account_create',
      actionAr: 'إنشاء حساب عضو جديد بالمنصة',
      entityType: 'permission',
      entityName: user.displayName || user.username || user.email,
      details: `تم إنشاء حساب (${user.displayName}) بالدور [${ROLE_LABELS_AR[user.role] || user.role}]`,
      severity: 'info',
    });
    res.status(201).json(user);
  } catch (err: any) {
    const status = err?.statusCode || 500;
    res.status(status).json({ error: err.message });
  }
});

app.put('/api/members/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل صلاحيات الأعضاء')) return;
  try {
    const memberId = Number(req.params.id);
    const prevUser = await repo.getUserById(memberId);
    const updated = await repo.updateUser(memberId, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'الحساب غير موجود في قاعدة البيانات' });
    }
    if (prevUser) {
      if (req.body?.isActive !== undefined && Boolean(prevUser.isActive) !== Boolean(updated.isActive)) {
        await recordSensitiveAuditLog(req, {
          action: updated.isActive ? 'account_activate' : 'account_deactivate',
          actionAr: updated.isActive ? 'تفعيل حساب مستخدم' : 'إيقاف حساب مستخدم',
          entityType: 'account_status',
          entityName: updated.displayName || updated.username || updated.email,
          details: updated.isActive
            ? `تم تفعيل حساب (${updated.displayName}) [@${updated.username || updated.email}] والسماح له بالدخول`
            : `تم إيقاف/تعطيل حساب (${updated.displayName}) [@${updated.username || updated.email}] ومنعه من الدخول`,
          severity: updated.isActive ? 'warning' : 'critical',
        });
      }
      const roleChanged = req.body?.role !== undefined && prevUser.role !== updated.role;
      const permsChanged = req.body?.permissions !== undefined && String(prevUser.permissions || '[]') !== String(updated.permissions || '[]');
      if (roleChanged || permsChanged) {
        await recordSensitiveAuditLog(req, {
          action: 'permission_change',
          actionAr: 'تغيير صلاحية أو دور مستخدم',
          entityType: 'permission',
          entityName: updated.displayName || updated.username || updated.email,
          details: `تم تعديل صلاحيات/دور (${updated.displayName}): الدور من [${ROLE_LABELS_AR[prevUser.role] || prevUser.role}] إلى [${ROLE_LABELS_AR[updated.role] || updated.role}]`,
          severity: 'critical',
        });
      }
    }
    res.json(updated);
  } catch (err: any) {
    const status = err?.statusCode || 500;
    res.status(status).json({ error: err.message });
  }
});

app.delete('/api/members/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف حسابات الأعضاء')) return;
  try {
    const memberId = Number(req.params.id);
    const prevUser = await repo.getUserById(memberId);
    const result = await repo.deleteUser(memberId);
    await recordSensitiveAuditLog(req, {
      action: 'account_delete',
      actionAr: 'حذف حساب مستخدم',
      entityType: 'account_status',
      entityName: prevUser?.displayName || String(memberId),
      details: `تم حذف حساب (${prevUser?.displayName || memberId}) [@${prevUser?.username || prevUser?.email || '-'}] نهائياً`,
      severity: 'critical',
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= AUTHENTICATION, REGISTRATION & PASSWORD RECOVERY =================
app.post('/api/auth/register', async (req, res) => {
  try {
    const result = await repo.registerUser(req.body || {});
    if (!result.success) {
      return res.status(result.statusCode || 400).json({
        success: false,
        error: result.error,
      });
    }
    res.status(201).json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { identifier, password, deviceId, deviceLabel, userAgent } = req.body || {};
    const result = await repo.verifyUserCredentials(identifier, password);
    if (!result.success) {
      const status = result.statusCode || (result.pendingApproval ? 403 : 401);
      return res.status(status).json({
        success: false,
        pendingApproval: Boolean(result.pendingApproval),
        error: result.error,
      });
    }

    // Strict Device (1 device default) + IP + Geographic Location Binding (Super Admin & Admin are exempt)
    const userObj: any = (result as any).user || {};
    const uRole = String(userObj.role || 'student');
    const uName = String(userObj.displayName || userObj.name || '');
    const isExempt = isAccountExemptFromDeviceLock({
      uid: userObj.uid,
      role: uRole,
      username: userObj.username,
      email: userObj.email,
      name: uName,
      isSuperAdmin: Boolean(userObj.isSuperAdmin),
    });

    if (!isExempt && deviceId) {
      const [rawCfg, rawBindings] = await Promise.all([
        repo.getSystemSetting('alsharif_security_drm_config_v1'),
        repo.getSystemSetting('alsharif_device_bindings_v1'),
      ]);
      const secCfg = rawCfg
        ? {
            enableDeviceBinding: true,
            maxDevicesPerStudent: 1,
            enforceStrictIpBinding: true,
            enforceStrictGeoBinding: true,
            ...JSON.parse(rawCfg),
          }
        : {
            enableDeviceBinding: true,
            maxDevicesPerStudent: 1,
            enforceStrictIpBinding: true,
            enforceStrictGeoBinding: true,
          };

      const records: any[] = rawBindings ? JSON.parse(rawBindings) : [];
      const userKey = String(
        userObj.uid || userObj.username || userObj.email || identifier
      ).toLowerCase();
      const networkCtx = await extractClientNetworkContext(req, req.body || {});

      const evalResult = evaluateDeviceAndNetworkAccess({
        records,
        config: secCfg,
        user: {
          userKey,
          studentId: userObj.studentId || userObj.uid || '',
          studentName: uName || userObj.username || 'مستخدم',
          username: userObj.username || '',
          email: userObj.email || '',
          phone: userObj.phone || '',
          role: uRole,
        },
        deviceId: String(deviceId),
        deviceLabel: deviceLabel ? String(deviceLabel) : undefined,
        userAgent: userAgent ? String(userAgent) : undefined,
        networkCtx,
      });

      await repo.setSystemSetting(
        'alsharif_device_bindings_v1',
        JSON.stringify(evalResult.records)
      );
      broadcastAll({
        type: 'content_security:devices_updated',
        deviceRecords: evalResult.records,
      });

      if (!evalResult.allowed) {
        await recordSensitiveAuditLog(req, {
          action: evalResult.blockReasonCode || 'device_security_blocked',
          actionAr:
            evalResult.blockReasonCode === 'ip_changed'
              ? 'حظر دخول بسبب تغيير عنوان الـ IP على نفس الجهاز'
              : evalResult.blockReasonCode === 'geo_changed'
              ? 'حظر دخول بسبب الانتقال الجغرافي (قرية/مدينة/محافظة/دولة)'
              : 'حظر دخول بسبب محاولة فتح الحساب على أكثر من جهاز بدون تفعيل الأدمن',
          entityType: 'security',
          entityName: uName || userObj.username || identifier,
          details: `${evalResult.messageAr || ''} [IP: ${networkCtx.ip} | الموقع: ${networkCtx.geoLabelAr}]`,
          severity: 'warning',
        });

        return res.status(403).json({
          success: false,
          deviceBlocked: true,
          deviceLimitBlocked: evalResult.blockReasonCode === 'device_limit_exceeded',
          ipMismatchBlocked: evalResult.blockReasonCode === 'ip_changed',
          geoMismatchBlocked: evalResult.blockReasonCode === 'geo_changed',
          blockReasonCode: evalResult.blockReasonCode,
          requiresAdminActivation: true,
          maxDevices: evalResult.maxDevices,
          boundDevices: evalResult.record.devices,
          currentIp: networkCtx.ip,
          currentGeoLabel: networkCtx.geoLabelAr,
          error: evalResult.messageAr,
        });
      }
    }

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/auth/forgot-password/question', async (req, res) => {
  try {
    const { identifier } = req.body;
    const result = await repo.getUserSecurityQuestion(identifier);
    if (!result.found) {
      return res.status(404).json(result);
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ found: false, error: err.message });
  }
});

app.post('/api/auth/forgot-password/verify', async (req, res) => {
  try {
    const { identifier, securityAnswer, newPassword } = req.body;
    const result = await repo.verifySecurityAnswerAndReset(identifier, securityAnswer, newPassword);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ================= CRUD: TIMETABLE =================
app.get('/api/timetable', async (req, res) => {
  try {
    const data = await repo.getAllTimetable({
      search: typeof req.query.search === 'string' ? req.query.search : undefined,
      day: typeof req.query.day === 'string' ? req.query.day : undefined,
      type: typeof req.query.type === 'string' ? req.query.type : undefined,
      grade: typeof req.query.grade === 'string' ? req.query.grade : undefined,
      status: typeof req.query.status === 'string' ? req.query.status : undefined,
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/timetable', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بإضافة حصص للجدول الدراسي')) return;
  try {
    const { subject, time, teacherName, grade, roomOrLink } = req.body || {};
    if (!subject?.trim() || !time?.trim() || !teacherName?.trim() || !grade?.trim() || !roomOrLink?.trim()) {
      return res.status(400).json({
        error: 'يرجى استيفاء الحقول المطلوبة: المادة، التوقيت، المعلم، الصف الدراسي، والقاعة أو الرابط',
      });
    }
    const slot = await repo.createTimetableSlot(req.body);
    res.status(201).json(slot);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/timetable/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل الجدول الدراسي')) return;
  try {
    const updated = await repo.updateTimetableSlot(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'الحصة غير موجودة في قاعدة البيانات' });
    }
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/timetable/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف حصص الجدول الدراسي')) return;
  try {
    const result = await repo.deleteTimetableSlot(req.params.id);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: INVOICES / PAYMENTS =================
app.get('/api/invoices', async (req, res) => {
  try {
    const data = await repo.getAllInvoices();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/invoices', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بإنشاء مطالبات مالية')) return;
  try {
    const invoice = await repo.createInvoice(req.body);
    res.json(invoice);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/invoices/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل الفواتير')) return;
  try {
    const updated = await repo.updateInvoice(req.params.id, req.body);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/invoices/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف الفواتير')) return;
  try {
    const result = await repo.deleteInvoice(req.params.id);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: NOTIFICATIONS =================
app.get('/api/notifications', async (req, res) => {
  try {
    const data = await repo.getAllNotifications({
      search: typeof req.query.search === 'string' ? req.query.search : undefined,
      category: typeof req.query.category === 'string' ? req.query.category : undefined,
      target: typeof req.query.target === 'string' ? req.query.target : undefined,
      read: typeof req.query.read === 'string' ? req.query.read : undefined,
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/notifications', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'صلاحية بث الإشعارات الإدارية متاحة للإدارة فقط')) return;
  try {
    const { title, message } = req.body || {};
    if (!title?.trim() || !message?.trim()) {
      return res.status(400).json({ error: 'يرجى إدخال عنوان الإشعار ونص الرسالة' });
    }
    const notif = await repo.createNotification(req.body);
    broadcastAll({ type: 'notification:created', notification: notif });
    dispatchWebPushNotification({
      title: notif.title,
      body: notif.message,
      target: notif.target,
      url: '/',
      tag: `notif-${notif.id}`,
    });
    res.status(201).json(notif);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/notifications/:id', async (req, res) => {
  const role = getRequestRole(req);
  if (role && ['student', 'female_student', 'parent', 'teacher', 'visitor'].includes(role)) {
    const keys = Object.keys(req.body || {});
    if (!(keys.length === 1 && keys[0] === 'read')) {
      return res.status(403).json({ error: 'غير مصرح بتعديل محتوى الإشعارات' });
    }
  }
  try {
    const updated = await repo.updateNotification(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'الإشعار غير موجود في قاعدة البيانات' });
    }
    broadcastAll({ type: 'notification:updated', notification: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/notifications/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف الإشعارات')) return;
  try {
    const result = await repo.deleteNotification(req.params.id);
    broadcastAll({ type: 'notification:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: FAQS =================
app.get('/api/faqs', async (req, res) => {
  try {
    const data = await repo.getAllFaqs({
      search: typeof req.query.search === 'string' ? req.query.search : undefined,
      category: typeof req.query.category === 'string' ? req.query.category : undefined,
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/faqs', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بإضافة أسئلة شائعة')) return;
  try {
    const { questionAr, questionEn, answerAr, answerEn } = req.body || {};
    if (!(questionAr?.trim() || questionEn?.trim()) || !(answerAr?.trim() || answerEn?.trim())) {
      return res.status(400).json({ error: 'يرجى إدخال نص السؤال والإجابة المعتمدة' });
    }
    const faq = await repo.createFaq(req.body);
    res.status(201).json(faq);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/faqs/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل الأسئلة الشائعة')) return;
  try {
    const updated = await repo.updateFaq(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'السؤال الشائع غير موجود في قاعدة البيانات' });
    }
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/faqs/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف الأسئلة الشائعة')) return;
  try {
    const result = await repo.deleteFaq(req.params.id);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CRUD: INQUIRIES (الاستفسارات والاقتراحات والشكاوى) =================
app.get('/api/inquiries', async (req, res) => {
  try {
    const data = await repo.getAllInquiries({
      search: typeof req.query.search === 'string' ? req.query.search : undefined,
      status: typeof req.query.status === 'string' ? req.query.status : undefined,
      category: typeof req.query.category === 'string' ? req.query.category : undefined,
      priority: typeof req.query.priority === 'string' ? req.query.priority : undefined,
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/inquiries', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'teacher'], 'إرسال الاقتراحات والشكاوى مخصص لولي الأمر والإدارة')) return;
  try {
    const { subject, message } = req.body || {};
    if (!subject?.trim() || !message?.trim()) {
      return res.status(400).json({ error: 'يرجى إدخال موضوع الرسالة وتفاصيلها' });
    }
    const created = await repo.createInquiry(req.body);
    broadcastAll({ type: 'inquiry:created', inquiry: created });
    res.status(201).json(created);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/inquiries/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل أو الرد على الشكاوى والاستفسارات')) return;
  try {
    const updated = await repo.updateInquiry(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'الاستفسار غير موجود في قاعدة البيانات' });
    }
    broadcastAll({ type: 'inquiry:updated', inquiry: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/inquiries/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بحذف الشكاوى والاستفسارات')) return;
  try {
    const result = await repo.deleteInquiry(req.params.id);
    broadcastAll({ type: 'inquiry:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= AUDIT LOGS (سجل المراجعة والرقابة للمدير العام) =================
app.get('/api/audit-logs', async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 200;
    const data = await repo.getAllAuditLogs(limit);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/audit-logs', async (req, res) => {
  try {
    const created = await repo.createAuditLog(req.body || {});
    broadcastAll({ type: 'audit_log:created', log: created });
    res.status(201).json(created);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/audit-logs/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'secretary', 'supervisor', 'visitor'], 'حذف سجلات المراجعة متاح للمدير العام فقط')) return;
  try {
    const result = await repo.deleteAuditLog(req.params.id);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/audit-logs', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'secretary', 'supervisor', 'visitor'], 'تفريغ سجل المراجعة متاح للمدير العام فقط')) return;
  try {
    const result = await repo.clearAllAuditLogs();
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= LESSON RATING SURVEYS (استبيانات تقييم الدروس) =================
app.get('/api/lesson-ratings', async (req, res) => {
  try {
    const data = await repo.getAllLessonRatings({
      lessonId: typeof req.query.lessonId === 'string' ? req.query.lessonId : undefined,
      studentId: typeof req.query.studentId === 'string' ? req.query.studentId : undefined,
      teacherId: typeof req.query.teacherId === 'string' ? req.query.teacherId : undefined,
    });
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/lesson-ratings', async (req, res) => {
  if (rejectIfRole(req, res, ['parent', 'visitor'], 'تقييم الدروس متاح للطلاب والطالبات وإدارة الجودة')) return;
  try {
    const { lessonId, studentId, rating } = req.body || {};
    if (!lessonId || !studentId || !rating) {
      return res.status(400).json({ error: 'يرجى تحديد الدرس والتقييم بالنجوم' });
    }
    const saved = await repo.upsertLessonRating(req.body);
    broadcastAll({ type: 'lesson_rating:upserted', rating: saved });
    res.status(201).json(saved);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/lesson-ratings/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'حذف التقييمات متاح للمدير العام والمشرف فقط')) return;
  try {
    const result = await repo.deleteLessonRating(req.params.id);
    broadcastAll({ type: 'lesson_rating:deleted', id: req.params.id });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= WEB PUSH NOTIFICATIONS & PWA SUBSCRIPTIONS =================
app.get('/api/push/vapid-public-key', async (_req, res) => {
  try {
    const keys = await ensureVapidConfig();
    res.json({ publicKey: keys.publicKey });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/push/subscribe', async (req, res) => {
  try {
    const { subscription, userId, userRole, userName, deviceLabel } = req.body || {};
    if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
      return res.status(400).json({ error: 'بيانات اشتراك الإشعارات غير مكتملة' });
    }
    const saved = await repo.savePushSubscription({
      endpoint: subscription.endpoint,
      p256dh: subscription.keys.p256dh,
      auth: subscription.keys.auth,
      userId,
      userRole,
      userName,
      deviceLabel,
    });
    res.status(201).json({ success: true, subscription: saved });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/push/unsubscribe', async (req, res) => {
  try {
    const endpoint = String(req.body?.endpoint || '').trim();
    if (!endpoint) return res.status(400).json({ error: 'endpoint required' });
    const result = await repo.deletePushSubscriptionByEndpoint(endpoint);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/push/test', async (req, res) => {
  try {
    const { title, body, target } = req.body || {};
    const stats = await dispatchWebPushNotification({
      title: title || '🔔 إشعار تجريبي من منصة نوابغ التعليمية',
      body: body || 'تعمل إشعارات المتصفح والتطبيق بنجاح حتى عندما يكون التطبيق مغلقاً.',
      target: target || 'all',
      url: '/',
      tag: `test-${Date.now()}`,
    });
    res.json({ success: true, ...stats });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= SCHOOL CUSTOMIZATION SETTINGS & HERO SLIDER =================
app.get('/api/school-settings', async (req, res) => {
  try {
    const data = await repo.getSchoolSettings();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/school-settings', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل إعدادات المنصة')) return;
  try {
    const updated = await repo.updateSchoolSettings(req.body);
    broadcastAll({ type: 'settings:updated', settings: updated });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/hero-slider', async (_req, res) => {
  try {
    const raw = await repo.getSystemSetting('hero_slider_config_v1');
    res.json(raw ? JSON.parse(raw) : null);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/hero-slider', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'غير مصرح بتعديل سلايدر الصفحة الرئيسية')) return;
  try {
    const sliderConfig = req.body;
    await repo.setSystemSetting('hero_slider_config_v1', JSON.stringify(sliderConfig));
    const updatedSettings = await repo.getSchoolSettings();
    broadcastAll({ type: 'settings:updated', settings: updatedSettings });
    res.json({ success: true, heroSlider: sliderConfig, settings: updatedSettings });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= ANTI-SCREEN-RECORDING & ACCOUNT DELETION ENFORCEMENT =================
app.post('/api/security/clear-super-admin-penalties', async (_req, res) => {
  try {
    await repo.purgeSuperAdminViolationsAndWarnings();
    res.json({ success: true, cleared: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/security/screen-capture-violation', async (req, res) => {
  try {
    const {
      userId,
      username,
      email,
      name,
      role,
      studentId,
      teacherId,
      isSuperAdmin,
      reason,
      clientViolationCount,
    } = req.body || {};

    // STRICT IMMUNITY FOR GENERAL MANAGER / SUPER ADMIN (Mo-NewFolder)
    // ممنوع عقاب أو إنذار أو حذف حساب المدير العام (Mo-NewFolder / الأدمن العام) بأي حال من الأحوال
    const nameStr = String(name || '');
    const usernameStr = String(username || '').toLowerCase();
    const emailStr = String(email || '').toLowerCase();
    const isExemptSuperAdmin =
      Boolean(isSuperAdmin) ||
      userId === 'usr-super-admin' ||
      role === 'admin' ||
      usernameStr.includes('mo-newfolder') ||
      emailStr.includes('mo-newfolder') ||
      nameStr.includes('Mo-NewFolder') ||
      nameStr.includes('الأدمن العام') ||
      nameStr.includes('المدير العام');

    const identifierKey = `screen_violation_${String(username || email || userId || 'guest').toLowerCase()}`;

    if (isExemptSuperAdmin) {
      await repo.setSystemSetting(identifierKey, '0');
      await repo.purgeSuperAdminViolationsAndWarnings();
      return res.json({
        success: true,
        exempt: true,
        isSuperAdminExempt: true,
        violationCount: 0,
        accountDeleted: false,
        message: 'المدير العام (Mo-NewFolder) معفى تماماً من أي عقاب أو إنذار أو حذف حساب.',
      });
    }

    const prevRaw = await repo.getSystemSetting(identifierKey);
    const prevCount = prevRaw ? Number(prevRaw) || 0 : 0;
    const nextCount = Math.max(prevCount + 1, Number(clientViolationCount) || 1);

    await repo.setSystemSetting(identifierKey, String(nextCount));

    let accountDeleted = false;

    if (nextCount >= 2) {
      accountDeleted = true;

      if (role !== 'visitor') {
        try {
          const allMembers = await repo.getAllUsers();
          const matchedMember = allMembers.find(
            (m: any) =>
              m.uid === userId ||
              `usr-${m.id}` === userId ||
              (username && String(m.username || '').toLowerCase() === String(username).toLowerCase()) ||
              (email && String(m.email || '').toLowerCase() === String(email).toLowerCase())
          );
          if (
            matchedMember &&
            typeof matchedMember.id === 'number' &&
            matchedMember.uid !== 'usr-super-admin' &&
            String(matchedMember.username || '').toLowerCase() !== 'mo-newfolder'
          ) {
            await repo.deleteUser(matchedMember.id);
            broadcastAll({ type: 'member:deleted', id: matchedMember.id, uid: matchedMember.uid });
          }

          if (studentId) {
            await repo.deleteStudent(studentId);
            broadcastAll({ type: 'student:deleted', id: studentId });
          } else {
            const allStudents = await repo.getAllStudents();
            const matchedStu = allStudents.find(
              (s: any) =>
                s.id === userId ||
                (name && s.name === name) ||
                (email && s.parentEmail === email)
            );
            if (matchedStu) {
              await repo.deleteStudent(matchedStu.id);
              broadcastAll({ type: 'student:deleted', id: matchedStu.id });
            }
          }

          if (teacherId) {
            await repo.deleteTeacher(teacherId);
            broadcastAll({ type: 'teacher:deleted', id: teacherId });
          }
        } catch (delErr) {
          console.warn('Error deleting violating user records:', delErr);
        }
      }

      await recordSensitiveAuditLog(req, {
        action: 'account_delete_piracy',
        actionAr: 'حذف حساب نهائياً لتكرار تصوير الشاشة بالفيديو (ممنوع السرقه)',
        entityType: 'account_status',
        entityName: name || username || email || userId || 'مستخدم',
        details: `تكرار محاولة تصوير الشاشة بالفيديو (${nextCount} مرات) — السبب: ${
          reason || 'تصوير شاشة'
        }. تم إظهار الشاشة السوداء (ممنوع السرقه) وحذف الحساب نهائياً من المنصة كلها.`,
        severity: 'critical',
      });
    } else {
      await recordSensitiveAuditLog(req, {
        action: 'screen_record_warning',
        actionAr: 'تحذير أمني (1/2): محاولة تصوير الشاشة بالفيديو',
        entityType: 'security',
        entityName: name || username || email || userId || 'مستخدم',
        details: `تم رصد محاولة تصوير الشاشة بالفيديو (${
          reason || 'تصوير شاشة'
        }) وتعتيم الفيديو بشاشة سوداء مع رسالة (ممنوع السرقه). في حال التكرار سيتم حذف الحساب نهائياً.`,
        severity: 'warning',
      });
    }

    res.json({
      success: true,
      violationCount: nextCount,
      accountDeleted,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= FLASHCARDS, AL-SHARIF COMPETITIONS & DIGITAL GIFTS (100% REAL DB) =================
const DEFAULT_STORE_CATALOG = [
  {
    id: 'store-free-lesson',
    rewardType: 'free_lesson_unlock',
    title: 'فتح درس مدفوع مجاناً (بطاقة فتح درس فورية)',
    description: 'استبدل نقاطك بكود تفعيل رسمي يفتح لك أي درس محمي أو مدفوع في منصة الشريف لمدة 30 يوماً مجاناً.',
    costPoints: 250,
    badgeText: 'فتح درس مجاني 🔓',
    iconName: 'unlock',
  },
  {
    id: 'store-month-discount',
    rewardType: 'next_month_discount',
    title: 'قسيمة خصم 50% على اشتراك الشهر القادم',
    description: 'كوبون خصم رسمي موثق في الإدارة المالية يمنحك خصم 50% عند تجديد اشتراك الشهر القادم.',
    costPoints: 400,
    badgeText: 'خصم 50% شهري 💳',
    iconName: 'discount',
  },
  {
    id: 'store-golden-cert',
    rewardType: 'golden_certificate',
    title: 'شهادة التميز الذهبية المعتمدة من منصة الشريف',
    description: 'إصدار فوري لشهادة تقدير وتميز ذهبية رسمية باسمك في قسم الشهادات وبوابة ولي الأمر.',
    costPoints: 350,
    badgeText: 'شهادة تميز ذهبية 🏆',
    iconName: 'certificate',
  },
  {
    id: 'store-badge-knight',
    rewardType: 'special_profile_badge',
    title: 'وسام «👑 فارس مسابقة الشريف» بجانب اسمك',
    description: 'وسام ذهبي خاص يظهر بجانب اسمك في لوحة الشرف، غرف التحدي المباشر، والمسابقات.',
    costPoints: 200,
    badgeText: '👑 فارس الشريف',
    iconName: 'badge',
  },
  {
    id: 'store-badge-lightning',
    rewardType: 'special_profile_badge',
    title: 'وسام «⚡ أسرع عقل في التحدي المباشر» بجانب اسمك',
    description: 'وسام خاص يظهر بجانب اسمك يميزك كأحد أبطال غرف التحدي المباشر 1 ضد 1.',
    costPoints: 300,
    badgeText: '⚡ صاعقة التحدي',
    iconName: 'badge',
  },
];

app.get('/api/flashcards-competitions', async (_req, res) => {
  try {
    const [
      rawCards,
      rawGifts,
      rawHistory,
      rawRooms,
      rawLeague,
      rawStoreItems,
      rawStoreRedemptions,
      rawBadges,
      rawSpacedRep,
      rawBonusPoints,
      dbLessons,
      dbQuizzes,
      dbStudents,
      extractedFromDb,
    ] = await Promise.all([
      repo.getSystemSetting('custom_flashcards_v1'),
      repo.getSystemSetting('student_digital_gifts_v1'),
      repo.getSystemSetting('competition_history_v1'),
      repo.getSystemSetting('alsharif_live_challenge_rooms_v1'),
      repo.getSystemSetting('alsharif_weekly_league_v1'),
      repo.getSystemSetting('alsharif_rewards_store_items_v1'),
      repo.getSystemSetting('alsharif_store_redemptions_v1'),
      repo.getSystemSetting('alsharif_student_badges_v1'),
      repo.getSystemSetting('alsharif_spaced_repetition_v1'),
      repo.getSystemSetting('alsharif_student_bonus_points_v1'),
      repo.getAllLessons(),
      repo.getAllQuizzes(),
      repo.getAllStudents(),
      repo.generateQuizQuestionsFromDbLessons({ count: 30, questionMix: 'mixed' }),
    ]);
    const customFlashcards = rawCards ? JSON.parse(rawCards) : [];
    const digitalGifts = rawGifts ? JSON.parse(rawGifts) : [];
    const competitionHistory = rawHistory ? JSON.parse(rawHistory) : [];
    const liveChallengeRooms = rawRooms ? JSON.parse(rawRooms) : [];
    const weeklyLeague = rawLeague ? JSON.parse(rawLeague) : [];
    const storeCatalog = rawStoreItems ? JSON.parse(rawStoreItems) : DEFAULT_STORE_CATALOG;
    const storeRedemptions = rawStoreRedemptions ? JSON.parse(rawStoreRedemptions) : [];
    const studentBadges = rawBadges ? JSON.parse(rawBadges) : {};
    const spacedRepetitionRecords = rawSpacedRep ? JSON.parse(rawSpacedRep) : {};
    const bonusPointsMap = rawBonusPoints ? JSON.parse(rawBonusPoints) : {};

    res.json({
      customFlashcards: Array.isArray(customFlashcards) ? customFlashcards : [],
      digitalGifts: Array.isArray(digitalGifts) ? digitalGifts : [],
      competitionHistory: Array.isArray(competitionHistory) ? competitionHistory : [],
      liveChallengeRooms: Array.isArray(liveChallengeRooms) ? liveChallengeRooms : [],
      weeklyLeague: Array.isArray(weeklyLeague) ? weeklyLeague : [],
      storeCatalog: Array.isArray(storeCatalog) && storeCatalog.length > 0 ? storeCatalog : DEFAULT_STORE_CATALOG,
      storeRedemptions: Array.isArray(storeRedemptions) ? storeRedemptions : [],
      studentBadges: studentBadges && typeof studentBadges === 'object' ? studentBadges : {},
      spacedRepetitionRecords:
        spacedRepetitionRecords && typeof spacedRepetitionRecords === 'object'
          ? spacedRepetitionRecords
          : {},
      bonusPointsMap: bonusPointsMap && typeof bonusPointsMap === 'object' ? bonusPointsMap : {},
      dbLessons: Array.isArray(dbLessons) ? dbLessons : [],
      dbQuizzes: Array.isArray(dbQuizzes) ? dbQuizzes : [],
      dbStudents: Array.isArray(dbStudents) ? dbStudents : [],
      dbLessonQuestions: Array.isArray(extractedFromDb?.questions)
        ? extractedFromDb.questions
        : [],
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/extract-from-lessons', async (req, res) => {
  try {
    const result = await repo.generateQuizQuestionsFromDbLessons({
      lessonIds: req.body?.lessonIds,
      formatFilter: req.body?.formatFilter || 'all',
      count: Number(req.body?.count) || 30,
      questionMix: req.body?.questionMix || 'mixed',
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/flashcards', async (req, res) => {
  try {
    const rawCards = await repo.getSystemSetting('custom_flashcards_v1');
    const current: any[] = rawCards ? JSON.parse(rawCards) : [];
    const card = req.body;
    if (!card || !card.question) {
      return res.status(400).json({ error: 'بيانات الفلاش كارد غير مكتملة' });
    }
    const newCard = {
      ...card,
      id: card.id || `fc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: card.createdAt || new Date().toISOString().split('T')[0],
    };
    const nextList = [newCard, ...current.filter((c) => c.id !== newCard.id)];
    await repo.setSystemSetting('custom_flashcards_v1', JSON.stringify(nextList));
    broadcastAll({ type: 'flashcard:created', item: newCard });
    res.status(201).json(newCard);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/flashcards-competitions/flashcards/:id', async (req, res) => {
  try {
    const rawCards = await repo.getSystemSetting('custom_flashcards_v1');
    const current: any[] = rawCards ? JSON.parse(rawCards) : [];
    const nextList = current.filter((c) => c.id !== req.params.id);
    await repo.setSystemSetting('custom_flashcards_v1', JSON.stringify(nextList));
    broadcastAll({ type: 'flashcard:deleted', id: req.params.id });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/gifts', async (req, res) => {
  try {
    const rawGifts = await repo.getSystemSetting('student_digital_gifts_v1');
    const current: any[] = rawGifts ? JSON.parse(rawGifts) : [];
    const gift = req.body;
    if (!gift || !gift.studentName || !gift.giftTitle) {
      return res.status(400).json({ error: 'بيانات الهدية الرقمية غير مكتملة' });
    }
    const newGift = {
      ...gift,
      id: gift.id || `gift-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      serialCode:
        gift.serialCode ||
        `SHARIF-GIFT-${Math.floor(100000 + Math.random() * 900000)}`,
      awardedAt:
        gift.awardedAt ||
        new Date().toLocaleDateString('ar-EG', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        }),
    };
    const nextList = [newGift, ...current.filter((g) => g.id !== newGift.id)].slice(0, 200);
    await repo.setSystemSetting('student_digital_gifts_v1', JSON.stringify(nextList));
    broadcastAll({ type: 'digital_gift:awarded', item: newGift });
    res.status(201).json(newGift);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/history', async (req, res) => {
  try {
    const rawHistory = await repo.getSystemSetting('competition_history_v1');
    const current: any[] = rawHistory ? JSON.parse(rawHistory) : [];
    const record = req.body;
    const newRecord = {
      ...record,
      id: record.id || `comp-${Date.now()}`,
      completedAt:
        record.completedAt ||
        new Date().toLocaleString('ar-EG', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
    };
    const nextList = [newRecord, ...current].slice(0, 100);
    await repo.setSystemSetting('competition_history_v1', JSON.stringify(nextList));
    broadcastAll({ type: 'competition:completed', item: newRecord });
    res.status(201).json(newRecord);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 1. LIVE 1v1 & TEAM CHALLENGE ROOMS (غرف التحدي المباشر 1 ضد 1 أو فرق + الدوري الأسبوعي)
app.post('/api/flashcards-competitions/challenge-rooms', async (req, res) => {
  try {
    const {
      title,
      mode, // '1v1' | 'teams'
      subject,
      grade,
      sideAName,
      sideBName,
      sideAPlayers,
      sideBPlayers,
      questions,
      createdBy,
    } = req.body || {};

    if (!Array.isArray(questions) || questions.length === 0) {
      return res.status(400).json({ error: 'لا توجد أسئلة كافية من الدروس لإنشاء غرفة التحدي' });
    }

    const rawRooms = await repo.getSystemSetting('alsharif_live_challenge_rooms_v1');
    const rooms: any[] = rawRooms ? JSON.parse(rawRooms) : [];

    const roomCode = `CH-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRoom = {
      id: `room-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      roomCode,
      title: title || 'تحدي الشريف المباشر — الأسرع يربح الضعف (×2)',
      mode: mode === 'teams' ? 'teams' : '1v1',
      subject: subject || 'كل المواد',
      grade: grade || 'كل المراحل',
      status: 'active', // 'waiting' | 'active' | 'finished'
      sideA: {
        name: sideAName || 'المتسابق الأول / فريق الصقور',
        players: Array.isArray(sideAPlayers) ? sideAPlayers : [sideAName || 'المتسابق الأول'],
        score: 0,
        correctCount: 0,
        fastestCount: 0,
      },
      sideB: {
        name: sideBName || 'المتسابق الثاني / فريق النخبة',
        players: Array.isArray(sideBPlayers) ? sideBPlayers : [sideBName || 'المتسابق الثاني'],
        score: 0,
        correctCount: 0,
        fastestCount: 0,
      },
      currentQuestionIndex: 0,
      questionStartedAt: Date.now(),
      questions: questions.map((q: any, idx: number) => ({
        index: idx,
        questionText: q.questionText || q.question,
        options: q.options || [],
        correctOptionIndex: q.correctOptionIndex ?? 0,
        explanation: q.explanation || '',
        subject: q.subject || subject || 'عام',
        sourceLessonTitle: q.sourceLessonTitle || q.lessonTitle || '',
        basePoints: 100,
        sideAAnswer: null,
        sideBAnswer: null,
        firstCorrectSide: null, // 'A' | 'B' | null
        winnerBanner: null,
      })),
      createdBy: createdBy || 'منصة الشريف',
      createdAt: new Date().toLocaleString('ar-EG'),
    };

    const nextRooms = [newRoom, ...rooms].slice(0, 30);
    await repo.setSystemSetting('alsharif_live_challenge_rooms_v1', JSON.stringify(nextRooms));
    broadcastAll({ type: 'challenge_room:updated', room: newRoom, allRooms: nextRooms });
    res.status(201).json({ success: true, room: newRoom, allRooms: nextRooms });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/challenge-rooms/:roomId/join', async (req, res) => {
  try {
    const { side, playerName } = req.body || {};
    const rawRooms = await repo.getSystemSetting('alsharif_live_challenge_rooms_v1');
    const rooms: any[] = rawRooms ? JSON.parse(rawRooms) : [];
    const room = rooms.find((r) => r.id === req.params.roomId || r.roomCode === req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'غرفة التحدي غير موجودة' });
    }
    const cleanName = String(playerName || '').trim();
    if (cleanName) {
      const targetSide = side === 'B' ? room.sideB : room.sideA;
      if (!targetSide.players.includes(cleanName)) {
        targetSide.players.push(cleanName);
      }
      if (room.mode === '1v1') {
        targetSide.name = cleanName;
      }
    }
    await repo.setSystemSetting('alsharif_live_challenge_rooms_v1', JSON.stringify(rooms));
    broadcastAll({ type: 'challenge_room:updated', room, allRooms: rooms });
    res.json({ success: true, room, allRooms: rooms });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/challenge-rooms/:roomId/answer', async (req, res) => {
  try {
    const { side, optionIndex, playerName } = req.body || {};
    const rawRooms = await repo.getSystemSetting('alsharif_live_challenge_rooms_v1');
    const rooms: any[] = rawRooms ? JSON.parse(rawRooms) : [];
    const room = rooms.find((r) => r.id === req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'غرفة التحدي غير موجودة' });
    }

    const qIdx = room.currentQuestionIndex || 0;
    const currentQ = room.questions[qIdx];
    if (!currentQ) {
      return res.status(400).json({ error: 'انتهت أسئلة هذه الغرفة' });
    }

    const isSideA = side === 'A';
    const existingAns = isSideA ? currentQ.sideAAnswer : currentQ.sideBAnswer;
    if (existingAns !== null && existingAns !== undefined) {
      return res.json({ success: true, room, alreadyAnswered: true });
    }

    const elapsedMs = Math.max(200, Date.now() - (room.questionStartedAt || Date.now()));
    const isCorrect = Number(optionIndex) === Number(currentQ.correctOptionIndex);
    let awardedPoints = 0;
    let isFastestDouble = false;

    if (isCorrect) {
      if (!currentQ.firstCorrectSide) {
        // الأسرع في الإجابة الصحيحة يحصل على نقاط مضاعفة (×2)
        currentQ.firstCorrectSide = isSideA ? 'A' : 'B';
        isFastestDouble = true;
        awardedPoints = (currentQ.basePoints || 100) * 2;
        const winnerTitle = isSideA ? room.sideA.name : room.sideB.name;
        currentQ.winnerBanner = `⚡ ${winnerTitle} أجاب أولاً في ${(elapsedMs / 1000).toFixed(1)} ثانية وحصل على نقاط مضاعفة (+${awardedPoints} نقطة)!`;
      } else {
        awardedPoints = currentQ.basePoints || 100;
      }

      if (isSideA) {
        room.sideA.score += awardedPoints;
        room.sideA.correctCount += 1;
        if (isFastestDouble) room.sideA.fastestCount += 1;
      } else {
        room.sideB.score += awardedPoints;
        room.sideB.correctCount += 1;
        if (isFastestDouble) room.sideB.fastestCount += 1;
      }
    }

    const answerPayload = {
      optionIndex: Number(optionIndex),
      isCorrect,
      elapsedMs,
      awardedPoints,
      isFastestDouble,
      answeredBy: playerName || (isSideA ? room.sideA.name : room.sideB.name),
    };

    if (isSideA) {
      currentQ.sideAAnswer = answerPayload;
    } else {
      currentQ.sideBAnswer = answerPayload;
    }

    // Update Weekly League Leaderboard if points were earned
    if (awardedPoints > 0) {
      const rawLeague = await repo.getSystemSetting('alsharif_weekly_league_v1');
      const league: any[] = rawLeague ? JSON.parse(rawLeague) : [];
      const targetParticipants = isSideA ? room.sideA.players : room.sideB.players;
      const namesToCredit =
        Array.isArray(targetParticipants) && targetParticipants.length > 0
          ? targetParticipants
          : [isSideA ? room.sideA.name : room.sideB.name];

      for (const pName of namesToCredit) {
        const clean = String(pName || '').trim();
        if (!clean) continue;
        let entry = league.find((e) => e.studentName === clean);
        if (!entry) {
          entry = {
            id: `lg-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
            studentName: clean,
            points: 0,
            wins: 0,
            fastestAnswers: 0,
            matchesPlayed: 1,
            updatedAt: new Date().toLocaleDateString('ar-EG'),
          };
          league.push(entry);
        }
        entry.points += awardedPoints;
        if (isFastestDouble) entry.fastestAnswers = (entry.fastestAnswers || 0) + 1;
        entry.updatedAt = new Date().toLocaleDateString('ar-EG');
      }
      league.sort((a, b) => b.points - a.points);
      await repo.setSystemSetting('alsharif_weekly_league_v1', JSON.stringify(league));
      broadcastAll({ type: 'weekly_league:updated', weeklyLeague: league });
    }

    await repo.setSystemSetting('alsharif_live_challenge_rooms_v1', JSON.stringify(rooms));
    broadcastAll({ type: 'challenge_room:updated', room, allRooms: rooms });
    res.json({ success: true, room, allRooms: rooms, answerPayload });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards-competitions/challenge-rooms/:roomId/next', async (req, res) => {
  try {
    const rawRooms = await repo.getSystemSetting('alsharif_live_challenge_rooms_v1');
    const rooms: any[] = rawRooms ? JSON.parse(rawRooms) : [];
    const room = rooms.find((r) => r.id === req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'غرفة التحدي غير موجودة' });
    }

    if (room.currentQuestionIndex + 1 < room.questions.length) {
      room.currentQuestionIndex += 1;
      room.questionStartedAt = Date.now();
    } else {
      room.status = 'finished';
    }

    await repo.setSystemSetting('alsharif_live_challenge_rooms_v1', JSON.stringify(rooms));
    broadcastAll({ type: 'challenge_room:updated', room, allRooms: rooms });
    res.json({ success: true, room, allRooms: rooms });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/flashcards-competitions/challenge-rooms/:roomId', async (req, res) => {
  try {
    const rawRooms = await repo.getSystemSetting('alsharif_live_challenge_rooms_v1');
    const rooms: any[] = rawRooms ? JSON.parse(rawRooms) : [];
    const nextRooms = rooms.filter((r) => r.id !== req.params.roomId);
    await repo.setSystemSetting('alsharif_live_challenge_rooms_v1', JSON.stringify(nextRooms));
    broadcastAll({ type: 'challenge_room:updated', allRooms: nextRooms });
    res.json({ success: true, allRooms: nextRooms });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. AL-SHARIF REWARDS STORE (متجر جوائز منصة الشريف واستبدال النقاط)
app.post('/api/flashcards-competitions/store/redeem', async (req, res) => {
  try {
    const {
      studentId,
      studentName,
      studentGrade,
      rewardId,
      targetLessonId,
      targetLessonTitle,
      availablePoints,
    } = req.body || {};

    if (!studentName || !rewardId) {
      return res.status(400).json({ error: 'يرجى تحديد الطالب والجائزة المراد استبدالها' });
    }

    const [rawStoreItems, rawStoreRedemptions, rawBadges, rawCards, rawRedemptions] =
      await Promise.all([
        repo.getSystemSetting('alsharif_rewards_store_items_v1'),
        repo.getSystemSetting('alsharif_store_redemptions_v1'),
        repo.getSystemSetting('alsharif_student_badges_v1'),
        repo.getSystemSetting('alsharif_scratch_cards_v1'),
        repo.getSystemSetting('alsharif_student_redemptions_v1'),
      ]);

    const catalog: any[] = rawStoreItems ? JSON.parse(rawStoreItems) : DEFAULT_STORE_CATALOG;
    const reward = catalog.find((item) => item.id === rewardId);
    if (!reward) {
      return res.status(404).json({ error: 'هذه الجائزة غير موجودة في المتجر' });
    }

    const storeRedemptions: any[] = rawStoreRedemptions ? JSON.parse(rawStoreRedemptions) : [];
    const badgesMap: Record<string, string> = rawBadges ? JSON.parse(rawBadges) : {};

    if (typeof availablePoints === 'number' && availablePoints < reward.costPoints) {
      return res.status(400).json({
        error: `رصيد نقاطك الحالي (${availablePoints} نقطة) غير كافٍ لاستبدال هذه الجائزة (${reward.costPoints} نقطة). شارك في مسابقة الشريف أو غرف التحدي لربح المزيد!`,
      });
    }

    const couponCode = `SHARIF-REWARD-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
    let fulfillmentDetails = '';

    if (reward.rewardType === 'free_lesson_unlock') {
      // Automatically create an active lesson/monthly unlock in content security redemptions
      const cardsList: any[] = rawCards ? JSON.parse(rawCards) : [];
      const redemptionsList: any[] = rawRedemptions ? JSON.parse(rawRedemptions) : [];
      const expDate = new Date(Date.now() + 30 * 86400000).toISOString();
      const newCard = {
        id: `card-store-${Date.now()}`,
        code: couponCode,
        scope: targetLessonId ? 'lesson' : 'monthly',
        title: `جائزة متجر الشريف: فتح ${targetLessonTitle || 'درس مجاني'}`,
        lessonId: targetLessonId || undefined,
        targetLessonId: targetLessonId || undefined,
        lessonTitle: targetLessonTitle || 'أي درس محمي',
        targetLessonTitle: targetLessonTitle || 'أي درس محمي',
        durationDays: 30,
        price: 0,
        currency: 'نقاط تفوق',
        maxUses: 1,
        usedCount: 1,
        status: 'redeemed',
        redeemedByStudentId: studentId || studentName,
        redeemedByStudentName: studentName,
        redeemedAt: new Date().toISOString(),
        expiresAt: expDate,
        createdBy: 'متجر جوائز منصة الشريف',
        createdAt: new Date().toISOString(),
      };
      const newSub = {
        id: `red-store-${Date.now()}`,
        codeId: newCard.id,
        code: couponCode,
        scope: targetLessonId ? 'lesson' : 'monthly',
        title: newCard.title,
        lessonId: targetLessonId || undefined,
        targetLessonId: targetLessonId || undefined,
        lessonTitle: targetLessonTitle || undefined,
        targetLessonTitle: targetLessonTitle || undefined,
        studentId: studentId || studentName,
        studentName,
        redeemedAt: new Date().toISOString(),
        expiresAt: expDate,
        isActive: true,
      };
      await Promise.all([
        repo.setSystemSetting('alsharif_scratch_cards_v1', JSON.stringify([newCard, ...cardsList])),
        repo.setSystemSetting(
          'alsharif_student_redemptions_v1',
          JSON.stringify([newSub, ...redemptionsList])
        ),
      ]);
      fulfillmentDetails = targetLessonTitle
        ? `تم فتح الدرس «${targetLessonTitle}» في حسابك فوراً وإصدار كود التفعيل (${couponCode})!`
        : `تم تفعيل بطاقة فتح الدروس المجانية في حسابك فوراً بالكود (${couponCode})!`;
    } else if (reward.rewardType === 'next_month_discount') {
      fulfillmentDetails = `تم إصدار قسيمة خصم 50% على الشهر القادم بالكود (${couponCode}). قدّم هذا الكود للإدارة المالية أو السكرتارية عند التجديد.`;
    } else if (reward.rewardType === 'golden_certificate') {
      try {
        const cert = await repo.createCertificate({
          id: `cert-store-${Date.now()}`,
          studentId: studentId || `stu-${Date.now()}`,
          studentName,
          grade: studentGrade || 'منصة الشريف التعليمية',
          courseTitle: 'التفوق في مسابقة الشريف والالتزام الأكاديمي',
          issueDate: new Date().toISOString().split('T')[0],
          score: 100,
          rank: 'وسام التميز الذهبي — متجر الشريف',
          verificationCode: couponCode,
          templateId: 'royal_gold',
        });
        broadcastAll({ type: 'certificate:created', certificate: cert });
      } catch {
        // ignore if studentId foreign key not matched
      }
      fulfillmentDetails = `تم إصدار شهادة التميز الذهبية الرسمية باسم (${studentName}) برقم توثيق (${couponCode}) وإضافتها لقسم الشهادات!`;
    } else if (reward.rewardType === 'special_profile_badge') {
      badgesMap[studentName] = reward.badgeText;
      if (studentId) badgesMap[studentId] = reward.badgeText;
      await repo.setSystemSetting('alsharif_student_badges_v1', JSON.stringify(badgesMap));
      fulfillmentDetails = `تم تفعيل الوسام الخاص «${reward.badgeText}» ليظهر بجانب اسمك (${studentName}) في جميع مسابقات ولوحات شرف منصة الشريف!`;
    }

    const redemptionRecord = {
      id: `st-red-${Date.now()}`,
      studentId: studentId || studentName,
      studentName,
      rewardId: reward.id,
      rewardTitle: reward.title,
      rewardType: reward.rewardType,
      badgeText: reward.badgeText,
      costPoints: reward.costPoints,
      couponCode,
      fulfillmentDetails,
      redeemedAt: new Date().toLocaleString('ar-EG'),
    };

    const nextStoreRedemptions = [redemptionRecord, ...storeRedemptions].slice(0, 200);
    await repo.setSystemSetting(
      'alsharif_store_redemptions_v1',
      JSON.stringify(nextStoreRedemptions)
    );

    broadcastAll({
      type: 'store:redeemed',
      redemption: redemptionRecord,
      storeRedemptions: nextStoreRedemptions,
      studentBadges: badgesMap,
    });

    res.json({
      success: true,
      redemption: redemptionRecord,
      storeRedemptions: nextStoreRedemptions,
      studentBadges: badgesMap,
      message: fulfillmentDetails,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Award bonus points (e.g. from attendance or teacher reward)
app.post('/api/flashcards-competitions/store/bonus-points', async (req, res) => {
  try {
    const { studentName, points } = req.body || {};
    if (!studentName) return res.status(400).json({ error: 'اسم الطالب مطلوب' });
    const rawBonus = await repo.getSystemSetting('alsharif_student_bonus_points_v1');
    const bonusMap: Record<string, number> = rawBonus ? JSON.parse(rawBonus) : {};
    bonusMap[studentName] = (Number(bonusMap[studentName]) || 0) + (Number(points) || 100);
    await repo.setSystemSetting('alsharif_student_bonus_points_v1', JSON.stringify(bonusMap));
    broadcastAll({ type: 'bonus_points:updated', bonusPointsMap: bonusMap });
    res.json({ success: true, bonusPointsMap: bonusMap });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. SPACED REPETITION SMART FLASHCARD REVIEW (نظام المراجعة الذكية المتباعدة حتى الإتقان 100%)
app.post('/api/flashcards-competitions/spaced-repetition', async (req, res) => {
  try {
    const { studentKey, cardId, outcome, question, subject } = req.body || {};
    // outcome: 'wrong' | 'hard' | 'review' | 'correct' | 'mastered'
    if (!studentKey || !cardId) {
      return res.status(400).json({ error: 'بيانات البطاقة غير مكتملة' });
    }

    const rawSpaced = await repo.getSystemSetting('alsharif_spaced_repetition_v1');
    const allSpaced: Record<string, Record<string, any>> = rawSpaced ? JSON.parse(rawSpaced) : {};
    if (!allSpaced[studentKey]) {
      allSpaced[studentKey] = {};
    }

    const prev = allSpaced[studentKey][cardId] || {
      cardId,
      question: question || '',
      subject: subject || '',
      boxLevel: 0, // 0..3 (3 = 100% mastered)
      consecutiveCorrect: 0,
      wrongCount: 0,
      hardCount: 0,
      masteryPercent: 0,
      status: 'review_tomorrow',
      nextReviewDate: new Date().toISOString().split('T')[0],
      lastReviewedAt: new Date().toISOString(),
    };

    const todayStr = new Date().toISOString().split('T')[0];
    const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];

    if (outcome === 'wrong' || outcome === 'hard') {
      // البطاقات التي يخطئ فيها الطالب أو يصنفها صعبة تتكرر عليه تلقائياً في اليوم التالي حتى يتقنها 100%
      prev.boxLevel = 0;
      prev.consecutiveCorrect = 0;
      if (outcome === 'wrong') prev.wrongCount = (prev.wrongCount || 0) + 1;
      if (outcome === 'hard') prev.hardCount = (prev.hardCount || 0) + 1;
      prev.masteryPercent = 15;
      prev.status = 'due_daily_until_mastered';
      prev.nextReviewDate = tomorrowStr;
    } else if (outcome === 'review') {
      prev.boxLevel = 1;
      prev.consecutiveCorrect = Math.max(0, (prev.consecutiveCorrect || 0));
      prev.masteryPercent = 45;
      prev.status = 'due_daily_until_mastered';
      prev.nextReviewDate = tomorrowStr;
    } else if (outcome === 'correct') {
      prev.consecutiveCorrect = (prev.consecutiveCorrect || 0) + 1;
      prev.boxLevel = Math.min(3, prev.consecutiveCorrect);
      if (prev.consecutiveCorrect >= 3) {
        prev.masteryPercent = 100;
        prev.status = 'mastered_100';
        prev.nextReviewDate = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];
      } else {
        prev.masteryPercent = prev.consecutiveCorrect === 1 ? 45 : 75;
        prev.status = 'due_daily_until_mastered';
        prev.nextReviewDate = tomorrowStr;
      }
    } else if (outcome === 'mastered') {
      prev.boxLevel = 3;
      prev.consecutiveCorrect = 3;
      prev.masteryPercent = 100;
      prev.status = 'mastered_100';
      prev.nextReviewDate = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];
    }

    prev.lastReviewedAt = todayStr;
    allSpaced[studentKey][cardId] = prev;

    await repo.setSystemSetting('alsharif_spaced_repetition_v1', JSON.stringify(allSpaced));
    res.json({
      success: true,
      cardRecord: prev,
      studentRecords: allSpaced[studentKey],
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= LIVE DATABASE PUBLIC SEARCH (HERO SLIDER SEARCH) =================
app.get('/api/public-search', async (req, res) => {
  try {
    const rawQuery = String(req.query.q || '').trim().toLowerCase();
    const subjectFilter = String(req.query.subject || 'all').trim();

    const [
      allLessons,
      allTeachers,
      allQuizzes,
      allAssignments,
      allTimetableSlots,
      allCertificates,
      allFaqs,
      allStudents,
    ] = await Promise.all([
      repo.getAllLessons(),
      repo.getAllTeachers(),
      repo.getAllQuizzes(),
      repo.getAllAssignments(),
      repo.getAllTimetable(),
      repo.getAllCertificates(),
      repo.getAllFaqs(),
      repo.getAllStudents(),
    ]);

    const matchesText = (...fields: (string | undefined | null)[]) => {
      if (!rawQuery) return true;
      return fields.some((f) => String(f || '').toLowerCase().includes(rawQuery));
    };

    const matchesSubject = (subj?: string | null) => {
      if (!subjectFilter || subjectFilter === 'all') return true;
      return String(subj || '').trim() === subjectFilter;
    };

    const lessons = allLessons.filter(
      (l: any) =>
        matchesSubject(l.subject) &&
        matchesText(
          l.title,
          l.subject,
          l.grade,
          l.unit,
          l.teacherName,
          l.description,
          l.contentHtml,
          l.format
        )
    );

    const teachers = allTeachers.filter(
      (t: any) =>
        matchesSubject(t.specialty) &&
        matchesText(t.name, t.nameEn, t.specialty, t.specialtyEn, t.bio)
    );

    const quizzes = allQuizzes.filter(
      (qz: any) =>
        matchesSubject(qz.subject) &&
        matchesText(qz.title, qz.subject, qz.grade, qz.teacherName)
    );

    const assignments = allAssignments.filter(
      (asg: any) =>
        matchesSubject(asg.subject) &&
        matchesText(asg.title, asg.subject, asg.grade, asg.description, asg.teacherName)
    );

    const timetableSlots = allTimetableSlots.filter(
      (slot: any) =>
        matchesSubject(slot.subject) &&
        matchesText(
          slot.subject,
          slot.courseTitle,
          slot.grade,
          slot.teacherName,
          slot.day,
          slot.dayAr,
          slot.roomOrLink,
          slot.time
        )
    );

    const certificates = allCertificates.filter(
      (cert: any) =>
        matchesSubject(cert.subjectOrTrack) &&
        matchesText(
          cert.studentName,
          cert.subjectOrTrack,
          cert.studentGrade,
          cert.serialNumber,
          cert.notes
        )
    );

    const faqs = allFaqs.filter((f: any) =>
      matchesText(f.questionAr, f.questionEn, f.answerAr, f.answerEn, f.category)
    );

    // Distinct subjects from actual DB records with lesson counts
    const subjectMap = new Map<string, number>();
    for (const l of allLessons) {
      const s = String(l.subject || '').trim();
      if (s) subjectMap.set(s, (subjectMap.get(s) || 0) + 1);
    }
    for (const t of allTeachers) {
      const s = String(t.specialty || '').trim();
      if (s && !subjectMap.has(s)) subjectMap.set(s, 0);
    }
    for (const qz of allQuizzes) {
      const s = String(qz.subject || '').trim();
      if (s && !subjectMap.has(s)) subjectMap.set(s, 0);
    }

    const availableSubjects = Array.from(subjectMap.entries()).map(([subject, lessonCount]) => ({
      subject,
      lessonCount,
    }));

    res.json({
      query: rawQuery,
      subject: subjectFilter,
      lessons,
      teachers,
      quizzes,
      assignments,
      timetableSlots,
      certificates,
      faqs,
      availableSubjects,
      totalMatches:
        lessons.length +
        teachers.length +
        quizzes.length +
        assignments.length +
        timetableSlots.length +
        certificates.length +
        faqs.length,
      databaseTotals: {
        lessons: allLessons.length,
        teachers: allTeachers.length,
        students: allStudents.length,
        quizzes: allQuizzes.length,
        assignments: allAssignments.length,
        timetableSlots: allTimetableSlots.length,
        certificates: allCertificates.length,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CONTENT SECURITY, SCRATCH CARDS / PROMO CODES & DEVICE BINDING =================
const DEFAULT_SECURITY_DRM_CONFIG = {
  requireActivationCodeForStudents: true,
  lockedLessonIds: [] as string[],
  lockedSubjects: [] as string[],
  enableDeviceBinding: true,
  maxDevicesPerStudent: 1,
  enforceStrictIpBinding: true,
  enforceStrictGeoBinding: true,
  enableJumpingCornerWatermark: true,
  jumpingWatermarkIntervalSec: 4,
  enableAudioWatermark: true,
  audioWatermarkIntervalSec: 35,
  audioWatermarkMode: 'voice_and_tone',
};

app.get('/api/content-security/state', async (_req, res) => {
  try {
    const [rawConfig, rawCards, rawRedemptions, rawBindings] = await Promise.all([
      repo.getSystemSetting('alsharif_security_drm_config_v1'),
      repo.getSystemSetting('alsharif_scratch_cards_v1'),
      repo.getSystemSetting('alsharif_student_redemptions_v1'),
      repo.getSystemSetting('alsharif_device_bindings_v1'),
    ]);

    const config = rawConfig
      ? { ...DEFAULT_SECURITY_DRM_CONFIG, ...JSON.parse(rawConfig) }
      : DEFAULT_SECURITY_DRM_CONFIG;
    const cards = rawCards ? JSON.parse(rawCards) : [];
    const redemptions = rawRedemptions ? JSON.parse(rawRedemptions) : [];
    const deviceRecords = rawBindings ? JSON.parse(rawBindings) : [];

    res.json({
      config,
      cards: Array.isArray(cards) ? cards : [],
      redemptions: Array.isArray(redemptions) ? redemptions : [],
      deviceRecords: Array.isArray(deviceRecords) ? deviceRecords : [],
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/content-security/config', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'تعديل إعدادات حماية المحتوى متاح للإدارة فقط')) return;
  try {
    const rawConfig = await repo.getSystemSetting('alsharif_security_drm_config_v1');
    const prev = rawConfig ? JSON.parse(rawConfig) : DEFAULT_SECURITY_DRM_CONFIG;
    const incoming = req.body?.config && typeof req.body.config === 'object' ? req.body.config : req.body || {};
    const nextConfig = { ...DEFAULT_SECURITY_DRM_CONFIG, ...prev, ...incoming };
    await repo.setSystemSetting('alsharif_security_drm_config_v1', JSON.stringify(nextConfig));
    broadcastAll({ type: 'content_security:updated', config: nextConfig });
    res.json({ success: true, config: nextConfig });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/content-security/generate-codes', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'توليد أكواد التفعيل متاح للإدارة فقط')) return;
  try {
    const {
      count = 5,
      scope = 'monthly',
      title,
      subject = '',
      targetSubject = '',
      grade = '',
      lessonId = '',
      targetLessonId = '',
      lessonTitle = '',
      targetLessonTitle = '',
      durationDays = 30,
      durationHours,
      discountPercent,
      firstUnitOnly,
      bundleLabel,
      price = 150,
      currency = 'ج.م',
      maxUses = 1,
      createdBy = 'Mo-NewFolder (الأدمن العام)',
    } = req.body || {};

    const resolvedSubject = String(targetSubject || subject || '').trim();
    const resolvedLessonId = String(targetLessonId || lessonId || '').trim();
    const resolvedLessonTitle = String(targetLessonTitle || lessonTitle || '').trim();
    const qty = Math.min(100, Math.max(1, Number(count) || 1));
    const resolvedHours =
      scope === 'trial_48h'
        ? Math.max(1, Number(durationHours) || 48)
        : durationHours
        ? Number(durationHours)
        : undefined;
    const days =
      scope === 'trial_48h'
        ? 2
        : Math.max(1, Number(durationDays) || (scope === 'semester' ? 120 : 30));
    const resolvedDiscount =
      scope === 'promo_discount'
        ? Math.min(100, Math.max(1, Number(discountPercent) || 20))
        : discountPercent
        ? Number(discountPercent)
        : undefined;
    const resolvedFirstUnitOnly =
      scope === 'trial_48h' ? true : Boolean(firstUnitOnly);
    const uses = Math.max(1, Number(maxUses) || 1);

    const rawCards = await repo.getSystemSetting('alsharif_scratch_cards_v1');
    const existingCards: any[] = rawCards ? JSON.parse(rawCards) : [];

    const scopePrefix =
      scope === 'semester'
        ? 'TERM'
        : scope === 'subject'
        ? 'SUBJ'
        : scope === 'lesson'
        ? 'LESN'
        : scope === 'full_vip'
        ? 'VIP'
        : scope === 'promo_discount'
        ? 'PROMO'
        : scope === 'trial_48h'
        ? 'TRIAL'
        : 'MNTH';

    const defaultTitle =
      title?.trim() ||
      (scope === 'semester'
        ? `باقة الترم كامل (${resolvedSubject || 'جميع المواد'}) — منصة الشريف`
        : scope === 'subject'
        ? `باقة مادة واحدة (${resolvedSubject || 'مادة دراسية'}) — منصة الشريف`
        : scope === 'lesson'
        ? `بطاقة فتح درس (${resolvedLessonTitle || 'درس محدد'}) — منصة الشريف`
        : scope === 'full_vip'
        ? 'باقة الشريف الشاملة (VIP لكل المواد والدروس)'
        : scope === 'promo_discount'
        ? `كود خصم ${resolvedDiscount || 20}% على الاشتراكات`
        : scope === 'trial_48h'
        ? `تجربة مجانية ${resolvedHours || 48} ساعة (أول فصل${resolvedSubject ? ` - ${resolvedSubject}` : ''})`
        : 'بطاقة اشتراك شهري — منصة الشريف');

    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const randomChunk = (len: number) =>
      Array.from({ length: len })
        .map(() => alphabet[Math.floor(Math.random() * alphabet.length)])
        .join('');

    const generated: any[] = [];
    const todayStr = new Date().toISOString().split('T')[0];

    for (let i = 0; i < qty; i++) {
      const code = `SHARIF-${scopePrefix}-${randomChunk(4)}-${randomChunk(4)}`;
      generated.push({
        id: `sc-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
        code,
        scope,
        title: defaultTitle,
        subject: resolvedSubject || undefined,
        targetSubject: resolvedSubject || undefined,
        grade: grade || undefined,
        lessonId: resolvedLessonId || undefined,
        targetLessonId: resolvedLessonId || undefined,
        lessonTitle: resolvedLessonTitle || undefined,
        targetLessonTitle: resolvedLessonTitle || undefined,
        durationDays: days,
        durationHours: resolvedHours,
        discountPercent: resolvedDiscount,
        firstUnitOnly: resolvedFirstUnitOnly || undefined,
        bundleLabel: bundleLabel || undefined,
        price: scope === 'trial_48h' ? 0 : Number(price) || 0,
        currency: currency || 'ج.م',
        maxUses: uses,
        usedCount: 0,
        status: 'available',
        createdBy: getRequestActor(req).userName || createdBy,
        createdAt: todayStr,
      });
    }

    const updatedCards = [...generated, ...existingCards];
    await repo.setSystemSetting('alsharif_scratch_cards_v1', JSON.stringify(updatedCards));
    await recordSensitiveAuditLog(req, {
      action: 'generate_activation_codes',
      actionAr: 'توليد أكواد/باقات تفعيل جديدة',
      entityType: 'security',
      entityName: defaultTitle,
      details: `تم توليد عدد (${qty}) كود من نوع [${scope}] — ${defaultTitle}`,
      severity: 'info',
    });
    broadcastAll({ type: 'content_security:codes_generated', count: generated.length });

    res.status(201).json({
      success: true,
      generated,
      cards: updatedCards,
      allCards: updatedCards,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/content-security/codes/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'حذف أكواد التفعيل متاح للإدارة فقط')) return;
  try {
    const rawCards = await repo.getSystemSetting('alsharif_scratch_cards_v1');
    const existingCards: any[] = rawCards ? JSON.parse(rawCards) : [];
    const targetCard = existingCards.find((c) => c.id === req.params.id);
    const nextCards = existingCards.filter((c) => c.id !== req.params.id);
    await repo.setSystemSetting('alsharif_scratch_cards_v1', JSON.stringify(nextCards));
    await recordSensitiveAuditLog(req, {
      action: 'delete_activation_code',
      actionAr: 'حذف كود تفعيل من النظام',
      entityType: 'security',
      entityName: targetCard?.code || req.params.id,
      details: `تم حذف كود التفعيل (${targetCard?.code || req.params.id}) — ${targetCard?.title || ''}`,
      severity: 'warning',
    });
    broadcastAll({ type: 'content_security:code_deleted', id: req.params.id });
    res.json({ success: true, cards: nextCards, allCards: nextCards });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/content-security/apply-promo', async (req, res) => {
  try {
    const { code, amount } = req.body || {};
    const cleanCode = String(code || '').trim().toUpperCase();
    if (!cleanCode) {
      return res.status(400).json({ success: false, error: 'يرجى إدخال كود الخصم أولاً' });
    }
    const rawCards = await repo.getSystemSetting('alsharif_scratch_cards_v1');
    const cards: any[] = rawCards ? JSON.parse(rawCards) : [];
    const targetCard = cards.find((c) => String(c.code || '').trim().toUpperCase() === cleanCode);
    if (!targetCard) {
      return res.status(404).json({ success: false, error: 'كود الخصم غير موجود أو غير صحيح' });
    }
    if (targetCard.scope !== 'promo_discount') {
      return res.status(400).json({ success: false, error: 'هذا الكود مخصص لتفعيل الدروس وليس كود خصم مالي' });
    }
    if (targetCard.status !== 'available' || (Number(targetCard.usedCount) || 0) >= Math.max(1, Number(targetCard.maxUses) || 1)) {
      return res.status(400).json({ success: false, error: 'انتهى الحد الأقصى لاستخدام كود الخصم' });
    }
    const percent = Math.min(100, Math.max(1, Number(targetCard.discountPercent) || 10));
    const baseAmount = Math.max(0, Number(amount) || 0);
    const discountAmount = Math.round((baseAmount * percent) / 100);
    const finalAmount = Math.max(0, baseAmount - discountAmount);
    res.json({
      success: true,
      code: targetCard.code,
      title: targetCard.title,
      discountPercent: percent,
      discountAmount,
      finalAmount,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/content-security/redeem-code', async (req, res) => {
  try {
    const { code, studentId, studentName, studentPhone } = req.body || {};
    const cleanCode = String(code || '').trim().toUpperCase();
    if (!cleanCode) {
      return res.status(400).json({ success: false, error: 'يرجى إدخال كود التفعيل أولاً' });
    }

    const [rawCards, rawRedemptions] = await Promise.all([
      repo.getSystemSetting('alsharif_scratch_cards_v1'),
      repo.getSystemSetting('alsharif_student_redemptions_v1'),
    ]);

    const cards: any[] = rawCards ? JSON.parse(rawCards) : [];
    const redemptions: any[] = rawRedemptions ? JSON.parse(rawRedemptions) : [];

    const targetCard = cards.find((c) => String(c.code || '').trim().toUpperCase() === cleanCode);
    if (!targetCard) {
      return res.status(404).json({
        success: false,
        error: 'كود التفعيل غير صحيح أو غير مسجل في قاعدة بيانات منصة الشريف',
      });
    }

    if (targetCard.status === 'revoked' || targetCard.status === 'expired') {
      return res.status(400).json({
        success: false,
        error: 'هذا الكود ملغى أو منتهي الصلاحية',
      });
    }

    const maxUses = Math.max(1, Number(targetCard.maxUses) || 1);
    const usedCount = Number(targetCard.usedCount) || 0;

    // Check if the same student already redeemed this exact code
    const stuKey = String(studentId || studentName || 'student').trim();
    const existingRedemption = redemptions.find(
      (r) =>
        String(r.code || '').toUpperCase() === cleanCode &&
        (r.studentId === stuKey || r.studentName === studentName)
    );
    if (existingRedemption) {
      return res.json({
        success: true,
        alreadyRedeemed: true,
        redemption: existingRedemption,
        card: targetCard,
        message: 'تم تفعيل هذا الكود على حسابك مسبقاً وهو ساري الصلاحية!',
      });
    }

    if (usedCount >= maxUses || targetCard.status === 'redeemed') {
      return res.status(400).json({
        success: false,
        error: 'عذراً، تم استخدام بطاقة التفعيل هذه مسبقاً واستنفدت الحد الأقصى للتفعيل',
      });
    }

    const now = new Date();
    const durationMs =
      targetCard.scope === 'trial_48h' || targetCard.durationHours
        ? (Number(targetCard.durationHours) || 48) * 3600000
        : (Number(targetCard.durationDays) || 30) * 86400000;
    const expDate = new Date(now.getTime() + durationMs);
    const redeemedAtStr = now.toISOString().split('T')[0];
    const expiresAtStr =
      targetCard.scope === 'trial_48h' || targetCard.durationHours
        ? expDate.toISOString()
        : expDate.toISOString().split('T')[0];

    targetCard.usedCount = usedCount + 1;
    if (targetCard.usedCount >= maxUses) {
      targetCard.status = 'redeemed';
    }
    targetCard.redeemedByStudentId = stuKey;
    targetCard.redeemedByStudentName = studentName || 'طالب';
    targetCard.redeemedByPhone = studentPhone || '';
    targetCard.redeemedAt = redeemedAtStr;
    targetCard.expiresAt = expiresAtStr;

    const newRedemption = {
      id: `red-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      codeId: targetCard.id,
      code: targetCard.code,
      scope: targetCard.scope,
      title: targetCard.title,
      subject: targetCard.subject || targetCard.targetSubject,
      targetSubject: targetCard.targetSubject || targetCard.subject,
      grade: targetCard.grade,
      lessonId: targetCard.lessonId || targetCard.targetLessonId,
      targetLessonId: targetCard.targetLessonId || targetCard.lessonId,
      lessonTitle: targetCard.lessonTitle || targetCard.targetLessonTitle,
      targetLessonTitle: targetCard.targetLessonTitle || targetCard.lessonTitle,
      durationHours: targetCard.durationHours,
      discountPercent: targetCard.discountPercent,
      firstUnitOnly: targetCard.firstUnitOnly,
      studentId: stuKey,
      studentName: studentName || 'طالب',
      studentPhone: studentPhone || '',
      redeemedAt: redeemedAtStr,
      expiresAt: expiresAtStr,
      isActive: true,
    };

    const nextRedemptions = [newRedemption, ...redemptions];
    await Promise.all([
      repo.setSystemSetting('alsharif_scratch_cards_v1', JSON.stringify(cards)),
      repo.setSystemSetting('alsharif_student_redemptions_v1', JSON.stringify(nextRedemptions)),
    ]);

    broadcastAll({
      type: 'content_security:code_redeemed',
      redemption: newRedemption,
      card: targetCard,
    });

    res.json({
      success: true,
      redemption: newRedemption,
      card: targetCard,
      cards,
      redemptions: nextRedemptions,
      message: `تم شحن وتفعيل (${targetCard.title}) بنجاح!`,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/content-security/verify-device', async (req, res) => {
  try {
    const {
      userId,
      username,
      email,
      name,
      phone,
      role,
      studentId,
      isSuperAdmin,
      deviceId,
      deviceLabel,
      userAgent,
    } = req.body || {};

    const isExempt = isAccountExemptFromDeviceLock({
      userId,
      role,
      username,
      email,
      name,
      isSuperAdmin: Boolean(isSuperAdmin),
    });

    if (isExempt || !deviceId) {
      return res.json({
        success: true,
        allowed: true,
        exempt: true,
      });
    }

    const [rawCfg, rawBindings, networkCtx] = await Promise.all([
      repo.getSystemSetting('alsharif_security_drm_config_v1'),
      repo.getSystemSetting('alsharif_device_bindings_v1'),
      extractClientNetworkContext(req, req.body || {}),
    ]);

    const cfg = rawCfg
      ? { ...DEFAULT_SECURITY_DRM_CONFIG, ...JSON.parse(rawCfg) }
      : DEFAULT_SECURITY_DRM_CONFIG;

    const records: any[] = rawBindings ? JSON.parse(rawBindings) : [];
    const userKey = String(userId || username || email || studentId || name).toLowerCase();

    const evalResult = evaluateDeviceAndNetworkAccess({
      records,
      config: cfg,
      user: {
        userKey,
        studentId: studentId || userId || '',
        studentName: name || username || 'مستخدم',
        username: username || '',
        email: email || '',
        phone: phone || '',
        role: role || 'student',
      },
      deviceId: String(deviceId),
      deviceLabel: deviceLabel ? String(deviceLabel) : undefined,
      userAgent: userAgent ? String(userAgent) : undefined,
      networkCtx,
    });

    if (evalResult.status === 'disabled') {
      return res.json({
        success: true,
        allowed: true,
        deviceBindingDisabled: true,
      });
    }

    await repo.setSystemSetting(
      'alsharif_device_bindings_v1',
      JSON.stringify(evalResult.records)
    );

    if (evalResult.allowed) {
      return res.json({
        success: true,
        allowed: true,
        devices: evalResult.record.devices,
        maxDevices: evalResult.maxDevices,
        currentIp: networkCtx.ip,
        currentGeoLabel: networkCtx.geoLabelAr,
      });
    }

    broadcastAll({
      type: 'content_security:devices_updated',
      deviceRecords: evalResult.records,
    });

    return res.status(403).json({
      success: false,
      allowed: false,
      blocked: true,
      requiresAdminActivation: true,
      blockReasonCode: evalResult.blockReasonCode,
      ipMismatchBlocked: evalResult.blockReasonCode === 'ip_changed',
      geoMismatchBlocked: evalResult.blockReasonCode === 'geo_changed',
      deviceLimitBlocked: evalResult.blockReasonCode === 'device_limit_exceeded',
      devices: evalResult.record.devices,
      maxDevices: evalResult.maxDevices,
      currentIp: networkCtx.ip,
      currentGeoLabel: networkCtx.geoLabelAr,
      message: evalResult.messageAr,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/content-security/reset-devices', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'إدارة وتفعيل الأجهزة متاح للإدارة فقط')) return;
  try {
    const {
      userKey,
      studentId,
      deviceIdToRemove,
      deviceId,
      maxAllowedDevices,
    } = req.body || {};
    const rawBindings = await repo.getSystemSetting('alsharif_device_bindings_v1');
    const records: any[] = rawBindings ? JSON.parse(rawBindings) : [];
    const targetKey = String(userKey || studentId || '').toLowerCase();
    const targetDeviceId = deviceIdToRemove || deviceId;

    const result = applyAdminDeviceApproval({
      records,
      userKey: targetKey,
      mode: targetDeviceId ? 'remove_device' : 'reset_all',
      deviceId: targetDeviceId,
      maxAllowedDevices,
      adminName: getRequestActor(req).userName || 'Mo-NewFolder (الأدمن العام)',
    });

    if (result.updated) {
      await repo.setSystemSetting('alsharif_device_bindings_v1', JSON.stringify(result.records));
      await recordSensitiveAuditLog(req, {
        action: 'admin_device_reset',
        actionAr: targetDeviceId
          ? 'حذف وفصل جهاز مرتبط من حساب طالب'
          : 'إعادة ضبط كافة الأجهزة والقيود للحساب',
        entityType: 'security',
        entityName: result.target?.studentName || targetKey,
        details: targetDeviceId
          ? `تم فصل الجهاز (${targetDeviceId}) عن الحساب (${targetKey}).`
          : `تمت إعادة ضبط أجهزة الحساب (${targetKey}) وفك القفل.`,
        severity: 'warning',
      });
    }

    broadcastAll({ type: 'content_security:devices_updated', deviceRecords: result.records });
    res.json({ success: true, deviceRecords: result.records });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/content-security/approve-access', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'اعتماد الأجهزة والمواقع متاح للأدمن فقط')) return;
  try {
    const {
      userKey,
      studentId,
      mode = 'approve_pending_device',
      deviceId,
      maxAllowedDevices,
    } = req.body || {};

    const rawBindings = await repo.getSystemSetting('alsharif_device_bindings_v1');
    const records: any[] = rawBindings ? JSON.parse(rawBindings) : [];
    const targetKey = String(userKey || studentId || '').toLowerCase();
    const actorName = getRequestActor(req).userName || 'Mo-NewFolder (الأدمن العام)';

    const result = applyAdminDeviceApproval({
      records,
      userKey: targetKey,
      mode: mode === 'approve_ip_or_geo' ? 'approve_ip_or_geo' : 'approve_pending_device',
      deviceId,
      maxAllowedDevices,
      adminName: actorName,
    });

    if (!result.updated) {
      return res.status(404).json({ success: false, error: 'لم يتم العثور على سجل الحساب المطلوب تفعيله' });
    }

    await repo.setSystemSetting('alsharif_device_bindings_v1', JSON.stringify(result.records));
    await recordSensitiveAuditLog(req, {
      action: 'admin_device_geo_activation',
      actionAr:
        mode === 'approve_ip_or_geo'
          ? 'تفعيل واعتماد تغيير IP / الموقع الجغرافي بواسطة الأدمن'
          : 'تفعيل واعتماد جهاز إضافي للحساب بواسطة الأدمن',
      entityType: 'security',
      entityName: result.target?.studentName || targetKey,
      details: `قام الأدمن (${actorName}) بتفعيل الوصول للحساب (${targetKey}).`,
      severity: 'info',
    });

    broadcastAll({ type: 'content_security:devices_updated', deviceRecords: result.records });
    res.json({ success: true, deviceRecords: result.records, record: result.target });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/content-security/reject-request', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'رفض طلبات فك الحظر متاح للأدمن فقط')) return;
  try {
    const { userKey, studentId } = req.body || {};
    const rawBindings = await repo.getSystemSetting('alsharif_device_bindings_v1');
    const records: any[] = rawBindings ? JSON.parse(rawBindings) : [];
    const targetKey = String(userKey || studentId || '').toLowerCase();
    const actorName = getRequestActor(req).userName || 'Mo-NewFolder (الأدمن العام)';

    const result = applyAdminDeviceApproval({
      records,
      userKey: targetKey,
      mode: 'reject_pending_request',
      adminName: actorName,
    });

    if (!result.updated) {
      return res.status(404).json({ success: false, error: 'لم يتم العثور على الطلب المطلوب رفضه' });
    }

    await repo.setSystemSetting('alsharif_device_bindings_v1', JSON.stringify(result.records));
    await recordSensitiveAuditLog(req, {
      action: 'admin_device_geo_rejection',
      actionAr: 'رفض طلب فك حظر جهاز / موقع جغرافي',
      entityType: 'security',
      entityName: result.target?.studentName || targetKey,
      details: `رفض الأدمن (${actorName}) طلب فك الحظر للحساب (${targetKey}).`,
      severity: 'warning',
    });

    broadcastAll({ type: 'content_security:devices_updated', deviceRecords: result.records });
    res.json({ success: true, deviceRecords: result.records, record: result.target });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= BACKUPS & EXPORT =================
app.get('/api/backups', async (req, res) => {
  try {
    const list = await repo.getAllBackups();
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Create Database Backup (generates dump and logs into database)
app.post('/api/backups/database', async (req, res) => {
  try {
    const dumpContent = await repo.generateSqlDump();
    const sizeKb = (Buffer.byteLength(dumpContent, 'utf8') / 1024).toFixed(1) + ' KB';
    const timestampStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `nawabegh_database_dump_${timestampStr}.sql`;

    const studentsCount = (await repo.getAllStudents()).length;
    const teachersCount = (await repo.getAllTeachers()).length;
    const lessonsCount = (await repo.getAllLessons()).length;
    const totalRecords = studentsCount + teachersCount + lessonsCount;

    const backupRecord = await repo.recordBackup({
      id: `bk-db-${Date.now()}`,
      type: 'database',
      filename,
      size: sizeKb,
      recordCount: totalRecords,
      notes: `نسخة احتياطية كاملة لقاعدة بيانات Cloud SQL (تتضمن الجداول والبيانات بصيغة SQL القياسية)`,
    });

    res.json({
      success: true,
      backup: backupRecord,
      downloadUrl: '/api/backups/export/database',
    });
  } catch (err: any) {
    console.error('Database backup generation error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Export Database as .sql file download (supports ?dialect=postgresql or ?dialect=mysql)
app.get('/api/backups/export/database', async (req, res) => {
  try {
    const dialect = req.query.dialect === 'mysql' ? 'mysql' : 'postgresql';
    const dumpContent = await repo.generateSqlDump(dialect);
    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = `nawabegh_database_${dialect}_${dateStr}.sql`;

    res.setHeader('Content-Type', 'application/sql; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(dumpContent);
  } catch (err: any) {
    console.error('SQL export error:', err);
    res.status(500).send('Failed to generate database SQL export');
  }
});

// Create Application Backup Record
app.post('/api/backups/application', async (req, res) => {
  try {
    const timestampStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `nawabegh_app_archive_${timestampStr}.zip`;

    const backupRecord = await repo.recordBackup({
      id: `bk-app-${Date.now()}`,
      type: 'application',
      filename,
      size: '2.4 MB (مضغوط ZIP)',
      recordCount: 52,
      notes: 'نسخة احتياطية كاملة لمشروع التطبيق البرمجي (المصادر، المكونات، القوالب، وقواعد البيانات)',
    });

    res.json({
      success: true,
      backup: backupRecord,
      downloadUrl: '/api/backups/export/application',
    });
  } catch (err: any) {
    console.error('App backup error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Export Application as .zip archive download
app.get('/api/backups/export/application', (req, res) => {
  try {
    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = `nawabegh_application_source_${dateStr}.zip`;

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    const archive = new archiver.ZipArchive({ zlib: { level: 9 } });

    archive.on('error', (err: any) => {
      console.error('Archive error:', err);
      if (!res.headersSent) res.status(500).send('Archiving failed');
    });

    archive.pipe(res);

    // Glob application files, ignoring node_modules, dist, git, and zip bundles
    archive.glob('**/*', {
      cwd: __dirname,
      ignore: [
        'node_modules/**',
        'dist/**',
        '.git/**',
        '*.zip',
        '*.tar.gz',
        'public/assets/aistudio/*.zip',
        '.aistudio/**',
      ],
      dot: true,
    });

    archive.finalize();
  } catch (err: any) {
    console.error('Zip export error:', err);
    res.status(500).send('Failed to export application zip');
  }
});

// ================= STUDENT EXPERIENCE: TIMESTAMPED VIDEO NOTES & POMODORO STUDY HUB =================
function formatSecondsToMmSs(totalSec: number): string {
  const safe = Math.max(0, Math.floor(totalSec || 0));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

app.get('/api/lesson-notes', async (req, res) => {
  try {
    const lessonId = String(req.query.lessonId || '').trim();
    const studentId = String(req.query.studentId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_timestamped_notes_v1');
    const allNotes: any[] = raw ? JSON.parse(raw) : [];
    const filtered = allNotes.filter((n) => {
      if (lessonId && n.lessonId !== lessonId) return false;
      if (studentId && n.studentId !== studentId) return false;
      return true;
    });
    res.json({ notes: filtered });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/lesson-notes', async (req, res) => {
  try {
    const {
      lessonId,
      lessonTitle,
      subject,
      studentId,
      studentName,
      timestampSeconds,
      noteText,
    } = req.body || {};
    if (!lessonId || !String(noteText || '').trim()) {
      return res.status(400).json({ error: 'يرجى كتابة نص الملاحظة قبل الحفظ' });
    }
    const actor = getRequestActor(req);
    const secs = Math.max(0, Math.round(Number(timestampSeconds || 0)));
    const newNote = {
      id: `vnote-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      lessonId: String(lessonId),
      lessonTitle: String(lessonTitle || 'درس فيديو'),
      subject: String(subject || 'عام'),
      studentId: String(studentId || actor.userId || 'guest'),
      studentName: String(studentName || actor.userName || 'طالب'),
      timestampSeconds: secs,
      formattedTime: formatSecondsToMmSs(secs),
      noteText: String(noteText).trim(),
      createdAt: new Date().toLocaleString('ar-EG'),
    };

    const raw = await repo.getSystemSetting('alsharif_timestamped_notes_v1');
    const allNotes: any[] = raw ? JSON.parse(raw) : [];
    const nextNotes = [newNote, ...allNotes].slice(0, 1500);
    await repo.setSystemSetting('alsharif_timestamped_notes_v1', JSON.stringify(nextNotes));
    res.status(201).json({ ok: true, note: newNote });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/lesson-notes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const raw = await repo.getSystemSetting('alsharif_timestamped_notes_v1');
    const allNotes: any[] = raw ? JSON.parse(raw) : [];
    const nextNotes = allNotes.filter((n) => n.id !== id);
    await repo.setSystemSetting('alsharif_timestamped_notes_v1', JSON.stringify(nextNotes));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/study-hub/state', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || '').trim();
    const [rawPlans, rawSessions, rawNotes, allStudents] = await Promise.all([
      repo.getSystemSetting('alsharif_personal_study_plans_v1'),
      repo.getSystemSetting('alsharif_pomodoro_sessions_v1'),
      repo.getSystemSetting('alsharif_timestamped_notes_v1'),
      repo.getAllStudents(),
    ]);

    const plans: any[] = rawPlans ? JSON.parse(rawPlans) : [];
    const sessions: any[] = rawSessions ? JSON.parse(rawSessions) : [];
    const notes: any[] = rawNotes ? JSON.parse(rawNotes) : [];

    const weekStartMs = Date.now() - 7 * 86400000;
    const weeklyFocusSessions = sessions.filter(
      (s) => s.mode !== 'break' && new Date(s.completedAt || 0).getTime() >= weekStartMs
    );

    // Aggregate per student for "أكثر الطلاب مذاكرة هذا الأسبوع"
    const aggMap: Record<
      string,
      {
        studentId: string;
        studentCode: string;
        studentName: string;
        studentGrade: string;
        studentAvatar?: string | null;
        totalMinutes: number;
        sessionsCount: number;
      }
    > = {};

    weeklyFocusSessions.forEach((sess) => {
      const matchedStu = allStudents.find(
        (st: any) =>
          st.id === sess.studentId ||
          (sess.studentCode && st.code === sess.studentCode) ||
          (sess.studentName && st.name.trim() === String(sess.studentName).trim())
      );
      const key = matchedStu?.id || sess.studentId || sess.studentName;
      if (!aggMap[key]) {
        aggMap[key] = {
          studentId: matchedStu?.id || String(sess.studentId || key),
          studentCode: matchedStu?.code || String(sess.studentCode || 'STU'),
          studentName: matchedStu?.name || String(sess.studentName || 'طالب'),
          studentGrade: matchedStu?.grade || 'الصف الثالث الثانوي',
          studentAvatar: matchedStu?.avatar || null,
          totalMinutes: 0,
          sessionsCount: 0,
        };
      }
      aggMap[key].totalMinutes += Number(sess.durationMinutes || 0);
      aggMap[key].sessionsCount += 1;
    });

    const weeklyLeaderboard = Object.values(aggMap)
      .sort((a, b) => b.totalMinutes - a.totalMinutes)
      .map((entry, idx) => ({
        rank: idx + 1,
        ...entry,
        totalHours: Number((entry.totalMinutes / 60).toFixed(1)),
      }));

    const scopedPlans = studentId
      ? plans.filter((p) => p.studentId === studentId)
      : plans;
    const scopedSessions = studentId
      ? sessions.filter((s) => s.studentId === studentId)
      : sessions;
    const scopedNotes = studentId
      ? notes.filter((n) => n.studentId === studentId)
      : notes;

    const myWeeklyFocusMinutes = weeklyFocusSessions
      .filter((s) => !studentId || s.studentId === studentId)
      .reduce((acc, s) => acc + Number(s.durationMinutes || 0), 0);

    res.json({
      plans: scopedPlans,
      sessions: scopedSessions.slice(0, 60),
      notes: scopedNotes.slice(0, 100),
      weeklyLeaderboard,
      myWeeklyFocusMinutes,
      myWeeklyFocusHours: Number((myWeeklyFocusMinutes / 60).toFixed(1)),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/study-hub/pomodoro/complete', async (req, res) => {
  try {
    const {
      studentId,
      studentCode,
      studentName,
      subject,
      lessonId,
      lessonTitle,
      taskTitle,
      planId,
      durationMinutes = 25,
      mode = 'focus',
    } = req.body || {};

    const actor = getRequestActor(req);
    const cleanDuration = Math.max(1, Math.min(180, Math.round(Number(durationMinutes || 25))));
    const newSession = {
      id: `pom-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      studentId: String(studentId || actor.userId || 'guest'),
      studentCode: studentCode ? String(studentCode) : undefined,
      studentName: String(studentName || actor.userName || 'طالب'),
      subject: String(subject || 'مذاكرة عامة'),
      lessonId: lessonId ? String(lessonId) : undefined,
      lessonTitle: lessonTitle ? String(lessonTitle) : undefined,
      taskTitle: taskTitle ? String(taskTitle) : undefined,
      durationMinutes: cleanDuration,
      mode: mode === 'break' ? 'break' : 'focus',
      completedAt: new Date().toISOString(),
    };

    const rawSessions = await repo.getSystemSetting('alsharif_pomodoro_sessions_v1');
    const sessions: any[] = rawSessions ? JSON.parse(rawSessions) : [];
    const nextSessions = [newSession, ...sessions].slice(0, 2000);
    await repo.setSystemSetting('alsharif_pomodoro_sessions_v1', JSON.stringify(nextSessions));

    if (planId && mode !== 'break') {
      const rawPlans = await repo.getSystemSetting('alsharif_personal_study_plans_v1');
      const plans: any[] = rawPlans ? JSON.parse(rawPlans) : [];
      const updatedPlans = plans.map((p) =>
        p.id === planId
          ? {
              ...p,
              completedPomodoros: Number(p.completedPomodoros || 0) + 1,
              isCompleted:
                Number(p.completedPomodoros || 0) + 1 >= Number(p.targetPomodoros || 1)
                  ? true
                  : p.isCompleted,
            }
          : p
      );
      await repo.setSystemSetting('alsharif_personal_study_plans_v1', JSON.stringify(updatedPlans));
    }

    broadcastAll({ type: 'study_hub:updated', session: newSession });
    res.status(201).json({ ok: true, session: newSession });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/study-hub/plans', async (req, res) => {
  try {
    const {
      studentId,
      studentName,
      dayOfWeek,
      timeSlot,
      subject,
      title,
      targetPomodoros = 2,
    } = req.body || {};

    if (!String(title || '').trim()) {
      return res.status(400).json({ error: 'يرجى إدخال عنوان مهمة المذاكرة' });
    }
    const actor = getRequestActor(req);
    const newPlan = {
      id: `splan-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      studentId: String(studentId || actor.userId || 'guest'),
      studentName: String(studentName || actor.userName || 'طالب'),
      dayOfWeek: String(dayOfWeek || 'السبت'),
      timeSlot: String(timeSlot || '05:00 م'),
      subject: String(subject || 'الرياضيات'),
      title: String(title).trim(),
      targetPomodoros: Math.max(1, Math.min(12, Number(targetPomodoros || 2))),
      completedPomodoros: 0,
      isCompleted: false,
      createdAt: new Date().toISOString(),
    };

    const rawPlans = await repo.getSystemSetting('alsharif_personal_study_plans_v1');
    const plans: any[] = rawPlans ? JSON.parse(rawPlans) : [];
    const nextPlans = [newPlan, ...plans].slice(0, 1000);
    await repo.setSystemSetting('alsharif_personal_study_plans_v1', JSON.stringify(nextPlans));
    res.status(201).json({ ok: true, plan: newPlan });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/study-hub/plans/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const rawPlans = await repo.getSystemSetting('alsharif_personal_study_plans_v1');
    const plans: any[] = rawPlans ? JSON.parse(rawPlans) : [];
    let updatedItem: any = null;
    const nextPlans = plans.map((p) => {
      if (p.id !== id) return p;
      updatedItem = { ...p, ...req.body, id: p.id };
      return updatedItem;
    });
    await repo.setSystemSetting('alsharif_personal_study_plans_v1', JSON.stringify(nextPlans));
    res.json({ ok: true, plan: updatedItem });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/study-hub/plans/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const rawPlans = await repo.getSystemSetting('alsharif_personal_study_plans_v1');
    const plans: any[] = rawPlans ? JSON.parse(rawPlans) : [];
    const nextPlans = plans.filter((p) => p.id !== id);
    await repo.setSystemSetting('alsharif_personal_study_plans_v1', JSON.stringify(nextPlans));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= SMART MISTAKE NOTEBOOK (دفتر الأخطاء الذكي) =================
app.get('/api/mistake-notebook', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_mistake_notebook_v1');
    const list: any[] = raw ? JSON.parse(raw) : [];
    const filtered = studentId ? list.filter((m) => m.studentId === studentId) : list;
    res.json({ mistakes: filtered });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/mistake-notebook/record', async (req, res) => {
  try {
    const { studentId, studentName, mistakes } = req.body || {};
    if (!studentId || !Array.isArray(mistakes) || mistakes.length === 0) {
      return res.json({ ok: true, added: 0 });
    }
    const raw = await repo.getSystemSetting('alsharif_mistake_notebook_v1');
    const existing: any[] = raw ? JSON.parse(raw) : [];
    const nowStr = new Date().toISOString();

    let added = 0;
    for (const item of mistakes) {
      if (!item || !item.question) continue;
      const idx = existing.findIndex(
        (m) =>
          m.studentId === studentId &&
          (m.questionId === item.questionId || m.question === item.question)
      );
      if (idx >= 0) {
        existing[idx] = {
          ...existing[idx],
          selectedOptionIndex: item.selectedOptionIndex,
          wrongCount: (Number(existing[idx].wrongCount) || 1) + 1,
          mastered: false,
          lastWrongAt: nowStr,
        };
      } else {
        existing.unshift({
          id: `mst-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          studentId: String(studentId),
          studentName: String(studentName || 'طالب'),
          subject: String(item.subject || 'عام'),
          grade: String(item.grade || ''),
          sourceType: item.sourceType === 'competition' ? 'competition' : 'quiz',
          quizId: item.quizId,
          quizTitle: item.quizTitle,
          questionId: String(item.questionId || item.question),
          question: String(item.question),
          options: Array.isArray(item.options) ? item.options : [],
          correctOptionIndex: Number(item.correctOptionIndex) || 0,
          selectedOptionIndex: Number(item.selectedOptionIndex) || 0,
          explanation: item.explanation || '',
          wrongCount: 1,
          mastered: false,
          lastWrongAt: nowStr,
        });
        added++;
      }
    }

    const trimmed = existing.slice(0, 3000);
    await repo.setSystemSetting('alsharif_mistake_notebook_v1', JSON.stringify(trimmed));
    res.json({ ok: true, added, mistakes: trimmed.filter((m) => m.studentId === studentId) });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/mistake-notebook/master', async (req, res) => {
  try {
    const { id, mastered = true } = req.body || {};
    if (!id) return res.status(400).json({ error: 'id is required' });
    const raw = await repo.getSystemSetting('alsharif_mistake_notebook_v1');
    const existing: any[] = raw ? JSON.parse(raw) : [];
    const next = existing.map((m) =>
      m.id === id
        ? {
            ...m,
            mastered: Boolean(mastered),
            masteredAt: mastered ? new Date().toISOString() : undefined,
          }
        : m
    );
    await repo.setSystemSetting('alsharif_mistake_notebook_v1', JSON.stringify(next));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/mistake-notebook/:id', async (req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_mistake_notebook_v1');
    const existing: any[] = raw ? JSON.parse(raw) : [];
    const next = existing.filter((m) => m.id !== req.params.id);
    await repo.setSystemSetting('alsharif_mistake_notebook_v1', JSON.stringify(next));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 7-DAY EXAM SPRINT GENERATOR (خطة مراجعة ليلة الامتحان) =================
app.get('/api/study-hub/exam-sprint', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_exam_sprint_plans_v1');
    const plans: any[] = raw ? JSON.parse(raw) : [];
    const filtered = studentId ? plans.filter((p) => p.studentId === studentId) : plans;
    res.json({ plans: filtered });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/study-hub/exam-sprint', async (req, res) => {
  try {
    const { studentId, studentName, subject, examDate, dailyHours = 2, tasks } = req.body || {};
    if (!studentId || !Array.isArray(tasks)) {
      return res.status(400).json({ error: 'studentId and tasks are required' });
    }
    const raw = await repo.getSystemSetting('alsharif_exam_sprint_plans_v1');
    const plans: any[] = raw ? JSON.parse(raw) : [];
    const newPlan = {
      id: `sprint-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      studentId: String(studentId),
      studentName: String(studentName || 'طالب'),
      subject: String(subject || 'جميع المواد'),
      examDate: String(examDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]),
      dailyHours: Math.max(1, Number(dailyHours) || 2),
      tasks,
      createdAt: new Date().toISOString(),
    };
    const next = [newPlan, ...plans].slice(0, 500);
    await repo.setSystemSetting('alsharif_exam_sprint_plans_v1', JSON.stringify(next));
    res.status(201).json({ ok: true, plan: newPlan });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/study-hub/exam-sprint/:id', async (req, res) => {
  try {
    const { taskId, isCompleted } = req.body || {};
    const raw = await repo.getSystemSetting('alsharif_exam_sprint_plans_v1');
    const plans: any[] = raw ? JSON.parse(raw) : [];
    let updatedPlan: any = null;
    const next = plans.map((p) => {
      if (p.id !== req.params.id) return p;
      const updatedTasks = Array.isArray(p.tasks)
        ? p.tasks.map((t: any) => (t.id === taskId ? { ...t, isCompleted: Boolean(isCompleted) } : t))
        : [];
      updatedPlan = { ...p, tasks: updatedTasks };
      return updatedPlan;
    });
    await repo.setSystemSetting('alsharif_exam_sprint_plans_v1', JSON.stringify(next));
    res.json({ ok: true, plan: updatedPlan });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/study-hub/exam-sprint/:id', async (req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_exam_sprint_plans_v1');
    const plans: any[] = raw ? JSON.parse(raw) : [];
    const next = plans.filter((p) => p.id !== req.params.id);
    await repo.setSystemSetting('alsharif_exam_sprint_plans_v1', JSON.stringify(next));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= LESSON BOOKMARKS (حفظ الدروس المفضلة للطالب) =================
app.get('/api/lesson-bookmarks', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_lesson_bookmarks_v1');
    const bookmarks: any[] = raw ? JSON.parse(raw) : [];
    const filtered = studentId ? bookmarks.filter((b) => b.studentId === studentId) : bookmarks;
    res.json({ bookmarks: filtered });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/lesson-bookmarks/toggle', async (req, res) => {
  try {
    const { studentId, lessonId } = req.body || {};
    if (!studentId || !lessonId) {
      return res.status(400).json({ error: 'studentId and lessonId are required' });
    }
    const raw = await repo.getSystemSetting('alsharif_lesson_bookmarks_v1');
    const bookmarks: any[] = raw ? JSON.parse(raw) : [];
    const exists = bookmarks.some((b) => b.studentId === studentId && b.lessonId === lessonId);
    const next = exists
      ? bookmarks.filter((b) => !(b.studentId === studentId && b.lessonId === lessonId))
      : [{ studentId, lessonId, createdAt: new Date().toISOString() }, ...bookmarks];
    await repo.setSystemSetting('alsharif_lesson_bookmarks_v1', JSON.stringify(next));
    res.json({
      ok: true,
      bookmarked: !exists,
      bookmarks: next.filter((b) => b.studentId === studentId),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= CONTENT ERROR REPORTS (سجل نشاط ومشاكل المحتوى) =================
app.get('/api/content-reports', async (_req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_content_error_reports_v1');
    const reports: any[] = raw ? JSON.parse(raw) : [];
    res.json({ reports });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/content-reports', async (req, res) => {
  try {
    const {
      targetType = 'lesson',
      lessonId,
      quizId,
      questionId,
      targetTitle,
      subject = 'عام',
      category = 'needs_clarification',
      details = '',
      reporterId = 'guest',
      reporterName = 'طالب',
    } = req.body || {};

    if (!String(targetTitle || '').trim()) {
      return res.status(400).json({ error: 'عنوان المحتوى مطلوب' });
    }

    const raw = await repo.getSystemSetting('alsharif_content_error_reports_v1');
    const reports: any[] = raw ? JSON.parse(raw) : [];
    const newReport = {
      id: `crep-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      targetType: targetType === 'quiz_question' ? 'quiz_question' : 'lesson',
      lessonId,
      quizId,
      questionId,
      targetTitle: String(targetTitle).trim(),
      subject: String(subject),
      category,
      details: String(details || '').trim(),
      reporterId: String(reporterId),
      reporterName: String(reporterName),
      status: 'open',
      createdAt: new Date().toISOString(),
    };
    const next = [newReport, ...reports].slice(0, 500);
    await repo.setSystemSetting('alsharif_content_error_reports_v1', JSON.stringify(next));
    broadcastAll({ type: 'content_reports:updated', report: newReport });
    res.status(201).json({ ok: true, report: newReport, reports: next });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/content-reports/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'معالجة بلاغات المحتوى متاحة للمعلم والإدارة فقط')) return;
  try {
    const { status = 'resolved' } = req.body || {};
    const actorName = getRequestActor(req).userName || 'المعلم / الإدارة';
    const raw = await repo.getSystemSetting('alsharif_content_error_reports_v1');
    const reports: any[] = raw ? JSON.parse(raw) : [];
    let updated: any = null;
    const next = reports.map((r) => {
      if (r.id !== req.params.id) return r;
      updated = {
        ...r,
        status,
        resolvedBy: actorName,
        resolvedAt: status === 'resolved' ? new Date().toISOString() : undefined,
      };
      return updated;
    });
    await repo.setSystemSetting('alsharif_content_error_reports_v1', JSON.stringify(next));
    await recordSensitiveAuditLog(req, {
      action: 'resolve_content_report',
      actionAr: 'معالجة بلاغ خطأ محتوى',
      entityType: 'lesson',
      entityName: updated?.targetTitle || req.params.id,
      details: `تم تحديث حالة البلاغ إلى (${status}) بواسطة (${actorName}).`,
      severity: 'info',
    });
    broadcastAll({ type: 'content_reports:updated' });
    res.json({ ok: true, report: updated, reports: next });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/content-reports/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'حذف بلاغات المحتوى متاح للمعلم والإدارة فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_content_error_reports_v1');
    const reports: any[] = raw ? JSON.parse(raw) : [];
    const next = reports.filter((r) => r.id !== req.params.id);
    await repo.setSystemSetting('alsharif_content_error_reports_v1', JSON.stringify(next));
    broadcastAll({ type: 'content_reports:updated' });
    res.json({ ok: true, reports: next });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= WEEKLY CLASS CHALLENGES (تحديات الصف الأسبوعية الجماعية) =================
async function evaluateChallengeWinnersList(challenge: any, attempts: any[], allStudents: any[]) {
  const minPct = Number(challenge.minPercentage) || 90;
  const maxWin = Math.max(1, Number(challenge.maxWinners) || 10);
  const matchingAttempts = attempts
    .filter((a) => {
      if (Number(a.percentage) < minPct) return false;
      if (challenge.quizId && a.quizId !== challenge.quizId) return false;
      if (challenge.subject && challenge.subject !== 'جميع المواد' && a.subject !== challenge.subject) {
        return false;
      }
      if (challenge.grade && challenge.grade !== 'جميع الصفوف' && a.grade !== challenge.grade) {
        return false;
      }
      return true;
    })
    .sort((a, b) => {
      const timeA = new Date(a.createdAt || a.takenDate || 0).getTime();
      const timeB = new Date(b.createdAt || b.takenDate || 0).getTime();
      return timeA - timeB;
    });

  const seenStudent = new Set<string>();
  const winners: any[] = [];
  for (const att of matchingAttempts) {
    if (seenStudent.has(att.studentId)) continue;
    seenStudent.add(att.studentId);
    const stu = allStudents.find((s) => s.id === att.studentId);
    winners.push({
      studentId: att.studentId,
      studentCode: att.studentCode || stu?.code || '',
      studentName: att.studentName,
      percentage: Number(att.percentage),
      achievedAt: att.takenDate || new Date().toISOString().split('T')[0],
      seatNumber: winners.length + 1,
    });
    if (winners.length >= maxWin) break;
  }
  return winners;
}

app.get('/api/class-challenges', async (_req, res) => {
  try {
    const [rawChallenges, attempts, students] = await Promise.all([
      repo.getSystemSetting('alsharif_weekly_class_challenges_v1'),
      repo.getAllQuizAttempts(),
      repo.getAllStudents(),
    ]);
    const list: any[] = rawChallenges ? JSON.parse(rawChallenges) : [];
    const hydrated = await Promise.all(
      list.map(async (ch) => ({
        ...ch,
        winners: await evaluateChallengeWinnersList(ch, attempts, students),
      }))
    );
    res.json({ challenges: hydrated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/class-challenges', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'إنشاء التحديات الأسبوعية متاح للمعلم والإدارة فقط')) return;
  try {
    const {
      title,
      subject = 'جميع المواد',
      grade = 'جميع الصفوف',
      quizId,
      minPercentage = 90,
      maxWinners = 10,
      badgeTitle = 'بطل التحدي الأسبوعي 🏆',
      deadlineDate,
    } = req.body || {};
    if (!String(title || '').trim()) {
      return res.status(400).json({ error: 'عنوان التحدي مطلوب' });
    }
    const actorName = getRequestActor(req).userName || 'الإدارة / المعلم';
    const [rawChallenges, attempts, students] = await Promise.all([
      repo.getSystemSetting('alsharif_weekly_class_challenges_v1'),
      repo.getAllQuizAttempts(),
      repo.getAllStudents(),
    ]);
    const list: any[] = rawChallenges ? JSON.parse(rawChallenges) : [];
    const newCh: any = {
      id: `ch-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      title: String(title).trim(),
      subject: String(subject),
      grade: String(grade),
      quizId: quizId || undefined,
      minPercentage: Math.min(100, Math.max(50, Number(minPercentage) || 90)),
      maxWinners: Math.min(100, Math.max(1, Number(maxWinners) || 10)),
      badgeTitle: String(badgeTitle || 'بطل التحدي الأسبوعي 🏆').trim(),
      deadlineDate: String(deadlineDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]),
      winners: [],
      createdBy: actorName,
      createdAt: new Date().toISOString().split('T')[0],
    };
    newCh.winners = await evaluateChallengeWinnersList(newCh, attempts, students);

    // Grant honor badge to evaluated winners in alsharif_student_badges_v1
    if (newCh.winners.length > 0) {
      const rawBadges = await repo.getSystemSetting('alsharif_student_badges_v1');
      const badgesMap: Record<string, any[]> = rawBadges ? JSON.parse(rawBadges) : {};
      for (const w of newCh.winners) {
        const currentBadges = Array.isArray(badgesMap[w.studentId]) ? badgesMap[w.studentId] : [];
        if (!currentBadges.some((b: any) => b.challengeId === newCh.id)) {
          badgesMap[w.studentId] = [
            ...currentBadges,
            {
              id: `bdg-${newCh.id}`,
              challengeId: newCh.id,
              title: newCh.badgeTitle,
              badgeText: newCh.badgeTitle,
              earnedAt: new Date().toISOString().split('T')[0],
            },
          ];
        }
      }
      await repo.setSystemSetting('alsharif_student_badges_v1', JSON.stringify(badgesMap));
    }

    const next = [newCh, ...list].slice(0, 100);
    await repo.setSystemSetting('alsharif_weekly_class_challenges_v1', JSON.stringify(next));
    broadcastAll({ type: 'class_challenges:updated' });
    res.status(201).json({ ok: true, challenge: newCh, challenges: next });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/class-challenges/:id/evaluate', async (_req, res) => {
  try {
    const [rawChallenges, attempts, students, rawBadges] = await Promise.all([
      repo.getSystemSetting('alsharif_weekly_class_challenges_v1'),
      repo.getAllQuizAttempts(),
      repo.getAllStudents(),
      repo.getSystemSetting('alsharif_student_badges_v1'),
    ]);
    const list: any[] = rawChallenges ? JSON.parse(rawChallenges) : [];
    const badgesMap: Record<string, any[]> = rawBadges ? JSON.parse(rawBadges) : {};
    let updatedCh: any = null;
    for (const ch of list) {
      if (ch.id === _req.params.id) {
        ch.winners = await evaluateChallengeWinnersList(ch, attempts, students);
        updatedCh = ch;
        for (const w of ch.winners) {
          const cur = Array.isArray(badgesMap[w.studentId]) ? badgesMap[w.studentId] : [];
          if (!cur.some((b: any) => b.challengeId === ch.id)) {
            badgesMap[w.studentId] = [
              ...cur,
              {
                id: `bdg-${ch.id}`,
                challengeId: ch.id,
                title: ch.badgeTitle,
                badgeText: ch.badgeTitle,
                earnedAt: new Date().toISOString().split('T')[0],
              },
            ];
          }
        }
      }
    }
    await Promise.all([
      repo.setSystemSetting('alsharif_weekly_class_challenges_v1', JSON.stringify(list)),
      repo.setSystemSetting('alsharif_student_badges_v1', JSON.stringify(badgesMap)),
    ]);
    broadcastAll({ type: 'class_challenges:updated' });
    res.json({ ok: true, challenge: updatedCh, challenges: list });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/class-challenges/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'حذف التحديات الأسبوعية متاح للإدارة فقط')) return;
  try {
    const rawChallenges = await repo.getSystemSetting('alsharif_weekly_class_challenges_v1');
    const list: any[] = rawChallenges ? JSON.parse(rawChallenges) : [];
    const next = list.filter((c) => c.id !== req.params.id);
    await repo.setSystemSetting('alsharif_weekly_class_challenges_v1', JSON.stringify(next));
    broadcastAll({ type: 'class_challenges:updated' });
    res.json({ ok: true, challenges: next });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 1. SMART QUESTION BANK (بنك الأسئلة المركزي والتصنيف بالصعوبة) =================
app.get('/api/question-bank', async (req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_question_bank_v1');
    const items: any[] = raw ? JSON.parse(raw) : [];
    res.json(Array.isArray(items) ? items : []);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/question-bank', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'إضافة أسئلة لبنك الأسئلة متاحة للمعلم أو الإدارة فقط')) return;
  try {
    const actor = getRequestActor(req);
    const raw = await repo.getSystemSetting('alsharif_question_bank_v1');
    const items: any[] = raw ? JSON.parse(raw) : [];
    const body = req.body || {};
    if (!String(body.question || '').trim()) {
      return res.status(400).json({ error: 'يرجى إدخال نص السؤال' });
    }
    const newItem = {
      id: body.id || `qb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      subject: String(body.subject || 'الرياضيات').trim(),
      grade: String(body.grade || 'الصف الثالث الثانوي').trim(),
      unit: String(body.unit || 'الوحدة الأولى').trim(),
      lessonId: body.lessonId ? String(body.lessonId) : undefined,
      lessonTitle: body.lessonTitle ? String(body.lessonTitle) : undefined,
      difficulty: ['easy', 'medium', 'advanced', 'gifted'].includes(body.difficulty)
        ? body.difficulty
        : 'medium',
      questionType: body.questionType === 'true_false' ? 'true_false' : 'mcq',
      question: String(body.question).trim(),
      options: Array.isArray(body.options) ? body.options : ['أ', 'ب', 'ج', 'د'],
      correctOptionIndex: Number(body.correctOptionIndex) || 0,
      explanation: String(body.explanation || '').trim(),
      points: Math.max(1, Number(body.points) || 2),
      usageCount: Number(body.usageCount) || 0,
      createdBy: actor.userName || body.createdBy || 'هيئة التدريس',
      createdAt: new Date().toISOString().split('T')[0],
    };
    const next = [newItem, ...items.filter((i) => i.id !== newItem.id)];
    await repo.setSystemSetting('alsharif_question_bank_v1', JSON.stringify(next));
    broadcastAll({ type: 'question_bank:updated' });
    res.status(201).json(newItem);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/question-bank/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'تعديل بنك الأسئلة متاح للمعلم أو الإدارة فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_question_bank_v1');
    const items: any[] = raw ? JSON.parse(raw) : [];
    const idx = items.findIndex((i) => i.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'السؤال غير موجود في البنك' });
    const updated = { ...items[idx], ...req.body, id: items[idx].id };
    items[idx] = updated;
    await repo.setSystemSetting('alsharif_question_bank_v1', JSON.stringify(items));
    broadcastAll({ type: 'question_bank:updated' });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/question-bank/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'حذف الأسئلة متاح للمعلم أو الإدارة فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_question_bank_v1');
    const items: any[] = raw ? JSON.parse(raw) : [];
    const next = items.filter((i) => i.id !== req.params.id);
    await repo.setSystemSetting('alsharif_question_bank_v1', JSON.stringify(next));
    broadcastAll({ type: 'question_bank:updated' });
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/question-bank/sync-from-quizzes', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'مزامنة الأسئلة متاحة للمعلم أو الإدارة فقط')) return;
  try {
    const actor = getRequestActor(req);
    const [raw, allQuizzes] = await Promise.all([
      repo.getSystemSetting('alsharif_question_bank_v1'),
      repo.getAllQuizzes(),
    ]);
    const items: any[] = raw ? JSON.parse(raw) : [];
    const existingTextSet = new Set(items.map((i) => `${i.subject}::${String(i.question || '').trim()}`));
    let addedCount = 0;

    for (const qz of allQuizzes) {
      let parsedQuestions: any[] = [];
      try {
        parsedQuestions = typeof qz.questions === 'string' ? JSON.parse(qz.questions) : (qz.questions || []);
      } catch {
        parsedQuestions = [];
      }
      for (const q of parsedQuestions) {
        const text = String(q.question || '').trim();
        if (!text) continue;
        const key = `${qz.subject}::${text}`;
        if (existingTextSet.has(key)) continue;
        existingTextSet.add(key);
        items.unshift({
          id: `qb-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          subject: qz.subject || 'عام',
          grade: qz.grade || 'الصف الثالث الثانوي',
          unit: q.unit || 'أسئلة الاختبارات',
          lessonId: q.sourceLessonId,
          lessonTitle: q.sourceLessonTitle || qz.title,
          difficulty: ['easy', 'medium', 'advanced', 'gifted'].includes(q.difficulty) ? q.difficulty : 'medium',
          questionType: q.questionType === 'true_false' ? 'true_false' : 'mcq',
          question: text,
          options: Array.isArray(q.options) ? q.options : [],
          correctOptionIndex: Number(q.correctOptionIndex) || 0,
          explanation: String(q.explanation || '').trim(),
          points: Number(q.points) || 2,
          usageCount: 1,
          createdBy: actor.userName || qz.teacherName || 'المزامنة التلقائية',
          createdAt: new Date().toISOString().split('T')[0],
        });
        addedCount += 1;
      }
    }
    await repo.setSystemSetting('alsharif_question_bank_v1', JSON.stringify(items));
    broadcastAll({ type: 'question_bank:updated' });
    res.json({ ok: true, addedCount, items });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/question-bank/pull', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'سحب الأسئلة متاح للمعلم أو الإدارة فقط')) return;
  try {
    const {
      subject,
      grade,
      unit,
      difficulty,
      count = 5,
      excludeIds = [],
      excludeQuestionTexts = [],
    } = req.body || {};

    const raw = await repo.getSystemSetting('alsharif_question_bank_v1');
    const items: any[] = raw ? JSON.parse(raw) : [];
    const exIdSet = new Set((Array.isArray(excludeIds) ? excludeIds : []).map(String));
    const exTextSet = new Set(
      (Array.isArray(excludeQuestionTexts) ? excludeQuestionTexts : []).map((t: any) =>
        String(t || '').trim().toLowerCase()
      )
    );

    const candidates = items.filter((item) => {
      if (subject && subject !== 'all' && item.subject !== subject) return false;
      if (grade && grade !== 'all' && item.grade !== grade) return false;
      if (unit && unit !== 'all' && item.unit !== unit) return false;
      if (difficulty && difficulty !== 'all' && item.difficulty !== difficulty) return false;
      if (exIdSet.has(String(item.id))) return false;
      if (exTextSet.has(String(item.question || '').trim().toLowerCase())) return false;
      return true;
    });

    const shuffled = [...candidates].sort(() => Math.random() - 0.5);
    const picked = shuffled.slice(0, Math.max(1, Number(count) || 5));
    const pickedIds = new Set(picked.map((p) => p.id));

    const updatedBank = items.map((i) =>
      pickedIds.has(i.id) ? { ...i, usageCount: (Number(i.usageCount) || 0) + 1 } : i
    );
    await repo.setSystemSetting('alsharif_question_bank_v1', JSON.stringify(updatedBank));

    res.json({ ok: true, questions: picked, totalMatched: candidates.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 2. SM2 SPACED REPETITION FOR FLASHCARDS =================
app.get('/api/flashcards/sm2', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_flashcard_sm2_v1');
    const allMap: Record<string, any> = raw ? JSON.parse(raw) : {};
    if (studentId) {
      return res.json({ records: allMap[studentId] || {} });
    }
    res.json({ allRecords: allMap });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/flashcards/sm2/review', async (req, res) => {
  try {
    const { studentId, cardId, quality } = req.body || {};
    if (!studentId || !cardId) {
      return res.status(400).json({ error: 'بيانات الطالب والبطاقة مطلوبة' });
    }
    const qLevel: 'hard' | 'medium' | 'easy' =
      quality === 'easy' ? 'easy' : quality === 'medium' ? 'medium' : 'hard';
    // SM2 Quality mapping: hard=2 (re-queue fast), medium=4, easy=5
    const qScore = qLevel === 'easy' ? 5 : qLevel === 'medium' ? 4 : 2;

    const raw = await repo.getSystemSetting('alsharif_flashcard_sm2_v1');
    const allMap: Record<string, Record<string, any>> = raw ? JSON.parse(raw) : {};
    const studentMap = allMap[studentId] || {};
    const prev = studentMap[cardId] || {
      easeFactor: 2.5,
      intervalDays: 0,
      repetitions: 0,
    };

    let easeFactor = Number(prev.easeFactor) || 2.5;
    let repetitions = Number(prev.repetitions) || 0;
    let intervalDays = Number(prev.intervalDays) || 0;

    if (qScore < 3) {
      repetitions = 0;
      intervalDays = 0; // Due immediately / same day
    } else {
      if (repetitions === 0) intervalDays = 1;
      else if (repetitions === 1) intervalDays = qLevel === 'easy' ? 4 : 3;
      else intervalDays = Math.round(intervalDays * easeFactor);
      repetitions += 1;
    }

    easeFactor = Math.max(
      1.3,
      Number((easeFactor + (0.1 - (5 - qScore) * (0.08 + (5 - qScore) * 0.02))).toFixed(2))
    );

    const nextDate = new Date(Date.now() + intervalDays * 86400000).toISOString();
    const record = {
      cardId,
      studentId,
      easeFactor,
      intervalDays,
      repetitions,
      lastQuality: qLevel,
      nextReviewAt: nextDate,
      updatedAt: new Date().toISOString(),
    };

    studentMap[cardId] = record;
    allMap[studentId] = studentMap;
    await repo.setSystemSetting('alsharif_flashcard_sm2_v1', JSON.stringify(allMap));
    res.json({ ok: true, record, records: studentMap });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 3. DAILY STUDY STREAKS, FREEZE & RANKS =================
function computeStreakRank(days: number): string {
  if (days >= 30) return 'بطل الشريف الذهبي';
  if (days >= 14) return 'متفوق منضبط';
  if (days >= 5) return 'مثابر نشط';
  return 'مبتدئ طموح';
}

app.get('/api/study-streaks', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_study_streaks_v1');
    const map: Record<string, any> = raw ? JSON.parse(raw) : {};
    if (studentId) {
      return res.json({ streak: map[studentId] || null, allStreaks: Object.values(map) });
    }
    res.json({ allStreaks: Object.values(map) });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/study-streaks/checkin', async (req, res) => {
  try {
    const { studentId, studentName, points = 15 } = req.body || {};
    if (!studentId) return res.status(400).json({ error: 'studentId مطلوب' });
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    const raw = await repo.getSystemSetting('alsharif_study_streaks_v1');
    const map: Record<string, any> = raw ? JSON.parse(raw) : {};
    const cur = map[studentId] || {
      studentId,
      studentName: studentName || 'طالب',
      currentStreak: 0,
      longestStreak: 0,
      lastStudyDate: '',
      freezeTokens: 2,
      frozenDates: [],
      totalPoints: 0,
      rankTitle: 'مبتدئ طموح',
      historyDates: [],
    };

    const historySet = new Set<string>(Array.isArray(cur.historyDates) ? cur.historyDates : []);
    if (cur.lastStudyDate === today) {
      cur.totalPoints = (Number(cur.totalPoints) || 0) + Number(points || 10);
    } else {
      const wasFrozenYesterday = Array.isArray(cur.frozenDates) && cur.frozenDates.includes(yesterday);
      if (cur.lastStudyDate === yesterday || wasFrozenYesterday || cur.currentStreak === 0) {
        cur.currentStreak = (Number(cur.currentStreak) || 0) + 1;
      } else {
        cur.currentStreak = 1;
      }
      cur.lastStudyDate = today;
      historySet.add(today);
      cur.historyDates = Array.from(historySet).slice(-60);
      cur.longestStreak = Math.max(Number(cur.longestStreak) || 0, cur.currentStreak);
      cur.totalPoints = (Number(cur.totalPoints) || 0) + Number(points || 15);
      // Award an extra freeze token every 7 days
      if (cur.currentStreak % 7 === 0) {
        cur.freezeTokens = Math.min(3, (Number(cur.freezeTokens) || 0) + 1);
      }
    }
    cur.studentName = studentName || cur.studentName;
    cur.rankTitle = computeStreakRank(cur.currentStreak);
    map[studentId] = cur;
    await repo.setSystemSetting('alsharif_study_streaks_v1', JSON.stringify(map));
    res.json({ ok: true, streak: cur });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/study-streaks/freeze', async (req, res) => {
  try {
    const { studentId, studentName } = req.body || {};
    if (!studentId) return res.status(400).json({ error: 'studentId مطلوب' });
    const today = new Date().toISOString().split('T')[0];

    const raw = await repo.getSystemSetting('alsharif_study_streaks_v1');
    const map: Record<string, any> = raw ? JSON.parse(raw) : {};
    const cur = map[studentId] || {
      studentId,
      studentName: studentName || 'طالب',
      currentStreak: 0,
      longestStreak: 0,
      lastStudyDate: today,
      freezeTokens: 2,
      frozenDates: [],
      totalPoints: 0,
      rankTitle: 'مبتدئ طموح',
      historyDates: [],
    };
    if ((Number(cur.freezeTokens) || 0) <= 0) {
      return res.status(400).json({ error: 'لا يتوفر لديك رصيد تجميد سلسلة متاح حالياً' });
    }
    const frozen = new Set<string>(Array.isArray(cur.frozenDates) ? cur.frozenDates : []);
    if (frozen.has(today)) {
      return res.status(400).json({ error: 'السلسلة مجمدة بالفعل لليوم' });
    }
    frozen.add(today);
    cur.frozenDates = Array.from(frozen);
    cur.freezeTokens = Math.max(0, (Number(cur.freezeTokens) || 0) - 1);
    map[studentId] = cur;
    await repo.setSystemSetting('alsharif_study_streaks_v1', JSON.stringify(map));
    res.json({ ok: true, streak: cur });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 4. LESSON Q&A THREAD (ركن اسأل المعلم أسفل كل درس) =================
app.get('/api/lesson-qa', async (req, res) => {
  try {
    const lessonId = String(req.query.lessonId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_lesson_qa_v1');
    const list: any[] = raw ? JSON.parse(raw) : [];
    const filtered = lessonId ? list.filter((q) => q.lessonId === lessonId) : list;
    filtered.sort((a, b) => Number(Boolean(b.isPinned)) - Number(Boolean(a.isPinned)));
    res.json(filtered);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/lesson-qa', async (req, res) => {
  try {
    const actor = getRequestActor(req);
    const { lessonId, lessonTitle, subject, questionText, videoTimestampSec, authorId, authorName } = req.body || {};
    if (!lessonId || !String(questionText || '').trim()) {
      return res.status(400).json({ error: 'يرجى كتابة سؤالك أولاً' });
    }
    const raw = await repo.getSystemSetting('alsharif_lesson_qa_v1');
    const list: any[] = raw ? JSON.parse(raw) : [];
    const item = {
      id: `lqa-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      lessonId: String(lessonId),
      lessonTitle: String(lessonTitle || 'درس'),
      subject: String(subject || 'عام'),
      authorId: String(actor.userId || authorId || 'user'),
      authorName: String(actor.userName || authorName || 'طالب'),
      authorRole: actor.role || 'student',
      questionText: String(questionText).trim(),
      videoTimestampSec: videoTimestampSec !== undefined && videoTimestampSec !== null ? Number(videoTimestampSec) : null,
      answerText: null,
      answeredBy: null,
      answeredAt: null,
      isPinned: false,
      upvotes: 0,
      createdAt: new Date().toLocaleString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    };
    const next = [item, ...list].slice(0, 500);
    await repo.setSystemSetting('alsharif_lesson_qa_v1', JSON.stringify(next));
    broadcastAll({ type: 'lesson_qa:updated', lessonId });
    res.status(201).json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/lesson-qa/:id/answer', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'الرد الرسمي وتثبيت الإجابات متاح للمعلم أو الإدارة فقط')) return;
  try {
    const actor = getRequestActor(req);
    const { answerText, isPinned } = req.body || {};
    const raw = await repo.getSystemSetting('alsharif_lesson_qa_v1');
    const list: any[] = raw ? JSON.parse(raw) : [];
    const idx = list.findIndex((q) => q.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'السؤال غير موجود' });
    if (answerText !== undefined) {
      list[idx].answerText = String(answerText).trim();
      list[idx].answeredBy = actor.userName || 'المعلم';
      list[idx].answeredAt = new Date().toLocaleString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }
    if (isPinned !== undefined) {
      list[idx].isPinned = Boolean(isPinned);
    }
    await repo.setSystemSetting('alsharif_lesson_qa_v1', JSON.stringify(list));
    broadcastAll({ type: 'lesson_qa:updated', lessonId: list[idx].lessonId });
    res.json(list[idx]);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/lesson-qa/:id/upvote', async (req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_lesson_qa_v1');
    const list: any[] = raw ? JSON.parse(raw) : [];
    const idx = list.findIndex((q) => q.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'السؤال غير موجود' });
    list[idx].upvotes = (Number(list[idx].upvotes) || 0) + 1;
    await repo.setSystemSetting('alsharif_lesson_qa_v1', JSON.stringify(list));
    res.json(list[idx]);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/lesson-qa/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'حذف الأسئلة متاح للمعلم أو الإدارة فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_lesson_qa_v1');
    const list: any[] = raw ? JSON.parse(raw) : [];
    const next = list.filter((q) => q.id !== req.params.id);
    await repo.setSystemSetting('alsharif_lesson_qa_v1', JSON.stringify(next));
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 5. DRIP CONTENT & CONDITIONAL LESSON UNLOCKING =================
app.get('/api/lessons/drip-rules', async (_req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_lesson_drip_rules_v1');
    const map = raw ? JSON.parse(raw) : {};
    res.json({ rules: map && typeof map === 'object' ? map : {} });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/lessons/drip-rules/:lessonId', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'تعديل قواعد فتح الدروس متاح للمعلم أو الإدارة فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_lesson_drip_rules_v1');
    const map: Record<string, any> = raw ? JSON.parse(raw) : {};
    const lessonId = req.params.lessonId;
    const body = req.body || {};
    if (!body.dripUnlockAtDate && !body.dripUnlockAfterDays && !body.prerequisiteLessonId) {
      delete map[lessonId];
    } else {
      map[lessonId] = {
        lessonId,
        dripUnlockAtDate: body.dripUnlockAtDate || '',
        dripUnlockAfterDays: body.dripUnlockAfterDays ? Number(body.dripUnlockAfterDays) : undefined,
        prerequisiteLessonId: body.prerequisiteLessonId || '',
        prerequisiteMinScore: body.prerequisiteMinScore ? Number(body.prerequisiteMinScore) : 70,
        updatedAt: new Date().toISOString(),
      };
    }
    await repo.setSystemSetting('alsharif_lesson_drip_rules_v1', JSON.stringify(map));
    broadcastAll({ type: 'lesson_drip:updated' });
    res.json({ ok: true, rules: map });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 6. AT-RISK STUDENT EARLY WARNING RADAR =================
app.get('/api/analytics/at-risk-students', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'رادار الإنذار المبكر متاح للمعلمين والإدارة فقط')) return;
  try {
    const [students, attempts, rawStreaks, rawSessions] = await Promise.all([
      repo.getAllStudents(),
      repo.getAllQuizAttempts(),
      repo.getSystemSetting('alsharif_study_streaks_v1'),
      repo.getSystemSetting('alsharif_pomodoro_sessions_v1'),
    ]);
    const streaksMap: Record<string, any> = rawStreaks ? JSON.parse(rawStreaks) : {};
    const sessions: any[] = rawSessions ? JSON.parse(rawSessions) : [];
    const nowMs = Date.now();

    const alerts: any[] = [];
    for (const s of students) {
      const reasons: string[] = [];
      let riskScore = 0;

      if ((Number(s.attendanceRate) || 100) < 75) {
        reasons.push(`انخفاض نسبة الحضور (${s.attendanceRate}%)`);
        riskScore += 35;
      }
      if ((Number(s.overallScore) || 100) < 65) {
        reasons.push(`متوسط الدرجات العام ضعيف (${s.overallScore}%)`);
        riskScore += 30;
      }

      const stuAttempts = attempts
        .filter((a: any) => a.studentId === s.id || a.studentName === s.name)
        .slice(0, 3);
      const lastTwoScores = stuAttempts.slice(0, 2).map((a: any) => Number(a.percentage) || 0);
      if (lastTwoScores.length >= 2 && lastTwoScores[0] < 65 && lastTwoScores[1] < 65) {
        reasons.push(`تراجع آخر اختبارين (${lastTwoScores[1]}% ثم ${lastTwoScores[0]}%)`);
        riskScore += 30;
      } else if (lastTwoScores.length === 2 && lastTwoScores[0] + 15 <= lastTwoScores[1]) {
        reasons.push(`هبوط حاد في آخر اختبار من ${lastTwoScores[1]}% إلى ${lastTwoScores[0]}%`);
        riskScore += 25;
      }

      // Check days since last study/streak/attempt
      let lastActMs = 0;
      const streak = streaksMap[s.id];
      if (streak?.lastStudyDate) {
        lastActMs = Math.max(lastActMs, new Date(streak.lastStudyDate).getTime() || 0);
      }
      const stuSession = sessions.find((p) => p.studentId === s.id);
      if (stuSession?.completedAt) {
        lastActMs = Math.max(lastActMs, new Date(stuSession.completedAt).getTime() || 0);
      }
      if (stuAttempts[0]?.createdAt) {
        lastActMs = Math.max(lastActMs, new Date(stuAttempts[0].createdAt).getTime() || 0);
      }
      const daysSince = lastActMs > 0 ? Math.floor((nowMs - lastActMs) / 86400000) : null;
      if (daysSince !== null && daysSince >= 5) {
        reasons.push(`انقطاع عن المذاكرة والمنصة منذ ${daysSince} أيام`);
        riskScore += 25;
      }

      if (reasons.length > 0 || s.status === 'weak') {
        if (reasons.length === 0) {
          reasons.push('مصنّف ضمن قائمة الطلاب المحتاجين للدعم الأكاديمي');
          riskScore += 20;
        }
        alerts.push({
          studentId: s.id,
          studentCode: s.code,
          studentName: s.name,
          grade: s.grade,
          type: s.type,
          parentName: s.parentName,
          parentPhone: s.parentPhone,
          attendanceRate: s.attendanceRate,
          overallScore: s.overallScore,
          lastTwoScores,
          daysSinceLastActivity: daysSince,
          riskScore: Math.min(100, riskScore),
          riskLevel: riskScore >= 50 ? 'high' : 'medium',
          reasons,
        });
      }
    }

    alerts.sort((a, b) => b.riskScore - a.riskScore);
    res.json({ alerts, totalEvaluated: students.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 7. LIVE CLASSES AUTO-ATTENDANCE =================
app.get('/api/live-attendance', async (req, res) => {
  try {
    const slotId = String(req.query.slotId || '').trim();
    const raw = await repo.getSystemSetting('alsharif_live_attendance_v1');
    const logs: any[] = raw ? JSON.parse(raw) : [];
    const filtered = slotId ? logs.filter((l) => l.slotId === slotId) : logs;
    res.json({ logs: filtered });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/live-attendance/join', async (req, res) => {
  try {
    const { slotId, slotTitle, subject, grade, platform, studentId, studentCode, studentName } = req.body || {};
    if (!slotId || !studentId) return res.status(400).json({ error: 'بيانات الجلسة والطالب مطلوبة' });
    const raw = await repo.getSystemSetting('alsharif_live_attendance_v1');
    const logs: any[] = raw ? JSON.parse(raw) : [];
    const nowIso = new Date().toISOString();
    const todayPrefix = nowIso.split('T')[0];

    const existingIdx = logs.findIndex(
      (l) => l.slotId === slotId && l.studentId === studentId && String(l.joinedAt || '').startsWith(todayPrefix)
    );
    let record: any;
    if (existingIdx >= 0) {
      logs[existingIdx].lastHeartbeatAt = nowIso;
      logs[existingIdx].durationMinutes = Math.max(1, Number(logs[existingIdx].durationMinutes) || 1);
      record = logs[existingIdx];
    } else {
      record = {
        id: `latt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        slotId,
        slotTitle: slotTitle || 'حصة مباشرة',
        subject: subject || 'عام',
        grade: grade || '',
        platform: platform || 'in_app',
        studentId,
        studentCode: studentCode || '',
        studentName: studentName || 'طالب',
        joinedAt: nowIso,
        lastHeartbeatAt: nowIso,
        durationMinutes: 1,
        status: 'present',
      };
      logs.unshift(record);
    }
    await repo.setSystemSetting('alsharif_live_attendance_v1', JSON.stringify(logs.slice(0, 600)));
    res.json({ ok: true, log: record });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/live-attendance/heartbeat', async (req, res) => {
  try {
    const { logId, addMinutes = 1 } = req.body || {};
    if (!logId) return res.status(400).json({ error: 'logId مطلوب' });
    const raw = await repo.getSystemSetting('alsharif_live_attendance_v1');
    const logs: any[] = raw ? JSON.parse(raw) : [];
    const idx = logs.findIndex((l) => l.id === logId);
    if (idx >= 0) {
      logs[idx].lastHeartbeatAt = new Date().toISOString();
      logs[idx].durationMinutes = (Number(logs[idx].durationMinutes) || 1) + Number(addMinutes || 1);
      await repo.setSystemSetting('alsharif_live_attendance_v1', JSON.stringify(logs));
      return res.json({ ok: true, log: logs[idx] });
    }
    res.status(404).json({ error: 'سجل الحضور غير موجود' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 8. REVENUE & TEACHER SPLIT ANALYTICS =================
app.get('/api/finance/revenue-analytics', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'التقارير المالية وتوزيع نسب المعلمين متاحة للإدارة والمعلمين فقط')) return;
  try {
    const [teachers, lessons, invoices, rawCards, rawRedemptions, rawSplits] = await Promise.all([
      repo.getAllTeachers(),
      repo.getAllLessons(),
      repo.getAllInvoices(),
      repo.getSystemSetting('alsharif_scratch_cards_v1'),
      repo.getSystemSetting('alsharif_student_redemptions_v1'),
      repo.getSystemSetting('alsharif_teacher_splits_v1'),
    ]);
    const cards: any[] = rawCards ? JSON.parse(rawCards) : [];
    const redemptions: any[] = rawRedemptions ? JSON.parse(rawRedemptions) : [];
    const splitsMap: Record<string, number> = rawSplits ? JSON.parse(rawSplits) : {};

    const cardByCode = new Map(cards.map((c) => [c.code, c]));
    let totalCodesRevenue = 0;
    const revenueBySubject: Record<string, { gross: number; count: number }> = {};

    for (const r of redemptions) {
      const card = cardByCode.get(r.code);
      const price = Number(card?.price) || 0;
      totalCodesRevenue += price;
      const subj = String(r.targetSubject || r.subject || card?.targetSubject || card?.subject || 'باقة شاملة').trim();
      if (!revenueBySubject[subj]) revenueBySubject[subj] = { gross: 0, count: 0 };
      revenueBySubject[subj].gross += price;
      revenueBySubject[subj].count += 1;
    }

    // Fallback to redeemed cards if redemptions list didn't capture price directly
    if (redemptions.length === 0) {
      for (const c of cards) {
        if (Number(c.usedCount) > 0 && Number(c.price) > 0) {
          const amt = Number(c.price) * Number(c.usedCount);
          totalCodesRevenue += amt;
          const subj = String(c.targetSubject || c.subject || 'باقة شاملة').trim();
          if (!revenueBySubject[subj]) revenueBySubject[subj] = { gross: 0, count: 0 };
          revenueBySubject[subj].gross += amt;
          revenueBySubject[subj].count += Number(c.usedCount);
        }
      }
    }

    const paidInvoices = invoices.filter((i: any) => i.status === 'paid');
    const pendingInvoices = invoices.filter((i: any) => i.status !== 'paid');
    const totalInvoicesPaidRevenue = paidInvoices.reduce((acc: number, i: any) => acc + (Number(i.amount) || 0), 0);
    const totalPendingInvoicesAmount = pendingInvoices.reduce((acc: number, i: any) => acc + (Number(i.amount) || 0), 0);

    // Distribute general/all-subject pool proportionally across active teachers + direct subject matches
    const poolGross = revenueBySubject['باقة شاملة']?.gross || 0;
    const poolCount = revenueBySubject['باقة شاملة']?.count || 0;
    const teacherCount = Math.max(1, teachers.length);

    const breakdown = teachers.map((t: any) => {
      const sharePercent = splitsMap[t.id] !== undefined ? Number(splitsMap[t.id]) : 70;
      const tLessons = lessons.filter((l: any) => l.teacherId === t.id || l.teacherName === t.name);
      const specData = revenueBySubject[t.specialty] || { gross: 0, count: 0 };
      // Attribute subject revenue + proportional share of platform-wide subscription pool
      const grossRevenue = Math.round(specData.gross + poolGross / teacherCount);
      const codesSoldCount = specData.count + Math.round(poolCount / teacherCount);
      const teacherShareAmount = Math.round((grossRevenue * sharePercent) / 100);
      const platformNetAmount = Math.max(0, grossRevenue - teacherShareAmount);
      return {
        teacherId: t.id,
        teacherName: t.name,
        specialty: t.specialty,
        sharePercent,
        grossRevenue,
        teacherShareAmount,
        platformNetAmount,
        codesSoldCount,
        lessonsCount: tLessons.length,
      };
    });

    const totalTeacherShares = breakdown.reduce((acc: number, b: any) => acc + b.teacherShareAmount, 0);
    const totalGrossRevenue = totalCodesRevenue + totalInvoicesPaidRevenue;
    const platformNetTotal = Math.max(0, totalGrossRevenue - totalTeacherShares);

    res.json({
      summary: {
        totalCodesRevenue,
        totalInvoicesPaidRevenue,
        totalGrossRevenue,
        totalTeacherShares,
        platformNetTotal,
        totalPendingInvoicesAmount,
        redeemedCodesCount: redemptions.length,
        paidInvoicesCount: paidInvoices.length,
      },
      breakdown,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/finance/teacher-splits', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'تعديل نسب توزيع المعلمين متاح للإدارة فقط')) return;
  try {
    const { teacherId, sharePercent } = req.body || {};
    if (!teacherId) return res.status(400).json({ error: 'teacherId مطلوب' });
    const raw = await repo.getSystemSetting('alsharif_teacher_splits_v1');
    const map: Record<string, number> = raw ? JSON.parse(raw) : {};
    map[teacherId] = Math.min(100, Math.max(0, Number(sharePercent) || 0));
    await repo.setSystemSetting('alsharif_teacher_splits_v1', JSON.stringify(map));
    await recordSensitiveAuditLog(req, {
      action: 'teacher_split_update',
      actionAr: 'تعديل نسبة أرباح معلم',
      entityType: 'finance',
      entityName: teacherId,
      details: `تم تحديث نسبة المعلم إلى ${map[teacherId]}%`,
      severity: 'warning',
    });
    res.json({ ok: true, splits: map });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 9. BOOKLETS & PRINTED NOTES STORE =================
app.get('/api/booklets/state', async (_req, res) => {
  try {
    const [rawCatalog, rawOrders] = await Promise.all([
      repo.getSystemSetting('alsharif_booklets_catalog_v1'),
      repo.getSystemSetting('alsharif_booklets_orders_v1'),
    ]);
    const catalog: any[] = rawCatalog ? JSON.parse(rawCatalog) : [];
    const orders: any[] = rawOrders ? JSON.parse(rawOrders) : [];
    res.json({
      catalog: Array.isArray(catalog) ? catalog : [],
      orders: Array.isArray(orders) ? orders : [],
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/booklets/catalog', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'إدارة متجر الملازم متاحة للإدارة والمعلمين فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_booklets_catalog_v1');
    const catalog: any[] = raw ? JSON.parse(raw) : [];
    const b = req.body || {};
    if (!String(b.title || '').trim()) {
      return res.status(400).json({ error: 'عنوان الملزمة أو الكتاب مطلوب' });
    }
    const item = {
      id: b.id || `bkl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title: String(b.title).trim(),
      subject: String(b.subject || 'الرياضيات').trim(),
      grade: String(b.grade || 'الصف الثالث الثانوي').trim(),
      teacherName: String(b.teacherName || '').trim(),
      pagesCount: Math.max(1, Number(b.pagesCount) || 80),
      price: Math.max(0, Number(b.price) || 0),
      currency: String(b.currency || 'ج.م'),
      stockCount: Math.max(0, Number(b.stockCount) || 50),
      description: String(b.description || '').trim(),
      coverUrl: b.coverUrl || '',
      isAvailable: b.isAvailable !== false,
      createdAt: b.createdAt || new Date().toISOString().split('T')[0],
    };
    const next = [item, ...catalog.filter((c) => c.id !== item.id)];
    await repo.setSystemSetting('alsharif_booklets_catalog_v1', JSON.stringify(next));
    broadcastAll({ type: 'booklets:updated' });
    res.status(201).json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/booklets/catalog/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'حذف الملازم متاح للإدارة فقط')) return;
  try {
    const raw = await repo.getSystemSetting('alsharif_booklets_catalog_v1');
    const catalog: any[] = raw ? JSON.parse(raw) : [];
    const next = catalog.filter((c) => c.id !== req.params.id);
    await repo.setSystemSetting('alsharif_booklets_catalog_v1', JSON.stringify(next));
    broadcastAll({ type: 'booklets:updated' });
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/booklets/orders', async (req, res) => {
  try {
    const [rawCatalog, rawOrders] = await Promise.all([
      repo.getSystemSetting('alsharif_booklets_catalog_v1'),
      repo.getSystemSetting('alsharif_booklets_orders_v1'),
    ]);
    const catalog: any[] = rawCatalog ? JSON.parse(rawCatalog) : [];
    const orders: any[] = rawOrders ? JSON.parse(rawOrders) : [];
    const b = req.body || {};
    const booklet = catalog.find((c) => c.id === b.bookletId);
    if (!booklet) return res.status(404).json({ error: 'الملزمة المختارة غير موجودة' });

    const qty = Math.max(1, Number(b.quantity) || 1);
    const unitPrice = Number(booklet.price) || 0;
    const nowIso = new Date().toISOString();
    const order = {
      id: `ord-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      orderNumber: `BK-${Math.floor(10000 + Math.random() * 90000)}`,
      bookletId: booklet.id,
      bookletTitle: booklet.title,
      subject: booklet.subject,
      grade: booklet.grade,
      quantity: qty,
      unitPrice,
      totalPrice: qty * unitPrice,
      currency: booklet.currency || 'ج.م',
      studentId: String(b.studentId || 'guest'),
      studentName: String(b.studentName || 'طالب').trim(),
      studentPhone: String(b.studentPhone || '').trim(),
      deliveryMethod: b.deliveryMethod === 'shipping' ? 'shipping' : 'pickup_center',
      shippingAddress: String(b.shippingAddress || '').trim(),
      notes: String(b.notes || '').trim(),
      paymentStatus: b.paymentStatus === 'paid' ? 'paid' : 'unpaid',
      status: 'pending',
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const nextCatalog = catalog.map((c) =>
      c.id === booklet.id ? { ...c, stockCount: Math.max(0, (Number(c.stockCount) || 0) - qty) } : c
    );
    const nextOrders = [order, ...orders];
    await Promise.all([
      repo.setSystemSetting('alsharif_booklets_catalog_v1', JSON.stringify(nextCatalog)),
      repo.setSystemSetting('alsharif_booklets_orders_v1', JSON.stringify(nextOrders)),
    ]);
    broadcastAll({ type: 'booklets:updated' });
    res.status(201).json(order);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/booklets/orders/:id', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'visitor'], 'تحديث حالة طلبات الملازم متاح للإدارة فقط')) return;
  try {
    const rawOrders = await repo.getSystemSetting('alsharif_booklets_orders_v1');
    const orders: any[] = rawOrders ? JSON.parse(rawOrders) : [];
    const idx = orders.findIndex((o) => o.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'الطلب غير موجود' });
    const { status, paymentStatus } = req.body || {};
    if (status) orders[idx].status = status;
    if (paymentStatus) orders[idx].paymentStatus = paymentStatus;
    orders[idx].updatedAt = new Date().toISOString();
    await repo.setSystemSetting('alsharif_booklets_orders_v1', JSON.stringify(orders));
    broadcastAll({ type: 'booklets:updated' });
    res.json(orders[idx]);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ================= 10. TARGETED BROADCAST CAMPAIGNS =================
app.get('/api/notifications/targeted-meta', async (_req, res) => {
  try {
    const raw = await repo.getSystemSetting('alsharif_notification_targets_v1');
    const meta = raw ? JSON.parse(raw) : {};
    res.json({ meta: meta && typeof meta === 'object' ? meta : {} });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/notifications/targeted-campaign', async (req, res) => {
  if (rejectIfRole(req, res, ['student', 'female_student', 'parent', 'teacher', 'visitor'], 'إرسال الحملات المستهدفة متاح للإدارة فقط')) return;
  try {
    const {
      title,
      message,
      target = 'students_parents',
      category = 'general',
      targetGrade = 'all',
      targetSubject = 'all',
      targetEnrollmentType = 'all',
      targetCondition = 'all',
    } = req.body || {};

    if (!String(title || '').trim() || !String(message || '').trim()) {
      return res.status(400).json({ error: 'عنوان الحملة ونص التنبيه مطلوبان' });
    }

    const [students, rawRedemptions, rawMeta] = await Promise.all([
      repo.getAllStudents(),
      repo.getSystemSetting('alsharif_student_redemptions_v1'),
      repo.getSystemSetting('alsharif_notification_targets_v1'),
    ]);
    const redemptions: any[] = rawRedemptions ? JSON.parse(rawRedemptions) : [];
    const metaMap: Record<string, any> = rawMeta ? JSON.parse(rawMeta) : {};

    const nowMs = Date.now();
    const expiringStudentIds = new Set(
      redemptions
        .filter((r) => {
          if (!r.expiresAt) return false;
          const diffDays = (new Date(r.expiresAt).getTime() - nowMs) / 86400000;
          return diffDays >= 0 && diffDays <= 5;
        })
        .map((r) => r.studentId)
    );

    const matchedStudents = students.filter((s: any) => {
      if (targetGrade && targetGrade !== 'all' && s.grade !== targetGrade) return false;
      if (targetEnrollmentType && targetEnrollmentType !== 'all' && s.type !== targetEnrollmentType) return false;
      if (targetCondition === 'expiring_codes' && !expiringStudentIds.has(s.id)) return false;
      if (targetCondition === 'at_risk' && s.status !== 'weak' && (Number(s.attendanceRate) || 100) >= 75) return false;
      return true;
    });

    const notif = await repo.createNotification({
      title: String(title).trim(),
      message: String(message).trim(),
      target,
      category,
      relatedType: 'general',
      relatedId: `campaign-${Date.now()}`,
    });

    metaMap[notif.id] = {
      targetGrade,
      targetSubject,
      targetEnrollmentType,
      targetCondition,
      recipientsCount: matchedStudents.length,
    };

    await repo.setSystemSetting('alsharif_notification_targets_v1', JSON.stringify(metaMap));
    const enriched = { ...notif, ...metaMap[notif.id] };

    broadcastAll({ type: 'notification:created', notification: enriched });
    dispatchWebPushNotification({
      title: notif.title,
      body: notif.message,
      target: notif.target,
      url: '/',
      tag: `campaign-${notif.id}`,
    });

    res.status(201).json({ ok: true, notification: enriched, matchedCount: matchedStudents.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Mount Live Classroom REST API & Structured Curriculum Path API
app.use('/api/classroom', classroomRouter);
app.use('/api/curriculum-path', curriculumRouter);

// Mount Vite or serve static files
async function startServer() {
  await initClassroomSocketGateway(server);

  if (!isProd) {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: isHmrDisabled ? false : true,
        watch: isHmrDisabled ? null : {},
        ws: { server, path: '/__vite_hmr' },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = 3000;
  server.listen(PORT, '0.0.0.0', async () => {
    console.log(`\n🚀 [Nawabegh Academy] Real-time Full-Stack Server active on http://0.0.0.0:${PORT}`);
    console.log(`⚡ WebSocket synchronization service mounted at ws://0.0.0.0:${PORT}/ws\n`);
    // Seed initial database records if empty
    try {
      await repo.seedInitialDataIfEmpty();
    } catch (e) {
      console.error('Initial DB seed warning:', e);
    }
  });
}

startServer();
