export function stripHtmlTags(html?: string | null): string {
  if (!html) return '';
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<\/(p|div|li|h[1-6]|tr|blockquote)>/gi, ' ')
    .replace(/<br\s*\/?>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

export function hasHtmlMarkup(value?: string | null): boolean {
  return /<[a-z][\s\S]*>/i.test(value || '');
}

export function hasMeaningfulHtmlContent(value?: string | null): boolean {
  if (!value) return false;
  if (stripHtmlTags(value).length > 0) return true;
  return /<(table|img|hr|iframe|video)/i.test(value);
}

export function buildLessonObjectivesTemplateHtml(
  lessonTitle: string,
  subject: string,
  grade: string,
  isAr: boolean
): string {
  const safeTitle = (lessonTitle || (isAr ? 'الدرس التعليمي' : 'Lesson')).trim();
  if (!isAr) {
    return `<div style="background-color:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:12px 16px;margin-bottom:12px;"><h3 style="margin:0 0 6px;color:#065f46;">📌 Lesson Summary — ${safeTitle}</h3><p style="margin:0;color:#1e293b;">Brief overview of core concepts covered in <strong>${subject}</strong> (${grade}).</p></div><h4 style="color:#0c3d36;margin:10px 0 6px;">🎯 Learning Objectives</h4><ul><li>Define the key terms and foundational concepts of the lesson.</li><li>Apply the main rules and formulas to solve guided exercises.</li><li>Analyze practical examples and avoid common mistakes.</li></ul><p><br/></p>`;
  }
  return `<div style="background-color:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:12px 16px;margin-bottom:12px;"><h3 style="margin:0 0 6px;color:#065f46;">📌 ملخص الدرس — ${safeTitle}</h3><p style="margin:0;color:#1e293b;">يتناول هذا الدرس المفاهيم الأساسية والتطبيقات العملية في مادة <strong>${subject}</strong> (${grade}) بأسلوب مبسط ومتدرج.</p></div><h4 style="color:#0c3d36;margin:10px 0 6px;">🎯 الأهداف التعليمية للدرس (بنهاية الدرس يكون الطالب قادراً على أن):</h4><ul><li>يتعرف على المفاهيم والمصطلحات الأساسية الواردة في الدرس بدقة.</li><li>يطبّق القواعد والخطوات العملية لحل التدريبات والنماذج التطبيقية.</li><li>يستنتج العلاقات ويربط بين الجانب النظري والتطبيق العملي.</li></ul><p><br/></p>`;
}
