/**
 * Eye-friendly color theme helpers to visually separate multiple-choice Questions
 * from their Answer Options using gentle, low-glare pastel surfaces in Light & Dark mode.
 */

export const MCQ_QUESTION_BOX_CLASS =
  'rounded-2xl p-4 sm:p-5 bg-[#eef6f3] dark:bg-[#0d2622] border border-[#b7ddd0] dark:border-emerald-800/70 text-slate-900 dark:text-slate-100 shadow-2xs';

const OPTION_PALETTES = [
  // Option A: Soft Sky
  'bg-[#eff6ff] border-[#bfdbfe] text-slate-800 hover:bg-[#e1effe] hover:border-sky-400 dark:bg-sky-950/35 dark:border-sky-800/70 dark:text-sky-100 dark:hover:bg-sky-900/45',
  // Option B: Soft Warm Cream
  'bg-[#fef9ee] border-[#fde6b8] text-slate-800 hover:bg-[#fdf1d6] hover:border-amber-400 dark:bg-amber-950/30 dark:border-amber-800/60 dark:text-amber-100 dark:hover:bg-amber-900/40',
  // Option C: Soft Lavender
  'bg-[#f4f3ff] border-[#ddd6fe] text-slate-800 hover:bg-[#eae6ff] hover:border-violet-400 dark:bg-violet-950/35 dark:border-violet-800/70 dark:text-violet-100 dark:hover:bg-violet-900/45',
  // Option D: Soft Warm Blush
  'bg-[#fdf2f4] border-[#fbcfe8] text-slate-800 hover:bg-[#fae4ea] hover:border-rose-400 dark:bg-rose-950/30 dark:border-rose-800/60 dark:text-rose-100 dark:hover:bg-rose-900/40',
];

export function getMcqOptionSurfaceClass(
  optionIndex: number,
  state?: {
    isSelected?: boolean;
    isChecked?: boolean;
    isCorrect?: boolean;
    dimUnselectedWhenChecked?: boolean;
  }
): string {
  const { isSelected, isChecked, isCorrect, dimUnselectedWhenChecked } = state || {};

  if (isChecked) {
    if (isCorrect) {
      return 'border-emerald-600 bg-emerald-100/90 dark:bg-emerald-950/75 text-emerald-950 dark:text-emerald-100 ring-2 ring-emerald-500/35 font-bold';
    }
    if (isSelected && !isCorrect) {
      return 'border-rose-500 bg-rose-100/90 dark:bg-rose-950/75 text-rose-950 dark:text-rose-100 ring-2 ring-rose-400/30';
    }
    if (dimUnselectedWhenChecked) {
      return `${OPTION_PALETTES[optionIndex % OPTION_PALETTES.length]} opacity-70`;
    }
  }

  if (isSelected) {
    return 'border-sky-600 bg-sky-100/90 dark:bg-sky-900/60 text-sky-950 dark:text-white ring-2 ring-sky-500/35 shadow-xs';
  }

  return OPTION_PALETTES[optionIndex % OPTION_PALETTES.length];
}
