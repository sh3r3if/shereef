import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  Building2,
  CheckCircle2,
  CreditCard,
  PackageCheck,
  Plus,
  Search,
  ShoppingBag,
  Trash2,
  Truck,
  X,
} from 'lucide-react';
import {
  BookletCatalogItem,
  BookletDeliveryMethod,
  BookletOrder,
  BookletOrderStatus,
  CurrentUser,
  Language,
  Teacher,
} from '../types';
import { getAuthHeaders, isAdminStaffRole, isTeacherRole } from '../utils/rbac';

interface BookletsStoreHubProps {
  currentUser: CurrentUser | null;
  teachers: Teacher[];
  language: Language;
}

const SUBJECTS = [
  'الرياضيات',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'اللغة العربية',
  'اللغة الإنجليزية',
  'الحاسب الآلي',
  'المراجعة النهائية',
];

const GRADES = [
  'الصف الثالث الثانوي',
  'الصف الثاني الثانوي',
  'الصف الأول الثانوي',
  'الصف الثالث المتوسط',
  'الصف الثاني المتوسط',
  'الصف الأول المتوسط',
];

const STATUS_META: Record<BookletOrderStatus, { ar: string; en: string; cls: string }> = {
  pending: { ar: 'قيد المراجعة', en: 'Pending', cls: 'bg-amber-50 text-amber-800 border-amber-200' },
  preparing: { ar: 'جاري التجهيز والطباعة', en: 'Preparing', cls: 'bg-sky-50 text-sky-800 border-sky-200' },
  ready_pickup: { ar: 'جاهزة للاستلام بالسنتر', en: 'Ready for Pickup', cls: 'bg-indigo-50 text-indigo-800 border-indigo-200' },
  shipped: { ar: 'تم الشحن مع المندوب', en: 'Shipped', cls: 'bg-purple-50 text-purple-800 border-purple-200' },
  delivered: { ar: 'تم التسليم بنجاح', en: 'Delivered', cls: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
  cancelled: { ar: 'ملغي', en: 'Cancelled', cls: 'bg-rose-50 text-rose-800 border-rose-200' },
};

export const BookletsStoreHub: React.FC<BookletsStoreHubProps> = ({
  currentUser,
  teachers,
  language,
}) => {
  const isAr = language === 'ar';
  const canManage =
    Boolean(currentUser?.isSuperAdmin) ||
    isAdminStaffRole(currentUser?.role) ||
    isTeacherRole(currentUser?.role);

  const [tab, setTab] = useState<'catalog' | 'orders'>('catalog');
  const [catalog, setCatalog] = useState<BookletCatalogItem[]>([]);
  const [orders, setOrders] = useState<BookletOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('all');

  // Add Booklet Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [bTitle, setBTitle] = useState('');
  const [bSubject, setBSubject] = useState(SUBJECTS[0]);
  const [bGrade, setBGrade] = useState(GRADES[0]);
  const [bTeacherName, setBTeacherName] = useState(currentUser?.name || '');
  const [bPages, setBPages] = useState(120);
  const [bPrice, setBPrice] = useState(65);
  const [bStock, setBStock] = useState(100);
  const [bDesc, setBDesc] = useState('');

  // Order Booklet Modal
  const [orderingItem, setOrderingItem] = useState<BookletCatalogItem | null>(null);
  const [oQty, setOQty] = useState(1);
  const [oDelivery, setODelivery] = useState<BookletDeliveryMethod>('pickup_center');
  const [oAddress, setOAddress] = useState('');
  const [oPhone, setOPhone] = useState(currentUser?.phone || '');
  const [oNotes, setONotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const showMsg = (type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 4500);
  };

  const fetchState = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/booklets/state');
      const data = await res.json();
      setCatalog(Array.isArray(data.catalog) ? data.catalog : []);
      setOrders(Array.isArray(data.orders) ? data.orders : []);
    } catch {
      setCatalog([]);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchState();
  }, []);

  const filteredCatalog = useMemo(() => {
    const q = search.trim().toLowerCase();
    return catalog.filter((c) => {
      if (subjectFilter !== 'all' && c.subject !== subjectFilter) return false;
      if (q) {
        const hay = `${c.title} ${c.subject} ${c.grade} ${c.teacherName || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [catalog, search, subjectFilter]);

  const visibleOrders = useMemo(() => {
    if (canManage) return orders;
    const uid = currentUser?.studentId || currentUser?.id;
    return orders.filter(
      (o) => (uid && o.studentId === uid) || (currentUser?.name && o.studentName === currentUser.name)
    );
  }, [orders, canManage, currentUser]);

  const handleAddBooklet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bTitle.trim()) return;
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/booklets/catalog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          title: bTitle.trim(),
          subject: bSubject,
          grade: bGrade,
          teacherName: bTeacherName.trim(),
          pagesCount: bPages,
          price: bPrice,
          stockCount: bStock,
          description: bDesc.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر الإضافة');
      setCatalog((prev) => [data, ...prev]);
      setIsAddOpen(false);
      setBTitle('');
      setBDesc('');
      showMsg('success', isAr ? 'تمت إضافة الملزمة للمتجر بنجاح' : 'Booklet added');
    } catch (err: any) {
      showMsg('error', err.message || 'تعذر الحفظ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteBooklet = async (id: string) => {
    try {
      const res = await fetch(`/api/booklets/catalog/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setCatalog((prev) => prev.filter((c) => c.id !== id));
        showMsg('success', isAr ? 'تم حذف الملزمة من المتجر' : 'Deleted');
      }
    } catch {
      showMsg('error', 'تعذر الحذف');
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderingItem) return;
    if (oDelivery === 'shipping' && !oAddress.trim()) {
      showMsg('error', isAr ? 'يرجى كتابة عنوان الشحن بالتفصيل' : 'Shipping address required');
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/booklets/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          bookletId: orderingItem.id,
          quantity: oQty,
          studentId: currentUser?.studentId || currentUser?.id || 'guest',
          studentName: currentUser?.name || 'طالب',
          studentPhone: oPhone.trim(),
          deliveryMethod: oDelivery,
          shippingAddress: oAddress.trim(),
          notes: oNotes.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تسجيل الطلب');
      setOrders((prev) => [data, ...prev]);
      setCatalog((prev) =>
        prev.map((c) =>
          c.id === orderingItem.id ? { ...c, stockCount: Math.max(0, c.stockCount - oQty) } : c
        )
      );
      setOrderingItem(null);
      setTab('orders');
      showMsg('success', isAr ? `تم تأكيد طلبك رقم ${data.orderNumber} بنجاح` : 'Order placed');
    } catch (err: any) {
      showMsg('error', err.message || 'تعذر إرسال الطلب');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateOrder = async (
    orderId: string,
    patch: { status?: BookletOrderStatus; paymentStatus?: 'paid' | 'unpaid' }
  ) => {
    try {
      const res = await fetch(`/api/booklets/orders/${encodeURIComponent(orderId)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify(patch),
      });
      const updated = await res.json();
      if (res.ok) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? updated : o)));
        showMsg('success', isAr ? 'تم تحديث حالة الطلب' : 'Order updated');
      }
    } catch {
      showMsg('error', 'تعذر التحديث');
    }
  };

  return (
    <div className="space-y-6 font-tajawal animate-in fade-in duration-200">
      {toast && (
        <div
          className={`fixed bottom-5 left-5 z-50 px-4 py-3 rounded-2xl shadow-xl border text-xs font-cairo font-bold flex items-center gap-2 ${
            toast.type === 'success'
              ? 'bg-emerald-900 text-white border-emerald-500'
              : 'bg-rose-900 text-white border-rose-500'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{toast.text}</span>
        </div>
      )}

      {/* Header */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-xl font-black font-cairo text-slate-900 dark:text-white flex items-center gap-2.5">
            <ShoppingBag className="w-6 h-6 text-emerald-600" />
            <span>{isAr ? 'متجر الملازم والمذكرات والكتب المطبوعة' : 'Printed Booklets & Notes Store'}</span>
          </h2>
          <p className="text-xs text-slate-500">
            {isAr
              ? 'احجز المذكرات والكتب الورقية لكل مادة مع خيار الاستلام المباشر من السنتر أو الشحن المنزلي وتتبع حالة الدفع والتسليم.'
              : 'Order printed booklets and books for center pickup or home shipping with live tracking.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setTab('catalog')}
            className={`px-4 py-2 rounded-xl text-xs font-cairo font-bold cursor-pointer transition-colors ${
              tab === 'catalog'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {isAr ? `كتالوج الملازم (${catalog.length})` : `Catalog (${catalog.length})`}
          </button>
          <button
            type="button"
            onClick={() => setTab('orders')}
            className={`px-4 py-2 rounded-xl text-xs font-cairo font-bold cursor-pointer transition-colors ${
              tab === 'orders'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {isAr ? `متابعة الطلبات (${visibleOrders.length})` : `Orders (${visibleOrders.length})`}
          </button>

          {canManage && (
            <button
              type="button"
              onClick={() => setIsAddOpen(true)}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة ملزمة / كتاب' : 'Add Booklet'}</span>
            </button>
          )}
        </div>
      </div>

      {tab === 'catalog' ? (
        <div className="space-y-4">
          {/* Filters */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="relative md:col-span-2">
              <Search className="w-4 h-4 text-slate-400 absolute top-2.5 right-3" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={isAr ? 'ابحث عن اسم الملزمة، المادة، أو المعلم...' : 'Search booklets...'}
                className="w-full pr-9 pl-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
              />
            </div>
            <select
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo"
            >
              <option value="all">{isAr ? 'كل المواد الدراسية' : 'All Subjects'}</option>
              {SUBJECTS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {loading ? (
            <div className="p-12 text-center text-xs text-slate-400">{isAr ? 'جاري التحميل...' : 'Loading...'}</div>
          ) : filteredCatalog.length === 0 ? (
            <div className="p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 space-y-2">
              <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-cairo font-bold text-slate-600 dark:text-slate-300">
                {isAr ? 'لا توجد ملازم مضافة حالياً' : 'No booklets listed yet'}
              </p>
              {canManage && (
                <p className="text-xs text-slate-400">
                  {isAr ? 'اضغط على "إضافة ملزمة / كتاب" لطرح المذكرات المطبوعة للطلاب.' : 'Add your first printed booklet.'}
                </p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCatalog.map((item) => (
                <div
                  key={item.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-400">
                          {item.subject} · {item.grade}
                        </span>
                        <h3 className="text-base font-black font-cairo text-slate-900 dark:text-white mt-0.5">
                          {item.title}
                        </h3>
                      </div>
                      <span className="font-mono-numbers text-base font-black text-amber-600 shrink-0">
                        {item.price} {item.currency}
                      </span>
                    </div>

                    {item.description && (
                      <p className="text-xs text-slate-500 leading-relaxed">{item.description}</p>
                    )}

                    <div className="text-[11px] text-slate-500 font-mono-numbers flex flex-wrap gap-2 pt-1">
                      <span>{item.pagesCount} {isAr ? 'صفحة' : 'pages'}</span>
                      <span>·</span>
                      <span>{isAr ? `متوفر: ${item.stockCount} نسخة` : `Stock: ${item.stockCount}`}</span>
                      {item.teacherName && (
                        <>
                          <span>·</span>
                          <span className="font-cairo">{item.teacherName}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      disabled={item.stockCount <= 0}
                      onClick={() => {
                        setOrderingItem(item);
                        setOQty(1);
                        setODelivery('pickup_center');
                        setOAddress('');
                        setONotes('');
                      }}
                      className="flex-1 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>
                        {item.stockCount > 0
                          ? isAr ? 'اطلب المطبوعة الآن' : 'Order Now'
                          : isAr ? 'نفذت الكمية' : 'Out of Stock'}
                      </span>
                    </button>
                    {canManage && (
                      <button
                        type="button"
                        onClick={() => handleDeleteBooklet(item.id)}
                        className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 hover:bg-rose-100 cursor-pointer"
                        title={isAr ? 'حذف' : 'Delete'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Orders Tab */
        <div className="space-y-3">
          {visibleOrders.length === 0 ? (
            <div className="p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-400">
              {isAr ? 'لا توجد طلبات ملازم مسجلة حتى الآن.' : 'No orders yet.'}
            </div>
          ) : (
            visibleOrders.map((ord) => {
              const sMeta = STATUS_META[ord.status] || STATUS_META.pending;
              return (
                <div
                  key={ord.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono-numbers font-black text-xs text-slate-900 dark:text-white">
                        #{ord.orderNumber}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-lg border text-[11px] font-cairo font-bold ${sMeta.cls}`}>
                        {isAr ? sMeta.ar : sMeta.en}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-lg text-[11px] font-cairo font-bold ${
                          ord.paymentStatus === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {ord.paymentStatus === 'paid' ? (isAr ? 'مدفوع ✓' : 'Paid') : (isAr ? 'دفع عند الاستلام' : 'Unpaid')}
                      </span>
                    </div>

                    <p className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                      {ord.bookletTitle} × <span className="font-mono-numbers">{ord.quantity}</span> —{' '}
                      <span className="text-emerald-700 dark:text-emerald-400 font-mono-numbers">
                        {ord.totalPrice} {ord.currency}
                      </span>
                    </p>

                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                      <span>{ord.studentName}</span>
                      {ord.studentPhone && <span className="font-mono-numbers">· {ord.studentPhone}</span>}
                      <span>·</span>
                      <span className="inline-flex items-center gap-1">
                        {ord.deliveryMethod === 'shipping' ? (
                          <><Truck className="w-3.5 h-3.5 text-purple-600" /> {isAr ? `شحن: ${ord.shippingAddress}` : `Ship: ${ord.shippingAddress}`}</>
                        ) : (
                          <><Building2 className="w-3.5 h-3.5 text-indigo-600" /> {isAr ? 'استلام من السنتر' : 'Center Pickup'}</>
                        )}
                      </span>
                    </div>
                  </div>

                  {canManage && (
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <select
                        value={ord.status}
                        onChange={(e) => handleUpdateOrder(ord.id, { status: e.target.value as BookletOrderStatus })}
                        className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo cursor-pointer"
                      >
                        {(Object.keys(STATUS_META) as BookletOrderStatus[]).map((st) => (
                          <option key={st} value={st}>{isAr ? STATUS_META[st].ar : STATUS_META[st].en}</option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() =>
                          handleUpdateOrder(ord.id, {
                            paymentStatus: ord.paymentStatus === 'paid' ? 'unpaid' : 'paid',
                          })
                        }
                        className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold flex items-center gap-1 cursor-pointer ${
                          ord.paymentStatus === 'paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-500 text-slate-950'
                        }`}
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>{ord.paymentStatus === 'paid' ? (isAr ? 'تم التحصيل' : 'Paid') : (isAr ? 'تأكيد الدفع' : 'Mark Paid')}</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Add Booklet Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg p-5 space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-cairo font-bold text-base">{isAr ? 'إضافة ملزمة / كتاب للمتجر' : 'New Booklet'}</h4>
              <button onClick={() => setIsAddOpen(false)} className="cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <form onSubmit={handleAddBooklet} className="space-y-3 text-xs">
              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'عنوان الملزمة أو الكتاب' : 'Title'}</label>
                <input
                  required
                  type="text"
                  value={bTitle}
                  onChange={(e) => setBTitle(e.target.value)}
                  placeholder={isAr ? 'مثال: ملزمة التفاضل والتكامل الشاملة — الترم الأول' : 'Booklet title'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'المادة' : 'Subject'}</label>
                  <select value={bSubject} onChange={(e) => setBSubject(e.target.value)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'المرحلة' : 'Grade'}</label>
                  <select value={bGrade} onChange={(e) => setBGrade(e.target.value)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'السعر (ج.م)' : 'Price'}</label>
                  <input type="number" min={0} value={bPrice} onChange={(e) => setBPrice(Number(e.target.value) || 0)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers" />
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'عدد الصفحات' : 'Pages'}</label>
                  <input type="number" min={1} value={bPages} onChange={(e) => setBPages(Number(e.target.value) || 1)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers" />
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'الكمية المتاحة' : 'Stock'}</label>
                  <input type="number" min={0} value={bStock} onChange={(e) => setBStock(Number(e.target.value) || 0)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers" />
                </div>
              </div>
              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'اسم المعلم المؤلف' : 'Author Teacher'}</label>
                <input type="text" value={bTeacherName} onChange={(e) => setBTeacherName(e.target.value)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
              </div>
              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'محتويات الملزمة' : 'Description'}</label>
                <textarea rows={2} value={bDesc} onChange={(e) => setBDesc(e.target.value)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsAddOpen(false)} className="px-4 py-2 rounded-xl bg-slate-100 font-cairo font-bold cursor-pointer">{isAr ? 'إلغاء' : 'Cancel'}</button>
                <button type="submit" disabled={isSubmitting} className="px-5 py-2 rounded-xl bg-emerald-700 text-white font-cairo font-bold cursor-pointer">{isAr ? 'نشر في المتجر' : 'Publish'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Order Booklet Modal */}
      {orderingItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-cairo font-bold text-base flex items-center gap-2">
                <PackageCheck className="w-5 h-5 text-emerald-600" />
                <span>{isAr ? 'تأكيد حجز الملزمة المطبوعة' : 'Order Booklet'}</span>
              </h4>
              <button onClick={() => setOrderingItem(null)} className="cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <form onSubmit={handleSubmitOrder} className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70">
                <p className="font-cairo font-bold text-slate-900 dark:text-white">{orderingItem.title}</p>
                <p className="text-slate-500 mt-0.5 font-mono-numbers">
                  {orderingItem.price} {orderingItem.currency} × {oQty} = <strong>{orderingItem.price * oQty} {orderingItem.currency}</strong>
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'الكمية' : 'Quantity'}</label>
                  <input type="number" min={1} max={Math.max(1, orderingItem.stockCount)} value={oQty} onChange={(e) => setOQty(Math.max(1, Number(e.target.value) || 1))} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers" />
                </div>
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'رقم الهاتف للتواصل' : 'Phone'}</label>
                  <input required type="text" value={oPhone} onChange={(e) => setOPhone(e.target.value)} placeholder="01xxxxxxxxx" className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono-numbers" />
                </div>
              </div>
              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'طريقة الاستلام' : 'Delivery Method'}</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setODelivery('pickup_center')}
                    className={`p-2.5 rounded-xl border font-cairo font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                      oDelivery === 'pickup_center' ? 'bg-emerald-50 border-emerald-500 text-emerald-800' : 'border-slate-200'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>{isAr ? 'استلام من السنتر' : 'Center Pickup'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setODelivery('shipping')}
                    className={`p-2.5 rounded-xl border font-cairo font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                      oDelivery === 'shipping' ? 'bg-emerald-50 border-emerald-500 text-emerald-800' : 'border-slate-200'
                    }`}
                  >
                    <Truck className="w-4 h-4" />
                    <span>{isAr ? 'شحن للمنزل' : 'Home Shipping'}</span>
                  </button>
                </div>
              </div>
              {oDelivery === 'shipping' && (
                <div>
                  <label className="font-cairo font-bold block mb-1">{isAr ? 'العنوان بالتفصيل' : 'Shipping Address'}</label>
                  <textarea required rows={2} value={oAddress} onChange={(e) => setOAddress(e.target.value)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
              )}
              <div>
                <label className="font-cairo font-bold block mb-1">{isAr ? 'ملاحظات إضافية (اختياري)' : 'Notes'}</label>
                <input type="text" value={oNotes} onChange={(e) => setONotes(e.target.value)} className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setOrderingItem(null)} className="px-4 py-2 rounded-xl bg-slate-100 font-cairo font-bold cursor-pointer">{isAr ? 'إلغاء' : 'Cancel'}</button>
                <button type="submit" disabled={isSubmitting} className="px-5 py-2 rounded-xl bg-emerald-700 text-white font-cairo font-bold cursor-pointer">{isAr ? 'تأكيد الطلب' : 'Confirm Order'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
