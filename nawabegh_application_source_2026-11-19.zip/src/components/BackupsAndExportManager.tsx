import React, { useState, useEffect } from 'react';
import {
  Database,
  Archive,
  Download,
  HardDriveDownload,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  FileCode2,
  FolderArchive,
  Clock,
  Sparkles,
  Server,
  Layers,
  FileText,
  ShieldCheck,
} from 'lucide-react';
import { Language, CurrentUser } from '../types';

interface BackupItem {
  id: string;
  type: string;
  filename: string;
  size: string;
  recordCount?: number;
  notes?: string;
  createdAt?: string;
}

interface DbStatus {
  status: string;
  dialect: string;
  counts: {
    students: number;
    teachers: number;
    lessons: number;
    quizzes: number;
    users: number;
    backups: number;
  };
  timestamp: string;
}

interface Props {
  language: Language;
  currentUser: CurrentUser;
  onLogAction: (actionAr: string, type: string, name: string, details: string) => void;
}

export const BackupsAndExportManager: React.FC<Props> = ({
  language,
  currentUser,
  onLogAction,
}) => {
  const isAr = language === 'ar';
  const [dbStatus, setDbStatus] = useState<DbStatus | null>(null);
  const [backups, setBackups] = useState<BackupItem[]>([]);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);
  const [isCreatingDbBackup, setIsCreatingDbBackup] = useState(false);
  const [isCreatingAppBackup, setIsCreatingAppBackup] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Fetch status and backups
  const loadData = async () => {
    setIsLoadingStatus(true);
    try {
      const [statusRes, backupsRes] = await Promise.all([
        fetch('/api/db/status'),
        fetch('/api/backups'),
      ]);

      if (statusRes.ok) {
        const statusData = await statusRes.json();
        setDbStatus(statusData);
      }

      if (backupsRes.ok) {
        const backupsData = await backupsRes.json();
        setBackups(backupsData);
      }
    } catch (err) {
      console.error('Failed to load backup status:', err);
    } finally {
      setIsLoadingStatus(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Trigger Database Backup creation
  const handleCreateDatabaseBackup = async () => {
    setIsCreatingDbBackup(true);
    try {
      const res = await fetch('/api/backups/database', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.backup) {
          setBackups((prev) => [data.backup, ...prev]);
        }
        setSuccessToast(
          isAr
            ? `تم إنشاء وتوليد النسخة الاحتياطية لقاعدة البيانات بنجاح (${data.backup?.filename || 'SQL dump'})`
            : `Database backup generated successfully!`
        );
        onLogAction(
          'إنشاء نسخة احتياطية لقاعدة البيانات',
          'backup',
          data.backup?.filename || 'database_dump.sql',
          `تم تصدير وحفظ سجلات قاعدة بيانات Cloud SQL بنجاح بحجم ${data.backup?.size}`
        );
        setTimeout(() => setSuccessToast(null), 5000);
      }
    } catch (err) {
      console.error('Error creating db backup:', err);
    } finally {
      setIsCreatingDbBackup(false);
    }
  };

  // Trigger Application Backup creation
  const handleCreateApplicationBackup = async () => {
    setIsCreatingAppBackup(true);
    try {
      const res = await fetch('/api/backups/application', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.backup) {
          setBackups((prev) => [data.backup, ...prev]);
        }
        setSuccessToast(
          isAr
            ? `تم إنشاء أرشيف النسخة الاحتياطية للتطبيق بنجاح (${data.backup?.filename || 'App ZIP'})`
            : `Application archive generated successfully!`
        );
        onLogAction(
          'إنشاء نسخة احتياطية للتطبيق البرمجي',
          'backup',
          data.backup?.filename || 'app_source.zip',
          'تم ضغط وحفظ مصادر التطبيق وقواعد البيانات كملف ZIP متكامل'
        );
        setTimeout(() => setSuccessToast(null), 5000);
      }
    } catch (err) {
      console.error('Error creating app backup:', err);
    } finally {
      setIsCreatingAppBackup(false);
    }
  };

  // Direct download handler
  const handleDownloadFile = (url: string, filename: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
            <Server className="w-4 h-4" />
            <span>{isAr ? 'مركز إدارة قواعد البيانات والتصدير' : 'Database & System Backups'}</span>
          </div>
          <h2 className="text-2xl font-bold font-cairo text-white">
            {isAr
              ? 'إنشاء وتصدير النسخ الاحتياطية (قاعدة البيانات والتطبيق)'
              : 'Backup & Export Center (Database & Application)'}
          </h2>
          <p className="text-xs md:text-sm text-slate-300 max-w-2xl font-tajawal">
            {isAr
              ? 'تصدير كامل لقاعدة بيانات Cloud SQL بصيغة SQL القياسية، وإنشاء وتنزيل حزمة كود التطبيق البرمجي والمصادر بصيغة ZIP مضغوطة.'
              : 'Export complete Cloud SQL database dumps in standard SQL format, and generate full application source backups as ZIP packages.'}
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-2 shrink-0">
          <button
            onClick={loadData}
            disabled={isLoadingStatus}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer border border-white/10"
            title={isAr ? 'تحديث الحالة' : 'Refresh'}
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingStatus ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successToast && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200 text-xs md:text-sm font-cairo font-bold shadow-xs animate-in fade-in duration-300">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Database Real-Time Diagnostics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-tajawal">{isAr ? 'حالة السيرفر' : 'DB Engine'}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="font-cairo font-bold text-sm text-slate-900 dark:text-white truncate">
            {dbStatus ? 'Cloud SQL' : 'جاري الفحص...'}
          </p>
          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-mono-numbers bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
            ONLINE 🟢
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-tajawal">{isAr ? 'الطلاب المسجلين' : 'Students'}</span>
          <p className="font-mono-numbers font-bold text-xl text-slate-900 dark:text-white">
            {dbStatus?.counts.students ?? 0}
          </p>
          <span className="text-[10px] text-slate-400 font-tajawal">{isAr ? 'سجل طالب نشط' : 'active records'}</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-tajawal">{isAr ? 'المعلمين' : 'Teachers'}</span>
          <p className="font-mono-numbers font-bold text-xl text-slate-900 dark:text-white">
            {dbStatus?.counts.teachers ?? 0}
          </p>
          <span className="text-[10px] text-slate-400 font-tajawal">{isAr ? 'ملف معلم' : 'teachers'}</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-tajawal">{isAr ? 'الدروس والملفات' : 'Lessons'}</span>
          <p className="font-mono-numbers font-bold text-xl text-slate-900 dark:text-white">
            {dbStatus?.counts.lessons ?? 0}
          </p>
          <span className="text-[10px] text-slate-400 font-tajawal">{isAr ? 'محاضرة ومذكرة' : 'materials'}</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-tajawal">{isAr ? 'الاختبارات' : 'Quizzes'}</span>
          <p className="font-mono-numbers font-bold text-xl text-slate-900 dark:text-white">
            {dbStatus?.counts.quizzes ?? 0}
          </p>
          <span className="text-[10px] text-slate-400 font-tajawal">{isAr ? 'بنك اختبارات' : 'quizzes'}</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-tajawal">{isAr ? 'الأعضاء والمشرفين' : 'Members'}</span>
          <p className="font-mono-numbers font-bold text-xl text-slate-900 dark:text-white">
            {dbStatus?.counts.users ?? 0}
          </p>
          <span className="text-[10px] text-slate-400 font-tajawal">{isAr ? 'حساب بصلاحيات' : 'accounts'}</span>
        </div>
      </div>

      {/* Main Backup Action Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* PANEL 1: DATABASE BACKUP & SQL EXPORT */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 flex items-center justify-center shadow-xs">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg text-slate-900 dark:text-white">
                {isAr ? 'تصدير قاعدة بيانات SQL (.sql)' : 'Export Database SQL (.sql)'}
              </h3>
              <p className="text-xs md:text-sm text-slate-500 font-tajawal mt-1">
                {isAr
                  ? 'توليد ملف تفريغ SQL متكامل يحتوي على إنشاء كافة الجداول (DDL) وجميع البيانات المسجلة (INSERT INTO) للطلاب والمعلمين والدروس لسهولة استعادتها على أي سيرفر MySQL / PostgreSQL.'
                  : 'Generate a complete SQL dump with full schema and INSERT statements ready for migration or offline archiving.'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 font-tajawal">
              <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>{isAr ? 'الصيغة القياسية:' : 'Format:'}</span>
                <span className="font-mono font-bold text-blue-600 dark:text-blue-400">Standard SQL (.sql)</span>
              </div>
              <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>{isAr ? 'محتويات التصدير:' : 'Contents:'}</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {isAr ? 'كافة الجداول + القيود + السجلات' : 'All Tables & Records'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row flex-wrap gap-2 pt-2">
            <button
              onClick={handleCreateDatabaseBackup}
              disabled={isCreatingDbBackup}
              className="flex-1 min-w-[160px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-cairo font-bold text-xs md:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <HardDriveDownload className={`w-4 h-4 ${isCreatingDbBackup ? 'animate-spin' : ''}`} />
              <span>{isAr ? 'إنشاء نسخة احتياطية' : 'Create DB Backup'}</span>
            </button>

            <a
              href="/api/backups/export/database?dialect=postgresql"
              download="nawabegh_database_postgresql.sql"
              className="px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-cairo font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-slate-300 dark:border-slate-600"
            >
              <Download className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>{isAr ? 'تصدير PostgreSQL .sql' : 'PostgreSQL .sql'}</span>
            </a>

            <a
              href="/api/backups/export/database?dialect=mysql"
              download="nawabegh_database_mysql.sql"
              className="px-3.5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/50 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-200 font-cairo font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-amber-300 dark:border-amber-700"
            >
              <Download className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>{isAr ? 'تصدير MySQL .sql' : 'MySQL .sql'}</span>
            </a>
          </div>
        </div>

        {/* PANEL 2: APPLICATION BACKUP & ZIP EXPORT */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 flex items-center justify-center shadow-xs">
              <FolderArchive className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg text-slate-900 dark:text-white">
                {isAr ? 'تصدير سورس كود التطبيق (.zip)' : 'Export Application Code (.zip)'}
              </h3>
              <p className="text-xs md:text-sm text-slate-500 font-tajawal mt-1">
                {isAr
                  ? 'حفظ وتصدير ملفات التطبيق البرمجي بالكامل (مجلد src، المكونات، خادم Express اللحظي، إعدادات Tailwind، وبنية قواعد البيانات) كحزمة ZIP مضغوطة جاهزة للنشر أو التشغيل المحلي.'
                  : 'Download complete application sources, backend Express server, React components, and schema configurations in a portable ZIP archive.'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 font-tajawal">
              <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>{isAr ? 'نوع الحزمة:' : 'Package Type:'}</span>
                <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">Full Archive (.zip)</span>
              </div>
              <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                <span>{isAr ? 'البيئة البرمجية:' : 'Stack:'}</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">React + Vite + Express + SQL</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <button
              onClick={handleCreateApplicationBackup}
              disabled={isCreatingAppBackup}
              className="flex-1 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-cairo font-bold text-xs md:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Archive className={`w-4 h-4 ${isCreatingAppBackup ? 'animate-spin' : ''}`} />
              <span>{isAr ? 'إنشاء نسخة للابليكيشن' : 'Create App Backup'}</span>
            </button>

            <a
              href="/api/backups/export/application"
              download="nawabegh_application_archive.zip"
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-cairo font-bold text-xs md:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-300 dark:border-slate-600"
            >
              <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{isAr ? 'تنزيل أرشيف .zip فوراً' : 'Download .zip File'}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Backups History Table */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden space-y-2 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <h3 className="font-cairo font-bold text-sm md:text-base text-slate-900 dark:text-white">
              {isAr ? 'سجل النسخ الاحتياطية المسجلة في السيرفر' : 'Saved Backups History'}
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono-numbers">
            {backups.length} {isAr ? 'نسخة مسجلة' : 'backups'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs md:text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-cairo font-bold">
              <tr>
                <th className="py-3 px-4">{isAr ? 'اسم الملف / الحزمة' : 'Filename'}</th>
                <th className="py-3 px-4">{isAr ? 'النوع' : 'Type'}</th>
                <th className="py-3 px-4">{isAr ? 'الحجم' : 'Size'}</th>
                <th className="py-3 px-4">{isAr ? 'السجلات المشمولة' : 'Records'}</th>
                <th className="py-3 px-4">{isAr ? 'تاريخ الإنشاء' : 'Created Date'}</th>
                <th className="py-3 px-4 text-center">{isAr ? 'تنزيل' : 'Download'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-tajawal">
              {backups.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500 font-tajawal">
                    {isAr
                      ? 'لا توجد نسخ احتياطية مسجلة بعد. استخدم الأزرار أعلاه لتوليد أول نسخة احتياطية لقاعدة البيانات أو التطبيق.'
                      : 'No backups recorded yet. Use the action buttons above to create one.'}
                  </td>
                </tr>
              ) : (
                backups.map((bk) => (
                  <tr key={bk.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        {bk.type === 'database' ? (
                          <FileCode2 className="w-4 h-4 text-blue-600 shrink-0" />
                        ) : (
                          <FolderArchive className="w-4 h-4 text-emerald-600 shrink-0" />
                        )}
                        <span className="font-mono text-slate-800 dark:text-slate-200 font-semibold truncate max-w-xs">
                          {bk.filename}
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          bk.type === 'database'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                            : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}
                      >
                        {bk.type === 'database'
                          ? isAr
                            ? 'قاعدة بيانات SQL'
                            : 'Database SQL'
                          : isAr
                          ? 'حزمة التطبيق ZIP'
                          : 'Application ZIP'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono-numbers text-slate-600 dark:text-slate-300">
                      {bk.size}
                    </td>
                    <td className="py-3.5 px-4 font-mono-numbers text-slate-600 dark:text-slate-300">
                      {bk.recordCount ? `${bk.recordCount} عنصر` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 text-xs font-mono-numbers">
                      {bk.createdAt
                        ? new Date(bk.createdAt).toLocaleString(isAr ? 'ar-SA' : 'en-US')
                        : isAr
                        ? 'الآن'
                        : 'Just now'}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() =>
                          handleDownloadFile(
                            bk.type === 'database'
                              ? '/api/backups/export/database'
                              : '/api/backups/export/application',
                            bk.filename
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
                        title={isAr ? 'تنزيل النسخة' : 'Download'}
                      >
                        <Download className="w-3.5 h-3.5 text-slate-500" />
                        <span>{isAr ? 'تحميل' : 'Download'}</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
