import React, { useState, useMemo, useEffect } from 'react';
import {
  GraduationCap,
  Plus,
  Search,
  Trash2,
  Edit,
  Eye,
  Wifi,
  Building2,
  AlertCircle,
  Award,
  Phone,
  Mail,
  X,
  ChevronLeft,
  ChevronRight,
  Zap,
  CheckCircle2,
  RefreshCw,
  Database,
  AlertTriangle,
  Download,
  Check,
  MapPin,
  Calendar,
  Upload,
  Camera,
  QrCode,
} from 'lucide-react';
import QRCode from 'qrcode';
import { Student, EnrollmentType, Language, CurrentUser } from '../types';
import { realtimeSync } from '../services/realtimeSync';
import { getAuthHeaders } from '../utils/rbac';
import {
  buildAutoStudentAvatarDataUrl,
  getStudentAvatarUrl,
  handleStudentAvatarError,
  readAndResizeImageFile,
} from '../utils/avatarFallback';

interface StudentsManagerProps {
  students: Student[];
  currentUser?: CurrentUser | null;
  onAddStudent: (student: Student | Omit<Student, 'id' | 'registeredDate'>) => void;
  onUpdateStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  language: Language;
}

const AVAILABLE_GRADES = [
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
  'الشهادة الإعدادية',
];

export const StudentsManager: React.FC<StudentsManagerProps> = ({
  students: propStudents,
  currentUser = null,
  onAddStudent,
  onUpdateStudent,
  onDeleteStudent,
  language,
}) => {
  const isAr = language === 'ar';

  // Local state synchronized strictly with Cloud SQL
  const [studentsList, setStudentsList] = useState<Student[]>(propStudents);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<{
    text: string;
    type: 'success' | 'info' | 'error';
  } | null>(null);

  useEffect(() => {
    setStudentsList(propStudents);
  }, [propStudents]);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Search, Filters, Pagination
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | EnrollmentType>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'top' | 'regular' | 'weak'>('all');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(6);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);
  const [qrModalStudent, setQrModalStudent] = useState<Student | null>(null);
  const [qrModalDataUrl, setQrModalDataUrl] = useState<string>('');

  // Form State (Strictly the requested registration fields)
  const [formCode, setFormCode] = useState('');
  const [formName, setFormName] = useState('');
  const [formGrade, setFormGrade] = useState('الصف الثالث الثانوي');
  const [formType, setFormType] = useState<EnrollmentType>('online');
  const [formStudentPhone, setFormStudentPhone] = useState('');
  const [formParentName, setFormParentName] = useState('');
  const [formParentPhone, setFormParentPhone] = useState('');
  const [formBookletName, setFormBookletName] = useState('عملي');
  const [formBookletStatus, setFormBookletStatus] = useState('مستلم');
  const [formBookletBookingDate, setFormBookletBookingDate] = useState(
    () => new Date().toISOString().split('T')[0]
  );
  const [formNotes, setFormNotes] = useState('');
  const [formAvatar, setFormAvatar] = useState<string>('');
  const [formGender, setFormGender] = useState<'male' | 'female'>('male');
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  // Direct DB Load & Refresh
  const handleRefreshFromDb = async (silent = false) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/students');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setStudentsList(data);
          if (!silent) {
            showToast(
              isAr ? 'تم تحديث سجلات الطلاب من قاعدة البيانات بنجاح ✓' : 'Refreshed students from database ✓',
              'info'
            );
          }
        }
      }
    } catch (err) {
      console.error('Failed to reload students:', err);
      if (!silent) {
        showToast(isAr ? 'تعذر الاتصال بقاعدة البيانات' : 'Failed to refresh', 'error');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    handleRefreshFromDb(true);
  }, []);

  // Export CSV
  const handleExportCsv = () => {
    const headers = [
      'المعرف',
      'كود الطالب',
      'اسم الطالب بالكامل',
      'المرحلة الدراسية',
      'نظام الدراسة',
      'التلفون واتساب',
      'اسم ولي الأمر',
      'رقم هاتف ولي الأمر',
      'المذكرة',
      'حالة الاستلام',
      'تاريخ الحجز',
      'ملاحظات المعلمين والتوجيه التربوي',
      'تاريخ التسجيل',
    ];
    const rows = filteredStudents.map((s) => [
      s.id,
      s.code,
      s.name,
      s.grade,
      s.type === 'online' ? 'أون لاين' : 'سنتر (أوف لاين)',
      s.studentPhone || '',
      s.parentName,
      s.parentPhone,
      s.bookletName || '',
      s.bookletStatus || '',
      s.bookletBookingDate || '',
      s.notes || '',
      s.registeredDate,
    ]);
    const csvContent =
      '\uFEFF' +
      [headers, ...rows]
        .map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','))
        .join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `students_affairs_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(isAr ? 'تم تصدير كشف شؤون الطلاب بصيغة Excel/CSV ✓' : 'Exported CSV ✓', 'info');
  };

  // Filtering
  const filteredStudents = useMemo(() => {
    return studentsList.filter((stu) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        stu.name.toLowerCase().includes(q) ||
        (stu.nameEn && stu.nameEn.toLowerCase().includes(q)) ||
        stu.code.toLowerCase().includes(q) ||
        (stu.studentPhone && stu.studentPhone.toLowerCase().includes(q)) ||
        (stu.parentName && stu.parentName.toLowerCase().includes(q)) ||
        (stu.parentPhone && stu.parentPhone.toLowerCase().includes(q)) ||
        (stu.bookletName && stu.bookletName.toLowerCase().includes(q)) ||
        (stu.notes && stu.notes.toLowerCase().includes(q));

      const matchType = selectedType === 'all' || stu.type === selectedType;
      const matchStatus = selectedStatus === 'all' || stu.status === selectedStatus;
      const matchGrade = selectedGrade === 'all' || stu.grade === selectedGrade;
      return matchSearch && matchType && matchStatus && matchGrade;
    });
  }, [studentsList, searchQuery, selectedType, selectedStatus, selectedGrade]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filteredStudents.length / itemsPerPage));
  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages);
  }, [currentPage, totalPages]);

  const paginatedStudents = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredStudents.slice(start, start + itemsPerPage);
  }, [filteredStudents, currentPage, itemsPerPage]);

  const onlineCount = useMemo(
    () => studentsList.filter((s) => s.type === 'online').length,
    [studentsList]
  );
  const offlineCount = useMemo(
    () => studentsList.filter((s) => s.type === 'offline').length,
    [studentsList]
  );

  const getCalculatedStatus = (score: number, attendance: number): 'top' | 'weak' | 'regular' => {
    if (score >= 90) return 'top';
    if (score < 60 || attendance < 70) return 'weak';
    return 'regular';
  };

  const handleOpenAdd = () => {
    setFormCode(`STU-${Math.floor(1000 + Math.random() * 9000)}`);
    setFormName('');
    setFormGrade('الصف الثالث الثانوي');
    setFormType('online');
    setFormStudentPhone('');
    setFormParentName('');
    setFormParentPhone('');
    setFormBookletName('عملي');
    setFormBookletStatus('مستلم');
    setFormBookletBookingDate(new Date().toISOString().split('T')[0]);
    setFormNotes('');
    setFormAvatar('');
    setFormGender('male');
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (stu: Student) => {
    setEditingStudent(stu);
    setFormCode(stu.code);
    setFormName(stu.name);
    setFormGrade(stu.grade);
    setFormType(stu.type);
    setFormStudentPhone(stu.studentPhone || '');
    setFormParentName(stu.parentName || '');
    setFormParentPhone(stu.parentPhone || '');
    setFormBookletName(stu.bookletName || 'عملي');
    setFormBookletStatus(stu.bookletStatus || 'مستلم');
    setFormBookletBookingDate(stu.bookletBookingDate || stu.registeredDate || new Date().toISOString().split('T')[0]);
    setFormNotes(stu.notes || '');
    setFormAvatar(stu.avatar || '');
    setFormGender(stu.gender === 'female' ? 'female' : 'male');
  };

  const handleStudentPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingAvatar(true);
    try {
      const dataUrl = await readAndResizeImageFile(file, 420, 0.85);
      setFormAvatar(dataUrl);
      showToast(isAr ? 'تم رفع صورة الطالب/الطالبة ومعاينتها بنجاح ✓' : 'Student photo ready ✓', 'info');
    } catch (err: any) {
      showToast(err?.message || (isAr ? 'تعذر رفع الصورة' : 'Upload failed'), 'error');
    } finally {
      setIsUploadingAvatar(false);
      e.target.value = '';
    }
  };

  // Save Add to DB
  const handleSaveAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    const code = formCode.trim() || `STU-${Math.floor(1000 + Math.random() * 9000)}`;
    const cleanName = formName.trim() || 'طالب جديد';
    const finalAvatar =
      formAvatar.trim() || buildAutoStudentAvatarDataUrl(cleanName, formGender);

    const payload: Student = {
      id: `stu-${Date.now()}`,
      code,
      name: cleanName,
      nameEn: cleanName,
      grade: formGrade,
      type: formType,
      studentPhone: formStudentPhone.trim(),
      parentName: formParentName.trim() || 'ولي أمر الطالب',
      parentPhone: formParentPhone.trim() || '+966 50 000 0000',
      parentEmail: '',
      overallScore: 88,
      attendanceRate: 95,
      status: 'regular',
      notes: formNotes.trim() || '',
      registeredDate: new Date().toISOString().split('T')[0],
      city: '',
      avatar: finalAvatar,
      gender: formGender,
      bookletName: formBookletName.trim(),
      bookletStatus: formBookletStatus,
      bookletBookingDate: formBookletBookingDate,
    };

    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const saved: Student = await res.json();
        setStudentsList((prev) => [saved, ...prev]);
        onAddStudent(saved);
        showToast(isAr ? 'تم تسجيل الطالب وحفظه في قاعدة البيانات بنجاح ✓' : 'Student saved to DB ✓');
        setIsAddModalOpen(false);
      } else {
        showToast(isAr ? 'تعذر حفظ بيانات الطالب في قاعدة البيانات' : 'Failed to save student', 'error');
      }
    } catch (err) {
      console.error('Failed to add student:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database connection error', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Edit to DB
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    setIsSaving(true);
    const cleanName = formName.trim() || editingStudent.name;
    const finalAvatar =
      formAvatar.trim() || buildAutoStudentAvatarDataUrl(cleanName, formGender);

    const updatedStudent: Student = {
      ...editingStudent,
      code: formCode.trim() || editingStudent.code,
      name: cleanName,
      grade: formGrade,
      type: formType,
      studentPhone: formStudentPhone.trim(),
      parentName: formParentName.trim(),
      parentPhone: formParentPhone.trim(),
      notes: formNotes.trim(),
      avatar: finalAvatar,
      gender: formGender,
      bookletName: formBookletName.trim(),
      bookletStatus: formBookletStatus,
      bookletBookingDate: formBookletBookingDate,
    };

    try {
      const res = await fetch(`/api/students/${editingStudent.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify(updatedStudent),
      });

      if (res.ok) {
        const saved: Student = await res.json();
        setStudentsList((prev) => prev.map((s) => (s.id === editingStudent.id ? saved : s)));
        onUpdateStudent(saved);
        if (viewingStudent && viewingStudent.id === editingStudent.id) {
          setViewingStudent(saved);
        }
        showToast(isAr ? 'تم تحديث بيانات الطالب في قاعدة البيانات بنجاح ✓' : 'Student updated in DB ✓');
        setEditingStudent(null);
      } else {
        showToast(isAr ? 'فشل تحديث بيانات الطالب' : 'Failed to update student', 'error');
      }
    } catch (err) {
      console.error('Failed to update student:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database error', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Confirm Delete from DB
  const handleConfirmDelete = async () => {
    if (!studentToDelete) return;
    const id = studentToDelete.id;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/students/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser),
      });
      if (res.ok) {
        setStudentsList((prev) => prev.filter((s) => s.id !== id));
        onDeleteStudent(id);
        if (viewingStudent && viewingStudent.id === id) {
          setViewingStudent(null);
        }
        showToast(isAr ? 'تم حذف سجل الطالب نهائياً من قاعدة البيانات ✓' : 'Student deleted from DB ✓');
      } else {
        showToast(isAr ? 'تعذر حذف سجل الطالب' : 'Failed to delete student', 'error');
      }
    } catch (err) {
      console.error('Failed to delete student:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database error', 'error');
    } finally {
      setIsSaving(false);
      setStudentToDelete(null);
    }
  };

  // Quick Grade Adjust persisted to DB + broadcast via WebSockets
  const handleQuickGradeAdjust = async (student: Student, delta: number) => {
    const newScore = Math.max(0, Math.min(100, student.overallScore + delta));
    const newStatus = getCalculatedStatus(newScore, student.attendanceRate);
    const updated: Student = {
      ...student,
      overallScore: newScore,
      status: newStatus,
    };

    setStudentsList((prev) => prev.map((s) => (s.id === student.id ? updated : s)));
    if (viewingStudent && viewingStudent.id === student.id) {
      setViewingStudent(updated);
    }

    try {
      const res = await fetch(`/api/students/${student.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify({ overallScore: newScore, status: newStatus }),
      });
      if (res.ok) {
        const saved: Student = await res.json();
        setStudentsList((prev) => prev.map((s) => (s.id === student.id ? saved : s)));
        onUpdateStudent(saved);
        realtimeSync.sendGradeUpdate({
          studentId: student.id,
          studentName: student.name,
          overallScore: newScore,
          notes: delta > 0 ? `زيادة درجات +${delta}%` : `تعديل درجات ${delta}%`,
          updatedBy: currentUser?.name || (isAr ? 'المعلم المشرف' : 'Educator'),
        });
        showToast(
          isAr
            ? `تم تحديث معدل (${student.name}) إلى ${newScore}% في قاعدة البيانات ✓`
            : `Updated score to ${newScore}% ✓`
        );
      }
    } catch (err) {
      console.error('Quick grade adjust error:', err);
      showToast(isAr ? 'تعذر حفظ تعديل الدرجة' : 'Failed to save grade change', 'error');
    }
  };

  return (
    <div className="space-y-6 font-tajawal">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          <div
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl shadow-xl text-xs md:text-sm font-bold font-cairo ${
              toastMessage.type === 'error'
                ? 'bg-rose-600 text-white'
                : toastMessage.type === 'info'
                ? 'bg-blue-700 text-white'
                : 'bg-emerald-600 text-white'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Real-time WebSocket Grade Sync Banner */}
      <div className="p-3.5 bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/50 rounded-2xl text-white shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
          <Zap className="w-4 h-4 text-emerald-400 shrink-0" />
          <div>
            <span className="font-bold text-white font-cairo">
              {isAr
                ? 'خدمة مزامنة سجلات ودرجات الطلاب فورياً عبر WebSockets'
                : 'Real-time WebSocket Student Grade Synchronization Service'}
            </span>
            <span className="text-[11px] text-emerald-300 block font-tajawal mt-0.5">
              {isAr
                ? 'جميع عمليات التسجيل والتعديل ورصد الدرجات محفوظة مباشرة في قاعدة البيانات وتتزامن فورياً عبر الأجهزة.'
                : 'All enrollments and grade updates are persisted in DB and synchronized instantly across peer devices.'}
            </span>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono font-bold text-[10px]">
          ● WS SYNC ACTIVE
        </span>
      </div>

      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-mono-numbers">
              <Database className="w-3 h-3 text-indigo-600" />
              <span>Cloud SQL Students Live</span>
            </span>
            <span className="text-xs text-slate-500 font-cairo">
              ({studentsList.length} {isAr ? 'طالب مسجل' : 'Students'} · {onlineCount}{' '}
              {isAr ? 'أونلاين' : 'Online'} · {offlineCount} {isAr ? 'سنتر' : 'Center'})
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white font-cairo">
            {isAr ? 'شؤون الطلاب (نظام أون لاين وأوف لاين)' : 'Student Affairs (Online & Center)'}
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 font-tajawal">
            {isAr
              ? 'إدارة حقيقية متصلة بقاعدة البيانات لتسجيل ومتابعة طلاب التعليم الإلكتروني (Online) وطلاب السنتر الحضوري (Offline).'
              : 'Real DB-backed enrollment and tracking for online remote learners and in-person center students.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto font-cairo">
          <button
            type="button"
            onClick={() => handleRefreshFromDb(false)}
            title={isAr ? 'تحديث السجلات من قاعدة البيانات' : 'Refresh from DB'}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 font-bold text-xs md:text-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>{isAr ? 'تصدير Excel / CSV' : 'Export CSV'}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-all shadow-sm cursor-pointer hover:scale-105"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'تسجيل طالب جديد' : 'Enroll New Student'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder={
                isAr ? 'ابحث باسم الطالب، الكود، الواتساب، المذكرة...' : 'Search name, code, phone...'
              }
              className="w-full pl-8 pr-9 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-tajawal"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setCurrentPage(1);
                }}
                className="absolute top-2.5 left-2.5 p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Type Filter (Online vs Offline) */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl font-cairo">
            <button
              type="button"
              onClick={() => {
                setSelectedType('all');
                setCurrentPage(1);
              }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                selectedType === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {isAr ? 'الكل' : 'All'}
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedType('online');
                setCurrentPage(1);
              }}
              className={`flex-1 flex items-center justify-center gap-1 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                selectedType === 'online'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Wifi className="w-3.5 h-3.5 text-emerald-500" />
              <span>{isAr ? 'أونلاين' : 'Online'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedType('offline');
                setCurrentPage(1);
              }}
              className={`flex-1 flex items-center justify-center gap-1 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                selectedType === 'offline'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-blue-500" />
              <span>{isAr ? 'سنتر' : 'Center'}</span>
            </button>
          </div>

          {/* Academic Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => {
              setSelectedStatus(e.target.value as any);
              setCurrentPage(1);
            }}
            className="w-full py-2 px-3 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 font-cairo cursor-pointer"
          >
            <option value="all">{isAr ? 'جميع المستويات الأكاديمية' : 'All Academic Levels'}</option>
            <option value="top">{isAr ? 'الطلاب الفائقين (90%+)' : 'Top Students (90%+)'}</option>
            <option value="regular">{isAr ? 'الطلاب المنتظمين' : 'Regular Students'}</option>
            <option value="weak">{isAr ? 'ضعاف المستوى (أقل من 60%)' : 'Weak Students (<60%)'}</option>
          </select>

          {/* Grade Filter */}
          <select
            value={selectedGrade}
            onChange={(e) => {
              setSelectedGrade(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full py-2 px-3 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 font-cairo cursor-pointer"
          >
            <option value="all">{isAr ? 'كافة الفصول والمراحل' : 'All Grades'}</option>
            {AVAILABLE_GRADES.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
          <span className="font-mono-numbers">
            {isAr
              ? `إجمالي الطلاب المعروضين: ${filteredStudents.length} من أصل ${studentsList.length} طالب`
              : `Showing ${filteredStudents.length} of ${studentsList.length} students`}
          </span>

          <div className="flex items-center gap-3">
            <span className="font-mono-numbers">
              {isAr ? `الصفحة ${currentPage} من ${totalPages}` : `Page ${currentPage} of ${totalPages}`}
            </span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo cursor-pointer"
              title="عدد الطلاب في الصفحة"
            >
              <option value={6}>6 / صفحة</option>
              <option value={10}>10 / صفحة</option>
              <option value={15}>15 / صفحة</option>
            </select>
          </div>
        </div>
      </div>

      {/* Students Table / Empty / Loading States */}
      {isLoading && studentsList.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 space-y-3">
          <RefreshCw className="w-10 h-10 mx-auto text-indigo-600 animate-spin" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 font-cairo">
            {isAr ? 'جارِ تحميل سجلات الطلاب من قاعدة البيانات...' : 'Loading students from database...'}
          </h3>
        </div>
      ) : paginatedStudents.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 space-y-3">
          <GraduationCap className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 font-cairo">
            {studentsList.length === 0
              ? isAr
                ? 'قاعدة البيانات لا تحتوي على أي طلاب مسجلين حتى الآن'
                : 'No students registered in database yet'
              : isAr
              ? 'لم يتم العثور على طلاب مطابقين لمعايير البحث'
              : 'No students matched your search'}
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto font-tajawal">
            {studentsList.length === 0
              ? isAr
                ? 'تم ربط شؤون الطلاب (أون لاين وأوف لاين) بقاعدة البيانات فقط دون أي بيانات وهمية. اضغط أدناه لتسجيل أول طالب.'
                : 'Database-only mode active. Click below to enroll your first student.'
              : isAr
              ? 'جرّب تعديل كلمات البحث أو إعادة ضبط الفلاتر.'
              : 'Try adjusting your search query or filters.'}
          </p>
          {studentsList.length === 0 ? (
            <button
              type="button"
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'تسجيل أول طالب الآن' : 'Enroll First Student'}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedType('all');
                setSelectedStatus('all');
                setSelectedGrade('all');
                setCurrentPage(1);
              }}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-cairo font-bold text-xs cursor-pointer"
            >
              {isAr ? 'إعادة ضبط الفلاتر' : 'Reset Filters'}
            </button>
          )}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs md:text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-xs font-cairo">
                <tr>
                  <th className="py-3.5 px-4 font-bold">{isAr ? 'كود واسم الطالب' : 'Student Code & Name'}</th>
                  <th className="py-3.5 px-4 font-bold">{isAr ? 'المرحلة الدراسية' : 'Grade'}</th>
                  <th className="py-3.5 px-4 font-bold">{isAr ? 'نظام الدراسة' : 'Enrollment'}</th>
                  <th className="py-3.5 px-4 font-bold">{isAr ? 'التلفون واتساب' : 'WhatsApp'}</th>
                  <th className="py-3.5 px-4 font-bold">{isAr ? 'ولي الأمر' : 'Parent'}</th>
                  <th className="py-3.5 px-4 font-bold">{isAr ? 'المذكرة وحالة الاستلام' : 'Booklet Status'}</th>
                  <th className="py-3.5 px-4 font-bold text-center">{isAr ? 'إجراءات' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginatedStudents.map((stu) => {
                  return (
                    <tr
                      key={stu.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={getStudentAvatarUrl(stu.avatar, stu.name, stu.gender || 'male')}
                            onError={(e) => handleStudentAvatarError(e, stu.name, stu.gender || 'male')}
                            alt={stu.name}
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 rounded-xl object-cover border border-indigo-100 dark:border-indigo-900 shrink-0 shadow-xs"
                          />
                          <div>
                            <p className="font-bold text-slate-900 dark:text-white truncate font-cairo">
                              {stu.name}
                            </p>
                            <span className="text-[11px] text-slate-400 font-mono-numbers block">
                              {stu.code}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 font-tajawal">
                        {stu.grade}
                      </td>

                      <td className="py-3.5 px-4">
                        {stu.type === 'online' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-xs text-emerald-700 dark:text-emerald-300 font-bold font-cairo">
                            <Wifi className="w-3.5 h-3.5" />
                            {isAr ? 'أون لاين (عن بعد)' : 'Online Remote'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-xs text-blue-700 dark:text-blue-300 font-bold font-cairo">
                            <Building2 className="w-3.5 h-3.5" />
                            {isAr ? 'سنتر (أوف لاين)' : 'Center (Offline)'}
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono-numbers">
                        <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                          {stu.studentPhone || '-'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200 font-cairo">
                          {stu.parentName}
                        </p>
                        <span className="text-[11px] text-slate-400 font-mono-numbers block">
                          {stu.parentPhone}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        {stu.bookletName || stu.bookletStatus ? (
                          <div className="space-y-0.5">
                            <p className="text-xs font-bold text-slate-800 dark:text-slate-200 font-cairo">
                              {stu.bookletName || (isAr ? 'المذكرة الدراسية' : 'Booklet')}
                            </p>
                            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                              <span
                                className={`px-2 py-0.5 rounded-md font-bold font-cairo ${
                                  stu.bookletStatus === 'مستلم'
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                                    : stu.bookletStatus === 'محجوز - لم يستلم بعد'
                                    ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                                    : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                                }`}
                              >
                                {stu.bookletStatus || 'مستلم'}
                              </span>
                              {stu.bookletBookingDate && (
                                <span className="text-slate-400 font-mono-numbers">
                                  {stu.bookletBookingDate}
                                </span>
                              )}
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">-</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={async () => {
                              setQrModalStudent(stu);
                              setQrModalDataUrl('');
                              try {
                                const url = await QRCode.toDataURL(
                                  `ALSHARIF-ATTEND:${stu.id}:${stu.code}`,
                                  { width: 260, margin: 2 }
                                );
                                setQrModalDataUrl(url);
                              } catch {
                                setQrModalDataUrl('');
                              }
                            }}
                            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 hover:border-emerald-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                            title={isAr ? 'بطاقة الحضور الرقمية QR' : 'Digital QR ID Card'}
                          >
                            <QrCode className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setViewingStudent(stu)}
                            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                            title={isAr ? 'مشاهدة تفاصيل الطالب' : 'View Student Details'}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(stu)}
                            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                            title={isAr ? 'تعديل بيانات الطالب' : 'Edit Student'}
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setStudentToDelete(stu)}
                            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:bg-rose-50 hover:border-rose-400 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title={isAr ? 'حذف سجل الطالب' : 'Delete Student'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold font-cairo rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-white dark:hover:bg-slate-800 cursor-pointer"
              >
                <ChevronRight className={`w-4 h-4 ${!isAr ? 'rotate-180' : ''}`} />
                <span>{isAr ? 'السابق' : 'Previous'}</span>
              </button>

              <div className="flex items-center gap-1">
                {Array.from({ length: totalPages }).map((_, idx) => (
                  <button
                    key={idx + 1}
                    type="button"
                    onClick={() => setCurrentPage(idx + 1)}
                    className={`w-8 h-8 rounded-xl text-xs font-bold font-mono-numbers transition-colors cursor-pointer ${
                      currentPage === idx + 1
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {idx + 1}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold font-cairo rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-white dark:hover:bg-slate-800 cursor-pointer"
              >
                <span>{isAr ? 'التالي' : 'Next'}</span>
                <ChevronLeft className={`w-4 h-4 ${!isAr ? 'rotate-180' : ''}`} />
              </button>
            </div>
          )}
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT STUDENT ================= */}
      {(isAddModalOpen || editingStudent) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                  {editingStudent ? <Edit className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-bold text-slate-900 dark:text-white font-cairo">
                    {editingStudent
                      ? isAr
                        ? 'تعديل بيانات الطالب بالمنظومة'
                        : 'Edit Student Details'
                      : isAr
                      ? 'تسجيل طالب جديد بالمنظومة'
                      : 'Enroll New Student'}
                  </h3>
                  <p className="text-xs text-slate-500 font-tajawal">
                    {isAr
                      ? 'الحقول المعتمدة لتسجيل بيانات الطالب والمذكرة وولي الأمر مع أفاتار تلقائي'
                      : 'Official student enrollment fields with automatic avatar fallback'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingStudent(null);
                }}
                className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={editingStudent ? handleSaveEdit : handleSaveAdd}
              className="p-6 overflow-y-auto space-y-4 text-xs md:text-sm"
            >
              {/* 1. حقل صورة الطالب / الطالبة أو أفاتار تلقائي لأي صورة مش موجودة */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                    {isAr
                      ? 'صورة الطالب / الطالبة (أو أفاتار تلقائي لأي صورة غير موجودة)'
                      : 'Student Photo or Automatic Avatar'}
                  </label>
                  <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-cairo text-[11px]">
                    <button
                      type="button"
                      onClick={() => setFormGender('male')}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                        formGender === 'male'
                          ? 'bg-indigo-600 text-white'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {isAr ? 'أفاتار طالب' : 'Male Avatar'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormGender('female')}
                      className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                        formGender === 'female'
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {isAr ? 'أفاتار طالبة' : 'Female Avatar'}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-3.5">
                  <div className="relative shrink-0 w-16 h-16">
                    <img
                      src={getStudentAvatarUrl(formAvatar, formName || 'طالب جديد', formGender)}
                      onError={(e) =>
                        handleStudentAvatarError(e, formName || 'طالب جديد', formGender)
                      }
                      alt="Student Preview"
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-200 dark:border-indigo-700 shadow-xs"
                    />
                    <span className="absolute -bottom-1 -left-1 w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow">
                      <Camera className="w-3.5 h-3.5" />
                    </span>
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs cursor-pointer shadow-xs">
                        <Upload className="w-3.5 h-3.5" />
                        <span>
                          {isUploadingAvatar
                            ? isAr
                              ? 'جاري الرفع...'
                              : 'Uploading...'
                            : isAr
                            ? 'رفع صورة الطالب / الطالبة'
                            : 'Upload Photo'}
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleStudentPhotoUpload}
                          className="hidden"
                        />
                      </label>
                      {formAvatar ? (
                        <button
                          type="button"
                          onClick={() => setFormAvatar('')}
                          className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-rose-600 text-xs font-cairo font-bold cursor-pointer"
                        >
                          {isAr ? 'تفعيل الأفاتار التلقائي' : 'Use Auto Avatar'}
                        </button>
                      ) : (
                        <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-cairo font-bold">
                          {isAr
                            ? '✓ الأفاتار التلقائي مفعّل تلقائياً لعدم وجود صورة مرفوعة'
                            : '✓ Auto avatar active'}
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={formAvatar.startsWith('data:') ? '' : formAvatar}
                      onChange={(e) => setFormAvatar(e.target.value)}
                      placeholder={
                        formAvatar.startsWith('data:')
                          ? isAr
                            ? 'تم إرفاق صورة الطالب بنجاح ✓'
                            : 'Student photo attached ✓'
                          : isAr
                          ? 'أو الصق رابط صورة مباشر (اتركه فارغاً للأفاتار التلقائي)...'
                          : 'Or paste image URL (leave blank for auto avatar)...'
                      }
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 font-mono-numbers"
                    />
                  </div>
                </div>
              </div>

              {/* 2. اسم الطالب بالكامل (بالعربية) * + 3. كود الطالب * */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم الطالب بالكامل (بالعربية) *' : 'Student Full Name (Arabic) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder={isAr ? 'مثال: عبد الله فيصل المنصور' : 'Full student name'}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'كود الطالب *' : 'Student Code *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formCode}
                    onChange={(e) => setFormCode(e.target.value)}
                    placeholder="STU-1001"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              {/* 4. المرحلة الدراسية * + 5. نظام الدراسة * */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المرحلة الدراسية *' : 'Grade *'}
                  </label>
                  <select
                    required
                    value={formGrade}
                    onChange={(e) => setFormGrade(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                  >
                    {AVAILABLE_GRADES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'نظام الدراسة *' : 'Enrollment System *'}
                  </label>
                  <select
                    required
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as EnrollmentType)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                  >
                    <option value="online">{isAr ? 'أون لاين (تعليم إلكتروني)' : 'Online (Remote)'}</option>
                    <option value="offline">{isAr ? 'أوف لاين (سنتر حضوري)' : 'Offline (In-Person Center)'}</option>
                  </select>
                </div>
              </div>

              {/* 6. التلفون واتساب + 7. اسم ولي الأمر * + 8. رقم هاتف ولي الأمر * */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'التلفون واتساب' : 'WhatsApp Phone'}
                  </label>
                  <input
                    type="text"
                    value={formStudentPhone}
                    onChange={(e) => setFormStudentPhone(e.target.value)}
                    placeholder="01000000000"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم ولي الأمر *' : 'Parent Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formParentName}
                    onChange={(e) => setFormParentName(e.target.value)}
                    placeholder={isAr ? 'اسم ولي الأمر' : 'Parent name'}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'رقم هاتف ولي الأمر *' : 'Parent Phone *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formParentPhone}
                    onChange={(e) => setFormParentPhone(e.target.value)}
                    placeholder="01000000000"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              {/* 9. المذكرة + حالة الاستلام + تاريخ الحجز */}
              <div className="p-3.5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200/70 dark:border-indigo-900/60 space-y-2.5">
                <span className="block font-cairo font-bold text-xs text-indigo-900 dark:text-indigo-300">
                  {isAr ? 'بيانات المذكرة الدراسية (المذكرة • حالة الاستلام • تاريخ الحجز)' : 'Study Booklet Details'}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'المذكرة' : 'Booklet'}
                    </label>
                    <select
                      value={formBookletName}
                      onChange={(e) => setFormBookletName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                    >
                      <option value="عملي">{isAr ? 'عملي' : 'Practical (عملي)'}</option>
                      <option value="نظري">{isAr ? 'نظري' : 'Theoretical (نظري)'}</option>
                      <option value="نظري و عملي">{isAr ? 'نظري و عملي' : 'Theoretical & Practical (نظري و عملي)'}</option>
                      <option value="ملغي">{isAr ? 'ملغي' : 'Cancelled (ملغي)'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'حالة الاستلام' : 'Receipt Status'}
                    </label>
                    <select
                      value={formBookletStatus}
                      onChange={(e) => setFormBookletStatus(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                    >
                      <option value="مستلم">{isAr ? 'مستلم' : 'Received'}</option>
                      <option value="محجوز - لم يستلم بعد">{isAr ? 'محجوز - لم يستلم بعد' : 'Booked - Pending'}</option>
                      <option value="غير محجوز">{isAr ? 'غير محجوز' : 'Not Booked'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'تاريخ الحجز' : 'Booking Date'}
                    </label>
                    <input
                      type="date"
                      value={formBookletBookingDate}
                      onChange={(e) => setFormBookletBookingDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                    />
                  </div>
                </div>
              </div>

              {/* 10. ملاحظات المعلمين والتوجيه التربوي */}
              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'ملاحظات المعلمين والتوجيه التربوي' : 'Notes & Academic Guidance'}
                </label>
                <textarea
                  rows={3}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder={isAr ? 'أضف ملاحظات المعلمين والتوجيه التربوي...' : 'Notes...'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 font-cairo">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingStudent(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>{isAr ? 'جارِ الحفظ...' : 'Saving...'}</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{editingStudent ? (isAr ? 'حفظ التعديلات' : 'Update') : isAr ? 'تسجيل الطالب' : 'Enroll'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: VIEW STUDENT DETAILS ================= */}
      {viewingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={getStudentAvatarUrl(
                    viewingStudent.avatar,
                    viewingStudent.name,
                    viewingStudent.gender || 'male'
                  )}
                  onError={(e) =>
                    handleStudentAvatarError(
                      e,
                      viewingStudent.name,
                      viewingStudent.gender || 'male'
                    )
                  }
                  alt={viewingStudent.name}
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-200 dark:border-indigo-700 shadow-sm shrink-0"
                />
                <div>
                  <h3 className="text-base md:text-lg font-black text-slate-900 dark:text-white font-cairo">
                    {viewingStudent.name}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono-numbers mt-0.5">
                    <span>{viewingStudent.code}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-tajawal">{viewingStudent.grade}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setViewingStudent(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs md:text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-cairo">{isAr ? 'نظام الدراسة' : 'Study Mode'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 mt-1 font-cairo">
                    {viewingStudent.type === 'online' ? (
                      <>
                        <Wifi className="w-4 h-4 text-emerald-500" />
                        {isAr ? 'تعليم إلكتروني (أونلاين)' : 'Online Remote'}
                      </>
                    ) : (
                      <>
                        <Building2 className="w-4 h-4 text-blue-500" />
                        {isAr ? 'حضور في السنتر (أوفلاين)' : 'Offline Center'}
                      </>
                    )}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-cairo">{isAr ? 'التلفون واتساب' : 'Student WhatsApp'}</span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-400 font-mono-numbers block mt-1">
                    {viewingStudent.studentPhone || '-'}
                  </span>
                </div>
              </div>

              {/* Booklet Details */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200/70 dark:border-indigo-900/60 space-y-2">
                <h4 className="font-bold text-indigo-900 dark:text-indigo-300 font-cairo">
                  {isAr ? 'بيانات المذكرة والحجز' : 'Booklet & Booking Info'}
                </h4>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 block font-cairo">{isAr ? 'المذكرة' : 'Booklet'}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {viewingStudent.bookletName || '-'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-cairo">{isAr ? 'حالة الاستلام' : 'Status'}</span>
                    <span className="font-bold text-emerald-700 dark:text-emerald-400">
                      {viewingStudent.bookletStatus || 'مستلم'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-cairo">{isAr ? 'تاريخ الحجز' : 'Booking Date'}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200 font-mono-numbers">
                      {viewingStudent.bookletBookingDate || viewingStudent.registeredDate || '-'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Parent Info */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2.5">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 font-cairo">
                  {isAr ? 'بيانات ولي الأمر' : 'Parent Contact Information'}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="text-slate-600 dark:text-slate-300">
                    <span className="text-slate-400">{isAr ? 'اسم ولي الأمر: ' : 'Name: '}</span>
                    <span className="font-bold">{viewingStudent.parentName}</span>
                  </div>
                  <div className="text-slate-600 dark:text-slate-300 font-mono-numbers">
                    <span className="text-slate-400 font-tajawal">{isAr ? 'رقم هاتف ولي الأمر: ' : 'Phone: '}</span>
                    <span className="font-bold">{viewingStudent.parentPhone}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 pt-1 font-cairo">
                  <button
                    type="button"
                    onClick={() =>
                      showToast(
                        isAr
                          ? `جاري طلب الاتصال بولي الأمر: ${viewingStudent.parentPhone}`
                          : `Calling ${viewingStudent.parentPhone}`,
                        'info'
                      )
                    }
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{isAr ? 'اتصال بولي الأمر' : 'Call Parent'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      showToast(
                        isAr
                          ? `تم إرسال تقرير متابعة للطالب (${viewingStudent.name}) إلى ولي الأمر ✓`
                          : 'Follow-up report sent to parent ✓'
                      )
                    }
                    className="flex-1 py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إرسال إشعار متابعة' : 'Send Alert'}</span>
                  </button>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-1.5 font-cairo">
                  {isAr ? 'ملاحظات المعلمين والتوجيه التربوي' : 'Notes & Academic Guidance'}
                </h4>
                <p className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 leading-relaxed text-slate-600 dark:text-slate-300">
                  {viewingStudent.notes || (isAr ? 'لا توجد ملاحظات مسجلة.' : 'No notes recorded.')}
                </p>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between font-cairo">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const target = viewingStudent;
                    setViewingStudent(null);
                    handleOpenEdit(target);
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <Edit className="w-3.5 h-3.5 text-blue-600" />
                  <span>{isAr ? 'تعديل الطالب' : 'Edit Student'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const target = viewingStudent;
                    setViewingStudent(null);
                    setStudentToDelete(target);
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 font-bold text-xs hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>{isAr ? 'حذف الطالب' : 'Delete'}</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setViewingStudent(null)}
                className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: DELETE CONFIRMATION ================= */}
      {studentToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="font-cairo font-bold text-base md:text-lg text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف سجل الطالب من قاعدة البيانات' : 'Confirm Student Deletion'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal">
                {isAr
                  ? 'هل أنت متأكد من حذف هذا الطالب نهائياً من قاعدة البيانات؟ لا يمكن التراجع عن هذا الإجراء.'
                  : 'Are you sure you want to permanently delete this student record from the database?'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-right space-y-1">
              <p className="font-cairo font-bold text-xs text-slate-900 dark:text-white truncate">
                {studentToDelete.name}
              </p>
              <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono-numbers">
                <span>{studentToDelete.code}</span>
                <span>•</span>
                <span className="font-tajawal">{studentToDelete.grade}</span>
                <span>•</span>
                <span className="font-tajawal">
                  {studentToDelete.type === 'online' ? 'أون لاين' : 'سنتر (أوف لاين)'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 font-cairo">
              <button
                type="button"
                onClick={() => setStudentToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{isAr ? 'جارِ الحذف...' : 'Deleting...'}</span>
                  </>
                ) : (
                  <span>{isAr ? 'نعم، احذف الطالب' : 'Yes, Delete'}</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: STUDENT DIGITAL QR ID CARD ================= */}
      {qrModalStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-emerald-500/40 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-gradient-to-l from-emerald-900 to-teal-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-amber-300" />
                <h3 className="font-cairo font-bold text-sm">
                  {isAr ? 'بطاقة الحضور الرقمية (QR السنتر)' : 'Digital QR Attendance Card'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setQrModalStudent(null)}
                className="p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 text-center space-y-3">
              <div>
                <h4 className="font-cairo font-black text-base text-slate-900 dark:text-white">
                  {qrModalStudent.name}
                </h4>
                <p className="text-xs text-slate-500">
                  {qrModalStudent.grade} ·{' '}
                  <span className="font-mono-numbers font-bold text-emerald-700 dark:text-emerald-400">
                    {qrModalStudent.code}
                  </span>
                </p>
              </div>

              <div className="inline-flex flex-col items-center p-3 rounded-2xl bg-white border-2 border-dashed border-emerald-400">
                {qrModalDataUrl ? (
                  <img
                    src={qrModalDataUrl}
                    alt={qrModalStudent.code}
                    className="w-44 h-44 object-contain"
                  />
                ) : (
                  <div className="w-44 h-44 flex items-center justify-center text-xs text-slate-400">
                    جارِ توليد الرمز...
                  </div>
                )}
              </div>

              <p className="text-[11px] text-slate-500">
                {isAr
                  ? 'يُمسح هذا الرمز بكاميرا المعلم أو المشرف عند دخول قاعة السنتر لتسجيل الحضور فوراً.'
                  : 'Scan at center hall entrance for instant attendance.'}
              </p>

              <div className="flex items-center gap-2 pt-2 font-cairo">
                {qrModalDataUrl && (
                  <a
                    href={qrModalDataUrl}
                    download={`qr-${qrModalStudent.code}.png`}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isAr ? 'حفظ صورة QR' : 'Download QR'}</span>
                  </a>
                )}
                <button
                  type="button"
                  onClick={() => setQrModalStudent(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
