import React, { useState, useEffect, useRef } from 'react';
import {
  FileText,
  Clock,
  Plus,
  Play,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Award,
  X,
  BookOpen,
  Sparkles,
  Dices,
  AlertCircle,
  Eye,
  Send,
  FileCheck,
  RefreshCw,
  Edit3,
  Trash2,
  Search,
  ListChecks,
  CheckSquare,
  Lightbulb,
  ArrowUp,
  ArrowDown,
  Copy,
  Save,
  Database,
  Check,
  ToggleLeft,
  ToggleRight,
  Video,
  FileSpreadsheet,
  LayoutGrid,
  ExternalLink,
  BookX,
  Code2,
  Flag,
  ShieldAlert,
  Upload,
  Download,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { getMcqOptionSurfaceClass, MCQ_QUESTION_BOX_CLASS } from '../utils/mcqTheme';
import { hasHtmlMarkup, hasMeaningfulHtmlContent } from '../utils/htmlText';
import { QuestionBankPanel } from './QuestionBankPanel';
import {
  Quiz,
  QuizQuestion,
  QuizQuestionType,
  Lesson,
  Student,
  Language,
  CurrentUser,
  Teacher,
  StudentMistakeEntry,
  ContentErrorReportCategory,
  QuestionBankItem,
  QuestionDifficulty,
} from '../types';
import {
  canTeacherManageQuiz,
  getAuthHeaders,
  isParentRole,
  isStudentRole,
  isTeacherRole,
  resolveMatchedTeacher,
} from '../utils/rbac';
import { AlSharifWatermark } from './ScreenProtectionGuard';
import { FlashcardsAndCompetitionsHub } from './FlashcardsAndCompetitionsHub';
import { MistakeNotebookPanel } from './MistakeNotebookPanel';
import { LiveCodeSandbox } from './LiveCodeSandbox';
import { parseBulkQuestionsText, downloadBulkQuestionsSampleCsv } from '../utils/bulkQuestionParser';

const SUBJECT_OPTIONS = [
  'الرياضيات',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'اللغة العربية',
  'اللغة الإنجليزية',
  'الحاسب الآلي',
  'الدراسات الاجتماعية',
];

const GRADE_OPTIONS = [
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
  'الصف الثالث المتوسط',
  'الصف الثاني المتوسط',
  'الصف الأول المتوسط',
];

const OPTION_LETTERS_AR = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];
const OPTION_LETTERS_EN = ['A', 'B', 'C', 'D', 'E', 'F'];

interface QuizzesSystemProps {
  quizzes: Quiz[];
  lessons?: Lesson[];
  students?: Student[];
  onAddQuiz: (quiz: Quiz) => void;
  onUpdateQuiz?: (quiz: Quiz) => void;
  onDeleteQuiz?: (id: string) => void;
  onNavigateToLessons?: () => void;
  onNavigateToCertificates?: () => void;
  onExamRecorded?: (payload: any) => void;
  language: Language;
  currentUser?: CurrentUser;
  teachers?: Teacher[];
}

const normalizeLessonFromApi = (raw: any): Lesson => ({
  ...raw,
  infographicData:
    typeof raw.infographicData === 'string' && raw.infographicData.trim()
      ? (() => {
          try {
            return JSON.parse(raw.infographicData);
          } catch {
            return undefined;
          }
        })()
      : raw.infographicData || undefined,
});

const normalizeQuizFromApi = (raw: any): Quiz => {
  const parsedQuestions: QuizQuestion[] = Array.isArray(raw.questions)
    ? raw.questions
    : typeof raw.questions === 'string' && raw.questions.trim()
    ? (() => {
        try {
          const parsed = JSON.parse(raw.questions);
          return Array.isArray(parsed) ? parsed : [];
        } catch {
          return [];
        }
      })()
    : [];

  return {
    id: raw.id,
    title: raw.title || '',
    subject: raw.subject || 'الرياضيات',
    grade: raw.grade || 'الصف الثالث الثانوي',
    type: raw.type === 'monthly' ? 'monthly' : 'weekly',
    durationMinutes: Number(raw.durationMinutes) || 30,
    totalMarks: Number(raw.totalMarks) || 20,
    questions: parsedQuestions.map((q, idx) => ({
      ...q,
      id: q.id || `q-${Date.now()}-${idx}`,
      questionType:
        q.questionType ||
        (Array.isArray(q.options) &&
        q.options.length === 2 &&
        (q.options[0] === 'صح' || q.options[0] === 'True')
          ? 'true_false'
          : 'mcq'),
      options: Array.isArray(q.options) && q.options.length > 0 ? q.options : ['صح', 'خطأ'],
      correctOptionIndex: Number(q.correctOptionIndex) || 0,
      explanation: q.explanation || '',
    })),
    dueDate: raw.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    completedStudentsCount: Number(raw.completedStudentsCount) || 0,
    averageScore: Number(raw.averageScore) || 0,
    teacherId: raw.teacherId || undefined,
    teacherName: raw.teacherName || undefined,
    pdfSourceFile: raw.pdfSourceFile,
    isRandomized: raw.isRandomized,
    pdfPageCount: raw.pdfPageCount,
    instantExplanation: raw.instantExplanation ?? true,
    enableMultiForms: raw.enableMultiForms ?? true,
    enableTabSwitchLock: raw.enableTabSwitchLock ?? true,
  };
};

function stripHtmlForPreview(html?: string): string {
  if (!html) return '';
  return html
    .replace(/<\/(p|div|li|h[1-6]|tr)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/[ \t]+/g, ' ')
    .trim();
}

export const QuizzesSystem: React.FC<QuizzesSystemProps> = ({
  quizzes,
  lessons = [],
  students = [],
  onAddQuiz,
  onUpdateQuiz,
  onDeleteQuiz,
  onNavigateToLessons,
  onNavigateToCertificates,
  onExamRecorded,
  language,
  currentUser,
  teachers = [],
}) => {
  const isAr = language === 'ar';
  const role = currentUser?.role;
  const isStudent = isStudentRole(role);
  const isParent = isParentRole(role);
  const isTeacher = isTeacherRole(role);
  const canManageQuizzes =
    !currentUser ||
    Boolean(currentUser.isSuperAdmin) ||
    role === 'admin' ||
    role === 'supervisor' ||
    isTeacher;
  const matchedTeacher = resolveMatchedTeacher(currentUser || null, teachers);

  // Strictly Database-Backed State (zero mock/fake data)
  const [localQuizzes, setLocalQuizzes] = useState<Quiz[]>(quizzes.map(normalizeQuizFromApi));
  const [localLessons, setLocalLessons] = useState<Lesson[]>(lessons.map(normalizeLessonFromApi));
  const [localStudents, setLocalStudents] = useState<Student[]>(students);
  const [isLoadingDb, setIsLoadingDb] = useState(false);
  const [isSavingDb, setIsSavingDb] = useState(false);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'weekly' | 'monthly'>('all');
  const [lessonFormatFilter, setLessonFormatFilter] = useState<'all' | 'video' | 'pdf' | 'word' | 'infographic'>('all');
  const [selectedLessonIds, setSelectedLessonIds] = useState<string[]>([]);

  // Toast Feedback
  const [statusBanner, setStatusBanner] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Modals
  const [isGeneratorModalOpen, setIsGeneratorModalOpen] = useState(false);
  const [previewingLesson, setPreviewingLesson] = useState<Lesson | null>(null);

  // Custom Quiz & Question Builder Modal
  const [isBuilderModalOpen, setIsBuilderModalOpen] = useState(false);
  const [editingQuizId, setEditingQuizId] = useState<string | null>(null);
  const [builderError, setBuilderError] = useState<string | null>(null);
  const [builderTitle, setBuilderTitle] = useState('');
  const [builderSubject, setBuilderSubject] = useState(SUBJECT_OPTIONS[0]);
  const [builderGrade, setBuilderGrade] = useState(GRADE_OPTIONS[2]);
  const [builderType, setBuilderType] = useState<'weekly' | 'monthly'>('weekly');
  const [builderDuration, setBuilderDuration] = useState(30);
  const [builderTotalMarks, setBuilderTotalMarks] = useState(20);
  const [builderDueDate, setBuilderDueDate] = useState(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );
  const [builderQuestions, setBuilderQuestions] = useState<QuizQuestion[]>([]);
  const [builderEnableMultiForms, setBuilderEnableMultiForms] = useState<boolean>(true);
  const [builderEnableTabSwitchLock, setBuilderEnableTabSwitchLock] = useState<boolean>(true);

  // Bulk Question Import Modal (Excel / CSV / Word)
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [bulkRawText, setBulkRawText] = useState('');
  const [bulkImportError, setBulkImportError] = useState<string | null>(null);

  // Pull from Question Bank Modal inside Builder
  const [isPullBankOpen, setIsPullBankOpen] = useState(false);
  const [pullDifficulty, setPullDifficulty] = useState<'all' | QuestionDifficulty>('all');
  const [pullCount, setPullCount] = useState(5);
  const [isPullingBank, setIsPullingBank] = useState(false);

  // Sub-view Tab & Smart Mistake Notebook
  const [activeSubView, setActiveSubView] = useState<'quizzes' | 'bank' | 'mistakes'>('quizzes');
  const [mistakeEntries, setMistakeEntries] = useState<StudentMistakeEntry[]>([]);
  const [isLoadingMistakes, setIsLoadingMistakes] = useState(false);

  // Delete Confirmation Modal
  const [quizToDelete, setQuizToDelete] = useState<Quiz | null>(null);
  const [isDeletingDb, setIsDeletingDb] = useState(false);

  // Interactive Student Test-Taking Runner State
  const [activeQuizToTake, setActiveQuizToTake] = useState<Quiz | null>(null);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [instantFeedbackEnabled, setInstantFeedbackEnabled] = useState<boolean>(true);
  const [revealedQuestions, setRevealedQuestions] = useState<Record<number, boolean>>({});
  const [isTestSubmitted, setIsTestSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isPersistingResult, setIsPersistingResult] = useState(false);
  const [examTakerStudentId, setExamTakerStudentId] = useState<string>('');
  const [autoCertGeneratedSummary, setAutoCertGeneratedSummary] = useState<string | null>(null);
  const submittedQuizGuardRef = useRef<boolean>(false);
  const [examFormLabel, setExamFormLabel] = useState<'أ' | 'ب' | 'ج'>('أ');
  const [tabSwitchCount, setTabSwitchCount] = useState<number>(0);
  const [tabSwitchWarningBanner, setTabSwitchWarningBanner] = useState<string | null>(null);
  const lastTabSwitchAtRef = useRef<number>(0);
  const [showRunnerCodeSandbox, setShowRunnerCodeSandbox] = useState<boolean>(false);

  // Question Error Reporting Modal
  const [reportingQuestion, setReportingQuestion] = useState<{
    quizId: string;
    quizTitle: string;
    subject: string;
    question: QuizQuestion;
  } | null>(null);
  const [reportCategory, setReportCategory] = useState<ContentErrorReportCategory>('needs_clarification');
  const [reportDescription, setReportDescription] = useState('');
  const [isSubmittingReport, setIsSubmittingReport] = useState(false);

  // Real DB Random Generator State
  const [genQuestionsCount, setGenQuestionsCount] = useState<number>(5);
  const [genQuestionMix, setGenQuestionMix] = useState<'mixed' | 'mcq' | 'true_false'>('mixed');
  const [genFormatFilter, setGenFormatFilter] = useState<'all' | 'video' | 'pdf' | 'word' | 'infographic'>('all');
  const [genQuizType, setGenQuizType] = useState<'weekly' | 'monthly'>('weekly');
  const [genTitle, setGenTitle] = useState('');
  const [genDuration, setGenDuration] = useState(25);
  const [genTotalMarks, setGenTotalMarks] = useState(25);
  const [isGeneratingFromDb, setIsGeneratingFromDb] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [extractedQuestions, setExtractedQuestions] = useState<QuizQuestion[]>([]);
  const [genSourceSummary, setGenSourceSummary] = useState<Array<{ id: string; title: string; subject: string; grade: string; format: string }>>([]);

  // Sync with parent props
  useEffect(() => {
    setLocalQuizzes(quizzes.map(normalizeQuizFromApi));
  }, [quizzes]);

  useEffect(() => {
    setLocalLessons(lessons.map(normalizeLessonFromApi));
  }, [lessons]);

  useEffect(() => {
    setLocalStudents(students);
  }, [students]);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusBanner({ type, text });
    setTimeout(() => setStatusBanner(null), 5000);
  };

  // Direct Database Sync for Quizzes, Lessons, and Students
  const syncAllFromDb = async (silent = false) => {
    if (!silent) setIsLoadingDb(true);
    try {
      const [qzRes, lesRes, stuRes] = await Promise.all([
        fetch('/api/quizzes'),
        fetch('/api/lessons'),
        fetch('/api/students'),
      ]);
      if (!qzRes.ok) throw new Error(`Quizzes HTTP ${qzRes.status}`);
      if (!lesRes.ok) throw new Error(`Lessons HTTP ${lesRes.status}`);

      const [qzData, lesData, stuData] = await Promise.all([
        qzRes.json(),
        lesRes.json(),
        stuRes.ok ? stuRes.json() : Promise.resolve([]),
      ]);

      const normalizedQuizzes = Array.isArray(qzData) ? qzData.map(normalizeQuizFromApi) : [];
      const normalizedLessons = Array.isArray(lesData) ? lesData.map(normalizeLessonFromApi) : [];

      setLocalQuizzes(normalizedQuizzes);
      setLocalLessons(normalizedLessons);
      if (Array.isArray(stuData)) setLocalStudents(stuData);

      if (!silent) {
        showToast(
          isAr
            ? `تمت المزامنة من قاعدة البيانات: ${normalizedQuizzes.length} اختبارات و ${normalizedLessons.length} دروس ✓`
            : `Synced from DB: ${normalizedQuizzes.length} quizzes and ${normalizedLessons.length} lessons ✓`
        );
      }
    } catch (err: any) {
      if (!silent) {
        showToast(
          isAr
            ? `تعذر تحديث البيانات من القاعدة: ${err.message}`
            : `Failed to sync DB: ${err.message}`,
          'error'
        );
      }
    } finally {
      if (!silent) setIsLoadingDb(false);
    }
  };

  const targetStudentIdForMistakes =
    currentUser?.studentId ||
    localStudents.find((s) => s.id === examTakerStudentId)?.id ||
    currentUser?.id ||
    '';

  const fetchMistakeEntries = async () => {
    setIsLoadingMistakes(true);
    try {
      const qs = targetStudentIdForMistakes
        ? `?studentId=${encodeURIComponent(targetStudentIdForMistakes)}`
        : '';
      const res = await fetch(`/api/mistake-notebook${qs}`, {
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        const data = await res.json();
        setMistakeEntries(Array.isArray(data?.mistakes) ? data.mistakes : []);
      }
    } catch {
      // silent
    } finally {
      setIsLoadingMistakes(false);
    }
  };

  useEffect(() => {
    syncAllFromDb(true);
    fetchMistakeEntries();
  }, [targetStudentIdForMistakes]);

  const handleMarkMistakeMastered = async (id: string, mastered: boolean) => {
    try {
      const res = await fetch('/api/mistake-notebook/master', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({ id, mastered }),
      });
      if (res.ok) {
        setMistakeEntries((prev) =>
          prev.map((m) => (m.id === id ? { ...m, mastered } : m))
        );
      }
    } catch {
      // silent
    }
  };

  const handleDeleteMistake = async (id: string) => {
    try {
      const res = await fetch(`/api/mistake-notebook/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setMistakeEntries((prev) => prev.filter((m) => m.id !== id));
      }
    } catch {
      // silent
    }
  };

  // ==========================================================
  // REAL DB LESSON SELECTION & RANDOMIZED GENERATION
  // ==========================================================
  const toggleLessonSelection = (id: string) => {
    setSelectedLessonIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const runDbRandomGeneration = async (opts?: {
    lessonIds?: string[];
    formatFilter?: 'all' | 'video' | 'pdf' | 'word' | 'infographic';
    count?: number;
    questionMix?: 'mixed' | 'mcq' | 'true_false';
  }) => {
    setIsGeneratingFromDb(true);
    setGenError(null);

    const targetIds = opts?.lessonIds ?? selectedLessonIds;
    const targetFmt = opts?.formatFilter ?? genFormatFilter;
    const targetCount = opts?.count ?? genQuestionsCount;
    const targetMix = opts?.questionMix ?? genQuestionMix;

    try {
      const res = await fetch('/api/quizzes/generate-from-lessons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          lessonIds: targetIds,
          formatFilter: targetFmt,
          count: targetCount,
          questionMix: targetMix,
          language,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      if (data.error || !Array.isArray(data.questions) || data.questions.length === 0) {
        setExtractedQuestions([]);
        setGenSourceSummary(Array.isArray(data.sourceLessons) ? data.sourceLessons : []);
        setGenError(
          data.error ||
            (isAr
              ? 'لا توجد أسئلة متاحة للاستخراج من الدروس المحددة حالياً.'
              : 'No questions available to generate from selected lessons.')
        );
      } else {
        setExtractedQuestions(data.questions);
        const sources = Array.isArray(data.sourceLessons) ? data.sourceLessons : [];
        setGenSourceSummary(sources);

        const firstSrc = sources[0];
        const subjectsText = Array.from(new Set(sources.map((s: any) => s.subject))).join('، ');
        if (!genTitle || genTitle.includes('مستخرج عشوائياً')) {
          const typeStr =
            genQuizType === 'weekly' ? (isAr ? 'أسبوعي' : 'Weekly') : isAr ? 'شهري' : 'Monthly';
          setGenTitle(
            isAr
              ? `اختبار ${subjectsText || firstSrc?.subject || ''} ${typeStr} (مستخرج عشوائياً من الدروس)`
              : `Randomized ${subjectsText || firstSrc?.subject || ''} ${typeStr} Quiz`
          );
        }
      }
    } catch (err: any) {
      setGenError(
        isAr
          ? `فشل توليد الأسئلة من قاعدة البيانات: ${err.message}`
          : `Failed to generate from DB: ${err.message}`
      );
    } finally {
      setIsGeneratingFromDb(false);
    }
  };

  const handleOpenRandomGenerator = (overrideIds?: string[], overrideFormat?: 'all' | 'video' | 'pdf' | 'word' | 'infographic') => {
    const idsToUse = overrideIds ?? selectedLessonIds;
    const fmtToUse = overrideFormat ?? lessonFormatFilter;
    if (overrideIds) setSelectedLessonIds(overrideIds);
    setGenFormatFilter(fmtToUse);
    setIsGeneratorModalOpen(true);
    runDbRandomGeneration({
      lessonIds: idsToUse,
      formatFilter: fmtToUse,
      count: genQuestionsCount,
      questionMix: genQuestionMix,
    });
  };

  const handlePublishGeneratedQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (extractedQuestions.length === 0) {
      setGenError(
        isAr ? 'لا توجد أسئلة مولدة لنشرها، يرجى إضافة دروس أولاً.' : 'No generated questions to publish.'
      );
      return;
    }

    const primarySource = genSourceSummary[0] || localLessons[0];
    const finalTitle =
      genTitle.trim() ||
      (isAr
        ? `اختبار ${primarySource?.subject || 'شامل'} عشوائي من الدروس (${extractedQuestions.length} أسئلة)`
        : `Randomized ${primarySource?.subject || 'Course'} Quiz`);

    setIsSavingDb(true);
    try {
      const res = await fetch('/api/quizzes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          id: `qz-${Date.now()}`,
          title: finalTitle,
          subject: primarySource?.subject || SUBJECT_OPTIONS[0],
          grade: primarySource?.grade || GRADE_OPTIONS[2],
          type: genQuizType,
          durationMinutes: Number(genDuration) || 25,
          totalMarks: Number(genTotalMarks) || 25,
          dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
          questions: JSON.stringify(extractedQuestions),
          completedStudentsCount: 0,
          averageScore: 0,
          teacherId: isTeacher ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || '' : '',
          teacherName: isTeacher ? matchedTeacher?.name || currentUser?.name || '' : '',
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const savedRaw = await res.json();
      const savedQuiz: Quiz = {
        ...normalizeQuizFromApi(savedRaw),
        isRandomized: true,
        instantExplanation: true,
      };
      setLocalQuizzes((prev) => [savedQuiz, ...prev]);
      onAddQuiz(savedQuiz);
      setIsGeneratorModalOpen(false);
      showToast(
        isAr
          ? `تم توليد وحفظ الاختبار العشوائي "${savedQuiz.title}" في قاعدة البيانات (${savedQuiz.questions.length} أسئلة) ✓`
          : `Published randomized quiz "${savedQuiz.title}" to database ✓`
      );
      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
    } catch (err: any) {
      setGenError(
        isAr ? `تعذر حفظ الاختبار في القاعدة: ${err.message}` : `Failed to save quiz: ${err.message}`
      );
    } finally {
      setIsSavingDb(false);
    }
  };

  // Send generated questions into the full Question Builder for further editing before publishing
  const handleCustomizeGeneratedInBuilder = () => {
    const primarySource = genSourceSummary[0] || localLessons[0];
    setEditingQuizId(null);
    setBuilderError(null);
    setBuilderTitle(genTitle.trim());
    setBuilderSubject(primarySource?.subject || SUBJECT_OPTIONS[0]);
    setBuilderGrade(primarySource?.grade || GRADE_OPTIONS[2]);
    setBuilderType(genQuizType);
    setBuilderDuration(genDuration);
    setBuilderTotalMarks(genTotalMarks);
    setBuilderDueDate(new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]);
    setBuilderQuestions(extractedQuestions.map((q) => ({ ...q, options: [...q.options] })));
    setBuilderEnableMultiForms(true);
    setBuilderEnableTabSwitchLock(true);
    setIsGeneratorModalOpen(false);
    setIsBuilderModalOpen(true);
  };

  // ==========================================================
  // QUESTION BUILDER (MCQ + TRUE/FALSE + INSTANT EXPLANATION)
  // ==========================================================
  const createBlankQuestion = (qType: QuizQuestionType): QuizQuestion => {
    if (qType === 'true_false') {
      return {
        id: `q-tf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        questionType: 'true_false',
        question: '',
        options: isAr ? ['صح', 'خطأ'] : ['True', 'False'],
        correctOptionIndex: 0,
        explanation: '',
        points: 2,
      };
    }
    return {
      id: `q-mcq-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      questionType: 'mcq',
      question: '',
      options: ['', '', '', ''],
      correctOptionIndex: 0,
      explanation: '',
      points: 2,
    };
  };

  const handleOpenCreateBuilder = () => {
    const defaultLesson = localLessons[0];
    setEditingQuizId(null);
    setBuilderError(null);
    setBuilderTitle('');
    setBuilderSubject(defaultLesson?.subject || SUBJECT_OPTIONS[0]);
    setBuilderGrade(defaultLesson?.grade || GRADE_OPTIONS[2]);
    setBuilderType('weekly');
    setBuilderDuration(30);
    setBuilderTotalMarks(20);
    setBuilderDueDate(new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]);
    setBuilderQuestions([createBlankQuestion('mcq'), createBlankQuestion('true_false')]);
    setBuilderEnableMultiForms(true);
    setBuilderEnableTabSwitchLock(true);
    setIsBuilderModalOpen(true);
  };

  const handleOpenEditBuilder = (quiz: Quiz) => {
    setEditingQuizId(quiz.id);
    setBuilderError(null);
    setBuilderTitle(quiz.title);
    setBuilderSubject(quiz.subject);
    setBuilderGrade(quiz.grade);
    setBuilderType(quiz.type);
    setBuilderDuration(quiz.durationMinutes);
    setBuilderTotalMarks(quiz.totalMarks);
    setBuilderDueDate(quiz.dueDate);
    setBuilderEnableMultiForms(quiz.enableMultiForms ?? true);
    setBuilderEnableTabSwitchLock(quiz.enableTabSwitchLock ?? true);
    setBuilderQuestions(
      quiz.questions.length > 0
        ? quiz.questions.map((q) => ({
            ...q,
            questionType:
              q.questionType ||
              (q.options.length === 2 && (q.options[0] === 'صح' || q.options[0] === 'True')
                ? 'true_false'
                : 'mcq'),
            options: [...q.options],
          }))
        : [createBlankQuestion('mcq')]
    );
    setIsBuilderModalOpen(true);
  };

  const handleAddQuestionToBuilder = (qType: QuizQuestionType) => {
    setBuilderQuestions((prev) => [...prev, createBlankQuestion(qType)]);
  };

  const handleRemoveQuestionFromBuilder = (idx: number) => {
    setBuilderQuestions((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleMoveQuestion = (idx: number, direction: -1 | 1) => {
    const target = idx + direction;
    if (target < 0 || target >= builderQuestions.length) return;
    setBuilderQuestions((prev) => {
      const next = [...prev];
      [next[idx], next[target]] = [next[target], next[idx]];
      return next;
    });
  };

  const handleDuplicateQuestion = (idx: number) => {
    setBuilderQuestions((prev) => {
      const src = prev[idx];
      const copy: QuizQuestion = {
        ...src,
        id: `q-dup-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        options: [...src.options],
      };
      const next = [...prev];
      next.splice(idx + 1, 0, copy);
      return next;
    });
  };

  const handleSwitchQuestionType = (idx: number, nextType: QuizQuestionType) => {
    setBuilderQuestions((prev) =>
      prev.map((q, i) => {
        if (i !== idx) return q;
        if (nextType === 'true_false') {
          return {
            ...q,
            questionType: 'true_false',
            options: isAr ? ['صح', 'خطأ'] : ['True', 'False'],
            correctOptionIndex: q.correctOptionIndex === 1 ? 1 : 0,
          };
        }
        return {
          ...q,
          questionType: 'mcq',
          options: q.options.length >= 4 ? q.options : ['', '', '', ''],
          correctOptionIndex: 0,
        };
      })
    );
  };

  const handleUpdateQuestionField = (idx: number, patch: Partial<QuizQuestion>) => {
    setBuilderQuestions((prev) => prev.map((q, i) => (i === idx ? { ...q, ...patch } : q)));
  };

  const handleUpdateMcqOptionText = (qIdx: number, optIdx: number, val: string) => {
    setBuilderQuestions((prev) =>
      prev.map((q, i) => {
        if (i !== qIdx) return q;
        const nextOpts = [...q.options];
        nextOpts[optIdx] = val;
        return { ...q, options: nextOpts };
      })
    );
  };

  const handleAddMcqOption = (qIdx: number) => {
    setBuilderQuestions((prev) =>
      prev.map((q, i) => {
        if (i !== qIdx || q.options.length >= 6) return q;
        return { ...q, options: [...q.options, ''] };
      })
    );
  };

  const handleRemoveMcqOption = (qIdx: number, optIdx: number) => {
    setBuilderQuestions((prev) =>
      prev.map((q, i) => {
        if (i !== qIdx || q.options.length <= 2) return q;
        const nextOpts = q.options.filter((_, oI) => oI !== optIdx);
        let nextCorrect = q.correctOptionIndex;
        if (optIdx === nextCorrect) nextCorrect = 0;
        else if (optIdx < nextCorrect) nextCorrect = Math.max(0, nextCorrect - 1);
        return { ...q, options: nextOpts, correctOptionIndex: nextCorrect };
      })
    );
  };

  const handleSaveBuiltQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    setBuilderError(null);

    if (!builderTitle.trim()) {
      setBuilderError(isAr ? 'يرجى إدخال عنوان الاختبار.' : 'Please enter a quiz title.');
      return;
    }

    if (builderQuestions.length === 0) {
      setBuilderError(
        isAr ? 'يجب إضافة سؤال واحد على الأقل داخل الاختبار.' : 'Add at least one question.'
      );
      return;
    }

    for (let i = 0; i < builderQuestions.length; i++) {
      const q = builderQuestions[i];
      if (!q.question.trim()) {
        setBuilderError(
          isAr
            ? `نص السؤال رقم (${i + 1}) فارغ، يرجى كتابته قبل الحفظ.`
            : `Question #${i + 1} text is required.`
        );
        return;
      }
      if (q.options.some((o) => !o.trim())) {
        setBuilderError(
          isAr
            ? `يرجى تعبئة كافة الخيارات في السؤال رقم (${i + 1}).`
            : `Please fill all options in question #${i + 1}.`
        );
        return;
      }
    }

    setIsSavingDb(true);
    try {
      const sanitizedQuestions: QuizQuestion[] = builderQuestions.map((q, idx) => ({
        ...q,
        id: q.id || `q-${Date.now()}-${idx}`,
        questionType: q.questionType || 'mcq',
        question: q.question.trim(),
        options: q.options.map((o) => o.trim()),
        correctOptionIndex: Math.min(q.correctOptionIndex, q.options.length - 1),
        explanation:
          q.explanation.trim() ||
          (isAr
            ? 'تمت مراجعة الإجابة النموذجية واعتمادها وفق معايير المادة.'
            : 'Verified answer key according to course guidelines.'),
      }));

      if (editingQuizId) {
        const res = await fetch(`/api/quizzes/${editingQuizId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            title: builderTitle.trim(),
            subject: builderSubject,
            grade: builderGrade,
            type: builderType,
            durationMinutes: Number(builderDuration) || 30,
            totalMarks: Number(builderTotalMarks) || 20,
            dueDate: builderDueDate,
            enableMultiForms: builderEnableMultiForms,
            enableTabSwitchLock: builderEnableTabSwitchLock,
            questions: JSON.stringify(sanitizedQuestions),
          }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const savedRaw = await res.json();
        const savedQuiz: Quiz = { ...normalizeQuizFromApi(savedRaw), instantExplanation: true };
        setLocalQuizzes((prev) => prev.map((q) => (q.id === savedQuiz.id ? savedQuiz : q)));
        onUpdateQuiz?.(savedQuiz);
        showToast(
          isAr
            ? `تم تحديث الاختبار "${savedQuiz.title}" وحفظ ${savedQuiz.questions.length} أسئلة في قاعدة البيانات ✓`
            : `Updated quiz "${savedQuiz.title}" in database ✓`
        );
      } else {
        const res = await fetch('/api/quizzes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            id: `qz-${Date.now()}`,
            title: builderTitle.trim(),
            subject: builderSubject,
            grade: builderGrade,
            type: builderType,
            durationMinutes: Number(builderDuration) || 30,
            totalMarks: Number(builderTotalMarks) || 20,
            dueDate: builderDueDate,
            enableMultiForms: builderEnableMultiForms,
            enableTabSwitchLock: builderEnableTabSwitchLock,
            questions: JSON.stringify(sanitizedQuestions),
            completedStudentsCount: 0,
            averageScore: 0,
            teacherId: isTeacher ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || '' : '',
            teacherName: isTeacher ? matchedTeacher?.name || currentUser?.name || '' : '',
          }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const savedRaw = await res.json();
        const savedQuiz = normalizeQuizFromApi(savedRaw);
        setLocalQuizzes((prev) => [savedQuiz, ...prev]);
        onAddQuiz(savedQuiz);
        showToast(
          isAr
            ? `تم إنشاء ونشر الاختبار "${savedQuiz.title}" في قاعدة البيانات (${savedQuiz.questions.length} أسئلة) ✓`
            : `Published quiz "${savedQuiz.title}" to database ✓`
        );
        confetti({ particleCount: 70, spread: 55, origin: { y: 0.6 } });
      }
      setIsBuilderModalOpen(false);
    } catch (err: any) {
      setBuilderError(
        isAr
          ? `فشل حفظ الاختبار في قاعدة البيانات: ${err.message}`
          : `Failed to save quiz: ${err.message}`
      );
    } finally {
      setIsSavingDb(false);
    }
  };

  // Delete Quiz in PostgreSQL
  const handleConfirmDeleteQuiz = async () => {
    if (!quizToDelete) return;
    setIsDeletingDb(true);
    try {
      const res = await fetch(`/api/quizzes/${quizToDelete.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setLocalQuizzes((prev) => prev.filter((q) => q.id !== quizToDelete.id));
      onDeleteQuiz?.(quizToDelete.id);
      showToast(
        isAr
          ? `تم حذف الاختبار "${quizToDelete.title}" نهائياً من قاعدة البيانات ✓`
          : `Deleted quiz "${quizToDelete.title}" from database ✓`
      );
      setQuizToDelete(null);
    } catch (err: any) {
      showToast(
        isAr ? `تعذر حذف الاختبار: ${err.message}` : `Failed to delete quiz: ${err.message}`,
        'error'
      );
    } finally {
      setIsDeletingDb(false);
    }
  };

  // ==========================================================
  // STUDENT INTERACTIVE TEST RUNNER & INSTANT EXPLANATION LOGIC
  // ==========================================================
  const shuffleArray = <T,>(items: T[]): T[] => {
    const arr = [...items];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  const buildRandomizedQuizForm = (quiz: Quiz): { quizForm: Quiz; formLabel: 'أ' | 'ب' | 'ج' } => {
    const forms: Array<'أ' | 'ب' | 'ج'> = ['أ', 'ب', 'ج'];
    const formLabel = forms[Math.floor(Math.random() * forms.length)];
    if (quiz.enableMultiForms === false || quiz.questions.length === 0) {
      return { quizForm: quiz, formLabel: 'أ' };
    }
    const shuffledQuestions = shuffleArray(quiz.questions).map((q) => {
      if (q.questionType === 'true_false' || q.options.length <= 2) {
        return { ...q, options: [...q.options] };
      }
      const indexed = q.options.map((text, origIdx) => ({ text, origIdx }));
      const shuffledOpts = shuffleArray(indexed);
      const newCorrectIdx = shuffledOpts.findIndex((item) => item.origIdx === q.correctOptionIndex);
      return {
        ...q,
        options: shuffledOpts.map((item) => item.text),
        correctOptionIndex: newCorrectIdx >= 0 ? newCorrectIdx : 0,
      };
    });
    return {
      quizForm: { ...quiz, questions: shuffledQuestions },
      formLabel,
    };
  };

  const handleStartQuiz = (quiz: Quiz) => {
    submittedQuizGuardRef.current = false;
    const { quizForm, formLabel } = buildRandomizedQuizForm(quiz);
    setActiveQuizToTake(quizForm);
    setExamFormLabel(formLabel);
    setTabSwitchCount(0);
    setTabSwitchWarningBanner(null);
    lastTabSwitchAtRef.current = 0;
    setShowRunnerCodeSandbox(false);
    setCurrentQuestionIdx(0);
    setSelectedAnswers({});
    setRevealedQuestions({});
    setInstantFeedbackEnabled(quiz.instantExplanation ?? true);
    setIsTestSubmitted(false);
    setAutoCertGeneratedSummary(null);
    const validUserStudent = currentUser?.studentId
      ? localStudents.find((s) => s.id === currentUser.studentId)
      : undefined;
    const defaultStuId =
      validUserStudent?.id ||
      localStudents.find((s) => s.grade === quiz.grade)?.id ||
      localStudents[0]?.id ||
      '';
    setExamTakerStudentId(defaultStuId);
    setTimeLeft(Math.max(1, quiz.durationMinutes) * 60);
  };

  const handleSelectOption = (optionIdx: number) => {
    if (isTestSubmitted) return;
    if (instantFeedbackEnabled && revealedQuestions[currentQuestionIdx]) return;

    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQuestionIdx]: optionIdx,
    }));

    if (instantFeedbackEnabled) {
      setRevealedQuestions((prev) => ({
        ...prev,
        [currentQuestionIdx]: true,
      }));
    }
  };

  const calculateResultForQuiz = (quiz: Quiz, answers: Record<number, number>) => {
    let correctCount = 0;
    let answeredCount = 0;
    let mcqTotal = 0;
    let mcqCorrect = 0;
    let tfTotal = 0;
    let tfCorrect = 0;

    quiz.questions.forEach((q, idx) => {
      const isTf = q.questionType === 'true_false';
      if (isTf) tfTotal++;
      else mcqTotal++;

      const choice = answers[idx];
      if (choice !== undefined) {
        answeredCount++;
        if (choice === q.correctOptionIndex) {
          correctCount++;
          if (isTf) tfCorrect++;
          else mcqCorrect++;
        }
      }
    });

    const totalQuestions = Math.max(1, quiz.questions.length);
    const percentage = Math.round((correctCount / totalQuestions) * 100);
    const earnedMarks = Math.round((correctCount / totalQuestions) * quiz.totalMarks);
    const wrongCount = answeredCount - correctCount;

    return {
      correctCount,
      wrongCount,
      unansweredCount: quiz.questions.length - answeredCount,
      totalQuestions: quiz.questions.length,
      percentage,
      earnedMarks,
      mcqTotal,
      mcqCorrect,
      tfTotal,
      tfCorrect,
    };
  };

  const handleSubmitTest = async () => {
    if (!activeQuizToTake || submittedQuizGuardRef.current) return;
    submittedQuizGuardRef.current = true;
    setIsTestSubmitted(true);

    const resSummary = calculateResultForQuiz(activeQuizToTake, selectedAnswers);
    if (resSummary.percentage >= 60) {
      confetti({
        particleCount: 110,
        spread: 70,
        origin: { y: 0.6 },
      });
    }

    setIsPersistingResult(true);
    try {
      const targetStudent = localStudents.find((s) => s.id === examTakerStudentId);

      // Record wrong / unanswered questions into Smart Mistake Notebook
      const wrongMistakes = activeQuizToTake.questions
        .map((q, idx) => {
          const userChoice = selectedAnswers[idx];
          if (userChoice === q.correctOptionIndex) return null;
          return {
            questionId: q.id,
            question: q.question,
            options: q.options,
            correctOptionIndex: q.correctOptionIndex,
            selectedOptionIndex: userChoice ?? -1,
            explanation: q.explanation,
            subject: activeQuizToTake.subject,
            grade: activeQuizToTake.grade,
            sourceType: 'quiz' as const,
            quizId: activeQuizToTake.id,
            quizTitle: activeQuizToTake.title,
          };
        })
        .filter(Boolean);

      const mistakeOwnerId = targetStudent?.id || currentUser?.studentId || currentUser?.id;
      if (wrongMistakes.length > 0 && mistakeOwnerId) {
        fetch('/api/mistake-notebook/record', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            studentId: mistakeOwnerId,
            studentName: targetStudent?.name || currentUser?.name || '',
            mistakes: wrongMistakes,
          }),
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (Array.isArray(d?.mistakes)) setMistakeEntries(d.mistakes);
          })
          .catch(() => {});
      }

      if (mistakeOwnerId) {
        fetch('/api/study-streaks/checkin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            studentId: mistakeOwnerId,
            studentName: targetStudent?.name || currentUser?.name || '',
            points: 20,
          }),
        }).catch(() => {});
      }

      if (targetStudent) {
        const attemptRes = await fetch('/api/quiz-attempts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            quizId: activeQuizToTake.id,
            quizTitle: activeQuizToTake.title,
            quizType: activeQuizToTake.type,
            subject: activeQuizToTake.subject,
            grade: activeQuizToTake.grade || targetStudent.grade,
            studentId: targetStudent.id,
            studentName: targetStudent.name,
            studentCode: targetStudent.code,
            earnedMarks: resSummary.earnedMarks,
            totalMarks: activeQuizToTake.totalMarks,
            percentage: resSummary.percentage,
            correctCount: resSummary.correctCount,
            totalQuestions: resSummary.totalQuestions,
            takenDate: new Date().toISOString().split('T')[0],
          }),
        });
        if (attemptRes.ok) {
          const payload = await attemptRes.json();
          if (payload.updatedQuiz) {
            const updatedQuiz: Quiz = {
              ...activeQuizToTake,
              ...normalizeQuizFromApi(payload.updatedQuiz),
              instantExplanation: activeQuizToTake.instantExplanation,
            };
            setLocalQuizzes((prev) => prev.map((q) => (q.id === updatedQuiz.id ? updatedQuiz : q)));
            onUpdateQuiz?.(updatedQuiz);
          }
          onExamRecorded?.(payload);
          const certsCount = Array.isArray(payload.autoCertificates) ? payload.autoCertificates.length : 0;
          setAutoCertGeneratedSummary(
            certsCount > 0
              ? isAr
                ? `تم رصد درجة الطالب «${targetStudent.name}» (${resSummary.percentage}%) وإصدار/تحديث (${certsCount}) شهادة وبيان درجات أوتوماتيك (80% فما فوق) ✓`
                : `Recorded score for ${targetStudent.name} (${resSummary.percentage}%) and auto-synced ${certsCount} certificate(s) (80%+) ✓`
              : isAr
              ? `تم رصد درجة الطالب «${targetStudent.name}» (${resSummary.percentage}%) في قاعدة البيانات. الشهادات وبيانات الدرجات تصدر أوتوماتيك عند تحقيق 80% فما فوق.`
              : `Recorded score for ${targetStudent.name} (${resSummary.percentage}%). Auto-certificates issue for 80%+.`
          );
          return;
        }
      }

      // Fallback when no student record was selected (only updates quiz counters)
      const prevCount = activeQuizToTake.completedStudentsCount || 0;
      const prevAvg = activeQuizToTake.averageScore || 0;
      const newCount = prevCount + 1;
      const newAvg = Math.round((prevAvg * prevCount + resSummary.earnedMarks) / newCount);

      const apiRes = await fetch(`/api/quizzes/${activeQuizToTake.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          completedStudentsCount: newCount,
          averageScore: newAvg,
        }),
      });
      if (apiRes.ok) {
        const updatedRaw = await apiRes.json();
        const updatedQuiz: Quiz = {
          ...activeQuizToTake,
          ...normalizeQuizFromApi(updatedRaw),
          instantExplanation: activeQuizToTake.instantExplanation,
        };
        setLocalQuizzes((prev) => prev.map((q) => (q.id === updatedQuiz.id ? updatedQuiz : q)));
        onUpdateQuiz?.(updatedQuiz);
      }
    } catch (err) {
      console.warn('Could not persist quiz attempt stats:', err);
    } finally {
      setIsPersistingResult(false);
    }
  };

  useEffect(() => {
    if (!activeQuizToTake || isTestSubmitted) return;
    if (timeLeft <= 0) {
      handleSubmitTest();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [activeQuizToTake, isTestSubmitted, timeLeft]);

  // Tab-Switch Anti-Cheat Monitor during Active Quiz
  useEffect(() => {
    if (
      !activeQuizToTake ||
      isTestSubmitted ||
      activeQuizToTake.enableTabSwitchLock === false ||
      currentUser?.isSuperAdmin
    ) {
      return;
    }

    const handleViolation = () => {
      const now = Date.now();
      if (now - lastTabSwitchAtRef.current < 1500) return;
      lastTabSwitchAtRef.current = now;
      setTabSwitchCount((prev) => {
        const next = prev + 1;
        if (next >= 3) {
          setTabSwitchWarningBanner(
            isAr
              ? 'تم تسليم الاختبار تلقائياً بعد 3 محاولات لمغادرة نافذة الاختبار.'
              : 'Quiz auto-submitted after 3 tab switches.'
          );
          setTimeout(() => {
            handleSubmitTest();
          }, 250);
        } else {
          setTabSwitchWarningBanner(
            isAr
              ? `تحذير أمني (${next}/3): يُمنع الخروج من صفحة الاختبار أو تبديل التبويب! في المحاولة الثالثة سيتم التسليم تلقائياً.`
              : `Warning (${next}/3): Leaving the quiz tab is not allowed! Auto-submit on 3rd attempt.`
          );
        }
        return next;
      });
    };

    const onVisibility = () => {
      if (document.hidden) handleViolation();
    };
    const onBlur = () => {
      handleViolation();
    };

    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('blur', onBlur);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('blur', onBlur);
    };
  }, [activeQuizToTake, isTestSubmitted, currentUser?.isSuperAdmin, isAr]);

  const handleSubmitQuestionReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportingQuestion || !reportDescription.trim()) return;
    setIsSubmittingReport(true);
    try {
      const res = await fetch('/api/content-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          targetType: 'quiz_question',
          quizId: reportingQuestion.quizId,
          questionId: reportingQuestion.question.id,
          targetTitle: `${reportingQuestion.quizTitle} — ${reportingQuestion.question.question.slice(0, 60)}`,
          subject: reportingQuestion.subject,
          category: reportCategory,
          details: reportDescription.trim(),
          reporterId: currentUser?.id || 'guest',
          reporterName: currentUser?.name || 'طالب',
        }),
      });
      if (!res.ok) throw new Error('Failed');
      showToast(
        isAr
          ? 'تم إرسال البلاغ عن السؤال إلى المعلم والأدمن للمراجعة الفورية ✓'
          : 'Question report sent to teacher and admin ✓'
      );
      setReportingQuestion(null);
      setReportDescription('');
    } catch {
      showToast(isAr ? 'تعذر إرسال البلاغ حالياً' : 'Failed to send report', 'error');
    } finally {
      setIsSubmittingReport(false);
    }
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  // Filtered Lists
  const filteredLessons = localLessons.filter((l) => {
    if (lessonFormatFilter === 'all') return true;
    return l.format === lessonFormatFilter;
  });

  const filteredQuizzes = localQuizzes.filter((q) => {
    const matchesSearch =
      !searchQuery.trim() ||
      q.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.grade.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (activeFilter === 'all') return true;
    return q.type === activeFilter;
  });

  const builderMcqCount = builderQuestions.filter((q) => q.questionType !== 'true_false').length;
  const builderTfCount = builderQuestions.filter((q) => q.questionType === 'true_false').length;

  const getFormatBadge = (format: Lesson['format']) => {
    switch (format) {
      case 'video':
        return {
          label: isAr ? 'فيديو' : 'Video',
          icon: <Video className="w-3 h-3" />,
          cls: 'bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300',
        };
      case 'pdf':
        return {
          label: isAr ? 'ملف PDF' : 'PDF',
          icon: <FileText className="w-3 h-3" />,
          cls: 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300',
        };
      case 'word':
        return {
          label: isAr ? 'مستند Word' : 'Word',
          icon: <FileSpreadsheet className="w-3 h-3" />,
          cls: 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300',
        };
      default:
        return {
          label: isAr ? 'إنفوجرافيك' : 'Infographic',
          icon: <LayoutGrid className="w-3 h-3" />,
          cls: 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Integrated Sub-Navigation Banner for Flashcards & Al-Sharif Competitions */}
      <FlashcardsAndCompetitionsHub
        lessons={localLessons}
        quizzes={localQuizzes}
        students={localStudents}
        teachers={teachers}
        currentUser={
          currentUser || {
            id: 'usr-guest',
            name: 'زائر',
            nameEn: 'Guest',
            email: 'guest@alsharif.edu',
            role: 'visitor',
            avatar: '',
          }
        }
        language={language}
        onNavigateToLessons={onNavigateToLessons}
      />

      {/* Toast Feedback */}
      {statusBanner && (
        <div
          className={`p-4 rounded-xl border text-xs md:text-sm flex items-center justify-between gap-3 shadow-sm font-cairo ${
            statusBanner.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-300 dark:border-rose-700 text-rose-900 dark:text-rose-200'
              : 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusBanner.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            )}
            <span className="font-bold">{statusBanner.text}</span>
          </div>
          <button onClick={() => setStatusBanner(null)} className="p-1 hover:opacity-75">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sub-Navigation: Quizzes vs Smart Mistake Notebook */}
      {(() => {
        const unmasteredCount = mistakeEntries.filter((m) => !m.mastered).length;
        return (
          <div className="flex flex-wrap items-center gap-2 font-cairo">
            <button
              type="button"
              onClick={() => setActiveSubView('quizzes')}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm flex items-center gap-2 transition-all cursor-pointer ${
                activeSubView === 'quizzes'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
              }`}
            >
              <ListChecks className="w-4 h-4" />
              <span>{isAr ? 'الاختبارات التفاعلية وبنك الأسئلة' : 'Interactive Quizzes'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubView('bank')}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm flex items-center gap-2 transition-all cursor-pointer ${
                activeSubView === 'bank'
                  ? 'bg-sky-700 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>{isAr ? 'بنك الأسئلة المركزي' : 'Question Bank'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveSubView('mistakes');
                fetchMistakeEntries();
              }}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm flex items-center gap-2 transition-all cursor-pointer ${
                activeSubView === 'mistakes'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
              }`}
            >
              <BookX className="w-4 h-4" />
              <span>{isAr ? 'دفتر الأخطاء الذكي' : 'Smart Mistake Notebook'}</span>
              {unmasteredCount > 0 && (
                <span
                  className={`px-2 py-0.5 rounded-full text-[11px] font-mono-numbers font-black ${
                    activeSubView === 'mistakes'
                      ? 'bg-white text-rose-700'
                      : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                  }`}
                >
                  {unmasteredCount}
                </span>
              )}
            </button>
          </div>
        );
      })()}

      {activeSubView === 'bank' && (
        <QuestionBankPanel
          lessons={localLessons}
          teachers={teachers}
          currentUser={currentUser ?? null}
          language={language}
          onCreateQuizWithQuestions={(picked: QuestionBankItem[], subj, grd) => {
            setEditingQuizId(null);
            setBuilderTitle(isAr ? `اختبار مخصص — ${subj}` : `Custom Quiz — ${subj}`);
            setBuilderSubject(subj);
            setBuilderGrade(grd);
            setBuilderQuestions(
              picked.map((p, idx) => ({
                id: `qb-pull-${Date.now()}-${idx}`,
                bankQuestionId: p.id,
                questionType: p.questionType,
                question: p.question,
                options: p.options,
                correctOptionIndex: p.correctOptionIndex,
                explanation: p.explanation,
                points: p.points,
                difficulty: p.difficulty,
                unit: p.unit,
                sourceLessonId: p.lessonId,
                sourceLessonTitle: p.lessonTitle,
              }))
            );
            setActiveSubView('quizzes');
            setIsBuilderModalOpen(true);
          }}
        />
      )}

      {activeSubView === 'mistakes' && (
        <MistakeNotebookPanel
          mistakes={mistakeEntries}
          isLoading={isLoadingMistakes}
          onMarkMastered={handleMarkMistakeMastered}
          onDeleteMistake={handleDeleteMistake}
          onRefresh={fetchMistakeEntries}
        />
      )}

      {activeSubView === 'quizzes' && (
        <>

      {/* Top Banner */}
      <div className="p-5 md:p-6 rounded-2xl bg-gradient-to-l from-emerald-900 via-emerald-800 to-teal-950 text-white shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-700/60 border border-emerald-500/40 text-emerald-200 text-xs font-bold font-cairo">
              <Database className="w-3.5 h-3.5 text-amber-300" />
              <span>
                {isAr
                  ? 'بيانات حقيقية 100% من قاعدة البيانات (بدون أي بيانات وهمية)'
                  : '100% Real Database Driven (Zero Mock Data)'}
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-black font-cairo leading-snug">
              {isAr
                ? 'منظومة الاختبارات العشوائية من الدروس والفيديوهات والملفات المرفقة'
                : 'Randomized Quizzes from Real Lessons, Videos & Attached Files'}
            </h2>
            <p className="text-xs md:text-sm text-emerald-100/90 leading-relaxed font-tajawal">
              {isParent
                ? isAr
                  ? 'بوابة متابعة الاختبارات الأسبوعية والشهرية لولي الأمر (عرض فقط بدون صلاحية الإضافة أو التعديل أو الحل).'
                  : 'Read-only overview of weekly and monthly exams for parents.'
                : isStudent
                ? isAr
                  ? 'بوابة حل الاختبارات الأسبوعية والشهرية للطالب والطالبة مع إظهار النتيجة والتوضيح الفوري فور الانتهاء.'
                  : 'Take interactive weekly and monthly exams with instant explanations and score recording.'
                : isAr
                ? 'توليد عشوائي لأسئلة اختيار من متعدد وصح وخطأ مباشرة من الدروس والفيديوهات والملفات المرفقة المسجلة في قاعدة البيانات، مع عرض توضيحي فوري للطالب وإظهار النتيجة فور الانتهاء.'
                : 'Generate randomized MCQ and True/False exams directly from database-stored lessons, videos, and attached files with instant explanations and immediate results.'}
            </p>
          </div>

          {canManageQuizzes && (
            <div className="flex flex-wrap items-center gap-2.5 shrink-0 font-cairo">
              <button
                onClick={() => handleOpenRandomGenerator()}
                disabled={localLessons.length === 0}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-black text-xs md:text-sm bg-amber-400 hover:bg-amber-300 disabled:opacity-45 text-slate-950 transition-all shadow-md"
              >
                <Dices className="w-4 h-4" />
                <span>{isAr ? 'توليد اختبار عشوائي من الدروس' : 'Generate from DB Lessons'}</span>
              </button>

              <button
                onClick={handleOpenCreateBuilder}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm bg-white/15 hover:bg-white/25 text-white border border-white/25 transition-all"
              >
                <Plus className="w-4 h-4 text-amber-300" />
                <span>{isAr ? 'إنشاء اختبار بأسئلة مخصصة' : 'Custom Quiz Builder'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* REAL DATABASE LESSONS, VIDEOS & ATTACHED FILES SOURCE PANEL */}
      {/* ========================================================================= */}
      {canManageQuizzes && (
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm md:text-base font-bold font-cairo text-slate-900 dark:text-white">
                {isAr
                  ? `مصادر التوليد العشوائي من قاعدة البيانات (${localLessons.length} دروس وفيديوهات وملفات)`
                  : `Database Lesson, Video & File Sources (${localLessons.length})`}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? 'اختر درساً أو أكثر (فيديو، ملف PDF/Word مرفق، أو إنفوجرافيك) لتوليد أسئلة اختيار من متعدد وصح وخطأ عشوائياً'
                  : 'Select one or more real database lessons, videos, or files to extract randomized MCQ & True/False questions'}
              </p>
            </div>
          </div>

          {/* Format filter & Selection helpers */}
          <div className="flex flex-wrap items-center gap-1.5 font-cairo text-xs">
            {[
              { id: 'all', label: isAr ? 'الكل' : 'All' },
              { id: 'video', label: isAr ? 'فيديو' : 'Videos' },
              { id: 'pdf', label: 'PDF' },
              { id: 'word', label: 'Word' },
              { id: 'infographic', label: isAr ? 'إنفوجرافيك' : 'Infographic' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setLessonFormatFilter(tab.id as any)}
                className={`px-2.5 py-1.5 rounded-lg font-bold transition-colors ${
                  lessonFormatFilter === tab.id
                    ? 'bg-emerald-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}

            {filteredLessons.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  const allVisibleIds = filteredLessons.map((l) => l.id);
                  const allSelected = allVisibleIds.every((id) => selectedLessonIds.includes(id));
                  setSelectedLessonIds(allSelected ? [] : allVisibleIds);
                }}
                className="px-2.5 py-1.5 rounded-lg font-bold border border-emerald-600 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/40"
              >
                {filteredLessons.every((l) => selectedLessonIds.includes(l.id))
                  ? isAr
                    ? 'إلغاء تحديد الكل'
                    : 'Deselect All'
                  : isAr
                  ? 'تحديد الكل'
                  : 'Select All'}
              </button>
            )}
          </div>
        </div>

        {localLessons.length === 0 ? (
          <div className="p-8 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/30 text-center space-y-3">
            <BookOpen className="w-10 h-10 text-slate-400 mx-auto" />
            <h4 className="font-bold font-cairo text-slate-900 dark:text-white text-sm md:text-base">
              {isAr
                ? 'لا توجد دروس أو فيديوهات أو ملفات مرفقة في قاعدة البيانات بعد'
                : 'No lessons, videos, or attached files in database yet'}
            </h4>
            <p className="text-xs text-slate-500 font-tajawal max-w-lg mx-auto leading-relaxed">
              {isAr
                ? 'تم حذف جميع البيانات الوهمية. أضف دروس فيديو أو ملفات PDF/Word أو دروس إنفوجرافيك حقيقية من قسم «إدارة الدروس والمحاضرات» لتظهر هنا تلقائياً كـمصدر لتوليد الاختبارات العشوائية، أو أنشئ اختباراً مخصصاً الآن.'
                : 'All mock data has been removed. Add real lessons, videos, PDFs, or infographics in Lessons Manager so they appear here for randomized quiz generation.'}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1 font-cairo">
              {onNavigateToLessons && (
                <button
                  type="button"
                  onClick={onNavigateToLessons}
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{isAr ? 'الانتقال لإدارة الدروس لإضافة دروس ومرفقات' : 'Go to Lessons Manager'}</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleOpenCreateBuilder}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAr ? 'إنشاء اختبار مخصص يدوياً' : 'Create Custom Quiz'}</span>
              </button>
            </div>
          </div>
        ) : filteredLessons.length === 0 ? (
          <div className="p-6 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-center text-xs text-slate-500 font-tajawal">
            {isAr
              ? 'لا توجد دروس من هذا النوع في قاعدة البيانات حالياً. جرّب اختيار تصنيف آخر.'
              : 'No lessons of this format in database. Try another filter.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {filteredLessons.map((lesson) => {
              const isSelected = selectedLessonIds.includes(lesson.id);
              const fmtBadge = getFormatBadge(lesson.format);

              return (
                <div
                  key={lesson.id}
                  onClick={() => toggleLessonSelection(lesson.id)}
                  className={`p-4 rounded-xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/30 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-emerald-300'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold font-cairo ${fmtBadge.cls}`}
                      >
                        {fmtBadge.icon}
                        <span>{fmtBadge.label}</span>
                      </span>
                      <span
                        className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs transition-colors ${
                          isSelected
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </span>
                    </div>

                    <h4 className="text-xs md:text-sm font-bold font-cairo text-slate-900 dark:text-white line-clamp-2 leading-snug">
                      {lesson.title}
                    </h4>

                    <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 font-tajawal space-y-0.5">
                      <p className="truncate">
                        {lesson.subject} · {lesson.grade}
                      </p>
                      <p className="truncate">
                        <span className="text-slate-400">{isAr ? 'المعلم:' : 'Teacher:'}</span>{' '}
                        {lesson.teacherName}
                      </p>
                      {(lesson.videoUrl || lesson.documentUrl) && (
                        <p className="truncate font-mono-numbers text-[10px] text-emerald-700 dark:text-emerald-400">
                          📎 {lesson.videoUrl || lesson.documentUrl}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs font-cairo">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreviewingLesson(lesson);
                      }}
                      className="text-emerald-700 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isAr ? 'معاينة' : 'Preview'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenRandomGenerator([lesson.id], 'all');
                      }}
                      className="px-2 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1"
                    >
                      <Dices className="w-3 h-3" />
                      <span>{isAr ? 'سحب عشوائي' : 'Generate'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {selectedLessonIds.length > 0 && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex flex-wrap items-center justify-between gap-2 text-xs font-cairo">
            <span className="font-bold text-emerald-900 dark:text-emerald-200">
              {isAr
                ? `تم تحديد ${selectedLessonIds.length} دروس/مرفقات للتوليد العشوائي`
                : `Selected ${selectedLessonIds.length} DB sources for extraction`}
            </span>
            <button
              type="button"
              onClick={() => handleOpenRandomGenerator()}
              className="px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold flex items-center gap-1.5"
            >
              <Dices className="w-3.5 h-3.5" />
              <span>{isAr ? 'توليد اختبار عشوائي من المحدد' : 'Generate from Selected'}</span>
            </button>
          </div>
        )}
      </div>
      )}

      {/* Filter, Search & Actions Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 font-cairo">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                activeFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {isAr ? `الكل (${localQuizzes.length})` : `All (${localQuizzes.length})`}
            </button>
            <button
              onClick={() => setActiveFilter('weekly')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                activeFilter === 'weekly'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {isAr ? 'أسبوعية' : 'Weekly'}
            </button>
            <button
              onClick={() => setActiveFilter('monthly')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                activeFilter === 'monthly'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {isAr ? 'شهرية' : 'Monthly'}
            </button>
          </div>

          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? 'ابحث باسم الاختبار أو المادة...' : 'Search quizzes...'}
              className="w-full pr-9 pl-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-tajawal text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => syncAllFromDb(false)}
            disabled={isLoadingDb}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDb ? 'animate-spin' : ''}`} />
            <span>{isAr ? 'تحديث من القاعدة' : 'Sync DB'}</span>
          </button>

          {canManageQuizzes && (
            <>
              <button
                onClick={() => handleOpenRandomGenerator()}
                disabled={localLessons.length === 0}
                className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-bold text-xs text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-45 transition-colors shadow-xs"
              >
                <Dices className="w-4 h-4" />
                <span>{isAr ? 'توليد عشوائي من الدروس' : 'Generate from Lessons'}</span>
              </button>

              <button
                onClick={handleOpenCreateBuilder}
                className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-bold text-xs text-white bg-emerald-700 hover:bg-emerald-800 transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إضافة اختبار وأسئلة' : 'New Quiz'}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Quizzes Grid */}
      {filteredQuizzes.length === 0 ? (
        <div className="p-10 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-3">
          <ListChecks className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="font-bold font-cairo text-slate-900 dark:text-white">
            {isAr ? 'لا توجد اختبارات مسجلة في قاعدة البيانات حالياً' : 'No quizzes saved in database yet'}
          </h3>
          <p className="text-xs text-slate-500 font-tajawal max-w-md mx-auto">
            {canManageQuizzes
              ? isAr
                ? 'يمكنك توليد اختبار عشوائي من الدروس والفيديوهات والملفات المرفقة في قاعدة البيانات أو إنشاء اختبار مخصص بأسئلة اختيار من متعدد وصح وخطأ.'
                : 'Generate a randomized quiz from DB lessons or build a custom MCQ & True/False quiz.'
              : isAr
              ? 'لم يقم المعلمون بنشر اختبارات أسبوعية أو شهرية بعد. سيصلك إشعار فوري عند إضافة أي اختبار جديد.'
              : 'No weekly or monthly quizzes published yet.'}
          </p>
          {canManageQuizzes && (
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1 font-cairo">
              {localLessons.length > 0 && (
                <button
                  onClick={() => handleOpenRandomGenerator()}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs"
                >
                  <Dices className="w-4 h-4" />
                  <span>{isAr ? 'توليد اختبار عشوائي من الدروس' : 'Generate from DB Lessons'}</span>
                </button>
              )}
              <button
                onClick={handleOpenCreateBuilder}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إنشاء اختبار بأسئلة مخصصة' : 'Create Custom Quiz'}</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredQuizzes.map((quiz) => {
            const isWeekly = quiz.type === 'weekly';
            const mcqCount = quiz.questions.filter((q) => q.questionType !== 'true_false').length;
            const tfCount = quiz.questions.filter((q) => q.questionType === 'true_false').length;
            const canEditThisQuiz = canManageQuizzes && canTeacherManageQuiz(quiz, currentUser, teachers);

            return (
              <div
                key={quiz.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-400 flex flex-col justify-between transition-all hover:shadow-md"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2.5">
                    <div className="flex flex-wrap items-center gap-1.5 text-xs font-cairo">
                      <span
                        className={`font-bold px-2 py-0.5 rounded-md ${
                          isWeekly
                            ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300'
                            : 'bg-purple-50 text-purple-700 dark:bg-purple-950/70 dark:text-purple-300'
                        }`}
                      >
                        {isWeekly ? (isAr ? 'أسبوعي' : 'Weekly') : isAr ? 'شهري شامل' : 'Monthly'}
                      </span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {quiz.subject}
                      </span>
                    </div>

                    {canEditThisQuiz && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleOpenEditBuilder(quiz)}
                          title={isAr ? 'تعديل الاختبار والأسئلة' : 'Edit quiz'}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setQuizToDelete(quiz)}
                          title={isAr ? 'حذف الاختبار' : 'Delete quiz'}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  <h3 className="text-base font-bold font-cairo text-slate-900 dark:text-white leading-snug">
                    {quiz.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-tajawal mt-1">{quiz.grade}</p>

                  {/* Question Types Breakdown */}
                  <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px] font-cairo">
                    {mcqCount > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold border border-indigo-200/70 dark:border-indigo-800/70">
                        <ListChecks className="w-3 h-3" />
                        <span>
                          {mcqCount} {isAr ? 'اختيار من متعدد' : 'MCQ'}
                        </span>
                      </span>
                    )}
                    {tfCount > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-bold border border-teal-200/70 dark:border-teal-800/70">
                        <CheckSquare className="w-3 h-3" />
                        <span>
                          {tfCount} {isAr ? 'صح وخطأ' : 'T/F'}
                        </span>
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 font-bold border border-amber-200/70 dark:border-amber-800/70">
                      <Lightbulb className="w-3 h-3" />
                      <span>{isAr ? 'توضيح فوري' : 'Instant Hint'}</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs font-mono-numbers text-center">
                    <div>
                      <span className="text-slate-400 block text-[11px] font-tajawal">
                        {isAr ? 'المدة' : 'Duration'}
                      </span>
                      <span className="font-bold text-slate-800 dark:text-slate-200">
                        {quiz.durationMinutes} {isAr ? 'د' : 'm'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px] font-tajawal">
                        {isAr ? 'الدرجة' : 'Marks'}
                      </span>
                      <span className="font-bold text-slate-800 dark:text-slate-200">
                        {quiz.totalMarks}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px] font-tajawal">
                        {isAr ? 'الأسئلة' : 'Questions'}
                      </span>
                      <span className="font-bold text-slate-800 dark:text-slate-200">
                        {quiz.questions.length}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 mt-3 font-mono-numbers font-tajawal">
                    <span>
                      {isAr ? 'أتمه:' : 'Completed:'} {quiz.completedStudentsCount}{' '}
                      {isAr ? 'طالب' : 'students'}
                    </span>
                    <span>
                      {isAr ? 'متوسط الدرجات:' : 'Avg:'} {quiz.averageScore}/{quiz.totalMarks}
                    </span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 font-cairo">
                  {canEditThisQuiz && (
                    <button
                      onClick={() => handleOpenEditBuilder(quiz)}
                      className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'الأسئلة' : 'Questions'}</span>
                    </button>
                  )}

                  {isParent ? (
                    <span className="flex-1 text-center py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-bold">
                      {isAr ? 'للاطلاع والمتابعة فقط' : 'Read-Only View'}
                    </span>
                  ) : (
                    <button
                      onClick={() => handleStartQuiz(quiz)}
                      disabled={quiz.questions.length === 0}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 text-white text-xs font-bold transition-all shadow-xs"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>{isAr ? 'خوض الاختبار تفاعلياً' : 'Take Exam'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
        </>
      )}

      {/* ========================================================================= */}
      {/* MODAL A: CREATE / EDIT QUIZ & MULTI-TYPE QUESTION BUILDER */}
      {/* ========================================================================= */}
      {isBuilderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[93vh] flex flex-col">
            <div className="p-4 bg-gradient-to-r from-emerald-900 to-teal-900 text-white border-b border-emerald-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center">
                  <ListChecks className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base md:text-lg">
                    {editingQuizId
                      ? isAr
                        ? 'تعديل الاختبار وبنك الأسئلة المتنوعة'
                        : 'Edit Quiz & Multi-Format Questions'
                      : isAr
                      ? 'إنشاء اختبار جديد وإضافة أسئلة متنوعة (اختيار من متعدد / صح وخطأ)'
                      : 'Create Quiz with MCQ & True/False Questions'}
                  </h3>
                  <p className="text-xs text-emerald-200 font-tajawal">
                    {isAr
                      ? 'أضف أو عدّل الأسئلة مع التوضيح الفوري للطالب واحفظها مباشرة في قاعدة البيانات'
                      : 'Add or refine MCQ & True/False questions with instant explanations saved to DB'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsBuilderModalOpen(false)}
                className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBuiltQuiz} className="flex-1 overflow-y-auto p-5 space-y-5 text-xs md:text-sm">
              {builderError && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{builderError}</span>
                </div>
              )}

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  {isAr ? '١. البيانات الأساسية للاختبار' : '1. Quiz Metadata'}
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="md:col-span-2">
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                      {isAr ? 'عنوان الاختبار *' : 'Quiz Title *'}
                    </label>
                    <input
                      type="text"
                      value={builderTitle}
                      onChange={(e) => setBuilderTitle(e.target.value)}
                      placeholder={
                        isAr ? 'مثال: اختبار الوحدة الثانية - التفاضل والتكامل' : 'e.g. Unit 2 Assessment'
                      }
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                      {isAr ? 'المادة الدراسية' : 'Subject'}
                    </label>
                    <select
                      value={builderSubject}
                      onChange={(e) => setBuilderSubject(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                    >
                      {Array.from(new Set([...SUBJECT_OPTIONS, ...localLessons.map((l) => l.subject)])).map((sub) => (
                        <option key={sub} value={sub}>
                          {sub}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                      {isAr ? 'الصف الدراسي' : 'Grade'}
                    </label>
                    <select
                      value={builderGrade}
                      onChange={(e) => setBuilderGrade(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                    >
                      {Array.from(new Set([...GRADE_OPTIONS, ...localLessons.map((l) => l.grade)])).map((gr) => (
                        <option key={gr} value={gr}>
                          {gr}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        {isAr ? 'النوع' : 'Type'}
                      </label>
                      <select
                        value={builderType}
                        onChange={(e) => setBuilderType(e.target.value as 'weekly' | 'monthly')}
                        className="w-full px-2.5 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      >
                        <option value="weekly">{isAr ? 'أسبوعي' : 'Weekly'}</option>
                        <option value="monthly">{isAr ? 'شهري' : 'Monthly'}</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        {isAr ? 'المدة (د)' : 'Duration'}
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={builderDuration}
                        onChange={(e) => setBuilderDuration(Number(e.target.value))}
                        className="w-full px-2.5 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        {isAr ? 'الدرجة' : 'Marks'}
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={builderTotalMarks}
                        onChange={(e) => setBuilderTotalMarks(Number(e.target.value))}
                        className="w-full px-2.5 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                      {isAr ? 'تاريخ الاستحقاق' : 'Due Date'}
                    </label>
                    <input
                      type="date"
                      value={builderDueDate}
                      onChange={(e) => setBuilderDueDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                    />
                  </div>

                  <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    <label className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 cursor-pointer">
                      <div>
                        <span className="font-bold text-xs text-slate-800 dark:text-slate-200 block">
                          {isAr ? 'نماذج متعددة عشوائية (نموذج أ / ب / ج)' : 'Random Multi-Forms (A/B/C)'}
                        </span>
                        <span className="text-[10px] text-slate-500 font-tajawal">
                          {isAr
                            ? 'خلط ترتيب الأسئلة والاختيارات تلقائياً لكل طالب'
                            : 'Auto-shuffle questions & options per student'}
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={builderEnableMultiForms}
                        onChange={(e) => setBuilderEnableMultiForms(e.target.checked)}
                        className="w-4 h-4 accent-emerald-600"
                      />
                    </label>

                    <label className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 cursor-pointer">
                      <div>
                        <span className="font-bold text-xs text-slate-800 dark:text-slate-200 block">
                          {isAr ? 'قفل تبديل التبويب (منع الغش)' : 'Tab-Switch Anti-Cheat Warning'}
                        </span>
                        <span className="text-[10px] text-slate-500 font-tajawal">
                          {isAr
                            ? 'تحذير فوري وتسليم تلقائي عند الخروج 3 مرات'
                            : 'Warn on blur/hidden & auto-submit on 3rd'}
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={builderEnableTabSwitchLock}
                        onChange={(e) => setBuilderEnableTabSwitchLock(e.target.checked)}
                        className="w-4 h-4 accent-amber-600"
                      />
                    </label>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      {isAr ? '٢. أسئلة الاختبار والتوضيح الفوري' : '2. Questions & Instant Explanations'}
                    </h4>
                    <p className="text-[11px] text-slate-500 font-tajawal">
                      {isAr
                        ? `الإجمالي: ${builderQuestions.length} أسئلة (${builderMcqCount} اختيار من متعدد · ${builderTfCount} صح وخطأ)`
                        : `Total: ${builderQuestions.length} (${builderMcqCount} MCQ · ${builderTfCount} T/F)`}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsPullBankOpen((p) => !p)}
                      className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <Database className="w-3.5 h-3.5" />
                      <span>{isAr ? '+ سحب من بنك الأسئلة' : '+ Pull from Bank'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setBulkImportError(null);
                        setIsBulkImportOpen((p) => !p);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>{isAr ? '+ استيراد من Excel / Word' : '+ Bulk Import Excel/Word'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAddQuestionToBuilder('mcq')}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <ListChecks className="w-3.5 h-3.5" />
                      <span>{isAr ? '+ سؤال اختيار من متعدد' : '+ Multiple Choice'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAddQuestionToBuilder('true_false')}
                      className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <CheckSquare className="w-3.5 h-3.5" />
                      <span>{isAr ? '+ سؤال صح وخطأ' : '+ True / False'}</span>
                    </button>
                  </div>
                </div>

                {isPullBankOpen && (
                  <div className="p-4 rounded-xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-300 dark:border-sky-800 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-cairo font-bold text-xs text-sky-900 dark:text-sky-200 flex items-center gap-1.5">
                        <Database className="w-4 h-4 text-sky-600" />
                        {isAr ? 'سحب أسئلة عشوائية من بنك الأسئلة دون تكرار الأسئلة الموجودة:' : 'Pull Unique Questions from Bank'}
                      </span>
                      <button type="button" onClick={() => setIsPullBankOpen(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                      <select
                        value={pullDifficulty}
                        onChange={(e) => setPullDifficulty(e.target.value as any)}
                        className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-sky-200 dark:border-slate-700 font-cairo"
                      >
                        <option value="all">{isAr ? 'كل مستويات الصعوبة' : 'All Difficulties'}</option>
                        <option value="easy">{isAr ? 'سهل' : 'Easy'}</option>
                        <option value="medium">{isAr ? 'متوسط' : 'Medium'}</option>
                        <option value="advanced">{isAr ? 'متقدم' : 'Advanced'}</option>
                        <option value="gifted">{isAr ? 'متفوقين' : 'Gifted'}</option>
                      </select>
                      <input
                        type="number"
                        min={1}
                        max={30}
                        value={pullCount}
                        onChange={(e) => setPullCount(Math.max(1, Number(e.target.value) || 5))}
                        className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-sky-200 dark:border-slate-700 font-mono-numbers"
                        placeholder={isAr ? 'عدد الأسئلة' : 'Count'}
                      />
                      <button
                        type="button"
                        disabled={isPullingBank}
                        onClick={async () => {
                          setIsPullingBank(true);
                          setBuilderError(null);
                          try {
                            const res = await fetch('/api/question-bank/pull', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
                              body: JSON.stringify({
                                subject: builderSubject,
                                grade: builderGrade,
                                difficulty: pullDifficulty,
                                count: pullCount,
                                excludeIds: builderQuestions.map((q) => q.bankQuestionId).filter(Boolean),
                                excludeQuestionTexts: builderQuestions.map((q) => q.question),
                              }),
                            });
                            const data = await res.json();
                            if (!res.ok) throw new Error(data.error || 'تعذر السحب');
                            const pulled: QuestionBankItem[] = Array.isArray(data.questions) ? data.questions : [];
                            if (pulled.length === 0) {
                              setBuilderError(isAr ? 'لم يتم العثور على أسئلة جديدة غير مكررة في البنك تطابق هذه المادة والصعوبة.' : 'No new unique matching questions in bank.');
                            } else {
                              setBuilderQuestions((prev) => [
                                ...prev,
                                ...pulled.map((p, i) => ({
                                  id: `qb-pull-${Date.now()}-${i}`,
                                  bankQuestionId: p.id,
                                  questionType: p.questionType,
                                  question: p.question,
                                  options: p.options,
                                  correctOptionIndex: p.correctOptionIndex,
                                  explanation: p.explanation,
                                  points: p.points,
                                  difficulty: p.difficulty,
                                  unit: p.unit,
                                })),
                              ]);
                              setIsPullBankOpen(false);
                            }
                          } catch (err: any) {
                            setBuilderError(err.message || 'تعذر السحب من البنك');
                          } finally {
                            setIsPullingBank(false);
                          }
                        }}
                        className="px-4 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-cairo font-bold cursor-pointer"
                      >
                        {isPullingBank ? (isAr ? 'جاري السحب...' : 'Pulling...') : (isAr ? 'سحب وإضافة للاختبار' : 'Pull & Append')}
                      </button>
                    </div>
                  </div>
                )}

                {isBulkImportOpen && (
                  <div className="p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border-2 border-amber-300 dark:border-amber-700 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h5 className="font-bold text-xs md:text-sm text-amber-950 dark:text-amber-200 flex items-center gap-1.5">
                          <Upload className="w-4 h-4 text-amber-600" />
                          <span>
                            {isAr
                              ? 'استيراد دفعة أسئلة من جدول Excel / CSV أو مستند Word'
                              : 'Bulk Import Questions from Excel / CSV / Word'}
                          </span>
                        </h5>
                        <p className="text-[11px] text-amber-800 dark:text-amber-300 font-tajawal mt-0.5">
                          {isAr
                            ? 'الصق الصفوف مباشرة من Excel أو ملف Word أو ارفع ملف CSV بصيغة: السؤال | خيار1 | خيار2 | خيار3 | خيار4 | رقم_الإجابة_الصحيحة | التفسير'
                            : 'Paste from Excel/Word or upload CSV: Question | Opt1 | Opt2 | Opt3 | Opt4 | Correct(1-4) | Explanation'}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => downloadBulkQuestionsSampleCsv()}
                          className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-amber-300 text-amber-900 dark:text-amber-200 font-bold text-[11px] flex items-center gap-1"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>{isAr ? 'تحميل نموذج CSV' : 'Sample CSV'}</span>
                        </button>
                        <label className="px-2.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer">
                          <Upload className="w-3.5 h-3.5" />
                          <span>{isAr ? 'رفع ملف CSV/TXT' : 'Upload File'}</span>
                          <input
                            type="file"
                            accept=".csv,.tsv,.txt"
                            className="hidden"
                            onChange={(e) => {
                              const f = e.target.files?.[0];
                              if (!f) return;
                              const reader = new FileReader();
                              reader.onload = () => {
                                setBulkRawText(String(reader.result || ''));
                                setBulkImportError(null);
                              };
                              reader.readAsText(f, 'UTF-8');
                              e.target.value = '';
                            }}
                          />
                        </label>
                      </div>
                    </div>

                    <textarea
                      rows={5}
                      value={bulkRawText}
                      onChange={(e) => {
                        setBulkRawText(e.target.value);
                        setBulkImportError(null);
                      }}
                      placeholder={
                        isAr
                          ? 'مثال Excel/CSV:\nما عاصمة مصر؟ | القاهرة | الإسكندرية | الجيزة | أسوان | 1 | القاهرة هي عاصمة جمهورية مصر العربية\n\nأو مثال Word:\nالسؤال: ما ناتج 5 × 6؟\nأ) 25\nب) 30\nج) 35\nد) 40\nالإجابة: ب\nالتفسير: 5 × 6 = 30'
                          : 'Paste Excel/CSV rows or Word question blocks here...'
                      }
                      className="w-full p-3 rounded-xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 text-xs font-tajawal text-slate-900 dark:text-white"
                    />

                    {bulkImportError && (
                      <p className="text-xs font-bold text-rose-600">{bulkImportError}</p>
                    )}

                    {(() => {
                      const previewResult = bulkRawText.trim()
                        ? parseBulkQuestionsText(bulkRawText)
                        : { questions: [], errors: [] };
                      return (
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                            {previewResult.questions.length > 0
                              ? isAr
                                ? `تم التعرف بنجاح على (${previewResult.questions.length}) سؤال جاهز للاستيراد ✓`
                                : `Parsed ${previewResult.questions.length} question(s) ready ✓`
                              : isAr
                              ? 'أدخل أو ارفع الأسئلة لمعاينتها قبل الإضافة'
                              : 'Paste or upload questions to preview'}
                          </span>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setIsBulkImportOpen(false)}
                              className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-bold"
                            >
                              {isAr ? 'إغلاق' : 'Close'}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (previewResult.questions.length === 0) {
                                  setBulkImportError(
                                    previewResult.errors[0] ||
                                      (isAr ? 'لم يتم العثور على أسئلة صالحة' : 'No valid questions found')
                                  );
                                  return;
                                }
                                setBuilderQuestions((prev) => {
                                  const cleaned = prev.filter((item) => item.question.trim().length > 0);
                                  return [...cleaned, ...previewResult.questions];
                                });
                                setIsBulkImportOpen(false);
                                setBulkRawText('');
                                showToast(
                                  isAr
                                    ? `تم استيراد ${previewResult.questions.length} سؤال داخل الاختبار بنجاح ✓`
                                    : `Imported ${previewResult.questions.length} questions ✓`
                                );
                              }}
                              className="px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs"
                            >
                              {isAr ? 'تأكيد واستيراد الأسئلة' : 'Confirm Import'}
                            </button>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}

                <div className="space-y-4">
                  {builderQuestions.map((q, qIdx) => {
                    const isTf = q.questionType === 'true_false';
                    return (
                      <div
                        key={q.id}
                        className={`p-4 rounded-xl border space-y-3 ${
                          isTf
                            ? 'border-teal-200 dark:border-teal-800/80 bg-teal-50/30 dark:bg-teal-950/15'
                            : 'border-indigo-200 dark:border-indigo-800/80 bg-indigo-50/30 dark:bg-indigo-950/15'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/70 dark:border-slate-700/60 pb-2.5">
                          <div className="flex items-center gap-2">
                            <span className="w-7 h-7 rounded-lg bg-slate-900 dark:bg-slate-800 text-white font-mono-numbers font-bold text-xs flex items-center justify-center">
                              {qIdx + 1}
                            </span>

                            <div className="inline-flex rounded-lg p-0.5 bg-slate-200/80 dark:bg-slate-800 text-[11px] font-bold">
                              <button
                                type="button"
                                onClick={() => handleSwitchQuestionType(qIdx, 'mcq')}
                                className={`px-2.5 py-1 rounded-md transition-colors ${
                                  !isTf
                                    ? 'bg-indigo-600 text-white shadow-xs'
                                    : 'text-slate-600 dark:text-slate-300'
                                }`}
                              >
                                {isAr ? 'اختيار من متعدد' : 'MCQ'}
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSwitchQuestionType(qIdx, 'true_false')}
                                className={`px-2.5 py-1 rounded-md transition-colors ${
                                  isTf
                                    ? 'bg-teal-600 text-white shadow-xs'
                                    : 'text-slate-600 dark:text-slate-300'
                                }`}
                              >
                                {isAr ? 'صح وخطأ' : 'True / False'}
                              </button>
                            </div>
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleMoveQuestion(qIdx, -1)}
                              disabled={qIdx === 0}
                              className="p-1.5 rounded-lg text-slate-500 hover:bg-white dark:hover:bg-slate-800 disabled:opacity-30"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleMoveQuestion(qIdx, 1)}
                              disabled={qIdx === builderQuestions.length - 1}
                              className="p-1.5 rounded-lg text-slate-500 hover:bg-white dark:hover:bg-slate-800 disabled:opacity-30"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDuplicateQuestion(qIdx)}
                              className="p-1.5 rounded-lg text-slate-500 hover:bg-white dark:hover:bg-slate-800"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveQuestionFromBuilder(qIdx)}
                              className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/60"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                            {isAr ? 'نص السؤال *' : 'Question Prompt *'}
                          </label>
                          <input
                            type="text"
                            value={q.question}
                            onChange={(e) =>
                              handleUpdateQuestionField(qIdx, { question: e.target.value })
                            }
                            placeholder={
                              isTf
                                ? isAr
                                  ? 'اكتب عبارة ليحدد الطالب هل هي صحيحة أم خاطئة...'
                                  : 'Enter True/False statement...'
                                : isAr
                                ? 'اكتب نص سؤال الاختيار من متعدد...'
                                : 'Enter MCQ prompt...'
                            }
                            className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-semibold"
                          />
                        </div>

                        {isTf ? (
                          <div>
                            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 text-xs">
                              {isAr ? 'اختر الإجابة الصحيحة:' : 'Select Correct Answer:'}
                            </label>
                            <div className="grid grid-cols-2 gap-3">
                              {[
                                {
                                  idx: 0,
                                  label: isAr ? 'صح ✓' : 'True ✓',
                                  activeCls:
                                    'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200',
                                },
                                {
                                  idx: 1,
                                  label: isAr ? 'خطأ ✗' : 'False ✗',
                                  activeCls:
                                    'border-rose-500 bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200',
                                },
                              ].map((choice) => {
                                const isChecked = q.correctOptionIndex === choice.idx;
                                return (
                                  <button
                                    key={choice.idx}
                                    type="button"
                                    onClick={() =>
                                      handleUpdateQuestionField(qIdx, {
                                        correctOptionIndex: choice.idx,
                                      })
                                    }
                                    className={`p-3 rounded-xl border-2 font-bold text-sm flex items-center justify-between transition-all ${
                                      isChecked
                                        ? choice.activeCls
                                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
                                    }`}
                                  >
                                    <span>{choice.label}</span>
                                    {isChecked && (
                                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-white/80 dark:bg-slate-900/70">
                                        {isAr ? 'الإجابة المعتمدة' : 'Correct'}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <label className="font-bold text-slate-700 dark:text-slate-300 text-xs">
                                {isAr
                                  ? 'الخيارات (انقر على الحرف لتحديد الإجابة الصحيحة):'
                                  : 'Options (click badge to set correct):'}
                              </label>
                              {q.options.length < 6 && (
                                <button
                                  type="button"
                                  onClick={() => handleAddMcqOption(qIdx)}
                                  className="text-[11px] font-bold text-indigo-700 dark:text-indigo-400 hover:underline"
                                >
                                  {isAr ? '+ إضافة خيار' : '+ Add Option'}
                                </button>
                              )}
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {q.options.map((opt, optIdx) => {
                                const isCorrect = q.correctOptionIndex === optIdx;
                                const letter = isAr
                                  ? OPTION_LETTERS_AR[optIdx] || optIdx + 1
                                  : OPTION_LETTERS_EN[optIdx] || optIdx + 1;
                                return (
                                  <div
                                    key={optIdx}
                                    className={`flex items-center gap-2 p-1.5 rounded-xl border bg-white dark:bg-slate-900 ${
                                      isCorrect
                                        ? 'border-emerald-500 ring-1 ring-emerald-500/30'
                                        : 'border-slate-200 dark:border-slate-700'
                                    }`}
                                  >
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleUpdateQuestionField(qIdx, {
                                          correctOptionIndex: optIdx,
                                        })
                                      }
                                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                                        isCorrect
                                          ? 'bg-emerald-600 text-white'
                                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                                      }`}
                                    >
                                      {isCorrect ? <Check className="w-3.5 h-3.5" /> : letter}
                                    </button>
                                    <input
                                      type="text"
                                      value={opt}
                                      onChange={(e) =>
                                        handleUpdateMcqOptionText(qIdx, optIdx, e.target.value)
                                      }
                                      placeholder={`${isAr ? 'الخيار' : 'Option'} ${letter}`}
                                      className="flex-1 bg-transparent text-xs font-tajawal text-slate-900 dark:text-white focus:outline-none"
                                    />
                                    {q.options.length > 2 && (
                                      <button
                                        type="button"
                                        onClick={() => handleRemoveMcqOption(qIdx, optIdx)}
                                        className="p-1 text-slate-400 hover:text-rose-500"
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        <div>
                          <label className="flex items-center gap-1.5 font-bold text-amber-800 dark:text-amber-300 mb-1 text-xs">
                            <Lightbulb className="w-3.5 h-3.5" />
                            <span>
                              {isAr
                                ? 'العرض التوضيحي الفوري للطالب (يظهر فور اختيار الإجابة):'
                                : 'Instant Explanation Shown to Student:'}
                            </span>
                          </label>
                          <textarea
                            rows={2}
                            value={q.explanation}
                            onChange={(e) =>
                              handleUpdateQuestionField(qIdx, { explanation: e.target.value })
                            }
                            placeholder={
                              isAr
                                ? 'اشرح سبب صحة الإجابة النموذجية ليظهر للطالب فوراً...'
                                : 'Explain why the answer is correct...'
                            }
                            className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800/70 text-slate-900 dark:text-white font-tajawal text-xs"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
                <span className="text-xs text-slate-500 font-tajawal">
                  {isAr
                    ? 'يتم حفظ الاختبار وجميع الأسئلة مباشرة في قاعدة البيانات.'
                    : 'Quiz and questions are saved directly to database.'}
                </span>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsBuilderModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-bold text-xs"
                  >
                    {isAr ? 'إلغاء' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingDb}
                    className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-black text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>
                      {isSavingDb
                        ? isAr
                          ? 'جاري الحفظ...'
                          : 'Saving...'
                        : editingQuizId
                        ? isAr
                          ? 'حفظ التعديلات في القاعدة'
                          : 'Save Changes'
                        : isAr
                        ? 'حفظ ونشر الاختبار'
                        : 'Save & Publish Quiz'}
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL B: DELETE QUIZ CONFIRMATION */}
      {/* ========================================================================= */}
      {quizToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  {isAr ? 'تأكيد حذف الاختبار نهائياً' : 'Confirm Quiz Deletion'}
                </h3>
                <p className="text-xs text-slate-500 font-tajawal mt-0.5">
                  {isAr
                    ? 'سيتم حذف الاختبار وكافة أسئلته من قاعدة البيانات.'
                    : 'This quiz and its questions will be permanently removed from database.'}
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200">
              {quizToDelete.title} ({quizToDelete.questions.length} {isAr ? 'أسئلة' : 'questions'})
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setQuizToDelete(null)}
                disabled={isDeletingDb}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold"
              >
                {isAr ? 'تراجع' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmDeleteQuiz}
                disabled={isDeletingDb}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeletingDb ? (isAr ? 'جاري الحذف...' : 'Deleting...') : isAr ? 'نعم، احذف الاختبار' : 'Delete Quiz'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: REAL DB RANDOMIZED QUESTION EXTRACTION FROM LESSONS/VIDEOS/FILES */}
      {/* ========================================================================= */}
      {isGeneratorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[93vh] flex flex-col">
            <div className="p-4 bg-gradient-to-r from-emerald-900 to-teal-900 text-white border-b border-emerald-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-900 flex items-center justify-center">
                  <Dices className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base md:text-lg leading-snug">
                    {isAr
                      ? 'محرك توليد الاختبار العشوائي من الدروس والفيديوهات والملفات (من قاعدة البيانات)'
                      : 'Database Randomized Exam Generator (Lessons, Videos & Attached Files)'}
                  </h3>
                  <p className="text-xs text-emerald-200 font-tajawal">
                    {isAr
                      ? 'يستخرج أسئلة اختيار من متعدد وصح وخطأ عشوائياً مباشرة من سجلات الدروس والمرفقات في قاعدة البيانات'
                      : 'Extracts randomized MCQ & True/False questions directly from database lessons & files'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsGeneratorModalOpen(false)}
                className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePublishGeneratedQuiz} className="flex-1 overflow-y-auto p-5 space-y-5 text-xs md:text-sm">
              {/* Source Lessons Selector */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-800 dark:text-slate-200">
                    {isAr
                      ? '١. الدروس والفيديوهات والملفات المرفقة من قاعدة البيانات:'
                      : '1. Real DB Lessons, Videos & Attached Files:'}
                  </label>
                  <span className="text-[11px] text-slate-500 font-tajawal">
                    {selectedLessonIds.length > 0
                      ? isAr
                        ? `محدد (${selectedLessonIds.length}) — اضغط على أي درس لتبديل التحديد`
                        : `Selected (${selectedLessonIds.length})`
                      : isAr
                      ? `سيتم السحب من كافة الدروس (${localLessons.length})`
                      : `Drawing from all (${localLessons.length}) lessons`}
                  </span>
                </div>

                {localLessons.length === 0 ? (
                  <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs font-tajawal">
                    {isAr
                      ? 'قاعدة البيانات لا تحتوي على دروس بعد. أضف دروس فيديو أو ملفات مرفقة أولاً من قسم إدارة الدروس.'
                      : 'No lessons found in DB yet. Add lessons first in Lessons Manager.'}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
                    {localLessons.map((l) => {
                      const checked = selectedLessonIds.includes(l.id);
                      const fmtBadge = getFormatBadge(l.format);
                      return (
                        <div
                          key={l.id}
                          onClick={() => toggleLessonSelection(l.id)}
                          className={`p-2.5 rounded-xl border text-right cursor-pointer transition-all flex items-center justify-between gap-2 ${
                            checked
                              ? 'border-emerald-600 bg-emerald-50/80 dark:bg-emerald-950/40 ring-1 ring-emerald-500/30'
                              : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40'
                          }`}
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 mb-0.5">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${fmtBadge.cls}`}>
                                {fmtBadge.label}
                              </span>
                              <span className="text-[11px] text-slate-500 truncate">{l.subject}</span>
                            </div>
                            <p className="font-bold text-xs truncate text-slate-900 dark:text-white">
                              {l.title}
                            </p>
                          </div>
                          <span
                            className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 ${
                              checked
                                ? 'bg-emerald-600 border-emerald-600 text-white'
                                : 'border-slate-300 dark:border-slate-600'
                            }`}
                          >
                            {checked && <Check className="w-3.5 h-3.5" />}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Extraction & Randomization Settings */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <span className="font-bold text-slate-900 dark:text-white">
                      {isAr ? '٢. خصائص التوليد العشوائي من القاعدة' : '2. Random Extraction Settings'}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => runDbRandomGeneration()}
                    disabled={isGeneratingFromDb || localLessons.length === 0}
                    className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-45 text-slate-950 font-black text-xs shadow-sm"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingFromDb ? 'animate-spin' : ''}`} />
                    <span>{isAr ? '🎲 سحب عشوائي جديد الآن' : 'Re-shuffle from DB'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                      {isAr ? 'تصنيف المصدر' : 'Source Type'}
                    </label>
                    <select
                      value={genFormatFilter}
                      onChange={(e) => {
                        const fmt = e.target.value as any;
                        setGenFormatFilter(fmt);
                        runDbRandomGeneration({ formatFilter: fmt });
                      }}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    >
                      <option value="all">{isAr ? 'الكل (فيديو + ملفات + إنفوجرافيك)' : 'All Sources'}</option>
                      <option value="video">{isAr ? 'دروس الفيديو فقط' : 'Videos Only'}</option>
                      <option value="pdf">{isAr ? 'ملفات PDF المرفقة فقط' : 'PDF Files Only'}</option>
                      <option value="word">{isAr ? 'مستندات Word المرفقة فقط' : 'Word Files Only'}</option>
                      <option value="infographic">{isAr ? 'دروس الإنفوجرافيك فقط' : 'Infographics Only'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                      {isAr ? 'أنواع الأسئلة' : 'Question Mix'}
                    </label>
                    <select
                      value={genQuestionMix}
                      onChange={(e) => {
                        const mix = e.target.value as any;
                        setGenQuestionMix(mix);
                        runDbRandomGeneration({ questionMix: mix });
                      }}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    >
                      <option value="mixed">{isAr ? 'مختلط (اختيار من متعدد + صح وخطأ)' : 'Mixed (MCQ + T/F)'}</option>
                      <option value="mcq">{isAr ? 'اختيار من متعدد فقط' : 'MCQ Only'}</option>
                      <option value="true_false">{isAr ? 'صح وخطأ فقط' : 'True / False Only'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                      {isAr ? 'عدد الأسئلة المطلوبة' : 'Questions Count'}
                    </label>
                    <select
                      value={genQuestionsCount}
                      onChange={(e) => {
                        const cnt = Number(e.target.value);
                        setGenQuestionsCount(cnt);
                        runDbRandomGeneration({ count: cnt });
                      }}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                    >
                      <option value={3}>3 {isAr ? 'أسئلة' : 'Questions'}</option>
                      <option value={5}>5 {isAr ? 'أسئلة' : 'Questions'}</option>
                      <option value={8}>8 {isAr ? 'أسئلة' : 'Questions'}</option>
                      <option value={10}>10 {isAr ? 'أسئلة' : 'Questions'}</option>
                      <option value={15}>15 {isAr ? 'سؤالاً' : 'Questions'}</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                        {isAr ? 'المدة (د)' : 'Min'}
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={genDuration}
                        onChange={(e) => setGenDuration(Number(e.target.value))}
                        className="w-full px-2.5 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                        {isAr ? 'الدرجة' : 'Marks'}
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={genTotalMarks}
                        onChange={(e) => setGenTotalMarks(Number(e.target.value))}
                        className="w-full px-2.5 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                      {isAr ? 'عنوان الاختبار' : 'Exam Title'}
                    </label>
                    <input
                      type="text"
                      value={genTitle}
                      onChange={(e) => setGenTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs md:text-sm font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1 text-xs">
                      {isAr ? 'التصنيف' : 'Type'}
                    </label>
                    <select
                      value={genQuizType}
                      onChange={(e) => setGenQuizType(e.target.value as 'weekly' | 'monthly')}
                      className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                    >
                      <option value="weekly">{isAr ? 'أسبوعي' : 'Weekly'}</option>
                      <option value="monthly">{isAr ? 'شهري' : 'Monthly'}</option>
                    </select>
                  </div>
                </div>
              </div>

              {genError && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{genError}</span>
                </div>
              )}

              {/* Preview Extracted Questions */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs md:text-sm flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '٣. الأسئلة المستخرجة عشوائياً من الدروس والمرفقات:'
                        : '3. Randomly Generated Questions from DB:'}
                    </span>
                  </h4>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-mono-numbers font-bold">
                    {extractedQuestions.length} {isAr ? 'أسئلة' : 'Questions'}
                  </span>
                </div>

                {isGeneratingFromDb ? (
                  <div className="py-10 flex flex-col items-center justify-center text-center space-y-2 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-300">
                    <Dices className="w-8 h-8 text-emerald-600 animate-spin" />
                    <p className="font-bold text-xs text-slate-600 dark:text-slate-300">
                      {isAr
                        ? 'جاري استخراج الأسئلة عشوائياً من قاعدة بيانات الدروس والمرفقات...'
                        : 'Generating randomized questions from DB lessons...'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                    {extractedQuestions.map((q, idx) => (
                      <div
                        key={q.id || idx}
                        className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs space-y-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-bold text-slate-900 dark:text-white leading-relaxed">
                            <span className="text-emerald-600 font-mono-numbers ml-1">#{idx + 1}</span>
                            {q.question}
                          </p>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {q.sourceLessonTitle && (
                              <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold">
                                {q.sourceLessonTitle}
                              </span>
                            )}
                            <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold">
                              {q.questionType === 'true_false'
                                ? isAr
                                  ? 'صح وخطأ'
                                  : 'T/F'
                                : isAr
                                ? 'اختيار من متعدد'
                                : 'MCQ'}
                            </span>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1.5 font-tajawal text-[11px]">
                          {q.options.map((opt, oI) => {
                            const optCls = getMcqOptionSurfaceClass(oI, {
                              isChecked: oI === q.correctOptionIndex,
                              isCorrect: oI === q.correctOptionIndex,
                            });
                            return (
                              <span
                                key={oI}
                                className={`px-2.5 py-1 rounded-lg border ${optCls}`}
                              >
                                {opt} {oI === q.correctOptionIndex && '✓'}
                              </span>
                            );
                          })}
                        </div>
                        <p className="text-[11px] text-slate-500 font-tajawal">
                          <strong className="text-amber-700 dark:text-amber-400">
                            {isAr ? 'التوضيح الفوري:' : 'Explanation:'}
                          </strong>{' '}
                          {q.explanation}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                {extractedQuestions.length > 0 ? (
                  <button
                    type="button"
                    onClick={handleCustomizeGeneratedInBuilder}
                    className="px-4 py-2 rounded-xl border border-indigo-500 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center gap-1.5 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isAr ? 'تعديل الأسئلة في المحرر قبل النشر' : 'Customize in Builder'}</span>
                  </button>
                ) : (
                  <span />
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsGeneratorModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs"
                  >
                    {isAr ? 'إلغاء' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingDb || extractedQuestions.length === 0}
                    className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-45 text-white font-black text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>
                      {isSavingDb
                        ? isAr
                          ? 'جاري الحفظ...'
                          : 'Publishing...'
                        : isAr
                        ? 'حفظ ونشر في قاعدة البيانات'
                        : 'Publish to DB'}
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: PREVIEW REAL LESSON SOURCE MODAL */}
      {/* ========================================================================= */}
      {previewingLesson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/80">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm md:text-base">
                  {previewingLesson.title}
                </h3>
                <p className="text-xs text-slate-500 font-tajawal">
                  {previewingLesson.subject} · {previewingLesson.grade} · {previewingLesson.teacherName}
                </p>
              </div>
              <button
                onClick={() => setPreviewingLesson(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative p-5 overflow-y-auto space-y-4 text-xs md:text-sm font-tajawal">
              <AlSharifWatermark extraLabel={previewingLesson.title} opacity="light" />
              {previewingLesson.description && hasMeaningfulHtmlContent(previewingLesson.description) && (
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <strong className="font-cairo text-slate-900 dark:text-white block mb-1">
                    {isAr ? 'ملخص الدرس والأهداف التعليمية:' : 'Description:'}
                  </strong>
                  {hasHtmlMarkup(previewingLesson.description) ? (
                    <div
                      className="ck-rich-content text-slate-700 dark:text-slate-200"
                      dangerouslySetInnerHTML={{ __html: previewingLesson.description }}
                    />
                  ) : (
                    <p className="text-slate-600 dark:text-slate-300 whitespace-pre-line">{previewingLesson.description}</p>
                  )}
                </div>
              )}

              {(previewingLesson.videoUrl || previewingLesson.documentUrl) && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 font-mono-numbers text-xs">
                  <strong>{isAr ? 'الرابط / الملف المرفق:' : 'Attachment:'}</strong>{' '}
                  {previewingLesson.videoUrl || previewingLesson.documentUrl}
                </div>
              )}

              {previewingLesson.infographicData?.sections?.length ? (
                <div className="space-y-2">
                  <h4 className="font-bold font-cairo text-slate-900 dark:text-white">
                    {isAr ? 'محاور الإنفوجرافيك المستخرجة:' : 'Infographic Sections:'}
                  </h4>
                  {previewingLesson.infographicData.sections.map((sec, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                    >
                      <p className="font-bold font-cairo text-emerald-700 dark:text-emerald-400">
                        {sec.title}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                        {sec.description}
                      </p>
                    </div>
                  ))}
                </div>
              ) : null}

              {previewingLesson.contentHtml && (
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-600 dark:text-slate-300 whitespace-pre-line">
                  {stripHtmlForPreview(previewingLesson.contentHtml)}
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => {
                  const id = previewingLesson.id;
                  setPreviewingLesson(null);
                  handleOpenRandomGenerator([id], 'all');
                }}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Dices className="w-3.5 h-3.5" />
                <span>{isAr ? 'توليد اختبار عشوائي من هذا الدرس' : 'Generate Quiz from Lesson'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: INTERACTIVE STUDENT TEST-TAKING RUNNER (INSTANT EXPLANATION + RESULT) */}
      {/* ========================================================================= */}
      {activeQuizToTake && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[93vh] flex flex-col">
            <div className="p-4 bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white border-b border-emerald-800 flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold text-sm md:text-base truncate">
                    {activeQuizToTake.title}
                  </h3>
                  {activeQuizToTake.enableMultiForms !== false && (
                    <span className="px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[11px]">
                      {isAr ? `نموذج ${examFormLabel}` : `Form ${examFormLabel}`}
                    </span>
                  )}
                </div>
                <span className="text-xs text-emerald-200 font-tajawal">
                  {activeQuizToTake.subject} · {activeQuizToTake.grade}
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0 flex-wrap">
                {!isTestSubmitted && (
                  <>
                    <button
                      type="button"
                      onClick={() => setShowRunnerCodeSandbox((p) => !p)}
                      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition-colors ${
                        showRunnerCodeSandbox
                          ? 'bg-amber-400 text-slate-950 border-amber-300'
                          : 'bg-white/10 border-white/20 text-emerald-100 hover:bg-white/20'
                      }`}
                    >
                      <Code2 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'مختبر الأكواد' : 'Code Sandbox'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setInstantFeedbackEnabled((prev) => !prev)}
                      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition-colors ${
                        instantFeedbackEnabled
                          ? 'bg-emerald-500/25 border-emerald-400/50 text-emerald-100'
                          : 'bg-white/10 border-white/20 text-slate-300'
                      }`}
                    >
                      {instantFeedbackEnabled ? (
                        <ToggleRight className="w-4 h-4 text-emerald-300" />
                      ) : (
                        <ToggleLeft className="w-4 h-4 text-slate-400" />
                      )}
                      <span>{isAr ? 'التوضيح الفوري' : 'Instant Explain'}</span>
                    </button>

                    <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400/20 text-amber-300 font-mono-numbers font-black text-xs border border-amber-400/30">
                      <Clock className="w-4 h-4 text-amber-400" />
                      <span>{formatSeconds(timeLeft)}</span>
                    </div>
                  </>
                )}

                <button
                  onClick={() => setActiveQuizToTake(null)}
                  className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {tabSwitchWarningBanner && !isTestSubmitted && (
              <div className="px-4 py-2.5 bg-rose-600 text-white text-xs font-bold flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{tabSwitchWarningBanner}</span>
                </div>
                <span className="font-mono-numbers bg-rose-800 px-2 py-0.5 rounded">
                  {tabSwitchCount}/3
                </span>
              </div>
            )}

            <div className="p-5 md:p-6 overflow-y-auto space-y-5 flex-1">
              {showRunnerCodeSandbox && !isTestSubmitted && (
                <LiveCodeSandbox
                  compact
                  title={
                    isAr
                      ? `مختبر الأكواد التفاعلي — ${activeQuizToTake.subject}`
                      : `Live Code Sandbox — ${activeQuizToTake.subject}`
                  }
                  initialLanguage={
                    /python|بايثون/i.test(activeQuizToTake.subject)
                      ? 'python'
                      : /css|html|ويب/i.test(activeQuizToTake.subject)
                      ? 'html'
                      : 'javascript'
                  }
                  onClose={() => setShowRunnerCodeSandbox(false)}
                />
              )}
              {!isTestSubmitted && (
                <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 font-bold text-emerald-900 dark:text-emerald-200">
                    <Award className="w-4 h-4 text-amber-500 shrink-0" />
                    <span>
                      {isAr
                        ? 'ربط النتيجة بملف الطالب (لإصدار الشهادة وبيان الدرجات أوتوماتيك):'
                        : 'Link exam score to DB Student (for Auto-Certificate & Transcript):'}
                    </span>
                  </div>
                  {localStudents.length > 0 ? (
                    <select
                      value={examTakerStudentId}
                      onChange={(e) => setExamTakerStudentId(e.target.value)}
                      disabled={Boolean(
                        currentUser?.studentId && localStudents.some((s) => s.id === currentUser.studentId)
                      )}
                      className="w-full sm:w-auto sm:min-w-[220px] px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-slate-900 dark:text-white font-bold text-xs"
                    >
                      <option value="">
                        {isAr ? '-- اختر الطالب من قاعدة البيانات --' : '-- Select Student --'}
                      </option>
                      {localStudents.map((stu) => (
                        <option key={stu.id} value={stu.id}>
                          {stu.name} ({stu.code} · {stu.grade})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className="text-[11px] text-amber-700 dark:text-amber-300 font-tajawal">
                      {isAr
                        ? 'لا يوجد طلاب مسجلون في قاعدة البيانات بعد (أضف طلاباً أولاً لربط الدرجة والشهادة).'
                        : 'No DB students yet.'}
                    </span>
                  )}
                </div>
              )}

              {!isTestSubmitted ? (
                (() => {
                  const currentQ = activeQuizToTake.questions[currentQuestionIdx];
                  const isTf = currentQ.questionType === 'true_false';
                  const selectedIdx = selectedAnswers[currentQuestionIdx];
                  const isAnswered = selectedIdx !== undefined;
                  const showInstantBox =
                    isAnswered && (instantFeedbackEnabled || revealedQuestions[currentQuestionIdx]);
                  const isCurrentCorrect = selectedIdx === currentQ.correctOptionIndex;
                  const totalQuestionsCount = activeQuizToTake.questions.length;
                  const answeredQuestionsCount = Object.keys(selectedAnswers).length;
                  const remainingQuestionsCount = Math.max(
                    0,
                    totalQuestionsCount - answeredQuestionsCount
                  );
                  const progressPercentage =
                    totalQuestionsCount > 0
                      ? Math.round((answeredQuestionsCount / totalQuestionsCount) * 100)
                      : 0;

                  return (
                    <div className="space-y-5">
                      {/* Visual Progress Tracker: Answered vs Remaining */}
                      <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2.5">
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                          <div className="flex items-center gap-3">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-200 dark:border-emerald-800/70">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                              <span>
                                {isAr ? 'تمت الإجابة:' : 'Answered:'}{' '}
                                <strong className="font-mono-numbers">{answeredQuestionsCount}</strong>
                              </span>
                            </span>
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-bold border border-amber-200 dark:border-amber-800/70">
                              <HelpCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                              <span>
                                {isAr ? 'المتبقي:' : 'Remaining:'}{' '}
                                <strong className="font-mono-numbers">{remainingQuestionsCount}</strong>
                              </span>
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
                              {isAr ? 'نسبة الإنجاز:' : 'Progress:'}
                            </span>
                            <span className="font-mono-numbers font-black text-xs text-emerald-700 dark:text-emerald-400">
                              {progressPercentage}%
                            </span>
                          </div>
                        </div>

                        <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-400 rounded-full transition-all duration-300"
                            style={{ width: `${progressPercentage}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {activeQuizToTake.questions.map((qItem, qI) => {
                            const ans = selectedAnswers[qI];
                            const revealed =
                              ans !== undefined &&
                              (instantFeedbackEnabled || revealedQuestions[qI]);
                            const right = ans === qItem.correctOptionIndex;

                            let pillClass =
                              'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700';
                            if (revealed) {
                              pillClass = right
                                ? 'bg-emerald-600 text-white border-emerald-600'
                                : 'bg-rose-600 text-white border-rose-600';
                            } else if (ans !== undefined) {
                              pillClass = 'bg-amber-400 text-slate-950 border-amber-500';
                            }

                            return (
                              <button
                                key={qItem.id || qI}
                                type="button"
                                onClick={() => setCurrentQuestionIdx(qI)}
                                className={`w-8 h-8 rounded-lg border text-xs font-mono-numbers font-bold transition-all ${pillClass} ${
                                  currentQuestionIdx === qI ? 'ring-2 ring-offset-2 ring-emerald-500' : ''
                                }`}
                              >
                                {qI + 1}
                              </button>
                            );
                          })}
                        </div>

                        <span className="text-xs text-slate-400 font-mono-numbers">
                          {currentQuestionIdx + 1} / {activeQuizToTake.questions.length}
                        </span>
                      </div>

                      <div className={`${MCQ_QUESTION_BOX_CLASS} space-y-2.5`}>
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-emerald-700 dark:text-emerald-400 font-mono-numbers">
                              {isAr ? `السؤال #${currentQuestionIdx + 1}` : `Question #${currentQuestionIdx + 1}`}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                isTf
                                  ? 'bg-teal-100 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300'
                                  : 'bg-indigo-100 dark:bg-indigo-950/70 text-indigo-800 dark:text-indigo-300'
                              }`}
                            >
                              {isTf
                                ? isAr
                                  ? 'صح وخطأ'
                                  : 'True / False'
                                : isAr
                                ? 'اختيار من متعدد'
                                : 'Multiple Choice'}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            {currentQ.sourceLessonTitle && (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold">
                                📚 {currentQ.sourceLessonTitle}
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                setReportCategory('needs_clarification');
                                setReportDescription('');
                                setReportingQuestion({
                                  quizId: activeQuizToTake.id,
                                  quizTitle: activeQuizToTake.title,
                                  subject: activeQuizToTake.subject,
                                  question: currentQ,
                                });
                              }}
                              className="px-2 py-0.5 rounded-full bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-[10px] font-bold flex items-center gap-1"
                              title={isAr ? 'إبلاغ عن خطأ أو سؤال يحتاج توضيح' : 'Report question issue'}
                            >
                              <Flag className="w-3 h-3" />
                              <span>{isAr ? 'إبلاغ عن مشكلة بالسؤال' : 'Report'}</span>
                            </button>
                          </div>
                        </div>

                        <p className="text-sm md:text-base font-bold font-cairo text-slate-900 dark:text-slate-100 leading-relaxed">
                          {currentQ.question}
                        </p>
                      </div>

                      <div
                        className={
                          isTf
                            ? 'grid grid-cols-1 sm:grid-cols-2 gap-3 font-tajawal'
                            : 'space-y-2.5 font-tajawal'
                        }
                      >
                        {currentQ.options.map((opt, optIdx) => {
                          const isSelected = selectedIdx === optIdx;
                          const isCorrectOption = optIdx === currentQ.correctOptionIndex;

                          const optionStyle = getMcqOptionSurfaceClass(optIdx, {
                            isSelected,
                            isChecked: showInstantBox,
                            isCorrect: isCorrectOption,
                            dimUnselectedWhenChecked: showInstantBox,
                          });

                          const letter = isAr
                            ? OPTION_LETTERS_AR[optIdx] || optIdx + 1
                            : OPTION_LETTERS_EN[optIdx] || optIdx + 1;

                          return (
                            <button
                              key={optIdx}
                              type="button"
                              onClick={() => handleSelectOption(optIdx)}
                              className={`w-full text-right p-3.5 rounded-xl border-2 text-xs md:text-sm font-bold transition-all flex items-center justify-between gap-3 ${optionStyle}`}
                            >
                              <div className="flex items-center gap-2.5">
                                {!isTf && (
                                  <span className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-700/70 text-slate-700 dark:text-slate-200 flex items-center justify-center text-xs font-cairo shrink-0">
                                    {letter}
                                  </span>
                                )}
                                <span>{opt}</span>
                              </div>

                              <span className="shrink-0">
                                {showInstantBox ? (
                                  isCorrectOption ? (
                                    <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                                  ) : isSelected ? (
                                    <XCircle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
                                  ) : null
                                ) : isSelected ? (
                                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">
                                    ✓
                                  </span>
                                ) : (
                                  <span className="w-5 h-5 rounded-full border border-slate-300 dark:border-slate-600 block" />
                                )}
                              </span>
                            </button>
                          );
                        })}
                      </div>

                      {!instantFeedbackEnabled && isAnswered && !showInstantBox && (
                        <button
                          type="button"
                          onClick={() =>
                            setRevealedQuestions((prev) => ({
                              ...prev,
                              [currentQuestionIdx]: true,
                            }))
                          }
                          className="w-full py-2.5 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold font-cairo text-xs flex items-center justify-center gap-2"
                        >
                          <Lightbulb className="w-4 h-4 text-amber-600" />
                          <span>{isAr ? 'فحص الإجابة وعرض التوضيح الفوري' : 'Check Answer & Show Explanation'}</span>
                        </button>
                      )}

                      {showInstantBox && (
                        <div
                          className={`p-4 rounded-xl border-2 space-y-2 transition-all ${
                            isCurrentCorrect
                              ? 'bg-emerald-50/90 dark:bg-emerald-950/50 border-emerald-400 dark:border-emerald-700'
                              : 'bg-rose-50/90 dark:bg-rose-950/50 border-rose-300 dark:border-rose-700'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 font-cairo font-black text-xs md:text-sm">
                              {isCurrentCorrect ? (
                                <>
                                  <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                                  <span className="text-emerald-800 dark:text-emerald-200">
                                    {isAr ? 'أحسنت! إجابتك صحيحة' : 'Great job! Correct answer'}
                                  </span>
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
                                  <span className="text-rose-800 dark:text-rose-200">
                                    {isAr
                                      ? `إجابة غير صحيحة — الصواب هو: "${currentQ.options[currentQ.correctOptionIndex]}"`
                                      : `Incorrect — Correct answer: "${currentQ.options[currentQ.correctOptionIndex]}"`}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>

                          <div className="p-3 rounded-lg bg-white/80 dark:bg-slate-900/70 border border-slate-200/60 dark:border-slate-700/60 text-xs font-tajawal text-slate-700 dark:text-slate-200 leading-relaxed flex items-start gap-2">
                            <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold font-cairo text-amber-800 dark:text-amber-300 ml-1">
                                {isAr ? 'التوضيح الفوري:' : 'Explanation:'}
                              </span>
                              {currentQ.explanation ||
                                (isAr
                                  ? 'تم اعتماد هذه الإجابة كإجابة نموذجية للسؤال.'
                                  : 'Verified standard answer for this question.')}
                            </div>
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800 font-cairo">
                        <button
                          type="button"
                          onClick={() => setCurrentQuestionIdx((p) => Math.max(0, p - 1))}
                          disabled={currentQuestionIdx === 0}
                          className="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30"
                        >
                          {isAr ? 'السؤال السابق' : 'Previous'}
                        </button>

                        <div className="flex items-center gap-2">
                          {currentQuestionIdx < activeQuizToTake.questions.length - 1 ? (
                            <button
                              type="button"
                              onClick={() => setCurrentQuestionIdx((p) => p + 1)}
                              className="px-5 py-2 text-xs font-bold rounded-lg bg-emerald-700 text-white hover:bg-emerald-800"
                            >
                              {isAr ? 'السؤال التالي' : 'Next Question'}
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={handleSubmitTest}
                              className="px-6 py-2 text-xs font-black rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-sm"
                            >
                              {isAr ? 'إنهاء وعرض النتيجة الفورية' : 'Finish & Show Instant Result'}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                (() => {
                  const result = calculateResultForQuiz(activeQuizToTake, selectedAnswers);
                  const passed = result.percentage >= 60;

                  return (
                    <div className="space-y-6 font-tajawal">
                      <div className="text-center p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
                        <div
                          className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto ${
                            passed
                              ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/80 dark:text-emerald-400'
                              : 'bg-rose-100 text-rose-600 dark:bg-rose-950/80 dark:text-rose-400'
                          }`}
                        >
                          {passed ? <Award className="w-8 h-8" /> : <HelpCircle className="w-8 h-8" />}
                        </div>

                        <div>
                          <h4 className="text-lg md:text-xl font-black font-cairo text-slate-900 dark:text-white">
                            {passed
                              ? isAr
                                ? 'مبارك! تم اجتياز الاختبار بنجاح'
                                : 'Congratulations! Exam Passed'
                              : isAr
                              ? 'تم إتمام الاختبار — راجع التوضيحات العلمية أدناه'
                              : 'Exam Completed — Review Explanations Below'}
                          </h4>
                          <p className="text-xs text-slate-500 mt-1">
                            {isPersistingResult
                              ? isAr
                                ? 'جاري تسجيل نتيجتك وإصدار الشهادات وبيان الدرجات أوتوماتيك في قاعدة البيانات...'
                                : 'Saving result and auto-generating certificates in database...'
                              : autoCertGeneratedSummary
                              ? autoCertGeneratedSummary
                              : isAr
                              ? 'تم رصد النتيجة الفورية وتحديث إحصائيات الاختبار في قاعدة البيانات ✓'
                              : 'Instant score recorded and database stats updated ✓'}
                          </p>

                          {autoCertGeneratedSummary && onNavigateToCertificates && (
                            <div className="pt-2 flex justify-center">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveQuizToTake(null);
                                  onNavigateToCertificates();
                                }}
                                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-cairo font-bold text-xs flex items-center gap-1.5 shadow-sm"
                              >
                                <Award className="w-4 h-4" />
                                <span>{isAr ? 'عرض الشهادة وبيان الدرجات الأوتوماتيك' : 'View Auto Certificate & Transcript'}</span>
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-numbers pt-2">
                          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                            <span className="text-[11px] text-slate-400 block font-tajawal">
                              {isAr ? 'الدرجة النهائية' : 'Score'}
                            </span>
                            <span className="text-xl font-black text-emerald-600 dark:text-emerald-400">
                              {result.earnedMarks} / {activeQuizToTake.totalMarks}
                            </span>
                          </div>
                          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                            <span className="text-[11px] text-slate-400 block font-tajawal">
                              {isAr ? 'النسبة المئوية' : 'Percentage'}
                            </span>
                            <span
                              className={`text-xl font-black ${
                                passed ? 'text-emerald-600' : 'text-rose-600'
                              }`}
                            >
                              {result.percentage}%
                            </span>
                          </div>
                          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                            <span className="text-[11px] text-slate-400 block font-tajawal">
                              {isAr ? 'إجابات صحيحة' : 'Correct'}
                            </span>
                            <span className="text-xl font-black text-emerald-600">
                              {result.correctCount} / {result.totalQuestions}
                            </span>
                          </div>
                          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                            <span className="text-[11px] text-slate-400 block font-tajawal">
                              {isAr ? 'إجابات خاطئة' : 'Wrong'}
                            </span>
                            <span className="text-xl font-black text-rose-600">
                              {result.wrongCount}
                            </span>
                          </div>
                        </div>

                        {(result.mcqTotal > 0 || result.tfTotal > 0) && (
                          <div className="flex flex-wrap items-center justify-center gap-3 text-xs font-cairo pt-1">
                            {result.mcqTotal > 0 && (
                              <span className="px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-200 font-bold">
                                {isAr
                                  ? `الاختيار من متعدد: ${result.mcqCorrect} / ${result.mcqTotal}`
                                  : `MCQ: ${result.mcqCorrect} / ${result.mcqTotal}`}
                              </span>
                            )}
                            {result.tfTotal > 0 && (
                              <span className="px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/60 text-teal-800 dark:text-teal-200 font-bold">
                                {isAr
                                  ? `الصح والخطأ: ${result.tfCorrect} / ${result.tfTotal}`
                                  : `True/False: ${result.tfCorrect} / ${result.tfTotal}`}
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="space-y-3">
                        <h4 className="text-xs font-bold font-cairo text-slate-500">
                          {isAr
                            ? 'مراجعة الإجابات ونموذج التصحيح والتوضيح العلمي:'
                            : 'Detailed Answer Review & Explanations:'}
                        </h4>

                        {activeQuizToTake.questions.map((q, idx) => {
                          const userChoice = selectedAnswers[idx];
                          const isCorrect = userChoice === q.correctOptionIndex;

                          return (
                            <div
                              key={idx}
                              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs space-y-2"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="space-y-1">
                                  <span className="inline-block px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold font-cairo text-slate-600 dark:text-slate-300">
                                    {q.questionType === 'true_false'
                                      ? isAr
                                        ? 'صح وخطأ'
                                        : 'True / False'
                                      : isAr
                                      ? 'اختيار من متعدد'
                                      : 'MCQ'}
                                  </span>
                                  <p className="font-bold font-cairo text-slate-900 dark:text-white text-sm">
                                    {idx + 1}. {q.question}
                                  </p>
                                </div>
                                {isCorrect ? (
                                  <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-bold shrink-0">
                                    <CheckCircle2 className="w-4 h-4" />
                                    {isAr ? 'صحيحة' : 'Correct'}
                                  </span>
                                ) : (
                                  <span className="text-rose-600 dark:text-rose-400 flex items-center gap-1 font-bold shrink-0">
                                    <XCircle className="w-4 h-4" />
                                    {isAr ? 'خاطئة' : 'Incorrect'}
                                  </span>
                                )}
                              </div>

                              <div className="space-y-1 pt-1 text-slate-600 dark:text-slate-300">
                                <div>
                                  <span className="text-slate-400">
                                    {isAr ? 'إجابتك:' : 'Your answer:'}
                                  </span>{' '}
                                  <span className={isCorrect ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                                    {userChoice !== undefined
                                      ? q.options[userChoice]
                                      : isAr
                                      ? 'لم تتم الإجابة'
                                      : 'No answer'}
                                  </span>
                                </div>
                                {!isCorrect && (
                                  <div>
                                    <span className="text-slate-400">
                                      {isAr ? 'الإجابة النموذجية:' : 'Correct answer:'}
                                    </span>{' '}
                                    <span className="text-emerald-600 font-bold">
                                      {q.options[q.correctOptionIndex]}
                                    </span>
                                  </div>
                                )}
                              </div>

                              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 text-slate-500 text-[11px] leading-relaxed">
                                <div>
                                  <span className="font-bold text-amber-700 dark:text-amber-400">
                                    {isAr ? 'التوضيح العلمي:' : 'Explanation:'}
                                  </span>{' '}
                                  {q.explanation}
                                </div>
                                {q.sourceLessonTitle && (
                                  <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold text-[10px] shrink-0">
                                    📚 {q.sourceLessonTitle}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()
              )}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 font-cairo">
              {isTestSubmitted ? (
                <button
                  type="button"
                  onClick={() => handleStartQuiz(activeQuizToTake)}
                  className="px-4 py-2 rounded-lg border border-emerald-600 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إعادة المحاولة' : 'Retake Quiz'}</span>
                </button>
              ) : (
                <span className="text-xs text-slate-400 font-tajawal">
                  {isAr
                    ? `أجبت عن ${Object.keys(selectedAnswers).length} من ${activeQuizToTake.questions.length} أسئلة`
                    : `Answered ${Object.keys(selectedAnswers).length} of ${activeQuizToTake.questions.length}`}
                </span>
              )}

              <button
                onClick={() => setActiveQuizToTake(null)}
                className="px-5 py-2 rounded-lg bg-slate-900 dark:bg-slate-800 text-white font-bold text-xs"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Question Error Report Modal */}
      {reportingQuestion && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-4 bg-rose-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flag className="w-4 h-4" />
                <h4 className="font-bold text-sm">
                  {isAr ? 'الإبلاغ عن مشكلة في السؤال' : 'Report Question Issue'}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setReportingQuestion(null)}
                className="p-1 rounded-lg hover:bg-white/15"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitQuestionReport} className="p-4 space-y-3 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold text-slate-800 dark:text-slate-200 line-clamp-2">
                {reportingQuestion.question.question}
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  {isAr ? 'نوع المشكلة' : 'Issue Category'}
                </label>
                <select
                  value={reportCategory}
                  onChange={(e) => setReportCategory(e.target.value as ContentErrorReportCategory)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-bold"
                >
                  <option value="needs_clarification">
                    {isAr ? 'سؤال يحتاج توضيح / إجابة محل شك' : 'Question unclear / key issue'}
                  </option>
                  <option value="typo">{isAr ? 'خطأ مطبعي أو إملائي' : 'Typo / spelling error'}</option>
                  <option value="broken_link">{isAr ? 'رابط أو وسائط لا تعمل' : 'Broken link / media'}</option>
                  <option value="other">{isAr ? 'ملاحظة أخرى' : 'Other'}</option>
                </select>
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  {isAr ? 'تفاصيل البلاغ للمعلم والأدمن' : 'Details'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  placeholder={isAr ? 'اكتب الملاحظة بوضوح ليتم تصحيحها فوراً...' : 'Describe the issue...'}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setReportingQuestion(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-bold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReport}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black"
                >
                  {isSubmittingReport
                    ? isAr
                      ? 'جاري الإرسال...'
                      : 'Sending...'
                    : isAr
                    ? 'إرسال البلاغ فوراً'
                    : 'Submit Report'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
