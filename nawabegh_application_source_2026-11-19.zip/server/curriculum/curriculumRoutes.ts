import express from 'express';
import * as mainRepo from '../../src/db/repository.ts';
import {
  DEFAULT_STAGES,
  DEFAULT_SUBJECTS,
} from './defaultCurriculumData.ts';
import {
  applyChapterReviewOutcome,
  computeDigitalAwardFromXp,
  gradeMcqSubmission,
} from './masteryEngine.ts';
import type {
  CurriculumSubject,
  EducationalStage,
  StudentSubjectProgress,
} from '../../src/types/curriculum.ts';

const CATALOG_KEY = 'alsharif_curriculum_catalog_v4';
const PROGRESS_KEY = 'alsharif_curriculum_progress_v1';

export const curriculumRouter = express.Router();

interface StoredCatalog {
  stages: EducationalStage[];
  subjects: CurriculumSubject[];
}

function createEmptyProgress(): StudentSubjectProgress {
  return {
    completedLessonIds: [],
    completedChapterIds: [],
    restudyRequiredChapterIds: [],
    passedCumulativeIds: [],
    chapterScores: {},
    cumulativeScores: {},
    totalXp: 0,
  };
}

async function getCatalog(): Promise<StoredCatalog> {
  const raw = await mainRepo.getSystemSetting(CATALOG_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed?.stages) && Array.isArray(parsed?.subjects)) {
        return parsed;
      }
    } catch {
      // Fallback to default seed
    }
  }
  const initial: StoredCatalog = {
    stages: DEFAULT_STAGES,
    subjects: DEFAULT_SUBJECTS,
  };
  await mainRepo.setSystemSetting(CATALOG_KEY, JSON.stringify(initial));
  return initial;
}

async function getAllProgressMap(): Promise<Record<string, StudentSubjectProgress>> {
  const raw = await mainRepo.getSystemSetting(PROGRESS_KEY);
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

async function computeStudentDigitalAward(opts: {
  studentId: string;
  studentName?: string;
  curriculumXp: number;
}) {
  const [rawBadges, rawBonus, rawGifts] = await Promise.all([
    mainRepo.getSystemSetting('alsharif_student_badges_v1'),
    mainRepo.getSystemSetting('alsharif_student_bonus_points_v1'),
    mainRepo.getSystemSetting('student_digital_gifts_v1'),
  ]);

  const badgesMap: Record<string, string[]> = rawBadges ? JSON.parse(rawBadges) : {};
  const bonusMap: Record<string, number> = rawBonus ? JSON.parse(rawBonus) : {};
  const giftsList: any[] = rawGifts ? JSON.parse(rawGifts) : [];

  const studentBadges = badgesMap[opts.studentId] || [];
  const bonusPoints = Number(bonusMap[opts.studentId] || 0);
  const matchingGifts = giftsList
    .filter(
      (g) =>
        g.studentId === opts.studentId ||
        (opts.studentName &&
          String(g.studentName || '').trim() === opts.studentName.trim())
    )
    .map((g) => String(g.giftTitle || '').trim())
    .filter(Boolean);

  const combinedTitles = Array.from(new Set([...matchingGifts, ...studentBadges]));
  const totalPoints = Number(opts.curriculumXp || 0) + bonusPoints;
  return computeDigitalAwardFromXp(totalPoints, combinedTitles);
}

// 1. Get Full Curriculum Catalog + Student Current Progress & Digital Award
curriculumRouter.get('/state', async (req, res) => {
  try {
    const studentId = String(req.query.studentId || 'guest').trim();
    const studentName = String(req.query.studentName || '').trim();

    const [catalog, progressMap] = await Promise.all([
      getCatalog(),
      getAllProgressMap(),
    ]);

    const progress = progressMap[studentId] || createEmptyProgress();
    const currentAward = await computeStudentDigitalAward({
      studentId,
      studentName,
      curriculumXp: progress.totalXp,
    });

    res.json({
      stages: catalog.stages,
      subjects: catalog.subjects,
      progress,
      currentAward,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Complete a Lesson (MCQs + Try-the-Code completed)
curriculumRouter.post('/lesson/complete', async (req, res) => {
  try {
    const {
      studentId = 'guest',
      studentName = '',
      subjectId,
      chapterId,
      lessonId,
      mcqScore = 0,
      mcqTotal = 0,
      codePassed = true,
    } = req.body || {};

    if (!subjectId || !chapterId || !lessonId) {
      return res.status(400).json({ error: 'بيانات الدرس غير مكتملة' });
    }

    const progressMap = await getAllProgressMap();
    const current = progressMap[studentId] || createEmptyProgress();

    const completedLessonIds = [...(current.completedLessonIds || [])];
    let totalXp = Number(current.totalXp || 0);

    if (!completedLessonIds.includes(lessonId)) {
      completedLessonIds.push(lessonId);
      totalXp += 15 + (codePassed ? 10 : 0) + Number(mcqScore || 0) * 2;
    }

    const updated: StudentSubjectProgress = {
      ...current,
      completedLessonIds,
      totalXp,
    };

    progressMap[studentId] = updated;
    await mainRepo.setSystemSetting(PROGRESS_KEY, JSON.stringify(progressMap));

    const currentAward = await computeStudentDigitalAward({
      studentId,
      studentName,
      curriculumXp: updated.totalXp,
    });

    res.json({
      ok: true,
      mcqScore,
      mcqTotal,
      progress: updated,
      currentAward,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Submit Chapter Review (Missed <= 2 -> PASS | Missed > 2 -> FULL CHAPTER RESTUDY RESET)
curriculumRouter.post('/chapter/submit-review', async (req, res) => {
  try {
    const {
      studentId = 'guest',
      studentName = '',
      subjectId,
      chapterId,
      answers = [],
    } = req.body || {};

    const catalog = await getCatalog();
    const subject = catalog.subjects.find((s) => s.id === subjectId);
    const chapter = subject?.chapters.find((c) => c.id === chapterId);

    if (!subject || !chapter) {
      return res.status(404).json({ error: 'الفصل غير موجود في المنهج' });
    }

    const progressMap = await getAllProgressMap();
    const current = progressMap[studentId] || createEmptyProgress();

    const { updatedProgress, result } = applyChapterReviewOutcome({
      progress: current,
      chapterId: chapter.id,
      chapterLessonIds: chapter.lessons.map((l) => l.id),
      questions: chapter.chapterReviewQuestions,
      selectedAnswers: Array.isArray(answers) ? answers : [],
    });

    progressMap[studentId] = updatedProgress;
    await mainRepo.setSystemSetting(PROGRESS_KEY, JSON.stringify(progressMap));

    const newAward = await computeStudentDigitalAward({
      studentId,
      studentName,
      curriculumXp: updatedProgress.totalXp,
    });

    res.json({
      ok: true,
      progress: updatedProgress,
      result: {
        ...result,
        newAward,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Submit Cumulative Multi-Chapter Review (Every 3 or 4 Chapters)
curriculumRouter.post('/cumulative/submit-review', async (req, res) => {
  try {
    const {
      studentId = 'guest',
      studentName = '',
      subjectId,
      milestoneId,
      answers = [],
    } = req.body || {};

    const catalog = await getCatalog();
    const subject = catalog.subjects.find((s) => s.id === subjectId);
    const milestone = subject?.cumulativeReviews.find((m) => m.id === milestoneId);

    if (!subject || !milestone) {
      return res.status(404).json({ error: 'المراجعة التراكمية غير موجودة' });
    }

    const graded = gradeMcqSubmission(
      milestone.questions,
      Array.isArray(answers) ? answers : []
    );

    const progressMap = await getAllProgressMap();
    const current = progressMap[studentId] || createEmptyProgress();
    const next: StudentSubjectProgress = {
      ...current,
      completedLessonIds: [...current.completedLessonIds],
      completedChapterIds: [...current.completedChapterIds],
      restudyRequiredChapterIds: [...current.restudyRequiredChapterIds],
      passedCumulativeIds: [...current.passedCumulativeIds],
      chapterScores: { ...current.chapterScores },
      cumulativeScores: { ...current.cumulativeScores },
      totalXp: Number(current.totalXp || 0),
    };

    next.cumulativeScores[milestone.id] = {
      score: graded.score,
      total: graded.totalQuestions,
      missedMarks: graded.missedMarks,
      passed: graded.passed,
      timestamp: new Date().toISOString(),
    };

    let message = '';
    if (graded.passed) {
      if (!next.passedCumulativeIds.includes(milestone.id)) {
        next.passedCumulativeIds.push(milestone.id);
        next.totalXp += 80;
      }
      message =
        graded.missedMarks === 0
          ? 'امتياز! اجتزت المراجعة التراكمية للـ 3 فصول كاملة وحصلت على +80 نقطة ترقية للجائزة الرقمية.'
          : `أحسنت! نقصت ${graded.missedMarks} درجة فقط وتم اعتماد اجتياز المراجعة التراكمية بنجاح.`;
    } else {
      // Reset the most recent chapter in the milestone block for full restudy from lesson 1
      const coveredChapters = subject.chapters.filter(
        (c) =>
          c.term === milestone.term &&
          milestone.coversChapterOrders.includes(c.order)
      );
      const lastCoveredChapter = coveredChapters[coveredChapters.length - 1];
      if (lastCoveredChapter) {
        const lidSet = new Set(lastCoveredChapter.lessons.map((l) => l.id));
        next.completedLessonIds = next.completedLessonIds.filter((id) => !lidSet.has(id));
        next.completedChapterIds = next.completedChapterIds.filter(
          (id) => id !== lastCoveredChapter.id
        );
        if (!next.restudyRequiredChapterIds.includes(lastCoveredChapter.id)) {
          next.restudyRequiredChapterIds.push(lastCoveredChapter.id);
        }
      }
      message = `نقصت ${graded.missedMarks} درجات في المراجعة التراكمية (أكثر من درجتين المسموح بهما) — يجب إعادة مذاكرة الفصل الأخير في هذه المجموعة من البداية.`;
    }

    progressMap[studentId] = next;
    await mainRepo.setSystemSetting(PROGRESS_KEY, JSON.stringify(progressMap));

    const newAward = await computeStudentDigitalAward({
      studentId,
      studentName,
      curriculumXp: next.totalXp,
    });

    res.json({
      ok: true,
      progress: next,
      result: {
        ...graded,
        message,
        newAward,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Teacher/Admin Authoring: Add Custom Lesson + 4-choice MCQ + Try-the-Code Challenge to a Chapter
curriculumRouter.post('/author/lesson', async (req, res) => {
  try {
    const role = String(req.headers['x-user-role'] || '').toLowerCase();
    if (role === 'student' || role === 'female_student' || role === 'parent' || role === 'visitor') {
      return res.status(403).json({ error: 'إضافة الدروس المنهجية متاحة للمعلمين والإدارة فقط' });
    }

    const { subjectId, chapterId, lesson } = req.body || {};
    if (!subjectId || !chapterId || !lesson?.title) {
      return res.status(400).json({ error: 'بيانات الدرس الجديد غير مكتملة' });
    }

    const catalog = await getCatalog();
    const subject = catalog.subjects.find((s) => s.id === subjectId);
    const chapter = subject?.chapters.find((c) => c.id === chapterId);
    if (!subject || !chapter) {
      return res.status(404).json({ error: 'المادة أو الفصل غير موجود' });
    }

    const createdLesson = {
      id: `custom-les-${Date.now()}`,
      order: chapter.lessons.length + 1,
      title: String(lesson.title).trim(),
      durationMinutes: Number(lesson.durationMinutes || 15),
      summary: String(lesson.summary || 'شرح الدرس التفاعلي').trim(),
      keyPoints: Array.isArray(lesson.keyPoints) ? lesson.keyPoints : [],
      mcqQuestions: Array.isArray(lesson.mcqQuestions) ? lesson.mcqQuestions : [],
      trueFalseQuestions: Array.isArray(lesson.trueFalseQuestions) ? lesson.trueFalseQuestions : [],
      essayQuestions: Array.isArray(lesson.essayQuestions) ? lesson.essayQuestions : [],
      codeChallenges: Array.isArray(lesson.codeChallenges) ? lesson.codeChallenges : [],
    };

    chapter.lessons.push(createdLesson);
    await mainRepo.setSystemSetting(CATALOG_KEY, JSON.stringify(catalog));

    res.status(201).json({ ok: true, lesson: createdLesson, subject });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export async function appendCurriculumChapterFromPdfFeed(opts: {
  subjectId: string;
  chapter: import('../../src/types/curriculum.ts').CurriculumChapter;
}): Promise<{ synced: boolean; subjectId?: string; chapterId?: string }> {
  try {
    const catalog = await getCatalog();
    const subject = catalog.subjects.find((s) => s.id === opts.subjectId);
    if (!subject) {
      return { synced: false };
    }
    const existingIdx = subject.chapters.findIndex((c) => c.id === opts.chapter.id);
    const nextOrder =
      existingIdx >= 0
        ? subject.chapters[existingIdx].order
        : subject.chapters.length + 1;
    const chapterToStore = {
      ...opts.chapter,
      order: nextOrder,
    };
    if (existingIdx >= 0) {
      subject.chapters[existingIdx] = chapterToStore;
    } else {
      subject.chapters.push(chapterToStore);
    }
    await mainRepo.setSystemSetting(CATALOG_KEY, JSON.stringify(catalog));
    return { synced: true, subjectId: subject.id, chapterId: chapterToStore.id };
  } catch (err) {
    console.warn('appendCurriculumChapterFromPdfFeed warning:', err);
    return { synced: false };
  }
}

