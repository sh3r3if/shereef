export interface CurriculumMcqQuestion {
  id: string;
  question: string;
  options: [string, string, string, string]; // 4 choices (1 correct)
  correctIndex: number; // 0..3
  explanation: string;
}

export interface CurriculumTrueFalseQuestion {
  id: string;
  statement: string;
  isTrue: boolean;
  explanation: string;
}

export interface CurriculumEssayQuestion {
  id: string;
  questionType: 'scientific_term' | 'essay' | 'complete';
  question: string;
  modelAnswer: string;
  keywords: string[];
}

export type CodeChallengeLanguage = 'python' | 'html_css' | 'javascript';

export interface SubjectCodeChallenge {
  id: string;
  language?: CodeChallengeLanguage;
  title: string;
  prompt: string;
  subjectContext: string;
  starterCode: string;
  hint: string;
  expectedOutputContains?: string[];
  requiredCodeSnippets?: string[];
  validationExpression?: string;
  expectedConsoleLines?: string[];
}

export interface CurriculumLesson {
  id: string;
  order: number;
  title: string;
  durationMinutes: number;
  summary: string;
  keyPoints: string[];
  videoUrl?: string;
  mcqQuestions: CurriculumMcqQuestion[];
  trueFalseQuestions?: CurriculumTrueFalseQuestion[];
  essayQuestions?: CurriculumEssayQuestion[];
  codeChallenges: SubjectCodeChallenge[];
}

export interface CurriculumChapter {
  id: string;
  order: number;
  term: 1 | 2;
  title: string;
  description: string;
  lessons: CurriculumLesson[];
  chapterReviewQuestions: CurriculumMcqQuestion[];
}

export interface CumulativeReviewMilestone {
  id: string;
  term: 1 | 2;
  afterChapterOrder: number; // e.g., 3 or 4
  coversChapterOrders: number[];
  title: string;
  questions: CurriculumMcqQuestion[];
}

export interface CurriculumSubject {
  id: string;
  stageId: string;
  name: string;
  description: string;
  iconKey: string;
  accentColor: string;
  checkpointIntervalChapters: 3 | 4;
  chapters: CurriculumChapter[];
  cumulativeReviews: CumulativeReviewMilestone[];
}

export interface EducationalStage {
  id: string;
  name: string;
  gradeLabel: string;
  description: string;
}

export interface DigitalAwardInfo {
  id: string;
  title: string;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  points: number;
  nextTierTitle?: string;
  nextTierPoints?: number;
  unlockedTitles: string[];
  serialCode?: string;
}

export interface CurriculumReviewResult {
  score: number;
  totalQuestions: number;
  missedMarks: number;
  passed: boolean;
  mustRestudyChapter: boolean;
  message: string;
  newAward: DigitalAwardInfo;
}

export interface StudentSubjectProgress {
  completedLessonIds: string[];
  completedChapterIds: string[];
  restudyRequiredChapterIds: string[];
  passedCumulativeIds: string[];
  chapterScores: Record<
    string,
    { score: number; total: number; missedMarks: number; passed: boolean; timestamp: string }
  >;
  cumulativeScores: Record<
    string,
    { score: number; total: number; missedMarks: number; passed: boolean; timestamp: string }
  >;
  totalXp: number;
}
