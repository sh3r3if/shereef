import {
  Lesson,
  Teacher,
  Student,
  Quiz,
  Certificate,
  ParentConversation,
  TimetableSlot,
  TuitionInvoice,
  AppNotification,
  FaqItem,
  SchoolSettings,
  AssistantAdmin,
  SystemAuditLog,
} from '../types';

export const INITIAL_SCHOOL_SETTINGS: SchoolSettings = {
  schoolName: 'منصة الشريف',
  schoolNameEn: 'Al-Sharif Edu Platform',
  tagline: 'تعلم بذكاء، تقدم بثقة — مهارات اليوم لمستقبل تصنعه',
  primaryColor: '#0f5132', // Deep Rich Emerald
  logoUrl: '/assets/images/certificate_crest_gold_1794403367581.jpg',
  academicYear: '2026 - 2027',
  enableInstantNotifications: true,
  enableRealtimeSync: true,
};

export const INITIAL_TEACHERS: Teacher[] = [];

export const INITIAL_LESSONS: Lesson[] = [];

export const INITIAL_STUDENTS: Student[] = [];

export const INITIAL_QUIZZES: Quiz[] = [];

export const INITIAL_CERTIFICATES: Certificate[] = [];

export const INITIAL_CONVERSATIONS: ParentConversation[] = [];

export const INITIAL_TIMETABLE: TimetableSlot[] = [];

export const INITIAL_INVOICES: TuitionInvoice[] = [];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [];

export const INITIAL_FAQS: FaqItem[] = [];

export const INITIAL_ASSISTANTS: AssistantAdmin[] = [];

export const INITIAL_AUDIT_LOGS: SystemAuditLog[] = [];

