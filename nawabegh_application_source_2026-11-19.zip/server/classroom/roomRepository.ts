import { createPool, db } from '../../src/db/index.ts';
import { liveRooms } from '../../src/db/schema.ts';
import * as mainRepo from '../../src/db/repository.ts';
import { desc, eq, or } from 'drizzle-orm';
import type { LiveRoomInfo } from '../../src/types/classroom.ts';

const FALLBACK_ROOMS_SETTING_KEY = 'alsharif_classroom_live_rooms_v1';

let storageMode: 'unknown' | 'sql_tables' | 'system_settings_pg' = 'unknown';

export async function ensureClassroomTables(): Promise<'sql_tables' | 'system_settings_pg'> {
  if (storageMode !== 'unknown') return storageMode;

  const pool = createPool();
  try {
    // First test if dedicated table already exists and is readable
    await pool.query('SELECT 1 FROM live_rooms LIMIT 1');
    storageMode = 'sql_tables';
    return storageMode;
  } catch {
    // Table does not exist yet or isn't accessible; try creating (works in Docker/local/admin PG)
  }

  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS live_rooms (
        id TEXT PRIMARY KEY,
        room_code TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        subject TEXT NOT NULL,
        grade TEXT NOT NULL,
        host_id TEXT NOT NULL,
        host_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'scheduled',
        is_locked BOOLEAN NOT NULL DEFAULT FALSE,
        waiting_room_enabled BOOLEAN NOT NULL DEFAULT FALSE,
        chat_muted BOOLEAN NOT NULL DEFAULT FALSE,
        hls_stream_url TEXT,
        max_participants INTEGER NOT NULL DEFAULT 200,
        scheduled_at TEXT,
        started_at TIMESTAMP,
        ended_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS room_attendance (
        id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        role TEXT NOT NULL,
        joined_at TIMESTAMP NOT NULL DEFAULT NOW(),
        left_at TIMESTAMP,
        duration_seconds INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS room_chat_messages (
        id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL,
        sender_id TEXT NOT NULL,
        sender_name TEXT NOT NULL,
        sender_role TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS room_polls (
        id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL,
        question TEXT NOT NULL,
        options_json TEXT NOT NULL,
        correct_option_index INTEGER,
        votes_json TEXT NOT NULL DEFAULT '{}',
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        created_by TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS room_timeline_events (
        id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL,
        recording_id TEXT,
        offset_ms INTEGER NOT NULL DEFAULT 0,
        event_type TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS room_recordings (
        id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL,
        room_title TEXT NOT NULL,
        teacher_name TEXT NOT NULL,
        video_url TEXT,
        duration_seconds INTEGER NOT NULL DEFAULT 0,
        yjs_snapshot_base64 TEXT,
        events_count INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    storageMode = 'sql_tables';
    return storageMode;
  } catch (err: any) {
    console.warn(
      `ℹ️ [LiveClassroom] PostgreSQL runtime role lacks schema DDL (${err?.message}); persisting classroom state in PostgreSQL system_settings.`
    );
    storageMode = 'system_settings_pg';
    return storageMode;
  }
}

async function readFallbackRooms(): Promise<LiveRoomInfo[]> {
  const raw = await mainRepo.getSystemSetting(FALLBACK_ROOMS_SETTING_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function writeFallbackRooms(rooms: LiveRoomInfo[]): Promise<void> {
  await mainRepo.setSystemSetting(FALLBACK_ROOMS_SETTING_KEY, JSON.stringify(rooms));
}

function serializeRoom(row: typeof liveRooms.$inferSelect): LiveRoomInfo {
  return {
    id: row.id,
    roomCode: row.roomCode,
    title: row.title,
    subject: row.subject,
    grade: row.grade,
    hostId: row.hostId,
    hostName: row.hostName,
    status: (row.status as LiveRoomInfo['status']) || 'scheduled',
    isLocked: Boolean(row.isLocked),
    waitingRoomEnabled: Boolean(row.waitingRoomEnabled),
    chatMuted: Boolean(row.chatMuted),
    hlsStreamUrl: row.hlsStreamUrl,
    maxParticipants: row.maxParticipants,
    scheduledAt: row.scheduledAt,
    startedAt: row.startedAt ? row.startedAt.toISOString() : null,
    endedAt: row.endedAt ? row.endedAt.toISOString() : null,
    createdAt: row.createdAt ? row.createdAt.toISOString() : null,
  };
}

export async function listLiveRooms(): Promise<LiveRoomInfo[]> {
  const mode = await ensureClassroomTables();
  if (mode === 'system_settings_pg') {
    return readFallbackRooms();
  }
  const rows = await db.select().from(liveRooms).orderBy(desc(liveRooms.createdAt));
  return rows.map(serializeRoom);
}

export async function getLiveRoomByIdOrCode(idOrCode: string): Promise<LiveRoomInfo | null> {
  const mode = await ensureClassroomTables();
  const clean = idOrCode.trim();
  if (mode === 'system_settings_pg') {
    const all = await readFallbackRooms();
    return (
      all.find((r) => r.id === clean || r.roomCode.toUpperCase() === clean.toUpperCase()) || null
    );
  }
  const rows = await db
    .select()
    .from(liveRooms)
    .where(or(eq(liveRooms.id, clean), eq(liveRooms.roomCode, clean)))
    .limit(1);
  if (!rows.length) return null;
  return serializeRoom(rows[0]);
}

export async function createLiveRoom(input: {
  title: string;
  subject: string;
  grade: string;
  hostId: string;
  hostName: string;
  waitingRoomEnabled?: boolean;
  maxParticipants?: number;
  scheduledAt?: string;
  status?: 'scheduled' | 'live';
}): Promise<LiveRoomInfo> {
  const mode = await ensureClassroomTables();
  const id = `room-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const randomDigits = Math.floor(100000 + Math.random() * 900000);
  const roomCode = `SHF-${randomDigits}`;
  const isLiveNow = input.status === 'live';
  const nowIso = new Date().toISOString();

  if (mode === 'system_settings_pg') {
    const newRoom: LiveRoomInfo = {
      id,
      roomCode,
      title: input.title.trim(),
      subject: input.subject.trim() || 'مادة عامة',
      grade: input.grade.trim() || 'الثانوية العامة',
      hostId: input.hostId,
      hostName: input.hostName,
      status: isLiveNow ? 'live' : 'scheduled',
      isLocked: false,
      waitingRoomEnabled: Boolean(input.waitingRoomEnabled),
      chatMuted: false,
      hlsStreamUrl: null,
      maxParticipants: Math.max(10, Math.min(2000, Number(input.maxParticipants || 200))),
      scheduledAt: input.scheduledAt || nowIso,
      startedAt: isLiveNow ? nowIso : null,
      endedAt: null,
      createdAt: nowIso,
    };
    const existing = await readFallbackRooms();
    await writeFallbackRooms([newRoom, ...existing]);
    return newRoom;
  }

  const [created] = await db
    .insert(liveRooms)
    .values({
      id,
      roomCode,
      title: input.title.trim(),
      subject: input.subject.trim() || 'مادة عامة',
      grade: input.grade.trim() || 'الثانوية العامة',
      hostId: input.hostId,
      hostName: input.hostName,
      status: isLiveNow ? 'live' : 'scheduled',
      isLocked: false,
      waitingRoomEnabled: Boolean(input.waitingRoomEnabled),
      chatMuted: false,
      maxParticipants: Math.max(10, Math.min(2000, Number(input.maxParticipants || 200))),
      scheduledAt: input.scheduledAt || nowIso,
      startedAt: isLiveNow ? new Date() : null,
    })
    .returning();

  return serializeRoom(created);
}

export async function updateLiveRoomSettings(
  roomId: string,
  patch: Partial<{
    status: 'scheduled' | 'live' | 'ended';
    isLocked: boolean;
    waitingRoomEnabled: boolean;
    chatMuted: boolean;
    hlsStreamUrl: string | null;
  }>
): Promise<LiveRoomInfo | null> {
  const mode = await ensureClassroomTables();

  if (mode === 'system_settings_pg') {
    const all = await readFallbackRooms();
    let updatedRoom: LiveRoomInfo | null = null;
    const next = all.map((r) => {
      if (r.id !== roomId) return r;
      updatedRoom = {
        ...r,
        ...(patch.status !== undefined ? { status: patch.status } : {}),
        ...(patch.status === 'live' ? { startedAt: new Date().toISOString() } : {}),
        ...(patch.status === 'ended' ? { endedAt: new Date().toISOString() } : {}),
        ...(patch.isLocked !== undefined ? { isLocked: Boolean(patch.isLocked) } : {}),
        ...(patch.waitingRoomEnabled !== undefined
          ? { waitingRoomEnabled: Boolean(patch.waitingRoomEnabled) }
          : {}),
        ...(patch.chatMuted !== undefined ? { chatMuted: Boolean(patch.chatMuted) } : {}),
        ...(patch.hlsStreamUrl !== undefined ? { hlsStreamUrl: patch.hlsStreamUrl } : {}),
      };
      return updatedRoom;
    });
    if (updatedRoom) await writeFallbackRooms(next);
    return updatedRoom;
  }

  const updateSet: Record<string, any> = {};
  if (patch.status !== undefined) {
    updateSet.status = patch.status;
    if (patch.status === 'live') updateSet.startedAt = new Date();
    if (patch.status === 'ended') updateSet.endedAt = new Date();
  }
  if (patch.isLocked !== undefined) updateSet.isLocked = Boolean(patch.isLocked);
  if (patch.waitingRoomEnabled !== undefined) {
    updateSet.waitingRoomEnabled = Boolean(patch.waitingRoomEnabled);
  }
  if (patch.chatMuted !== undefined) updateSet.chatMuted = Boolean(patch.chatMuted);
  if (patch.hlsStreamUrl !== undefined) updateSet.hlsStreamUrl = patch.hlsStreamUrl;

  if (Object.keys(updateSet).length === 0) {
    return getLiveRoomByIdOrCode(roomId);
  }

  const [updated] = await db
    .update(liveRooms)
    .set(updateSet)
    .where(eq(liveRooms.id, roomId))
    .returning();

  return updated ? serializeRoom(updated) : null;
}

export async function deleteLiveRoom(roomId: string): Promise<boolean> {
  const mode = await ensureClassroomTables();
  if (mode === 'system_settings_pg') {
    const all = await readFallbackRooms();
    const filtered = all.filter((r) => r.id !== roomId);
    if (filtered.length === all.length) return false;
    await writeFallbackRooms(filtered);
    return true;
  }
  const deleted = await db.delete(liveRooms).where(eq(liveRooms.id, roomId)).returning();
  return deleted.length > 0;
}
