import { db } from './index.ts';
import {
  users,
  students,
  teachers,
  lessons,
  quizzes,
  quizAttempts,
  assignments,
  assignmentSubmissions,
  certificates,
  backups,
  auditLogs,
  timetable,
  invoices,
  notifications,
  faqs,
  inquiries,
  schoolSettings,
  systemSettings,
  parentConversations,
  parentMessages,
  lessonRatings,
  pushSubscriptions,
} from './schema.ts';
import { eq, desc, asc, or, ilike, sql, and } from 'drizzle-orm';
import {
  INITIAL_INVOICES,
  INITIAL_SCHOOL_SETTINGS,
} from '../data/mockData.ts';

export async function seedInitialDataIfEmpty() {
  try {
    // 1. Students: No fake/mock students auto-seeded; students come strictly from real DB operations.

    // 2. Teachers: No fake/mock teachers auto-seeded; teachers come strictly from real DB operations.

    // 3. Lessons: No fake/mock lessons auto-seeded; lessons come strictly from real DB operations.

    // 4. Quizzes: No fake/mock quizzes auto-seeded; quizzes come strictly from real DB operations.

    // 5. Certificates: No fake/mock certificates auto-seeded; certificates are auto-generated strictly from real DB exam attempts.

    // 6. Users / Members: Seed only the root Super Admin if table is empty (zero fake assistants)
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length === 0) {
      console.log('🌱 Seeding root super admin...');
      await db.insert(users).values({
        uid: 'usr-super-admin',
        username: 'Mo-NewFolder',
        email: 'Mo-NewFolder@nawabegh.edu',
        displayName: 'Mo-NewFolder (الأدمن العام)',
        displayNameEn: 'Mo-NewFolder (Super Admin)',
        role: 'admin',
        roleTitle: 'المدير العام للمنصة',
        phone: '+966 50 000 0001',
        permissions: JSON.stringify(['all', 'manage_students', 'manage_teachers', 'manage_lessons', 'manage_quizzes', 'manage_certificates', 'manage_finances', 'manage_members', 'manage_backups', 'manage_settings']),
        isActive: true,
      }).onConflictDoNothing();
    }

    // 7. Timetable: No fake/mock timetable rows auto-seeded; scheduled classes & courses come strictly from real DB operations.

    // 8. Invoices / Tuition
    const existingInvoices = await db.select().from(invoices).limit(1);
    if (existingInvoices.length === 0) {
      console.log('🌱 Seeding invoices...');
      for (const inv of INITIAL_INVOICES) {
        await db.insert(invoices).values({
          id: inv.id,
          invoiceNumber: inv.invoiceNumber,
          studentId: inv.studentId,
          studentName: inv.studentName,
          grade: inv.grade,
          amount: inv.amount,
          currency: inv.currency,
          dueDate: inv.dueDate,
          status: inv.status,
          paymentMethod: inv.paymentMethod || null,
          paidDate: inv.paidDate || null,
          description: inv.description,
        }).onConflictDoNothing();
      }
    }

    // 9. Notifications: No fake/mock notifications auto-seeded; notifications come strictly from real DB operations.

    // 10. FAQs: No fake/mock FAQs auto-seeded; FAQs & inquiries come strictly from real DB operations.

    // 11. School Customization Settings
    const existingSettings = await db.select().from(schoolSettings).limit(1);
    if (existingSettings.length === 0) {
      console.log('🌱 Seeding school settings...');
      await db.insert(schoolSettings).values({
        id: 'main_school',
        schoolName: 'منصة الشريف',
        schoolNameEn: 'Al-Sharif Edu Platform',
        tagline: INITIAL_SCHOOL_SETTINGS.tagline,
        primaryColor: INITIAL_SCHOOL_SETTINGS.primaryColor,
        logoUrl: INITIAL_SCHOOL_SETTINGS.logoUrl || null,
        academicYear: INITIAL_SCHOOL_SETTINGS.academicYear,
        enableInstantNotifications: INITIAL_SCHOOL_SETTINGS.enableInstantNotifications,
        enableRealtimeSync: INITIAL_SCHOOL_SETTINGS.enableRealtimeSync,
      }).onConflictDoNothing();
    } else if (
      existingSettings[0].schoolName === 'تعلّمنوفا' ||
      existingSettings[0].schoolName === 'تعلمنوفا' ||
      existingSettings[0].schoolName === 'أكاديمية نوابغ التعليمية'
    ) {
      await db
        .update(schoolSettings)
        .set({
          schoolName: 'منصة الشريف',
          schoolNameEn: 'Al-Sharif Edu Platform',
          updatedAt: new Date(),
        })
        .where(eq(schoolSettings.id, 'main_school'));
    }

    console.log('✅ Initial database seed check completed successfully!');
  } catch (error) {
    console.error('Error during initial database seeding:', error);
  }
}

// ---------------- Students CRUD ----------------
const STUDENT_EXTRA_KEY = 'alsharif_student_extra_fields_v1';

async function getStudentsExtraMap(): Promise<Record<string, Record<string, any>>> {
  try {
    const raw = await getSystemSetting(STUDENT_EXTRA_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

async function saveStudentExtraFields(studentId: string, extra: Record<string, any>) {
  try {
    const map = await getStudentsExtraMap();
    map[studentId] = {
      ...(map[studentId] || {}),
      ...extra,
    };
    await setSystemSetting(STUDENT_EXTRA_KEY, JSON.stringify(map));
    return map[studentId];
  } catch (err) {
    console.warn('Could not persist student extra metadata:', err);
    return extra;
  }
}

export async function getAllStudents() {
  try {
    const [rows, extraMap] = await Promise.all([
      db.select().from(students).orderBy(desc(students.createdAt)),
      getStudentsExtraMap(),
    ]);
    return rows.map((row) => ({
      ...row,
      ...(extraMap[row.id] || {}),
    }));
  } catch (error) {
    console.error('Failed to query students:', error);
    throw new Error('Failed to query students from database', { cause: error });
  }
}

export async function createStudent(data: any) {
  try {
    const score = Number(data.overallScore ?? 85);
    const attendance = Number(data.attendanceRate ?? 95);
    const computedStatus =
      data.status || (score >= 90 ? 'top' : score < 60 || attendance < 70 ? 'weak' : 'regular');

    const studentId = data.id || `stu-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const payload = {
      id: studentId,
      code: data.code || `STU-${Math.floor(1000 + Math.random() * 9000)}`,
      name: data.name || 'طالب جديد',
      nameEn: data.nameEn || data.name || 'New Student',
      grade: data.grade || 'الصف الثالث الثانوي',
      type: data.type === 'offline' ? 'offline' : 'online',
      parentName: data.parentName || '',
      parentPhone: data.parentPhone || '',
      parentEmail: data.parentEmail || '',
      overallScore: score,
      attendanceRate: attendance,
      status: computedStatus,
      notes: data.notes || '',
      registeredDate: data.registeredDate || new Date().toISOString().split('T')[0],
      city: data.city || '',
      avatar: data.avatar || null,
      createdAt: new Date(),
    };

    const res = await db.insert(students).values(payload).returning();
    const extra = await saveStudentExtraFields(studentId, {
      studentPhone: data.studentPhone ?? '',
      bookletName: data.bookletName ?? '',
      bookletStatus: data.bookletStatus ?? 'مستلم',
      bookletBookingDate: data.bookletBookingDate ?? new Date().toISOString().split('T')[0],
      gender: data.gender === 'female' ? 'female' : 'male',
    });
    return { ...res[0], ...extra };
  } catch (error: any) {
    console.error('Failed to create student:', error);
    throw new Error(`Failed to create student: ${error?.message || error}`);
  }
}

export async function updateStudent(id: string, data: any) {
  try {
    const payload = { ...data };
    delete payload.id;
    delete payload.createdAt;

    const extraUpdates: Record<string, any> = {};
    for (const key of ['studentPhone', 'bookletName', 'bookletStatus', 'bookletBookingDate', 'gender']) {
      if (key in payload) {
        extraUpdates[key] = payload[key];
        delete payload[key];
      }
    }

    if (payload.overallScore !== undefined) {
      payload.overallScore = Number(payload.overallScore);
    }
    if (payload.attendanceRate !== undefined) {
      payload.attendanceRate = Number(payload.attendanceRate);
    }

    const res = await db.update(students).set(payload).where(eq(students.id, id)).returning();
    const extra =
      Object.keys(extraUpdates).length > 0
        ? await saveStudentExtraFields(id, extraUpdates)
        : (await getStudentsExtraMap())[id] || {};
    return { ...res[0], ...extra };
  } catch (error: any) {
    console.error('Failed to update student:', error);
    throw new Error(`Failed to update student: ${error?.message || error}`);
  }
}

export async function deleteStudent(id: string) {
  try {
    await db.delete(students).where(eq(students.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete student:', error);
    throw new Error('Failed to delete student from database', { cause: error });
  }
}

// ---------------- Teachers CRUD ----------------
export async function getAllTeachers() {
  try {
    return await db.select().from(teachers).orderBy(desc(teachers.createdAt));
  } catch (error) {
    console.error('Failed to query teachers:', error);
    throw new Error('Failed to query teachers from database', { cause: error });
  }
}

export async function createTeacher(data: any) {
  try {
    const payload = {
      ...data,
      id: data.id || `tch-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: data.name || 'معلم جديد',
      nameEn: data.nameEn || data.name || 'New Teacher',
      specialty: data.specialty || 'التعليم العام',
      specialtyEn: data.specialtyEn || data.specialty || 'General',
      grades: Array.isArray(data.grades) ? JSON.stringify(data.grades) : data.grades || '[]',
      rating: String(data.rating || '5.0'),
      totalStudents: Number(data.totalStudents) || 0,
      activeLessonsCount: Number(data.activeLessonsCount) || 0,
      joinedDate: data.joinedDate || new Date().toISOString().split('T')[0],
      createdAt: new Date(),
    };
    const res = await db.insert(teachers).values(payload).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to create teacher:', error);
    throw new Error(`Failed to create teacher: ${error?.message || error}`);
  }
}

export async function updateTeacher(id: string, data: any) {
  try {
    const payload = { ...data };
    delete payload.id;
    delete payload.createdAt;
    if (Array.isArray(payload.grades)) {
      payload.grades = JSON.stringify(payload.grades);
    }
    if (payload.rating !== undefined) {
      payload.rating = String(payload.rating);
    }
    if (payload.totalStudents !== undefined) {
      payload.totalStudents = Number(payload.totalStudents) || 0;
    }
    if (payload.activeLessonsCount !== undefined) {
      payload.activeLessonsCount = Number(payload.activeLessonsCount) || 0;
    }
    const res = await db.update(teachers).set(payload).where(eq(teachers.id, id)).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to update teacher:', error);
    throw new Error(`Failed to update teacher: ${error?.message || error}`);
  }
}

export async function deleteTeacher(id: string) {
  try {
    await db.delete(teachers).where(eq(teachers.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete teacher:', error);
    throw new Error('Failed to delete teacher from database', { cause: error });
  }
}

// ---------------- Lessons CRUD ----------------
export async function getAllLessons() {
  try {
    return await db.select().from(lessons).orderBy(desc(lessons.createdAt));
  } catch (error) {
    console.error('Failed to query lessons:', error);
    throw new Error('Failed to query lessons from database', { cause: error });
  }
}

export async function createLesson(data: any) {
  try {
    const payload = {
      ...data,
      id: data.id || `les-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: data.createdAt ? new Date(data.createdAt) : new Date(),
      viewsCount: Number(data.viewsCount) || 0,
      likesCount: Number(data.likesCount) || 0,
      isPublished: data.isPublished ?? true,
      infographicData:
        data.infographicData && typeof data.infographicData === 'object'
          ? JSON.stringify(data.infographicData)
          : data.infographicData,
    };
    const res = await db.insert(lessons).values(payload).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to create lesson:', error);
    throw new Error(`Failed to create lesson: ${error?.message || error}`);
  }
}

export async function updateLesson(id: string, data: any) {
  try {
    const payload = { ...data };
    delete payload.id;
    if (payload.createdAt) {
      payload.createdAt = new Date(payload.createdAt);
    }
    if (payload.infographicData && typeof payload.infographicData === 'object') {
      payload.infographicData = JSON.stringify(payload.infographicData);
    }
    const res = await db.update(lessons).set(payload).where(eq(lessons.id, id)).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to update lesson:', error);
    throw new Error(`Failed to update lesson: ${error?.message || error}`);
  }
}

export async function deleteLesson(id: string) {
  try {
    await db.delete(lessons).where(eq(lessons.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete lesson:', error);
    throw new Error('Failed to delete lesson from database', { cause: error });
  }
}

// ---------------- Quizzes CRUD ----------------
export async function getAllQuizzes() {
  try {
    return await db.select().from(quizzes).orderBy(desc(quizzes.createdAt));
  } catch (error) {
    console.error('Failed to query quizzes:', error);
    throw new Error('Failed to query quizzes from database', { cause: error });
  }
}

export async function createQuiz(data: any) {
  try {
    const payload = {
      id: data.id || `qz-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: data.title || 'اختبار جديد',
      subject: data.subject || 'الرياضيات',
      grade: data.grade || 'الصف الثالث الثانوي',
      type: data.type === 'monthly' ? 'monthly' : 'weekly',
      durationMinutes: Number(data.durationMinutes) || 30,
      totalMarks: Number(data.totalMarks) || 20,
      questions: Array.isArray(data.questions)
        ? JSON.stringify(data.questions)
        : typeof data.questions === 'string'
        ? data.questions
        : '[]',
      dueDate: data.dueDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      completedStudentsCount: Number(data.completedStudentsCount) || 0,
      averageScore: Math.round(Number(data.averageScore) || 0),
      teacherId: String(data.teacherId || '').trim(),
      teacherName: String(data.teacherName || '').trim(),
      createdAt: new Date(),
    };
    const res = await db.insert(quizzes).values(payload).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to create quiz:', error);
    throw new Error(`Failed to create quiz in database: ${error?.message || error}`);
  }
}

export async function updateQuiz(id: string, data: any) {
  try {
    const payload: Record<string, any> = {};
    if (data.title !== undefined) payload.title = data.title;
    if (data.subject !== undefined) payload.subject = data.subject;
    if (data.grade !== undefined) payload.grade = data.grade;
    if (data.type !== undefined) payload.type = data.type === 'monthly' ? 'monthly' : 'weekly';
    if (data.durationMinutes !== undefined) payload.durationMinutes = Number(data.durationMinutes) || 30;
    if (data.totalMarks !== undefined) payload.totalMarks = Number(data.totalMarks) || 20;
    if (data.questions !== undefined) {
      payload.questions = Array.isArray(data.questions)
        ? JSON.stringify(data.questions)
        : String(data.questions);
    }
    if (data.dueDate !== undefined) payload.dueDate = data.dueDate;
    if (data.completedStudentsCount !== undefined) {
      payload.completedStudentsCount = Number(data.completedStudentsCount) || 0;
    }
    if (data.averageScore !== undefined) {
      payload.averageScore = Math.round(Number(data.averageScore) || 0);
    }
    if (data.teacherId !== undefined) payload.teacherId = String(data.teacherId).trim();
    if (data.teacherName !== undefined) payload.teacherName = String(data.teacherName).trim();

    const res = await db.update(quizzes).set(payload).where(eq(quizzes.id, id)).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to update quiz:', error);
    throw new Error(`Failed to update quiz in database: ${error?.message || error}`);
  }
}

export async function deleteQuiz(id: string) {
  try {
    await db.delete(quizzes).where(eq(quizzes.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete quiz:', error);
    throw new Error('Failed to delete quiz from database', { cause: error });
  }
}

// ---------------- Assignments & Submissions CRUD (الواجبات المنزلية وتسليمات الطلاب) ----------------
export async function getAllAssignments(filters?: {
  search?: string;
  subject?: string;
  grade?: string;
  teacherId?: string;
}) {
  try {
    const rows = await db.select().from(assignments).orderBy(desc(assignments.createdAt));
    if (!filters) return rows;
    const q = (filters.search || '').trim().toLowerCase();
    return rows.filter((row) => {
      if (filters.subject && filters.subject !== 'all' && row.subject !== filters.subject) return false;
      if (filters.grade && filters.grade !== 'all' && row.grade !== filters.grade) return false;
      if (filters.teacherId && row.teacherId !== filters.teacherId) return false;
      if (q) {
        const hay = [
          row.title,
          row.description,
          row.instructions,
          row.subject,
          row.grade,
          row.teacherName,
          row.lessonTitle,
          row.unit,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  } catch (error) {
    console.error('Failed to query assignments:', error);
    throw new Error('Failed to query assignments from database', { cause: error });
  }
}

export async function createAssignment(data: any) {
  try {
    const id =
      data.id && String(data.id).trim()
        ? String(data.id).trim()
        : `asg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const payload = {
      id,
      title: String(data.title || 'واجب منزلي جديد').trim(),
      description: String(data.description || '').trim(),
      instructions: String(data.instructions || '').trim(),
      subject: String(data.subject || 'الرياضيات').trim(),
      grade: String(data.grade || 'الصف الثالث الثانوي').trim(),
      unit: String(data.unit || '').trim(),
      lessonId: String(data.lessonId || '').trim(),
      lessonTitle: String(data.lessonTitle || '').trim(),
      teacherId: String(data.teacherId || '').trim(),
      teacherName: String(data.teacherName || 'المعلم').trim(),
      attachmentUrl: data.attachmentUrl || null,
      attachmentName: data.attachmentName || null,
      dueDate:
        String(data.dueDate || '').trim() ||
        new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
      maxMarks: Number(data.maxMarks) > 0 ? Number(data.maxMarks) : 20,
      isPublished: data.isPublished !== undefined ? Boolean(data.isPublished) : true,
      createdAt: new Date(),
    };
    const res = await db.insert(assignments).values(payload).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to create assignment:', error);
    throw new Error(`Failed to create assignment in database: ${error?.message || error}`);
  }
}

export async function updateAssignment(id: string, data: any) {
  try {
    const payload: Record<string, any> = {};
    if (data.title !== undefined) payload.title = String(data.title).trim();
    if (data.description !== undefined) payload.description = String(data.description).trim();
    if (data.instructions !== undefined) payload.instructions = String(data.instructions).trim();
    if (data.subject !== undefined) payload.subject = String(data.subject).trim();
    if (data.grade !== undefined) payload.grade = String(data.grade).trim();
    if (data.unit !== undefined) payload.unit = String(data.unit).trim();
    if (data.lessonId !== undefined) payload.lessonId = String(data.lessonId).trim();
    if (data.lessonTitle !== undefined) payload.lessonTitle = String(data.lessonTitle).trim();
    if (data.teacherId !== undefined) payload.teacherId = String(data.teacherId).trim();
    if (data.teacherName !== undefined) payload.teacherName = String(data.teacherName).trim();
    if (data.attachmentUrl !== undefined) payload.attachmentUrl = data.attachmentUrl || null;
    if (data.attachmentName !== undefined) payload.attachmentName = data.attachmentName || null;
    if (data.dueDate !== undefined) payload.dueDate = String(data.dueDate).trim();
    if (data.maxMarks !== undefined) payload.maxMarks = Number(data.maxMarks) > 0 ? Number(data.maxMarks) : 20;
    if (data.isPublished !== undefined) payload.isPublished = Boolean(data.isPublished);

    const res = await db.update(assignments).set(payload).where(eq(assignments.id, id)).returning();
    return res[0] || null;
  } catch (error: any) {
    console.error('Failed to update assignment:', error);
    throw new Error(`Failed to update assignment in database: ${error?.message || error}`);
  }
}

export async function deleteAssignment(id: string) {
  try {
    await db.delete(assignmentSubmissions).where(eq(assignmentSubmissions.assignmentId, id));
    await db.delete(assignments).where(eq(assignments.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete assignment:', error);
    throw new Error('Failed to delete assignment from database', { cause: error });
  }
}

export async function getAllAssignmentSubmissions(filters?: {
  assignmentId?: string;
  studentId?: string;
}) {
  try {
    const rows = await db
      .select()
      .from(assignmentSubmissions)
      .orderBy(desc(assignmentSubmissions.createdAt));
    if (!filters) return rows;
    return rows.filter((row) => {
      if (filters.assignmentId && row.assignmentId !== filters.assignmentId) return false;
      if (filters.studentId && row.studentId !== filters.studentId) return false;
      return true;
    });
  } catch (error) {
    console.error('Failed to query assignment submissions:', error);
    return [];
  }
}

export async function createAssignmentSubmission(data: any) {
  try {
    const assignmentId = String(data.assignmentId || '').trim();
    const studentId = String(data.studentId || '').trim();
    const studentName = String(data.studentName || 'طالب').trim();
    if (!assignmentId || !studentId) {
      throw new Error('معرف الواجب ومعرف الطالب مطلوبان لتسليم الحل');
    }

    const existingRows = await db
      .select()
      .from(assignmentSubmissions)
      .where(eq(assignmentSubmissions.assignmentId, assignmentId));
    const existing = existingRows.find((r) => r.studentId === studentId);

    const nowLabel = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    if (existing) {
      const updated = await db
        .update(assignmentSubmissions)
        .set({
          studentName,
          studentCode: String(data.studentCode || existing.studentCode || '').trim(),
          answerText: String(data.answerText || '').trim(),
          attachmentUrl:
            data.attachmentUrl !== undefined ? data.attachmentUrl : existing.attachmentUrl,
          attachmentName:
            data.attachmentName !== undefined ? data.attachmentName : existing.attachmentName,
          submittedAt: nowLabel,
        })
        .where(eq(assignmentSubmissions.id, existing.id))
        .returning();
      return updated[0];
    }

    const id =
      data.id && String(data.id).trim()
        ? String(data.id).trim()
        : `sub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const payload = {
      id,
      assignmentId,
      studentId,
      studentName,
      studentCode: String(data.studentCode || '').trim(),
      answerText: String(data.answerText || '').trim(),
      attachmentUrl: data.attachmentUrl || null,
      attachmentName: data.attachmentName || null,
      score: null,
      feedback: '',
      status: 'submitted',
      submittedAt: nowLabel,
      gradedAt: '',
      createdAt: new Date(),
    };
    const res = await db.insert(assignmentSubmissions).values(payload).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to create assignment submission:', error);
    throw new Error(`Failed to submit assignment: ${error?.message || error}`);
  }
}

export async function gradeAssignmentSubmission(
  id: string,
  data: { score: number; feedback?: string }
) {
  try {
    const nowLabel = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const res = await db
      .update(assignmentSubmissions)
      .set({
        score: Math.max(0, Math.round(Number(data.score) || 0)),
        feedback: String(data.feedback || '').trim(),
        status: 'graded',
        gradedAt: nowLabel,
      })
      .where(eq(assignmentSubmissions.id, id))
      .returning();
    return res[0] || null;
  } catch (error: any) {
    console.error('Failed to grade assignment submission:', error);
    throw new Error(`Failed to grade submission: ${error?.message || error}`);
  }
}

export async function deleteAssignmentSubmission(id: string) {
  try {
    await db.delete(assignmentSubmissions).where(eq(assignmentSubmissions.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete assignment submission:', error);
    throw new Error('Failed to delete assignment submission', { cause: error });
  }
}

function stripHtmlTags(html?: string | null): string {
  if (!html) return '';
  return html
    .replace(/<\/(p|div|li|h[1-6]|tr|blockquote)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{2,}/g, '\n')
    .trim();
}

function shuffleItems<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export async function generateQuizQuestionsFromDbLessons(params: {
  lessonIds?: string[];
  formatFilter?: 'all' | 'video' | 'pdf' | 'word' | 'infographic';
  count?: number;
  questionMix?: 'mixed' | 'mcq' | 'true_false';
  language?: 'ar' | 'en';
}) {
  const isAr = params.language !== 'en';
  const requestedCount = Math.max(1, Math.min(30, Number(params.count) || 5));
  const questionMix = params.questionMix || 'mixed';
  const formatFilter = params.formatFilter || 'all';

  const allLessons = await db.select().from(lessons).orderBy(desc(lessons.createdAt));
  if (allLessons.length === 0) {
    return {
      questions: [],
      sourceLessons: [],
      error: isAr
        ? 'لا توجد دروس أو فيديوهات أو ملفات مرفقة مسجلة في قاعدة البيانات بعد.'
        : 'No lessons, videos, or attached files found in database yet.',
    };
  }

  let selectedLessons =
    Array.isArray(params.lessonIds) && params.lessonIds.length > 0
      ? allLessons.filter((l) => params.lessonIds!.includes(l.id))
      : allLessons;

  if (formatFilter !== 'all') {
    selectedLessons = selectedLessons.filter((l) => l.format === formatFilter);
  }

  if (selectedLessons.length === 0) {
    return {
      questions: [],
      sourceLessons: [],
      error: isAr
        ? 'لم يتم العثور على دروس مطابقة للتصنيف المحدد في قاعدة البيانات.'
        : 'No matching lessons found for the selected filter in database.',
    };
  }

  const formatLabels: Record<string, string> = isAr
    ? { video: 'فيديو تعليمي', pdf: 'ملف PDF مرفق', word: 'مستند Word مرفق', infographic: 'درس إنفوجرافيك' }
    : { video: 'Video Lesson', pdf: 'Attached PDF', word: 'Attached Word Doc', infographic: 'Infographic Lesson' };

  const allDescriptions = Array.from(
    new Set(
      allLessons
        .map((l) => stripHtmlTags(l.description))
        .filter((d) => d.length >= 6)
    )
  );
  const allUnits = Array.from(
    new Set(
      allLessons
        .map((l) => (l.unit || '').trim())
        .filter((u) => u.length >= 2)
    )
  );
  const allSubjects = Array.from(
    new Set(
      allLessons
        .map((l) => (l.subject || '').trim())
        .filter((s) => s.length >= 2)
    )
  );
  const allGrades = Array.from(
    new Set(
      allLessons
        .map((l) => (l.grade || '').trim())
        .filter((g) => g.length >= 2)
    )
  );

  // Collect infographic section descriptions across all DB lessons for realistic distractors
  const allSectionDescs: string[] = [];
  for (const l of allLessons) {
    if (l.infographicData) {
      try {
        const parsed = JSON.parse(l.infographicData);
        if (Array.isArray(parsed?.sections)) {
          for (const sec of parsed.sections) {
            const desc = String(sec?.description || '').trim();
            if (desc.length >= 6) allSectionDescs.push(desc);
          }
        }
      } catch {
        // ignore invalid json
      }
    }
  }

  const pickDistractors = (correctText: string, pool: string[], fallbacks: string[], needed = 3): string[] => {
    const unique = Array.from(new Set(pool.filter((p) => p && p !== correctText)));
    const picked = shuffleItems(unique).slice(0, needed);
    for (const fb of fallbacks) {
      if (picked.length >= needed) break;
      if (fb !== correctText && !picked.includes(fb)) picked.push(fb);
    }
    return picked.slice(0, needed);
  };

  const buildMcq = (
    id: string,
    questionText: string,
    correctAnswer: string,
    distractors: string[],
    explanation: string,
    lesson: typeof allLessons[number]
  ) => {
    const rawOptions = [correctAnswer, ...distractors];
    const indexed = rawOptions.map((text, idx) => ({ text, isCorrect: idx === 0 }));
    const shuffled = shuffleItems(indexed);
    return {
      id,
      questionType: 'mcq' as const,
      question: questionText,
      options: shuffled.map((o) => o.text),
      correctOptionIndex: shuffled.findIndex((o) => o.isCorrect),
      explanation,
      sourceLessonId: lesson.id,
      sourceLessonTitle: lesson.title,
      sourceFormat: (lesson.format as 'video' | 'pdf' | 'word' | 'infographic') || 'video',
    };
  };

  const candidates: any[] = [];
  const tfLabels = isAr ? ['صح', 'خطأ'] : ['True', 'False'];

  for (const lesson of selectedLessons) {
    const fmt = (lesson.format as 'video' | 'pdf' | 'word' | 'infographic') || 'video';
    const fmtLabel = formatLabels[fmt] || fmt;
    const attachmentHint = lesson.videoUrl
      ? isAr
        ? `رابط الفيديو: ${lesson.videoUrl}`
        : `Video: ${lesson.videoUrl}`
      : lesson.documentUrl
      ? isAr
        ? `الملف المرفق: ${lesson.documentUrl}`
        : `File: ${lesson.documentUrl}`
      : '';

    const baseExplanationSuffix = attachmentHint ? ` (${fmtLabel} — ${attachmentHint})` : ` (${fmtLabel})`;

    // A. Extract from Infographic sections if available
    if (lesson.infographicData) {
      try {
        const parsedInfo = JSON.parse(lesson.infographicData);
        const sections = Array.isArray(parsedInfo?.sections) ? parsedInfo.sections : [];
        for (let sIdx = 0; sIdx < sections.length; sIdx++) {
          const sec = sections[sIdx];
          const secTitle = String(sec?.title || '').trim();
          const secDesc = String(sec?.description || '').trim();
          if (secTitle && secDesc) {
            const distractors = pickDistractors(
              secDesc,
              [...allSectionDescs, ...allDescriptions],
              isAr
                ? [
                    'مفهوم غير مرتبط بهذا المحور وفق خطة المنهج المعتمد.',
                    'إجراء تكميلي يخص وحدة دراسية أخرى مختلفة تماماً.',
                    'وصف عام لا ينطبق على المعيار المحدد في الإنفوجرافيك.',
                  ]
                : [
                    'Concept unrelated to this specific unit objective.',
                    'Secondary procedure from a different curriculum module.',
                    'General remark outside this infographic topic.',
                  ]
            );
            candidates.push(
              buildMcq(
                `dbq-info-mcq-${lesson.id}-${sIdx}-${Date.now()}`,
                isAr
                  ? `في درس «${lesson.title}» (${lesson.subject})، أيٌّ مما يلي يوضح محور «${secTitle}»؟`
                  : `In lesson "${lesson.title}" (${lesson.subject}), which statement explains "${secTitle}"?`,
                secDesc,
                distractors,
                isAr
                  ? `وفقاً لمحور «${secTitle}» في درس «${lesson.title}»: ${secDesc}${baseExplanationSuffix}`
                  : `According to section "${secTitle}" in "${lesson.title}": ${secDesc}${baseExplanationSuffix}`,
                lesson
              )
            );

            // True/False variation from section
            const makeFalse = sIdx % 2 === 1;
            const otherSub = allSubjects.find((s) => s !== lesson.subject);
            if (makeFalse && otherSub) {
              candidates.push({
                id: `dbq-info-tf-${lesson.id}-${sIdx}-${Date.now()}`,
                questionType: 'true_false',
                question: isAr
                  ? `يندرج محور «${secTitle}» الوارد في درس «${lesson.title}» ضمن مادة «${otherSub}».`
                  : `The topic "${secTitle}" from lesson "${lesson.title}" belongs to "${otherSub}".`,
                options: tfLabels,
                correctOptionIndex: 1,
                explanation: isAr
                  ? `خطأ؛ محور «${secTitle}» (${secDesc}) ينتمي إلى مادة «${lesson.subject}» في درس «${lesson.title}»${baseExplanationSuffix}.`
                  : `False; "${secTitle}" belongs to "${lesson.subject}" in lesson "${lesson.title}"${baseExplanationSuffix}.`,
                sourceLessonId: lesson.id,
                sourceLessonTitle: lesson.title,
                sourceFormat: fmt,
              });
            } else {
              candidates.push({
                id: `dbq-info-tf-${lesson.id}-${sIdx}-${Date.now()}`,
                questionType: 'true_false',
                question: isAr
                  ? `يتناول درس «${lesson.title}» محور «${secTitle}» الذي يوضح أن: ${secDesc}.`
                  : `Lesson "${lesson.title}" covers "${secTitle}": ${secDesc}.`,
                options: tfLabels,
                correctOptionIndex: 0,
                explanation: isAr
                  ? `صح؛ هذه المعلومة موثقة ضمن قسم «${secTitle}» في درس «${lesson.title}»${baseExplanationSuffix}.`
                  : `True; this fact is documented in section "${secTitle}" of "${lesson.title}"${baseExplanationSuffix}.`,
                sourceLessonId: lesson.id,
                sourceLessonTitle: lesson.title,
                sourceFormat: fmt,
              });
            }
          }
        }
      } catch {
        // ignore invalid infographic json
      }
    }

    // B. Extract from CKEditor / HTML content paragraphs
    const plainText = stripHtmlTags(lesson.contentHtml);
    if (plainText.length >= 20) {
      const lines = plainText
        .split(/\n+|(?<=[.!؟])\s+/)
        .map((line) => line.trim())
        .filter((line) => line.length >= 18 && line.length <= 240);

      for (let lIdx = 0; lIdx < Math.min(lines.length, 6); lIdx++) {
        const fact = lines[lIdx];
        const otherLines = lines.filter((_, i) => i !== lIdx);
        const distractors = pickDistractors(
          fact,
          [...otherLines, ...allDescriptions],
          isAr
            ? [
                'لا تتطابق هذه النقطة مع الشرح العلمي الوارد في محتوى الدرس.',
                'عبارة عامة خارج نطاق المحاور الأساسية المشروحة في الملف.',
                'تفصيل جانبي لم يرد كاستنتاج رئيسي في الدرس المرفق.',
              ]
            : [
                'Statement not matching the explanation in the attached lesson.',
                'General note outside the lesson core objectives.',
                'Unverified secondary detail.',
              ]
        );

        candidates.push(
          buildMcq(
            `dbq-html-mcq-${lesson.id}-${lIdx}-${Date.now()}`,
            isAr
              ? `استناداً إلى محتوى درس «${lesson.title}» (${fmtLabel})، أي العبارات التالية صحيحة ومستخلصة من الدرس؟`
              : `Based on "${lesson.title}" (${fmtLabel}), which of the following statements is directly covered in the lesson?`,
            fact,
            distractors,
            isAr
              ? `مستخلص مباشرة من محتوى درس «${lesson.title}»: «${fact}»${baseExplanationSuffix}`
              : `Extracted from "${lesson.title}": "${fact}"${baseExplanationSuffix}`,
            lesson
          )
        );

        candidates.push({
          id: `dbq-html-tf-${lesson.id}-${lIdx}-${Date.now()}`,
          questionType: 'true_false',
          question: isAr
            ? `ورد في الشرح العلمي لدرس «${lesson.title}» أن: «${fact}».`
            : `In "${lesson.title}", the material states: "${fact}".`,
          options: tfLabels,
          correctOptionIndex: 0,
          explanation: isAr
            ? `صحيح؛ هذه المعلومة مقتبسة مباشرة من درس «${lesson.title}» (${lesson.subject})${baseExplanationSuffix}.`
            : `True; this statement appears directly in "${lesson.title}"${baseExplanationSuffix}.`,
          sourceLessonId: lesson.id,
          sourceLessonTitle: lesson.title,
          sourceFormat: fmt,
        });
      }
    }

    // C. Core Lesson / Video / File Metadata Questions (always available for every real DB lesson)
    const descClean = stripHtmlTags(lesson.description);
    if (descClean.length >= 5) {
      const distractors = pickDistractors(
        descClean,
        allDescriptions,
        isAr
          ? [
              'مراجعة تطبيقية عامة خارج محاور هذا الدرس.',
              'ملخص تمهيدي لوحدة دراسية لاحقة في الفصل القادم.',
              'تدريب إثرائي غير مرتبط بمحتوى هذا الفيديو أو الملف.',
            ]
          : [
              'General review outside this lesson scope.',
              'Introductory summary for a later term.',
              'Supplemental drill unrelated to this file.',
            ]
      );
      candidates.push(
        buildMcq(
          `dbq-desc-mcq-${lesson.id}-${Date.now()}`,
          isAr
            ? `ما الهدف أو الوصف العلمي الرئيسي لدرس «${lesson.title}» (${fmtLabel})؟`
            : `What is the primary topic/description of "${lesson.title}" (${fmtLabel})?`,
          descClean,
          distractors,
          isAr
            ? `الدرس «${lesson.title}» يركز على: ${descClean}${baseExplanationSuffix}`
            : `Lesson "${lesson.title}" focuses on: ${descClean}${baseExplanationSuffix}`,
          lesson
        )
      );

      candidates.push({
        id: `dbq-desc-tf-${lesson.id}-${Date.now()}`,
        questionType: 'true_false',
        question: isAr
          ? `يتناول درس «${lesson.title}» في مادة ${lesson.subject}: ${descClean}.`
          : `Lesson "${lesson.title}" in ${lesson.subject} covers: ${descClean}.`,
        options: tfLabels,
        correctOptionIndex: 0,
        explanation: isAr
          ? `صحيح؛ تم توثيق هذا المحور ضمن بيانات درس «${lesson.title}» للصف «${lesson.grade}»${baseExplanationSuffix}.`
          : `True; documented for "${lesson.title}" (${lesson.grade})${baseExplanationSuffix}.`,
        sourceLessonId: lesson.id,
        sourceLessonTitle: lesson.title,
        sourceFormat: fmt,
      });
    }

    if (lesson.unit && lesson.unit.trim()) {
      const unitClean = lesson.unit.trim();
      const unitDistractors = pickDistractors(
        unitClean,
        allUnits,
        isAr
          ? ['الوحدة التمهيدية العامة', 'وحدة التطبيقات الإثرائية', 'الوحدة الختامية للمراجعة']
          : ['Introductory Unit', 'Enrichment Applications Unit', 'Final Review Unit']
      );
      candidates.push(
        buildMcq(
          `dbq-unit-mcq-${lesson.id}-${Date.now()}`,
          isAr
            ? `ضمن أي وحدة دراسية يُدرّس محتوى «${lesson.title}»؟`
            : `Which curriculum unit contains "${lesson.title}"?`,
          unitClean,
          unitDistractors,
          isAr
            ? `يندرج درس «${lesson.title}» تحت «${unitClean}» في مادة ${lesson.subject}${baseExplanationSuffix}.`
            : `"${lesson.title}" belongs to "${unitClean}" in ${lesson.subject}${baseExplanationSuffix}`,
          lesson
        )
      );
    }

    // Grade/Format verification True/False question (creates balanced False questions using real DB values)
    const wrongGrade = allGrades.find((g) => g !== lesson.grade);
    const wrongFormatKey = (['video', 'pdf', 'word', 'infographic'] as const).find((k) => k !== fmt);
    if (wrongGrade) {
      candidates.push({
        id: `dbq-grade-tf-${lesson.id}-${Date.now()}`,
        questionType: 'true_false',
        question: isAr
          ? `درس «${lesson.title}» (${lesson.subject}) مخصّص لطلاب «${wrongGrade}».`
          : `Lesson "${lesson.title}" (${lesson.subject}) is assigned to "${wrongGrade}".`,
        options: tfLabels,
        correctOptionIndex: 1,
        explanation: isAr
          ? `خطأ؛ درس «${lesson.title}» مخصص لطلاب «${lesson.grade}» بإشراف ${lesson.teacherName}${baseExplanationSuffix}.`
          : `False; "${lesson.title}" is assigned to "${lesson.grade}" taught by ${lesson.teacherName}${baseExplanationSuffix}.`,
        sourceLessonId: lesson.id,
        sourceLessonTitle: lesson.title,
        sourceFormat: fmt,
      });
    } else if (wrongFormatKey) {
      candidates.push({
        id: `dbq-fmt-tf-${lesson.id}-${Date.now()}`,
        questionType: 'true_false',
        question: isAr
          ? `يتوفر درس «${lesson.title}» حالياً بصيغة «${formatLabels[wrongFormatKey]}» وليس «${fmtLabel}».`
          : `Lesson "${lesson.title}" is provided as "${formatLabels[wrongFormatKey]}" rather than "${fmtLabel}".`,
        options: tfLabels,
        correctOptionIndex: 1,
        explanation: isAr
          ? `خطأ؛ الصيغة المعتمدة لدرس «${lesson.title}» في قاعدة البيانات هي «${fmtLabel}»${baseExplanationSuffix}.`
          : `False; "${lesson.title}" is stored in database as "${formatLabels[wrongFormatKey] ? fmtLabel : fmt}"${baseExplanationSuffix}.`,
        sourceLessonId: lesson.id,
        sourceLessonTitle: lesson.title,
        sourceFormat: fmt,
      });
    }
  }

  // D. Also include real questions already saved inside DB quizzes matching selected lessons' subjects
  const selectedSubjects = new Set(selectedLessons.map((l) => l.subject));
  const savedQuizzes = await db.select().from(quizzes);
  for (const sq of savedQuizzes) {
    if (!selectedSubjects.has(sq.subject)) continue;
    try {
      const sqQuestions = JSON.parse(sq.questions || '[]');
      if (Array.isArray(sqQuestions)) {
        for (const qItem of sqQuestions) {
          if (qItem && qItem.question && Array.isArray(qItem.options)) {
            candidates.push({
              ...qItem,
              id: `dbq-existing-${sq.id}-${qItem.id || Math.random().toString(36).slice(2, 6)}`,
              questionType:
                qItem.questionType ||
                (qItem.options.length === 2 && (qItem.options[0] === 'صح' || qItem.options[0] === 'True')
                  ? 'true_false'
                  : 'mcq'),
            });
          }
        }
      }
    } catch {
      // skip invalid json
    }
  }

  // Filter & balance according to questionMix
  let filteredPool = shuffleItems(candidates);
  if (questionMix === 'mcq') {
    filteredPool = filteredPool.filter((q) => q.questionType !== 'true_false');
  } else if (questionMix === 'true_false') {
    filteredPool = filteredPool.filter((q) => q.questionType === 'true_false');
  }

  let selectedQuestions: any[] = [];
  if (questionMix === 'mixed') {
    const mcqs = filteredPool.filter((q) => q.questionType !== 'true_false');
    const tfs = filteredPool.filter((q) => q.questionType === 'true_false');
    const desiredTf = Math.max(1, Math.floor(requestedCount * 0.4));
    const takenTf = tfs.slice(0, desiredTf);
    const takenMcq = mcqs.slice(0, requestedCount - takenTf.length);
    selectedQuestions = shuffleItems([...takenMcq, ...takenTf]);
    if (selectedQuestions.length < requestedCount) {
      const usedIds = new Set(selectedQuestions.map((x) => x.id));
      const extras = filteredPool.filter((x) => !usedIds.has(x.id));
      selectedQuestions = [...selectedQuestions, ...extras.slice(0, requestedCount - selectedQuestions.length)];
    }
  } else {
    selectedQuestions = filteredPool.slice(0, requestedCount);
  }

  // If fewer unique questions exist than requestedCount, return unique ones (no fake padding!)
  return {
    questions: selectedQuestions.slice(0, requestedCount),
    sourceLessons: selectedLessons.map((l) => ({
      id: l.id,
      title: l.title,
      subject: l.subject,
      grade: l.grade,
      format: l.format,
      teacherName: l.teacherName,
      videoUrl: l.videoUrl,
      documentUrl: l.documentUrl,
      durationOrPages: l.durationOrPages,
    })),
    totalAvailablePool: filteredPool.length,
  };
}

// ---------------- Quiz Attempts & Automatic Certificates / Grade Reports ----------------
function normalizeCertificateRow(row: any) {
  let breakdown: any[] = [];
  if (typeof row.breakdownJson === 'string' && row.breakdownJson.trim()) {
    try {
      const parsed = JSON.parse(row.breakdownJson);
      if (Array.isArray(parsed)) breakdown = parsed;
    } catch {
      breakdown = [];
    }
  } else if (Array.isArray(row.breakdown)) {
    breakdown = row.breakdown;
  }

  return {
    id: row.id,
    studentId: row.studentId,
    studentName: row.studentName,
    studentGrade: row.studentGrade,
    type: row.type === 'grades_report' ? 'grades_report' : 'excellence',
    subjectOrTrack: row.subjectOrTrack || '',
    score: Number(row.score) || 0,
    issueDate: row.issueDate || new Date().toISOString().split('T')[0],
    academicYear: row.academicYear || '2026 - 2027',
    principalName: row.principalName || 'د. عبد العزيز الأحمدي',
    notes: row.notes || '',
    serialNumber: row.serialNumber || `CERT-${Date.now()}`,
    examPeriod: (row.examPeriod as 'weekly' | 'monthly' | 'all') || 'all',
    weeklyAverage: row.weeklyAverage !== null && row.weeklyAverage !== undefined ? Number(row.weeklyAverage) : null,
    monthlyAverage: row.monthlyAverage !== null && row.monthlyAverage !== undefined ? Number(row.monthlyAverage) : null,
    examsCount: Number(row.examsCount) || breakdown.length || 0,
    breakdown,
    isAutoGenerated: row.isAutoGenerated ?? true,
  };
}

export async function getAllQuizAttempts(filters?: { studentId?: string; quizType?: string }) {
  try {
    const allRows = await db.select().from(quizAttempts).orderBy(desc(quizAttempts.createdAt));
    return allRows.filter((row) => {
      if (filters?.studentId && row.studentId !== filters.studentId) return false;
      if (filters?.quizType && filters.quizType !== 'all' && row.quizType !== filters.quizType) return false;
      return true;
    });
  } catch (error) {
    console.error('Failed to query quiz attempts:', error);
    throw new Error('Failed to query quiz attempts from database', { cause: error });
  }
}

export async function getAllCertificates() {
  try {
    const [rows, studentRows] = await Promise.all([
      db.select().from(certificates).orderBy(desc(certificates.createdAt)),
      db.select({ id: students.id, avatar: students.avatar }).from(students),
    ]);
    const avatarMap = new Map(studentRows.map((s) => [s.id, s.avatar || null]));
    return rows.map((row) => ({
      ...normalizeCertificateRow(row),
      studentAvatar: avatarMap.get(row.studentId) || null,
    }));
  } catch (error) {
    console.error('Failed to query certificates:', error);
    throw new Error('Failed to query certificates from database', { cause: error });
  }
}

export async function createCertificate(data: any) {
  try {
    const id = data.id || `cert-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const payload = {
      id,
      studentId: String(data.studentId || ''),
      studentName: String(data.studentName || ''),
      studentGrade: String(data.studentGrade || 'الصف الثالث الثانوي'),
      type: data.type === 'grades_report' ? 'grades_report' : 'excellence',
      subjectOrTrack: data.subjectOrTrack || (data.type === 'grades_report' ? 'بيان الدرجات المعتمد' : 'شهادة تقدير وتفوق'),
      score: Math.round(Number(data.score) || 0),
      issueDate: data.issueDate || new Date().toISOString().split('T')[0],
      academicYear: data.academicYear || '2026 - 2027',
      principalName: data.principalName || 'إدارة الأكاديمية',
      notes: data.notes || '',
      serialNumber: data.serialNumber || `CERT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      examPeriod: data.examPeriod || 'all',
      weeklyAverage: data.weeklyAverage !== undefined && data.weeklyAverage !== null ? Math.round(Number(data.weeklyAverage)) : null,
      monthlyAverage: data.monthlyAverage !== undefined && data.monthlyAverage !== null ? Math.round(Number(data.monthlyAverage)) : null,
      examsCount: Number(data.examsCount) || (Array.isArray(data.breakdown) ? data.breakdown.length : 0),
      breakdownJson: Array.isArray(data.breakdown)
        ? JSON.stringify(data.breakdown)
        : typeof data.breakdownJson === 'string'
        ? data.breakdownJson
        : '[]',
      isAutoGenerated: data.isAutoGenerated ?? false,
      createdAt: new Date(),
    };
    const res = await db.insert(certificates).values(payload).returning();
    let stuAvatar: string | null = null;
    if (payload.studentId) {
      const sRow = await db.select({ avatar: students.avatar }).from(students).where(eq(students.id, payload.studentId)).limit(1);
      stuAvatar = sRow[0]?.avatar || null;
    }
    return { ...normalizeCertificateRow(res[0]), studentAvatar: stuAvatar };
  } catch (error: any) {
    console.error('Failed to create certificate:', error);
    throw new Error(`Failed to create certificate in database: ${error?.message || error}`);
  }
}

export async function updateCertificate(id: string, data: any) {
  try {
    const payload: Record<string, any> = {};
    if (data.studentId !== undefined) payload.studentId = String(data.studentId);
    if (data.studentName !== undefined) payload.studentName = String(data.studentName);
    if (data.studentGrade !== undefined) payload.studentGrade = String(data.studentGrade);
    if (data.type !== undefined) payload.type = data.type === 'grades_report' ? 'grades_report' : 'excellence';
    if (data.subjectOrTrack !== undefined) payload.subjectOrTrack = String(data.subjectOrTrack);
    if (data.score !== undefined) payload.score = Math.round(Number(data.score) || 0);
    if (data.issueDate !== undefined) payload.issueDate = String(data.issueDate);
    if (data.academicYear !== undefined) payload.academicYear = String(data.academicYear);
    if (data.principalName !== undefined) payload.principalName = String(data.principalName);
    if (data.notes !== undefined) payload.notes = String(data.notes);
    if (data.serialNumber !== undefined) payload.serialNumber = String(data.serialNumber);
    if (data.examPeriod !== undefined) payload.examPeriod = String(data.examPeriod);

    const res = await db
      .update(certificates)
      .set(payload)
      .where(eq(certificates.id, id))
      .returning();
    if (!res[0]) return null;
    let stuAvatar: string | null = null;
    if (res[0].studentId) {
      const sRow = await db.select({ avatar: students.avatar }).from(students).where(eq(students.id, res[0].studentId)).limit(1);
      stuAvatar = sRow[0]?.avatar || null;
    }
    return { ...normalizeCertificateRow(res[0]), studentAvatar: stuAvatar };
  } catch (error: any) {
    console.error('Failed to update certificate:', error);
    throw new Error(`Failed to update certificate in database: ${error?.message || error}`);
  }
}

export async function deleteCertificate(id: string) {
  try {
    await db.delete(certificates).where(eq(certificates.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete certificate:', error);
    throw new Error('Failed to delete certificate from database', { cause: error });
  }
}

async function recalculateStudentAndQuizFromAttempts(studentId: string, quizId?: string) {
  // 1. Update quiz aggregate stats from real attempts
  let updatedQuiz = null;
  if (quizId) {
    const qRows = await db.select().from(quizAttempts).where(eq(quizAttempts.quizId, quizId));
    const qTarget = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);
    if (qTarget[0]) {
      const count = qRows.length;
      const avgMarks = count > 0
        ? Math.round(qRows.reduce((sum, r) => sum + Number(r.earnedMarks || 0), 0) / count)
        : 0;
      const qUpd = await db
        .update(quizzes)
        .set({ completedStudentsCount: count, averageScore: avgMarks })
        .where(eq(quizzes.id, quizId))
        .returning();
      updatedQuiz = qUpd[0] || null;
    }
  }

  // 2. Update student's overallScore & status from real attempts
  let updatedStudent = null;
  if (studentId) {
    const sRows = await db.select().from(quizAttempts).where(eq(quizAttempts.studentId, studentId));
    const sTarget = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
    if (sTarget[0] && sRows.length > 0) {
      const overallPct = Math.round(
        sRows.reduce((sum, r) => sum + Number(r.percentage || 0), 0) / sRows.length
      );
      const attendance = Number(sTarget[0].attendanceRate ?? 95);
      const nextStatus = overallPct >= 90 ? 'top' : overallPct < 60 || attendance < 70 ? 'weak' : 'regular';
      const sUpd = await db
        .update(students)
        .set({ overallScore: overallPct, status: nextStatus })
        .where(eq(students.id, studentId))
        .returning();
      updatedStudent = sUpd[0] || null;
    }
  }

  return { updatedQuiz, updatedStudent };
}

export async function autoGenerateCertificatesFromExamAttempts(options?: {
  period?: 'all' | 'weekly' | 'monthly';
  excellenceThreshold?: number;
  onlyQualifiedForReports?: boolean;
  studentId?: string;
  academicYear?: string;
  principalName?: string;
}) {
  const period: 'all' | 'weekly' | 'monthly' =
    options?.period === 'weekly' || options?.period === 'monthly' ? options.period : 'all';
  const excellenceThreshold = Math.max(50, Math.min(100, Number(options?.excellenceThreshold) || 80));
  const onlyQualifiedForReports = options?.onlyQualifiedForReports ?? true;

  const [allAttempts, allStudents, schoolRows] = await Promise.all([
    db.select().from(quizAttempts).orderBy(desc(quizAttempts.createdAt)),
    db.select().from(students),
    db.select().from(schoolSettings).where(eq(schoolSettings.id, 'main_school')).limit(1),
  ]);

  const academicYear = options?.academicYear || schoolRows[0]?.academicYear || '2026 - 2027';
  const schoolName = schoolRows[0]?.schoolName || 'أكاديمية نوابغ التعليمية';
  const principalName = options?.principalName || `إدارة ${schoolName}`;
  const today = new Date().toISOString().split('T')[0];

  const scopedAttempts = allAttempts.filter((a) => {
    if (options?.studentId && a.studentId !== options.studentId) return false;
    if (period !== 'all' && a.quizType !== period) return false;
    return true;
  });

  if (scopedAttempts.length === 0) {
    return {
      certificates: [],
      generatedCount: 0,
      updatedCount: 0,
      totalStudentsProcessed: 0,
      message: 'لا توجد درجات امتحانات مسجلة في قاعدة البيانات لهذا التصنيف بعد.',
    };
  }

  const studentLookup = new Map(allStudents.map((s) => [s.id, s]));
  const grouped = new Map<string, typeof scopedAttempts>();
  for (const att of scopedAttempts) {
    const arr = grouped.get(att.studentId) || [];
    arr.push(att);
    grouped.set(att.studentId, arr);
  }

  const upsertedCerts: any[] = [];
  let generatedCount = 0;
  let updatedCount = 0;

  for (const [stuId, stuAttempts] of grouped.entries()) {
    const stuRecord = studentLookup.get(stuId);
    const stuName = stuRecord?.name || stuAttempts[0].studentName;
    const stuGrade = stuRecord?.grade || stuAttempts[0].grade;
    const stuCode = stuRecord?.code || stuAttempts[0].studentCode || stuId;

    // Also inspect all student attempts for weekly/monthly averages even when period === 'all'
    const allStuAttempts = allAttempts.filter((a) => a.studentId === stuId);
    const weeklyList = allStuAttempts.filter((a) => a.quizType === 'weekly');
    const monthlyList = allStuAttempts.filter((a) => a.quizType === 'monthly');

    const weeklyAvg = weeklyList.length > 0
      ? Math.round(weeklyList.reduce((s, r) => s + Number(r.percentage || 0), 0) / weeklyList.length)
      : null;
    const monthlyAvg = monthlyList.length > 0
      ? Math.round(monthlyList.reduce((s, r) => s + Number(r.percentage || 0), 0) / monthlyList.length)
      : null;

    const rawPeriodAvg = Math.round(
      stuAttempts.reduce((s, r) => s + Number(r.percentage || 0), 0) / stuAttempts.length
    );
    const periodAvg = Math.min(100, Math.max(0, rawPeriodAvg));
    const getHonorTierAr = (score: number) => {
      if (score >= 95) return 'امتياز مع مرتبة الشرف العليا (95% - 100%)';
      if (score >= 90) return 'امتياز وتفوق رفيع (90% - 94%)';
      if (score >= 85) return 'تفوق متميز (85% - 89%)';
      return 'تقدير جيد جداً متقدم (80% - 84%)';
    };

    const breakdown = stuAttempts.map((a) => ({
      attemptId: a.id,
      quizId: a.quizId,
      quizTitle: a.quizTitle,
      quizType: (a.quizType === 'monthly' ? 'monthly' : 'weekly') as 'weekly' | 'monthly',
      subject: a.subject,
      earnedMarks: Number(a.earnedMarks),
      totalMarks: Number(a.totalMarks),
      percentage: Number(a.percentage),
      takenDate: a.takenDate,
    }));

    const subjectsList = Array.from(new Set(stuAttempts.map((a) => a.subject))).join('، ');
    const periodLabelAr =
      period === 'weekly'
        ? 'الاختبارات الأسبوعية'
        : period === 'monthly'
        ? 'الاختبارات الشهرية'
        : 'الاختبارات الأسبوعية والشهرية';

    // 1. Auto-issue / update Certified Grades Report (بيان درجات)
    const reportId = `auto-rep-${stuId}-${period}`;
    const existingReport = await db.select().from(certificates).where(eq(certificates.id, reportId)).limit(1);

    if (!onlyQualifiedForReports || (periodAvg >= excellenceThreshold && periodAvg <= 100)) {
      const reportSerial =
        existingReport[0]?.serialNumber ||
        `REP-${new Date().getFullYear()}-${String(stuCode).replace(/[^A-Z0-9]/gi, '').slice(-4) || 'DB'}-${period.toUpperCase().slice(0, 2)}`;

      const reportNotes =
        `بيان درجات أوتوماتيك مستخرج من قاعدة البيانات لتحقيق معدل (${periodAvg}%) في ${periodLabelAr} عبر (${stuAttempts.length}) اختبارات` +
        (subjectsList ? ` لمواد: ${subjectsList}.` : '.') +
        (weeklyAvg !== null ? ` متوسط الأسبوعي: ${weeklyAvg}%.` : '') +
        (monthlyAvg !== null ? ` متوسط الشهري: ${monthlyAvg}%.` : '');

      const reportPayload = {
        id: reportId,
        studentId: stuId,
        studentName: stuName,
        studentGrade: stuGrade,
        type: 'grades_report',
        subjectOrTrack: `بيان درجات ${periodLabelAr} (${subjectsList || 'كافة المواد'})`,
        score: periodAvg,
        issueDate: today,
        academicYear,
        principalName,
        notes: reportNotes,
        serialNumber: reportSerial,
        examPeriod: period,
        weeklyAverage: weeklyAvg,
        monthlyAverage: monthlyAvg,
        examsCount: stuAttempts.length,
        breakdownJson: JSON.stringify(breakdown),
        isAutoGenerated: true,
      };

      const repRes = await db
        .insert(certificates)
        .values({ ...reportPayload, createdAt: new Date() })
        .onConflictDoUpdate({
          target: certificates.id,
          set: reportPayload,
        })
        .returning();

      upsertedCerts.push({ ...normalizeCertificateRow(repRes[0]), studentAvatar: stuRecord?.avatar || null });
      if (existingReport[0]) updatedCount++;
      else generatedCount++;
    } else if (existingReport[0]) {
      // Remove stale auto-generated report if student average dropped below threshold
      await db.delete(certificates).where(eq(certificates.id, reportId));
    }

    // 2. Auto-issue / update Excellence Certificate (شهادة تقدير وتفوق) if score is in [threshold..100] (default 80% to 100%)
    const excId = `auto-exc-${stuId}-${period}`;
    const existingExc = await db.select().from(certificates).where(eq(certificates.id, excId)).limit(1);

    if (periodAvg >= excellenceThreshold && periodAvg <= 100) {
      const honorTier = getHonorTierAr(periodAvg);
      const excSerial =
        existingExc[0]?.serialNumber ||
        `EX-${new Date().getFullYear()}-${String(stuCode).replace(/[^A-Z0-9]/gi, '').slice(-4) || 'DB'}-${period.toUpperCase().slice(0, 2)}`;

      const excNotes =
        `شهادة تقدير وتفوق أوتوماتيك (${honorTier}) ممنوحة لاستيفاء معدل (${periodAvg}% — ضمن النطاق المعتمد ${excellenceThreshold}% إلى 100%) في ${periodLabelAr} عبر (${stuAttempts.length}) اختبارات مسجلة في قاعدة البيانات` +
        (subjectsList ? ` (${subjectsList}).` : '.');

      const excPayload = {
        id: excId,
        studentId: stuId,
        studentName: stuName,
        studentGrade: stuGrade,
        type: 'excellence',
        subjectOrTrack: `${honorTier} — ${periodLabelAr}`,
        score: periodAvg,
        issueDate: today,
        academicYear,
        principalName,
        notes: excNotes,
        serialNumber: excSerial,
        examPeriod: period,
        weeklyAverage: weeklyAvg,
        monthlyAverage: monthlyAvg,
        examsCount: stuAttempts.length,
        breakdownJson: JSON.stringify(breakdown),
        isAutoGenerated: true,
      };

      const excRes = await db
        .insert(certificates)
        .values({ ...excPayload, createdAt: new Date() })
        .onConflictDoUpdate({
          target: certificates.id,
          set: excPayload,
        })
        .returning();

      upsertedCerts.push({ ...normalizeCertificateRow(excRes[0]), studentAvatar: stuRecord?.avatar || null });
      if (existingExc[0]) updatedCount++;
      else generatedCount++;
    } else if (existingExc[0]) {
      // Remove stale auto-generated excellence certificate if score dropped below threshold
      await db.delete(certificates).where(eq(certificates.id, excId));
    }
  }

  return {
    certificates: upsertedCerts,
    generatedCount,
    updatedCount,
    totalStudentsProcessed: grouped.size,
    excellenceThreshold,
    message:
      upsertedCerts.length > 0
        ? `تم إصدار وتحديث ${upsertedCerts.length} وثيقة أوتوماتيك للدرجات من ${excellenceThreshold}% فما فوق (من أصل ${grouped.size} طالب مسجل).`
        : `تم فحص ${grouped.size} طالب مسجل: لم يستوفِ أي طالب شرط الدرجة (${excellenceThreshold}% فما فوق) بعد.`,
  };
}

export async function recordQuizAttemptAndSyncCertificates(data: any) {
  try {
    const earnedMarks = Math.max(0, Math.round(Number(data.earnedMarks) || 0));
    const totalMarks = Math.max(1, Math.round(Number(data.totalMarks) || 100));
    const percentage =
      data.percentage !== undefined
        ? Math.min(100, Math.max(0, Math.round(Number(data.percentage))))
        : Math.min(100, Math.round((earnedMarks / totalMarks) * 100));

    const payload = {
      id: data.id || `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      quizId: String(data.quizId || 'manual-exam'),
      quizTitle: String(data.quizTitle || 'اختبار دوري'),
      quizType: data.quizType === 'monthly' ? 'monthly' : 'weekly',
      subject: String(data.subject || 'عام'),
      grade: String(data.grade || 'الصف الثالث الثانوي'),
      studentId: String(data.studentId),
      studentName: String(data.studentName || 'طالب'),
      studentCode: data.studentCode || null,
      earnedMarks,
      totalMarks,
      percentage,
      correctCount: Math.max(0, Math.round(Number(data.correctCount) || 0)),
      totalQuestions: Math.max(1, Math.round(Number(data.totalQuestions) || 1)),
      takenDate: data.takenDate || new Date().toISOString().split('T')[0],
      createdAt: new Date(),
    };

    const inserted = await db.insert(quizAttempts).values(payload).returning();
    const attempt = inserted[0];

    const { updatedQuiz, updatedStudent } = await recalculateStudentAndQuizFromAttempts(
      attempt.studentId,
      attempt.quizId
    );

    // Automatically generate/update BOTH combined ('all') and period-specific ('weekly' | 'monthly') certificates & grade reports (default 80%+)
    const threshold = Number(data.excellenceThreshold) || 80;
    const onlyQualifiedForReports = data.onlyQualifiedForReports ?? true;
    const [allSync, periodSync] = await Promise.all([
      autoGenerateCertificatesFromExamAttempts({
        period: 'all',
        studentId: attempt.studentId,
        excellenceThreshold: threshold,
        onlyQualifiedForReports,
      }),
      autoGenerateCertificatesFromExamAttempts({
        period: attempt.quizType === 'monthly' ? 'monthly' : 'weekly',
        studentId: attempt.studentId,
        excellenceThreshold: threshold,
        onlyQualifiedForReports,
      }),
    ]);

    const autoCertificates = [...allSync.certificates, ...periodSync.certificates];

    return {
      attempt,
      updatedQuiz,
      updatedStudent,
      autoCertificates,
    };
  } catch (error: any) {
    console.error('Failed to record quiz attempt:', error);
    throw new Error(`Failed to record exam attempt in database: ${error?.message || error}`);
  }
}

export async function deleteQuizAttempt(id: string) {
  try {
    const existing = await db.select().from(quizAttempts).where(eq(quizAttempts.id, id)).limit(1);
    await db.delete(quizAttempts).where(eq(quizAttempts.id, id));
    let updatedQuiz = null;
    let updatedStudent = null;
    if (existing[0]) {
      const recalc = await recalculateStudentAndQuizFromAttempts(existing[0].studentId, existing[0].quizId);
      updatedQuiz = recalc.updatedQuiz;
      updatedStudent = recalc.updatedStudent;

      const remaining = await db
        .select()
        .from(quizAttempts)
        .where(eq(quizAttempts.studentId, existing[0].studentId));

      if (remaining.length === 0) {
        // Remove auto-generated certificates for this student if zero attempts remain
        const existingCerts = await db
          .select()
          .from(certificates)
          .where(eq(certificates.studentId, existing[0].studentId));
        for (const c of existingCerts) {
          if (c.isAutoGenerated) {
            await db.delete(certificates).where(eq(certificates.id, c.id));
          }
        }
      } else {
        await Promise.all([
          autoGenerateCertificatesFromExamAttempts({
            period: 'all',
            studentId: existing[0].studentId,
          }),
          autoGenerateCertificatesFromExamAttempts({
            period: existing[0].quizType === 'monthly' ? 'monthly' : 'weekly',
            studentId: existing[0].studentId,
          }),
        ]);
      }
    }
    return { success: true, id, updatedQuiz, updatedStudent };
  } catch (error: any) {
    console.error('Failed to delete quiz attempt:', error);
    throw new Error(`Failed to delete exam attempt: ${error?.message || error}`);
  }
}

export async function updateQuizAttempt(id: string, data: any) {
  try {
    const existing = await db.select().from(quizAttempts).where(eq(quizAttempts.id, id)).limit(1);
    if (!existing[0]) {
      throw new Error('Exam attempt not found');
    }

    const earnedMarks =
      data.earnedMarks !== undefined
        ? Math.max(0, Math.round(Number(data.earnedMarks) || 0))
        : existing[0].earnedMarks;
    const totalMarks =
      data.totalMarks !== undefined
        ? Math.max(1, Math.round(Number(data.totalMarks) || 1))
        : existing[0].totalMarks;
    const percentage = Math.min(100, Math.max(0, Math.round((earnedMarks / totalMarks) * 100)));

    const payload: Record<string, any> = {
      earnedMarks,
      totalMarks,
      percentage,
    };
    if (data.quizTitle !== undefined) payload.quizTitle = String(data.quizTitle);
    if (data.quizType !== undefined) payload.quizType = data.quizType === 'monthly' ? 'monthly' : 'weekly';
    if (data.subject !== undefined) payload.subject = String(data.subject);
    if (data.takenDate !== undefined) payload.takenDate = String(data.takenDate);

    const res = await db.update(quizAttempts).set(payload).where(eq(quizAttempts.id, id)).returning();
    const updatedAttempt = res[0];

    const { updatedQuiz, updatedStudent } = await recalculateStudentAndQuizFromAttempts(
      updatedAttempt.studentId,
      updatedAttempt.quizId
    );

    const threshold = Number(data.excellenceThreshold) || 80;
    const onlyQualifiedForReports = data.onlyQualifiedForReports ?? true;
    await Promise.all([
      autoGenerateCertificatesFromExamAttempts({
        period: 'all',
        studentId: updatedAttempt.studentId,
        excellenceThreshold: threshold,
        onlyQualifiedForReports,
      }),
      autoGenerateCertificatesFromExamAttempts({
        period: updatedAttempt.quizType === 'monthly' ? 'monthly' : 'weekly',
        studentId: updatedAttempt.studentId,
        excellenceThreshold: threshold,
        onlyQualifiedForReports,
      }),
    ]);

    return { attempt: updatedAttempt, updatedQuiz, updatedStudent };
  } catch (error: any) {
    console.error('Failed to update quiz attempt:', error);
    throw new Error(`Failed to update exam attempt: ${error?.message || error}`);
  }
}

// ---------------- Parent Communication CRUD & Rich Messaging ----------------
function parseJsonStringArray(val: any): string[] {
  if (Array.isArray(val)) return val.map((v) => String(v)).filter(Boolean);
  if (typeof val === 'string' && val.trim()) {
    try {
      const parsed = JSON.parse(val);
      return Array.isArray(parsed) ? parsed.map((v) => String(v)).filter(Boolean) : [];
    } catch {
      return [];
    }
  }
  return [];
}

const VALID_CHANNEL_TYPES = new Set([
  'student_teacher',
  'parent_teacher',
  'teacher_admin',
  'private_group',
  'public_group',
]);

const VALID_CHAT_SENDERS = new Set([
  'student',
  'female_student',
  'teacher',
  'parent',
  'admin',
  'secretary',
  'supervisor',
]);

function normalizeParentMessage(row: any) {
  const sender = VALID_CHAT_SENDERS.has(row.sender) ? row.sender : 'teacher';
  return {
    id: row.id,
    conversationId: row.conversationId,
    sender: sender as
      | 'student'
      | 'female_student'
      | 'teacher'
      | 'parent'
      | 'admin'
      | 'secretary'
      | 'supervisor',
    senderId: row.senderId || '',
    senderName: row.senderName || 'الإدارة التعليمية',
    senderRoleLabel: row.senderRoleLabel || '',
    messageType: (row.messageType || 'text') as
      | 'text'
      | 'audio'
      | 'image'
      | 'video'
      | 'file'
      | 'sticker'
      | 'call_log',
    text: row.text || '',
    mediaUrl: row.mediaUrl || null,
    fileName: row.fileName || null,
    fileSize: row.fileSize || null,
    mimeType: row.mimeType || null,
    durationSeconds:
      row.durationSeconds !== null && row.durationSeconds !== undefined
        ? Number(row.durationSeconds)
        : null,
    stickerKey: row.stickerKey || null,
    stickerCategory: row.stickerCategory || null,
    stickerLabel: row.stickerLabel || null,
    timestamp: row.timestamp || '',
    read: Boolean(row.read),
    createdAt: row.createdAt ? new Date(row.createdAt).toISOString() : undefined,
  };
}

function normalizeParentConversation(row: any, msgs: any[] = []) {
  const channelType = VALID_CHANNEL_TYPES.has(row.channelType)
    ? row.channelType
    : 'parent_teacher';
  return {
    id: row.id,
    channelType: channelType as
      | 'student_teacher'
      | 'parent_teacher'
      | 'teacher_admin'
      | 'private_group'
      | 'public_group',
    title: row.title || '',
    description: row.description || '',
    studentId: row.studentId || '',
    studentName: row.studentName || '',
    studentGrade: row.studentGrade || '',
    teacherId: row.teacherId || '',
    teacherName: row.teacherName || '',
    adminName: row.adminName || '',
    parentName: row.parentName || '',
    parentPhone: row.parentPhone || '',
    parentEmail: row.parentEmail || '',
    createdById: row.createdById || '',
    createdByName: row.createdByName || '',
    createdByRole: row.createdByRole || 'admin',
    memberIds: parseJsonStringArray(row.memberIds),
    memberNames: parseJsonStringArray(row.memberNames),
    targetAudience: (row.targetAudience || 'all') as
      | 'all'
      | 'students'
      | 'parents'
      | 'teachers'
      | 'staff',
    status: (row.status === 'needs_followup' || row.status === 'archived'
      ? row.status
      : 'active') as 'active' | 'needs_followup' | 'archived',
    warningCount: Number(row.warningCount) || 0,
    notes: row.notes || '',
    lastMessage: row.lastMessage || '',
    lastTimestamp: row.lastTimestamp || '',
    unreadCount: Number(row.unreadCount) || 0,
    messages: msgs.map(normalizeParentMessage),
    createdAt: row.createdAt ? new Date(row.createdAt).toISOString() : undefined,
    updatedAt: row.updatedAt ? new Date(row.updatedAt).toISOString() : undefined,
  };
}

function buildMessagePreview(msg: {
  messageType?: string;
  text?: string;
  fileName?: string | null;
  durationSeconds?: number | null;
  stickerLabel?: string | null;
}): string {
  const t = msg.messageType || 'text';
  if (t === 'audio') {
    const dur = msg.durationSeconds ? ` (${msg.durationSeconds}ث)` : '';
    return `🎤 تسجيل صوتي${dur}`;
  }
  if (t === 'image') {
    return msg.text?.trim() ? `🖼️ ${msg.text}` : `🖼️ صورة مرفقة${msg.fileName ? `: ${msg.fileName}` : ''}`;
  }
  if (t === 'video') {
    return msg.text?.trim() ? `🎬 ${msg.text}` : `🎬 مقطع فيديو${msg.fileName ? `: ${msg.fileName}` : ''}`;
  }
  if (t === 'file') {
    return `📎 ملف مرفق${msg.fileName ? `: ${msg.fileName}` : ''}`;
  }
  if (t === 'sticker') {
    return msg.stickerLabel || msg.text || '🏷️ ملصق تفاعلي';
  }
  if (t === 'call_log') {
    return `📞 ${msg.text || 'مكالمة صوتية'}`;
  }
  return msg.text || '';
}

export async function getAllParentConversations() {
  try {
    const [convRows, msgRows] = await Promise.all([
      db.select().from(parentConversations).orderBy(desc(parentConversations.updatedAt)),
      db.select().from(parentMessages).orderBy(asc(parentMessages.createdAt)),
    ]);

    const msgMap = new Map<string, any[]>();
    for (const m of msgRows) {
      const list = msgMap.get(m.conversationId) || [];
      list.push(m);
      msgMap.set(m.conversationId, list);
    }

    return convRows.map((c) => normalizeParentConversation(c, msgMap.get(c.id) || []));
  } catch (error) {
    console.error('Failed to query parent conversations:', error);
    throw new Error('Failed to query parent conversations from database', { cause: error });
  }
}

export async function getParentConversationById(id: string) {
  const [convRows, msgRows] = await Promise.all([
    db.select().from(parentConversations).where(eq(parentConversations.id, id)).limit(1),
    db
      .select()
      .from(parentMessages)
      .where(eq(parentMessages.conversationId, id))
      .orderBy(asc(parentMessages.createdAt)),
  ]);
  if (!convRows[0]) return null;
  return normalizeParentConversation(convRows[0], msgRows);
}

export async function createParentConversation(data: any) {
  try {
    const now = new Date();
    const convId =
      data.id || `conv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const nowLabel = new Date().toLocaleTimeString('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
    });

    const channelType = VALID_CHANNEL_TYPES.has(data.channelType)
      ? String(data.channelType)
      : 'parent_teacher';
    const memberIdsArr = parseJsonStringArray(data.memberIds);
    const memberNamesArr = parseJsonStringArray(data.memberNames);

    const studentName = String(
      data.studentName ||
        (channelType === 'teacher_admin'
          ? data.teacherName || 'تواصل معلم'
          : channelType === 'private_group' || channelType === 'public_group'
          ? data.title || 'مجموعة تواصل'
          : 'طالب')
    ).trim();

    const parentName = String(
      data.parentName ||
        (channelType === 'student_teacher'
          ? data.teacherName || 'المعلم'
          : channelType === 'teacher_admin'
          ? data.adminName || 'الإدارة العامة'
          : channelType === 'private_group'
          ? data.title || 'مجموعة خاصة'
          : channelType === 'public_group'
          ? data.title || 'مجموعة عامة'
          : 'ولي الأمر')
    ).trim();

    const payload = {
      id: convId,
      channelType,
      title: String(data.title || '').trim(),
      description: String(data.description || '').trim(),
      studentId: String(data.studentId || ''),
      studentName,
      studentGrade: String(data.studentGrade || ''),
      teacherId: String(data.teacherId || ''),
      teacherName: String(data.teacherName || ''),
      adminName: String(data.adminName || ''),
      parentName,
      parentPhone: String(data.parentPhone || ''),
      parentEmail: String(data.parentEmail || ''),
      createdById: String(data.createdById || ''),
      createdByName: String(data.createdByName || ''),
      createdByRole: String(data.createdByRole || 'admin'),
      memberIds: JSON.stringify(memberIdsArr),
      memberNames: JSON.stringify(memberNamesArr),
      targetAudience: String(data.targetAudience || 'all'),
      status:
        data.status === 'needs_followup' || data.status === 'archived'
          ? data.status
          : 'active',
      warningCount: Number(data.warningCount) || 0,
      notes: String(data.notes || ''),
      lastMessage: String(data.lastMessage || data.initialMessage || ''),
      lastTimestamp: data.lastMessage || data.initialMessage ? nowLabel : '',
      unreadCount: 0,
      createdAt: now,
      updatedAt: now,
    };

    await db.insert(parentConversations).values(payload);

    if (data.initialMessage && String(data.initialMessage).trim()) {
      await createParentMessage(convId, {
        sender: data.sender || data.createdByRole || 'teacher',
        senderId: data.senderId || data.createdById || '',
        senderName: data.senderName || data.createdByName || 'الإدارة التعليمية',
        senderRoleLabel: data.senderRoleLabel || '',
        messageType: 'text',
        text: String(data.initialMessage).trim(),
        read: true,
      });
    }

    return await getParentConversationById(convId);
  } catch (error: any) {
    console.error('Failed to create parent conversation:', error);
    throw new Error(`Failed to create parent conversation: ${error?.message || error}`);
  }
}

export async function updateParentConversation(id: string, data: any) {
  try {
    const payload: Record<string, any> = { updatedAt: new Date() };
    if (data.channelType !== undefined && VALID_CHANNEL_TYPES.has(data.channelType)) {
      payload.channelType = String(data.channelType);
    }
    if (data.title !== undefined) payload.title = String(data.title);
    if (data.description !== undefined) payload.description = String(data.description);
    if (data.studentId !== undefined) payload.studentId = String(data.studentId);
    if (data.studentName !== undefined) payload.studentName = String(data.studentName);
    if (data.studentGrade !== undefined) payload.studentGrade = String(data.studentGrade);
    if (data.teacherId !== undefined) payload.teacherId = String(data.teacherId);
    if (data.teacherName !== undefined) payload.teacherName = String(data.teacherName);
    if (data.adminName !== undefined) payload.adminName = String(data.adminName);
    if (data.parentName !== undefined) payload.parentName = String(data.parentName);
    if (data.parentPhone !== undefined) payload.parentPhone = String(data.parentPhone);
    if (data.parentEmail !== undefined) payload.parentEmail = String(data.parentEmail);
    if (data.memberIds !== undefined) {
      payload.memberIds = JSON.stringify(parseJsonStringArray(data.memberIds));
    }
    if (data.memberNames !== undefined) {
      payload.memberNames = JSON.stringify(parseJsonStringArray(data.memberNames));
    }
    if (data.targetAudience !== undefined) payload.targetAudience = String(data.targetAudience);
    if (data.status !== undefined) payload.status = String(data.status);
    if (data.warningCount !== undefined) payload.warningCount = Number(data.warningCount) || 0;
    if (data.notes !== undefined) payload.notes = String(data.notes);

    await db
      .update(parentConversations)
      .set(payload)
      .where(eq(parentConversations.id, id));

    return await getParentConversationById(id);
  } catch (error: any) {
    console.error('Failed to update parent conversation:', error);
    throw new Error(`Failed to update parent conversation: ${error?.message || error}`);
  }
}

export async function deleteParentConversation(id: string) {
  try {
    await db.delete(parentMessages).where(eq(parentMessages.conversationId, id));
    await db.delete(parentConversations).where(eq(parentConversations.id, id));
    return { success: true, id };
  } catch (error: any) {
    console.error('Failed to delete parent conversation:', error);
    throw new Error(`Failed to delete parent conversation: ${error?.message || error}`);
  }
}

export async function createParentMessage(conversationId: string, data: any) {
  try {
    const convRows = await db
      .select()
      .from(parentConversations)
      .where(eq(parentConversations.id, conversationId))
      .limit(1);

    if (!convRows[0]) {
      throw new Error('Conversation not found');
    }

    const msgId = data.id || `pmsg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const nowTime =
      data.timestamp ||
      new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });

    const sender = VALID_CHAT_SENDERS.has(data.sender) ? String(data.sender) : 'teacher';
    const messageType = data.messageType || 'text';

    const insertPayload = {
      id: msgId,
      conversationId,
      sender,
      senderId: String(data.senderId || ''),
      senderName: String(
        data.senderName || (sender === 'parent' ? convRows[0].parentName : 'الإدارة التعليمية')
      ),
      senderRoleLabel: String(data.senderRoleLabel || ''),
      messageType,
      text: String(data.text || ''),
      mediaUrl: data.mediaUrl || null,
      fileName: data.fileName || null,
      fileSize: data.fileSize || null,
      mimeType: data.mimeType || null,
      durationSeconds:
        data.durationSeconds !== null && data.durationSeconds !== undefined
          ? Math.round(Number(data.durationSeconds))
          : null,
      stickerKey: data.stickerKey || null,
      stickerCategory: data.stickerCategory || null,
      stickerLabel: data.stickerLabel || null,
      timestamp: nowTime,
      read: data.read ?? !['parent', 'student', 'female_student'].includes(sender),
      createdAt: new Date(),
    };

    const inserted = await db.insert(parentMessages).values(insertPayload).returning();
    const preview = buildMessagePreview(insertPayload);

    const isWarning = insertPayload.stickerCategory === 'warning';
    const nextWarningCount = Number(convRows[0].warningCount || 0) + (isWarning ? 1 : 0);
    const isIncomingForStaff = ['parent', 'student', 'female_student'].includes(sender);
    const nextUnreadCount = isIncomingForStaff
      ? Number(convRows[0].unreadCount || 0) + 1
      : Number(convRows[0].unreadCount || 0);

    await db
      .update(parentConversations)
      .set({
        lastMessage: preview,
        lastTimestamp: nowTime,
        unreadCount: nextUnreadCount,
        warningCount: nextWarningCount,
        status: isWarning ? 'needs_followup' : convRows[0].status,
        updatedAt: new Date(),
      })
      .where(eq(parentConversations.id, conversationId));

    const updatedConv = await getParentConversationById(conversationId);
    return {
      message: normalizeParentMessage(inserted[0]),
      conversation: updatedConv,
    };
  } catch (error: any) {
    console.error('Failed to create parent message:', error);
    throw new Error(`Failed to save message: ${error?.message || error}`);
  }
}

export async function updateParentMessage(msgId: string, data: any) {
  try {
    const existingRows = await db
      .select()
      .from(parentMessages)
      .where(eq(parentMessages.id, msgId))
      .limit(1);
    if (!existingRows[0]) {
      throw new Error('Message not found');
    }

    const payload: Record<string, any> = {};
    if (data.text !== undefined) payload.text = String(data.text);
    if (data.read !== undefined) payload.read = Boolean(data.read);
    if (data.stickerLabel !== undefined) payload.stickerLabel = data.stickerLabel;

    const updated = await db
      .update(parentMessages)
      .set(payload)
      .where(eq(parentMessages.id, msgId))
      .returning();

    const conversationId = existingRows[0].conversationId;
    const convMessages = await db
      .select()
      .from(parentMessages)
      .where(eq(parentMessages.conversationId, conversationId))
      .orderBy(asc(parentMessages.createdAt));

    const latest = convMessages[convMessages.length - 1];
    await db
      .update(parentConversations)
      .set({
        lastMessage: latest ? buildMessagePreview(latest) : '',
        lastTimestamp: latest ? latest.timestamp : '',
        updatedAt: new Date(),
      })
      .where(eq(parentConversations.id, conversationId));

    const conversation = await getParentConversationById(conversationId);
    return {
      message: normalizeParentMessage(updated[0]),
      conversation,
    };
  } catch (error: any) {
    console.error('Failed to update parent message:', error);
    throw new Error(`Failed to update message: ${error?.message || error}`);
  }
}

export async function deleteParentMessage(msgId: string) {
  try {
    const existingRows = await db
      .select()
      .from(parentMessages)
      .where(eq(parentMessages.id, msgId))
      .limit(1);
    if (!existingRows[0]) {
      return { success: true, id: msgId, conversation: null };
    }

    const conversationId = existingRows[0].conversationId;
    await db.delete(parentMessages).where(eq(parentMessages.id, msgId));

    const remaining = await db
      .select()
      .from(parentMessages)
      .where(eq(parentMessages.conversationId, conversationId))
      .orderBy(asc(parentMessages.createdAt));

    const latest = remaining[remaining.length - 1];
    const warningsCount = remaining.filter((m) => m.stickerCategory === 'warning').length;

    await db
      .update(parentConversations)
      .set({
        lastMessage: latest ? buildMessagePreview(latest) : '',
        lastTimestamp: latest ? latest.timestamp : '',
        warningCount: warningsCount,
        updatedAt: new Date(),
      })
      .where(eq(parentConversations.id, conversationId));

    const conversation = await getParentConversationById(conversationId);
    return { success: true, id: msgId, conversation };
  } catch (error: any) {
    console.error('Failed to delete parent message:', error);
    throw new Error(`Failed to delete message: ${error?.message || error}`);
  }
}

export async function markParentConversationRead(conversationId: string) {
  try {
    await db
      .update(parentMessages)
      .set({ read: true })
      .where(eq(parentMessages.conversationId, conversationId));
    await db
      .update(parentConversations)
      .set({ unreadCount: 0 })
      .where(eq(parentConversations.id, conversationId));
    return await getParentConversationById(conversationId);
  } catch (error: any) {
    console.error('Failed to mark conversation read:', error);
    throw new Error(`Failed to mark conversation read: ${error?.message || error}`);
  }
}

// ---------------- Timetable CRUD (تنظيم وجدولة الحصص والمقررات الدراسية) ----------------
const DAY_AR_MAP: Record<string, string> = {
  Saturday: 'السبت',
  Sunday: 'الأحد',
  Monday: 'الاثنين',
  Tuesday: 'الثلاثاء',
  Wednesday: 'الأربعاء',
  Thursday: 'الخميس',
  Friday: 'الجمعة',
};

export async function getAllTimetable(filters?: {
  search?: string;
  day?: string;
  type?: string;
  grade?: string;
  status?: string;
}) {
  try {
    const rows = await db.select().from(timetable).orderBy(asc(timetable.createdAt));
    if (!filters) return rows;
    const q = (filters.search || '').trim().toLowerCase();
    return rows.filter((row) => {
      if (filters.day && filters.day !== 'all' && row.day !== filters.day) return false;
      if (filters.type && filters.type !== 'all' && row.type !== filters.type) return false;
      if (filters.grade && filters.grade !== 'all' && row.grade !== filters.grade) return false;
      if (filters.status && filters.status !== 'all' && (row.status || 'scheduled') !== filters.status) return false;
      if (q) {
        const hay = [
          row.subject,
          row.courseTitle,
          row.teacherName,
          row.lessonTitle,
          row.grade,
          row.semester,
          row.roomOrLink,
          row.notes,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  } catch (error) {
    console.error('Failed to query timetable:', error);
    return [];
  }
}

export async function createTimetableSlot(data: any) {
  try {
    const day = String(data.day || 'Saturday').trim();
    const dayAr = String(data.dayAr || DAY_AR_MAP[day] || day).trim();
    const id = data.id && String(data.id).trim() ? String(data.id).trim() : `slot-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const payload = {
      id,
      day,
      dayAr,
      time: String(data.time || '').trim(),
      subject: String(data.subject || '').trim(),
      courseTitle: String(data.courseTitle || '').trim(),
      teacherId: String(data.teacherId || '').trim(),
      teacherName: String(data.teacherName || '').trim(),
      lessonId: String(data.lessonId || '').trim(),
      lessonTitle: String(data.lessonTitle || '').trim(),
      grade: String(data.grade || '').trim(),
      semester: String(data.semester || 'الفصل الدراسي الأول').trim(),
      type: data.type === 'offline' ? 'offline' : 'online',
      roomOrLink: String(data.roomOrLink || '').trim(),
      status: ['scheduled', 'live', 'completed', 'cancelled'].includes(data.status)
        ? String(data.status)
        : 'scheduled',
      capacity: Number.isFinite(Number(data.capacity)) && Number(data.capacity) > 0 ? Math.round(Number(data.capacity)) : 30,
      notes: String(data.notes || '').trim(),
      createdAt: new Date(),
    };
    const res = await db.insert(timetable).values(payload).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to create timetable slot:', error);
    throw new Error('Failed to create timetable slot in database', { cause: error });
  }
}

export async function updateTimetableSlot(id: string, data: any) {
  try {
    const payload: Record<string, any> = {};
    if (data.day !== undefined) {
      payload.day = String(data.day).trim();
      payload.dayAr = String(data.dayAr || DAY_AR_MAP[payload.day] || payload.day).trim();
    } else if (data.dayAr !== undefined) {
      payload.dayAr = String(data.dayAr).trim();
    }
    if (data.time !== undefined) payload.time = String(data.time).trim();
    if (data.subject !== undefined) payload.subject = String(data.subject).trim();
    if (data.courseTitle !== undefined) payload.courseTitle = String(data.courseTitle).trim();
    if (data.teacherId !== undefined) payload.teacherId = String(data.teacherId).trim();
    if (data.teacherName !== undefined) payload.teacherName = String(data.teacherName).trim();
    if (data.lessonId !== undefined) payload.lessonId = String(data.lessonId).trim();
    if (data.lessonTitle !== undefined) payload.lessonTitle = String(data.lessonTitle).trim();
    if (data.grade !== undefined) payload.grade = String(data.grade).trim();
    if (data.semester !== undefined) payload.semester = String(data.semester).trim();
    if (data.type !== undefined) payload.type = data.type === 'offline' ? 'offline' : 'online';
    if (data.roomOrLink !== undefined) payload.roomOrLink = String(data.roomOrLink).trim();
    if (data.status !== undefined && ['scheduled', 'live', 'completed', 'cancelled'].includes(data.status)) {
      payload.status = String(data.status);
    }
    if (data.capacity !== undefined && Number.isFinite(Number(data.capacity)) && Number(data.capacity) > 0) {
      payload.capacity = Math.round(Number(data.capacity));
    }
    if (data.notes !== undefined) payload.notes = String(data.notes).trim();

    const res = await db.update(timetable).set(payload).where(eq(timetable.id, id)).returning();
    return res[0] || null;
  } catch (error) {
    console.error('Failed to update timetable slot:', error);
    throw new Error('Failed to update timetable slot in database', { cause: error });
  }
}

export async function deleteTimetableSlot(id: string) {
  try {
    await db.delete(timetable).where(eq(timetable.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete timetable slot:', error);
    throw new Error('Failed to delete timetable slot from database', { cause: error });
  }
}

// ---------------- Invoices / Tuition CRUD (منظومة الدفع والرسوم) ----------------
export async function getAllInvoices() {
  try {
    return await db.select().from(invoices);
  } catch (error) {
    console.error('Failed to query invoices:', error);
    return [];
  }
}

export async function createInvoice(data: typeof invoices.$inferInsert) {
  try {
    const res = await db.insert(invoices).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to create invoice:', error);
    throw new Error('Failed to create invoice in database', { cause: error });
  }
}

export async function updateInvoice(id: string, data: Partial<typeof invoices.$inferInsert>) {
  try {
    const res = await db.update(invoices).set(data).where(eq(invoices.id, id)).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to update invoice:', error);
    throw new Error('Failed to update invoice in database', { cause: error });
  }
}

export async function deleteInvoice(id: string) {
  try {
    await db.delete(invoices).where(eq(invoices.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete invoice:', error);
    throw new Error('Failed to delete invoice from database', { cause: error });
  }
}

// ---------------- Notifications CRUD (الإشعارات الدورية) ----------------
export async function getAllNotifications(filters?: {
  search?: string;
  category?: string;
  target?: string;
  read?: string;
}) {
  try {
    const rows = await db.select().from(notifications);
    const ordered = [...rows].reverse();
    if (!filters) return ordered;
    const q = (filters.search || '').trim().toLowerCase();
    return ordered.filter((row) => {
      if (filters.category && filters.category !== 'all' && row.category !== filters.category) return false;
      if (filters.target && filters.target !== 'all' && row.target !== filters.target) return false;
      if (filters.read === 'read' && !row.read) return false;
      if (filters.read === 'unread' && row.read) return false;
      if (q) {
        const hay = [row.title, row.message, row.target, row.category, row.createdAt]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  } catch (error) {
    console.error('Failed to query notifications:', error);
    return [];
  }
}

export async function createNotification(data: any) {
  try {
    const id =
      data.id && String(data.id).trim()
        ? String(data.id).trim()
        : `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const nowLabel = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const payload = {
      id,
      title: String(data.title || '').trim(),
      message: String(data.message || '').trim(),
      target: String(data.target || 'all').trim(),
      category: String(data.category || 'general').trim(),
      relatedType: String(data.relatedType || 'general').trim(),
      relatedId: String(data.relatedId || '').trim(),
      createdAt: String(data.createdAt || nowLabel).trim(),
      read: Boolean(data.read ?? false),
    };
    const res = await db.insert(notifications).values(payload).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to create notification:', error);
    throw new Error('Failed to create notification in database', { cause: error });
  }
}

export async function updateNotification(id: string, data: any) {
  try {
    const payload: Record<string, any> = {};
    if (data.title !== undefined) payload.title = String(data.title).trim();
    if (data.message !== undefined) payload.message = String(data.message).trim();
    if (data.target !== undefined) payload.target = String(data.target).trim();
    if (data.category !== undefined) payload.category = String(data.category).trim();
    if (data.read !== undefined) payload.read = Boolean(data.read);
    const res = await db.update(notifications).set(payload).where(eq(notifications.id, id)).returning();
    return res[0] || null;
  } catch (error) {
    console.error('Failed to update notification:', error);
    throw new Error('Failed to update notification in database', { cause: error });
  }
}

export async function deleteNotification(id: string) {
  try {
    await db.delete(notifications).where(eq(notifications.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete notification:', error);
    throw new Error('Failed to delete notification from database', { cause: error });
  }
}

// ---------------- FAQs CRUD (مركز الاستفسارات - الأسئلة الشائعة) ----------------
export async function getAllFaqs(filters?: { search?: string; category?: string }) {
  try {
    const rows = await db.select().from(faqs).orderBy(desc(faqs.createdAt));
    if (!filters) return rows;
    const q = (filters.search || '').trim().toLowerCase();
    return rows.filter((row) => {
      if (filters.category && filters.category !== 'all' && row.category !== filters.category) return false;
      if (q) {
        const hay = [row.questionAr, row.questionEn, row.answerAr, row.answerEn, row.category]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  } catch (error) {
    console.error('Failed to query faqs:', error);
    return [];
  }
}

export async function createFaq(data: any) {
  try {
    const id =
      data.id && String(data.id).trim()
        ? String(data.id).trim()
        : `faq-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const questionAr = String(data.questionAr || data.questionEn || '').trim();
    const answerAr = String(data.answerAr || data.answerEn || '').trim();
    const payload = {
      id,
      questionAr,
      questionEn: String(data.questionEn || questionAr).trim(),
      answerAr,
      answerEn: String(data.answerEn || answerAr).trim(),
      category: String(data.category || 'general').trim(),
      createdAt: new Date(),
    };
    const res = await db.insert(faqs).values(payload).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to create faq:', error);
    throw new Error('Failed to create faq in database', { cause: error });
  }
}

export async function updateFaq(id: string, data: any) {
  try {
    const payload: Record<string, any> = {};
    if (data.questionAr !== undefined) payload.questionAr = String(data.questionAr).trim();
    if (data.questionEn !== undefined) payload.questionEn = String(data.questionEn).trim();
    if (data.answerAr !== undefined) payload.answerAr = String(data.answerAr).trim();
    if (data.answerEn !== undefined) payload.answerEn = String(data.answerEn).trim();
    if (data.category !== undefined) payload.category = String(data.category).trim();
    const res = await db.update(faqs).set(payload).where(eq(faqs.id, id)).returning();
    return res[0] || null;
  } catch (error) {
    console.error('Failed to update faq:', error);
    throw new Error('Failed to update faq in database', { cause: error });
  }
}

export async function deleteFaq(id: string) {
  try {
    await db.delete(faqs).where(eq(faqs.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete faq:', error);
    throw new Error('Failed to delete faq from database', { cause: error });
  }
}

// ---------------- Inquiries CRUD (الاستفسارات المباشرة والردود) ----------------
export async function getAllInquiries(filters?: {
  search?: string;
  status?: string;
  category?: string;
  priority?: string;
}) {
  try {
    const rows = await db.select().from(inquiries).orderBy(desc(inquiries.updatedAt));
    if (!filters) return rows;
    const q = (filters.search || '').trim().toLowerCase();
    return rows.filter((row) => {
      if (filters.status && filters.status !== 'all' && row.status !== filters.status) return false;
      if (filters.category && filters.category !== 'all' && row.category !== filters.category) return false;
      if (filters.priority && filters.priority !== 'all' && row.priority !== filters.priority) return false;
      if (q) {
        const hay = [
          row.senderName,
          row.senderContact,
          row.subject,
          row.message,
          row.replyText,
          row.repliedBy,
          row.category,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  } catch (error) {
    console.error('Failed to query inquiries:', error);
    return [];
  }
}

export async function createInquiry(data: any) {
  try {
    const id =
      data.id && String(data.id).trim()
        ? String(data.id).trim()
        : `inq-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const nowLabel = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const replyText = String(data.replyText || '').trim();
    const status = ['pending', 'answered', 'closed'].includes(data.status)
      ? String(data.status)
      : replyText
      ? 'answered'
      : 'pending';
    const payload = {
      id,
      senderName: String(data.senderName || 'مستخدم المنصة').trim(),
      senderRole: ['student', 'parent', 'teacher', 'visitor'].includes(data.senderRole)
        ? String(data.senderRole)
        : 'student',
      senderContact: String(data.senderContact || '').trim(),
      subject: String(data.subject || '').trim(),
      message: String(data.message || '').trim(),
      category: ['academic', 'financial', 'technical', 'general', 'suggestion', 'complaint'].includes(data.category)
        ? String(data.category)
        : 'general',
      priority: ['low', 'normal', 'high', 'urgent'].includes(data.priority)
        ? String(data.priority)
        : 'normal',
      status,
      replyText,
      repliedBy: String(data.repliedBy || '').trim(),
      repliedAt: replyText ? String(data.repliedAt || nowLabel).trim() : '',
      createdAt: String(data.createdAt || nowLabel).trim(),
      updatedAt: new Date(),
    };
    const res = await db.insert(inquiries).values(payload).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to create inquiry:', error);
    throw new Error('Failed to create inquiry in database', { cause: error });
  }
}

export async function updateInquiry(id: string, data: any) {
  try {
    const payload: Record<string, any> = { updatedAt: new Date() };
    if (data.senderName !== undefined) payload.senderName = String(data.senderName).trim();
    if (data.senderRole !== undefined && ['student', 'parent', 'teacher', 'visitor'].includes(data.senderRole)) {
      payload.senderRole = String(data.senderRole);
    }
    if (data.senderContact !== undefined) payload.senderContact = String(data.senderContact).trim();
    if (data.subject !== undefined) payload.subject = String(data.subject).trim();
    if (data.message !== undefined) payload.message = String(data.message).trim();
    if (data.category !== undefined && ['academic', 'financial', 'technical', 'general', 'suggestion', 'complaint'].includes(data.category)) {
      payload.category = String(data.category);
    }
    if (data.priority !== undefined && ['low', 'normal', 'high', 'urgent'].includes(data.priority)) {
      payload.priority = String(data.priority);
    }
    if (data.status !== undefined && ['pending', 'answered', 'closed'].includes(data.status)) {
      payload.status = String(data.status);
    }
    if (data.replyText !== undefined) {
      const cleanedReply = String(data.replyText).trim();
      payload.replyText = cleanedReply;
      if (cleanedReply) {
        payload.repliedAt =
          String(data.repliedAt || '').trim() ||
          new Date().toLocaleString('ar-EG', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          });
        if (!data.status) payload.status = 'answered';
      }
    }
    if (data.repliedBy !== undefined) payload.repliedBy = String(data.repliedBy).trim();

    const res = await db.update(inquiries).set(payload).where(eq(inquiries.id, id)).returning();
    return res[0] || null;
  } catch (error) {
    console.error('Failed to update inquiry:', error);
    throw new Error('Failed to update inquiry in database', { cause: error });
  }
}

export async function deleteInquiry(id: string) {
  try {
    await db.delete(inquiries).where(eq(inquiries.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete inquiry:', error);
    throw new Error('Failed to delete inquiry from database', { cause: error });
  }
}

// ---------------- School Customization Settings (تخصيص هوية المدرسة والسلايدر) ----------------
export async function getSchoolSettings() {
  try {
    const [res, rawSlider] = await Promise.all([
      db.select().from(schoolSettings).where(eq(schoolSettings.id, 'main_school')),
      getSystemSetting('hero_slider_config_v1'),
    ]);
    let parsedSlider: any = undefined;
    if (rawSlider) {
      try {
        parsedSlider = JSON.parse(rawSlider);
      } catch {
        parsedSlider = undefined;
      }
    }
    const row = res[0] || {
      id: 'main_school',
      schoolName: 'منصة الشريف',
      schoolNameEn: 'Al-Sharif Edu Platform',
      tagline:
        'منصة رائدة تدمج التعليم الإلكتروني التفاعلي ومراكز التدريب الحضورية بأعلى معايير الجودة',
      primaryColor: '#0f5132',
      logoUrl: '/assets/images/certificate_crest_gold_1794403367581.jpg',
      academicYear: '2026 - 2027',
      enableInstantNotifications: true,
      enableRealtimeSync: true,
    };
    if (
      row &&
      (row.schoolName === 'تعلّمنوفا' ||
        row.schoolName === 'تعلمنوفا' ||
        row.schoolName === 'أكاديمية نوابغ التعليمية')
    ) {
      row.schoolName = 'منصة الشريف';
      if (
        !row.schoolNameEn ||
        row.schoolNameEn.includes('LearnNova') ||
        row.schoolNameEn.includes('Nawabegh')
      ) {
        row.schoolNameEn = 'Al-Sharif Edu Platform';
      }
    }
    return {
      ...row,
      ...(parsedSlider ? { heroSlider: parsedSlider } : {}),
    };
  } catch (error) {
    console.error('Failed to query school settings:', error);
    return null;
  }
}

export async function updateSchoolSettings(
  data: Partial<typeof schoolSettings.$inferInsert> & { heroSlider?: any }
) {
  try {
    const { heroSlider, ...dbColumns } = data as any;
    if (heroSlider && typeof heroSlider === 'object') {
      await setSystemSetting('hero_slider_config_v1', JSON.stringify(heroSlider));
    }

    const res = await db
      .insert(schoolSettings)
      .values({
        id: 'main_school',
        schoolName: dbColumns.schoolName || 'منصة الشريف',
        schoolNameEn: dbColumns.schoolNameEn || 'Al-Sharif Edu Platform',
        tagline: dbColumns.tagline,
        primaryColor: dbColumns.primaryColor || '#0f5132',
        logoUrl: dbColumns.logoUrl,
        academicYear: dbColumns.academicYear || '2026 - 2027',
        enableInstantNotifications: dbColumns.enableInstantNotifications ?? true,
        enableRealtimeSync: dbColumns.enableRealtimeSync ?? true,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: schoolSettings.id,
        set: {
          ...(dbColumns.schoolName !== undefined ? { schoolName: dbColumns.schoolName } : {}),
          ...(dbColumns.schoolNameEn !== undefined ? { schoolNameEn: dbColumns.schoolNameEn } : {}),
          ...(dbColumns.tagline !== undefined ? { tagline: dbColumns.tagline } : {}),
          ...(dbColumns.primaryColor !== undefined ? { primaryColor: dbColumns.primaryColor } : {}),
          ...(dbColumns.logoUrl !== undefined ? { logoUrl: dbColumns.logoUrl } : {}),
          ...(dbColumns.academicYear !== undefined ? { academicYear: dbColumns.academicYear } : {}),
          ...(dbColumns.enableInstantNotifications !== undefined
            ? { enableInstantNotifications: dbColumns.enableInstantNotifications }
            : {}),
          ...(dbColumns.enableRealtimeSync !== undefined
            ? { enableRealtimeSync: dbColumns.enableRealtimeSync }
            : {}),
          updatedAt: new Date(),
        },
      })
      .returning();

    const rawSlider = await getSystemSetting('hero_slider_config_v1');
    let savedSlider: any = heroSlider;
    if (!savedSlider && rawSlider) {
      try {
        savedSlider = JSON.parse(rawSlider);
      } catch {
        savedSlider = undefined;
      }
    }

    return {
      ...res[0],
      ...(savedSlider ? { heroSlider: savedSlider } : {}),
    };
  } catch (error) {
    console.error('Failed to update school settings:', error);
    throw new Error('Failed to update school settings in database', { cause: error });
  }
}

// ---------------- Users / Members CRUD & Registration ----------------
export const ALLOWED_ACCOUNT_ROLES = [
  'admin',
  'secretary',
  'supervisor',
  'teacher',
  'student',
  'female_student',
  'parent',
] as const;

export function getRoleDefaults(role: string): { roleTitle: string; permissions: string[] } {
  switch (role) {
    case 'admin':
      return {
        roleTitle: 'مدير عام',
        permissions: [
          'manage_students',
          'manage_teachers',
          'manage_lessons',
          'manage_quizzes',
          'manage_certificates',
          'manage_finances',
          'manage_whiteboard',
          'manage_triage',
          'manage_timetable',
          'manage_faqs',
          'manage_members',
          'manage_backups',
          'manage_settings',
        ],
      };
    case 'secretary':
      return {
        roleTitle: 'سكرتارية',
        permissions: [
          'manage_students',
          'manage_certificates',
          'manage_finances',
          'manage_timetable',
          'manage_faqs',
        ],
      };
    case 'supervisor':
      return {
        roleTitle: 'مشرف أكاديمي',
        permissions: [
          'manage_students',
          'manage_teachers',
          'manage_lessons',
          'manage_quizzes',
          'manage_certificates',
          'manage_whiteboard',
          'manage_triage',
          'manage_timetable',
          'manage_faqs',
        ],
      };
    case 'teacher':
      return {
        roleTitle: 'معلم',
        permissions: ['manage_lessons', 'manage_quizzes', 'manage_whiteboard'],
      };
    case 'student':
      return {
        roleTitle: 'طالب',
        permissions: [],
      };
    case 'female_student':
      return {
        roleTitle: 'طالبة',
        permissions: [],
      };
    case 'parent':
      return {
        roleTitle: 'ولي أمر',
        permissions: [],
      };
    default:
      return {
        roleTitle: 'عضو',
        permissions: [],
      };
  }
}

export async function getAllUsers() {
  try {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  } catch (error) {
    console.error('Failed to query users:', error);
    throw new Error('Failed to query users from database', { cause: error });
  }
}

export async function createUser(data: typeof users.$inferInsert) {
  try {
    const cleanUsername = data.username ? data.username.trim() : '';
    const cleanEmail = (data.email || '').trim().toLowerCase();

    if (!cleanEmail) {
      const err: any = new Error('يرجى إدخال البريد الإلكتروني');
      err.statusCode = 400;
      throw err;
    }

    if (cleanUsername) {
      const existingByUsername = await db
        .select()
        .from(users)
        .where(ilike(users.username, cleanUsername))
        .limit(1);
      if (existingByUsername.length > 0) {
        const err: any = new Error('اسم المستخدم مسجل مسبقاً، يرجى اختيار اسم مستخدم آخر');
        err.statusCode = 409;
        throw err;
      }
    }

    const existingByEmail = await db
      .select()
      .from(users)
      .where(ilike(users.email, cleanEmail))
      .limit(1);
    if (existingByEmail.length > 0) {
      const err: any = new Error('البريد الإلكتروني مسجل مسبقاً في قاعدة البيانات');
      err.statusCode = 409;
      throw err;
    }

    const roleDefaults = getRoleDefaults(data.role || 'student');
    const payload = {
      ...data,
      uid: data.uid || `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      username: cleanUsername || cleanEmail.split('@')[0],
      email: cleanEmail,
      roleTitle: data.roleTitle || roleDefaults.roleTitle,
      permissions:
        data.permissions !== undefined
          ? data.permissions
          : JSON.stringify(roleDefaults.permissions),
    };
    const res = await db.insert(users).values(payload).returning();
    return res[0];
  } catch (error: any) {
    console.error('Failed to create user:', error);
    if (error?.statusCode) throw error;
    throw new Error(`Failed to create user: ${error?.message || error}`);
  }
}

export async function registerUser(input: {
  displayName?: string;
  username?: string;
  email?: string;
  password?: string;
  phone?: string;
  role?: string;
  roleTitle?: string;
  securityQuestion?: string;
  securityAnswer?: string;
}) {
  const displayName = (input.displayName || '').trim();
  const username = (input.username || '').trim();
  const email = (input.email || '').trim().toLowerCase();
  const password = (input.password || '').trim();
  const phone = (input.phone || '').trim();
  const role = (input.role || 'student').trim();
  const securityQuestion =
    (input.securityQuestion || '').trim() || 'ما هو اسم مدرستك الابتدائية الأولى؟';
  const securityAnswer = (input.securityAnswer || '').trim() || 'نوابغ';

  if (!displayName) {
    return { success: false, statusCode: 400, error: 'يرجى إدخال الاسم الكامل' };
  }
  if (!username || username.length < 3) {
    return {
      success: false,
      statusCode: 400,
      error: 'يرجى إدخال اسم مستخدم (Username) لا يقل عن 3 أحرف',
    };
  }
  if (/\s/.test(username)) {
    return {
      success: false,
      statusCode: 400,
      error: 'اسم المستخدم يجب أن لا يحتوي على مسافات (استخدم حروفاً أو أرقاماً أو - _)',
    };
  }
  if (!email || !email.includes('@')) {
    return { success: false, statusCode: 400, error: 'يرجى إدخال بريد إلكتروني صحيح' };
  }
  if (!password || password.length < 4) {
    return {
      success: false,
      statusCode: 400,
      error: 'يجب أن تتكون كلمة المرور من 4 خانات على الأقل',
    };
  }
  if (!(ALLOWED_ACCOUNT_ROLES as readonly string[]).includes(role)) {
    return {
      success: false,
      statusCode: 400,
      error: 'الصلاحية (الدور) المختارة غير صالحة',
    };
  }

  // Enforce uniqueness of username & email
  const dupUsername = await db
    .select()
    .from(users)
    .where(ilike(users.username, username))
    .limit(1);
  if (dupUsername.length > 0) {
    return {
      success: false,
      statusCode: 409,
      error: 'اسم المستخدم هذا محجوز بالفعل، يرجى اختيار اسم مستخدم آخر',
    };
  }

  const dupEmail = await db
    .select()
    .from(users)
    .where(ilike(users.email, email))
    .limit(1);
  if (dupEmail.length > 0) {
    return {
      success: false,
      statusCode: 409,
      error: 'هذا البريد الإلكتروني مسجل مسبقاً في المنظومة',
    };
  }

  const roleDefaults = getRoleDefaults(role);
  const uid = `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

  const [created] = await db
    .insert(users)
    .values({
      uid,
      displayName,
      displayNameEn: displayName,
      username,
      email,
      password,
      phone: phone || null,
      role,
      roleTitle: (input.roleTitle || '').trim() || roleDefaults.roleTitle,
      permissions: JSON.stringify(roleDefaults.permissions),
      securityQuestion,
      securityAnswer,
      // CRITICAL: All self-registered accounts remain locked until Admin activates them
      isActive: false,
      notes: 'تم التسجيل عبر بوابة إنشاء الحسابات — بانتظار موافقة وتفعيل المدير العام',
    })
    .returning();

  // Log registration request in system audit logs
  try {
    await createAuditLog({
      action: 'register_pending',
      actionAr: 'طلب تسجيل حساب جديد (بانتظار التفعيل)',
      entityType: 'member',
      entityName: `${displayName} (@${username})`,
      performedBy: displayName,
      details: `سجّل حساباً جديداً بصلاحية (${roleDefaults.roleTitle}) — الحالة: قيد المراجعة وبانتظار تفعيل الأدمن`,
      severity: 'warning',
    });
  } catch (logErr) {
    console.warn('Audit log write skipped during registration:', logErr);
  }

  const { password: _hiddenPw, securityAnswer: _hiddenAns, ...safeUser } = created;
  return {
    success: true,
    pendingApproval: true,
    user: safeUser,
    message:
      'تم تسجيل حسابك بنجاح في قاعدة البيانات! لا يمكنك الدخول للنظام حالياً إلا بعد مراجعة وتفعيل الحساب من قِبل المدير العام (الأدمن).',
  };
}

export async function updateUser(id: number, data: Partial<typeof users.$inferInsert>) {
  try {
    const existingRows = await db.select().from(users).where(eq(users.id, id)).limit(1);
    const existing = existingRows[0];
    if (!existing) return null;

    if (data.username !== undefined && data.username !== null) {
      const cleanUsername = data.username.trim();
      if (cleanUsername) {
        const dup = await db
          .select()
          .from(users)
          .where(ilike(users.username, cleanUsername))
          .limit(1);
        if (dup.length > 0 && dup[0].id !== id) {
          const err: any = new Error('اسم المستخدم مستخدم من قِبل حساب آخر');
          err.statusCode = 409;
          throw err;
        }
      }
    }

    if (data.email !== undefined && data.email !== null) {
      const cleanEmail = data.email.trim().toLowerCase();
      if (cleanEmail) {
        const dup = await db
          .select()
          .from(users)
          .where(ilike(users.email, cleanEmail))
          .limit(1);
        if (dup.length > 0 && dup[0].id !== id) {
          const err: any = new Error('البريد الإلكتروني مستخدم من قِبل حساب آخر');
          err.statusCode = 409;
          throw err;
        }
      }
    }

    const res = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    const updated = res[0];

    if (
      updated &&
      data.isActive !== undefined &&
      Boolean(existing.isActive) !== Boolean(updated.isActive)
    ) {
      try {
        await createAuditLog({
          action: updated.isActive ? 'account_activated' : 'account_deactivated',
          actionAr: updated.isActive ? 'تفعيل حساب مستخدم' : 'تعطيل حساب مستخدم',
          entityType: 'member',
          entityName: `${updated.displayName} (@${updated.username || updated.email})`,
          performedBy: 'المدير العام (الأدمن)',
          details: updated.isActive
            ? `تم تفعيل الحساب والسماح بتسجيل الدخول بصلاحية (${updated.roleTitle || updated.role})`
            : `تم إيقاف/تعطيل الحساب ومنع تسجيل الدخول مؤقتاً`,
          severity: updated.isActive ? 'info' : 'warning',
        });
      } catch (logErr) {
        console.warn('Audit log skipped on status change:', logErr);
      }
    }

    return updated;
  } catch (error: any) {
    console.error('Failed to update user:', error);
    if (error?.statusCode) throw error;
    throw new Error('Failed to update user in database', { cause: error });
  }
}

export async function deleteUser(id: number) {
  try {
    await db.delete(users).where(eq(users.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete user:', error);
    throw new Error('Failed to delete user from database', { cause: error });
  }
}

// ---------------- User Authentication & Password Recovery ----------------
export async function findUserByLogin(loginIdentifier: string) {
  try {
    const clean = loginIdentifier.trim();
    if (!clean) return null;

    const res = await db
      .select()
      .from(users)
      .where(
        or(
          ilike(users.email, clean),
          ilike(users.username, clean),
          eq(users.uid, clean)
        )
      )
      .limit(1);

    return res[0] || null;
  } catch (error) {
    console.error('Failed to find user by login:', error);
    return null;
  }
}

export async function verifyUserCredentials(loginIdentifier: string, passwordAttempt: string) {
  try {
    const cleanId = (loginIdentifier || '').trim();
    const cleanPw = (passwordAttempt || '').trim();

    if (!cleanId || !cleanPw) {
      return {
        success: false,
        statusCode: 400,
        error: 'يرجى إدخال اسم المستخدم وكلمة المرور',
      };
    }

    const user = await findUserByLogin(cleanId);
    if (!user) {
      return {
        success: false,
        statusCode: 401,
        error: 'اسم المستخدم أو البريد الإلكتروني غير مسجل بالمنظومة',
      };
    }

    const storedPassword = user.password || '';
    if (!storedPassword || storedPassword !== cleanPw) {
      return {
        success: false,
        statusCode: 401,
        error: 'كلمة المرور غير صحيحة، يرجى المحاولة مرة أخرى أو استعادة الحساب عبر السؤال السري',
      };
    }

    if (!user.isActive) {
      return {
        success: false,
        pendingApproval: true,
        statusCode: 403,
        error:
          'حسابك غير مفعل حالياً — لا يمكنك الدخول إلا بعد موافقة وتفعيل الحساب من قِبل المدير العام (الأدمن).',
      };
    }

    return { success: true, user };
  } catch (error: any) {
    console.error('Credentials verification error:', error);
    return {
      success: false,
      statusCode: 500,
      error: error.message || 'حدث خطأ أثناء التحقق من بيانات الدخول',
    };
  }
}

export async function getUserSecurityQuestion(loginIdentifier: string) {
  try {
    const cleanId = (loginIdentifier || '').trim();
    if (!cleanId) {
      return { found: false, error: 'يرجى كتابة اسم المستخدم أو البريد الإلكتروني' };
    }

    const user = await findUserByLogin(cleanId);
    if (!user) {
      return { found: false, error: 'لم يتم العثور على أي حساب مسجل بهذا الاسم أو البريد' };
    }

    const question = user.securityQuestion || 'ما هو اسم مدرستك الابتدائية؟';
    return {
      found: true,
      username: user.username || user.email,
      displayName: user.displayName,
      securityQuestion: question,
    };
  } catch (error: any) {
    console.error('Get security question error:', error);
    return { found: false, error: error.message || 'تعذر جلب السؤال السري' };
  }
}

export async function verifySecurityAnswerAndReset(
  loginIdentifier: string,
  answerAttempt: string,
  newPassword?: string
) {
  try {
    const cleanId = (loginIdentifier || '').trim();
    const cleanAnswer = (answerAttempt || '').trim().toLowerCase();

    if (!cleanId || !cleanAnswer) {
      return { success: false, error: 'يرجى إدخال اسم المستخدم والإجابة على السؤال السري' };
    }

    const user = await findUserByLogin(cleanId);
    if (!user) {
      return { success: false, error: 'لم يتم العثور على الحساب المطلوب' };
    }

    const storedAnswer = (user.securityAnswer || 'نوابغ').trim().toLowerCase();
    if (storedAnswer !== cleanAnswer) {
      return {
        success: false,
        error: 'الإجابة على السؤال السري غير صحيحة، يرجى التأكد من الإجابة',
      };
    }

    if (newPassword && newPassword.trim()) {
      await db
        .update(users)
        .set({ password: newPassword.trim(), updatedAt: new Date() })
        .where(eq(users.id, user.id));
    }

    if (!user.isActive) {
      return {
        success: true,
        pendingApproval: true,
        message:
          'تم تحديث كلمة المرور بنجاح، ولكن الحساب ما زال بانتظار التفعيل من قِبل المدير العام (الأدمن) قبل الدخول.',
        user: null,
      };
    }

    return {
      success: true,
      pendingApproval: false,
      message: 'تم التحقق من هويتك بنجاح وتحديث كلمة المرور',
      user: {
        ...user,
        password: newPassword ? newPassword.trim() : user.password,
      },
    };
  } catch (error: any) {
    console.error('Security answer verification error:', error);
    return { success: false, error: error.message || 'فشلت عملية التحقق' };
  }
}

// ---------------- System Audit Logs CRUD ----------------
export async function purgeSuperAdminViolationsAndWarnings() {
  try {
    // 1. Reset any screen_violation counters for Mo-NewFolder / Super Admin
    const adminKeys = [
      'screen_violation_mo-newfolder',
      'screen_violation_usr-super-admin',
      'screen_violation_mo-newfolder@nawabegh.edu',
      'screen_violation_admin',
    ];
    for (const k of adminKeys) {
      await setSystemSetting(k, '0');
    }

    // 2. Delete any audit log entry that warns or penalizes Mo-NewFolder / الأدمن العام / المدير العام
    const allLogs = await db.select().from(auditLogs);
    for (const row of allLogs) {
      const combinedText = `${row.entityName || ''} ${row.performedBy || ''} ${row.details || ''} ${row.actionAr || ''}`.toLowerCase();
      const isSuperAdminTarget =
        combinedText.includes('mo-newfolder') ||
        combinedText.includes('الأدمن العام') ||
        combinedText.includes('المدير العام') ||
        combinedText.includes('usr-super-admin');
      const isPenaltyLog =
        row.action === 'account_delete_piracy' ||
        row.action === 'screen_record_warning' ||
        combinedText.includes('ممنوع السرقه') ||
        combinedText.includes('تصوير الشاشة') ||
        combinedText.includes('حذف حساب نهائياً لتكرار تصوير');

      if (isSuperAdminTarget && isPenaltyLog) {
        await db.delete(auditLogs).where(eq(auditLogs.id, row.id));
      }
    }
  } catch (error) {
    console.warn('Failed to purge super admin violations:', error);
  }
}

export async function getAllAuditLogs(limitCount = 100) {
  try {
    await purgeSuperAdminViolationsAndWarnings();
    return await db.select().from(auditLogs).orderBy(desc(auditLogs.id)).limit(limitCount);
  } catch (error) {
    console.error('Failed to query audit logs:', error);
    return [];
  }
}

export async function createAuditLog(data: Partial<typeof auditLogs.$inferInsert>) {
  try {
    const id = data.id && String(data.id).trim() ? String(data.id).trim() : `log-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
    const nowLabel = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const payload = {
      id,
      action: String(data.action || 'system').trim(),
      actionAr: String(data.actionAr || 'تحديث بالنظام').trim(),
      entityType: String(data.entityType || 'system').trim(),
      entityName: String(data.entityName || '').trim(),
      performedBy: String(data.performedBy || 'النظام').trim(),
      timestamp: String(data.timestamp || nowLabel).trim(),
      details: String(data.details || '').trim(),
      severity: ['info', 'warning', 'critical'].includes(String(data.severity))
        ? String(data.severity)
        : 'info',
    };
    const res = await db.insert(auditLogs).values(payload).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to create audit log:', error);
    throw new Error('Failed to create audit log in database', { cause: error });
  }
}

export async function deleteAuditLog(id: string) {
  try {
    await db.delete(auditLogs).where(eq(auditLogs.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete audit log:', error);
    throw new Error('Failed to delete audit log from database', { cause: error });
  }
}

export async function clearAllAuditLogs() {
  try {
    await db.delete(auditLogs);
    return { success: true };
  } catch (error) {
    console.error('Failed to clear audit logs:', error);
    throw new Error('Failed to clear audit logs from database', { cause: error });
  }
}

// ---------------- Backups & Export Service ----------------
export async function getAllBackups() {
  try {
    return await db.select().from(backups).orderBy(desc(backups.createdAt));
  } catch (error) {
    console.error('Failed to query backups:', error);
    return [];
  }
}

export async function recordBackup(data: typeof backups.$inferInsert) {
  try {
    const res = await db.insert(backups).values(data).returning();
    return res[0];
  } catch (error) {
    console.error('Failed to record backup:', error);
    return null;
  }
}

// Generate Complete SQL Dump (.sql) with dialect support (PostgreSQL or MySQL-compatible export)
export async function generateSqlDump(dialect: 'postgresql' | 'mysql' = 'postgresql'): Promise<string> {
  const isMysql = dialect === 'mysql';
  const timestamp = new Date().toISOString();
  let dump = `-- ========================================================\n`;
  dump += `-- NAWABEGH EDU PLATFORM - DATABASE SQL BACKUP DUMP\n`;
  dump += `-- Generated on: ${timestamp}\n`;
  dump += `-- Target Dialect: ${isMysql ? 'MySQL 8.0 / MariaDB Compatible' : 'PostgreSQL / Cloud SQL Standard'}\n`;
  dump += `-- ========================================================\n\n`;
  dump += isMysql ? `SET FOREIGN_KEY_CHECKS=0;\nSTART TRANSACTION;\n\n` : `BEGIN;\n\n`;

  const escapeSqlValue = (val: any): string => {
    if (val === null || val === undefined) return 'NULL';
    if (typeof val === 'number') return String(val);
    if (typeof val === 'boolean') return isMysql ? (val ? '1' : '0') : val ? 'TRUE' : 'FALSE';
    if (val instanceof Date) {
      return isMysql
        ? `'${val.toISOString().slice(0, 19).replace('T', ' ')}'`
        : `'${val.toISOString()}'`;
    }
    const str = isMysql
      ? String(val).replace(/\\/g, '\\\\').replace(/'/g, "\\'")
      : String(val).replace(/'/g, "''");
    return `'${str}'`;
  };

  const insertPrefix = isMysql ? 'INSERT IGNORE INTO' : 'INSERT INTO';
  const conflictEnd = (col: string) => (isMysql ? ';' : ` ON CONFLICT (${col}) DO NOTHING;`);

  // 1. Users
  const userRows = await db.select().from(users);
  dump += `-- Table: users (${userRows.length} records)\n`;
  for (const row of userRows) {
    dump += `${insertPrefix} users (uid, email, display_name, display_name_en, role, role_title, phone, permissions, is_active, notes) VALUES (${escapeSqlValue(row.uid)}, ${escapeSqlValue(row.email)}, ${escapeSqlValue(row.displayName)}, ${escapeSqlValue(row.displayNameEn)}, ${escapeSqlValue(row.role)}, ${escapeSqlValue(row.roleTitle)}, ${escapeSqlValue(row.phone)}, ${escapeSqlValue(row.permissions)}, ${escapeSqlValue(row.isActive)}, ${escapeSqlValue(row.notes)})${conflictEnd('uid')}\n`;
  }
  dump += `\n`;

  // 2. Students
  const studentRows = await db.select().from(students);
  dump += `-- Table: students (${studentRows.length} records)\n`;
  for (const row of studentRows) {
    dump += `${insertPrefix} students (id, code, name, name_en, grade, type, parent_name, parent_phone, parent_email, overall_score, attendance_rate, status, notes, registered_date, city) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.code)}, ${escapeSqlValue(row.name)}, ${escapeSqlValue(row.nameEn)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.type)}, ${escapeSqlValue(row.parentName)}, ${escapeSqlValue(row.parentPhone)}, ${escapeSqlValue(row.parentEmail)}, ${escapeSqlValue(row.overallScore)}, ${escapeSqlValue(row.attendanceRate)}, ${escapeSqlValue(row.status)}, ${escapeSqlValue(row.notes)}, ${escapeSqlValue(row.registeredDate)}, ${escapeSqlValue(row.city)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 3. Teachers
  const teacherRows = await db.select().from(teachers);
  dump += `-- Table: teachers (${teacherRows.length} records)\n`;
  for (const row of teacherRows) {
    dump += `${insertPrefix} teachers (id, name, name_en, specialty, specialty_en, email, phone, avatar, grades, rating, total_students, active_lessons_count, bio, joined_date) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.name)}, ${escapeSqlValue(row.nameEn)}, ${escapeSqlValue(row.specialty)}, ${escapeSqlValue(row.specialtyEn)}, ${escapeSqlValue(row.email)}, ${escapeSqlValue(row.phone)}, ${escapeSqlValue(row.avatar)}, ${escapeSqlValue(row.grades)}, ${escapeSqlValue(row.rating)}, ${escapeSqlValue(row.totalStudents)}, ${escapeSqlValue(row.activeLessonsCount)}, ${escapeSqlValue(row.bio)}, ${escapeSqlValue(row.joinedDate)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 4. Lessons
  const lessonRows = await db.select().from(lessons);
  dump += `-- Table: lessons (${lessonRows.length} records)\n`;
  for (const row of lessonRows) {
    dump += `${insertPrefix} lessons (id, title, title_en, subject, grade, teacher_id, teacher_name, format, duration_or_pages, video_url, document_url, description, views_count, likes_count, is_published, unit, content_html, infographic_data) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.title)}, ${escapeSqlValue(row.titleEn)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.teacherId)}, ${escapeSqlValue(row.teacherName)}, ${escapeSqlValue(row.format)}, ${escapeSqlValue(row.durationOrPages)}, ${escapeSqlValue(row.videoUrl)}, ${escapeSqlValue(row.documentUrl)}, ${escapeSqlValue(row.description)}, ${escapeSqlValue(row.viewsCount)}, ${escapeSqlValue(row.likesCount)}, ${escapeSqlValue(row.isPublished)}, ${escapeSqlValue(row.unit)}, ${escapeSqlValue(row.contentHtml)}, ${escapeSqlValue(row.infographicData)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 5. Quizzes
  const quizRows = await db.select().from(quizzes);
  dump += `-- Table: quizzes (${quizRows.length} records)\n`;
  for (const row of quizRows) {
    dump += `${insertPrefix} quizzes (id, title, subject, grade, type, duration_minutes, total_marks, questions, due_date, completed_students_count, average_score) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.title)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.type)}, ${escapeSqlValue(row.durationMinutes)}, ${escapeSqlValue(row.totalMarks)}, ${escapeSqlValue(row.questions)}, ${escapeSqlValue(row.dueDate)}, ${escapeSqlValue(row.completedStudentsCount)}, ${escapeSqlValue(row.averageScore)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 5b. Quiz Attempts (Recorded Student Exam Scores)
  const attemptRows = await db.select().from(quizAttempts);
  dump += `-- Table: quiz_attempts (${attemptRows.length} records)\n`;
  for (const row of attemptRows) {
    dump += `${insertPrefix} quiz_attempts (id, quiz_id, quiz_title, quiz_type, subject, grade, student_id, student_name, student_code, earned_marks, total_marks, percentage, correct_count, total_questions, taken_date) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.quizId)}, ${escapeSqlValue(row.quizTitle)}, ${escapeSqlValue(row.quizType)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.studentId)}, ${escapeSqlValue(row.studentName)}, ${escapeSqlValue(row.studentCode)}, ${escapeSqlValue(row.earnedMarks)}, ${escapeSqlValue(row.totalMarks)}, ${escapeSqlValue(row.percentage)}, ${escapeSqlValue(row.correctCount)}, ${escapeSqlValue(row.totalQuestions)}, ${escapeSqlValue(row.takenDate)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 6. Certificates
  const certRows = await db.select().from(certificates);
  dump += `-- Table: certificates (${certRows.length} records)\n`;
  for (const row of certRows) {
    dump += `${insertPrefix} certificates (id, student_id, student_name, student_grade, type, subject_or_track, score, issue_date, academic_year, principal_name, notes, serial_number, exam_period, weekly_average, monthly_average, exams_count, breakdown_json, is_auto_generated) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.studentId)}, ${escapeSqlValue(row.studentName)}, ${escapeSqlValue(row.studentGrade)}, ${escapeSqlValue(row.type)}, ${escapeSqlValue(row.subjectOrTrack)}, ${escapeSqlValue(row.score)}, ${escapeSqlValue(row.issueDate)}, ${escapeSqlValue(row.academicYear)}, ${escapeSqlValue(row.principalName)}, ${escapeSqlValue(row.notes)}, ${escapeSqlValue(row.serialNumber)}, ${escapeSqlValue(row.examPeriod)}, ${escapeSqlValue(row.weeklyAverage)}, ${escapeSqlValue(row.monthlyAverage)}, ${escapeSqlValue(row.examsCount)}, ${escapeSqlValue(row.breakdownJson)}, ${escapeSqlValue(row.isAutoGenerated)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 6. Timetable
  const timetableRows = await db.select().from(timetable);
  dump += `-- Table: timetable (${timetableRows.length} records)\n`;
  for (const row of timetableRows) {
    dump += `${insertPrefix} timetable (id, day, day_ar, time, subject, course_title, teacher_id, teacher_name, lesson_id, lesson_title, grade, semester, type, room_or_link, status, capacity, notes) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.day)}, ${escapeSqlValue(row.dayAr)}, ${escapeSqlValue(row.time)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.courseTitle)}, ${escapeSqlValue(row.teacherId)}, ${escapeSqlValue(row.teacherName)}, ${escapeSqlValue(row.lessonId)}, ${escapeSqlValue(row.lessonTitle)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.semester)}, ${escapeSqlValue(row.type)}, ${escapeSqlValue(row.roomOrLink)}, ${escapeSqlValue(row.status)}, ${escapeSqlValue(row.capacity)}, ${escapeSqlValue(row.notes)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 7. Invoices
  const invoiceRows = await db.select().from(invoices);
  dump += `-- Table: invoices (${invoiceRows.length} records)\n`;
  for (const row of invoiceRows) {
    dump += `${insertPrefix} invoices (id, invoice_number, student_id, student_name, grade, amount, currency, due_date, status, payment_method, paid_date, description) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.invoiceNumber)}, ${escapeSqlValue(row.studentId)}, ${escapeSqlValue(row.studentName)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.amount)}, ${escapeSqlValue(row.currency)}, ${escapeSqlValue(row.dueDate)}, ${escapeSqlValue(row.status)}, ${escapeSqlValue(row.paymentMethod)}, ${escapeSqlValue(row.paidDate)}, ${escapeSqlValue(row.description)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 8. Parent Conversations
  const convRows = await db.select().from(parentConversations);
  dump += `-- Table: parent_conversations (${convRows.length} records)\n`;
  for (const row of convRows) {
    dump += `${insertPrefix} parent_conversations (id, channel_type, title, description, student_id, student_name, student_grade, teacher_id, teacher_name, admin_name, parent_name, parent_phone, parent_email, created_by_id, created_by_name, created_by_role, member_ids, member_names, target_audience, status, warning_count, notes, last_message, last_timestamp, unread_count) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.channelType)}, ${escapeSqlValue(row.title)}, ${escapeSqlValue(row.description)}, ${escapeSqlValue(row.studentId)}, ${escapeSqlValue(row.studentName)}, ${escapeSqlValue(row.studentGrade)}, ${escapeSqlValue(row.teacherId)}, ${escapeSqlValue(row.teacherName)}, ${escapeSqlValue(row.adminName)}, ${escapeSqlValue(row.parentName)}, ${escapeSqlValue(row.parentPhone)}, ${escapeSqlValue(row.parentEmail)}, ${escapeSqlValue(row.createdById)}, ${escapeSqlValue(row.createdByName)}, ${escapeSqlValue(row.createdByRole)}, ${escapeSqlValue(row.memberIds)}, ${escapeSqlValue(row.memberNames)}, ${escapeSqlValue(row.targetAudience)}, ${escapeSqlValue(row.status)}, ${escapeSqlValue(row.warningCount)}, ${escapeSqlValue(row.notes)}, ${escapeSqlValue(row.lastMessage)}, ${escapeSqlValue(row.lastTimestamp)}, ${escapeSqlValue(row.unreadCount)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 9. Parent Messages
  const pMsgRows = await db.select().from(parentMessages);
  dump += `-- Table: parent_messages (${pMsgRows.length} records)\n`;
  for (const row of pMsgRows) {
    dump += `${insertPrefix} parent_messages (id, conversation_id, sender, sender_id, sender_name, sender_role_label, message_type, text, media_url, file_name, file_size, mime_type, duration_seconds, sticker_key, sticker_category, sticker_label, timestamp, read) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.conversationId)}, ${escapeSqlValue(row.sender)}, ${escapeSqlValue(row.senderId)}, ${escapeSqlValue(row.senderName)}, ${escapeSqlValue(row.senderRoleLabel)}, ${escapeSqlValue(row.messageType)}, ${escapeSqlValue(row.text)}, ${escapeSqlValue(row.mediaUrl)}, ${escapeSqlValue(row.fileName)}, ${escapeSqlValue(row.fileSize)}, ${escapeSqlValue(row.mimeType)}, ${escapeSqlValue(row.durationSeconds)}, ${escapeSqlValue(row.stickerKey)}, ${escapeSqlValue(row.stickerCategory)}, ${escapeSqlValue(row.stickerLabel)}, ${escapeSqlValue(row.timestamp)}, ${escapeSqlValue(row.read)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 5c. Assignments
  const assignmentRows = await db.select().from(assignments);
  dump += `-- Table: assignments (${assignmentRows.length} records)\n`;
  for (const row of assignmentRows) {
    dump += `${insertPrefix} assignments (id, title, description, instructions, subject, grade, unit, lesson_id, lesson_title, teacher_id, teacher_name, due_date, max_marks, is_published) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.title)}, ${escapeSqlValue(row.description)}, ${escapeSqlValue(row.instructions)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.unit)}, ${escapeSqlValue(row.lessonId)}, ${escapeSqlValue(row.lessonTitle)}, ${escapeSqlValue(row.teacherId)}, ${escapeSqlValue(row.teacherName)}, ${escapeSqlValue(row.dueDate)}, ${escapeSqlValue(row.maxMarks)}, ${escapeSqlValue(row.isPublished)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 5d. Assignment Submissions
  const subRows = await db.select().from(assignmentSubmissions);
  dump += `-- Table: assignment_submissions (${subRows.length} records)\n`;
  for (const row of subRows) {
    dump += `${insertPrefix} assignment_submissions (id, assignment_id, student_id, student_name, student_code, answer_text, score, feedback, status, submitted_at, graded_at) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.assignmentId)}, ${escapeSqlValue(row.studentId)}, ${escapeSqlValue(row.studentName)}, ${escapeSqlValue(row.studentCode)}, ${escapeSqlValue(row.answerText)}, ${escapeSqlValue(row.score)}, ${escapeSqlValue(row.feedback)}, ${escapeSqlValue(row.status)}, ${escapeSqlValue(row.submittedAt)}, ${escapeSqlValue(row.gradedAt)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 10. Notifications
  const notifRows = await db.select().from(notifications);
  dump += `-- Table: notifications (${notifRows.length} records)\n`;
  for (const row of notifRows) {
    dump += `${insertPrefix} notifications (id, title, message, target, category, related_type, related_id, created_at, read) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.title)}, ${escapeSqlValue(row.message)}, ${escapeSqlValue(row.target)}, ${escapeSqlValue(row.category)}, ${escapeSqlValue(row.relatedType)}, ${escapeSqlValue(row.relatedId)}, ${escapeSqlValue(row.createdAt)}, ${escapeSqlValue(row.read)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 11. FAQs
  const faqRows = await db.select().from(faqs);
  dump += `-- Table: faqs (${faqRows.length} records)\n`;
  for (const row of faqRows) {
    dump += `${insertPrefix} faqs (id, question_ar, question_en, answer_ar, answer_en, category) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.questionAr)}, ${escapeSqlValue(row.questionEn)}, ${escapeSqlValue(row.answerAr)}, ${escapeSqlValue(row.answerEn)}, ${escapeSqlValue(row.category)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 12. Inquiries
  const inquiryRows = await db.select().from(inquiries);
  dump += `-- Table: inquiries (${inquiryRows.length} records)\n`;
  for (const row of inquiryRows) {
    dump += `${insertPrefix} inquiries (id, sender_name, sender_role, sender_contact, subject, message, category, priority, status, reply_text, replied_by, replied_at, created_at) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.senderName)}, ${escapeSqlValue(row.senderRole)}, ${escapeSqlValue(row.senderContact)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.message)}, ${escapeSqlValue(row.category)}, ${escapeSqlValue(row.priority)}, ${escapeSqlValue(row.status)}, ${escapeSqlValue(row.replyText)}, ${escapeSqlValue(row.repliedBy)}, ${escapeSqlValue(row.repliedAt)}, ${escapeSqlValue(row.createdAt)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 13. Audit Logs
  const auditRows = await db.select().from(auditLogs);
  dump += `-- Table: audit_logs (${auditRows.length} records)\n`;
  for (const row of auditRows) {
    dump += `${insertPrefix} audit_logs (id, action, action_ar, entity_type, entity_name, performed_by, timestamp, details, severity) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.action)}, ${escapeSqlValue(row.actionAr)}, ${escapeSqlValue(row.entityType)}, ${escapeSqlValue(row.entityName)}, ${escapeSqlValue(row.performedBy)}, ${escapeSqlValue(row.timestamp)}, ${escapeSqlValue(row.details)}, ${escapeSqlValue(row.severity)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  // 14. Lesson Ratings
  const ratingRows = await db.select().from(lessonRatings);
  dump += `-- Table: lesson_ratings (${ratingRows.length} records)\n`;
  for (const row of ratingRows) {
    dump += `${insertPrefix} lesson_ratings (id, lesson_id, lesson_title, subject, grade, teacher_id, teacher_name, student_id, student_name, rating, clarity_rating, benefit_rating, comment, created_at) VALUES (${escapeSqlValue(row.id)}, ${escapeSqlValue(row.lessonId)}, ${escapeSqlValue(row.lessonTitle)}, ${escapeSqlValue(row.subject)}, ${escapeSqlValue(row.grade)}, ${escapeSqlValue(row.teacherId)}, ${escapeSqlValue(row.teacherName)}, ${escapeSqlValue(row.studentId)}, ${escapeSqlValue(row.studentName)}, ${escapeSqlValue(row.rating)}, ${escapeSqlValue(row.clarityRating)}, ${escapeSqlValue(row.benefitRating)}, ${escapeSqlValue(row.comment)}, ${escapeSqlValue(row.createdAt)})${conflictEnd('id')}\n`;
  }
  dump += `\n`;

  dump += isMysql ? `COMMIT;\nSET FOREIGN_KEY_CHECKS=1;\n` : `COMMIT;\n`;
  dump += `-- Dump completed at ${new Date().toISOString()}\n`;

  return dump;
}

// ---------------- System Settings Key/Value Helpers ----------------
export async function getSystemSetting(key: string): Promise<string | null> {
  try {
    const rows = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return rows[0]?.value ?? null;
  } catch (error) {
    console.error('Failed to get system setting:', error);
    return null;
  }
}

export async function setSystemSetting(key: string, value: string): Promise<void> {
  try {
    const existing = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    if (existing.length > 0) {
      await db
        .update(systemSettings)
        .set({ value, updatedAt: new Date() })
        .where(eq(systemSettings.key, key));
    } else {
      await db.insert(systemSettings).values({ key, value, updatedAt: new Date() });
    }
  } catch (error) {
    console.error('Failed to set system setting:', error);
  }
}

export async function getUserById(id: number) {
  try {
    const rows = await db.select().from(users).where(eq(users.id, id));
    return rows[0] || null;
  } catch (error) {
    console.error('Failed to fetch user by id:', error);
    return null;
  }
}

// ---------------- Lesson Rating Surveys CRUD ----------------
export async function getAllLessonRatings(filters?: {
  lessonId?: string;
  studentId?: string;
  teacherId?: string;
}) {
  try {
    const all = await db.select().from(lessonRatings).orderBy(desc(lessonRatings.updatedAt));
    return all.filter((r) => {
      if (filters?.lessonId && r.lessonId !== filters.lessonId) return false;
      if (filters?.studentId && r.studentId !== filters.studentId) return false;
      if (filters?.teacherId && r.teacherId !== filters.teacherId) return false;
      return true;
    });
  } catch (error) {
    console.error('Failed to fetch lesson ratings:', error);
    return [];
  }
}

export async function upsertLessonRating(data: any) {
  try {
    const lessonId = String(data.lessonId || '').trim();
    const studentId = String(data.studentId || '').trim();
    if (!lessonId || !studentId) {
      throw new Error('lessonId and studentId are required');
    }
    const clampStars = (val: any, fallback = 5) => {
      const n = Number(val);
      if (Number.isNaN(n)) return fallback;
      return Math.min(5, Math.max(1, Math.round(n)));
    };
    const rating = clampStars(data.rating, 5);
    const clarityRating = clampStars(data.clarityRating, rating);
    const benefitRating = clampStars(data.benefitRating, rating);
    const comment = String(data.comment || '').trim();
    const nowStr = new Date().toISOString().split('T')[0];

    const existing = await db
      .select()
      .from(lessonRatings)
      .where(and(eq(lessonRatings.lessonId, lessonId), eq(lessonRatings.studentId, studentId)));

    if (existing.length > 0) {
      const updated = await db
        .update(lessonRatings)
        .set({
          rating,
          clarityRating,
          benefitRating,
          comment,
          lessonTitle: String(data.lessonTitle || existing[0].lessonTitle),
          subject: String(data.subject || existing[0].subject),
          grade: String(data.grade || existing[0].grade),
          teacherId: String(data.teacherId ?? existing[0].teacherId ?? ''),
          teacherName: String(data.teacherName ?? existing[0].teacherName ?? ''),
          studentName: String(data.studentName || existing[0].studentName),
          createdAt: nowStr,
          updatedAt: new Date(),
        })
        .where(eq(lessonRatings.id, existing[0].id))
        .returning();
      return updated[0];
    }

    const id = `lrat-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const inserted = await db
      .insert(lessonRatings)
      .values({
        id,
        lessonId,
        lessonTitle: String(data.lessonTitle || 'درس تعليمي').trim(),
        subject: String(data.subject || 'مادة دراسية').trim(),
        grade: String(data.grade || '').trim(),
        teacherId: String(data.teacherId || '').trim(),
        teacherName: String(data.teacherName || '').trim(),
        studentId,
        studentName: String(data.studentName || 'طالب').trim(),
        rating,
        clarityRating,
        benefitRating,
        comment,
        createdAt: nowStr,
        updatedAt: new Date(),
      })
      .returning();
    return inserted[0];
  } catch (error) {
    console.error('Failed to upsert lesson rating:', error);
    throw new Error('Failed to save lesson rating in database', { cause: error });
  }
}

export async function deleteLessonRating(id: string) {
  try {
    await db.delete(lessonRatings).where(eq(lessonRatings.id, id));
    return { success: true, id };
  } catch (error) {
    console.error('Failed to delete lesson rating:', error);
    throw new Error('Failed to delete lesson rating from database', { cause: error });
  }
}

// ---------------- Web Push Subscriptions CRUD ----------------
export async function getAllPushSubscriptions() {
  try {
    return await db.select().from(pushSubscriptions);
  } catch (error) {
    console.error('Failed to fetch push subscriptions:', error);
    return [];
  }
}

export async function savePushSubscription(data: {
  endpoint: string;
  p256dh: string;
  auth: string;
  userId?: string;
  userRole?: string;
  userName?: string;
  deviceLabel?: string;
}) {
  try {
    const endpoint = String(data.endpoint || '').trim();
    if (!endpoint) throw new Error('endpoint is required');
    const existing = await db
      .select()
      .from(pushSubscriptions)
      .where(eq(pushSubscriptions.endpoint, endpoint));

    const nowStr = new Date().toISOString();
    if (existing.length > 0) {
      const updated = await db
        .update(pushSubscriptions)
        .set({
          p256dh: String(data.p256dh || existing[0].p256dh),
          auth: String(data.auth || existing[0].auth),
          userId: String(data.userId ?? existing[0].userId ?? ''),
          userRole: String(data.userRole ?? existing[0].userRole ?? 'visitor'),
          userName: String(data.userName ?? existing[0].userName ?? ''),
          deviceLabel: String(data.deviceLabel ?? existing[0].deviceLabel ?? ''),
        })
        .where(eq(pushSubscriptions.id, existing[0].id))
        .returning();
      return updated[0];
    }

    const id = `psub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const inserted = await db
      .insert(pushSubscriptions)
      .values({
        id,
        endpoint,
        p256dh: String(data.p256dh || ''),
        auth: String(data.auth || ''),
        userId: String(data.userId || ''),
        userRole: String(data.userRole || 'visitor'),
        userName: String(data.userName || ''),
        deviceLabel: String(data.deviceLabel || ''),
        createdAt: nowStr,
      })
      .returning();
    return inserted[0];
  } catch (error) {
    console.error('Failed to save push subscription:', error);
    throw new Error('Failed to persist push subscription', { cause: error });
  }
}

export async function deletePushSubscriptionByEndpoint(endpoint: string) {
  try {
    await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));
    return { success: true };
  } catch (error) {
    console.error('Failed to delete push subscription:', error);
    return { success: false };
  }
}

