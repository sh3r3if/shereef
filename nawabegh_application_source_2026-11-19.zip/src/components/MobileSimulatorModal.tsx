import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Wifi,
  Battery,
  Signal,
  Bell,
  Home,
  Video,
  PenTool,
  MessageSquare,
  Award,
  BookOpen,
  CheckCircle2,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { Lesson, Student, Certificate, Language } from '../types';

interface MobileSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  lessons: Lesson[];
  students: Student[];
  certificates: Certificate[];
  language: Language;
}

type MobileTab = 'home' | 'lessons' | 'whiteboard' | 'chat' | 'certificate';

export const MobileSimulatorModal: React.FC<MobileSimulatorModalProps> = ({
  isOpen,
  onClose,
  lessons,
  students,
  certificates,
  language,
}) => {
  const isAr = language === 'ar';
  const [deviceModel, setDeviceModel] = useState<'ios' | 'android'>('ios');
  const [activeMobileTab, setActiveMobileTab] = useState<MobileTab>('home');
  const [showSimulatedPush, setShowSimulatedPush] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative flex flex-col items-center">
        {/* Top Control Bar for Simulator */}
        <div className="mb-3 flex items-center justify-between w-full max-w-[380px] px-2 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-300">
              {isAr ? 'معاينة تطبيق الموبايل:' : 'Mobile App Simulation:'}
            </span>
            <div className="flex bg-slate-800 p-0.5 rounded-lg text-xs font-mono-numbers">
              <button
                onClick={() => setDeviceModel('ios')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  deviceModel === 'ios' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400'
                }`}
              >
                Apple iOS
              </button>
              <button
                onClick={() => setDeviceModel('android')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  deviceModel === 'android' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400'
                }`}
              >
                Android
              </button>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Smartphone Hardware Frame */}
        <div
          className={`relative w-[min(360px,calc(100vw-2rem))] h-[min(700px,calc(100dvh-6rem))] bg-slate-900 rounded-[40px] sm:rounded-[48px] p-2.5 sm:p-3 shadow-2xl border-4 ${
            deviceModel === 'ios' ? 'border-slate-700 ring-2 ring-slate-800' : 'border-slate-800 rounded-[34px] sm:rounded-[38px]'
          }`}
        >
          {/* Screen Glass */}
          <div className="relative w-full h-full bg-slate-50 dark:bg-slate-950 rounded-[38px] overflow-hidden flex flex-col justify-between text-slate-900 dark:text-white border border-slate-800/40 select-none">
            {/* Status Bar */}
            <div className="px-6 pt-3 pb-1 flex items-center justify-between text-xs font-mono-numbers text-slate-800 dark:text-slate-200 shrink-0 z-20">
              <span className="font-bold text-[13px]">09:41</span>

              {/* Dynamic Island Notch for iOS or Pin-hole for Android */}
              {deviceModel === 'ios' ? (
                <div className="w-24 h-5 bg-black rounded-full mx-auto" />
              ) : (
                <div className="w-3.5 h-3.5 bg-black rounded-full mx-auto" />
              )}

              <div className="flex items-center gap-1.5 text-xs">
                <Signal className="w-3.5 h-3.5" />
                <Wifi className="w-3.5 h-3.5 text-emerald-500" />
                <Battery className="w-4 h-4" />
              </div>
            </div>

            {/* Simulated Live Push Notification Banner */}
            {showSimulatedPush && (
              <div className="mx-3 mt-1 p-2.5 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-indigo-200 dark:border-indigo-900/80 shadow-lg text-xs z-30 animate-bounce duration-1000">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-indigo-600 dark:text-indigo-400">
                    <Bell className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إشعار فوري من الأكاديمية' : 'Nawabegh Edu Alert'}</span>
                  </div>
                  <button onClick={() => setShowSimulatedPush(false)}>
                    <X className="w-3 h-3 text-slate-400" />
                  </button>
                </div>
                <p className="text-[11px] text-slate-700 dark:text-slate-300 mt-1 leading-snug">
                  {isAr
                    ? 'تم رفع ملخص درس التفاضل الجديد واقتراب موعد الاختبار الأسبوعي!'
                    : 'New calculus lesson uploaded and weekly test is live!'}
                </p>
              </div>
            )}

            {/* Mobile Viewport Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {activeMobileTab === 'home' && (
                <div className="space-y-4">
                  {/* Student Quick Profile Widget (Real DB Data) */}
                  {students.length > 0 ? (
                    <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-600 to-indigo-800 text-white shadow-md">
                      <div className="flex items-center justify-between text-xs opacity-80 mb-2">
                        <span>{isAr ? 'أكاديمية نوابغ التعليمية' : 'Nawabegh Mobile'}</span>
                        <span className="flex items-center gap-1 font-mono-numbers">
                          <CheckCircle2 className="w-3 h-3 text-emerald-300" />
                          {isAr ? 'متزامن' : 'Synced'}
                        </span>
                      </div>

                      <h3 className="text-base font-black">
                        {isAr ? `مرحباً، ${students[0].name}` : `Welcome, ${students[0].nameEn || students[0].name}`}
                      </h3>
                      <p className="text-xs opacity-90 mt-0.5">
                        {students[0].grade} · {students[0].code}
                      </p>

                      <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-white/20 text-center font-mono-numbers text-xs">
                        <div className="bg-white/10 rounded-xl p-2">
                          <span className="text-[10px] block opacity-80">{isAr ? 'المعدل العام' : 'Score'}</span>
                          <span className="text-lg font-black text-amber-300">{students[0].overallScore}%</span>
                        </div>
                        <div className="bg-white/10 rounded-xl p-2">
                          <span className="text-[10px] block opacity-80">{isAr ? 'الحضور' : 'Attendance'}</span>
                          <span className="text-lg font-black text-emerald-300">{students[0].attendanceRate}%</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-2xl bg-slate-200 dark:bg-slate-800 text-center space-y-1">
                      <h3 className="text-sm font-bold">{isAr ? 'أكاديمية نوابغ التعليمية' : 'Nawabegh Mobile'}</h3>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {isAr ? 'لا يوجد طلاب مسجلون في قاعدة البيانات بعد' : 'No students registered in DB yet'}
                      </p>
                    </div>
                  )}

                  {/* Quick Lesson Cards on Mobile */}
                  <div>
                    <h4 className="text-xs font-bold text-slate-500 mb-2">
                      {isAr ? 'أحدث الدروس والمحاضرات' : 'Recent Lessons'}
                    </h4>
                    <div className="space-y-2">
                      {lessons.slice(0, 3).map((les) => (
                        <div
                          key={les.id}
                          className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between"
                        >
                          <div className="min-w-0 pr-2">
                            <h5 className="text-xs font-bold truncate text-slate-900 dark:text-white">
                              {les.title}
                            </h5>
                            <span className="text-[10px] text-slate-400 font-mono-numbers">
                              {les.subject} · {les.durationOrPages}
                            </span>
                          </div>
                          <span className="px-2 py-1 rounded-md text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
                            {les.format.toUpperCase()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeMobileTab === 'lessons' && (
                <div className="space-y-3">
                  <h4 className="text-sm font-bold">{isAr ? 'المكتبة والدروس الرقمية' : 'Digital Lessons'}</h4>
                  {lessons.map((les) => (
                    <div
                      key={les.id}
                      className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs space-y-1.5"
                    >
                      <span className="text-[10px] text-indigo-600 font-bold block">{les.subject}</span>
                      <h5 className="font-bold text-slate-900 dark:text-white leading-snug">{les.title}</h5>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono-numbers pt-1">
                        <span>{les.teacherName}</span>
                        <span>{les.durationOrPages}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeMobileTab === 'whiteboard' && (
                <div className="space-y-3 text-center">
                  <h4 className="text-sm font-bold">{isAr ? 'السبورة التفاعلية باللمس' : 'Touch Whiteboard'}</h4>
                  <div className="h-56 bg-slate-900 rounded-2xl border border-slate-700 flex flex-col items-center justify-center text-white p-4">
                    <PenTool className="w-8 h-8 text-indigo-400 mb-2 animate-pulse" />
                    <p className="text-xs font-bold">{isAr ? 'مساحة رسم ذكية متوافقة مع شاشات اللمس' : 'Touch-ready canvas'}</p>
                    <span className="text-[11px] text-slate-400 mt-1 font-mono-numbers">
                      {isAr ? 'تزامن لحظي مع شاشة المعلم' : 'Synchronized with Teacher Screen'}
                    </span>
                  </div>
                </div>
              )}

              {activeMobileTab === 'chat' && (
                <div className="space-y-3">
                  <h4 className="text-sm font-bold">{isAr ? 'محادثة ولي الأمر والمعلم' : 'Parent Messenger'}</h4>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-indigo-600 text-white self-start max-w-[85%] rounded-tr-xs">
                      {isAr ? 'السلام عليكم، تم رصد تفوق الطالب في اختبار اليوم.' : 'Student scored top marks in test!'}
                    </div>
                    <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 self-end max-w-[85%] rounded-tl-xs">
                      {isAr ? 'شكراً جزيلاً لاهتمامكم وحرصكم الدائم.' : 'Thank you for your dedicated care.'}
                    </div>
                  </div>
                </div>
              )}

              {activeMobileTab === 'certificate' && (
                <div className="space-y-3 text-center">
                  <h4 className="text-sm font-bold">{isAr ? 'الشهادات وبيانات الدرجات' : 'DB Certificates & Transcripts'}</h4>
                  {certificates.length === 0 ? (
                    <div className="p-5 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-100/60 dark:bg-slate-900 space-y-2">
                      <Award className="w-8 h-8 text-slate-400 mx-auto" />
                      <p className="text-xs text-slate-500">
                        {isAr
                          ? 'لا توجد شهادات أو بيانات درجات صادرة من قاعدة البيانات بعد.'
                          : 'No DB certificates or transcripts issued yet.'}
                      </p>
                    </div>
                  ) : (
                    certificates.slice(0, 3).map((cert) => (
                      <div key={cert.id} className="p-4 rounded-2xl border-2 border-amber-400 bg-amber-500/10 space-y-2">
                        <Sparkles className="w-6 h-6 text-amber-500 mx-auto" />
                        <h5 className="font-bold text-xs text-slate-900 dark:text-white">
                          {cert.type === 'excellence'
                            ? isAr
                              ? 'شهادة تقدير وتفوق'
                              : 'Certificate of Excellence'
                            : isAr
                            ? 'بيان درجات معتمد'
                            : 'Certified Transcript'}
                        </h5>
                        <p className="text-xs text-indigo-600 font-bold">{cert.studentName}</p>
                        <p className="text-[10px] text-slate-500 font-mono-numbers">{cert.serialNumber}</p>
                        <span className="inline-block px-3 py-1 bg-amber-500 text-white rounded-full text-xs font-mono-numbers font-black">
                          {cert.score}%
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Mobile Bottom Navigation Bar */}
            <div className="px-3 py-2 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-around text-slate-500 shrink-0 z-20">
              <button
                onClick={() => setActiveMobileTab('home')}
                className={`flex flex-col items-center gap-0.5 ${
                  activeMobileTab === 'home' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : ''
                }`}
              >
                <Home className="w-4 h-4" />
                <span className="text-[10px]">{isAr ? 'الرئيسية' : 'Home'}</span>
              </button>

              <button
                onClick={() => setActiveMobileTab('lessons')}
                className={`flex flex-col items-center gap-0.5 ${
                  activeMobileTab === 'lessons' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : ''
                }`}
              >
                <Video className="w-4 h-4" />
                <span className="text-[10px]">{isAr ? 'الدروس' : 'Lessons'}</span>
              </button>

              <button
                onClick={() => setActiveMobileTab('whiteboard')}
                className={`flex flex-col items-center gap-0.5 ${
                  activeMobileTab === 'whiteboard' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : ''
                }`}
              >
                <PenTool className="w-4 h-4" />
                <span className="text-[10px]">{isAr ? 'السبورة' : 'Board'}</span>
              </button>

              <button
                onClick={() => setActiveMobileTab('chat')}
                className={`flex flex-col items-center gap-0.5 ${
                  activeMobileTab === 'chat' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : ''
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span className="text-[10px]">{isAr ? 'محادثة' : 'Chat'}</span>
              </button>

              <button
                onClick={() => setActiveMobileTab('certificate')}
                className={`flex flex-col items-center gap-0.5 ${
                  activeMobileTab === 'certificate' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : ''
                }`}
              >
                <Award className="w-4 h-4" />
                <span className="text-[10px]">{isAr ? 'الشهادة' : 'Honor'}</span>
              </button>
            </div>

            {/* Bottom Home Indicator Bar */}
            <div className="w-32 h-1 bg-slate-400 dark:bg-slate-600 rounded-full mx-auto my-1.5 shrink-0" />
          </div>
        </div>
      </div>
    </div>
  );
};
