import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ChatChannelType,
  ChatDirectoryUser,
  ChatGroupAudience,
  ChatMessage,
  ChatSenderRole,
  CurrentUser,
  Language,
  ParentConversation,
  ParentMessageType,
  StickerCategory,
  Student,
  Teacher,
} from '../types';
import { realtimeSync } from '../services/realtimeSync';
import {
  getAuthHeaders,
  getChannelTypeLabel,
  getRoleBadgeLabel,
  isAdminStaffRole,
  isConversationVisibleForUser,
  isParentRole,
  isStudentRole,
  isTeacherRole,
  resolveMatchedStudent,
  resolveMatchedTeacher,
} from '../utils/rbac';
import {
  AlertTriangle,
  ArrowRight,
  Building2,
  Check,
  CheckCheck,
  Download,
  Edit3,
  Eye,
  FileText,
  Film,
  Globe,
  GraduationCap,
  Lock,
  MessageSquare,
  Mic,
  MicOff,
  Paperclip,
  Phone,
  PhoneCall,
  PhoneIncoming,
  PhoneOff,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Smile,
  Square,
  Sticker,
  Trash2,
  UserCheck,
  Users,
  Volume2,
  X,
} from 'lucide-react';

interface ParentCommunicationProps {
  conversations: ParentConversation[];
  students: Student[];
  teachers?: Teacher[];
  directoryUsers?: ChatDirectoryUser[];
  currentUser: CurrentUser;
  language: Language;
  onConversationsSync: (updater: (prev: ParentConversation[]) => ParentConversation[]) => void;
  onLogActivity?: (actionAr: string, entityName: string, details: string) => void;
}

interface StickerItem {
  key: string;
  category: StickerCategory;
  label: string;
  labelEn: string;
  emoji: string;
  subtitle: string;
  gradient: string;
  badgeText: string;
}

const STICKER_PACK: StickerItem[] = [
  {
    key: 'rate_excellent',
    category: 'rating',
    label: 'ممتاز',
    labelEn: 'Excellent',
    emoji: '🌟',
    subtitle: 'أداء أكاديمي وتفاعلي متفوق',
    gradient: 'from-emerald-500 to-teal-600 text-white border-emerald-400',
    badgeText: 'تقييم مستوى',
  },
  {
    key: 'rate_very_good',
    category: 'rating',
    label: 'جيد جداً',
    labelEn: 'Very Good',
    emoji: '👏',
    subtitle: 'تقدم ملحوظ والتزام رائع',
    gradient: 'from-cyan-500 to-blue-600 text-white border-cyan-400',
    badgeText: 'تقييم مستوى',
  },
  {
    key: 'rate_good',
    category: 'rating',
    label: 'جيد',
    labelEn: 'Good',
    emoji: '👍',
    subtitle: 'مستوى مستقر وقابل للتطوير',
    gradient: 'from-sky-500 to-indigo-600 text-white border-sky-400',
    badgeText: 'تقييم مستوى',
  },
  {
    key: 'rate_acceptable',
    category: 'rating',
    label: 'مقبول',
    labelEn: 'Acceptable',
    emoji: '✅',
    subtitle: 'يحتاج لمزيد من المراجعة المنزلية',
    gradient: 'from-amber-500 to-yellow-600 text-slate-950 border-amber-400',
    badgeText: 'تقييم مستوى',
  },
  {
    key: 'rate_weak',
    category: 'rating',
    label: 'ضعيف',
    labelEn: 'Weak / Needs Help',
    emoji: '📉',
    subtitle: 'تراجع ملحوظ يتطلب خطة علاجية',
    gradient: 'from-rose-500 to-red-600 text-white border-rose-400',
    badgeText: 'تقييم مستوى',
  },
  {
    key: 'congrats_excellence',
    category: 'congrats',
    label: 'مبروك التميز',
    labelEn: 'Congratulations on Excellence',
    emoji: '🏆',
    subtitle: 'ألف مبروك التفوق والتميز الدراسي',
    gradient: 'from-amber-400 via-yellow-500 to-orange-500 text-slate-950 border-yellow-300',
    badgeText: 'تهنئة وتفوق',
  },
  {
    key: 'warn_1',
    category: 'warning',
    label: 'إنذار أول',
    labelEn: 'First Warning',
    emoji: '🟡',
    subtitle: 'تنبيه أول بخصوص الانضباط أو المستوى',
    gradient: 'from-yellow-400 to-amber-500 text-slate-950 border-yellow-300',
    badgeText: 'إشعار رسمي',
  },
  {
    key: 'warn_2',
    category: 'warning',
    label: 'إنذار ثاني',
    labelEn: 'Second Warning',
    emoji: '🟠',
    subtitle: 'تنبيه ثانٍ يستلزم المتابعة فوراً',
    gradient: 'from-orange-500 to-red-500 text-white border-orange-300',
    badgeText: 'إشعار رسمي',
  },
  {
    key: 'warn_3',
    category: 'warning',
    label: 'إنذار ثالث',
    labelEn: 'Third / Final Warning',
    emoji: '🔴',
    subtitle: 'إنذار نهائي — يرجى مراجعة إدارة الأكاديمية',
    gradient: 'from-red-600 to-rose-800 text-white border-red-400',
    badgeText: 'إنذار نهائي',
  },
  {
    key: 'complaint_box',
    category: 'complaint',
    label: 'شكوى',
    labelEn: 'Complaint',
    emoji: '📋',
    subtitle: 'بلاغ أو شكوى رسمية قيد المتابعة',
    gradient: 'from-rose-600 to-pink-700 text-white border-rose-400',
    badgeText: 'قسم الشكاوى',
  },
  {
    key: 'suggestion_box',
    category: 'suggestion',
    label: 'اقتراح',
    labelEn: 'Suggestion',
    emoji: '💡',
    subtitle: 'مقترح تطويري للعملية التعليمية',
    gradient: 'from-violet-600 to-indigo-700 text-white border-violet-400',
    badgeText: 'قسم الاقتراحات',
  },
];

const EMOJI_CATEGORIES = [
  {
    id: 'faces',
    labelAr: 'تعبيرات',
    labelEn: 'Faces',
    emojis: ['😀', '😊', '🥰', '😍', '🤝', '🙏', '👏', '👍', '👌', '🫡', '🤔', '😔', '😟', '😢', '😡', '🥳'],
  },
  {
    id: 'awards',
    labelAr: 'تشجيع',
    labelEn: 'Awards',
    emojis: ['🌟', '⭐', '🏆', '🥇', '🎖️', '💯', '🔥', '🚀', '✨', '💐', '🎉', '🎊', '💪', '👑', '💎', '✅'],
  },
  {
    id: 'study',
    labelAr: 'دراسة',
    labelEn: 'Study',
    emojis: ['📚', '📖', '✏️', '📝', '🎓', '🏫', '🧮', '🔬', '🧪', '💻', '📊', '📅', '⏰', '🔔', '📌', '📎'],
  },
  {
    id: 'alerts',
    labelAr: 'تنبيهات',
    labelEn: 'Alerts',
    emojis: ['⚠️', '🟡', '🟠', '🔴', '📢', '📞', '🎤', '📷', '🎬', '💡', '📋', '❤️', '💚', '💙', '🤍', '🤲'],
  },
];

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function channelVisualMeta(channelType: ChatChannelType, isAr: boolean) {
  switch (channelType) {
    case 'student_teacher':
      return {
        label: isAr ? 'طالب ↔ معلم' : 'Student ↔ Teacher',
        badgeClass: 'bg-sky-100 text-sky-800 dark:bg-sky-900/40 dark:text-sky-300',
        avatarGradient: 'from-sky-500 to-indigo-600',
        Icon: GraduationCap,
      };
    case 'parent_teacher':
      return {
        label: isAr ? 'ولي أمر ↔ معلم' : 'Parent ↔ Teacher',
        badgeClass: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300',
        avatarGradient: 'from-emerald-500 to-teal-700',
        Icon: UserCheck,
      };
    case 'teacher_admin':
      return {
        label: isAr ? 'معلم ↔ إدارة' : 'Teacher ↔ Admin',
        badgeClass: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300',
        avatarGradient: 'from-indigo-500 to-violet-700',
        Icon: Building2,
      };
    case 'private_group':
      return {
        label: isAr ? 'مجموعة خاصة' : 'Private Group',
        badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300',
        avatarGradient: 'from-amber-500 to-orange-600',
        Icon: Lock,
      };
    case 'public_group':
      return {
        label: isAr ? 'مجموعة عامة' : 'Public Group',
        badgeClass: 'bg-teal-100 text-teal-800 dark:bg-teal-900/40 dark:text-teal-300',
        avatarGradient: 'from-teal-500 to-cyan-700',
        Icon: Globe,
      };
  }
}

function audienceLabel(aud: ChatGroupAudience | undefined, isAr: boolean): string {
  switch (aud) {
    case 'students':
      return isAr ? 'الطلاب والطالبات' : 'Students';
    case 'parents':
      return isAr ? 'أولياء الأمور' : 'Parents';
    case 'teachers':
      return isAr ? 'المعلمون' : 'Teachers';
    case 'staff':
      return isAr ? 'الهيئة الإدارية والتعليمية' : 'Staff & Teachers';
    default:
      return isAr ? 'الجميع (عامة)' : 'Everyone';
  }
}

export const ParentCommunication: React.FC<ParentCommunicationProps> = ({
  conversations,
  students,
  teachers = [],
  directoryUsers = [],
  currentUser,
  language,
  onConversationsSync,
  onLogActivity,
}) => {
  const isAr = language === 'ar';

  const isStudent = isStudentRole(currentUser.role);
  const isParent = isParentRole(currentUser.role);
  const isTeacher = isTeacherRole(currentUser.role);
  const isAdminStaff = isAdminStaffRole(currentUser.role);
  const canManageGroupsAndEdit = isAdminStaff || isTeacher;

  const matchedTeacher = useMemo(
    () => resolveMatchedTeacher(currentUser, teachers),
    [currentUser, teachers]
  );
  const matchedStudent = useMemo(
    () => resolveMatchedStudent(currentUser, students),
    [currentUser, students]
  );

  // Deduplicated directory of selectable members for Private Groups
  const selectableDirectory = useMemo(() => {
    const map = new Map<
      string,
      { id: string; name: string; role: string; subtitle: string }
    >();

    for (const u of directoryUsers) {
      if (!u.id || u.role === 'visitor') continue;
      map.set(u.id, {
        id: u.id,
        name: u.name,
        role: u.role,
        subtitle: u.roleTitle || getRoleBadgeLabel(u.role, language),
      });
    }
    for (const t of teachers) {
      if (!map.has(t.id)) {
        map.set(t.id, {
          id: t.id,
          name: t.name,
          role: 'teacher',
          subtitle: t.specialty || getRoleBadgeLabel('teacher', language),
        });
      }
    }
    for (const s of students) {
      if (!map.has(s.id)) {
        map.set(s.id, {
          id: s.id,
          name: s.name,
          role: 'student',
          subtitle: `${s.grade}${s.parentName ? ` · ولي الأمر: ${s.parentName}` : ''}`,
        });
      }
    }
    return Array.from(map.values());
  }, [directoryUsers, teachers, students, language]);

  const adminDirectory = useMemo(
    () =>
      directoryUsers.filter(
        (u) => u.role === 'admin' || u.role === 'supervisor' || u.role === 'secretary'
      ),
    [directoryUsers]
  );

  // Selected conversation & list filtering
  const [selectedId, setSelectedId] = useState<string>('');
  const [mobileShowChat, setMobileShowChat] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [channelFilter, setChannelFilter] = useState<'all' | ChatChannelType>('all');
  const [statusFilter, setStatusFilter] = useState<
    'all' | 'active' | 'needs_followup' | 'warnings' | 'archived'
  >('all');
  const [isLoading, setIsLoading] = useState(false);

  // Optional Admin view-as switcher (only for Admin/Staff testing or replying on behalf; Teachers/Students/Parents send strictly as their real role)
  const [adminReplyMode, setAdminReplyMode] = useState<'self' | 'teacher' | 'parent' | 'student'>('self');

  useEffect(() => {
    setAdminReplyMode('self');
    setChannelFilter('all');
  }, [currentUser.id, currentUser.role]);

  // Message composer state
  const [messageText, setMessageText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [activeEmojiTab, setActiveEmojiTab] = useState('faces');
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [stickerFilter, setStickerFilter] = useState<'all' | StickerCategory>('all');
  const [stickerCustomNote, setStickerCustomNote] = useState('');

  // Pending file/media attachment preview
  const [pendingAttachment, setPendingAttachment] = useState<{
    messageType: 'image' | 'video' | 'audio' | 'file';
    mediaUrl: string;
    fileName: string;
    fileSize: string;
    mimeType: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Voice recording (MediaRecorder)
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);
  const recordingStreamRef = useRef<MediaStream | null>(null);
  const cancelRecordingFlagRef = useRef(false);

  // Inline toast notification
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const showToast = (type: 'success' | 'error' | 'info', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 5000);
  };

  // Live typing indicator
  const [remoteTyping, setRemoteTyping] = useState<{
    conversationId: string;
    senderName: string;
  } | null>(null);
  const typingTimeoutRef = useRef<any>(null);

  // Modals: Create / Edit / Delete / Details / Lightbox / Edit Message
  const [isConvModalOpen, setIsConvModalOpen] = useState(false);
  const [editingConv, setEditingConv] = useState<ParentConversation | null>(null);
  const [memberSearchTerm, setMemberSearchTerm] = useState('');
  const [convForm, setConvForm] = useState<{
    channelType: ChatChannelType;
    title: string;
    description: string;
    studentId: string;
    studentName: string;
    studentGrade: string;
    teacherId: string;
    teacherName: string;
    adminName: string;
    parentName: string;
    parentPhone: string;
    parentEmail: string;
    targetAudience: ChatGroupAudience;
    memberIds: string[];
    memberNames: string[];
    status: 'active' | 'needs_followup' | 'archived';
    notes: string;
    initialMessage: string;
  }>({
    channelType: 'parent_teacher',
    title: '',
    description: '',
    studentId: '',
    studentName: '',
    studentGrade: 'الصف الثالث الثانوي',
    teacherId: '',
    teacherName: '',
    adminName: 'الإدارة العامة',
    parentName: '',
    parentPhone: '',
    parentEmail: '',
    targetAudience: 'all',
    memberIds: [],
    memberNames: [],
    status: 'active',
    notes: '',
    initialMessage: '',
  });

  const [deletingConv, setDeletingConv] = useState<ParentConversation | null>(null);
  const [detailsConv, setDetailsConv] = useState<ParentConversation | null>(null);
  const [detailsTab, setDetailsTab] = useState<'overview' | 'members' | 'media' | 'warnings' | 'calls'>('overview');
  const [lightboxImage, setLightboxImage] = useState<{ url: string; title: string } | null>(null);

  const [editingMsg, setEditingMsg] = useState<{ id: string; text: string } | null>(null);
  const [deletingMsgId, setDeletingMsgId] = useState<string | null>(null);

  // Real WebRTC Voice Call state
  const [callState, setCallState] = useState<'idle' | 'calling' | 'incoming' | 'connected'>('idle');
  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const [callConversationId, setCallConversationId] = useState<string | null>(null);
  const [callPeerName, setCallPeerName] = useState<string>('');
  const [callDuration, setCallDuration] = useState(0);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [incomingOfferSdp, setIncomingOfferSdp] = useState<RTCSessionDescriptionInit | null>(null);

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localCallStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const callTimerRef = useRef<any>(null);
  const callDurationRef = useRef(0);
  const pendingIceCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Filter conversations visible to current user role
  const roleVisibleConvs = useMemo(
    () =>
      conversations.filter((c) =>
        isConversationVisibleForUser(c, currentUser, teachers, students)
      ),
    [conversations, currentUser, teachers, students]
  );

  // Visible channel tabs for this user's role
  const availableChannelTabs = useMemo(() => {
    const base: Array<{ key: 'all' | ChatChannelType; label: string }> = [
      { key: 'all', label: isAr ? 'الكل' : 'All' },
    ];
    if (isAdminStaff || isTeacher || isStudent) {
      base.push({
        key: 'student_teacher',
        label: isAr ? 'طالب ↔ معلم' : 'Student ↔ Teacher',
      });
    }
    if (isAdminStaff || isTeacher || isParent) {
      base.push({
        key: 'parent_teacher',
        label: isAr ? 'ولي أمر ↔ معلم' : 'Parent ↔ Teacher',
      });
    }
    if (isAdminStaff || isTeacher) {
      base.push({
        key: 'teacher_admin',
        label: isAr ? 'معلم ↔ إدارة' : 'Teacher ↔ Admin',
      });
    }
    base.push({
      key: 'private_group',
      label: isAr ? 'مجموعات خاصة' : 'Private Groups',
    });
    base.push({
      key: 'public_group',
      label: isAr ? 'مجموعات عامة' : 'Public Groups',
    });
    return base;
  }, [isAr, isAdminStaff, isTeacher, isStudent, isParent]);

  const channelCounts = useMemo(() => {
    const counts: Record<string, number> = {
      all: roleVisibleConvs.length,
      student_teacher: 0,
      parent_teacher: 0,
      teacher_admin: 0,
      private_group: 0,
      public_group: 0,
    };
    for (const c of roleVisibleConvs) {
      const ch = c.channelType || 'parent_teacher';
      counts[ch] = (counts[ch] || 0) + 1;
    }
    return counts;
  }, [roleVisibleConvs]);

  // Filtered conversations list
  const filteredConvs = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return roleVisibleConvs.filter((c) => {
      const ch = c.channelType || 'parent_teacher';
      if (channelFilter !== 'all' && ch !== channelFilter) return false;
      const matchesQuery =
        !q ||
        (c.title || '').toLowerCase().includes(q) ||
        c.parentName.toLowerCase().includes(q) ||
        c.studentName.toLowerCase().includes(q) ||
        (c.teacherName || '').toLowerCase().includes(q) ||
        (c.adminName || '').toLowerCase().includes(q) ||
        c.parentPhone.toLowerCase().includes(q) ||
        (c.lastMessage || '').toLowerCase().includes(q);
      if (!matchesQuery) return false;
      if (statusFilter === 'warnings') return (c.warningCount || 0) > 0;
      if (statusFilter !== 'all') return (c.status || 'active') === statusFilter;
      return true;
    });
  }, [roleVisibleConvs, searchTerm, channelFilter, statusFilter]);

  // Keep selectedId valid inside role-visible list
  useEffect(() => {
    if (filteredConvs.length > 0) {
      if (!selectedId || !filteredConvs.some((c) => c.id === selectedId)) {
        setSelectedId(filteredConvs[0].id);
      }
      return;
    }
    if (roleVisibleConvs.length > 0) {
      if (!selectedId || !roleVisibleConvs.some((c) => c.id === selectedId)) {
        setSelectedId(roleVisibleConvs[0].id);
      }
      return;
    }
    setSelectedId('');
  }, [filteredConvs, roleVisibleConvs, selectedId]);

  const activeConv = useMemo(
    () => roleVisibleConvs.find((c) => c.id === selectedId) || null,
    [roleVisibleConvs, selectedId]
  );

  // Auto-scroll to newest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConv?.id, activeConv?.messages.length]);

  // Mark conversation as read in DB when opened
  useEffect(() => {
    if (!activeConv || activeConv.unreadCount === 0) return;
    fetch(`/api/parent-conversations/${activeConv.id}/read`, { method: 'PUT' })
      .then((r) => (r.ok ? r.json() : null))
      .then((updated) => {
        if (updated?.id) {
          onConversationsSync((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
        }
      })
      .catch(() => {});
  }, [activeConv?.id]);

  // Keep detailsConv synced with latest conversation state
  useEffect(() => {
    if (detailsConv) {
      const fresh = conversations.find((c) => c.id === detailsConv.id);
      if (fresh) setDetailsConv(fresh);
    }
  }, [conversations]);

  const matchedStudentForActive = useMemo(() => {
    if (!activeConv) return null;
    return (
      students.find((s) => s.id === activeConv.studentId) ||
      students.find((s) => s.name === activeConv.studentName) ||
      null
    );
  }, [activeConv, students]);

  // Helper to compute display title & subtitle cleanly per channel type
  const getConversationDisplay = (conv: ParentConversation) => {
    const ch = conv.channelType || 'parent_teacher';
    if (ch === 'private_group') {
      return {
        primary: conv.title || (isAr ? 'مجموعة خاصة' : 'Private Group'),
        secondary: isAr
          ? `${conv.memberNames.length || 1} عضو مشارك${conv.description ? ` · ${conv.description}` : ''}`
          : `${conv.memberNames.length || 1} members`,
      };
    }
    if (ch === 'public_group') {
      return {
        primary: conv.title || (isAr ? 'مجموعة عامة' : 'Public Group'),
        secondary: `${audienceLabel(conv.targetAudience, isAr)}${
          conv.description ? ` · ${conv.description}` : ''
        }`,
      };
    }
    if (ch === 'student_teacher') {
      const stuLabel = conv.studentName || (isAr ? 'طالب' : 'Student');
      const tchLabel = conv.teacherName || conv.parentName || (isAr ? 'معلم' : 'Teacher');
      return {
        primary: conv.title || `${stuLabel} ↔ ${tchLabel}`,
        secondary: isAr
          ? `الطالب: ${stuLabel}${conv.studentGrade ? ` (${conv.studentGrade})` : ''} · المعلم: ${tchLabel}`
          : `Student: ${stuLabel} · Teacher: ${tchLabel}`,
      };
    }
    if (ch === 'teacher_admin') {
      const tchLabel = conv.teacherName || conv.studentName || (isAr ? 'المعلم' : 'Teacher');
      const admLabel = conv.adminName || conv.parentName || (isAr ? 'الإدارة العامة' : 'Administration');
      return {
        primary: conv.title || `${tchLabel} ↔ ${admLabel}`,
        secondary: isAr ? `المعلم: ${tchLabel} · الإدارة: ${admLabel}` : `Teacher: ${tchLabel} · Admin: ${admLabel}`,
      };
    }
    // parent_teacher
    return {
      primary: conv.title || conv.parentName,
      secondary: isAr
        ? `الطالب: ${conv.studentName}${conv.teacherName ? ` · المعلم: ${conv.teacherName}` : ''}`
        : `Student: ${conv.studentName}${conv.teacherName ? ` · Teacher: ${conv.teacherName}` : ''}`,
    };
  };

  // Refresh conversations from DB manually
  const refreshFromDb = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/parent-conversations');
      if (res.ok) {
        const rows = await res.json();
        if (Array.isArray(rows)) {
          onConversationsSync(() => rows);
          showToast('success', isAr ? 'تم تحديث المحادثات من قاعدة البيانات.' : 'Conversations refreshed from DB.');
        }
      }
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to load conversations');
    } finally {
      setIsLoading(false);
    }
  };

  // ---------------- WebRTC Voice Call Helpers & Listeners ----------------
  const cleanupCallResources = () => {
    if (callTimerRef.current) {
      clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    if (peerConnectionRef.current) {
      try {
        peerConnectionRef.current.close();
      } catch {}
      peerConnectionRef.current = null;
    }
    if (localCallStreamRef.current) {
      localCallStreamRef.current.getTracks().forEach((t) => t.stop());
      localCallStreamRef.current = null;
    }
    if (remoteAudioRef.current) {
      remoteAudioRef.current.srcObject = null;
    }
    pendingIceCandidatesRef.current = [];
    setCallState('idle');
    setActiveCallId(null);
    setCallConversationId(null);
    setIncomingOfferSdp(null);
    setIsMicMuted(false);
    setCallDuration(0);
    callDurationRef.current = 0;
  };

  const startCallTimer = () => {
    if (callTimerRef.current) clearInterval(callTimerRef.current);
    callDurationRef.current = 0;
    setCallDuration(0);
    callTimerRef.current = setInterval(() => {
      callDurationRef.current += 1;
      setCallDuration(callDurationRef.current);
    }, 1000);
  };

  const createPeerConnection = (conversationId: string, callId: string) => {
    const pc = new RTCPeerConnection(RTC_CONFIG);

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        realtimeSync.sendParentCallIce({
          conversationId,
          callId,
          candidate: event.candidate.toJSON(),
        });
      }
    };

    pc.ontrack = (event) => {
      if (remoteAudioRef.current && event.streams && event.streams[0]) {
        remoteAudioRef.current.srcObject = event.streams[0];
        remoteAudioRef.current.play().catch(() => {});
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        setCallState('connected');
        startCallTimer();
      } else if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
        showToast('info', isAr ? 'انقطع اتصال المكالمة الصوتية.' : 'Voice call connection interrupted.');
      }
    };

    peerConnectionRef.current = pc;
    return pc;
  };

  useEffect(() => {
    const unsubTyping = realtimeSync.on('parent_chat:typing', (data: any) => {
      if (!data?.conversationId) return;
      if (data.isTyping) {
        setRemoteTyping({ conversationId: data.conversationId, senderName: data.senderName || 'الطرف الآخر' });
        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(() => setRemoteTyping(null), 3000);
      } else {
        setRemoteTyping(null);
      }
    });

    const unsubOffer = realtimeSync.on('parent_call:offer', (data: any) => {
      if (!data?.callId || !data?.sdp) return;
      setActiveCallId(data.callId);
      setCallConversationId(data.conversationId);
      setCallPeerName(data.callerName || (isAr ? 'متصل وارد' : 'Incoming Caller'));
      setIncomingOfferSdp(data.sdp);
      setCallState('incoming');
      if (data.conversationId) setSelectedId(data.conversationId);
    });

    const unsubAnswer = realtimeSync.on('parent_call:answer', async (data: any) => {
      if (!peerConnectionRef.current || !data?.sdp) return;
      try {
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(data.sdp));
        for (const cand of pendingIceCandidatesRef.current) {
          await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(cand));
        }
        pendingIceCandidatesRef.current = [];
        setCallState('connected');
        startCallTimer();
      } catch (err) {
        console.warn('Error setting remote answer:', err);
      }
    });

    const unsubIce = realtimeSync.on('parent_call:ice', async (data: any) => {
      if (!data?.candidate) return;
      if (peerConnectionRef.current && peerConnectionRef.current.remoteDescription) {
        try {
          await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(data.candidate));
        } catch (err) {
          console.warn('Error adding ICE candidate:', err);
        }
      } else {
        pendingIceCandidatesRef.current.push(data.candidate);
      }
    });

    const unsubReject = realtimeSync.on('parent_call:reject', () => {
      showToast('info', isAr ? 'لم يتم الرد أو تم رفض المكالمة الصوتية.' : 'Voice call was declined.');
      cleanupCallResources();
    });

    const unsubEnd = realtimeSync.on('parent_call:end', (data: any) => {
      showToast(
        'info',
        isAr
          ? `انتهت المكالمة الصوتية (المدة: ${formatDuration(Number(data?.durationSeconds || 0))}).`
          : `Voice call ended (${formatDuration(Number(data?.durationSeconds || 0))}).`
      );
      cleanupCallResources();
    });

    return () => {
      unsubTyping();
      unsubOffer();
      unsubAnswer();
      unsubIce();
      unsubReject();
      unsubEnd();
    };
  }, [isAr]);

  useEffect(() => {
    return () => {
      cleanupCallResources();
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      if (recordingStreamRef.current) {
        recordingStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  // ---------------- Core Sender Identity ----------------
  const getCurrentSenderMeta = (): {
    sender: ChatSenderRole;
    senderId: string;
    senderName: string;
    senderRoleLabel: string;
  } => {
    if (isAdminStaff && adminReplyMode !== 'self' && activeConv) {
      if (adminReplyMode === 'parent') {
        return {
          sender: 'parent',
          senderId: currentUser.id,
          senderName: activeConv.parentName || 'ولي الأمر',
          senderRoleLabel: getRoleBadgeLabel('parent', language),
        };
      }
      if (adminReplyMode === 'student') {
        return {
          sender: 'student',
          senderId: activeConv.studentId || currentUser.id,
          senderName: activeConv.studentName || 'الطالب',
          senderRoleLabel: getRoleBadgeLabel('student', language),
        };
      }
      if (adminReplyMode === 'teacher') {
        return {
          sender: 'teacher',
          senderId: activeConv.teacherId || currentUser.id,
          senderName: activeConv.teacherName || currentUser.name,
          senderRoleLabel: getRoleBadgeLabel('teacher', language),
        };
      }
    }

    const roleMap: Record<string, ChatSenderRole> = {
      admin: 'admin',
      supervisor: 'supervisor',
      secretary: 'secretary',
      teacher: 'teacher',
      student: 'student',
      female_student: 'female_student',
      parent: 'parent',
    };
    const sender = roleMap[currentUser.role] || 'teacher';
    return {
      sender,
      senderId: currentUser.id || matchedTeacher?.id || matchedStudent?.id || '',
      senderName: currentUser.name || 'مشارك',
      senderRoleLabel: currentUser.roleTitle || getRoleBadgeLabel(sender, language),
    };
  };

  // Initiate real WebRTC Audio Call
  const handleStartVoiceCall = async () => {
    if (!activeConv) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showToast('error', isAr ? 'المتصفح لا يدعم الوصول إلى الميكروفون.' : 'Microphone API not supported.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      localCallStreamRef.current = stream;

      const callId = `call-${Date.now()}`;
      const display = getConversationDisplay(activeConv);
      const senderMeta = getCurrentSenderMeta();
      setActiveCallId(callId);
      setCallConversationId(activeConv.id);
      setCallPeerName(display.primary);
      setCallState('calling');

      const pc = createPeerConnection(activeConv.id, callId);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      realtimeSync.sendParentCallOffer({
        conversationId: activeConv.id,
        callId,
        callerName: senderMeta.senderName,
        callerRole: senderMeta.sender,
        sdp: offer,
      });

      showToast(
        'info',
        isAr
          ? 'جاري الاتصال الصوتي المباشر عبر WebRTC...'
          : 'Calling via live WebRTC audio...'
      );
    } catch (err: any) {
      cleanupCallResources();
      showToast(
        'error',
        isAr
          ? 'تعذر الوصول للميكروفون لبدء المكالمة الصوتية الحقيقية.'
          : `Microphone error: ${err?.message || 'Permission denied'}`
      );
    }
  };

  const handleAcceptIncomingCall = async () => {
    if (!incomingOfferSdp || !callConversationId || !activeCallId) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      localCallStreamRef.current = stream;

      const pc = createPeerConnection(callConversationId, activeCallId);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      await pc.setRemoteDescription(new RTCSessionDescription(incomingOfferSdp));
      for (const cand of pendingIceCandidatesRef.current) {
        await pc.addIceCandidate(new RTCIceCandidate(cand));
      }
      pendingIceCandidatesRef.current = [];

      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      realtimeSync.sendParentCallAnswer({
        conversationId: callConversationId,
        callId: activeCallId,
        calleeName: currentUser.name || 'الطرف المستجيب',
        sdp: answer,
      });

      setCallState('connected');
      startCallTimer();
    } catch {
      showToast('error', isAr ? 'تعذر تشغيل الميكروفون للرد على المكالمة.' : 'Failed to access microphone.');
      handleRejectIncomingCall();
    }
  };

  const handleRejectIncomingCall = () => {
    if (callConversationId && activeCallId) {
      realtimeSync.sendParentCallReject(callConversationId, activeCallId, 'declined');
    }
    cleanupCallResources();
  };

  const handleEndCall = async () => {
    const convId = callConversationId || activeConv?.id;
    const dur = callDurationRef.current;
    const senderMeta = getCurrentSenderMeta();

    if (convId && activeCallId) {
      realtimeSync.sendParentCallEnd(convId, activeCallId, dur, senderMeta.senderName);
      await saveMessageToDb(convId, {
        messageType: 'call_log',
        text:
          dur > 0
            ? isAr
              ? `مكالمة صوتية مباشرة مكتملة (${formatDuration(dur)})`
              : `Completed live voice call (${formatDuration(dur)})`
            : isAr
            ? 'محاولة اتصال صوتي مباشر'
            : 'Outgoing voice call attempt',
        durationSeconds: dur,
      });
    }
    cleanupCallResources();
  };

  const toggleCallMute = () => {
    if (!localCallStreamRef.current) return;
    const nextMuted = !isMicMuted;
    localCallStreamRef.current.getAudioTracks().forEach((track) => {
      track.enabled = !nextMuted;
    });
    setIsMicMuted(nextMuted);
  };

  // ---------------- Core DB Messaging Helpers ----------------
  const saveMessageToDb = async (
    conversationId: string,
    payload: {
      messageType: ParentMessageType;
      text: string;
      mediaUrl?: string | null;
      fileName?: string | null;
      fileSize?: string | null;
      mimeType?: string | null;
      durationSeconds?: number | null;
      stickerKey?: string | null;
      stickerCategory?: StickerCategory | null;
      stickerLabel?: string | null;
    }
  ) => {
    const senderMeta = getCurrentSenderMeta();
    const res = await fetch(`/api/parent-conversations/${conversationId}/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders(currentUser, teachers),
      },
      body: JSON.stringify({
        ...senderMeta,
        ...payload,
        read: !['parent', 'student', 'female_student'].includes(senderMeta.sender),
      }),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to save message to DB');
    }
    const data = await res.json();
    if (data?.conversation) {
      onConversationsSync((prev) =>
        prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
      );
    }
    return data;
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeConv || isSending) return;
    const cleanText = messageText.trim();
    if (!cleanText && !pendingAttachment) return;

    const senderMeta = getCurrentSenderMeta();
    setIsSending(true);
    try {
      await saveMessageToDb(activeConv.id, {
        messageType: pendingAttachment ? pendingAttachment.messageType : 'text',
        text: cleanText,
        mediaUrl: pendingAttachment?.mediaUrl || null,
        fileName: pendingAttachment?.fileName || null,
        fileSize: pendingAttachment?.fileSize || null,
        mimeType: pendingAttachment?.mimeType || null,
      });
      setMessageText('');
      setPendingAttachment(null);
      setShowEmojiPicker(false);
      realtimeSync.sendParentTyping(
        activeConv.id,
        senderMeta.senderName,
        senderMeta.sender,
        false
      );
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حفظ الرسالة في قاعدة البيانات.' : 'Failed to send message.'));
    } finally {
      setIsSending(false);
    }
  };

  const handleSendSticker = async (sticker: StickerItem) => {
    if (!activeConv || isSending) return;
    setIsSending(true);
    try {
      const noteText = stickerCustomNote.trim() || sticker.subtitle;
      await saveMessageToDb(activeConv.id, {
        messageType: 'sticker',
        text: noteText,
        stickerKey: sticker.key,
        stickerCategory: sticker.category,
        stickerLabel: `${sticker.emoji} ${sticker.label}`,
      });
      setStickerCustomNote('');
      setShowStickerPicker(false);
      if (sticker.category === 'warning') {
        onLogActivity?.(
          'توجيه إنذار رسمي في المحادثات',
          getConversationDisplay(activeConv).primary,
          `تم إرسال (${sticker.label}) وتوثيقه في قاعدة البيانات`
        );
      }
      showToast('success', isAr ? `تم إرسال ملصق (${sticker.label}) وحفظه في قاعدة البيانات.` : `Sent sticker: ${sticker.labelEn}`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to send sticker');
    } finally {
      setIsSending(false);
    }
  };

  const handleStartVoiceRecord = async () => {
    if (!activeConv) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showToast('error', isAr ? 'المتصفح لا يدعم تسجيل الصوت.' : 'Audio recording is not supported.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recordingStreamRef.current = stream;
      cancelRecordingFlagRef.current = false;
      audioChunksRef.current = [];

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        recordingStreamRef.current = null;
        if (recordingTimerRef.current) {
          clearInterval(recordingTimerRef.current);
          recordingTimerRef.current = null;
        }

        const wasCancelled = cancelRecordingFlagRef.current;
        const recordedDuration = Math.max(1, recordingSeconds);
        setIsRecording(false);
        setRecordingSeconds(0);

        if (wasCancelled || audioChunksRef.current.length === 0) return;

        const mimeType = recorder.mimeType || 'audio/webm';
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const dataUrl = String(reader.result || '');
          if (!dataUrl) return;
          try {
            setIsSending(true);
            await saveMessageToDb(activeConv.id, {
              messageType: 'audio',
              text: isAr ? 'تسجيل صوتي مباشر' : 'Voice recording',
              mediaUrl: dataUrl,
              fileName: `voice_${Date.now()}.webm`,
              fileSize: formatBytes(blob.size),
              mimeType,
              durationSeconds: recordedDuration,
            });
            showToast('success', isAr ? 'تم إرسال التسجيل الصوتي وحفظه في قاعدة البيانات.' : 'Voice recording saved to DB.');
          } catch (err: any) {
            showToast('error', err?.message || 'Failed to save voice note');
          } finally {
            setIsSending(false);
          }
        };
        reader.readAsDataURL(blob);
      };

      recorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      showToast(
        'error',
        isAr
          ? 'يرجى السماح بصلاحية الميكروفون لتسجيل الريكورد الصوتي.'
          : `Microphone permission error: ${err?.message || ''}`
      );
    }
  };

  const handleStopAndSendVoiceRecord = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      cancelRecordingFlagRef.current = false;
      mediaRecorderRef.current.stop();
    }
  };

  const handleCancelVoiceRecord = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      cancelRecordingFlagRef.current = true;
      mediaRecorderRef.current.stop();
    } else {
      setIsRecording(false);
      setRecordingSeconds(0);
    }
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    if (file.size > 18 * 1024 * 1024) {
      showToast(
        'error',
        isAr
          ? 'حجم الملف يتجاوز الحد الأقصى المسموح (18 ميجابايت).'
          : 'File size exceeds 18 MB limit.'
      );
      return;
    }

    const mime = file.type || 'application/octet-stream';
    const messageType: 'image' | 'video' | 'audio' | 'file' = mime.startsWith('image/')
      ? 'image'
      : mime.startsWith('video/')
      ? 'video'
      : mime.startsWith('audio/')
      ? 'audio'
      : 'file';

    const reader = new FileReader();
    reader.onload = () => {
      setPendingAttachment({
        messageType,
        mediaUrl: String(reader.result || ''),
        fileName: file.name,
        fileSize: formatBytes(file.size),
        mimeType: mime,
      });
    };
    reader.readAsDataURL(file);
  };

  // ---------------- Conversation & Group CRUD Handlers ----------------
  const allowedChannelTypesForCreate = useMemo<ChatChannelType[]>(() => {
    if (isStudent) return ['student_teacher'];
    if (isParent) return ['parent_teacher'];
    if (isTeacher) {
      return ['student_teacher', 'parent_teacher', 'teacher_admin', 'private_group', 'public_group'];
    }
    return ['student_teacher', 'parent_teacher', 'teacher_admin', 'private_group', 'public_group'];
  }, [isStudent, isParent, isTeacher]);

  const applyChannelDefaults = (ch: ChatChannelType) => {
    const firstStu = matchedStudent || students[0];
    const firstTch = matchedTeacher || teachers[0];
    const firstAdmin = adminDirectory[0];

    setConvForm((prev) => ({
      ...prev,
      channelType: ch,
      studentId: isStudent ? matchedStudent?.id || currentUser.id : firstStu?.id || '',
      studentName: isStudent
        ? matchedStudent?.name || currentUser.name
        : ch === 'teacher_admin' || ch === 'private_group' || ch === 'public_group'
        ? ''
        : firstStu?.name || '',
      studentGrade: isStudent
        ? matchedStudent?.grade || 'الصف الثالث الثانوي'
        : firstStu?.grade || 'الصف الثالث الثانوي',
      teacherId: isTeacher ? matchedTeacher?.id || currentUser.id : firstTch?.id || '',
      teacherName: isTeacher ? matchedTeacher?.name || currentUser.name : firstTch?.name || '',
      adminName: isAdminStaff ? currentUser.name : firstAdmin?.name || 'الإدارة العامة',
      parentName: isParent
        ? currentUser.name
        : ch === 'parent_teacher'
        ? firstStu?.parentName || ''
        : '',
      parentPhone: firstStu?.parentPhone || '',
      parentEmail: isParent ? currentUser.email : firstStu?.parentEmail || '',
      title:
        ch === 'private_group'
          ? ''
          : ch === 'public_group'
          ? ''
          : prev.title,
      memberIds: ch === 'private_group' ? [currentUser.id] : [],
      memberNames: ch === 'private_group' ? [currentUser.name] : [],
    }));
  };

  const openCreateModal = (forcedChannel?: ChatChannelType) => {
    setEditingConv(null);
    setMemberSearchTerm('');
    const defaultCh: ChatChannelType =
      forcedChannel && allowedChannelTypesForCreate.includes(forcedChannel)
        ? forcedChannel
        : isStudent
        ? 'student_teacher'
        : isParent
        ? 'parent_teacher'
        : channelFilter !== 'all' && allowedChannelTypesForCreate.includes(channelFilter)
        ? channelFilter
        : isTeacher
        ? 'student_teacher'
        : 'parent_teacher';

    const firstStu = matchedStudent || students[0];
    const firstTch = matchedTeacher || teachers[0];
    const firstAdmin = adminDirectory[0];

    setConvForm({
      channelType: defaultCh,
      title: '',
      description: '',
      studentId: isStudent ? matchedStudent?.id || currentUser.id : firstStu?.id || '',
      studentName: isStudent
        ? matchedStudent?.name || currentUser.name
        : defaultCh === 'student_teacher' || defaultCh === 'parent_teacher'
        ? firstStu?.name || ''
        : '',
      studentGrade: isStudent
        ? matchedStudent?.grade || 'الصف الثالث الثانوي'
        : firstStu?.grade || 'الصف الثالث الثانوي',
      teacherId: isTeacher ? matchedTeacher?.id || currentUser.id : firstTch?.id || '',
      teacherName: isTeacher ? matchedTeacher?.name || currentUser.name : firstTch?.name || '',
      adminName: isAdminStaff ? currentUser.name : firstAdmin?.name || 'الإدارة العامة',
      parentName: isParent ? currentUser.name : firstStu?.parentName || '',
      parentPhone: firstStu?.parentPhone || '',
      parentEmail: isParent ? currentUser.email : firstStu?.parentEmail || '',
      targetAudience: 'all',
      memberIds: defaultCh === 'private_group' ? [currentUser.id] : [],
      memberNames: defaultCh === 'private_group' ? [currentUser.name] : [],
      status: 'active',
      notes: '',
      initialMessage: '',
    });
    setIsConvModalOpen(true);
  };

  const openEditModal = (conv: ParentConversation) => {
    setEditingConv(conv);
    setMemberSearchTerm('');
    setConvForm({
      channelType: conv.channelType || 'parent_teacher',
      title: conv.title || '',
      description: conv.description || '',
      studentId: conv.studentId || '',
      studentName: conv.studentName || '',
      studentGrade: conv.studentGrade || 'الصف الثالث الثانوي',
      teacherId: conv.teacherId || '',
      teacherName: conv.teacherName || '',
      adminName: conv.adminName || 'الإدارة العامة',
      parentName: conv.parentName || '',
      parentPhone: conv.parentPhone || '',
      parentEmail: conv.parentEmail || '',
      targetAudience: conv.targetAudience || 'all',
      memberIds: conv.memberIds || [],
      memberNames: conv.memberNames || [],
      status: conv.status || 'active',
      notes: conv.notes || '',
      initialMessage: '',
    });
    setIsConvModalOpen(true);
  };

  const toggleGroupMember = (item: { id: string; name: string }) => {
    setConvForm((prev) => {
      const exists = prev.memberIds.includes(item.id);
      if (exists) {
        return {
          ...prev,
          memberIds: prev.memberIds.filter((id) => id !== item.id),
          memberNames: prev.memberNames.filter((n) => n !== item.name),
        };
      }
      return {
        ...prev,
        memberIds: [...prev.memberIds, item.id],
        memberNames: prev.memberNames.includes(item.name)
          ? prev.memberNames
          : [...prev.memberNames, item.name],
      };
    });
  };

  const handleSaveConversation = async (e: React.FormEvent) => {
    e.preventDefault();
    const ch = convForm.channelType;

    if (ch === 'student_teacher' && (!convForm.studentName.trim() || !convForm.teacherName.trim())) {
      showToast('error', isAr ? 'يرجى تحديد الطالب والمعلم.' : 'Student and Teacher names required.');
      return;
    }
    if (ch === 'parent_teacher' && (!convForm.studentName.trim() || !convForm.parentName.trim())) {
      showToast('error', isAr ? 'يرجى إدخال اسم الطالب واسم ولي الأمر.' : 'Student and parent name required.');
      return;
    }
    if (ch === 'teacher_admin' && !convForm.teacherName.trim()) {
      showToast('error', isAr ? 'يرجى تحديد المعلم.' : 'Teacher name required.');
      return;
    }
    if ((ch === 'private_group' || ch === 'public_group') && !convForm.title.trim()) {
      showToast('error', isAr ? 'يرجى كتابة اسم المجموعة.' : 'Group name is required.');
      return;
    }
    if (ch === 'private_group' && convForm.memberIds.length === 0) {
      showToast('error', isAr ? 'يرجى اختيار عضو واحد على الأقل للمجموعة الخاصة.' : 'Select at least one group member.');
      return;
    }

    const senderMeta = getCurrentSenderMeta();
    const derivedMemberIds =
      ch === 'private_group'
        ? Array.from(new Set([...convForm.memberIds, currentUser.id].filter(Boolean)))
        : convForm.memberIds;
    const derivedMemberNames =
      ch === 'private_group'
        ? Array.from(new Set([...convForm.memberNames, currentUser.name].filter(Boolean)))
        : convForm.memberNames;

    const payload = {
      channelType: ch,
      title: convForm.title.trim(),
      description: convForm.description.trim(),
      studentId: convForm.studentId,
      studentName:
        ch === 'teacher_admin'
          ? convForm.teacherName.trim()
          : ch === 'private_group' || ch === 'public_group'
          ? convForm.title.trim()
          : convForm.studentName.trim(),
      studentGrade: convForm.studentGrade.trim(),
      teacherId: convForm.teacherId,
      teacherName: convForm.teacherName.trim(),
      adminName: convForm.adminName.trim() || 'الإدارة العامة',
      parentName:
        ch === 'student_teacher'
          ? convForm.teacherName.trim()
          : ch === 'teacher_admin'
          ? convForm.adminName.trim() || 'الإدارة العامة'
          : ch === 'private_group' || ch === 'public_group'
          ? convForm.title.trim()
          : convForm.parentName.trim(),
      parentPhone: convForm.parentPhone.trim(),
      parentEmail: convForm.parentEmail.trim(),
      targetAudience: convForm.targetAudience,
      memberIds: derivedMemberIds,
      memberNames: derivedMemberNames,
      status: convForm.status,
      notes: convForm.notes.trim(),
    };

    try {
      if (editingConv) {
        const res = await fetch(`/api/parent-conversations/${editingConv.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...getAuthHeaders(currentUser, teachers),
          },
          body: JSON.stringify(payload),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err.error || 'Update failed');
        }
        const updated = await res.json();
        onConversationsSync((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
        onLogActivity?.('تعديل قناة أو مجموعة شات', getConversationDisplay(updated).primary, `تم التحديث في قاعدة البيانات`);
        showToast('success', isAr ? 'تم تحديث بيانات المحادثة/المجموعة في قاعدة البيانات.' : 'Updated in DB.');
      } else {
        const res = await fetch('/api/parent-conversations', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getAuthHeaders(currentUser, teachers),
          },
          body: JSON.stringify({
            ...payload,
            createdById: currentUser.id,
            createdByName: currentUser.name,
            createdByRole: currentUser.role,
            sender: senderMeta.sender,
            senderId: senderMeta.senderId,
            senderName: senderMeta.senderName,
            senderRoleLabel: senderMeta.senderRoleLabel,
            initialMessage: convForm.initialMessage.trim(),
          }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err.error || 'Create failed');
        }
        const created = await res.json();
        onConversationsSync((prev) => [created, ...prev.filter((c) => c.id !== created.id)]);
        setChannelFilter('all');
        setSelectedId(created.id);
        setMobileShowChat(true);
        onLogActivity?.('إنشاء محادثة أو مجموعة شات', getConversationDisplay(created).primary, `قناة: ${getChannelTypeLabel(created.channelType, 'ar')}`);
        showToast('success', isAr ? 'تم إنشاء المحادثة وحفظها في قاعدة البيانات.' : 'Created and saved in DB.');
      }
      setIsConvModalOpen(false);
    } catch (err: any) {
      showToast('error', err?.message || 'Database error');
    }
  };

  const handleConfirmDeleteConversation = async () => {
    if (!deletingConv) return;
    try {
      const res = await fetch(`/api/parent-conversations/${deletingConv.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Delete failed');
      }
      onConversationsSync((prev) => prev.filter((c) => c.id !== deletingConv.id));
      onLogActivity?.('حذف محادثة أو مجموعة شات', getConversationDisplay(deletingConv).primary, 'تم الحذف نهائياً من قاعدة البيانات');
      showToast('success', isAr ? 'تم حذف المحادثة وكافة رسائلها من قاعدة البيانات.' : 'Conversation deleted.');
      setDeletingConv(null);
    } catch (err: any) {
      showToast('error', err?.message || 'Delete failed');
    }
  };

  const handleSaveEditedMessage = async () => {
    if (!editingMsg || !editingMsg.text.trim()) return;
    try {
      const res = await fetch(`/api/parent-messages/${editingMsg.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({ text: editingMsg.text.trim() }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to edit message');
      }
      const data = await res.json();
      if (data?.conversation) {
        onConversationsSync((prev) =>
          prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
        );
      }
      setEditingMsg(null);
      showToast('success', isAr ? 'تم تعديل الرسالة في قاعدة البيانات.' : 'Message updated.');
    } catch (err: any) {
      showToast('error', err?.message || 'Edit failed');
    }
  };

  const handleDeleteMessage = async (msgId: string) => {
    try {
      const res = await fetch(`/api/parent-messages/${msgId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to delete message');
      }
      const data = await res.json();
      if (data?.conversation) {
        onConversationsSync((prev) =>
          prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
        );
      }
      setDeletingMsgId(null);
      showToast('success', isAr ? 'تم حذف الرسالة من قاعدة البيانات.' : 'Message deleted.');
    } catch (err: any) {
      showToast('error', err?.message || 'Delete failed');
    }
  };

  const visibleStickers = useMemo(() => {
    if (stickerFilter === 'all') return STICKER_PACK;
    return STICKER_PACK.filter((s) => s.category === stickerFilter);
  }, [stickerFilter]);

  const statusBadge = (status?: string, warningCount = 0) => {
    if (warningCount > 0 || status === 'needs_followup') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 font-cairo">
          <AlertTriangle className="w-3 h-3" />
          {warningCount > 0
            ? isAr
              ? `${warningCount} إنذار`
              : `${warningCount} warning`
            : isAr
            ? 'يتطلب متابعة'
            : 'Follow-up'}
        </span>
      );
    }
    if (status === 'archived') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-cairo">
          {isAr ? 'مؤرشف' : 'Archived'}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 font-cairo">
        {isAr ? 'نشط' : 'Active'}
      </span>
    );
  };

  const canModifyConversation = (conv: ParentConversation) => {
    if (isAdminStaff) return true;
    if (!isTeacher) return false;
    return (
      conv.createdById === currentUser.id ||
      conv.teacherId === currentUser.id ||
      (matchedTeacher && conv.teacherId === matchedTeacher.id) ||
      conv.teacherName === currentUser.name
    );
  };

  const renderMessageContent = (msg: ChatMessage, isMine: boolean) => {
    const mType = msg.messageType || 'text';

    if (mType === 'sticker') {
      const def = STICKER_PACK.find((s) => s.key === msg.stickerKey);
      const gradient =
        def?.gradient || 'from-emerald-600 to-teal-700 text-white border-emerald-400';
      return (
        <div className="space-y-1.5 max-w-full">
          <div
            className={`bg-gradient-to-br ${gradient} p-3.5 rounded-2xl border shadow-md w-full min-w-0 sm:min-w-[210px] text-center`}
          >
            <div className="text-[10px] font-bold uppercase tracking-wider opacity-85 font-cairo mb-1">
              {def?.badgeText || msg.stickerCategory}
            </div>
            <div className="text-3xl mb-1">{def?.emoji || '🏷️'}</div>
            <div className="text-lg font-black font-cairo">
              {def ? (isAr ? def.label : def.labelEn) : msg.stickerLabel}
            </div>
            {msg.text && (
              <p className="text-xs opacity-95 font-tajawal mt-1.5 pt-1.5 border-t border-white/25">
                {msg.text}
              </p>
            )}
          </div>
        </div>
      );
    }

    if (mType === 'audio') {
      return (
        <div className="space-y-2 w-full min-w-[190px] sm:min-w-[260px] max-w-full">
          <div className="flex items-center gap-2 text-xs font-bold font-cairo">
            <Volume2 className="w-4 h-4 shrink-0" />
            <span>{isAr ? 'تسجيل صوتي' : 'Voice Note'}</span>
            {msg.durationSeconds ? (
              <span className="font-mono-numbers opacity-80">
                ({formatDuration(msg.durationSeconds)})
              </span>
            ) : null}
          </div>
          {msg.mediaUrl && (
            <audio controls src={msg.mediaUrl} className="w-full h-9 rounded-lg" />
          )}
          {msg.text && msg.text !== 'تسجيل صوتي مباشر' && msg.text !== 'Voice recording' && (
            <p className="text-xs font-tajawal opacity-90">{msg.text}</p>
          )}
        </div>
      );
    }

    if (mType === 'image') {
      return (
        <div className="space-y-2 max-w-[280px]">
          {msg.mediaUrl && (
            <button
              type="button"
              onClick={() =>
                setLightboxImage({ url: msg.mediaUrl!, title: msg.fileName || msg.text || 'صورة' })
              }
              className="block w-full overflow-hidden rounded-xl border border-black/10 dark:border-white/10 group relative"
            >
              <img
                src={msg.mediaUrl}
                alt={msg.fileName || 'Attachment'}
                className="w-full max-h-60 object-cover group-hover:scale-105 transition-transform"
              />
              <span className="absolute bottom-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-md font-cairo">
                {isAr ? 'عرض مكبّر' : 'Zoom'}
              </span>
            </button>
          )}
          {msg.text && <p className="text-sm font-tajawal whitespace-pre-wrap">{msg.text}</p>}
        </div>
      );
    }

    if (mType === 'video') {
      return (
        <div className="space-y-2 max-w-[300px]">
          {msg.mediaUrl && (
            <video
              controls
              src={msg.mediaUrl}
              className="w-full max-h-60 rounded-xl bg-black border border-black/15"
            />
          )}
          {msg.text && <p className="text-sm font-tajawal whitespace-pre-wrap">{msg.text}</p>}
        </div>
      );
    }

    if (mType === 'file') {
      return (
        <div className="space-y-2 w-full min-w-0 sm:min-w-[220px]">
          <div
            className={`flex items-center gap-3 p-2.5 rounded-xl border ${
              isMine
                ? 'bg-emerald-900/40 border-emerald-400/30 text-white'
                : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-500 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold truncate font-tajawal">
                {msg.fileName || (isAr ? 'ملف مرفق' : 'Attachment')}
              </div>
              {msg.fileSize && (
                <div className="text-[10px] opacity-75 font-mono-numbers">{msg.fileSize}</div>
              )}
            </div>
            {msg.mediaUrl && (
              <a
                href={msg.mediaUrl}
                download={msg.fileName || 'attachment'}
                className="p-2 rounded-lg bg-white/15 hover:bg-white/25 transition-colors"
                title={isAr ? 'تحميل الملف' : 'Download'}
              >
                <Download className="w-4 h-4" />
              </a>
            )}
          </div>
          {msg.text && <p className="text-sm font-tajawal whitespace-pre-wrap">{msg.text}</p>}
        </div>
      );
    }

    if (mType === 'call_log') {
      return (
        <div className="flex items-center gap-2.5 text-xs font-bold font-cairo">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
            <PhoneCall className="w-4 h-4" />
          </div>
          <span>{msg.text}</span>
        </div>
      );
    }

    return (
      <p className="text-sm leading-relaxed font-tajawal whitespace-pre-wrap break-words">
        {msg.text}
      </p>
    );
  };

  const filteredDirectoryMembers = useMemo(() => {
    const q = memberSearchTerm.trim().toLowerCase();
    return selectableDirectory.filter(
      (item) =>
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q)
    );
  }, [selectableDirectory, memberSearchTerm]);

  const activeSenderMeta = getCurrentSenderMeta();

  return (
    <div className="space-y-4">
      <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />

      {/* Top Section Header + Quick Creation Controls */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold font-cairo text-slate-900 dark:text-white">
                {isAr ? 'منظومة الشات والتواصل المنظّم والمجموعات' : 'Organized Chat & Groups Hub'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal">
                {isAr
                  ? 'قنوات منظمة: طالب ↔ معلم · ولي أمر ↔ معلم · معلم ↔ إدارة · مجموعات خاصة وعامة بتزامن فوري وقاعدة بيانات سحابية'
                  : 'Structured channels: Student ↔ Teacher · Parent ↔ Teacher · Teacher ↔ Admin · Private & Public Groups'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Optional Admin Sender Role Switcher for testing or replying */}
            {isAdminStaff && (
              <div className="inline-flex rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-1">
                {[
                  { id: 'self', label: isAr ? 'بصفتي (الإدارة)' : 'Admin' },
                  { id: 'teacher', label: isAr ? 'المعلم' : 'Teacher' },
                  { id: 'parent', label: isAr ? 'ولي الأمر' : 'Parent' },
                  { id: 'student', label: isAr ? 'الطالب' : 'Student' },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setAdminReplyMode(opt.id as any)}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold font-cairo transition-colors ${
                      adminReplyMode === opt.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={refreshFromDb}
              disabled={isLoading}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-bold font-cairo text-slate-700 dark:text-slate-200"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              {isAr ? 'تحديث' : 'Refresh'}
            </button>

            {canManageGroupsAndEdit ? (
              <>
                <button
                  type="button"
                  onClick={() => openCreateModal('private_group')}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold font-cairo shadow-xs"
                >
                  <Lock className="w-3.5 h-3.5" />
                  {isAr ? 'مجموعة خاصة' : 'Private Group'}
                </button>
                <button
                  type="button"
                  onClick={() => openCreateModal('public_group')}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold font-cairo shadow-xs"
                >
                  <Globe className="w-3.5 h-3.5" />
                  {isAr ? 'مجموعة عامة' : 'Public Group'}
                </button>
                <button
                  type="button"
                  onClick={() => openCreateModal()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold font-cairo shadow-md shadow-emerald-600/20"
                >
                  <Plus className="w-4 h-4" />
                  {isAr ? 'محادثة مباشرة' : 'Direct Chat'}
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => openCreateModal()}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold font-cairo shadow-md shadow-emerald-600/20"
              >
                <Plus className="w-4 h-4" />
                {isStudent
                  ? isAr
                    ? 'بدء محادثة مع المعلم'
                    : 'Chat with Teacher'
                  : isAr
                  ? 'مراسلة المعلم'
                  : 'Message Teacher'}
              </button>
            )}
          </div>
        </div>

        {/* Organized 5-Channel Tabs Bar */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1 border-t border-slate-100 dark:border-slate-800">
          {availableChannelTabs.map((tab) => {
            const count = channelCounts[tab.key] || 0;
            const active = channelFilter === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setChannelFilter(tab.key)}
                className={`shrink-0 inline-flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold font-cairo transition-all border ${
                  active
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono-numbers ${
                    active
                      ? 'bg-white/20 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Inline Status Toast */}
      {toast && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs sm:text-sm font-bold font-cairo flex items-center justify-between gap-3 ${
            toast.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
              : toast.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-sky-50 dark:bg-sky-950/50 border-sky-200 dark:border-sky-800 text-sky-800 dark:text-sky-200'
          }`}
        >
          <span>{toast.message}</span>
          <button type="button" onClick={() => setToast(null)} className="p-1 opacity-75 hover:opacity-100">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Active WebRTC Call Banner */}
      {(callState === 'calling' || callState === 'connected') && (
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white rounded-2xl p-4 shadow-lg border border-emerald-500/40 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-emerald-500/25 border border-emerald-400 flex items-center justify-center animate-pulse">
              <PhoneCall className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black font-cairo">{callPeerName}</span>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500 text-slate-950 font-cairo">
                  {callState === 'calling'
                    ? isAr
                      ? 'جاري الرنين...'
                      : 'Ringing...'
                    : isAr
                    ? 'متصل صوتياً الآن'
                    : 'Live Audio Connected'}
                </span>
              </div>
              <div className="text-xs text-emerald-200 font-mono-numbers mt-0.5">
                {callState === 'connected'
                  ? `${isAr ? 'مدة المكالمة:' : 'Duration:'} ${formatDuration(callDuration)}`
                  : isAr
                  ? 'في انتظار رد الطرف الآخر عبر WebRTC...'
                  : 'Waiting for peer to answer via WebRTC...'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleCallMute}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold font-cairo transition-colors ${
                isMicMuted ? 'bg-amber-500 text-slate-950' : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              {isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              {isMicMuted ? (isAr ? 'إلغاء الكتم' : 'Unmute') : isAr ? 'كتم المايك' : 'Mute'}
            </button>
            <button
              type="button"
              onClick={handleEndCall}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold font-cairo shadow-md"
            >
              <PhoneOff className="w-4 h-4" />
              {isAr ? 'إنهاء المكالمة' : 'End Call'}
            </button>
          </div>
        </div>
      )}

      {/* Main Two-Column Chat Workspace */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm grid grid-cols-1 lg:grid-cols-12 h-[calc(100dvh-13rem)] min-h-[520px] lg:h-[calc(100vh-16rem)]">
        {/* Sidebar: Conversations & Groups List */}
        <div
          className={`${
            mobileShowChat && activeConv ? 'hidden lg:flex' : 'flex'
          } lg:col-span-4 border-b lg:border-b-0 lg:border-e border-slate-200 dark:border-slate-800 flex-col bg-slate-50/70 dark:bg-slate-950/40 min-h-0`}
        >
          <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 space-y-2.5 bg-white dark:bg-slate-900">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={isAr ? 'بحث باسم المحادثة، المعلم، الطالب، المجموعة...' : 'Search chats, teachers, groups...'}
                className="w-full ps-9 pe-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-tajawal focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {[
                { key: 'all', label: isAr ? `الكل (${filteredConvs.length})` : `All (${filteredConvs.length})` },
                { key: 'active', label: isAr ? 'نشط' : 'Active' },
                { key: 'warnings', label: isAr ? 'إنذارات ومتابعة' : 'Warnings' },
                { key: 'archived', label: isAr ? 'مؤرشف' : 'Archived' },
              ].map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setStatusFilter(f.key as any)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold font-cairo transition-colors ${
                    statusFilter === f.key
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {filteredConvs.length === 0 ? (
              <div className="p-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-200 dark:bg-slate-800 text-slate-500 mx-auto flex items-center justify-center">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold font-cairo text-slate-700 dark:text-slate-300">
                  {roleVisibleConvs.length === 0
                    ? isAr
                      ? 'لا توجد محادثات أو مجموعات في هذا القسم بعد'
                      : 'No conversations in this section yet'
                    : isAr
                    ? 'لا توجد نتائج مطابقة للبحث'
                    : 'No matching conversations'}
                </p>
                <p className="text-xs text-slate-500 font-tajawal">
                  {isStudent
                    ? isAr
                      ? 'يمكنك بدء محادثة مباشرة مع معلمك أو المشاركة في المجموعات المضافة لك.'
                      : 'Start a direct chat with your teacher or participate in joined groups.'
                    : isParent
                    ? isAr
                      ? 'يمكنك بدء محادثة مباشرة مع المعلم لمتابعة مستوى الطالب.'
                      : 'Start a direct chat with a teacher to follow up.'
                    : isAr
                    ? 'ابدأ محادثة ثنائية (طالب/ولي أمر/معلم/إدارة) أو أنشئ مجموعة خاصة أو عامة.'
                    : 'Start a direct chat or create a private/public group.'}
                </p>
                <button
                  type="button"
                  onClick={() => openCreateModal()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold font-cairo"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {isAr ? 'بدء محادثة جديدة' : 'Start New Chat'}
                </button>
              </div>
            ) : (
              filteredConvs.map((conv) => {
                const isSelected = conv.id === activeConv?.id;
                const ch = conv.channelType || 'parent_teacher';
                const visual = channelVisualMeta(ch, isAr);
                const display = getConversationDisplay(conv);
                const ChIcon = visual.Icon;
                const canMod = canModifyConversation(conv);

                return (
                  <div
                    key={conv.id}
                    onClick={() => {
                      setSelectedId(conv.id);
                      setMobileShowChat(true);
                    }}
                    className={`p-3.5 cursor-pointer transition-all group ${
                      isSelected
                        ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-s-4 border-emerald-600'
                        : 'hover:bg-white dark:hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-10 h-10 rounded-full bg-gradient-to-br ${visual.avatarGradient} text-white flex items-center justify-center font-cairo font-bold text-sm shrink-0 shadow-sm`}
                      >
                        <ChIcon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white font-cairo truncate">
                            {display.primary}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-mono-numbers shrink-0">
                            {conv.lastTimestamp || ''}
                          </span>
                        </div>

                        <div className="flex items-center justify-between gap-1.5 mt-1 flex-wrap">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold font-cairo ${visual.badgeClass}`}
                          >
                            {visual.label}
                          </span>
                          {statusBadge(conv.status, conv.warningCount)}
                        </div>

                        <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 font-tajawal truncate mt-1">
                          {display.secondary}
                        </div>

                        <div className="flex items-center justify-between gap-2 mt-1.5">
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate font-tajawal">
                            {conv.lastMessage || (isAr ? 'لا توجد رسائل بعد...' : 'No messages yet...')}
                          </p>
                          {conv.unreadCount > 0 && (
                            <span className="bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full font-mono-numbers shrink-0">
                              {conv.unreadCount}
                            </span>
                          )}
                        </div>

                        {/* Quick inline actions */}
                        <div className="flex items-center gap-1 mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDetailsConv(conv);
                              setDetailsTab('overview');
                            }}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-sky-100 hover:text-sky-700 text-[10px] font-bold font-cairo"
                          >
                            <Eye className="w-3 h-3" />
                            {isAr ? 'التفاصيل' : 'Details'}
                          </button>
                          {canMod && (
                            <>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEditModal(conv);
                                }}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-amber-100 hover:text-amber-700 text-[10px] font-bold font-cairo"
                              >
                                <Edit3 className="w-3 h-3" />
                                {isAr ? 'تعديل' : 'Edit'}
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeletingConv(conv);
                                }}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-rose-100 hover:text-rose-700 text-[10px] font-bold font-cairo"
                              >
                                <Trash2 className="w-3 h-3" />
                                {isAr ? 'حذف' : 'Delete'}
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Main Chat Area */}
        <div
          className={`${
            mobileShowChat && activeConv ? 'flex' : 'hidden lg:flex'
          } lg:col-span-8 flex-col bg-slate-50/40 dark:bg-slate-900 min-h-0`}
        >
          {activeConv ? (
            <>
              {(() => {
                const ch = activeConv.channelType || 'parent_teacher';
                const visual = channelVisualMeta(ch, isAr);
                const display = getConversationDisplay(activeConv);
                const ChIcon = visual.Icon;
                const canMod = canModifyConversation(activeConv);
                return (
                  <div className="p-3 sm:p-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-2.5 sm:gap-3">
                    <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                      <button
                        type="button"
                        onClick={() => setMobileShowChat(false)}
                        className="lg:hidden min-w-[36px] min-h-[36px] flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 shrink-0"
                        title={isAr ? 'العودة لقائمة المحادثات' : 'Back'}
                      >
                        <ArrowRight className={`w-4 h-4 ${isAr ? '' : 'rotate-180'}`} />
                      </button>
                      <div
                        className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-gradient-to-br ${visual.avatarGradient} text-white flex items-center justify-center shrink-0 shadow-xs`}
                      >
                        <ChIcon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-bold text-slate-900 dark:text-white font-cairo text-sm sm:text-base truncate">
                            {display.primary}
                          </h3>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold font-cairo ${visual.badgeClass}`}
                          >
                            {visual.label}
                          </span>
                          {statusBadge(activeConv.status, activeConv.warningCount)}
                        </div>
                        <div className="text-xs text-slate-500 font-tajawal flex items-center gap-2 flex-wrap mt-0.5">
                          <span>{display.secondary}</span>
                          {activeConv.parentPhone && ch === 'parent_teacher' && (
                            <span className="font-mono-numbers" dir="ltr">
                              · {activeConv.parentPhone}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => {
                          setDetailsConv(activeConv);
                          setDetailsTab('overview');
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold font-cairo"
                      >
                        <Eye className="w-3.5 h-3.5 text-sky-600" />
                        {isAr ? 'التفاصيل' : 'Details'}
                      </button>

                      {canMod && (
                        <button
                          type="button"
                          onClick={() => openEditModal(activeConv)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold font-cairo"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-amber-600" />
                          {ch === 'private_group'
                            ? isAr
                              ? 'إدارة الأعضاء'
                              : 'Members'
                            : isAr
                            ? 'تعديل'
                            : 'Edit'}
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={handleStartVoiceCall}
                        disabled={callState !== 'idle'}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold font-cairo shadow-sm"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        {isAr ? 'اتصال صوتي' : 'Voice Call'}
                      </button>
                    </div>
                  </div>
                );
              })()}

              {/* Messages Feed */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
                {activeConv.messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center py-12 space-y-2">
                    <MessageSquare className="w-10 h-10 text-slate-300 dark:text-slate-700" />
                    <p className="text-sm font-bold font-cairo text-slate-600 dark:text-slate-400">
                      {isAr
                        ? 'بدأت المحادثة للتو — أرسل أول رسالة أو ملصق أو تسجيل صوتي'
                        : 'Conversation ready — send the first message'}
                    </p>
                  </div>
                ) : (
                  activeConv.messages.map((msg) => {
                    const isMine =
                      (msg.senderId && msg.senderId === activeSenderMeta.senderId) ||
                      (msg.sender === activeSenderMeta.sender &&
                        msg.senderName === activeSenderMeta.senderName) ||
                      (!msg.senderId &&
                        (isParent
                          ? msg.sender === 'parent'
                          : isStudent
                          ? msg.sender === 'student' || msg.sender === 'female_student'
                          : msg.sender === activeSenderMeta.sender));
                    const isSticker = msg.messageType === 'sticker';
                    const roleBadge =
                      msg.senderRoleLabel || getRoleBadgeLabel(msg.sender, language);
                    const canModMsg = isAdminStaff || isTeacher;

                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMine ? 'items-end' : 'items-start'} group`}
                      >
                        <div
                          className={`relative max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 shadow-sm ${
                            isSticker
                              ? 'bg-transparent p-0 shadow-none'
                              : isMine
                              ? 'bg-emerald-700 text-white rounded-ee-none'
                              : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-es-none'
                          }`}
                        >
                          <div
                            className={`text-[10px] font-bold mb-1.5 flex items-center justify-between gap-3 font-cairo ${
                              isSticker
                                ? 'text-slate-500 dark:text-slate-400 px-1'
                                : isMine
                                ? 'text-emerald-100'
                                : 'text-emerald-700 dark:text-emerald-400'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span>{msg.senderName}</span>
                              <span
                                className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                  isMine && !isSticker
                                    ? 'bg-white/20 text-white'
                                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-200'
                                }`}
                              >
                                {roleBadge}
                              </span>
                            </div>

                            {canModMsg && (
                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                {(msg.messageType === 'text' || !msg.messageType) && (
                                  <button
                                    type="button"
                                    onClick={() => setEditingMsg({ id: msg.id, text: msg.text })}
                                    className="p-1 rounded hover:bg-black/15"
                                    title={isAr ? 'تعديل الرسالة' : 'Edit'}
                                  >
                                    <Edit3 className="w-3 h-3" />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => setDeletingMsgId(msg.id)}
                                  className="p-1 rounded hover:bg-rose-500/20 text-rose-400"
                                  title={isAr ? 'حذف الرسالة' : 'Delete'}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                          </div>

                          {renderMessageContent(msg, isMine)}

                          <div
                            className={`flex items-center justify-end gap-1 mt-1.5 text-[10px] font-mono-numbers ${
                              isSticker
                                ? 'text-slate-400 px-1'
                                : isMine
                                ? 'text-emerald-200'
                                : 'text-slate-400'
                            }`}
                          >
                            <span>{msg.timestamp}</span>
                            {isMine &&
                              (msg.read ? (
                                <CheckCheck className="w-3.5 h-3.5" />
                              ) : (
                                <Check className="w-3.5 h-3.5" />
                              ))}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}

                {remoteTyping && remoteTyping.conversationId === activeConv.id && (
                  <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-cairo px-2">
                    <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    <span>
                      {isAr
                        ? `${remoteTyping.senderName} يكتب الآن...`
                        : `${remoteTyping.senderName} is typing...`}
                    </span>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Drawers above Composer */}
              <div className="relative bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
                {showEmojiPicker && (
                  <div className="p-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/70">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1 flex-wrap">
                        {EMOJI_CATEGORIES.map((cat) => (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={() => setActiveEmojiTab(cat.id)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold font-cairo ${
                              activeEmojiTab === cat.id
                                ? 'bg-emerald-600 text-white'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {isAr ? cat.labelAr : cat.labelEn}
                          </button>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowEmojiPicker(false)}
                        className="p-1 text-slate-400 hover:text-slate-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-6 sm:grid-cols-10 md:grid-cols-12 gap-1.5">
                      {EMOJI_CATEGORIES.find((c) => c.id === activeEmojiTab)?.emojis.map((em) => (
                        <button
                          key={em}
                          type="button"
                          onClick={() => setMessageText((prev) => `${prev}${em}`)}
                          className="text-xl p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-transform hover:scale-110"
                        >
                          {em}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {showStickerPicker && (
                  <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/70 space-y-3 max-h-80 overflow-y-auto">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {[
                          { key: 'all', label: isAr ? 'كل الملصقات' : 'All Stickers' },
                          { key: 'rating', label: isAr ? 'التقييمات' : 'Ratings' },
                          { key: 'congrats', label: isAr ? 'مبروك التميز' : 'Excellence' },
                          { key: 'warning', label: isAr ? 'الإنذارات' : 'Warnings' },
                          { key: 'complaint', label: isAr ? 'شكاوى' : 'Complaints' },
                          { key: 'suggestion', label: isAr ? 'اقتراحات' : 'Suggestions' },
                        ].map((tab) => (
                          <button
                            key={tab.key}
                            type="button"
                            onClick={() => setStickerFilter(tab.key as any)}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold font-cairo ${
                              stickerFilter === tab.key
                                ? 'bg-emerald-600 text-white'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowStickerPicker(false)}
                        className="p-1 text-slate-400 hover:text-slate-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <input
                      type="text"
                      value={stickerCustomNote}
                      onChange={(e) => setStickerCustomNote(e.target.value)}
                      placeholder={
                        isAr
                          ? 'ملاحظة مرفقة اختيارية مع الاستيكر (تظهر أسفل الاستيكر)...'
                          : 'Optional note attached to sticker...'
                      }
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-tajawal outline-none"
                    />

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                      {visibleStickers.map((stk) => (
                        <button
                          key={stk.key}
                          type="button"
                          onClick={() => handleSendSticker(stk)}
                          className={`bg-gradient-to-br ${stk.gradient} p-3 rounded-xl border text-center shadow-sm hover:scale-[1.03] active:scale-95 transition-transform`}
                        >
                          <div className="text-2xl mb-1">{stk.emoji}</div>
                          <div className="font-black text-xs font-cairo">
                            {isAr ? stk.label : stk.labelEn}
                          </div>
                          <div className="text-[10px] opacity-85 font-tajawal line-clamp-1 mt-0.5">
                            {stk.badgeText}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {pendingAttachment && (
                  <div className="p-3 border-b border-slate-200 dark:border-slate-800 bg-emerald-50/70 dark:bg-emerald-950/30 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {pendingAttachment.messageType === 'image' ? (
                        <img
                          src={pendingAttachment.mediaUrl}
                          alt={pendingAttachment.fileName}
                          className="w-12 h-12 rounded-lg object-cover border border-emerald-300"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                          {pendingAttachment.messageType === 'video' ? (
                            <Film className="w-5 h-5" />
                          ) : pendingAttachment.messageType === 'audio' ? (
                            <Volume2 className="w-5 h-5" />
                          ) : (
                            <FileText className="w-5 h-5" />
                          )}
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-bold font-cairo text-slate-900 dark:text-white truncate">
                          {pendingAttachment.fileName}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono-numbers">
                          {pendingAttachment.fileSize} · {pendingAttachment.messageType.toUpperCase()}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setPendingAttachment(null)}
                      className="p-1.5 rounded-lg bg-rose-100 text-rose-700 hover:bg-rose-200 text-xs font-bold"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {isRecording ? (
                  <div className="p-3.5 flex items-center justify-between gap-3 bg-rose-50 dark:bg-rose-950/40">
                    <div className="flex items-center gap-3">
                      <span className="w-3.5 h-3.5 rounded-full bg-rose-600 animate-ping" />
                      <span className="text-sm font-bold font-cairo text-rose-700 dark:text-rose-300">
                        {isAr ? 'جاري تسجيل ريكورد صوتي...' : 'Recording voice note...'}
                      </span>
                      <span className="text-sm font-black font-mono-numbers text-rose-800 dark:text-rose-200">
                        {formatDuration(recordingSeconds)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleCancelVoiceRecord}
                        className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo text-slate-700 dark:text-slate-200"
                      >
                        {isAr ? 'إلغاء' : 'Cancel'}
                      </button>
                      <button
                        type="button"
                        onClick={handleStopAndSendVoiceRecord}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold font-cairo shadow-sm"
                      >
                        <Square className="w-3.5 h-3.5 fill-current" />
                        {isAr ? 'إيقاف وإرسال الصوت' : 'Stop & Send'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSend} className="p-3 flex flex-wrap items-center gap-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                      onChange={handleFileSelected}
                      className="hidden"
                    />

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setShowEmojiPicker((prev) => !prev);
                          setShowStickerPicker(false);
                        }}
                        className={`p-2.5 rounded-xl border transition-colors ${
                          showEmojiPicker
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                        }`}
                        title={isAr ? 'إيموشن' : 'Emoji'}
                      >
                        <Smile className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowStickerPicker((prev) => !prev);
                          setShowEmojiPicker(false);
                        }}
                        className={`inline-flex items-center gap-1 px-2.5 py-2.5 rounded-xl border text-xs font-bold font-cairo transition-colors ${
                          showStickerPicker
                            ? 'bg-amber-500 text-slate-950 border-amber-500'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100'
                        }`}
                        title={isAr ? 'استيكرات وتقييمات' : 'Stickers'}
                      >
                        <Sticker className="w-4 h-4" />
                        <span className="hidden sm:inline">{isAr ? 'استيكرات' : 'Stickers'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                        title={isAr ? 'إرسال صور أو فيديو أو ملفات' : 'Attach media or file'}
                      >
                        <Paperclip className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={handleStartVoiceRecord}
                        className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        title={isAr ? 'تسجيل ريكورد صوتي' : 'Record Voice Note'}
                      >
                        <Mic className="w-4 h-4" />
                      </button>
                    </div>

                    <input
                      type="text"
                      value={messageText}
                      onChange={(e) => {
                        setMessageText(e.target.value);
                        if (activeConv) {
                          realtimeSync.sendParentTyping(
                            activeConv.id,
                            activeSenderMeta.senderName,
                            activeSenderMeta.sender,
                            e.target.value.trim().length > 0
                          );
                        }
                      }}
                      placeholder={
                        isAr
                          ? `اكتب رسالتك بصفتك (${activeSenderMeta.senderName} - ${activeSenderMeta.senderRoleLabel})...`
                          : `Message as ${activeSenderMeta.senderName}...`
                      }
                      className="flex-1 min-w-[160px] px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal focus:ring-2 focus:ring-emerald-500 outline-none"
                    />

                    <button
                      type="submit"
                      disabled={isSending || (!messageText.trim() && !pendingAttachment)}
                      className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-5 py-2.5 rounded-xl font-bold text-sm font-cairo flex items-center gap-2 shadow-sm transition-colors"
                    >
                      <Send className="w-4 h-4" />
                      <span className="hidden sm:inline">{isAr ? 'إرسال' : 'Send'}</span>
                    </button>
                  </form>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 flex items-center justify-center">
                <MessageSquare className="w-8 h-8" />
              </div>
              <div className="max-w-md space-y-1.5">
                <h3 className="text-lg font-extrabold font-cairo text-slate-900 dark:text-white">
                  {isAr ? 'اختر محادثة أو أنشئ قناة تواصل جديدة' : 'Select or create a conversation'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 font-tajawal">
                  {isAr
                    ? 'اختر من التبويبات المنظمة: طالب ↔ معلم، ولي أمر ↔ معلم، معلم ↔ إدارة، مجموعات خاصة، أو مجموعات عامة.'
                    : 'Choose from Student ↔ Teacher, Parent ↔ Teacher, Teacher ↔ Admin, Private Groups, or Public Groups.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => openCreateModal()}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm font-cairo shadow-md"
              >
                <Plus className="w-4 h-4" />
                {isAr ? 'بدء محادثة أو مجموعة جديدة' : 'New Chat / Group'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Incoming WebRTC Voice Call Modal */}
      {callState === 'incoming' && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500 p-6 max-w-sm w-full text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 mx-auto flex items-center justify-center animate-bounce">
              <PhoneIncoming className="w-8 h-8" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 font-cairo">
                {isAr ? 'مكالمة صوتية مباشرة واردة (WebRTC)' : 'Incoming Live Voice Call'}
              </span>
              <h3 className="text-xl font-black font-cairo text-slate-900 dark:text-white mt-1">
                {callPeerName}
              </h3>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleRejectIncomingCall}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm font-cairo"
              >
                <PhoneOff className="w-4 h-4" />
                {isAr ? 'رفض' : 'Decline'}
              </button>
              <button
                type="button"
                onClick={handleAcceptIncomingCall}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm font-cairo"
              >
                <PhoneCall className="w-4 h-4" />
                {isAr ? 'رد الآن' : 'Accept'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit Conversation & Group Modal */}
      {isConvModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-extrabold font-cairo text-slate-900 dark:text-white">
                {editingConv
                  ? isAr
                    ? 'تعديل بيانات المحادثة / المجموعة'
                    : 'Edit Conversation / Group'
                  : isAr
                  ? 'فتح قناة محادثة أو إنشاء مجموعة جديدة'
                  : 'Create Organized Chat or Group'}
              </h3>
              <button
                type="button"
                onClick={() => setIsConvModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveConversation} className="space-y-4">
              {/* Channel Type Selector */}
              {!editingConv && allowedChannelTypesForCreate.length > 1 && (
                <div>
                  <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-2">
                    {isAr ? 'نوع القناة أو المجموعة *' : 'Channel / Group Type *'}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {allowedChannelTypesForCreate.map((ch) => {
                      const meta = channelVisualMeta(ch, isAr);
                      const ChIcon = meta.Icon;
                      const isSel = convForm.channelType === ch;
                      return (
                        <button
                          key={ch}
                          type="button"
                          onClick={() => applyChannelDefaults(ch)}
                          className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold font-cairo transition-all ${
                            isSel
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <ChIcon className="w-4 h-4 shrink-0" />
                          <span className="truncate">{meta.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Group Title / Description / Audience for Private & Public Groups */}
              {(convForm.channelType === 'private_group' || convForm.channelType === 'public_group') && (
                <div className="space-y-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                        {convForm.channelType === 'private_group'
                          ? isAr
                            ? 'اسم المجموعة الخاصة *'
                            : 'Private Group Name *'
                          : isAr
                          ? 'اسم المجموعة العامة *'
                          : 'Public Group Name *'}
                      </label>
                      <input
                        required
                        type="text"
                        value={convForm.title}
                        onChange={(e) => setConvForm({ ...convForm, title: e.target.value })}
                        placeholder={
                          convForm.channelType === 'private_group'
                            ? isAr
                              ? 'مثال: مجموعة المتفوقين — الصف الثالث'
                              : 'Top Students Group'
                            : isAr
                            ? 'مثال: الملتقى العام للرياضيات والعلوم'
                            : 'General Math & Science Forum'
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      />
                    </div>

                    {convForm.channelType === 'public_group' && (
                      <div>
                        <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                          {isAr ? 'الجمهور المستهدف للمجموعة العامة' : 'Target Audience'}
                        </label>
                        <select
                          value={convForm.targetAudience}
                          onChange={(e) =>
                            setConvForm({ ...convForm, targetAudience: e.target.value as ChatGroupAudience })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                        >
                          <option value="all">{isAr ? 'الجميع (طلاب وأولياء أمور ومعلمين وإدارة)' : 'Everyone'}</option>
                          <option value="students">{isAr ? 'الطلاب والطالبات فقط' : 'Students Only'}</option>
                          <option value="parents">{isAr ? 'أولياء الأمور فقط' : 'Parents Only'}</option>
                          <option value="teachers">{isAr ? 'المعلمون فقط' : 'Teachers Only'}</option>
                        </select>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'وصف المجموعة / الهدف منها' : 'Group Description'}
                    </label>
                    <input
                      type="text"
                      value={convForm.description}
                      onChange={(e) => setConvForm({ ...convForm, description: e.target.value })}
                      placeholder={isAr ? 'وصف مختصر لأعضاء المجموعة...' : 'Short group description...'}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                    />
                  </div>

                  {convForm.channelType === 'private_group' && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <label className="text-xs font-bold font-cairo text-slate-700 dark:text-slate-300">
                          {isAr
                            ? `تحديد أعضاء المجموعة الخاصة (${convForm.memberIds.length} محدد)`
                            : `Select Private Group Members (${convForm.memberIds.length})`}
                        </label>
                        <input
                          type="text"
                          value={memberSearchTerm}
                          onChange={(e) => setMemberSearchTerm(e.target.value)}
                          placeholder={isAr ? 'بحث عن عضو...' : 'Filter members...'}
                          className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-tajawal w-44"
                        />
                      </div>
                      <div className="max-h-44 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-1.5 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                        {filteredDirectoryMembers.map((item) => {
                          const checked = convForm.memberIds.includes(item.id);
                          return (
                            <label
                              key={item.id}
                              className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer text-xs border transition-colors ${
                                checked
                                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 text-emerald-900 dark:text-emerald-200'
                                  : 'bg-slate-50/70 dark:bg-slate-800/40 border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => toggleGroupMember(item)}
                                className="rounded accent-emerald-600"
                              />
                              <div className="min-w-0 flex-1">
                                <div className="font-bold font-cairo truncate">{item.name}</div>
                                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                                  {item.subtitle}
                                </div>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Student ↔ Teacher OR Parent ↔ Teacher fields */}
              {(convForm.channelType === 'student_teacher' || convForm.channelType === 'parent_teacher') && (
                <div className="space-y-3">
                  {/* Teacher picker (unless currentUser is already teacher) */}
                  {!isTeacher && teachers.length > 0 && (
                    <div>
                      <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'اختيار المعلم من قاعدة البيانات *' : 'Select Teacher *'}
                      </label>
                      <select
                        value={convForm.teacherId}
                        onChange={(e) => {
                          const t = teachers.find((x) => x.id === e.target.value);
                          if (t) {
                            setConvForm((prev) => ({
                              ...prev,
                              teacherId: t.id,
                              teacherName: t.name,
                            }));
                          }
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      >
                        <option value="">{isAr ? '-- اختر المعلم --' : '-- Select Teacher --'}</option>
                        {teachers.map((t) => (
                          <option key={t.id} value={t.id}>
                            {t.name} ({t.specialty})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Student picker (unless currentUser is student) */}
                  {!isStudent && students.length > 0 && (
                    <div>
                      <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'ربط بطالب مسجل في قاعدة البيانات' : 'Select DB Student'}
                      </label>
                      <select
                        value={convForm.studentId}
                        onChange={(e) => {
                          const stu = students.find((s) => s.id === e.target.value);
                          if (stu) {
                            setConvForm((prev) => ({
                              ...prev,
                              studentId: stu.id,
                              studentName: stu.name,
                              studentGrade: stu.grade,
                              parentName: isParent ? prev.parentName : stu.parentName || prev.parentName,
                              parentPhone: stu.parentPhone || prev.parentPhone,
                              parentEmail: stu.parentEmail || prev.parentEmail,
                            }));
                          } else {
                            setConvForm((prev) => ({ ...prev, studentId: '' }));
                          }
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      >
                        <option value="">{isAr ? '-- إدخال يدوي / اختيار طالب --' : '-- Manual / Select --'}</option>
                        {students.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.code}) — {s.grade}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'اسم الطالب *' : 'Student Name *'}
                      </label>
                      <input
                        required
                        readOnly={isStudent}
                        type="text"
                        value={convForm.studentName}
                        onChange={(e) => setConvForm({ ...convForm, studentName: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'اسم المعلم *' : 'Teacher Name *'}
                      </label>
                      <input
                        required
                        readOnly={isTeacher}
                        type="text"
                        value={convForm.teacherName}
                        onChange={(e) => setConvForm({ ...convForm, teacherName: e.target.value })}
                        placeholder={isAr ? 'مثال: أ. أحمد السالم' : 'Teacher Name'}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      />
                    </div>
                  </div>

                  {convForm.channelType === 'parent_teacher' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                          {isAr ? 'اسم ولي الأمر *' : 'Parent Name *'}
                        </label>
                        <input
                          required
                          readOnly={isParent}
                          type="text"
                          value={convForm.parentName}
                          onChange={(e) => setConvForm({ ...convForm, parentName: e.target.value })}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                          {isAr ? 'رقم الجوال' : 'Phone'}
                        </label>
                        <input
                          type="text"
                          value={convForm.parentPhone}
                          onChange={(e) => setConvForm({ ...convForm, parentPhone: e.target.value })}
                          placeholder="+966 5X XXX XXXX"
                          dir="ltr"
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-mono-numbers"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Teacher ↔ Admin fields */}
              {convForm.channelType === 'teacher_admin' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'المعلم *' : 'Teacher *'}
                    </label>
                    {isAdminStaff && teachers.length > 0 ? (
                      <select
                        value={convForm.teacherId}
                        onChange={(e) => {
                          const t = teachers.find((x) => x.id === e.target.value);
                          if (t) {
                            setConvForm((prev) => ({ ...prev, teacherId: t.id, teacherName: t.name }));
                          }
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      >
                        <option value="">{isAr ? '-- اختر المعلم --' : '-- Select Teacher --'}</option>
                        {teachers.map((t) => (
                          <option key={t.id} value={t.id}>
                            {t.name} ({t.specialty})
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        required
                        readOnly={isTeacher}
                        type="text"
                        value={convForm.teacherName}
                        onChange={(e) => setConvForm({ ...convForm, teacherName: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      />
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'مسؤول الإدارة' : 'Admin Contact'}
                    </label>
                    {adminDirectory.length > 0 && !isAdminStaff ? (
                      <select
                        value={convForm.adminName}
                        onChange={(e) => setConvForm({ ...convForm, adminName: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      >
                        <option value="الإدارة العامة">{isAr ? 'الإدارة العامة' : 'General Administration'}</option>
                        {adminDirectory.map((a) => (
                          <option key={a.id} value={a.name}>
                            {a.name} ({a.roleTitle || getRoleBadgeLabel(a.role, language)})
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={convForm.adminName}
                        onChange={(e) => setConvForm({ ...convForm, adminName: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                      />
                    )}
                  </div>
                </div>
              )}

              {!editingConv && (
                <div>
                  <label className="block text-xs font-bold font-cairo text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'رسالة افتتاحية (اختيارية)' : 'Initial Message (optional)'}
                  </label>
                  <input
                    type="text"
                    value={convForm.initialMessage}
                    onChange={(e) => setConvForm({ ...convForm, initialMessage: e.target.value })}
                    placeholder={isAr ? 'السلام عليكم، ...' : 'Hello...'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsConvModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold font-cairo"
                >
                  {editingConv ? (isAr ? 'حفظ التعديلات' : 'Save Changes') : isAr ? 'إنشاء وحفظ' : 'Create & Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Conversation Confirmation Modal */}
      {deletingConv && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-800 max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/60 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-extrabold font-cairo">
                {isAr ? 'تأكيد حذف المحادثة / المجموعة' : 'Confirm Delete'}
              </h3>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 font-tajawal">
              {isAr
                ? `هل أنت متأكد من حذف (${getConversationDisplay(deletingConv).primary}) وكافة رسائلها وملفاتها من قاعدة البيانات؟ لا يمكن التراجع عن هذا الإجراء.`
                : `Delete ${getConversationDisplay(deletingConv).primary} and all its messages permanently from DB?`}
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeletingConv(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo"
              >
                {isAr ? 'تراجع' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteConversation}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold font-cairo"
              >
                {isAr ? 'نعم، احذف نهائياً' : 'Delete Permanently'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Single Message Modal */}
      {editingMsg && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-5 shadow-2xl space-y-4">
            <h3 className="text-base font-extrabold font-cairo text-slate-900 dark:text-white">
              {isAr ? 'تعديل نص الرسالة في قاعدة البيانات' : 'Edit Message in DB'}
            </h3>
            <textarea
              rows={3}
              value={editingMsg.text}
              onChange={(e) => setEditingMsg({ ...editingMsg, text: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-tajawal"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingMsg(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleSaveEditedMessage}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold font-cairo"
              >
                {isAr ? 'حفظ التعديل' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Single Message Modal */}
      {deletingMsgId && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-800 max-w-sm w-full p-5 shadow-2xl space-y-4">
            <h3 className="text-base font-extrabold font-cairo text-rose-600">
              {isAr ? 'حذف هذه الرسالة؟' : 'Delete this message?'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal">
              {isAr ? 'سيتم إزالة الرسالة نهائياً من قاعدة البيانات.' : 'This message will be permanently removed from DB.'}
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeletingMsgId(null)}
                className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold font-cairo"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={() => handleDeleteMessage(deletingMsgId)}
                className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold font-cairo"
              >
                {isAr ? 'حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Conversation & Group Details Modal */}
      {detailsConv && (
        <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-cairo font-black text-lg">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold font-cairo text-slate-900 dark:text-white">
                    {getConversationDisplay(detailsConv).primary}
                  </h3>
                  <p className="text-xs text-slate-500 font-tajawal">
                    {getChannelTypeLabel(detailsConv.channelType || 'parent_teacher', language)} ·{' '}
                    {getConversationDisplay(detailsConv).secondary}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDetailsConv(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-5 pt-3 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 flex-wrap bg-slate-50 dark:bg-slate-950/50">
              {[
                { key: 'overview', label: isAr ? 'البيانات العامة' : 'Overview' },
                {
                  key: 'members',
                  label: isAr
                    ? `المشاركون (${detailsConv.memberNames?.length || 2})`
                    : `Members`,
                },
                {
                  key: 'media',
                  label: isAr
                    ? `الوسائط والملفات (${detailsConv.messages.filter((m) => ['image', 'video', 'audio', 'file'].includes(m.messageType || '')).length})`
                    : 'Media & Files',
                },
                {
                  key: 'warnings',
                  label: isAr
                    ? `الإنذارات والتقييمات (${detailsConv.messages.filter((m) => m.messageType === 'sticker').length})`
                    : 'Stickers & Warnings',
                },
                {
                  key: 'calls',
                  label: isAr
                    ? `سجل المكالمات (${detailsConv.messages.filter((m) => m.messageType === 'call_log').length})`
                    : 'Call Logs',
                },
              ].map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setDetailsTab(t.key as any)}
                  className={`px-3.5 py-2 text-xs font-bold font-cairo border-b-2 transition-colors ${
                    detailsTab === t.key
                      ? 'border-emerald-600 text-emerald-700 dark:text-emerald-400'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              {detailsTab === 'overview' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1">
                      <span className="text-[11px] text-slate-500 font-cairo">
                        {isAr ? 'نوع القناة / المنشئ' : 'Channel / Creator'}
                      </span>
                      <div className="font-bold text-sm font-cairo">
                        {getChannelTypeLabel(detailsConv.channelType || 'parent_teacher', language)}
                      </div>
                      {detailsConv.createdByName && (
                        <div className="text-xs text-slate-500">
                          {isAr ? 'أنشأها:' : 'Created by:'} {detailsConv.createdByName}
                        </div>
                      )}
                      {detailsConv.description && (
                        <div className="text-xs text-slate-500">{detailsConv.description}</div>
                      )}
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1">
                      <span className="text-[11px] text-slate-500 font-cairo">
                        {isAr ? 'الأطراف المشاركة' : 'Participants'}
                      </span>
                      <div className="font-bold text-sm font-cairo">
                        {getConversationDisplay(detailsConv).primary}
                      </div>
                      <div className="text-xs text-slate-500 font-tajawal">
                        {getConversationDisplay(detailsConv).secondary}
                      </div>
                      {matchedStudentForActive && (
                        <div className="text-xs text-emerald-600 font-bold font-mono-numbers">
                          {isAr
                            ? `المعدل: ${matchedStudentForActive.overallScore}% · الحضور: ${matchedStudentForActive.attendanceRate}%`
                            : `Score: ${matchedStudentForActive.overallScore}% · Attendance: ${matchedStudentForActive.attendanceRate}%`}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                      <div className="text-xl font-black font-mono-numbers text-emerald-700 dark:text-emerald-300">
                        {detailsConv.messages.length}
                      </div>
                      <div className="text-[11px] font-bold font-cairo text-emerald-800 dark:text-emerald-200">
                        {isAr ? 'إجمالي الرسائل' : 'Messages'}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
                      <div className="text-xl font-black font-mono-numbers text-amber-700 dark:text-amber-300">
                        {detailsConv.warningCount || 0}
                      </div>
                      <div className="text-[11px] font-bold font-cairo text-amber-800 dark:text-amber-200">
                        {isAr ? 'عدد الإنذارات' : 'Warnings'}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-sky-50 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800">
                      <div className="text-xl font-black font-mono-numbers text-sky-700 dark:text-sky-300">
                        {detailsConv.messages.filter((m) => m.messageType === 'audio').length}
                      </div>
                      <div className="text-[11px] font-bold font-cairo text-sky-800 dark:text-sky-200">
                        {isAr ? 'الريكوردات الصوتية' : 'Voice Notes'}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {detailsTab === 'members' && (
                <div className="space-y-3">
                  {detailsConv.channelType === 'public_group' && (
                    <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800 text-xs font-cairo font-bold text-teal-800 dark:text-teal-200">
                      {isAr
                        ? `مجموعة عامة مفتوحة لـ: ${audienceLabel(detailsConv.targetAudience, true)}`
                        : `Public Group open to: ${audienceLabel(detailsConv.targetAudience, false)}`}
                    </div>
                  )}
                  {detailsConv.memberNames && detailsConv.memberNames.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {detailsConv.memberNames.map((name, idx) => (
                        <div
                          key={`${name}-${idx}`}
                          className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-2.5 bg-slate-50 dark:bg-slate-800/50"
                        >
                          <Users className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span className="text-xs font-bold font-cairo">{name}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 font-tajawal">
                      {getConversationDisplay(detailsConv).secondary}
                    </p>
                  )}
                </div>
              )}

              {detailsTab === 'media' && (
                <div className="space-y-2.5">
                  {detailsConv.messages.filter((m) =>
                    ['image', 'video', 'audio', 'file'].includes(m.messageType || '')
                  ).length === 0 ? (
                    <p className="text-sm text-slate-500 font-tajawal text-center py-8">
                      {isAr ? 'لا توجد صور أو ملفات أو تسجيلات صوتية مرسلة بعد.' : 'No media or files shared yet.'}
                    </p>
                  ) : (
                    detailsConv.messages
                      .filter((m) => ['image', 'video', 'audio', 'file'].includes(m.messageType || ''))
                      .map((m) => (
                        <div
                          key={m.id}
                          className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="text-xs font-bold font-cairo truncate">
                              {m.fileName || m.text || m.messageType}
                            </div>
                            <div className="text-[11px] text-slate-500 font-tajawal">
                              {m.senderName} · {m.timestamp} {m.fileSize ? `· ${m.fileSize}` : ''}
                            </div>
                            {m.messageType === 'audio' && m.mediaUrl && (
                              <audio controls src={m.mediaUrl} className="mt-2 h-8 w-full max-w-xs" />
                            )}
                          </div>
                          {m.mediaUrl && (
                            <a
                              href={m.mediaUrl}
                              download={m.fileName || `media-${m.id}`}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold font-cairo"
                            >
                              <Download className="w-3.5 h-3.5" />
                              {isAr ? 'تنزيل' : 'Download'}
                            </a>
                          )}
                        </div>
                      ))
                  )}
                </div>
              )}

              {detailsTab === 'warnings' && (
                <div className="space-y-2.5">
                  {detailsConv.messages.filter((m) => m.messageType === 'sticker').length === 0 ? (
                    <p className="text-sm text-slate-500 font-tajawal text-center py-8">
                      {isAr ? 'لم يتم إرسال استيكرات تقييم أو إنذارات أو شكاوى بعد.' : 'No stickers or warnings sent yet.'}
                    </p>
                  ) : (
                    detailsConv.messages
                      .filter((m) => m.messageType === 'sticker')
                      .map((m) => (
                        <div
                          key={m.id}
                          className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3"
                        >
                          <div>
                            <div className="font-bold text-sm font-cairo">{m.stickerLabel}</div>
                            <div className="text-xs text-slate-600 dark:text-slate-300 font-tajawal mt-0.5">
                              {m.text}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono-numbers mt-1">
                              {m.senderName} · {m.timestamp}
                            </div>
                          </div>
                          <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[10px] font-bold font-cairo">
                            {m.stickerCategory}
                          </span>
                        </div>
                      ))
                  )}
                </div>
              )}

              {detailsTab === 'calls' && (
                <div className="space-y-2.5">
                  {detailsConv.messages.filter((m) => m.messageType === 'call_log').length === 0 ? (
                    <p className="text-sm text-slate-500 font-tajawal text-center py-8">
                      {isAr ? 'لا توجد مكالمات صوتية مسجلة بعد.' : 'No recorded calls yet.'}
                    </p>
                  ) : (
                    detailsConv.messages
                      .filter((m) => m.messageType === 'call_log')
                      .map((m) => (
                        <div
                          key={m.id}
                          className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2.5">
                            <PhoneCall className="w-4 h-4 text-emerald-600" />
                            <div>
                              <div className="text-xs font-bold font-cairo">{m.text}</div>
                              <div className="text-[11px] text-slate-500 font-tajawal">
                                {m.senderName} · {m.timestamp}
                              </div>
                            </div>
                          </div>
                          {m.durationSeconds ? (
                            <span className="text-xs font-bold font-mono-numbers text-emerald-700 dark:text-emerald-400">
                              {formatDuration(m.durationSeconds)}
                            </span>
                          ) : null}
                        </div>
                      ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Image Lightbox Preview */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-3xl w-full bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-700"
          >
            <div className="p-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold font-cairo truncate">{lightboxImage.title}</span>
              <div className="flex items-center gap-2">
                <a
                  href={lightboxImage.url}
                  download={lightboxImage.title}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold font-cairo"
                >
                  <Download className="w-3.5 h-3.5" />
                  {isAr ? 'تحميل' : 'Download'}
                </a>
                <button
                  type="button"
                  onClick={() => setLightboxImage(null)}
                  className="p-1 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-4 bg-slate-950 flex items-center justify-center max-h-[75vh] overflow-auto">
              <img
                src={lightboxImage.url}
                alt={lightboxImage.title}
                className="max-h-[70vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
