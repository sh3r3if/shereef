export type Language = 'ar' | 'en';

export type UserRole =
  | 'admin'
  | 'secretary'
  | 'supervisor'
  | 'teacher'
  | 'student'
  | 'female_student'
  | 'parent'
  | 'visitor';

export interface CurrentUser {
  id: string;
  name: string;
  nameEn: string;
  username?: string;
  email: string;
  role: UserRole;
  roleTitle?: string;
  isActive?: boolean;
  avatar?: string;
  isSuperAdmin?: boolean;
  permissions?: string[];
  studentId?: string; // for student or parent linking
  teacherId?: string; // for teacher linking
  phone?: string; // student/user phone number for dynamic watermark
}

export type EnrollmentType = 'online' | 'offline'; // أون لاين / أوف لاين (سنتر)

export type LessonFormat = 'video' | 'pdf' | 'word' | 'infographic';

export interface InfographicSection {
  id: string;
  title: string;
  description: string;
  iconName?: string;
  value?: string;
  color?: string;
  badge?: string;
  highlights?: string[];
  imageUrl?: string;
}

export type InfographicTemplate =
  | 'steps'
  | 'comparison'
  | 'cards'
  | 'stats'
  | 'timeline'
  | 'pyramid'
  | 'mindmap'
  | 'cycle'
  | 'swot'
  | 'checklist'
  | 'donut'
  | 'barchart'
  | 'funnel'
  | 'fishbone'
  | 'venn'
  | 'roadmap'
  | 'flashcards';

export type InfographicSurfaceStyle =
  | 'modern'
  | 'glass'
  | 'academic'
  | 'dark'
  | 'minimal';

export interface InfographicData {
  template: InfographicTemplate;
  themeColor: string;
  summary: string;
  sections: InfographicSection[];
  surfaceStyle?: InfographicSurfaceStyle;
  columns?: 1 | 2 | 3;
  authorName?: string;
  showNumbers?: boolean;
}

export interface Lesson {
  id: string;
  title: string;
  titleEn: string;
  subject: string;
  grade: string;
  teacherId: string;
  teacherName: string;
  format: LessonFormat;
  durationOrPages: string; // e.g. "45 دقيقة" or "18 صفحة" or "انفوجرافيك تفاعلي"
  videoUrl?: string;
  documentUrl?: string;
  description: string;
  createdAt: string;
  viewsCount: number;
  likesCount: number;
  thumbnail?: string;
  isPublished: boolean;
  unit: string;
  contentHtml?: string; // Rich text from CKEditor
  infographicData?: InfographicData; // Visual infographic model
  dripUnlockAtDate?: string;
  dripUnlockAfterDays?: number;
  prerequisiteLessonId?: string;
  prerequisiteMinScore?: number;
}

export interface AssistantAdmin {
  id: string;
  dbId?: number;
  name: string;
  nameEn: string;
  username: string;
  password?: string;
  email: string;
  phone: string;
  roleTitle: string;
  permissions: string[]; // ['manage_lessons', 'manage_teachers', 'manage_students', 'manage_quizzes', 'view_finances', etc.]
  createdAt: string;
  isActive: boolean;
  avatar?: string;
}

export interface SystemAuditLog {
  id: string;
  action: string;
  actionAr: string;
  entityType: string;
  entityName: string;
  performedBy: string;
  timestamp: string;
  details: string;
  severity: 'info' | 'warning' | 'critical';
}

export interface Teacher {
  id: string;
  name: string;
  nameEn: string;
  specialty: string;
  specialtyEn: string;
  email: string;
  phone: string;
  avatar: string;
  grades: string[];
  rating: number;
  totalStudents: number;
  activeLessonsCount: number;
  bio: string;
  joinedDate: string;
}

export interface Student {
  id: string;
  code: string; // e.g. "STU-1042"
  name: string;
  nameEn: string;
  grade: string;
  type: EnrollmentType; // online or offline
  studentPhone?: string; // التلفون واتساب للطالب
  parentName: string;
  parentPhone: string;
  parentEmail: string;
  bookletName?: string; // المذكرة
  bookletStatus?: string; // حالة الاستلام
  bookletBookingDate?: string; // تاريخ الحجز
  gender?: 'male' | 'female';
  overallScore: number; // percentage e.g. 94 or 55
  attendanceRate: number; // e.g. 96%
  status: 'top' | 'regular' | 'weak'; // تصنيف المستوى
  notes: string;
  registeredDate: string;
  city: string;
  avatar?: string;
}

export type QuizQuestionType = 'mcq' | 'true_false' | 'essay';

export type QuestionDifficulty = 'easy' | 'medium' | 'advanced' | 'gifted';

export interface QuizQuestion {
  id: string;
  questionType?: QuizQuestionType;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  points?: number;
  difficulty?: QuestionDifficulty;
  unit?: string;
  bankQuestionId?: string;
  sourcePdfPage?: number;
  sourceLessonId?: string;
  sourceLessonTitle?: string;
  sourceFormat?: 'video' | 'pdf' | 'word' | 'infographic';
}

export interface Quiz {
  id: string;
  title: string;
  subject: string;
  grade: string;
  type: 'weekly' | 'monthly'; // أسبوعي أو شهري
  durationMinutes: number;
  totalMarks: number;
  questions: QuizQuestion[];
  dueDate: string;
  completedStudentsCount: number;
  averageScore: number;
  pdfSourceFile?: string;
  isRandomized?: boolean;
  pdfPageCount?: number;
  instantExplanation?: boolean;
  enableMultiForms?: boolean;
  enableTabSwitchLock?: boolean;
  teacherId?: string;
  teacherName?: string;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  instructions: string;
  subject: string;
  grade: string;
  unit?: string;
  lessonId?: string;
  lessonTitle?: string;
  teacherId?: string;
  teacherName: string;
  attachmentUrl?: string | null;
  attachmentName?: string | null;
  dueDate: string;
  maxMarks: number;
  isPublished: boolean;
  createdAt?: string;
}

export interface AssignmentSubmission {
  id: string;
  assignmentId: string;
  studentId: string;
  studentName: string;
  studentCode?: string;
  answerText: string;
  attachmentUrl?: string | null;
  attachmentName?: string | null;
  annotatedImageUrl?: string | null;
  voiceFeedbackUrl?: string | null;
  voiceDurationSec?: number | null;
  score?: number | null;
  feedback?: string;
  status: 'submitted' | 'graded';
  submittedAt: string;
  gradedAt?: string;
  createdAt?: string;
}

export interface SequentialLessonConfig {
  enabled: boolean;
  minimumPassPercentage: number; // default 70
  scopeBySubjectAndGrade?: boolean;
}

export interface SequentialStudentLessonProgress {
  studentKey: string;
  studentName: string;
  watchedLessonIds: string[];
  passedLessonScores: Record<string, number>; // lessonId -> best percentage e.g. 85
  updatedAt: string;
}


export interface CertificateExamBreakdownItem {
  attemptId: string;
  quizId: string;
  quizTitle: string;
  quizType: 'weekly' | 'monthly';
  subject: string;
  earnedMarks: number;
  totalMarks: number;
  percentage: number;
  takenDate: string;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  quizTitle: string;
  quizType: 'weekly' | 'monthly';
  subject: string;
  grade: string;
  studentId: string;
  studentName: string;
  studentCode?: string | null;
  earnedMarks: number;
  totalMarks: number;
  percentage: number;
  correctCount: number;
  totalQuestions: number;
  takenDate: string;
  createdAt?: string;
}

export interface Certificate {
  id: string;
  studentId: string;
  studentName: string;
  studentGrade: string;
  studentAvatar?: string | null;
  type: 'excellence' | 'grades_report'; // شهادة تقدير وتفوق أو بيان درجات
  subjectOrTrack: string;
  score: number;
  issueDate: string;
  academicYear: string;
  principalName: string;
  notes: string;
  serialNumber: string;
  examPeriod?: 'weekly' | 'monthly' | 'all';
  weeklyAverage?: number | null;
  monthlyAverage?: number | null;
  examsCount?: number;
  breakdown?: CertificateExamBreakdownItem[];
  isAutoGenerated?: boolean;
}

export type ParentMessageType =
  | 'text'
  | 'audio'
  | 'image'
  | 'video'
  | 'file'
  | 'sticker'
  | 'call_log';

export type StickerCategory =
  | 'complaint'
  | 'suggestion'
  | 'rating'
  | 'congrats'
  | 'warning';

export type ChatChannelType =
  | 'student_teacher'
  | 'parent_teacher'
  | 'teacher_admin'
  | 'private_group'
  | 'public_group';

export type ChatGroupAudience = 'all' | 'students' | 'parents' | 'teachers' | 'staff';

export type ChatSenderRole =
  | 'student'
  | 'female_student'
  | 'teacher'
  | 'parent'
  | 'admin'
  | 'secretary'
  | 'supervisor';

export interface ChatDirectoryUser {
  id: string;
  uid?: string;
  name: string;
  role: UserRole;
  roleTitle?: string;
  email?: string;
  avatar?: string;
}

export interface ChatMessage {
  id: string;
  conversationId?: string;
  sender: ChatSenderRole;
  senderId?: string;
  senderName: string;
  senderRoleLabel?: string;
  messageType?: ParentMessageType;
  text: string;
  mediaUrl?: string | null;
  fileName?: string | null;
  fileSize?: string | null;
  mimeType?: string | null;
  durationSeconds?: number | null;
  stickerKey?: string | null;
  stickerCategory?: StickerCategory | null;
  stickerLabel?: string | null;
  timestamp: string;
  read: boolean;
  createdAt?: string;
}

export interface ParentConversation {
  id: string;
  channelType: ChatChannelType;
  title?: string;
  description?: string;
  studentId: string;
  studentName: string;
  studentGrade?: string;
  teacherId?: string;
  teacherName?: string;
  adminName?: string;
  parentName: string;
  parentPhone: string;
  parentEmail?: string;
  createdById?: string;
  createdByName?: string;
  createdByRole?: string;
  memberIds: string[];
  memberNames: string[];
  targetAudience?: ChatGroupAudience;
  status?: 'active' | 'needs_followup' | 'archived';
  warningCount?: number;
  notes?: string;
  lastMessage: string;
  lastTimestamp: string;
  unreadCount: number;
  messages: ChatMessage[];
  createdAt?: string;
  updatedAt?: string;
}

export type TimetableDay =
  | 'Saturday'
  | 'Sunday'
  | 'Monday'
  | 'Tuesday'
  | 'Wednesday'
  | 'Thursday'
  | 'Friday';

export type TimetableStatus = 'scheduled' | 'live' | 'completed' | 'cancelled';

export interface TimetableSlot {
  id: string;
  day: TimetableDay;
  dayAr: string;
  time: string;
  subject: string;
  courseTitle?: string;
  teacherId?: string;
  teacherName: string;
  lessonId?: string;
  lessonTitle?: string;
  grade: string;
  semester?: string;
  type: EnrollmentType;
  roomOrLink: string;
  status?: TimetableStatus;
  capacity?: number;
  notes?: string;
  createdAt?: string;
}

export interface TuitionInvoice {
  id: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  grade: string;
  amount: number;
  currency: string;
  dueDate: string;
  status: 'paid' | 'pending' | 'overdue';
  paymentMethod?: 'mada' | 'visa' | 'apple_pay' | 'cash';
  paidDate?: string;
  description: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  target:
    | 'all'
    | 'students'
    | 'parents'
    | 'students_parents'
    | 'weak_students'
    | 'top_students';
  category: 'academic' | 'financial' | 'attendance' | 'general';
  relatedType?: 'lesson' | 'assignment' | 'quiz_weekly' | 'quiz_monthly' | 'general';
  relatedId?: string;
  targetGrade?: string;
  targetSubject?: string;
  targetEnrollmentType?: 'all' | 'online' | 'offline';
  targetCondition?: 'all' | 'expiring_codes' | 'at_risk';
  recipientsCount?: number;
  createdAt: string;
  read: boolean;
}

export interface FaqItem {
  id: string;
  questionAr: string;
  questionEn: string;
  answerAr: string;
  answerEn: string;
  category: string;
  createdAt?: string;
}

export interface InquiryItem {
  id: string;
  senderName: string;
  senderRole: 'student' | 'parent' | 'teacher' | 'visitor';
  senderContact?: string;
  subject: string;
  message: string;
  category: 'academic' | 'financial' | 'technical' | 'general' | 'suggestion' | 'complaint';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'pending' | 'answered' | 'closed';
  replyText?: string;
  repliedBy?: string;
  repliedAt?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface HeroSliderConfig {
  badgeTextAr: string;
  badgeTextEn: string;
  headlineLine1Ar: string;
  headlineLine1En: string;
  headlineLine2Ar: string;
  headlineLine2En: string;
  subtitleAr: string;
  subtitleEn: string;
  searchPlaceholderAr: string;
  searchPlaceholderEn: string;
  searchButtonTextAr: string;
  searchButtonTextEn: string;
  primaryBtnTextAr: string;
  primaryBtnTextEn: string;
  primaryBtnLink: string;
  showPrimaryBtn: boolean;
  secondaryBtnTextAr: string;
  secondaryBtnTextEn: string;
  secondaryBtnLink: string;
  showSecondaryBtn: boolean;
  sliderImageUrl: string;
  ratingBadgeScore: string;
  ratingBadgeLabelAr: string;
  ratingBadgeLabelEn: string;
  floatingCardKickerAr: string;
  floatingCardKickerEn: string;
  floatingCardTitleAr: string;
  floatingCardTitleEn: string;
  stat1Value?: string;
  stat1LabelAr?: string;
  stat1LabelEn?: string;
  stat2Value?: string;
  stat2LabelAr?: string;
  stat2LabelEn?: string;
  stat3Value?: string;
  stat3LabelAr?: string;
  stat3LabelEn?: string;
  stat4Value?: string;
  stat4LabelAr?: string;
  stat4LabelEn?: string;

  // 3. Featured Courses Section
  coursesKickerAr?: string;
  coursesTitleAr?: string;
  coursesSubtitleAr?: string;
  coursesViewAllBtnAr?: string;
  coursesEmptyTitleAr?: string;
  coursesEmptyDescAr?: string;
  coursesEmptyBtnTextAr?: string;
  coursesEmptyBtnLink?: string;

  // 4. Tracks & Categories Section
  tracksKickerAr?: string;
  tracksTitleAr?: string;
  tracksEmptyDescAr?: string;

  // 5. Why Al-Sharif Value Proposition Section
  whyKickerAr?: string;
  whyTitleAr?: string;
  whySubtitleAr?: string;
  whyFeature1Icon?: string;
  whyFeature1TitleAr?: string;
  whyFeature1DescAr?: string;
  whyFeature2Icon?: string;
  whyFeature2TitleAr?: string;
  whyFeature2DescAr?: string;
  whyFeature3Icon?: string;
  whyFeature3TitleAr?: string;
  whyFeature3DescAr?: string;
  whyFeature4Icon?: string;
  whyFeature4TitleAr?: string;
  whyFeature4DescAr?: string;
  whyImageUrl?: string;
  whyImageAlt?: string;
  whyTrophyIcon?: string;
  whyTrophyTitleAr?: string;
  whyTrophyDescAr?: string;

  // 6. Testimonial Section
  testimonialKickerAr?: string;
  testimonialTitleAr?: string;
  testimonialQuoteAr?: string;
  testimonialAvatarUrl?: string;
  testimonialAuthorNameAr?: string;
  testimonialAuthorRoleAr?: string;

  // 7. Newsletter CTA Section
  newsletterTitleAr?: string;
  newsletterSubtitleAr?: string;
  newsletterPlaceholderAr?: string;
  newsletterBtnTextAr?: string;

  // 8. Footer Section
  footerBrandNameAr?: string;
  footerBrandDescAr?: string;
  footerCol1TitleAr?: string;
  footerCol1Link1TextAr?: string;
  footerCol1Link1Url?: string;
  footerCol1Link2TextAr?: string;
  footerCol1Link2Url?: string;
  footerCol1Link3TextAr?: string;
  footerCol1Link3Url?: string;
  footerCol2TitleAr?: string;
  footerCol2Link1TextAr?: string;
  footerCol2Link1Url?: string;
  footerCol2Link2TextAr?: string;
  footerCol2Link2Url?: string;
  footerCol2Link3TextAr?: string;
  footerCol2Link3Url?: string;
  footerCol3TitleAr?: string;
  footerCol3Link1TextAr?: string;
  footerCol3Link1Url?: string;
  footerCol3Link2TextAr?: string;
  footerCol3Link2Url?: string;
  footerCol3Link3TextAr?: string;
  footerCol3Link3Url?: string;
  footerCopyrightAr?: string;
  footerTaglineAr?: string;
}

export const DEFAULT_HERO_SLIDER_CONFIG: HeroSliderConfig = {
  badgeTextAr: 'تعلم بذكاء، تقدّم بثقة عبر منصة الشريف',
  badgeTextEn: 'Learn smart, advance with confidence',
  headlineLine1Ar: 'مهارات اليوم،',
  headlineLine1En: 'Skills of Today',
  headlineLine2Ar: 'لمستقبل تصنعه',
  headlineLine2En: 'for a Future You Create',
  subtitleAr:
    'منصة الشريف التعليمية تجمع الخبراء والمحتوى التطبيقي في تجربة تعلم مرنة، مصممة لتقودك من أول درس إلى أول إنجاز.',
  subtitleEn:
    'Al-Sharif educational platform connecting industry experts and practical learning from day one.',
  searchPlaceholderAr: 'ابحث في قاعدة البيانات عن درس، مادة، معلم، اختبار، أو شهادة...',
  searchPlaceholderEn: 'Search database for lessons, subjects, teachers, quizzes...',
  searchButtonTextAr: 'بحث',
  searchButtonTextEn: 'Search',
  primaryBtnTextAr: 'استكشف الدورات',
  primaryBtnTextEn: 'Explore Courses',
  primaryBtnLink: '#courses-section',
  showPrimaryBtn: true,
  secondaryBtnTextAr: 'شاهد كيف نتعلّم',
  secondaryBtnTextEn: 'See How We Learn',
  secondaryBtnLink: '#auth',
  showSecondaryBtn: true,
  sliderImageUrl: '/assets/images/hero_school_platform_1794403365692.jpg',
  ratingBadgeScore: '4.9 / 5',
  ratingBadgeLabelAr: 'تقييم المتعلمين',
  ratingBadgeLabelEn: 'Student Rating',
  floatingCardKickerAr: 'منصة الشريف التعليمية',
  floatingCardKickerEn: 'Al-Sharif Interactive',
  floatingCardTitleAr: 'دروس ومحاضرات تفاعلية',
  floatingCardTitleEn: 'Interactive Courses',
  stat1Value: '',
  stat1LabelAr: 'طالب مسجل في قاعدة البيانات',
  stat1LabelEn: 'Registered Students in DB',
  stat2Value: '',
  stat2LabelAr: 'درس ومحاضرة في قاعدة البيانات',
  stat2LabelEn: 'Lessons in Database',
  stat3Value: '',
  stat3LabelAr: 'معلم وخبير معتمد',
  stat3LabelEn: 'Certified Instructors',
  stat4Value: '',
  stat4LabelAr: 'اختبار ومسابقة تفاعلية',
  stat4LabelEn: 'Interactive Quizzes',

  // 3. Featured Courses Section
  coursesKickerAr: 'دورات ودروس منصة الشريف (من قاعدة البيانات)',
  coursesTitleAr: 'ابدأ من حيث أنت، وتقدّم بطريقتك',
  coursesSubtitleAr: 'محتوى تطبيقي محدث مرتبط مباشرة بقاعدة بيانات منصة الشريف.',
  coursesViewAllBtnAr: 'عرض كل الدورات',
  coursesEmptyTitleAr: 'لا توجد دورات مطابقة حالياً في قاعدة البيانات',
  coursesEmptyDescAr:
    'سجّل الدخول إلى البوابة التعليمية لإضافة الدروس والمقررات الدراسية وستظهر هنا وفي مربع البحث تلقائياً.',
  coursesEmptyBtnTextAr: 'دخول البوابة لإضافة دروس',
  coursesEmptyBtnLink: '#auth',

  // 4. Tracks & Categories Section
  tracksKickerAr: 'اكتشف المواد الدراسية في قاعدة البيانات',
  tracksTitleAr: 'مسارات تبدأ بفضول وتنتهي بمهارة',
  tracksEmptyDescAr: 'ستظهر مسارات المواد الدراسية هنا تلقائياً فور إضافة الدروس في قاعدة البيانات.',

  // 5. Why Al-Sharif Value Proposition Section
  whyKickerAr: 'لماذا منصة الشريف؟',
  whyTitleAr: 'كل ما تحتاجه لتستمر في التقدّم',
  whySubtitleAr: 'نبني تجربة التعلّم حول وقتك وأهدافك، لا العكس.',
  whyFeature1Icon: '📅',
  whyFeature1TitleAr: 'تعلم بمرونة',
  whyFeature1DescAr: 'دروس قصيرة ومنظمة يمكنك متابعتها في أي وقت ومن أي جهاز.',
  whyFeature2Icon: '🎓',
  whyFeature2TitleAr: 'خبراء حقيقيون',
  whyFeature2DescAr: 'تعلم من ممارسين ينقلون لك خبرة السوق، لا المعلومات النظرية فقط.',
  whyFeature3Icon: '⚡',
  whyFeature3TitleAr: 'تطبيق من اليوم الأول',
  whyFeature3DescAr: 'مشاريع واختبارات تفاعلية تساعدك على تحويل المعرفة إلى مهارة.',
  whyFeature4Icon: '📊',
  whyFeature4TitleAr: 'تقدم يمكنك قياسه',
  whyFeature4DescAr: 'تابع إنجازك، حافظ على استمراريتك، واحتفل بكل مرحلة.',
  whyImageUrl: '/assets/images/hero_school_platform_1794403365692.jpg',
  whyImageAlt: 'Students collaborating',
  whyTrophyIcon: '🏆',
  whyTrophyTitleAr: 'أحسنت!',
  whyTrophyDescAr: 'حققت هدفك الأسبوعي',

  // 6. Testimonial Section
  testimonialKickerAr: 'قصص من مجتمعنا',
  testimonialTitleAr: 'حين يتحوّل التعلّم إلى فرصة',
  testimonialQuoteAr:
    '«لم تكن الدورة مجرد فيديوهات. المشاريع والتغذية الراجعة جعلتني أبني ملف أعمال حقيقياً، وبعد شهرين حصلت على أول فرصة في مجال تصميم المنتجات.»',
  testimonialAvatarUrl: '/assets/images/avatar_teacher_female_1794403365703.jpg',
  testimonialAuthorNameAr: 'سارة خالد',
  testimonialAuthorRoleAr: 'مصممة منتجات رقمية',

  // 7. Newsletter CTA Section
  newsletterTitleAr: 'خطوتك القادمة تبدأ من بريدك',
  newsletterSubtitleAr: 'نشرة أسبوعية مختصرة: دورات جديدة، نصائح عملية، وفرص تستحق وقتك.',
  newsletterPlaceholderAr: 'البريد الإلكتروني',
  newsletterBtnTextAr: 'اشترك الآن',

  // 8. Footer Section
  footerBrandNameAr: 'منصة الشريف',
  footerBrandDescAr:
    'تعلّم مستمر يصنع مستقبلاً أوسع. محتوى عربي احترافي لكل طموح عبر منصة الشريف.',
  footerCol1TitleAr: 'المنصة',
  footerCol1Link1TextAr: 'عن منصة الشريف',
  footerCol1Link1Url: '#auth',
  footerCol1Link2TextAr: 'الدورات',
  footerCol1Link2Url: '#courses-section',
  footerCol1Link3TextAr: 'المدربون',
  footerCol1Link3Url: '#auth',
  footerCol2TitleAr: 'الدعم',
  footerCol2Link1TextAr: 'مركز المساعدة',
  footerCol2Link1Url: '#auth',
  footerCol2Link2TextAr: 'الأسئلة الشائعة',
  footerCol2Link2Url: '#auth',
  footerCol2Link3TextAr: 'تواصل معنا',
  footerCol2Link3Url: '#auth',
  footerCol3TitleAr: 'قانوني وبوابات الدخول',
  footerCol3Link1TextAr: 'دخول لوحة الأدمن (الداش بورد)',
  footerCol3Link1Url: '#auth',
  footerCol3Link2TextAr: 'بوابة المعلمين والطلاب',
  footerCol3Link2Url: '#auth',
  footerCol3Link3TextAr: 'الخصوصية والشروط',
  footerCol3Link3Url: '#auth',
  footerCopyrightAr: '© 2026 منصة الشريف. جميع الحقوق محفوظة.',
  footerTaglineAr: 'صممت لأفضل تجربة مستخدم تعليمية',
};

export interface SchoolSettings {
  schoolName: string;
  schoolNameEn: string;
  tagline: string;
  primaryColor: string; // hex
  logoUrl?: string;
  academicYear: string;
  enableInstantNotifications: boolean;
  enableRealtimeSync: boolean;
  heroSlider?: HeroSliderConfig;
}

export interface LessonRating {
  id: string;
  lessonId: string;
  lessonTitle: string;
  subject: string;
  grade: string;
  teacherId?: string;
  teacherName?: string;
  studentId: string;
  studentName: string;
  rating: number; // 1..5
  clarityRating: number; // 1..5
  benefitRating: number; // 1..5
  comment?: string;
  createdAt: string;
}

export type LessonItem = Lesson;

export type ActivationCodeScope =
  | 'monthly'
  | 'semester'
  | 'subject'
  | 'lesson'
  | 'full_vip'
  | 'promo_discount'
  | 'trial_48h';

export interface ActivationCodeCard {
  id: string;
  code: string;
  scope: ActivationCodeScope;
  title: string;
  subject?: string;
  targetSubject?: string;
  grade?: string;
  lessonId?: string;
  targetLessonId?: string;
  lessonTitle?: string;
  targetLessonTitle?: string;
  durationDays: number;
  durationHours?: number;
  discountPercent?: number;
  firstUnitOnly?: boolean;
  bundleLabel?: string;
  price: number;
  currency: string;
  maxUses: number;
  usedCount: number;
  status: 'available' | 'redeemed' | 'expired' | 'revoked';
  redeemedByStudentId?: string;
  redeemedByStudentName?: string;
  redeemedByPhone?: string;
  redeemedAt?: string;
  expiresAt?: string;
  createdBy: string;
  createdAt: string;
}

export interface StudentCodeRedemption {
  id: string;
  codeId: string;
  code: string;
  scope: ActivationCodeScope;
  title: string;
  subject?: string;
  targetSubject?: string;
  grade?: string;
  lessonId?: string;
  targetLessonId?: string;
  lessonTitle?: string;
  targetLessonTitle?: string;
  durationHours?: number;
  discountPercent?: number;
  firstUnitOnly?: boolean;
  studentId: string;
  studentName: string;
  studentPhone?: string;
  redeemedAt: string;
  expiresAt: string;
  isActive: boolean;
}

export interface GeoSnapshot {
  country?: string;
  countryCode?: string;
  governorate?: string;
  city?: string;
  village?: string;
  lat?: number;
  lon?: number;
  timezone?: string;
}

export interface BoundDeviceEntry {
  deviceId: string;
  deviceLabel: string;
  userAgent: string;
  firstBoundAt: string;
  lastActiveAt: string;
  boundIp?: string;
  boundGeo?: GeoSnapshot;
  boundGeoLabel?: string;
  adminApproved?: boolean;
  approvedAt?: string;
  approvedBy?: string;
}

export interface PendingDeviceRequest {
  deviceId: string;
  deviceLabel: string;
  userAgent: string;
  ip: string;
  geo?: GeoSnapshot;
  geoLabel?: string;
  requestedAt: string;
  reasonCode: 'device_limit_exceeded' | 'ip_changed' | 'geo_changed';
  reasonMessageAr: string;
}

export interface StudentDeviceRecord {
  userKey: string;
  studentId?: string;
  studentName: string;
  username?: string;
  studentUsername?: string;
  email?: string;
  phone?: string;
  role: string;
  maxAllowedDevices?: number;
  devices: BoundDeviceEntry[];
  blockedAttemptsCount: number;
  blockedAttempts?: number;
  lastBlockedDeviceLabel?: string;
  lastBlockedIp?: string;
  lastBlockedGeo?: GeoSnapshot;
  lastBlockedGeoLabel?: string;
  lastBlockedAt?: string;
  lockStatus?: 'active' | 'locked';
  lockReasonCode?: 'device_limit_exceeded' | 'ip_changed' | 'geo_changed' | null;
  lockReasonMessageAr?: string | null;
  pendingDeviceRequest?: PendingDeviceRequest | null;
}

export interface ContentSecurityConfig {
  requireActivationCodeForStudents: boolean;
  lockedLessonIds: string[];
  lockedSubjects: string[];
  enableDeviceBinding: boolean;
  maxDevicesPerStudent: number;
  enforceStrictIpBinding: boolean;
  enforceStrictGeoBinding: boolean;
  enableJumpingCornerWatermark: boolean;
  enableJumpingWatermark?: boolean;
  jumpingWatermarkIntervalSec: number;
  watermarkJumpingIntervalSec?: number;
  enableAudioWatermark: boolean;
  audioWatermarkIntervalSec: number;
  audioWatermarkMode: 'voice_and_tone' | 'voice_only' | 'tone_only';
}

export const DEFAULT_CONTENT_SECURITY_CONFIG: ContentSecurityConfig = {
  requireActivationCodeForStudents: false,
  lockedLessonIds: [],
  lockedSubjects: [],
  enableDeviceBinding: true,
  maxDevicesPerStudent: 1,
  enforceStrictIpBinding: true,
  enforceStrictGeoBinding: true,
  enableJumpingCornerWatermark: true,
  enableJumpingWatermark: true,
  jumpingWatermarkIntervalSec: 4,
  watermarkJumpingIntervalSec: 4,
  enableAudioWatermark: true,
  audioWatermarkIntervalSec: 35,
  audioWatermarkMode: 'voice_and_tone',
};

export interface CenterAttendanceSession {
  id: string;
  title: string;
  subject: string;
  grade: string;
  hallName: string;
  sessionDate: string;
  createdBy: string;
  createdAt: string;
}

export interface QrAttendanceRecord {
  id: string;
  sessionId: string;
  sessionTitle: string;
  sessionDate: string;
  studentId: string;
  studentCode: string;
  studentName: string;
  studentGrade: string;
  status: 'present' | 'absent' | 'late';
  checkedInAt: string;
  scannedBy: string;
  method: 'qr_camera' | 'qr_manual' | 'quick_roster';
}

export interface WeeklyParentReportExamItem {
  title: string;
  subject: string;
  scoreText: string;
  percentage: number;
  date: string;
}

export interface WeeklyParentReportSummary {
  studentId: string;
  studentCode: string;
  studentName: string;
  studentGrade: string;
  studentType: 'online' | 'offline';
  studentAvatar?: string | null;
  parentName: string;
  parentPhone: string;
  parentEmail?: string;
  weekLabel: string;
  studyHours: number;
  completedLessonsCount: number;
  completedLessonTitles: string[];
  examsCount: number;
  averageExamScore: number;
  weakestSubject?: string | null;
  weakestSubjectScore?: number | null;
  examDetails: WeeklyParentReportExamItem[];
  absenceDays: number;
  attendanceDays: number;
  attendanceRate: number;
  assignmentsSubmittedCount: number;
  customTeacherNote?: string;
  lastSentViaWhatsappAt?: string | null;
  lastSentBy?: string | null;
}

export interface TimestampedLessonNote {
  id: string;
  lessonId: string;
  lessonTitle: string;
  subject: string;
  studentId: string;
  studentName: string;
  timestampSeconds: number;
  formattedTime: string;
  noteText: string;
  createdAt: string;
}

export interface PersonalStudyPlanItem {
  id: string;
  studentId: string;
  studentName: string;
  dayOfWeek: string;
  timeSlot: string;
  subject: string;
  title: string;
  targetPomodoros: number;
  completedPomodoros: number;
  isCompleted: boolean;
  createdAt: string;
}

export interface PomodoroStudySession {
  id: string;
  studentId: string;
  studentCode?: string;
  studentName: string;
  subject: string;
  lessonId?: string;
  lessonTitle?: string;
  taskTitle?: string;
  durationMinutes: number;
  mode: 'focus' | 'break';
  completedAt: string;
}

export interface WeeklyStudyLeaderboardEntry {
  rank: number;
  studentId: string;
  studentCode: string;
  studentName: string;
  studentGrade: string;
  studentAvatar?: string | null;
  totalMinutes: number;
  totalHours: number;
  sessionsCount: number;
}

export interface StudentMistakeEntry {
  id: string;
  studentId: string;
  studentName: string;
  subject: string;
  grade: string;
  sourceType: 'quiz' | 'competition';
  quizId?: string;
  quizTitle?: string;
  questionId: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  selectedOptionIndex: number;
  explanation?: string;
  wrongCount: number;
  mastered: boolean;
  lastWrongAt: string;
  masteredAt?: string;
}

export interface ExamSprintTask {
  id: string;
  dayNumber: number; // 1..7
  dayLabel: string;
  taskType: 'lesson' | 'flashcards' | 'quiz' | 'mistakes_review';
  title: string;
  subject: string;
  targetId?: string;
  estimatedMinutes: number;
  isCompleted: boolean;
}

export interface ExamSprintPlan {
  id: string;
  studentId: string;
  studentName: string;
  subject: string;
  examDate: string;
  dailyHours: number;
  tasks: ExamSprintTask[];
  createdAt: string;
}

export interface LessonBookmark {
  studentId: string;
  lessonId: string;
  createdAt: string;
}

export type ContentErrorReportCategory = 'typo' | 'broken_link' | 'needs_clarification' | 'other';

export interface ContentErrorReport {
  id: string;
  targetType: 'lesson' | 'quiz_question';
  lessonId?: string;
  quizId?: string;
  questionId?: string;
  targetTitle: string;
  subject: string;
  category: ContentErrorReportCategory;
  details: string;
  reporterId: string;
  reporterName: string;
  status: 'open' | 'resolved';
  resolvedBy?: string;
  resolvedAt?: string;
  createdAt: string;
}

export interface WeeklyClassChallengeWinner {
  studentId: string;
  studentCode?: string;
  studentName: string;
  percentage: number;
  achievedAt: string;
  seatNumber: number;
}

export interface WeeklyClassChallenge {
  id: string;
  title: string;
  subject: string;
  grade: string;
  quizId?: string;
  minPercentage: number;
  maxWinners: number;
  badgeTitle: string;
  deadlineDate: string;
  winners: WeeklyClassChallengeWinner[];
  createdBy: string;
  createdAt: string;
}

export interface QuestionBankItem {
  id: string;
  subject: string;
  grade: string;
  unit: string;
  lessonId?: string;
  lessonTitle?: string;
  difficulty: QuestionDifficulty;
  questionType: 'mcq' | 'true_false';
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  points: number;
  usageCount?: number;
  createdBy: string;
  createdAt: string;
}

export interface FlashcardSm2State {
  cardId: string;
  studentId: string;
  easeFactor: number;
  intervalDays: number;
  repetitions: number;
  lastQuality: 'hard' | 'medium' | 'easy';
  nextReviewAt: string;
  updatedAt: string;
}

export interface StudentStreakRecord {
  studentId: string;
  studentName: string;
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string;
  freezeTokens: number;
  frozenDates: string[];
  totalPoints: number;
  rankTitle: string;
  historyDates: string[];
}

export interface LessonQaQuestion {
  id: string;
  lessonId: string;
  lessonTitle: string;
  subject: string;
  authorId: string;
  authorName: string;
  authorRole: string;
  questionText: string;
  videoTimestampSec?: number | null;
  answerText?: string | null;
  answeredBy?: string | null;
  answeredAt?: string | null;
  isPinned: boolean;
  upvotes: number;
  createdAt: string;
}

export interface LessonDripRule {
  lessonId: string;
  dripUnlockAtDate?: string;
  dripUnlockAfterDays?: number;
  prerequisiteLessonId?: string;
  prerequisiteMinScore?: number;
  updatedAt: string;
}

export interface AtRiskStudentAlert {
  studentId: string;
  studentCode: string;
  studentName: string;
  grade: string;
  type: EnrollmentType;
  parentName: string;
  parentPhone: string;
  attendanceRate: number;
  overallScore: number;
  lastTwoScores: number[];
  daysSinceLastActivity: number | null;
  riskScore: number;
  riskLevel: 'high' | 'medium';
  reasons: string[];
}

export interface LiveSessionAttendanceLog {
  id: string;
  slotId: string;
  slotTitle: string;
  subject: string;
  grade: string;
  platform: 'jitsi' | 'zoom' | 'meet' | 'in_app';
  studentId: string;
  studentCode?: string;
  studentName: string;
  joinedAt: string;
  lastHeartbeatAt: string;
  durationMinutes: number;
  status: 'present' | 'partial';
}

export interface TeacherRevenueSplitConfig {
  teacherId: string;
  teacherName: string;
  specialty: string;
  sharePercent: number;
}

export interface TeacherRevenueBreakdownItem {
  teacherId: string;
  teacherName: string;
  specialty: string;
  sharePercent: number;
  grossRevenue: number;
  teacherShareAmount: number;
  platformNetAmount: number;
  codesSoldCount: number;
  lessonsCount: number;
}

export interface BookletCatalogItem {
  id: string;
  title: string;
  subject: string;
  grade: string;
  teacherName?: string;
  pagesCount: number;
  price: number;
  currency: string;
  stockCount: number;
  description: string;
  coverUrl?: string;
  isAvailable: boolean;
  createdAt: string;
}

export type BookletDeliveryMethod = 'pickup_center' | 'shipping';
export type BookletOrderStatus = 'pending' | 'preparing' | 'ready_pickup' | 'shipped' | 'delivered' | 'cancelled';

export interface BookletOrder {
  id: string;
  orderNumber: string;
  bookletId: string;
  bookletTitle: string;
  subject: string;
  grade: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  currency: string;
  studentId: string;
  studentName: string;
  studentPhone: string;
  deliveryMethod: BookletDeliveryMethod;
  shippingAddress?: string;
  notes?: string;
  paymentStatus: 'unpaid' | 'paid';
  status: BookletOrderStatus;
  createdAt: string;
  updatedAt: string;
}



