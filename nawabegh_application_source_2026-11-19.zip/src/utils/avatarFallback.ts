import React from 'react';

export const DEFAULT_TEACHER_AVATAR = '/assets/images/avatar_teacher_male_1794403366117.jpg';
export const DEFAULT_TEACHER_FEMALE_AVATAR = '/assets/images/avatar_teacher_female_1794403365703.jpg';
export const CERTIFICATE_CREST_IMAGE = '/assets/images/certificate_crest_gold_1794403367581.jpg';
export const HERO_PLATFORM_IMAGE = '/assets/images/hero_school_platform_1794403365692.jpg';

export function getSafeAvatarUrl(
  src?: string | null,
  fallback: string = DEFAULT_TEACHER_AVATAR
): string {
  const trimmed = typeof src === 'string' ? src.trim() : '';
  if (!trimmed) return fallback;
  if (trimmed.includes('avatar_teacher_female_1794403366852')) {
    return DEFAULT_TEACHER_FEMALE_AVATAR;
  }
  if (trimmed.startsWith('/src/assets/images/')) {
    return trimmed.replace('/src/assets/images/', '/assets/images/');
  }
  return trimmed;
}

export function buildAutoStudentAvatarDataUrl(
  name?: string,
  gender: 'male' | 'female' = 'male'
): string {
  const clean = (name || '').trim();
  const parts = clean.split(/\s+/).filter(Boolean);
  const initials =
    parts.length >= 2
      ? `${parts[0][0] || ''} ${parts[1][0] || ''}`
      : clean.slice(0, 2) || (gender === 'female' ? 'ط' : 'ط');
  const bgStart = gender === 'female' ? '#be185d' : '#1e40af';
  const bgEnd = gender === 'female' ? '#7e22ce' : '#0f766e';
  const badgeBg = gender === 'female' ? '#fce7f3' : '#dbeafe';
  const badgeText = gender === 'female' ? '#9d174d' : '#1e3a8a';
  const label = gender === 'female' ? 'طالبة' : 'طالب';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" viewBox="0 0 160 160">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${bgStart}" />
        <stop offset="100%" stop-color="${bgEnd}" />
      </linearGradient>
    </defs>
    <rect width="160" height="160" rx="32" fill="url(#g)" />
    <circle cx="80" cy="58" r="24" fill="rgba(255,255,255,0.18)" />
    <path d="M40 132c6-22 23-34 40-34s34 12 40 34" fill="rgba(255,255,255,0.18)" />
    <text x="80" y="72" text-anchor="middle" fill="#ffffff" font-family="Cairo, Tajawal, sans-serif" font-weight="800" font-size="30">${initials}</text>
    <rect x="44" y="114" width="72" height="24" rx="12" fill="${badgeBg}" />
    <text x="80" y="130" text-anchor="middle" fill="${badgeText}" font-family="Cairo, Tajawal, sans-serif" font-weight="700" font-size="13">${label}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function getStudentAvatarUrl(
  src?: string | null,
  name?: string,
  gender: 'male' | 'female' = 'male'
): string {
  const trimmed = typeof src === 'string' ? src.trim() : '';
  if (!trimmed) {
    return buildAutoStudentAvatarDataUrl(name, gender);
  }
  if (trimmed.startsWith('/src/assets/images/')) {
    return trimmed.replace('/src/assets/images/', '/assets/images/');
  }
  return trimmed;
}

export function handleStudentAvatarError(
  event: React.SyntheticEvent<HTMLImageElement, Event>,
  name?: string,
  gender: 'male' | 'female' = 'male'
): void {
  const img = event.currentTarget;
  if (img.dataset.fallbackApplied === 'true') return;
  img.dataset.fallbackApplied = 'true';
  img.src = buildAutoStudentAvatarDataUrl(name, gender);
}

export function handleImageErrorToTeacherAvatar(
  event: React.SyntheticEvent<HTMLImageElement, Event>
): void {
  const img = event.currentTarget;
  if (img.dataset.fallbackApplied === 'true') return;
  img.dataset.fallbackApplied = 'true';
  img.src = DEFAULT_TEACHER_AVATAR;
}

export function readAndResizeImageFile(
  file: File,
  maxDimension = 420,
  quality = 0.85
): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('الملف المختار ليس صورة صالحة'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة ملف الصورة'));
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      if (file.type === 'image/svg+xml' || file.size <= 120 * 1024) {
        resolve(dataUrl);
        return;
      }

      const img = new Image();
      img.onerror = () => resolve(dataUrl);
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width >= height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }
          canvas.width = Math.max(1, width);
          canvas.height = Math.max(1, height);
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const outputType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
          resolve(canvas.toDataURL(outputType, quality));
        } catch {
          resolve(dataUrl);
        }
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}
