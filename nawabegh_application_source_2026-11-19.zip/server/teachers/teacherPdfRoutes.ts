import express from 'express';
import * as repo from '../../src/db/repository.ts';
import { appendCurriculumChapterFromPdfFeed } from '../curriculum/curriculumRoutes.ts';
import {
  PdfFeedApiError,
  buildCurriculumChapterFromExtracted,
  buildFormattedLessonHtml,
  extractCurriculumAndQuizFromPdf,
  mapGradeToCurriculumSubjectId,
  validatePdfPayloadOrThrow,
  type TeacherPdfMetadata,
} from './pdfCurriculumFeedService.ts';

const TEACHER_PDF_LIBRARY_KEY = 'teacher_pdf_library_v1';
const PDF_BLOB_PREFIX = 'teacher_pdf_blob_';

async function getAllPdfMetadata(): Promise<TeacherPdfMetadata[]> {
  const raw = await repo.getSystemSetting(TEACHER_PDF_LIBRARY_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function saveAllPdfMetadata(list: TeacherPdfMetadata[]) {
  await repo.setSystemSetting(TEACHER_PDF_LIBRARY_KEY, JSON.stringify(list));
}

function getRole(req: express.Request): string {
  return String(req.headers['x-user-role'] || '').trim().toLowerCase();
}

function getUserName(req: express.Request): string {
  try {
    return decodeURIComponent(String(req.headers['x-user-name'] || '')).trim();
  } catch {
    return '';
  }
}

function isStudentOrRestricted(req: express.Request): boolean {
  const role = getRole(req);
  return Boolean(role && ['student', 'female_student', 'parent', 'visitor'].includes(role));
}

export function createTeacherPdfRouter(deps: {
  broadcastAll: (payload: any) => void;
  dispatchWebPushNotification: (opts: {
    title: string;
    body: string;
    url?: string;
    target?: string;
    tag?: string;
  }) => Promise<{ sent: number; failed: number }>;
}) {
  const router = express.Router();

  // 1. Summary map of uploaded PDFs grouped by teacherId
  router.get('/pdfs/summary', async (_req, res) => {
    try {
      const list = await getAllPdfMetadata();
      const byTeacher: Record<string, TeacherPdfMetadata[]> = {};
      for (const item of list) {
        if (!byTeacher[item.teacherId]) byTeacher[item.teacherId] = [];
        byTeacher[item.teacherId].push(item);
      }
      res.json({ byTeacher });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. List PDFs for a specific teacher
  router.get('/:teacherId/pdfs', async (req, res) => {
    try {
      const list = await getAllPdfMetadata();
      const pdfs = list.filter((p) => p.teacherId === req.params.teacherId);
      res.json({ pdfs });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3. Stream stored PDF binary cleanly
  router.get('/:teacherId/pdfs/:pdfId/file', async (req, res) => {
    try {
      const list = await getAllPdfMetadata();
      const meta = list.find(
        (p) => p.id === req.params.pdfId && p.teacherId === req.params.teacherId
      );
      if (!meta) {
        return res.status(404).json({ error: 'ملف PDF غير موجود' });
      }
      const base64 = await repo.getSystemSetting(`${PDF_BLOB_PREFIX}${meta.id}`);
      if (!base64) {
        return res.status(404).json({ error: 'بيانات ملف PDF غير متوفرة في المخزن' });
      }
      const buffer = Buffer.from(base64, 'base64');
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        `inline; filename="${encodeURIComponent(meta.fileName)}"`
      );
      res.send(buffer);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. Upload 1 or more PDF files ONLY (Strictly queued as uploaded_pending; never auto-feeds until teacher clicks the feed button)
  router.post('/:teacherId/pdfs', async (req, res) => {
    if (isStudentOrRestricted(req)) {
      return res
        .status(403)
        .json({ error: 'رفع ملفات المناهج متاح للمعلمين والإدارة فقط' });
    }

    try {
      const { teacherId } = req.params;
      const rawFiles = Array.isArray(req.body?.files) ? req.body.files : [];
      if (rawFiles.length === 0) {
        return res.status(400).json({ error: 'يرجى اختيار ملف PDF واحد على الأقل للرفع' });
      }

      const uploadedBy =
        getUserName(req) || String(req.body?.uploadedBy || 'الكادر التعليمي').trim();
      const existing = await getAllPdfMetadata();
      const newlyUploaded: TeacherPdfMetadata[] = [];

      for (let i = 0; i < rawFiles.length; i++) {
        const f = rawFiles[i] || {};
        const fileName = String(f.fileName || `document_${i + 1}.pdf`).trim();
        const cleanBase64 = validatePdfPayloadOrThrow(String(f.base64Data || ''), fileName);
        const approxBytes =
          Number(f.fileSizeBytes) || Math.floor((cleanBase64.length * 3) / 4);

        const pdfId = `tpdf-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        await repo.setSystemSetting(`${PDF_BLOB_PREFIX}${pdfId}`, cleanBase64);

        const meta: TeacherPdfMetadata = {
          id: pdfId,
          teacherId,
          fileName,
          fileSizeBytes: approxBytes,
          subject: String(f.subject || req.body?.subject || 'المادة الدراسية').trim(),
          grade: String(f.grade || req.body?.grade || 'الصف الثاني الثانوي').trim(),
          uploadedAt: new Date().toISOString(),
          uploadedBy,
          status: 'uploaded_pending',
        };
        newlyUploaded.push(meta);
      }

      const updatedAll = [...newlyUploaded, ...existing];
      await saveAllPdfMetadata(updatedAll);

      const teacherPdfs = updatedAll.filter((p) => p.teacherId === teacherId);
      deps.broadcastAll({
        type: 'teacher_pdfs:updated',
        teacherId,
        pdfs: teacherPdfs,
      });

      res.status(201).json({
        ok: true,
        uploaded: newlyUploaded,
        pdfs: teacherPdfs,
      });
    } catch (err: any) {
      if (err instanceof PdfFeedApiError) {
        return res.status(err.statusCode).json({ error: err.message, code: err.code });
      }
      res.status(500).json({ error: err?.message || 'تعذر حفظ ملف PDF' });
    }
  });

  // 5. Delete an uploaded PDF file from a teacher's library
  router.delete('/:teacherId/pdfs/:pdfId', async (req, res) => {
    if (isStudentOrRestricted(req)) {
      return res.status(403).json({ error: 'غير مصرح بحذف ملفات المناهج' });
    }

    try {
      const { teacherId, pdfId } = req.params;
      const existing = await getAllPdfMetadata();
      const filtered = existing.filter(
        (p) => !(p.id === pdfId && p.teacherId === teacherId)
      );
      await saveAllPdfMetadata(filtered);
      await repo.setSystemSetting(`${PDF_BLOB_PREFIX}${pdfId}`, '');

      const teacherPdfs = filtered.filter((p) => p.teacherId === teacherId);
      deps.broadcastAll({
        type: 'teacher_pdfs:updated',
        teacherId,
        pdfs: teacherPdfs,
      });

      res.json({ ok: true, pdfs: teacherPdfs });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. Explicit Teacher Trigger Button: "تغذية الدروس والاختبارات" from Uploaded PDFs
  router.post('/:teacherId/feed-from-pdfs', async (req, res) => {
    if (isStudentOrRestricted(req)) {
      return res
        .status(403)
        .json({ error: 'صلاحية تغذية الدروس والاختبارات متاحة للمعلم أو الإدارة فقط' });
    }

    try {
      const { teacherId } = req.params;
      const {
        pdfIds,
        subject: overrideSubject,
        grade: overrideGrade,
        quizType = 'weekly',
        lessonCount = 4,
        questionsCount = 10,
        term = 1,
        alsoSyncCurriculumPath = true,
      } = req.body || {};

      const allTeachers = await repo.getAllTeachers();
      const teacher = allTeachers.find((t: any) => t.id === teacherId);
      if (!teacher) {
        return res.status(404).json({ error: 'ملف المعلم غير موجود في قاعدة البيانات' });
      }

      const allPdfs = await getAllPdfMetadata();
      const teacherPdfs = allPdfs.filter((p) => p.teacherId === teacherId);
      if (teacherPdfs.length === 0) {
        return res.status(400).json({
          error: 'يرجى رفع ملف PDF واحد على الأقل أولاً قبل الضغط على زر تغذية الدروس والاختبارات.',
        });
      }

      const requestedIds = Array.isArray(pdfIds) && pdfIds.length > 0 ? new Set(pdfIds) : null;
      const targetPdfs = requestedIds
        ? teacherPdfs.filter((p) => requestedIds.has(p.id))
        : teacherPdfs.some((p) => p.status === 'uploaded_pending')
        ? teacherPdfs.filter((p) => p.status === 'uploaded_pending')
        : teacherPdfs;

      if (targetPdfs.length === 0) {
        return res.status(400).json({
          error: 'لم يتم العثور على ملفات PDF محددة للتغذية.',
        });
      }

      const parsedTeacherGrades: string[] = (() => {
        try {
          return typeof teacher.grades === 'string'
            ? JSON.parse(teacher.grades || '[]')
            : Array.isArray(teacher.grades)
            ? teacher.grades
            : [];
        } catch {
          return [];
        }
      })();

      const createdLessons: any[] = [];
      const createdQuizzes: any[] = [];
      const curriculumSyncResults: Array<{ synced: boolean; subjectId?: string; chapterId?: string }> = [];

      for (const pdf of targetPdfs) {
        const blobBase64 = await repo.getSystemSetting(`${PDF_BLOB_PREFIX}${pdf.id}`);
        if (!blobBase64) {
          throw new PdfFeedApiError(
            `بيانات ملف PDF (${pdf.fileName}) غير متوفرة في قاعدة البيانات. أعد رفعه من فضلك.`,
            404,
            'PDF_BLOB_NOT_FOUND'
          );
        }

        const effectiveSubject = String(
          overrideSubject || pdf.subject || teacher.specialty || 'المادة الدراسية'
        ).trim();
        const effectiveGrade = String(
          overrideGrade || pdf.grade || parsedTeacherGrades[0] || 'الصف الثاني الثانوي'
        ).trim();

        const extracted = await extractCurriculumAndQuizFromPdf({
          pdfBase64: blobBase64,
          fileName: pdf.fileName,
          teacherName: teacher.name,
          subject: effectiveSubject,
          grade: effectiveGrade,
          lessonCount: Number(lessonCount) || 4,
          questionsCount: Number(questionsCount) || 10,
        });

        const pdfDocUrl = `/api/teachers/${teacher.id}/pdfs/${pdf.id}/file`;
        const lessonsForThisPdf: any[] = [];

        for (let idx = 0; idx < extracted.lessons.length; idx++) {
          const item = extracted.lessons[idx];
          const lessonPayload = {
            id: `les-pdf-${Date.now()}-${idx + 1}-${Math.random().toString(36).slice(2, 5)}`,
            title: item.title,
            titleEn: item.titleEn,
            subject: effectiveSubject,
            grade: effectiveGrade,
            teacherId: teacher.id,
            teacherName: teacher.name,
            format: 'pdf',
            durationOrPages: item.pageRange
              ? `${item.durationMinutes} دقيقة · ${item.pageRange}`
              : `${item.durationMinutes} دقيقة`,
            documentUrl: pdfDocUrl,
            description: item.summary,
            unit: extracted.unitTitle,
            contentHtml: buildFormattedLessonHtml({
              title: item.title,
              unit: extracted.unitTitle,
              summary: item.summary,
              keyPoints: item.keyPoints,
              pageRange: item.pageRange,
              fileName: pdf.fileName,
            }),
            isPublished: true,
            viewsCount: 0,
            likesCount: 0,
          };

          const createdLesson = await repo.createLesson(lessonPayload);
          lessonsForThisPdf.push(createdLesson);
          createdLessons.push(createdLesson);
          deps.broadcastAll({ type: 'lesson:created', lesson: createdLesson });
        }

        const formattedQuestions = extracted.questions.map((q, qIdx) => {
          const linkedLesson =
            lessonsForThisPdf[q.sourceLessonIndex] || lessonsForThisPdf[0] || null;
          return {
            id: `q-pdf-${Date.now()}-${qIdx + 1}`,
            questionType: q.questionType,
            question: q.question,
            options: q.options,
            correctOptionIndex: q.correctOptionIndex,
            explanation: q.explanation,
            points: 2,
            sourcePdfPage: q.sourcePdfPage,
            sourceLessonId: linkedLesson?.id,
            sourceLessonTitle: linkedLesson?.title,
            sourceFormat: 'pdf' as const,
          };
        });

        const cleanPdfTitle = pdf.fileName.replace(/\.pdf$/i, '').trim();
        const quizPayload = {
          id: `qz-pdf-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          title: `اختبار تلقائي: ${extracted.unitTitle} (${cleanPdfTitle})`,
          subject: effectiveSubject,
          grade: effectiveGrade,
          type: quizType === 'monthly' ? 'monthly' : 'weekly',
          durationMinutes: Math.max(15, formattedQuestions.length * 2),
          totalMarks: formattedQuestions.length * 2,
          questions: formattedQuestions,
          pdfSourceFile: pdf.fileName,
          isRandomized: true,
          instantExplanation: true,
          teacherId: teacher.id,
          teacherName: teacher.name,
        };

        const createdQuiz = await repo.createQuiz(quizPayload);
        createdQuizzes.push(createdQuiz);
        deps.broadcastAll({ type: 'quiz:created', quiz: createdQuiz });

        let syncedChapterId: string | undefined;
        if (alsoSyncCurriculumPath !== false) {
          const targetSubjId = mapGradeToCurriculumSubjectId(effectiveGrade);
          if (targetSubjId) {
            const chapterId = `ch-tpdf-${pdf.id}`;
            const chapterObj = buildCurriculumChapterFromExtracted({
              chapterId,
              order: 1,
              term: term === 2 ? 2 : 1,
              pdfName: pdf.fileName,
              extracted,
            });
            const syncRes = await appendCurriculumChapterFromPdfFeed({
              subjectId: targetSubjId,
              chapter: chapterObj,
            });
            curriculumSyncResults.push(syncRes);
            if (syncRes.synced) syncedChapterId = syncRes.chapterId;
          }
        }

        // Mark PDF metadata as fed
        const metaIdx = allPdfs.findIndex((p) => p.id === pdf.id);
        if (metaIdx >= 0) {
          allPdfs[metaIdx] = {
            ...allPdfs[metaIdx],
            subject: effectiveSubject,
            grade: effectiveGrade,
            status: 'fed',
            fedAt: new Date().toISOString(),
            fedLessonsCount: lessonsForThisPdf.length,
            fedQuizId: createdQuiz.id,
            fedQuestionsCount: formattedQuestions.length,
            fedChapterId: syncedChapterId,
          };
        }
      }

      await saveAllPdfMetadata(allPdfs);

      // Update teacher activeLessonsCount in DB
      const allDbLessons = await repo.getAllLessons();
      const teacherLessonCount = allDbLessons.filter(
        (l: any) => l.teacherId === teacher.id || l.teacherName === teacher.name
      ).length;
      const updatedTeacher = await repo.updateTeacher(teacher.id, {
        activeLessonsCount: Math.max(
          Number(teacher.activeLessonsCount || 0) + createdLessons.length,
          teacherLessonCount
        ),
      });
      deps.broadcastAll({ type: 'teacher:updated', teacher: updatedTeacher });

      const updatedTeacherPdfs = allPdfs.filter((p) => p.teacherId === teacher.id);
      deps.broadcastAll({
        type: 'teacher_pdfs:updated',
        teacherId: teacher.id,
        pdfs: updatedTeacherPdfs,
      });

      // Notify Students & Parents + Audit Log
      try {
        const autoNotif = await repo.createNotification({
          title: `📚📝 دروس واختبار تلقائي جديد من (${teacher.name})`,
          message: `قام المعلم ${teacher.name} بتغذية ${createdLessons.length} دروس و${createdQuizzes.length} اختباراً آلياً من ملفات PDF المرفوعة.`,
          target: 'students_parents',
          category: 'academic',
          relatedType: 'lesson',
          relatedId: createdLessons[0]?.id || '',
        });
        deps.broadcastAll({ type: 'notification:created', notification: autoNotif });
        await deps.dispatchWebPushNotification({
          title: autoNotif.title,
          body: autoNotif.message,
          target: 'students_parents',
          url: '/',
          tag: `teacher-pdf-feed-${teacher.id}`,
        });
        await repo.createAuditLog({
          action: 'teacher_pdf_auto_feed',
          actionAr: 'تغذية الدروس والاختبارات تلقائياً من PDF',
          entityType: 'teacher',
          entityName: teacher.name,
          performedBy: getUserName(req) || teacher.name,
          details: `توليد ${createdLessons.length} دروس و${createdQuizzes.reduce(
            (sum, q) =>
              sum +
              (Array.isArray(q.questions)
                ? q.questions.length
                : typeof q.questions === 'string'
                ? JSON.parse(q.questions || '[]').length
                : 0),
            0
          )} سؤال اختبار تلقائياً من ${targetPdfs.length} ملف PDF.`,
          severity: 'info',
        });
      } catch (notifErr) {
        console.warn('Auto feed notification warning:', notifErr);
      }

      res.json({
        ok: true,
        teacherId: teacher.id,
        updatedTeacher,
        pdfs: updatedTeacherPdfs,
        createdLessons,
        createdQuizzes,
        curriculumSynced: curriculumSyncResults.filter((r) => r.synced),
      });
    } catch (err: any) {
      if (err instanceof PdfFeedApiError) {
        return res.status(err.statusCode).json({ error: err.message, code: err.code });
      }
      res.status(500).json({ error: err?.message || 'تعذر تشغيل تغذية الدروس والاختبارات' });
    }
  });

  return router;
}
