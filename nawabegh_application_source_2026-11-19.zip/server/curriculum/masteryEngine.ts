import type {
  CurriculumMcqQuestion,
  DigitalAwardInfo,
  StudentSubjectProgress,
} from '../../src/types/curriculum.ts';

export const ALLOWED_MISSED_MARKS = 2;

export function gradeMcqSubmission(
  questions: CurriculumMcqQuestion[],
  selectedAnswers: number[]
): { score: number; totalQuestions: number; missedMarks: number; passed: boolean; mustRestudyChapter: boolean } {
  const totalQuestions = questions.length;
  let score = 0;

  for (let i = 0; i < questions.length; i++) {
    if (selectedAnswers[i] === questions[i].correctIndex) {
      score += 1;
    }
  }

  const missedMarks = Math.max(0, totalQuestions - score);
  const passed = missedMarks <= ALLOWED_MISSED_MARKS;
  const mustRestudyChapter = missedMarks > ALLOWED_MISSED_MARKS;

  return {
    score,
    totalQuestions,
    missedMarks,
    passed,
    mustRestudyChapter,
  };
}

export function applyChapterReviewOutcome(opts: {
  progress: StudentSubjectProgress;
  chapterId: string;
  chapterLessonIds: string[];
  questions: CurriculumMcqQuestion[];
  selectedAnswers: number[];
}): {
  updatedProgress: StudentSubjectProgress;
  result: {
    score: number;
    totalQuestions: number;
    missedMarks: number;
    passed: boolean;
    mustRestudyChapter: boolean;
    message: string;
  };
} {
  const graded = gradeMcqSubmission(opts.questions, opts.selectedAnswers);
  const next: StudentSubjectProgress = {
    completedLessonIds: [...(opts.progress.completedLessonIds || [])],
    completedChapterIds: [...(opts.progress.completedChapterIds || [])],
    restudyRequiredChapterIds: [...(opts.progress.restudyRequiredChapterIds || [])],
    passedCumulativeIds: [...(opts.progress.passedCumulativeIds || [])],
    chapterScores: { ...(opts.progress.chapterScores || {}) },
    cumulativeScores: { ...(opts.progress.cumulativeScores || {}) },
    totalXp: Number(opts.progress.totalXp || 0),
  };

  next.chapterScores[opts.chapterId] = {
    score: graded.score,
    total: graded.totalQuestions,
    missedMarks: graded.missedMarks,
    passed: graded.passed,
    timestamp: new Date().toISOString(),
  };

  if (graded.passed) {
    if (!next.completedChapterIds.includes(opts.chapterId)) {
      next.completedChapterIds.push(opts.chapterId);
      next.totalXp += 40 + graded.score * 5;
    } else {
      next.totalXp += 10;
    }
    next.restudyRequiredChapterIds = next.restudyRequiredChapterIds.filter(
      (id) => id !== opts.chapterId
    );

    const message =
      graded.missedMarks === 0
        ? 'ممتاز! حصلت على الدرجة النهائية في مراجعة الفصل وتم فتح المرحلة التالية.'
        : `أحسنت! نقصت ${graded.missedMarks === 1 ? 'درجة واحدة' : 'درجتين'} فقط (ضمن الحد المسموح)، واجتزت مراجعة الفصل بنجاح.`;

    return {
      updatedProgress: next,
      result: { ...graded, message },
    };
  }

  // More than 2 marks missed -> MUST restudy the entire chapter from Lesson 1!
  const lessonSet = new Set(opts.chapterLessonIds);
  next.completedLessonIds = next.completedLessonIds.filter((lid) => !lessonSet.has(lid));
  next.completedChapterIds = next.completedChapterIds.filter((cid) => cid !== opts.chapterId);
  if (!next.restudyRequiredChapterIds.includes(opts.chapterId)) {
    next.restudyRequiredChapterIds.push(opts.chapterId);
  }

  return {
    updatedProgress: next,
    result: {
      ...graded,
      message: `نقصت ${graded.missedMarks} درجات (أكثر من درجتين المسموح بهما) — يرجى إعادة مذاكرة الفصل بالكامل من الدرس الأول قبل إعادة المراجعة.`,
    },
  };
}

export function computeDigitalAwardFromXp(
  xp: number,
  extraBadges: string[] = []
): DigitalAwardInfo {
  const safeXp = Math.max(0, Math.round(xp));
  const unlockedTitles = [...extraBadges];

  if (safeXp >= 300) {
    if (!unlockedTitles.includes('تاج الشريف البلاتيني')) unlockedTitles.unshift('تاج الشريف البلاتيني');
    return {
      id: 'award-platinum',
      title: 'تاج الشريف البلاتيني للتميز',
      tier: 'platinum',
      points: safeXp,
      unlockedTitles,
    };
  }
  if (safeXp >= 150) {
    if (!unlockedTitles.includes('درع التفوق الذهبي')) unlockedTitles.unshift('درع التفوق الذهبي');
    return {
      id: 'award-gold',
      title: 'درع التفوق الذهبي',
      tier: 'gold',
      points: safeXp,
      nextTierTitle: 'تاج الشريف البلاتيني للتميز',
      nextTierPoints: 300,
      unlockedTitles,
    };
  }
  if (safeXp >= 50) {
    if (!unlockedTitles.includes('وسام المثابر الفضي')) unlockedTitles.unshift('وسام المثابر الفضي');
    return {
      id: 'award-silver',
      title: 'وسام المثابر الفضي',
      tier: 'silver',
      points: safeXp,
      nextTierTitle: 'درع التفوق الذهبي',
      nextTierPoints: 150,
      unlockedTitles,
    };
  }

  if (!unlockedTitles.includes('وسام مستكشف المعرفة')) unlockedTitles.unshift('وسام مستكشف المعرفة');
  return {
    id: 'award-bronze',
    title: 'وسام مستكشف المعرفة (المستوى التأسيسي)',
    tier: 'bronze',
    points: safeXp,
    nextTierTitle: 'وسام المثابر الفضي',
    nextTierPoints: 50,
    unlockedTitles,
  };
}
