import React, { useState, useEffect } from 'react';
import { X, Save, AlertCircle } from 'lucide-react';
import { Lesson, Language, Teacher } from '../types';
import { OfficeCKEditor } from './OfficeCKEditor';

interface CKEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveLesson: (lessonData: {
    id?: string;
    title: string;
    subject: string;
    grade: string;
    teacherId: string;
    teacherName: string;
    unit: string;
    description: string;
    contentHtml: string;
    format: 'pdf' | 'word';
    durationOrPages: string;
  }) => void;
  teachers: Teacher[];
  language: Language;
  initialLesson?: Lesson | null;
}

export const CKEditorModal: React.FC<CKEditorModalProps> = ({
  isOpen,
  onClose,
  onSaveLesson,
  teachers,
  language,
  initialLesson,
}) => {
  const isAr = language === 'ar';

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('الرياضيات');
  const [grade, setGrade] = useState('الصف الثالث الثانوي');
  const [teacherId, setTeacherId] = useState(teachers[0]?.id || '');
  const [unit, setUnit] = useState('');
  const [outputFormat, setOutputFormat] = useState<'pdf' | 'word'>('pdf');
  const [editorContent, setEditorContent] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setValidationError(null);

    if (initialLesson) {
      setTitle(initialLesson.title || '');
      setSubject(initialLesson.subject || 'الرياضيات');
      setGrade(initialLesson.grade || 'الصف الثالث الثانوي');
      setTeacherId(initialLesson.teacherId || teachers[0]?.id || '');
      setUnit(initialLesson.unit || '');
      setOutputFormat(initialLesson.format === 'word' ? 'word' : 'pdf');
      setEditorContent(initialLesson.contentHtml || '');
    } else {
      setTitle('');
      setSubject('الرياضيات');
      setGrade('الصف الثالث الثانوي');
      setTeacherId(teachers[0]?.id || '');
      setUnit('');
      setOutputFormat('pdf');
      setEditorContent('');
    }
  }, [isOpen, initialLesson, teachers]);

  if (!isOpen) return null;

  const plainText = editorContent
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .trim();
  const wordsCount = plainText ? plainText.split(/\s+/).filter(Boolean).length : 0;

  const teacherName = teachers.find((t) => t.id === teacherId)?.name || 'مدرس المادة';

  const handleSave = () => {
    const cleanTitle = title.trim();
    if (!cleanTitle) {
      setValidationError(isAr ? 'يرجى إدخال عنوان الدرس قبل الحفظ' : 'Please enter a lesson title');
      return;
    }
    const snippet = plainText.slice(0, 140) || 'محتوى درس أكاديمي مكتوب.';

    onSaveLesson({
      id: initialLesson?.id,
      title: cleanTitle,
      subject,
      grade,
      teacherId,
      teacherName,
      unit: unit.trim() || 'الوحدة الأولى',
      description: snippet,
      contentHtml: editorContent,
      format: outputFormat,
      durationOrPages:
        outputFormat === 'word'
          ? `مستند Word (${wordsCount} كلمة)`
          : `مستند PDF أكاديمي (${wordsCount} كلمة)`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-4 bg-slate-950/80 backdrop-blur-xs font-cairo">
      <div className="w-full max-w-6xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[96dvh] h-[94dvh] flex flex-col">
        {/* Top Editor Header */}
        <div className="p-3.5 md:p-4 bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border-b border-emerald-800 text-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md">
              📝
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm md:text-base">
                  {isAr
                    ? 'شاشة كتابة الدرس كاملا (أدوات تحرير متكاملة + انفوجرافيك)'
                    : 'Full Lesson Writing Screen'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  {isAr ? 'شريط الأدوات' : 'Editor Ribbon'}
                </span>
              </div>
              <p className="text-[11px] text-emerald-200/80 font-tajawal">
                {isAr
                  ? 'أدوات تحرير وتنسيق متكاملة + جداول تفاعلية + إدراج بلوكات انفوجرافيك + تصدير Word و PDF'
                  : 'Full editing ribbon, live tables, infographic blocks & Word/PDF export'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-sm cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>
                {initialLesson
                  ? isAr
                    ? 'حفظ التعديلات'
                    : 'Update Lesson'
                  : isAr
                  ? 'حفظ ونشر الدرس'
                  : 'Save & Publish'}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-emerald-200 hover:text-white hover:bg-white/10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Validation Alert */}
        {validationError && (
          <div className="px-4 py-2 bg-rose-50 dark:bg-rose-950/70 border-b border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Lesson Metadata Strip */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2 text-xs shrink-0">
          <div className="lg:col-span-2">
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'عنوان الدرس *' : 'Lesson Title *'}
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setValidationError(null);
              }}
              placeholder={isAr ? 'اكتب عنوان الدرس هنا...' : 'Enter lesson title...'}
              className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-semibold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'المادة' : 'Subject'}
            </label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              <option value="الرياضيات">الرياضيات</option>
              <option value="الفيزياء">الفيزياء</option>
              <option value="الكيمياء">الكيمياء</option>
              <option value="الأحياء">الأحياء</option>
              <option value="اللغة العربية">اللغة العربية</option>
              <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
              <option value="الحاسب الآلي">الحاسب الآلي</option>
              <option value="التربية الإسلامية">التربية الإسلامية</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'المرحلة' : 'Grade'}
            </label>
            <select
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              <option value="الصف الأول الثانوي">الصف الأول الثانوي</option>
              <option value="الصف الثاني الثانوي">الصف الثاني الثانوي</option>
              <option value="الصف الثالث الثانوي">الصف الثالث الثانوي</option>
              <option value="الشهادة الإعدادية">الشهادة الإعدادية</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'المعلم' : 'Teacher'}
            </label>
            <select
              value={teacherId}
              onChange={(e) => setTeacherId(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              {teachers.length === 0 ? (
                <option value="">{isAr ? '-- بدون معلم مسجل --' : '-- No Teacher --'}</option>
              ) : (
                teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))
              )}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'الوحدة / الصيغة' : 'Unit / Format'}
            </label>
            <div className="flex gap-1">
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder={isAr ? 'الوحدة...' : 'Unit...'}
                className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-tajawal"
              />
              <select
                value={outputFormat}
                onChange={(e) => setOutputFormat(e.target.value as 'pdf' | 'word')}
                className="px-1.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
              >
                <option value="pdf">PDF</option>
                <option value="word">Word</option>
              </select>
            </div>
          </div>
        </div>

        {/* Full Embedded OfficeCKEditor */}
        <OfficeCKEditor
          value={editorContent}
          onChange={setEditorContent}
          language={language}
          documentTitle={title || (isAr ? 'وثيقة درس تعليمي' : 'Lesson Document')}
          documentMeta={`${subject} · ${grade}${unit ? ` · ${unit}` : ''}`}
          teacherName={teacherName}
        />
      </div>
    </div>
  );
};
