import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';
import { DEFAULT_TEACHER_AVATAR } from './utils/avatarFallback';

registerSW({ immediate: true });

// Global broken-image handler: any broken <img> anywhere in the app automatically falls back to the teacher avatar
window.addEventListener(
  'error',
  (event) => {
    const target = event.target as HTMLElement | null;
    if (!target || target.tagName !== 'IMG') return;
    const img = target as HTMLImageElement;
    if (img.dataset.fallbackApplied === 'true') return;
    if (img.src.includes('avatar_teacher_male_1794403366117.jpg')) return;
    img.dataset.fallbackApplied = 'true';
    img.src = DEFAULT_TEACHER_AVATAR;
  },
  true
);

createRoot(document.getElementById('root')!).render(<App />);
