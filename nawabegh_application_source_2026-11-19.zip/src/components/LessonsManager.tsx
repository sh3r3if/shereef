import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Video,
  FileText,
  FileCheck2,
  Plus,
  Search,
  Trash2,
  Edit,
  Eye,
  Play,
  Download,
  X,
  BookOpen,
  Check,
  ChevronLeft,
  ChevronRight,
  Eye as ViewsIcon,
  ThumbsUp,
  Layers,
  Sparkles,
  Printer,
  RefreshCw,
  Database,
  AlertTriangle,
  CheckCircle2,
  FileCode,
  FileSpreadsheet,
  FileJson,
  FileDown,
  Upload,
  Paperclip,
  Wand2,
  Star,
  BarChart3,
  Lock,
  KeyRound,
  Clock,
  BookmarkPlus,
  PlayCircle,
  Pause,
  Maximize2,
  Minimize2,
  Bookmark,
  Flag,
  Code2,
  MessageCircle,
  Pin,
  Focus,
  CalendarClock,
} from 'lucide-react';
import { getMcqOptionSurfaceClass, MCQ_QUESTION_BOX_CLASS } from '../utils/mcqTheme';
import {
  stripHtmlTags,
  hasHtmlMarkup,
  hasMeaningfulHtmlContent,
  buildLessonObjectivesTemplateHtml,
} from '../utils/htmlText';
import {
  CurrentUser,
  Lesson,
  LessonFormat,
  LessonRating,
  Language,
  Teacher,
  InfographicData,
  ContentSecurityConfig,
  DEFAULT_CONTENT_SECURITY_CONFIG,
  StudentCodeRedemption,
  SequentialLessonConfig,
  SequentialStudentLessonProgress,
  TimestampedLessonNote,
  ContentErrorReport,
  ContentErrorReportCategory,
  LessonDripRule,
  LessonQaQuestion,
} from '../types';
import {
  canTeacherManageLesson,
  getAuthHeaders,
  isParentRole,
  isStudentRole,
  isTeacherRole,
  resolveMatchedTeacher,
} from '../utils/rbac';
import { CKEditorModal } from './CKEditorModal';
import { InfographicLessonModal } from './InfographicLessonModal';
import { InfographicRenderer, buildInfographicEmbedHtml } from './InfographicRenderer';
import { OfficeCKEditor } from './OfficeCKEditor';
import { InfographicStudioPanel } from './InfographicStudioPanel';
import { AlSharifWatermark } from './ScreenProtectionGuard';
import { LiveCodeSandbox } from './LiveCodeSandbox';
import { exportLessonNotesToPdf } from '../utils/notesPdfExport';
import { ZenStudyOverlay } from './ZenStudyOverlay';

interface LessonsManagerProps {
  lessons: Lesson[];
  teachers: Teacher[];
  lessonRatings?: LessonRating[];
  currentUser?: CurrentUser | null;
  onAddLesson: (lesson: Lesson | Omit<Lesson, 'id' | 'createdAt' | 'viewsCount' | 'likesCount'>) => void;
  onUpdateLesson: (lesson: Lesson) => void;
  onDeleteLesson: (id: string) => void;
  onRatingSubmitted?: (rating: LessonRating) => void;
  onRatingDeleted?: (id: string) => void;
  language: Language;
}

const AVAILABLE_SUBJECTS = [
  'الرياضيات',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'اللغة الإنجليزية',
  'اللغة العربية',
  'الحاسب الآلي',
  'التربية الإسلامية',
];

const AVAILABLE_GRADES = [
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
  'الشهادة الإعدادية',
];

const parseLessonRecord = (raw: any): Lesson => {
  let parsedInfo = raw.infographicData;
  if (typeof raw.infographicData === 'string' && raw.infographicData.trim()) {
    try {
      parsedInfo = JSON.parse(raw.infographicData);
    } catch {
      parsedInfo = undefined;
    }
  }
  return {
    ...raw,
    infographicData: parsedInfo || undefined,
  };
};

const createStarterInfographic = (title: string): InfographicData => ({
  template: 'steps',
  themeColor: 'emerald',
  surfaceStyle: 'modern',
  columns: 2,
  showNumbers: true,
  summary: title
    ? `ملخص بصري تفاعلي لأهم محاور ومفاهيم درس: ${title}`
    : 'ملخص بصري تفاعلي يوضح أبرز النقاط والقوانين والخطوات العملية للدرس.',
  sections: [
    {
      id: `sec-${Date.now()}-1`,
      title: 'المفهوم التمهيدي للدرس',
      description: 'شرح الفكرة الجوهرية والهدف التعليمي الرئيسي من هذا الدرس.',
      value: '01',
      color: '#059669',
      iconName: 'book',
    },
    {
      id: `sec-${Date.now()}-2`,
      title: 'القاعدة أو القانون الأساسي',
      description: 'الصياغة العلمية أو الرياضية القياسية مع تفسير المتغيرات.',
      value: '02',
      color: '#2563eb',
      iconName: 'calc',
    },
    {
      id: `sec-${Date.now()}-3`,
      title: 'نموذج تطبيقي محلول',
      description: 'تطبيق مباشر خطوة بخطوة لتثبيت المهارة لدى الطالب.',
      value: '03',
      color: '#d97706',
      iconName: 'lightbulb',
    },
    {
      id: `sec-${Date.now()}-4`,
      title: 'خلاصة ونقاط المراجعة',
      description: 'أهم التنبيهات لتفادي الأخطاء الشائعة في الاختبار.',
      value: '04',
      color: '#7c3aed',
      iconName: 'award',
    },
  ],
});

export const LessonsManager: React.FC<LessonsManagerProps> = ({
  lessons: propLessons,
  teachers,
  lessonRatings: propLessonRatings,
  currentUser = null,
  onAddLesson,
  onUpdateLesson,
  onDeleteLesson,
  onRatingSubmitted,
  onRatingDeleted,
  language,
}) => {
  const isAr = language === 'ar';
  const role = currentUser?.role;
  const isTeacher = isTeacherRole(role);
  const isParent = isParentRole(role);
  const isStudent = isStudentRole(role);
  const canModerateRatings =
    Boolean(currentUser?.isSuperAdmin) || role === 'admin' || role === 'supervisor';
  const canSubmitSurvey = isStudent || canModerateRatings;
  const canCreateLessons =
    Boolean(currentUser?.isSuperAdmin) ||
    role === 'admin' ||
    role === 'supervisor' ||
    role === 'teacher';
  const matchedTeacher = useMemo(
    () => resolveMatchedTeacher(currentUser, teachers),
    [currentUser, teachers]
  );
  const canManageLessonItem = (lesson: Lesson) =>
    canTeacherManageLesson(lesson, currentUser, teachers);

  const [lessonsList, setLessonsList] = useState<Lesson[]>(propLessons);
  const [ratingsList, setRatingsList] = useState<LessonRating[]>(propLessonRatings || []);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<{
    text: string;
    type: 'success' | 'info' | 'error';
  } | null>(null);

  useEffect(() => {
    setLessonsList(propLessons);
  }, [propLessons]);

  useEffect(() => {
    if (propLessonRatings) {
      setRatingsList(propLessonRatings);
    }
  }, [propLessonRatings]);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Search, Filters, Pagination
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFormat, setSelectedFormat] = useState<'all' | LessonFormat>('all');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(6);

  // Modals State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isCKEditorOpen, setIsCKEditorOpen] = useState(false);
  const [ckEditorEditingLesson, setCkEditorEditingLesson] = useState<Lesson | null>(null);
  const [isInfographicOpen, setIsInfographicOpen] = useState(false);
  const [infographicEditingLesson, setInfographicEditingLesson] = useState<Lesson | null>(null);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [viewingLesson, setViewingLesson] = useState<Lesson | null>(null);
  const [lessonToDelete, setLessonToDelete] = useState<Lesson | null>(null);
  const [isRatingsReportOpen, setIsRatingsReportOpen] = useState(false);

  // Bookmarks, Live Code Sandbox & Content Error Reports State
  const [bookmarkedLessonIds, setBookmarkedLessonIds] = useState<string[]>([]);
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  const [isLessonSandboxOpen, setIsLessonSandboxOpen] = useState(false);
  const [reportingLesson, setReportingLesson] = useState<Lesson | null>(null);
  const [reportCategory, setReportCategory] = useState<ContentErrorReportCategory>('needs_clarification');
  const [reportDetails, setReportDetails] = useState('');
  const [isSubmittingReport, setIsSubmittingReport] = useState(false);
  const [contentReports, setContentReports] = useState<ContentErrorReport[]>([]);
  const [isReportsQueueOpen, setIsReportsQueueOpen] = useState(false);

  // Drip Content Rules, Zen Mode & Lesson Q&A Thread
  const [dripRulesMap, setDripRulesMap] = useState<Record<string, LessonDripRule>>({});
  const [formDripDate, setFormDripDate] = useState('');
  const [formDripDays, setFormDripDays] = useState<number>(0);
  const [formPrereqLessonId, setFormPrereqLessonId] = useState('');
  const [formPrereqMinScore, setFormPrereqMinScore] = useState<number>(70);
  const [isZenStudyOpen, setIsZenStudyOpen] = useState(false);
  const [lessonQaList, setLessonQaList] = useState<LessonQaQuestion[]>([]);
  const [qaInputText, setQaInputText] = useState('');
  const [qaLinkVideoTime, setQaLinkVideoTime] = useState(true);
  const [qaAnswerDrafts, setQaAnswerDrafts] = useState<Record<string, string>>({});
  const [isSubmittingQa, setIsSubmittingQa] = useState(false);

  // Content Security & Activation Code Gating State
  const [securityConfig, setSecurityConfig] = useState<ContentSecurityConfig>(
    DEFAULT_CONTENT_SECURITY_CONFIG
  );
  const [studentRedemptions, setStudentRedemptions] = useState<StudentCodeRedemption[]>([]);
  const [lockedLessonPrompt, setLockedLessonPrompt] = useState<Lesson | null>(null);
  const [quickActivationCode, setQuickActivationCode] = useState('');
  const [isRedeemingCode, setIsRedeemingCode] = useState(false);

  // Sequential Lesson Locking (شرط اجتياز الاختبار لفتح الدرس التالي)
  const [sequentialConfig, setSequentialConfig] = useState<SequentialLessonConfig>({
    enabled: true,
    minimumPassPercentage: 70,
    scopeBySubjectAndGrade: true,
  });
  const [sequentialProgressMap, setSequentialProgressMap] = useState<
    Record<string, SequentialStudentLessonProgress>
  >({});
  const [isSavingSeqConfig, setIsSavingSeqConfig] = useState(false);
  const [sequentialBlockedPrompt, setSequentialBlockedPrompt] = useState<{
    targetLesson: Lesson;
    prerequisiteLesson: Lesson;
    currentBestPct: number;
  } | null>(null);
  const [masteryQuizLesson, setMasteryQuizLesson] = useState<Lesson | null>(null);
  const [masteryAnswers, setMasteryAnswers] = useState<Record<number, number>>({});
  const [masteryResult, setMasteryResult] = useState<{
    scorePct: number;
    passed: boolean;
    earned: number;
    total: number;
  } | null>(null);
  const [isSubmittingMastery, setIsSubmittingMastery] = useState(false);

  // Timestamped Video Notes State (مفكرة ملاحظات الطالب المرتبطة بدقيقة الفيديو)
  const lessonVideoRef = useRef<HTMLVideoElement | null>(null);
  const youtubeIframeRef = useRef<HTMLIFrameElement | null>(null);
  const videoContainerRef = useRef<HTMLDivElement | null>(null);
  const [videoNotes, setVideoNotes] = useState<TimestampedLessonNote[]>([]);
  const [noteInputText, setNoteInputText] = useState('');
  const [currentVideoSeconds, setCurrentVideoSeconds] = useState(0);
  const [manualMmSsInput, setManualMmSsInput] = useState('');
  const [isSavingVideoNote, setIsSavingVideoNote] = useState(false);
  const [youtubeSeekSeconds, setYoutubeSeekSeconds] = useState<number>(0);
  const [isWatchTimerRunning, setIsWatchTimerRunning] = useState<boolean>(false);

  const formatSecondsMmSs = (sec: number) => {
    const safe = Math.max(0, Math.floor(sec || 0));
    const m = Math.floor(safe / 60);
    const s = safe % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const parseMmSsInput = (val: string): number | null => {
    const clean = val.trim();
    if (!clean) return null;
    if (/^\d+$/.test(clean)) return Math.max(0, Number(clean));
    const parts = clean.split(':').map((p) => Number(p));
    if (parts.length === 2 && !Number.isNaN(parts[0]) && !Number.isNaN(parts[1])) {
      return Math.max(0, parts[0] * 60 + parts[1]);
    }
    return null;
  };

  const buildYouTubeEmbedSrc = (rawUrl: string, startSec: number) => {
    try {
      let videoId = '';
      if (rawUrl.includes('youtu.be/')) {
        videoId = rawUrl.split('youtu.be/')[1].split(/[?&/]/)[0];
      } else if (rawUrl.includes('youtube.com/watch')) {
        const u = new URL(rawUrl);
        videoId = u.searchParams.get('v') || '';
      } else if (rawUrl.includes('youtube.com/embed/')) {
        videoId = rawUrl.split('youtube.com/embed/')[1].split(/[?&/]/)[0];
      }
      if (!videoId) return rawUrl;
      const params = new URLSearchParams({
        enablejsapi: '1',
        rel: '0',
      });
      if (startSec > 0) {
        params.set('start', String(startSec));
        params.set('autoplay', '1');
      }
      return `https://www.youtube.com/embed/${videoId}?${params.toString()}`;
    } catch {
      return rawUrl;
    }
  };

  useEffect(() => {
    if (!viewingLesson) {
      setVideoNotes([]);
      setIsWatchTimerRunning(false);
      setCurrentVideoSeconds(0);
      setYoutubeSeekSeconds(0);
      setManualMmSsInput('');
      return;
    }
    setCurrentVideoSeconds(0);
    setYoutubeSeekSeconds(0);
    setManualMmSsInput('');
    const isYt = Boolean(
      viewingLesson.videoUrl &&
        (viewingLesson.videoUrl.includes('youtube') || viewingLesson.videoUrl.includes('youtu.be'))
    );
    setIsWatchTimerRunning(viewingLesson.format === 'video' && (isYt || !viewingLesson.videoUrl));

    const sid = String(currentUser?.studentId || currentUser?.id || '').trim();
    fetch(
      `/api/lesson-notes?lessonId=${encodeURIComponent(viewingLesson.id)}${
        isStudent && sid ? `&studentId=${encodeURIComponent(sid)}` : ''
      }`
    )
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (Array.isArray(data?.notes)) {
          setVideoNotes(data.notes);
        }
      })
      .catch(() => {});

    fetch(`/api/lesson-qa?lessonId=${encodeURIComponent(viewingLesson.id)}`)
      .then((r) => (r.ok ? r.json() : []))
      .then((list) => {
        setLessonQaList(Array.isArray(list) ? list : []);
      })
      .catch(() => setLessonQaList([]));
  }, [viewingLesson?.id]);

  // Watch timer fallback for YouTube embeds / stream lectures without native <video> currentTime
  useEffect(() => {
    if (!viewingLesson || !isWatchTimerRunning) return;
    const interval = window.setInterval(() => {
      setCurrentVideoSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [viewingLesson?.id, isWatchTimerRunning]);

  const handleSaveTimestampedNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!viewingLesson || !noteInputText.trim()) return;
    setIsSavingVideoNote(true);
    try {
      const parsedManual = parseMmSsInput(manualMmSsInput);
      const targetSec = parsedManual !== null ? parsedManual : currentVideoSeconds;
      const sid = String(currentUser?.studentId || currentUser?.id || 'guest').trim();
      const res = await fetch('/api/lesson-notes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          lessonId: viewingLesson.id,
          lessonTitle: viewingLesson.title,
          subject: viewingLesson.subject,
          studentId: sid,
          studentName: currentUser?.name || 'طالب',
          timestampSeconds: targetSec,
          noteText: noteInputText.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر حفظ الملاحظة');
      if (data.note) {
        setVideoNotes((prev) => [data.note, ...prev]);
      }
      setNoteInputText('');
      setManualMmSsInput('');
      showToast(
        isAr
          ? `تم حفظ الملاحظة عند الدقيقة (${formatSecondsMmSs(targetSec)}) ✓`
          : `Saved note at ${formatSecondsMmSs(targetSec)} ✓`,
        'success'
      );
    } catch (err: any) {
      showToast(err.message || 'تعذر حفظ الملاحظة', 'error');
    } finally {
      setIsSavingVideoNote(false);
    }
  };

  const handleSeekToVideoTimestamp = (seconds: number) => {
    const safeSec = Math.max(0, Math.floor(seconds || 0));
    setCurrentVideoSeconds(safeSec);
    if (lessonVideoRef.current) {
      lessonVideoRef.current.currentTime = safeSec;
      lessonVideoRef.current.play().catch(() => {});
    } else if (youtubeIframeRef.current) {
      try {
        youtubeIframeRef.current.contentWindow?.postMessage(
          JSON.stringify({ event: 'command', func: 'seekTo', args: [safeSec, true] }),
          '*'
        );
        youtubeIframeRef.current.contentWindow?.postMessage(
          JSON.stringify({ event: 'command', func: 'playVideo', args: [] }),
          '*'
        );
      } catch {
        // ignore cross-origin postMessage error
      }
      setYoutubeSeekSeconds(safeSec);
    }
    videoContainerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    showToast(
      isAr
        ? `تم الانتقال إلى الدقيقة (${formatSecondsMmSs(safeSec)}) في الفيديو ▶`
        : `Jumped to ${formatSecondsMmSs(safeSec)} ▶`,
      'info'
    );
  };

  const handleDeleteTimestampedNote = async (noteId: string) => {
    try {
      const res = await fetch(`/api/lesson-notes/${encodeURIComponent(noteId)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setVideoNotes((prev) => prev.filter((n) => n.id !== noteId));
        showToast(isAr ? 'تم حذف الملاحظة' : 'Note deleted', 'info');
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetch('/api/content-security/state')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.config) {
          setSecurityConfig({ ...DEFAULT_CONTENT_SECURITY_CONFIG, ...data.config });
        }
        if (Array.isArray(data?.redemptions)) {
          setStudentRedemptions(data.redemptions);
        }
      })
      .catch(() => {});

    fetch('/api/sequential-lessons/state')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.config) {
          setSequentialConfig((prev) => ({ ...prev, ...data.config }));
        }
        if (data?.progressMap && typeof data.progressMap === 'object') {
          setSequentialProgressMap(data.progressMap);
        }
      })
      .catch(() => {});
  }, []);

  const isLessonUnlockedByCode = (lesson: Lesson): boolean => {
    if (!currentUser) return false;
    if (
      currentUser.isSuperAdmin ||
      currentUser.role === 'admin' ||
      currentUser.role === 'teacher' ||
      currentUser.role === 'supervisor' ||
      currentUser.role === 'secretary'
    ) {
      return true;
    }
    const sid = currentUser.studentId || currentUser.id;
    const now = Date.now();
    return studentRedemptions.some((r) => {
      if (r.studentId !== sid && r.studentName !== currentUser.name) return false;
      if (new Date(r.expiresAt).getTime() < now) return false;
      if (r.scope === 'monthly' || r.scope === 'semester' || r.scope === 'full_vip') {
        const subjMatch = !r.targetSubject && !r.subject ? true : (r.targetSubject || r.subject) === lesson.subject;
        return subjMatch;
      }
      if (r.scope === 'subject' && (r.targetSubject || r.subject) === lesson.subject) return true;
      if (r.scope === 'lesson' && (r.targetLessonId || r.lessonId) === lesson.id) return true;
      if (r.scope === 'trial_48h') {
        const subjOk = !(r.targetSubject || r.subject) || (r.targetSubject || r.subject) === lesson.subject;
        const unitStr = String(lesson.unit || '').trim();
        const isFirstUnit =
          !unitStr ||
          unitStr.includes('الأول') ||
          unitStr.includes('1') ||
          lessonsList.filter((l) => l.subject === lesson.subject && l.grade === lesson.grade)[0]?.id === lesson.id;
        return subjOk && isFirstUnit;
      }
      return false;
    });
  };

  const isLessonLockedForCurrentUser = (lesson: Lesson): boolean => {
    if (
      currentUser?.isSuperAdmin ||
      currentUser?.role === 'admin' ||
      currentUser?.role === 'teacher' ||
      currentUser?.role === 'supervisor' ||
      currentUser?.role === 'secretary'
    ) {
      return false;
    }
    const requiresCode =
      securityConfig.requireActivationCodeForStudents ||
      securityConfig.lockedLessonIds.includes(lesson.id) ||
      securityConfig.lockedSubjects.includes(lesson.subject);
    if (!requiresCode) return false;
    return !isLessonUnlockedByCode(lesson);
  };

  // Compute sequential order & prerequisite status for each lesson
  const getLessonSequentialInfo = (lesson: Lesson) => {
    const sid = String(currentUser?.studentId || currentUser?.id || currentUser?.name || 'guest').trim();
    const sName = String(currentUser?.name || '').trim();
    const sameTrackLessons = [...lessonsList]
      .filter((l) =>
        sequentialConfig.scopeBySubjectAndGrade !== false
          ? l.subject === lesson.subject && l.grade === lesson.grade
          : l.subject === lesson.subject
      )
      .sort((a, b) => {
        const da = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const db = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        if (da !== db) return da - db;
        return String(a.id).localeCompare(String(b.id));
      });

    const orderIndex = sameTrackLessons.findIndex((l) => l.id === lesson.id);
    const prerequisiteLesson = orderIndex > 0 ? sameTrackLessons[orderIndex - 1] : null;

    const studentRec =
      sequentialProgressMap[sid] ||
      (sName ? sequentialProgressMap[sName] : undefined) ||
      Object.values(sequentialProgressMap).find(
        (r) => r.studentKey === sid || (sName && r.studentName === sName)
      );

    const watchedList = studentRec?.watchedLessonIds || [];
    const scoresMap = studentRec?.passedLessonScores || {};

    const myBestScore = Number(scoresMap[lesson.id] || 0);
    const prereqBestScore = prerequisiteLesson ? Number(scoresMap[prerequisiteLesson.id] || 0) : 100;
    const prereqWatched = prerequisiteLesson
      ? watchedList.includes(prerequisiteLesson.id) || prereqBestScore > 0
      : true;

    const isStaffBypass =
      Boolean(currentUser?.isSuperAdmin) ||
      currentUser?.role === 'admin' ||
      currentUser?.role === 'teacher' ||
      currentUser?.role === 'supervisor' ||
      currentUser?.role === 'secretary';

    const prereqPassed =
      !prerequisiteLesson ||
      (prereqWatched && prereqBestScore >= sequentialConfig.minimumPassPercentage);

    const isSequentiallyLocked =
      sequentialConfig.enabled && !isStaffBypass && orderIndex > 0 && !prereqPassed;

    return {
      orderNumber: orderIndex >= 0 ? orderIndex + 1 : 1,
      totalInTrack: sameTrackLessons.length,
      prerequisiteLesson,
      isWatched: watchedList.includes(lesson.id),
      isQuizPassed: myBestScore >= sequentialConfig.minimumPassPercentage,
      bestScorePct: myBestScore,
      prereqBestScorePct: prereqBestScore,
      isSequentiallyLocked,
    };
  };

  const handleUpdateSequentialConfig = async (patch: Partial<SequentialLessonConfig>) => {
    const nextConfig = { ...sequentialConfig, ...patch };
    setSequentialConfig(nextConfig);
    setIsSavingSeqConfig(true);
    try {
      const res = await fetch('/api/sequential-lessons/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(nextConfig),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.config) setSequentialConfig(data.config);
        showToast('تم تحديث إعدادات قفل الدروس المتسلسل بنجاح ✓', 'success');
      }
    } catch {
      showToast('تعذر حفظ إعدادات التسلسل', 'error');
    } finally {
      setIsSavingSeqConfig(false);
    }
  };

  // Build 4 real mastery questions from the database lesson content
  const buildLessonMasteryQuestions = (lesson: Lesson) => {
    const otherSubjects = AVAILABLE_SUBJECTS.filter((s) => s !== lesson.subject).slice(0, 3);
    const otherGrades = AVAILABLE_GRADES.filter((g) => g !== lesson.grade).slice(0, 3);
    const sec0 = lesson.infographicData?.sections?.[0];
    const sec1 = lesson.infographicData?.sections?.[1];

    return [
      {
        q: `ما المحور العلمي والمادة الدراسية الأساسية لدرس «${lesson.title}»؟`,
        options: [
          lesson.subject,
          otherSubjects[0] || 'الفيزياء',
          otherSubjects[1] || 'الكيمياء',
          otherSubjects[2] || 'الأحياء',
        ],
        correctIndex: 0,
      },
      {
        q: sec0
          ? `في شرح درس «${lesson.title}»، ما المقصود بالمحور الأساسي (${sec0.title})؟`
          : `ما الهدف التعليمي الرئيسي الموضح في شرح درس «${lesson.title}»؟`,
        options: [
          sec0?.description ||
            stripHtmlTags(lesson.description).slice(0, 90) ||
            `إتقان المفاهيم والتطبيقات العملية لدرس ${lesson.title}`,
          'حفظ العناوين الفرعية دون تطبيق عملي أو حل مسائل',
          'تجاوز الأمثلة التطبيقية والاعتماد على التخمين',
          'إلغاء القواعد العلمية الأساسية للوحدة الدراسية',
        ],
        correctIndex: 0,
      },
      {
        q: `إلى أي مرحلة دراسية ووحدة منهجية ينتمي درس «${lesson.title}» الذي يقدمه (${lesson.teacherName})؟`,
        options: [
          `${lesson.grade}${lesson.unit ? ` — ${lesson.unit}` : ''}`,
          `${otherGrades[0] || 'المرحلة الابتدائية'} — وحدة عامة`,
          `${otherGrades[1] || 'الشهادة الإعدادية'} — مراجعة خارجية`,
          'غير مرتبط بأي منهج دراسي في قاعدة البيانات',
        ],
        correctIndex: 0,
      },
      {
        q: sec1
          ? `أي مما يلي يمثل القاعدة الثانية (${sec1.title}) في هذا الدرس؟`
          : `ما الشرط المطلوب في منصة الشريف بعد استيعاب درس «${lesson.title}» لفتح الدرس التالي؟`,
        options: [
          sec1?.description ||
            `تطبيق خطوات الدرس عملياً واجتياز اختبار الإتقان بنسبة لا تقل عن ${sequentialConfig.minimumPassPercentage}%`,
          'الانتقال العشوائي بين الدروس دون مشاهدة الشرح',
          'ترك التمارين والاختبارات القصيرة دون حل',
          'الاكتفاء بقراءة عنوان الدرس فقط',
        ],
        correctIndex: 0,
      },
    ];
  };

  const openLessonMasteryQuiz = (lesson: Lesson) => {
    setMasteryQuizLesson(lesson);
    setMasteryAnswers({});
    setMasteryResult(null);
  };

  const handleSubmitMasteryQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!masteryQuizLesson) return;
    const questions = buildLessonMasteryQuestions(masteryQuizLesson);
    let earned = 0;
    questions.forEach((item, idx) => {
      if (masteryAnswers[idx] === item.correctIndex) {
        earned += 1;
      }
    });
    const total = questions.length;
    const scorePct = Math.round((earned / total) * 100);
    const passed = scorePct >= sequentialConfig.minimumPassPercentage;

    setIsSubmittingMastery(true);
    try {
      const sid = String(currentUser?.studentId || currentUser?.id || 'guest').trim();
      const res = await fetch('/api/sequential-lessons/record-progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentKey: sid,
          studentId: sid,
          studentName: currentUser?.name || 'طالب',
          watchedLessonId: masteryQuizLesson.id,
          passedLessonId: masteryQuizLesson.id,
          lessonTitle: masteryQuizLesson.title,
          subject: masteryQuizLesson.subject,
          grade: masteryQuizLesson.grade,
          scorePercentage: scorePct,
          earnedMarks: earned,
          totalMarks: total,
        }),
      });
      const data = await res.json();
      if (res.ok && data?.progressMap) {
        setSequentialProgressMap(data.progressMap);
      }
      setMasteryResult({ scorePct, passed, earned, total });
      if (passed) {
        showToast(
          `أحسنت! اجتزت اختبار الدرس بنسبة ${scorePct}% وتم فتح الدرس التالي لك تلقائياً ✓`,
          'success'
        );
      } else {
        showToast(
          `حصلت على ${scorePct}% — يلزم الحصول على ${sequentialConfig.minimumPassPercentage}% على الأقل لفتح الدرس التالي`,
          'error'
        );
      }
    } catch {
      showToast('تعذر حفظ نتيجة الاختبار القصير', 'error');
    } finally {
      setIsSubmittingMastery(false);
    }
  };

  // Quick Student Rating Survey Form State
  const [surveyRating, setSurveyRating] = useState(5);
  const [surveyClarity, setSurveyClarity] = useState(5);
  const [surveyBenefit, setSurveyBenefit] = useState(5);
  const [surveyComment, setSurveyComment] = useState('');
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);

  // Add / Edit Form State
  const [formTitle, setFormTitle] = useState('');
  const [formTitleEn, setFormTitleEn] = useState('');
  const [formSubject, setFormSubject] = useState('الرياضيات');
  const [formGrade, setFormGrade] = useState('الصف الثالث الثانوي');
  const [formTeacherId, setFormTeacherId] = useState(teachers[0]?.id || '');
  const [formFormat, setFormFormat] = useState<LessonFormat>('video');
  const [formDurationOrPages, setFormDurationOrPages] = useState('45 دقيقة');
  const [formDescription, setFormDescription] = useState('');
  const [formUnit, setFormUnit] = useState('الوحدة الأولى');
  const [formUrl, setFormUrl] = useState('');
  const [formContentHtml, setFormContentHtml] = useState('');
  const [formInfographicData, setFormInfographicData] = useState<InfographicData | null>(null);
  const [attachInfographic, setAttachInfographic] = useState(false);
  const [addEditTab, setAddEditTab] = useState<'media' | 'ckeditor' | 'infographic'>('media');
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [isSummaryEditorExpanded, setIsSummaryEditorExpanded] = useState(false);

  // Load & Refresh Strictly from Database
  const handleRefreshFromDb = async (silent = false) => {
    setIsLoading(true);
    try {
      const [res, ratRes] = await Promise.all([
        fetch('/api/lessons'),
        fetch('/api/lesson-ratings'),
      ]);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const parsed = data.map(parseLessonRecord);
          setLessonsList(parsed);
          if (!silent) {
            showToast(
              isAr ? 'تم تحديث بنك الدروس والتقييمات من قاعدة البيانات مباشرة ✓' : 'Refreshed lessons & ratings ✓',
              'info'
            );
          }
        }
      }
      if (ratRes.ok) {
        const ratData = await ratRes.json();
        if (Array.isArray(ratData)) {
          setRatingsList(ratData);
        }
      }
    } catch (err) {
      console.error('Failed to reload lessons:', err);
      if (!silent) {
        showToast(isAr ? 'تعذر الاتصال بقاعدة البيانات' : 'Database error', 'error');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    handleRefreshFromDb(true);
  }, []);

  const currentActorStudentId =
    currentUser?.studentId || currentUser?.id || currentUser?.username || 'student-guest';

  // Fetch Lesson Bookmarks & Content Error Reports
  const fetchBookmarksAndReports = async () => {
    try {
      const [bmRes, repRes] = await Promise.all([
        fetch(`/api/lesson-bookmarks?studentId=${encodeURIComponent(currentActorStudentId)}`),
        fetch('/api/content-reports'),
      ]);
      if (bmRes.ok) {
        const bmData = await bmRes.json();
        if (Array.isArray(bmData?.bookmarks)) {
          setBookmarkedLessonIds(bmData.bookmarks.map((b: any) => b.lessonId));
        }
      }
      if (repRes.ok) {
        const repData = await repRes.json();
        if (Array.isArray(repData?.reports)) {
          setContentReports(repData.reports);
        }
      }
    } catch {
      // silent
    }
  };

  useEffect(() => {
    fetchBookmarksAndReports();
    fetch('/api/lessons/drip-rules')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.rules && typeof d.rules === 'object') setDripRulesMap(d.rules);
      })
      .catch(() => {});
  }, [currentActorStudentId]);

  const handleToggleLessonBookmark = async (lessonId: string) => {
    try {
      const res = await fetch('/api/lesson-bookmarks/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: currentActorStudentId, lessonId }),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data?.bookmarks)) {
        setBookmarkedLessonIds(data.bookmarks.map((b: any) => b.lessonId));
        showToast(
          data.bookmarked
            ? 'تم حفظ الدرس في قائمة المفضلة للرجوع السريع ★'
            : 'تمت إزالة الدرس من المحفوظات',
          'info'
        );
      }
    } catch {
      showToast('تعذر تحديث قائمة المحفوظات', 'error');
    }
  };

  const handleSubmitContentReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportingLesson) return;
    setIsSubmittingReport(true);
    try {
      const res = await fetch('/api/content-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetType: 'lesson',
          lessonId: reportingLesson.id,
          targetTitle: reportingLesson.title,
          subject: reportingLesson.subject,
          category: reportCategory,
          details: reportDetails.trim() || 'يرجى مراجعة هذا الدرس.',
          reporterId: currentActorStudentId,
          reporterName: currentUser?.name || 'طالب',
        }),
      });
      const data = await res.json();
      if (res.ok) {
        if (Array.isArray(data?.reports)) setContentReports(data.reports);
        setReportingLesson(null);
        setReportDetails('');
        showToast('تم إرسال البلاغ بنجاح للمعلم والإدارة للمراجعة ✓', 'success');
      } else {
        showToast(data?.error || 'تعذر إرسال البلاغ', 'error');
      }
    } catch {
      showToast('تعذر إرسال البلاغ', 'error');
    } finally {
      setIsSubmittingReport(false);
    }
  };

  const handleResolveContentReport = async (reportId: string, nextStatus: 'open' | 'resolved') => {
    try {
      const res = await fetch(`/api/content-reports/${reportId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({ status: nextStatus }),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data?.reports)) {
        setContentReports(data.reports);
        showToast(nextStatus === 'resolved' ? 'تم إغلاق البلاغ وتوثيق الحل ✓' : 'تمت إعادة فتح البلاغ', 'success');
      }
    } catch {
      showToast('تعذر تحديث حالة البلاغ', 'error');
    }
  };

  const handleDeleteContentReport = async (reportId: string) => {
    try {
      const res = await fetch(`/api/content-reports/${reportId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data?.reports)) {
        setContentReports(data.reports);
      }
    } catch {
      // silent
    }
  };

  const getLessonRatingStats = (lessonId: string) => {
    const reviews = ratingsList.filter((r) => r.lessonId === lessonId);
    if (!reviews.length) {
      return { avg: 0, clarityAvg: 0, benefitAvg: 0, count: 0, reviews };
    }
    const avg = reviews.reduce((s, r) => s + Number(r.rating || 0), 0) / reviews.length;
    const clarityAvg = reviews.reduce((s, r) => s + Number(r.clarityRating || r.rating || 0), 0) / reviews.length;
    const benefitAvg = reviews.reduce((s, r) => s + Number(r.benefitRating || r.rating || 0), 0) / reviews.length;
    return {
      avg: Number(avg.toFixed(1)),
      clarityAvg: Number(clarityAvg.toFixed(1)),
      benefitAvg: Number(benefitAvg.toFixed(1)),
      count: reviews.length,
      reviews,
    };
  };

  const overallRatingsAverage = useMemo(() => {
    if (!ratingsList.length) return 0;
    const sum = ratingsList.reduce((acc, r) => acc + Number(r.rating || 0), 0);
    return Number((sum / ratingsList.length).toFixed(1));
  }, [ratingsList]);

  // Sync survey form when opening a lesson
  useEffect(() => {
    if (!viewingLesson) return;
    const existing = ratingsList.find(
      (r) => r.lessonId === viewingLesson.id && r.studentId === currentActorStudentId
    );
    if (existing) {
      setSurveyRating(existing.rating);
      setSurveyClarity(existing.clarityRating);
      setSurveyBenefit(existing.benefitRating);
      setSurveyComment(existing.comment || '');
    } else {
      setSurveyRating(5);
      setSurveyClarity(5);
      setSurveyBenefit(5);
      setSurveyComment('');
    }
  }, [viewingLesson?.id, currentActorStudentId, ratingsList]);

  const handleSubmitLessonRating = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!viewingLesson || !canSubmitSurvey) return;
    setIsSubmittingRating(true);
    try {
      const res = await fetch('/api/lesson-ratings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          lessonId: viewingLesson.id,
          lessonTitle: viewingLesson.title,
          subject: viewingLesson.subject,
          grade: viewingLesson.grade,
          teacherId: viewingLesson.teacherId,
          teacherName: viewingLesson.teacherName,
          studentId: currentActorStudentId,
          studentName: currentUser?.name || (isAr ? 'طالب مسجل' : 'Student'),
          rating: surveyRating,
          clarityRating: surveyClarity,
          benefitRating: surveyBenefit,
          comment: surveyComment.trim(),
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        showToast(err.error || (isAr ? 'تعذر إرسال التقييم' : 'Rating failed'), 'error');
        return;
      }
      const saved: LessonRating = await res.json();
      setRatingsList((prev) => {
        const exists = prev.some((r) => r.id === saved.id);
        return exists ? prev.map((r) => (r.id === saved.id ? saved : r)) : [saved, ...prev];
      });
      onRatingSubmitted?.(saved);
      showToast(
        isAr
          ? 'شكراً لك! تم حفظ تقييمك للدرس في قاعدة البيانات بنجاح ★'
          : 'Thank you! Lesson rating saved ✓'
      );
    } catch (err) {
      console.error('Submit rating error:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Network error', 'error');
    } finally {
      setIsSubmittingRating(false);
    }
  };

  const handleDeleteLessonRating = async (ratingId: string) => {
    if (!canModerateRatings) return;
    try {
      const res = await fetch(`/api/lesson-ratings/${ratingId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setRatingsList((prev) => prev.filter((r) => r.id !== ratingId));
        onRatingDeleted?.(ratingId);
        showToast(isAr ? 'تم حذف التقييم من قاعدة البيانات ✓' : 'Rating removed ✓', 'info');
      }
    } catch (err) {
      console.error('Delete rating error:', err);
    }
  };

  // Filtered List
  const filteredLessons = useMemo(() => {
    return lessonsList.filter((les) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        les.title.toLowerCase().includes(q) ||
        (les.titleEn && les.titleEn.toLowerCase().includes(q)) ||
        les.subject.toLowerCase().includes(q) ||
        les.teacherName.toLowerCase().includes(q) ||
        (les.unit && les.unit.toLowerCase().includes(q)) ||
        (les.description && stripHtmlTags(les.description).toLowerCase().includes(q));

      const matchesFormat = selectedFormat === 'all' || les.format === selectedFormat;
      const matchesGrade = selectedGrade === 'all' || les.grade === selectedGrade;
      const matchesSubject = selectedSubject === 'all' || les.subject === selectedSubject;
      const matchesBookmark = !showBookmarksOnly || bookmarkedLessonIds.includes(les.id);

      return matchesSearch && matchesFormat && matchesGrade && matchesSubject && matchesBookmark;
    });
  }, [lessonsList, searchQuery, selectedFormat, selectedGrade, selectedSubject, showBookmarksOnly, bookmarkedLessonIds]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filteredLessons.length / itemsPerPage));

  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [currentPage, totalPages]);

  const paginatedLessons = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredLessons.slice(start, start + itemsPerPage);
  }, [filteredLessons, currentPage, itemsPerPage]);

  // Exports
  const handleExportCsv = () => {
    const headers = [
      'المعرف',
      'عنوان الدرس',
      'المادة',
      'المرحلة',
      'المعلم',
      'الصيغة',
      'المدة/الصفحات',
      'الوحدة',
      'المشاهدات',
      'الإعجابات',
      'تاريخ الإضافة',
    ];
    const rows = filteredLessons.map((l) => [
      l.id,
      `"${(l.title || '').replace(/"/g, '""')}"`,
      `"${l.subject || ''}"`,
      `"${l.grade || ''}"`,
      `"${l.teacherName || ''}"`,
      l.format,
      `"${l.durationOrPages || ''}"`,
      `"${l.unit || ''}"`,
      l.viewsCount || 0,
      l.likesCount || 0,
      l.createdAt || '',
    ]);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lessons_export_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(isAr ? 'تم تصدير جدول الدروس بصيغة Excel/CSV بنجاح ✓' : 'Exported CSV ✓', 'info');
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(filteredLessons, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lessons_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(isAr ? 'تم تصدير الدروس بصيغة JSON بنجاح ✓' : 'Exported JSON ✓', 'info');
  };

  const handleExportLessonWord = (lesson: Lesson) => {
    const htmlDoc = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><meta charset="utf-8" /><title>${lesson.title} - منصة الشريف</title>
      <style>
        body { font-family: 'Tajawal', Arial, sans-serif; direction: rtl; line-height: 1.8; position: relative; }
        .watermark-header { text-align: center; padding: 8px; background: #ecfdf5; border: 1px dashed #059669; color: #065f46; font-weight: bold; margin-bottom: 16px; }
        .watermark-stamp { text-align: center; color: rgba(6, 95, 70, 0.22); font-size: 28pt; font-weight: 900; margin: 18px 0; }
      </style></head>
      <body>
        <div class="watermark-header">علامة مائية رسمية: منصة الشريف التعليمية — جميع الحقوق محفوظة (ممنوع النقل أو التصوير)</div>
        <h1>${lesson.title}</h1>
        <p><strong>المنصة:</strong> منصة الشريف | <strong>المادة:</strong> ${lesson.subject} | <strong>المرحلة:</strong> ${lesson.grade} | <strong>المعلم:</strong> ${lesson.teacherName}</p>
        <hr/>
        <div class="watermark-stamp">منصة الشريف</div>
        ${
          lesson.contentHtml ||
          (hasHtmlMarkup(lesson.description) ? lesson.description : `<p>${lesson.description}</p>`)
        }
        <div class="watermark-stamp">منصة الشريف</div>
      </body></html>
    `;
    const blob = new Blob(['\ufeff', htmlDoc], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${lesson.title.replace(/\s+/g, '_')}_منصة_الشريف.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Open Create Modal
  const handleOpenAdd = () => {
    if (!canCreateLessons) return;
    setFormTitle('');
    setFormTitleEn('');
    setFormSubject('الرياضيات');
    setFormGrade('الصف الثالث الثانوي');
    setFormTeacherId(
      isTeacher
        ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || ''
        : teachers[0]?.id || ''
    );
    setFormFormat('video');
    setFormDurationOrPages('45 دقيقة');
    setFormDescription('');
    setFormUnit('الوحدة الأولى');
    setFormUrl('');
    setFormContentHtml('');
    setFormInfographicData(null);
    setAttachInfographic(false);
    setUploadedFileName('');
    setIsSummaryEditorExpanded(false);
    setFormDripDate('');
    setFormDripDays(0);
    setFormPrereqLessonId('');
    setFormPrereqMinScore(70);
    setAddEditTab('media');
    setIsAddModalOpen(true);
  };

  // Open Edit Modal with all 3 Studio Tabs (Media, CKEditor, Infographic)
  const handleOpenEdit = (lesson: Lesson) => {
    if (!canManageLessonItem(lesson)) {
      showToast(
        isAr ? 'غير مصرح لك بتعديل هذا الدرس — يمكنك تعديل دروسك فقط' : 'Not authorized to edit this lesson',
        'error'
      );
      return;
    }
    setEditingLesson(lesson);
    setFormTitle(lesson.title);
    setFormTitleEn(lesson.titleEn || '');
    setFormSubject(lesson.subject);
    setFormGrade(lesson.grade);
    setFormTeacherId(lesson.teacherId);
    setFormFormat(lesson.format);
    setFormDurationOrPages(lesson.durationOrPages);
    setFormDescription(lesson.description || '');
    setFormUnit(lesson.unit || 'الوحدة الأولى');
    setFormUrl(lesson.videoUrl || lesson.documentUrl || '');
    setFormContentHtml(lesson.contentHtml || '');
    setFormInfographicData(lesson.infographicData || null);
    setAttachInfographic(Boolean(lesson.infographicData));
    const existingDrip = dripRulesMap[lesson.id];
    setFormDripDate(existingDrip?.dripUnlockAtDate || '');
    setFormDripDays(existingDrip?.dripUnlockAfterDays || 0);
    setFormPrereqLessonId(existingDrip?.prerequisiteLessonId || '');
    setFormPrereqMinScore(existingDrip?.prerequisiteMinScore || 70);
    setUploadedFileName('');
    setIsSummaryEditorExpanded(false);
    if (lesson.format === 'infographic') {
      setAddEditTab('infographic');
    } else if ((lesson.format === 'pdf' || lesson.format === 'word') && lesson.contentHtml && !lesson.documentUrl) {
      setAddEditTab('ckeditor');
    } else {
      setAddEditTab('media');
    }
  };

  const handleOpenInfographicTab = () => {
    if (!formInfographicData) {
      setFormInfographicData(createStarterInfographic(formTitle));
    }
    setAttachInfographic(true);
    setAddEditTab('infographic');
  };

  const handleLocalLessonFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      showToast(
        isAr
          ? 'الملف كبير جداً للحفظ المباشر (> 15 ميجا)، يرجى استخدام رابط مباشر (YouTube / Drive)'
          : 'File too large (>15MB). Please paste a direct URL.',
        'error'
      );
      e.target.value = '';
      return;
    }
    setUploadedFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setFormUrl(reader.result);
        showToast(
          isAr ? `تم إرفاق الملف (${file.name}) بنجاح ✓` : `Attached ${file.name} ✓`,
          'info'
        );
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Open View Details Modal (Checks activation code & sequential lock for locked lessons, then increments views count in DB)
  const handleOpenViewDetails = async (lesson: Lesson) => {
    if (isLessonLockedForCurrentUser(lesson)) {
      setLockedLessonPrompt(lesson);
      setQuickActivationCode('');
      return;
    }
    // Check Drip Content & Prerequisite Lesson Rule for Students
    if (isStudent) {
      const drip = dripRulesMap[lesson.id];
      if (drip) {
        if (drip.dripUnlockAtDate) {
          const unlockMs = new Date(drip.dripUnlockAtDate).getTime();
          if (Number.isFinite(unlockMs) && Date.now() < unlockMs) {
            showToast(
              isAr
                ? `هذا الدرس مجدول للفتح تلقائياً بتاريخ ${drip.dripUnlockAtDate}`
                : `Scheduled to unlock on ${drip.dripUnlockAtDate}`,
              'info'
            );
            return;
          }
        }
        if (drip.prerequisiteLessonId) {
          const sid = String(currentUser?.studentId || currentUser?.id || 'guest').trim();
          const prog = sequentialProgressMap[sid];
          const bestScore = prog?.passedLessonScores?.[drip.prerequisiteLessonId] || 0;
          const minNeeded = drip.prerequisiteMinScore || 70;
          if (bestScore < minNeeded) {
            const prereq = lessonsList.find((l) => l.id === drip.prerequisiteLessonId);
            if (prereq) {
              setSequentialBlockedPrompt({
                targetLesson: lesson,
                prerequisiteLesson: prereq,
                currentBestPct: bestScore,
              });
              return;
            }
          }
        }
      }
    }

    const seqInfo = getLessonSequentialInfo(lesson);
    if (seqInfo.isSequentiallyLocked && seqInfo.prerequisiteLesson) {
      setSequentialBlockedPrompt({
        targetLesson: lesson,
        prerequisiteLesson: seqInfo.prerequisiteLesson,
        currentBestPct: seqInfo.prereqBestScorePct,
      });
      return;
    }

    const updatedViews = (lesson.viewsCount || 0) + 1;
    const updatedLesson = { ...lesson, viewsCount: updatedViews };
    setViewingLesson(updatedLesson);
    setLessonsList((prev) => prev.map((l) => (l.id === lesson.id ? updatedLesson : l)));

    if (isStudent) {
      fetch('/api/study-streaks/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          studentId: currentActorStudentId,
          studentName: currentUser?.name || 'طالب',
          points: 10,
        }),
      }).catch(() => {});
    }

    // Record that the student watched this lesson for Sequential Locking
    try {
      const sid = String(currentUser?.studentId || currentUser?.id || 'guest').trim();
      const progRes = await fetch('/api/sequential-lessons/record-progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentKey: sid,
          studentId: sid,
          studentName: currentUser?.name || 'طالب',
          watchedLessonId: lesson.id,
          lessonTitle: lesson.title,
          subject: lesson.subject,
          grade: lesson.grade,
        }),
      });
      const progData = await progRes.json();
      if (progRes.ok && progData?.progressMap) {
        setSequentialProgressMap(progData.progressMap);
      }
    } catch {
      // ignore
    }

    try {
      await fetch(`/api/lessons/${lesson.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ viewsCount: updatedViews }),
      });
    } catch (e) {
      console.warn('View count increment error', e);
    }
  };

  const handleQuickRedeemLessonCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lockedLessonPrompt || !quickActivationCode.trim()) return;
    setIsRedeemingCode(true);
    try {
      const res = await fetch('/api/content-security/redeem-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: quickActivationCode.trim().toUpperCase(),
          studentId: currentUser?.studentId || currentUser?.id || 'guest',
          studentName: currentUser?.name || 'طالب',
          studentPhone: currentUser?.phone || '',
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (Array.isArray(data.allRedemptions)) {
          setStudentRedemptions(data.allRedemptions);
        } else if (data.redemption) {
          setStudentRedemptions((prev) => [data.redemption, ...prev]);
        }
        showToast(data.message || 'تم تفعيل الكود وفتح الدرس بنجاح ✓', 'success');
        const targetLesson = lockedLessonPrompt;
        setLockedLessonPrompt(null);
        setQuickActivationCode('');
        setViewingLesson(targetLesson);
      } else {
        showToast(data.error || 'كود التفعيل غير صالح أو مستخدم من قبل', 'error');
      }
    } catch {
      showToast('تعذر التحقق من الكود حالياً', 'error');
    } finally {
      setIsRedeemingCode(false);
    }
  };

  // Like Lesson Handler (Updates DB)
  const handleLikeLesson = async (lessonId: string) => {
    const target = lessonsList.find((l) => l.id === lessonId);
    if (!target) return;
    const newLikes = (target.likesCount || 0) + 1;
    const updated = { ...target, likesCount: newLikes };
    setLessonsList((prev) => prev.map((l) => (l.id === lessonId ? updated : l)));
    if (viewingLesson && viewingLesson.id === lessonId) {
      setViewingLesson(updated);
    }
    showToast(isAr ? 'تم تسجيل الإعجاب بالدرس في قاعدة البيانات ✓' : 'Liked lesson!', 'success');
    try {
      await fetch(`/api/lessons/${lessonId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ likesCount: newLikes }),
      });
    } catch (e) {
      console.warn('Like increment error', e);
    }
  };

  // Persist Lesson (Create or Update) directly to DB
  const persistLessonPayload = async (
    payload: Partial<Lesson> & { title: string },
    isUpdate: boolean,
    existingId?: string
  ): Promise<Lesson | null> => {
    setIsSaving(true);
    try {
      const url = isUpdate && existingId ? `/api/lessons/${existingId}` : '/api/lessons';
      const method = isUpdate && existingId ? 'PUT' : 'POST';
      const bodyToSend = {
        ...payload,
        infographicData: payload.infographicData
          ? JSON.stringify(payload.infographicData)
          : null,
      };
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify(bodyToSend),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        showToast(
          errData?.error || (isAr ? 'تعذر حفظ الدرس في قاعدة البيانات' : 'Failed to save lesson'),
          'error'
        );
        return null;
      }

      const savedRaw = await res.json();
      const saved = parseLessonRecord(savedRaw);

      if (isUpdate) {
        setLessonsList((prev) => prev.map((l) => (l.id === saved.id ? saved : l)));
        onUpdateLesson(saved);
        if (viewingLesson && viewingLesson.id === saved.id) {
          setViewingLesson(saved);
        }
        showToast(isAr ? 'تم تحديث وحفظ الدرس في قاعدة البيانات بنجاح ✓' : 'Lesson updated in DB ✓');
      } else {
        setLessonsList((prev) => [saved, ...prev]);
        onAddLesson(saved);
        showToast(isAr ? 'تمت إضافة ونشر الدرس في قاعدة البيانات بنجاح ✓' : 'Lesson published in DB ✓');
      }
      return saved;
    } catch (err) {
      console.error('Database save error:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database connection error', 'error');
      return null;
    } finally {
      setIsSaving(false);
    }
  };

  // Save Unified Add Form (Media + Office CKEditor + Infographic)
  const handleSaveAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canCreateLessons) return;
    const teacher = teachers.find((t) => t.id === formTeacherId);
    const resolvedTeacherId = isTeacher
      ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || ''
      : formTeacherId;
    const resolvedTeacherName = isTeacher
      ? matchedTeacher?.name || currentUser?.name || 'معلم المادة'
      : teacher?.name || currentUser?.name || 'معلم المادة';
    const activeInfo = attachInfographic && formInfographicData ? formInfographicData : undefined;
    const newLessonData = {
      id: `les-${Date.now()}`,
      title: formTitle.trim() || 'درس تعليمي جديد',
      titleEn: formTitleEn.trim() || formTitle.trim() || 'New Lesson',
      subject: formSubject,
      grade: formGrade,
      teacherId: resolvedTeacherId,
      teacherName: resolvedTeacherName,
      format: formFormat,
      durationOrPages: formDurationOrPages,
      videoUrl: formFormat === 'video' ? formUrl.trim() || '' : undefined,
      documentUrl: formFormat !== 'video' ? formUrl.trim() || '#' : undefined,
      description: hasMeaningfulHtmlContent(formDescription) ? formDescription.trim() : activeInfo?.summary || '',
      unit: formUnit.trim() || 'الوحدة الأولى',
      contentHtml: formContentHtml.trim() ? formContentHtml : undefined,
      infographicData: activeInfo,
      viewsCount: 1,
      likesCount: 0,
      isPublished: true,
    };

    const saved = await persistLessonPayload(newLessonData, false);
    if (saved) {
      if (formDripDate || formDripDays > 0 || formPrereqLessonId) {
        fetch(`/api/lessons/drip-rules/${encodeURIComponent(saved.id)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            dripUnlockAtDate: formDripDate,
            dripUnlockAfterDays: formDripDays,
            prerequisiteLessonId: formPrereqLessonId,
            prerequisiteMinScore: formPrereqMinScore,
          }),
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (d?.rules) setDripRulesMap(d.rules);
          })
          .catch(() => {});
      }
      setIsAddModalOpen(false);
    }
  };

  // Save Unified Edit Form
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLesson) return;
    const teacher = teachers.find((t) => t.id === formTeacherId);
    const activeInfo = attachInfographic && formInfographicData ? formInfographicData : undefined;
    const updatedLessonData: Partial<Lesson> & { title: string } = {
      title: formTitle.trim(),
      titleEn: formTitleEn.trim() || editingLesson.titleEn || formTitle.trim(),
      subject: formSubject,
      grade: formGrade,
      teacherId: formTeacherId,
      teacherName: teacher?.name || editingLesson.teacherName,
      format: formFormat,
      durationOrPages: formDurationOrPages,
      videoUrl: formFormat === 'video' ? formUrl.trim() : undefined,
      documentUrl: formFormat !== 'video' ? formUrl.trim() : undefined,
      description: hasMeaningfulHtmlContent(formDescription) ? formDescription.trim() : activeInfo?.summary || '',
      unit: formUnit.trim() || 'الوحدة الأولى',
      contentHtml: formContentHtml.trim() ? formContentHtml : undefined,
      infographicData: activeInfo,
    };

    const saved = await persistLessonPayload(updatedLessonData, true, editingLesson.id);
    if (saved) {
      fetch(`/api/lessons/drip-rules/${encodeURIComponent(saved.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          dripUnlockAtDate: formDripDate,
          dripUnlockAfterDays: formDripDays,
          prerequisiteLessonId: formPrereqLessonId,
          prerequisiteMinScore: formPrereqMinScore,
        }),
      })
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (d?.rules) setDripRulesMap(d.rules);
        })
        .catch(() => {});
      setEditingLesson(null);
    }
  };

  // Save from CKEditor (Create OR Update in DB)
  const handleSaveFromCKEditor = async (ckData: {
    id?: string;
    title: string;
    subject: string;
    grade: string;
    teacherId: string;
    teacherName: string;
    unit: string;
    description: string;
    contentHtml: string;
    format: 'pdf' | 'word';
    durationOrPages: string;
  }) => {
    if (!canCreateLessons) return;
    const isUpdate = Boolean(ckData.id);
    const resolvedTeacherId = isTeacher
      ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || ''
      : ckData.teacherId;
    const resolvedTeacherName = isTeacher
      ? matchedTeacher?.name || currentUser?.name || ckData.teacherName
      : ckData.teacherName;
    await persistLessonPayload(
      {
        id: ckData.id || `les-ck-${Date.now()}`,
        title: ckData.title,
        titleEn: ckData.title,
        subject: ckData.subject,
        grade: ckData.grade,
        teacherId: resolvedTeacherId,
        teacherName: resolvedTeacherName,
        format: ckData.format,
        durationOrPages: ckData.durationOrPages,
        description: ckData.description,
        unit: ckData.unit,
        contentHtml: ckData.contentHtml,
        isPublished: true,
        ...(isUpdate ? {} : { viewsCount: 1, likesCount: 0 }),
      },
      isUpdate,
      ckData.id
    );
    setCkEditorEditingLesson(null);
    setIsCKEditorOpen(false);
  };

  // Save from Infographic Studio (Create OR Update in DB)
  const handleSaveFromInfographic = async (infoData: {
    id?: string;
    title: string;
    subject: string;
    grade: string;
    teacherId: string;
    teacherName: string;
    unit: string;
    description: string;
    format: 'infographic';
    durationOrPages: string;
    infographicData: InfographicData;
  }) => {
    if (!canCreateLessons) return;
    const isUpdate = Boolean(infoData.id);
    const resolvedTeacherId = isTeacher
      ? matchedTeacher?.id || currentUser?.teacherId || currentUser?.id || ''
      : infoData.teacherId;
    const resolvedTeacherName = isTeacher
      ? matchedTeacher?.name || currentUser?.name || infoData.teacherName
      : infoData.teacherName;
    await persistLessonPayload(
      {
        id: infoData.id || `les-info-${Date.now()}`,
        title: infoData.title,
        titleEn: infoData.title,
        subject: infoData.subject,
        grade: infoData.grade,
        teacherId: resolvedTeacherId,
        teacherName: resolvedTeacherName,
        format: 'infographic',
        durationOrPages: infoData.durationOrPages,
        description: infoData.description,
        unit: infoData.unit,
        infographicData: infoData.infographicData,
        isPublished: true,
        ...(isUpdate ? {} : { viewsCount: 1, likesCount: 0 }),
      },
      isUpdate,
      infoData.id
    );
    setInfographicEditingLesson(null);
    setIsInfographicOpen(false);
  };

  // Delete from Database
  const handleConfirmDelete = async () => {
    if (!lessonToDelete || !canManageLessonItem(lessonToDelete)) return;
    const id = lessonToDelete.id;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/lessons/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (res.ok) {
        setLessonsList((prev) => prev.filter((l) => l.id !== id));
        onDeleteLesson(id);
        if (viewingLesson && viewingLesson.id === id) {
          setViewingLesson(null);
        }
        showToast(isAr ? 'تم حذف الدرس نهائياً من قاعدة البيانات ✓' : 'Lesson deleted from DB ✓');
      } else {
        const err = await res.json().catch(() => ({}));
        showToast(err.error || (isAr ? 'تعذر حذف الدرس من قاعدة البيانات' : 'Failed to delete'), 'error');
      }
    } catch (err) {
      console.error('Failed to delete lesson:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database error', 'error');
    } finally {
      setIsSaving(false);
      setLessonToDelete(null);
    }
  };

  const rangeStart = filteredLessons.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1;
  const rangeEnd = Math.min(currentPage * itemsPerPage, filteredLessons.length);

  return (
    <div className="space-y-6 font-tajawal">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          <div
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl shadow-xl text-xs md:text-sm font-bold font-cairo ${
              toastMessage.type === 'error'
                ? 'bg-rose-600 text-white'
                : toastMessage.type === 'info'
                ? 'bg-blue-700 text-white'
                : 'bg-emerald-600 text-white'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Top Banner and Quick Actions */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-mono-numbers">
              <Database className="w-3 h-3 text-emerald-600" />
              <span>Cloud SQL Live Sync</span>
            </span>
            <span className="text-[11px] text-slate-400 font-cairo">
              {isAr ? `(إجمالي الدروس: ${lessonsList.length})` : `(${lessonsList.length} Lessons)`}
            </span>
          </div>

          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white font-cairo">
            {isAr ? 'إدارة الدروس والمحاضرات (فيديو وملفات)' : 'Lessons & Media Repository'}
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 font-tajawal">
            {isAr
              ? 'تحكم كامل بالإضافة، الحذف، التعديل، البحث، المشاهدة، الترقيم (Pagination)، التصدير، شاشة كتابة الدرس كاملا، واستوديو الانفوجرافيك.'
              : 'Full DB CRUD, pagination, CSV/JSON/PDF export, full lesson writing screen, and 17-template Infographic Studio.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start xl:self-auto font-cairo">
          <button
            type="button"
            onClick={() => handleRefreshFromDb(false)}
            title={isAr ? 'تحديث من قاعدة البيانات' : 'Refresh from DB'}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-emerald-600' : ''}`} />
          </button>

          {/* Export Buttons */}
          <button
            type="button"
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs cursor-pointer"
            title={isAr ? 'تصدير الدروس إلى Excel (CSV)' : 'Export Excel CSV'}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Excel / CSV</span>
          </button>

          <button
            type="button"
            onClick={handleExportJson}
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs cursor-pointer"
            title={isAr ? 'تصدير الدروس بصيغة JSON' : 'Export JSON'}
          >
            <FileJson className="w-4 h-4 text-blue-600" />
            <span>JSON</span>
          </button>

          {canModerateRatings && (
            <>
              <button
                type="button"
                onClick={() => setIsRatingsReportOpen(true)}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-200 font-bold text-xs cursor-pointer whitespace-nowrap"
                title={isAr ? 'تقرير جودة المحتوى وتقييمات الطلاب للدرس' : 'Lesson Quality Ratings'}
              >
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>
                  {isAr ? 'تقييمات الجودة' : 'Quality Ratings'} ({ratingsList.length})
                </span>
              </button>

              <button
                type="button"
                onClick={() => setIsReportsQueueOpen(true)}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-900 dark:text-rose-200 font-bold text-xs cursor-pointer whitespace-nowrap"
                title="سجل بلاغات ومشاكل المحتوى والأسئلة"
              >
                <Flag className="w-4 h-4 text-rose-600" />
                <span>
                  بلاغات المحتوى ({contentReports.filter((r) => r.status === 'open').length})
                </span>
              </button>
            </>
          )}

          {/* CKEditor & Infographic & Add Lesson (Teachers & Admin/Supervisor ONLY) */}
          {canCreateLessons && (
            <>
              <button
                type="button"
                onClick={() => {
                  setCkEditorEditingLesson(null);
                  setIsCKEditorOpen(true);
                }}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-slate-950 bg-amber-400 hover:bg-amber-300 transition-all shadow-xs cursor-pointer"
                title="شاشة كتابة الدرس كاملا"
              >
                <Sparkles className="w-4 h-4 text-emerald-950" />
                <span>{isAr ? 'شاشة كتابة الدرس كاملا' : 'Full Lesson Writer'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setInfographicEditingLesson(null);
                  setIsInfographicOpen(true);
                }}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-emerald-700 hover:bg-emerald-800 transition-all shadow-xs cursor-pointer"
                title="تصميم درس بـ 10 نماذج انفوجرافيك احترافية"
              >
                <Layers className="w-4 h-4 text-amber-300" />
                <span>{isAr ? 'درس انفوجرافيك' : 'Infographic'}</span>
              </button>

              <button
                type="button"
                onClick={handleOpenAdd}
                className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-blue-700 hover:bg-blue-800 transition-all shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إضافة درس (فيديو / ملف)' : 'Add Lesson'}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Filter and Live Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Live Search */}
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder={
                isAr
                  ? 'ابحث بعنوان الدرس، المادة، المعلم، الوحدة، أو الوصف...'
                  : 'Search by lesson title, subject, teacher, unit...'
              }
              className="w-full pl-8 pr-9 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-tajawal font-medium"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setCurrentPage(1);
                }}
                className="absolute top-2.5 left-2.5 p-1 rounded-md text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Grade Selector */}
          <div>
            <select
              value={selectedGrade}
              onChange={(e) => {
                setSelectedGrade(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-cairo cursor-pointer"
            >
              <option value="all">{isAr ? 'كافة المراحل الدراسية' : 'All Grades'}</option>
              {AVAILABLE_GRADES.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          {/* Subject Selector */}
          <div>
            <select
              value={selectedSubject}
              onChange={(e) => {
                setSelectedSubject(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-cairo cursor-pointer"
            >
              <option value="all">{isAr ? 'كافة المواد الدراسية' : 'All Subjects'}</option>
              {AVAILABLE_SUBJECTS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Format Filter & Page Size Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-x-auto text-xs font-cairo">
            <button
              type="button"
              onClick={() => {
                setSelectedFormat('all');
                setCurrentPage(1);
              }}
              className={`py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                selectedFormat === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {isAr ? 'جميع الصيغ' : 'All Formats'}
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedFormat('video');
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1 py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                selectedFormat === 'video'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-slate-700'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>{isAr ? 'فيديو' : 'Video'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedFormat('pdf');
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1 py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                selectedFormat === 'pdf'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-slate-700'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>PDF</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedFormat('word');
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1 py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                selectedFormat === 'word'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-700'
              }`}
            >
              <FileCheck2 className="w-3.5 h-3.5" />
              <span>Word</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedFormat('infographic');
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1 py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                selectedFormat === 'infographic'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-slate-700'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{isAr ? 'انفوجرافيك' : 'Infographic'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setShowBookmarksOnly((v) => !v);
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1 py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                showBookmarksOnly
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-slate-700'
              }`}
            >
              <Bookmark className={`w-3.5 h-3.5 ${showBookmarksOnly ? 'fill-slate-950' : ''}`} />
              <span>الدروس المحفوظة ({bookmarkedLessonIds.length})</span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 font-mono-numbers">
            <span>
              {isAr
                ? `عرض ${rangeStart}-${rangeEnd} من ${filteredLessons.length} درس`
                : `Showing ${rangeStart}-${rangeEnd} of ${filteredLessons.length}`}
            </span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo cursor-pointer"
              title="عدد الدروس في الصفحة"
            >
              <option value={6}>6 / صفحة</option>
              <option value={9}>9 / صفحة</option>
              <option value={12}>12 / صفحة</option>
            </select>
          </div>
        </div>
      </div>

      {/* Sequential Lesson Locking Banner (شرط اجتياز الاختبار لفتح الدرس التالي) */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950 via-slate-900 to-emerald-950 text-white border border-indigo-700/40 shadow-md flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">
            <Lock className="w-5 h-5" />
          </div>
          <div className="space-y-0.5">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-cairo font-black text-sm md:text-base text-white">
                شرط اجتياز الاختبار لفتح الدرس التالي (Sequential Locking)
              </h3>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[11px] font-cairo font-bold ${
                  sequentialConfig.enabled
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-700 text-slate-300'
                }`}
              >
                {sequentialConfig.enabled
                  ? `مفعّل • الحد الأدنى للاجتياز ${sequentialConfig.minimumPassPercentage}%`
                  : 'غير مفعّل حالياً'}
              </span>
            </div>
            <p className="text-xs text-slate-300 font-tajawal">
              لا ينتقل الطالب للدرس الثاني في نفس المادة إلا بعد مشاهدة الدرس الأول واجتياز اختباره القصير بنسبة لا تقل عن{' '}
              <strong className="text-amber-300 font-mono-numbers">
                {sequentialConfig.minimumPassPercentage}%
              </strong>
              .
            </p>
          </div>
        </div>

        {canCreateLessons ? (
          <div className="flex flex-wrap items-center gap-2 shrink-0 font-cairo">
            <label className="flex items-center gap-1.5 text-xs bg-white/10 px-3 py-1.5 rounded-xl border border-white/15">
              <span>نسبة الاجتياز:</span>
              <select
                value={sequentialConfig.minimumPassPercentage}
                disabled={isSavingSeqConfig}
                onChange={(e) =>
                  handleUpdateSequentialConfig({
                    minimumPassPercentage: Number(e.target.value) || 70,
                  })
                }
                className="bg-slate-900 text-amber-300 font-mono-numbers font-bold rounded-lg px-2 py-0.5 border border-slate-700 text-xs"
              >
                <option value={60}>60%</option>
                <option value={70}>70% (افتراضي)</option>
                <option value={75}>75%</option>
                <option value={80}>80%</option>
                <option value={85}>85%</option>
              </select>
            </label>

            <button
              type="button"
              disabled={isSavingSeqConfig}
              onClick={() => handleUpdateSequentialConfig({ enabled: !sequentialConfig.enabled })}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs cursor-pointer transition-all ${
                sequentialConfig.enabled
                  ? 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {sequentialConfig.enabled ? 'إيقاف القفل المتسلسل' : 'تفعيل القفل المتسلسل'}
            </button>
          </div>
        ) : (
          <div className="px-3.5 py-2 rounded-xl bg-white/10 border border-white/15 text-xs font-cairo font-bold text-amber-300 shrink-0">
            ✓ اجتز اختبار كل درس ({sequentialConfig.minimumPassPercentage}% فأعلى) لفتح الدرس التالي
          </div>
        )}
      </div>

      {/* Lessons Grid Cards */}
      {isLoading && lessonsList.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <RefreshCw className="w-10 h-10 mx-auto text-emerald-600 animate-spin" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 font-cairo">
            {isAr ? 'جارِ تحميل الدروس من قاعدة البيانات...' : 'Loading lessons from database...'}
          </h3>
        </div>
      ) : filteredLessons.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <BookOpen className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-700" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 font-cairo">
            {lessonsList.length === 0
              ? isAr
                ? 'قاعدة البيانات لا تحتوي على أي دروس مسجلة حتى الآن'
                : 'No lessons saved in database yet'
              : isAr
              ? 'لم يتم العثور على أي دروس مطابقة لمعايير البحث'
              : 'No lessons matched your search'}
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto font-tajawal">
            {lessonsList.length === 0
              ? isAr
                ? 'تم ربط هذا القسم بقاعدة البيانات فقط دون أي دروس وهمية. ابدأ بإضافة درس جديد أو الكتابة عبر شاشة كتابة الدرس كاملا أو تصميم انفوجرافيك.'
                : 'Database-only mode active. Add your first real lesson above.'
              : isAr
              ? 'جرّب تعديل كلمات البحث أو إعادة ضبط الفلاتر.'
              : 'Try adjusting your search or resetting filters.'}
          </p>
          {lessonsList.length === 0 ? (
            canCreateLessons ? (
              <div className="flex flex-wrap items-center justify-center gap-2 pt-1 font-cairo">
                <button
                  type="button"
                  onClick={handleOpenAdd}
                  className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إضافة أول درس' : 'Add First Lesson'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCkEditorEditingLesson(null);
                    setIsCKEditorOpen(true);
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isAr ? 'شاشة كتابة الدرس كاملا' : 'Write Full Lesson'}</span>
                </button>
              </div>
            ) : null
          ) : (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedFormat('all');
                setSelectedGrade('all');
                setSelectedSubject('all');
                setCurrentPage(1);
              }}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-cairo font-bold text-xs hover:bg-slate-200 cursor-pointer"
            >
              {isAr ? 'إعادة ضبط الفلاتر' : 'Reset Filters'}
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {paginatedLessons.map((lesson) => {
            const isVideo = lesson.format === 'video';
            const isPdf = lesson.format === 'pdf';
            const isWord = lesson.format === 'word';
            const isInfo = lesson.format === 'infographic';

            return (
              <div
                key={lesson.id}
                className="group relative rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-lg transition-all overflow-hidden flex flex-col justify-between transform hover:-translate-y-1 protected-lesson-area"
              >
                {/* Watermark stamp on every lesson & study note card */}
                <div className="pointer-events-none select-none absolute top-11 left-3 -rotate-12 px-2 py-0.5 rounded border border-emerald-600/25 bg-emerald-500/5 text-[10px] font-cairo font-black text-emerald-800/35 dark:text-emerald-300/30 z-10">
                  منصة الشريف
                </div>
                <div className="p-5 space-y-3 relative z-10">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold font-cairo ${
                        isVideo
                          ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                          : isPdf
                          ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                          : isWord
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                      }`}
                    >
                      {isVideo && <Video className="w-3.5 h-3.5" />}
                      {isPdf && <FileText className="w-3.5 h-3.5" />}
                      {isWord && <FileCheck2 className="w-3.5 h-3.5" />}
                      {isInfo && <Layers className="w-3.5 h-3.5" />}
                      <span>
                        {isVideo
                          ? isAr
                            ? 'فيديو مرئي'
                            : 'Video'
                          : isPdf
                          ? 'مستند PDF'
                          : isWord
                          ? 'مستند Word'
                          : isAr
                          ? 'انفوجرافيك'
                          : 'Infographic'}
                      </span>
                    </span>

                    <span className="text-[11px] font-bold text-slate-400 font-mono-numbers">
                      {lesson.durationOrPages}
                    </span>
                  </div>

                  {/* Sequential Order & Mastery Status Badge */}
                  {(() => {
                    const seqInfo = getLessonSequentialInfo(lesson);
                    return (
                      <div className="flex flex-wrap items-center justify-between gap-1.5">
                        <span className="px-2.5 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-cairo font-bold">
                          الدرس #{seqInfo.orderNumber} في {lesson.subject}
                        </span>
                        {seqInfo.isSequentiallyLocked ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 text-[11px] font-cairo font-bold">
                            <Lock className="w-3 h-3" />
                            <span>يتطلب اجتياز الدرس #{seqInfo.orderNumber - 1} ({sequentialConfig.minimumPassPercentage}%)</span>
                          </span>
                        ) : seqInfo.isQuizPassed ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 text-[11px] font-cairo font-bold">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>مجتاز ({seqInfo.bestScorePct}%) ✓</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => openLessonMasteryQuiz(lesson)}
                            className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-amber-100 hover:bg-amber-200 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 text-[11px] font-cairo font-bold cursor-pointer"
                          >
                            <Sparkles className="w-3 h-3" />
                            <span>اختبار فتح الدرس التالي ({sequentialConfig.minimumPassPercentage}%)</span>
                          </button>
                        )}
                      </div>
                    );
                  })()}

                  <div>
                    <h3 className="font-cairo font-bold text-sm md:text-base text-slate-900 dark:text-white line-clamp-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {lesson.title}
                    </h3>
                    {lesson.description && stripHtmlTags(lesson.description) && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal mt-1 line-clamp-2">
                        {stripHtmlTags(lesson.description)}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-[11px] font-tajawal">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold">
                        {lesson.subject}
                      </span>
                      <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {lesson.grade}
                      </span>
                      {lesson.unit && (
                        <span className="px-2 py-0.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 font-medium">
                          {lesson.unit}
                        </span>
                      )}
                    </div>

                    {(() => {
                      const stats = getLessonRatingStats(lesson.id);
                      return (
                        <button
                          type="button"
                          onClick={() => handleOpenViewDetails(lesson)}
                          className="inline-flex items-center gap-1 text-[11px] font-cairo font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
                          title={isAr ? 'مشاهدة التقييمات أو تقييم الدرس' : 'View or rate lesson'}
                        >
                          <Star className={`w-3.5 h-3.5 ${stats.count > 0 ? 'fill-amber-400 text-amber-500' : 'text-slate-300 dark:text-slate-600'}`} />
                          <span className="font-mono-numbers">
                            {stats.count > 0
                              ? `${stats.avg} (${stats.count})`
                              : isStudent
                              ? isAr
                                ? 'قيّم الدرس'
                                : 'Rate'
                              : isAr
                              ? 'بدون تقييم'
                              : '0'}
                          </span>
                        </button>
                      );
                    })()}
                  </div>
                </div>

                {/* Card Footer */}
                <div className="p-4 bg-slate-50/70 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-7 h-7 rounded-lg bg-emerald-700 text-white flex items-center justify-center text-xs font-bold font-cairo shrink-0">
                      {lesson.teacherName?.slice(0, 1) || 'م'}
                    </div>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 truncate font-cairo">
                      {lesson.teacherName}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => openLessonMasteryQuiz(lesson)}
                      className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/50 text-amber-800 dark:text-amber-300 text-[11px] font-cairo font-bold cursor-pointer"
                      title="اختبار قصير لفتح الدرس التالي"
                    >
                      اختبار الدرس
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggleLessonBookmark(lesson.id)}
                      className={`p-1.5 rounded-xl border transition-colors cursor-pointer ${
                        bookmarkedLessonIds.includes(lesson.id)
                          ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-400 text-amber-600 dark:text-amber-400'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400 hover:text-amber-500'
                      }`}
                      title={bookmarkedLessonIds.includes(lesson.id) ? 'إزالة من المحفوظات' : 'حفظ الدرس للرجوع السريع'}
                    >
                      <Bookmark
                        className={`w-4 h-4 ${bookmarkedLessonIds.includes(lesson.id) ? 'fill-amber-500' : ''}`}
                      />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleOpenViewDetails(lesson)}
                      className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-emerald-600 hover:border-emerald-500 transition-colors cursor-pointer"
                      title={isAr ? 'مشاهدة تفاصيل الدرس' : 'View Lesson Details'}
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {canManageLessonItem(lesson) && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(lesson)}
                          className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-blue-600 hover:border-blue-500 transition-colors cursor-pointer"
                          title={isAr ? 'تعديل الدرس' : 'Edit Lesson'}
                        >
                          <Edit className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setLessonToDelete(lesson)}
                          className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:border-rose-400 transition-colors cursor-pointer"
                          title={isAr ? 'حذف الدرس' : 'Delete Lesson'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-5 py-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <button
            type="button"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold font-cairo rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <ChevronRight className={`w-4 h-4 ${!isAr ? 'rotate-180' : ''}`} />
            <span>{isAr ? 'السابق' : 'Previous'}</span>
          </button>

          <div className="flex items-center gap-1">
            {Array.from({ length: totalPages }).map((_, idx) => {
              const page = idx + 1;
              return (
                <button
                  key={page}
                  type="button"
                  onClick={() => setCurrentPage(page)}
                  className={`w-8 h-8 rounded-xl text-xs font-bold transition-all font-mono-numbers cursor-pointer ${
                    currentPage === page
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {page}
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold font-cairo rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <span>{isAr ? 'التالي' : 'Next'}</span>
            <ChevronLeft className={`w-4 h-4 ${!isAr ? 'rotate-180' : ''}`} />
          </button>
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT UNIFIED STUDIO LESSON (MEDIA + CKEDITOR + INFOGRAPHIC) ================= */}
      {(isAddModalOpen || editingLesson) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-7xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[96dvh] h-[94dvh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 md:p-5 bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 text-white border-b border-emerald-800 flex items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-md shrink-0">
                  {editingLesson ? <Edit className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                </div>
                <div className="min-w-0">
                  <h3 className="font-cairo font-bold text-sm md:text-lg text-white truncate">
                    {editingLesson
                      ? isAr
                        ? 'تعديل الدرس'
                        : 'Edit Lesson'
                      : isAr
                      ? 'إضافة درس جديد'
                      : 'Add New Lesson'}
                  </h3>
                  <p className="text-[11px] text-emerald-200/80 font-tajawal truncate">
                    {isAr
                      ? 'أرفق الفيديو أو الملف ثم اكتب الدرس كاملاً وصمّم الانفوجرافيك التفاعلي في مكان واحد'
                      : 'Combine video/file, full lesson writing screen, and 17-template Infographic in one lesson'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingLesson(null);
                }}
                className="p-1.5 rounded-xl text-emerald-200 hover:text-white hover:bg-white/10 cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 3-Tab Studio Switcher */}
            <div className="px-4 py-2 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0 font-cairo text-xs">
              <button
                type="button"
                onClick={() => setAddEditTab('media')}
                className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                  addEditTab === 'media'
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                <span>{isAr ? '1. بيانات الدرس والفيديو / الملف' : '1. Media & Metadata'}</span>
              </button>

              <button
                type="button"
                onClick={() => setAddEditTab('ckeditor')}
                className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                  addEditTab === 'ckeditor'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{isAr ? '2. شاشة كتابة الدرس كاملا' : '2. Full Lesson Writing Screen'}</span>
                {formContentHtml.trim().length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-md bg-amber-400 text-slate-950 text-[10px] font-black">
                    ✓
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={handleOpenInfographicTab}
                className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                  addEditTab === 'infographic'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-amber-300" />
                <span>{isAr ? '3. استوديو الانفوجرافيك (17 نموذجاً)' : '3. Infographic Studio'}</span>
                {attachInfographic && (
                  <span className="px-1.5 py-0.5 rounded-md bg-emerald-400 text-slate-950 text-[10px] font-black">
                    مُرفق
                  </span>
                )}
              </button>
            </div>

            <form
              onSubmit={editingLesson ? handleSaveEdit : handleSaveAdd}
              className="flex-1 flex flex-col min-h-0 overflow-hidden"
            >
              {/* TAB 1: BASIC METADATA & VIDEO / FILE */}
              {addEditTab === 'media' && (
                <div className="flex-1 p-5 md:p-6 overflow-y-auto space-y-4 text-xs md:text-sm font-tajawal">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'عنوان الدرس *' : 'Lesson Title *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        placeholder={isAr ? 'اكتب عنوان الدرس هنا...' : 'Lesson title...'}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                      />
                    </div>

                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'عنوان الدرس بالإنجليزية (اختياري)' : 'English Title (Optional)'}
                      </label>
                      <input
                        type="text"
                        value={formTitleEn}
                        onChange={(e) => setFormTitleEn(e.target.value)}
                        placeholder="e.g. Calculus Derivatives & Applications"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'المادة الدراسية *' : 'Subject *'}
                      </label>
                      <select
                        value={formSubject}
                        onChange={(e) => setFormSubject(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                      >
                        {AVAILABLE_SUBJECTS.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'المرحلة الدراسية *' : 'Grade Level *'}
                      </label>
                      <select
                        value={formGrade}
                        onChange={(e) => setFormGrade(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                      >
                        {AVAILABLE_GRADES.map((g) => (
                          <option key={g} value={g}>
                            {g}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'المعلم المشرف *' : 'Teacher *'}
                      </label>
                      {isTeacher ? (
                        <input
                          type="text"
                          readOnly
                          value={matchedTeacher?.name || currentUser?.name || 'المعلم'}
                          className="w-full px-3 py-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 font-cairo font-bold"
                        />
                      ) : (
                        <select
                          value={formTeacherId}
                          onChange={(e) => setFormTeacherId(e.target.value)}
                          className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                        >
                          {teachers.length === 0 ? (
                            <option value="">{isAr ? '-- بدون معلم مسجل (إدارة المنصة) --' : '-- No Registered Teacher --'}</option>
                          ) : (
                            teachers.map((t) => (
                              <option key={t.id} value={t.id}>
                                {t.name}
                              </option>
                            ))
                          )}
                        </select>
                      )}
                    </div>

                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'صيغة الدرس *' : 'Format *'}
                      </label>
                      <select
                        value={formFormat}
                        onChange={(e) => {
                          const f = e.target.value as LessonFormat;
                          setFormFormat(f);
                          if (f === 'video') setFormDurationOrPages('45 دقيقة');
                          else if (f === 'pdf') setFormDurationOrPages('28 صفحة PDF');
                          else if (f === 'word') setFormDurationOrPages('15 صفحة DOCX');
                          else setFormDurationOrPages('انفوجرافيك تفاعلي');
                        }}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-cairo cursor-pointer"
                      >
                        <option value="video">{isAr ? 'فيديو ومحاضرة مرئية' : 'Video Lesson'}</option>
                        <option value="pdf">{isAr ? 'ملف مكتوب (PDF)' : 'PDF Document'}</option>
                        <option value="word">{isAr ? 'مستند مكتوب (Word)' : 'Word Document'}</option>
                        <option value="infographic">{isAr ? 'انفوجرافيك تفاعلي' : 'Infographic'}</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {formFormat === 'video' ? (isAr ? 'مدة الفيديو *' : 'Duration *') : isAr ? 'عدد الصفحات *' : 'Pages *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={formDurationOrPages}
                        onChange={(e) => setFormDurationOrPages(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                      />
                    </div>

                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                        {isAr ? 'الوحدة / الفصل' : 'Unit'}
                      </label>
                      <input
                        type="text"
                        value={formUnit}
                        onChange={(e) => setFormUnit(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  {/* URL OR Local File Upload */}
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                        {formFormat === 'video'
                          ? isAr
                            ? 'رابط الفيديو (YouTube أو رابط مباشر) أو رفع من الجهاز'
                            : 'Video URL or Local Upload'
                          : isAr
                          ? 'رابط الملف (PDF / Word / مرفق) أو رفع من الجهاز'
                          : 'Document URL or Local Upload'}
                      </label>
                      {uploadedFileName && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-lg">
                          <Paperclip className="w-3 h-3" />
                          <span>{uploadedFileName}</span>
                        </span>
                      )}
                    </div>

                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={formUrl}
                        onChange={(e) => setFormUrl(e.target.value)}
                        placeholder="https://..."
                        className="flex-1 px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs"
                      />
                      <label className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0">
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isAr ? 'رفع ملف من الجهاز' : 'Upload File'}</span>
                        <input
                          type="file"
                          accept={formFormat === 'video' ? 'video/*,.mp4,.webm' : '.pdf,.doc,.docx,image/*'}
                          onChange={handleLocalLessonFileUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 flex items-center gap-2">
                        <span>
                          {isAr
                            ? 'ملخص الدرس والأهداف التعليمية (محرر CKEditor الاحترافي)'
                            : 'Lesson Summary & Learning Objectives (Full CKEditor)'}
                        </span>
                        {hasMeaningfulHtmlContent(formDescription) && (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                            {isAr ? '✓ جاهز' : '✓ Ready'}
                          </span>
                        )}
                      </label>

                      <div className="flex items-center gap-1.5 font-cairo text-[11px]">
                        <button
                          type="button"
                          onClick={() => {
                            const tpl = buildLessonObjectivesTemplateHtml(formTitle, formSubject, formGrade, isAr);
                            setFormDescription((prev) =>
                              hasMeaningfulHtmlContent(prev) ? `${prev}${tpl}` : tpl
                            );
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>{isAr ? 'إدراج قالب الملخص والأهداف' : 'Insert Objectives Template'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setIsSummaryEditorExpanded((v) => !v)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold flex items-center gap-1 cursor-pointer transition-colors"
                          title={isAr ? 'تبديل ارتفاع المحرر' : 'Toggle Editor Height'}
                        >
                          {isSummaryEditorExpanded ? (
                            <>
                              <Minimize2 className="w-3 h-3" />
                              <span>{isAr ? 'حجم قياسي' : 'Compact'}</span>
                            </>
                          ) : (
                            <>
                              <Maximize2 className="w-3 h-3" />
                              <span>{isAr ? 'توسيع المحرر' : 'Expand'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    <div
                      className={`rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs flex flex-col transition-all ${
                        isSummaryEditorExpanded ? 'min-h-[820px] h-[820px]' : 'min-h-[660px] h-[660px]'
                      }`}
                    >
                      <OfficeCKEditor
                        key="lesson-description-ckeditor"
                        value={formDescription}
                        onChange={setFormDescription}
                        language={language}
                        minHeight={isSummaryEditorExpanded ? 620 : 450}
                        placeholderAr="اكتب ملخص الدرس والأهداف التعليمية بتنسيق احترافي (عناوين، قوائم، جداول، ألوان، معادلات)..."
                        placeholderEn="Write lesson summary and learning objectives with full CKEditor tools..."
                        documentTitle={
                          formTitle
                            ? isAr
                              ? `ملخص وأهداف: ${formTitle}`
                              : `Summary & Objectives: ${formTitle}`
                            : isAr
                            ? 'ملخص الدرس والأهداف التعليمية'
                            : 'Lesson Summary & Objectives'
                        }
                        documentMeta={`${formSubject} · ${formGrade}${formUnit ? ` · ${formUnit}` : ''}`}
                        teacherName={teachers.find((t) => t.id === formTeacherId)?.name || 'معلم المادة'}
                        onAttachCurrentInfographic={() => {
                          const infoData = formInfographicData || createStarterInfographic(formTitle);
                          if (!formInfographicData) setFormInfographicData(infoData);
                          setAttachInfographic(true);
                          return buildInfographicEmbedHtml(
                            formTitle || 'انفوجرافيك الدرس',
                            formSubject,
                            formGrade,
                            infoData,
                            isAr
                          );
                        }}
                      />
                    </div>
                  </div>

                  {/* Drip Content & Conditional Prerequisite Controls */}
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3 text-xs">
                    <div className="flex items-center gap-2 font-cairo font-bold text-slate-800 dark:text-slate-200">
                      <CalendarClock className="w-4 h-4 text-emerald-600" />
                      <span>{isAr ? 'جدولة الفتح التدريجي والشرط المسبق للدرس (Drip Content)' : 'Drip Schedule & Prerequisites'}</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                      <div>
                        <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                          {isAr ? 'فتح الدرس بتاريخ محدد' : 'Unlock Date'}
                        </label>
                        <input
                          type="date"
                          value={formDripDate}
                          onChange={(e) => setFormDripDate(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                          {isAr ? 'أو بعد (أيام من الاشتراك)' : 'Unlock After Days'}
                        </label>
                        <input
                          type="number"
                          min={0}
                          value={formDripDays}
                          onChange={(e) => setFormDripDays(Math.max(0, Number(e.target.value) || 0))}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                          {isAr ? 'يشترط اجتياز الدرس السابق:' : 'Prerequisite Lesson'}
                        </label>
                        <select
                          value={formPrereqLessonId}
                          onChange={(e) => setFormPrereqLessonId(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-cairo"
                        >
                          <option value="">{isAr ? '-- مفتوح بدون شرط --' : '-- None --'}</option>
                          {lessonsList
                            .filter((l) => l.id !== editingLesson?.id)
                            .map((l) => (
                              <option key={l.id} value={l.id}>{l.title}</option>
                            ))}
                        </select>
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                          {isAr ? 'نسبة الاجتياز المطلوبة (%)' : 'Min Pass %'}
                        </label>
                        <input
                          type="number"
                          min={50}
                          max={100}
                          value={formPrereqMinScore}
                          onChange={(e) => setFormPrereqMinScore(Math.min(100, Math.max(50, Number(e.target.value) || 70)))}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Quick Studio Switch Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setAddEditTab('ckeditor')}
                      className="p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/30 hover:border-emerald-500 text-start transition-all flex items-center justify-between gap-3 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0">
                          <Sparkles className="w-5 h-5 text-amber-300" />
                        </div>
                        <div>
                          <h4 className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                            {isAr ? 'شاشة كتابة الدرس كاملا' : 'Full Lesson Writing Screen'}
                          </h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            {isAr ? 'كتابة ملخصات وجداول ومعادلات ورسوم داخل الدرس' : 'Write rich notes, tables & formulas'}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-300 shrink-0">
                        {isAr ? 'فتح ←' : 'Open →'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={handleOpenInfographicTab}
                      className="p-4 rounded-2xl border border-teal-200 dark:border-teal-800 bg-teal-50/50 dark:bg-teal-950/30 hover:border-teal-500 text-start transition-all flex items-center justify-between gap-3 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-teal-700 text-white flex items-center justify-center shrink-0">
                          <Wand2 className="w-5 h-5 text-amber-300" />
                        </div>
                        <div>
                          <h4 className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                            {isAr ? 'تصميم انفوجرافيك احترافي مرفق بالدرس' : 'Design Attached Infographic'}
                          </h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            {isAr ? '17 نموذجاً (مخطط دائري، أعمدة، فين، عظمة السمكة...)' : '17 visual chart & flow templates'}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs font-cairo font-bold text-teal-700 dark:text-teal-300 shrink-0">
                        {isAr ? 'تصميم ←' : 'Design →'}
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: FULL OFFICE CKEDITOR */}
              {addEditTab === 'ckeditor' && (
                <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                  <OfficeCKEditor
                    key="lesson-content-ckeditor"
                    value={formContentHtml}
                    onChange={setFormContentHtml}
                    language={language}
                    minHeight={560}
                    documentTitle={formTitle || 'درس تعليمي'}
                    documentMeta={`${formSubject} · ${formGrade}${formUnit ? ` · ${formUnit}` : ''}`}
                    teacherName={teachers.find((t) => t.id === formTeacherId)?.name || 'معلم المادة'}
                    onAttachCurrentInfographic={() => {
                      const infoData = formInfographicData || createStarterInfographic(formTitle);
                      if (!formInfographicData) setFormInfographicData(infoData);
                      setAttachInfographic(true);
                      return buildInfographicEmbedHtml(
                        formTitle || 'انفوجرافيك الدرس',
                        formSubject,
                        formGrade,
                        infoData,
                        isAr
                      );
                    }}
                  />
                </div>
              )}

              {/* TAB 3: ADVANCED 17-TEMPLATE INFOGRAPHIC STUDIO */}
              {addEditTab === 'infographic' && (
                <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                  <div className="px-4 py-2 bg-emerald-50/70 dark:bg-emerald-950/30 border-b border-emerald-200 dark:border-emerald-800 flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
                    <label className="flex items-center gap-2 font-cairo font-bold text-emerald-900 dark:text-emerald-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={attachInfographic}
                        onChange={(e) => setAttachInfographic(e.target.checked)}
                      />
                      <span>
                        {isAr
                          ? 'إرفاق ونشر هذا الانفوجرافيك مع الدرس للطلاب'
                          : 'Attach & publish this Infographic with the lesson'}
                      </span>
                    </label>
                    <span className="text-[11px] text-emerald-700 dark:text-emerald-300 font-tajawal">
                      {isAr
                        ? 'يمكنك أيضاً إدراج نسخة بصرية مباشرة داخل شاشة كتابة الدرس من الزر الأخضر أسفل المعاينة'
                        : 'You can also embed a copy directly inside the lesson editor'}
                    </span>
                  </div>

                  <InfographicStudioPanel
                    title={formTitle || 'عنوان الدرس'}
                    subject={formSubject}
                    grade={formGrade}
                    authorName={teachers.find((t) => t.id === formTeacherId)?.name}
                    data={formInfographicData || createStarterInfographic(formTitle)}
                    onChange={(nextData) => {
                      setFormInfographicData(nextData);
                      setAttachInfographic(true);
                    }}
                    onApplyPresetMeta={(meta) => {
                      if (!formTitle.trim()) setFormTitle(meta.title);
                    }}
                    onInsertHtmlIntoEditor={(html) => {
                      setFormContentHtml((prev) => `${prev || ''}${html}`);
                      setAddEditTab('ckeditor');
                      showToast(
                        isAr
                          ? 'تم إدراج الانفوجرافيك داخل شاشة كتابة الدرس بنجاح ✓'
                          : 'Infographic inserted into Lesson Editor ✓',
                        'info'
                      );
                    }}
                    language={language}
                    printableId="lesson-studio-infographic-preview"
                  />
                </div>
              )}

              {/* Unified Pinned Modal Footer */}
              <div className="px-5 py-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 font-cairo shrink-0">
                <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
                  <span>
                    {isAr ? 'الصيغة:' : 'Format:'}{' '}
                    <strong className="text-slate-800 dark:text-slate-200">{formFormat.toUpperCase()}</strong>
                  </span>
                  <span>•</span>
                  <span className={formContentHtml.trim() ? 'text-emerald-600 font-bold' : ''}>
                    {formContentHtml.trim()
                      ? isAr
                        ? '✓ يحتوي على نص الدرس المكتوب'
                        : '✓ Lesson text ready'
                      : isAr
                      ? 'بدون نص درس مكتوب بعد'
                      : 'No written lesson yet'}
                  </span>
                  <span>•</span>
                  <span className={attachInfographic ? 'text-teal-600 font-bold' : ''}>
                    {attachInfographic
                      ? isAr
                        ? '✓ مرفق بلوحة انفوجرافيك'
                        : '✓ Infographic attached'
                      : isAr
                      ? 'بدون انفوجرافيك مرفق'
                      : 'No infographic'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddModalOpen(false);
                      setEditingLesson(null);
                    }}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    {isAr ? 'إلغاء' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-6 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    {isSaving ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>{isAr ? 'جارِ الحفظ...' : 'Saving...'}</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>
                          {editingLesson
                            ? isAr
                              ? 'حفظ التعديلات في قاعدة البيانات'
                              : 'Save Changes'
                            : isAr
                            ? 'حفظ ونشر الدرس بالكامل'
                            : 'Publish Full Lesson'}
                        </span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: VIEW LESSON DETAILS ================= */}
      {viewingLesson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[94vh] flex flex-col">
            <div className="p-5 md:p-6 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-xs ${
                    viewingLesson.format === 'video'
                      ? 'bg-indigo-600'
                      : viewingLesson.format === 'pdf'
                      ? 'bg-rose-600'
                      : viewingLesson.format === 'word'
                      ? 'bg-blue-600'
                      : 'bg-emerald-700'
                  }`}
                >
                  {viewingLesson.format === 'video' && <Video className="w-5 h-5" />}
                  {viewingLesson.format === 'pdf' && <FileText className="w-5 h-5" />}
                  {viewingLesson.format === 'word' && <FileCheck2 className="w-5 h-5" />}
                  {viewingLesson.format === 'infographic' && <Layers className="w-5 h-5" />}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-cairo">
                      {viewingLesson.subject}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono-numbers">
                      {viewingLesson.durationOrPages}
                    </span>
                  </div>
                  <h3 className="font-cairo font-bold text-base md:text-lg text-slate-900 dark:text-white truncate mt-0.5">
                    {viewingLesson.title}
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsZenStudyOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Focus className="w-3.5 h-3.5" />
                  <span>{isAr ? 'وضع المذاكرة المركّز (Zen)' : 'Zen Study Mode'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewingLesson(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 relative protected-lesson-area">
              {viewingLesson.format === 'video' ? (
                <div className="space-y-4">
                  <div
                    ref={videoContainerRef}
                    className="aspect-video w-full rounded-2xl overflow-hidden bg-black shadow-inner relative flex items-center justify-center"
                  >
                    <AlSharifWatermark
                      studentName={currentUser?.name}
                      studentCode={currentUser?.studentId || currentUser?.id}
                      studentPhone={currentUser?.phone}
                      extraLabel={viewingLesson.title}
                      opacity="medium"
                      enableJumpingWatermark={securityConfig.enableJumpingWatermark}
                      jumpingIntervalSec={securityConfig.watermarkJumpingIntervalSec}
                      enableAudioWatermark={securityConfig.enableAudioWatermark}
                      audioIntervalSec={securityConfig.audioWatermarkIntervalSec}
                    />
                    {viewingLesson.videoUrl &&
                    (viewingLesson.videoUrl.includes('youtube') ||
                      viewingLesson.videoUrl.includes('youtu.be')) ? (
                      <iframe
                        ref={youtubeIframeRef}
                        key={`${viewingLesson.id}-${youtubeSeekSeconds}`}
                        src={buildYouTubeEmbedSrc(viewingLesson.videoUrl, youtubeSeekSeconds)}
                        title={viewingLesson.title}
                        className="w-full h-full relative z-10"
                        allow="autoplay; encrypted-media"
                        allowFullScreen
                      />
                    ) : viewingLesson.videoUrl ? (
                      <video
                        ref={lessonVideoRef}
                        src={viewingLesson.videoUrl}
                        controls
                        controlsList="nodownload noplaybackrate"
                        disablePictureInPicture
                        onTimeUpdate={(e) => {
                          setCurrentVideoSeconds(Math.floor(e.currentTarget.currentTime || 0));
                        }}
                        className="w-full h-full relative z-10"
                      />
                    ) : (
                      <div className="text-center text-white p-6 relative z-10">
                        <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-3">
                          <Play className="w-8 h-8 text-white fill-white ml-1" />
                        </div>
                        <p className="font-cairo font-bold text-sm">
                          {isAr ? 'مشغل الفيديو التفاعلي جاهز للبث المباشر' : 'Interactive Video Ready'}
                        </p>
                        <p className="text-xs text-slate-300 mt-1 font-mono-numbers">
                          {viewingLesson.durationOrPages} · {formatSecondsMmSs(currentVideoSeconds)}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Timestamped Video Notes Panel (مفكرة ملاحظات الطالب المرتبطة بدقيقة الفيديو) */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/25 border border-indigo-200 dark:border-indigo-800/70 space-y-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                          <BookmarkPlus className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-cairo font-black text-xs sm:text-sm text-slate-900 dark:text-white">
                            {isAr
                              ? 'مفكرة ملاحظات الطالب المرتبطة بدقيقة الفيديو (Timestamped Notes)'
                              : 'Timestamped Video Notes'}
                          </h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            {isAr
                              ? 'دوّن ملاحظتك الآن مع الدقيقة والثانية، وعند الضغط عليها لاحقاً يقفز الفيديو لتلك اللحظة مباشرة.'
                              : 'Write a note bound to the exact MM:SS timestamp and click it later to jump right back.'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            exportLessonNotesToPdf({
                              lessonTitle: viewingLesson.title,
                              subject: viewingLesson.subject,
                              grade: viewingLesson.grade,
                              studentName: currentUser?.name || 'طالب منصة الشريف',
                              summaryHtml: viewingLesson.description,
                              notes: videoNotes,
                            })
                          }
                          className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-[11px] flex items-center gap-1.5 cursor-pointer shadow-xs"
                          title="تصدير جميع الملاحظات وملخص الدرس إلى ملف PDF منسق للمذاكرة الورقية"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>تصدير الملاحظات PDF</span>
                        </button>
                        <span className="px-3 py-1 rounded-xl bg-indigo-600 text-white font-mono-numbers font-bold text-xs flex items-center gap-1.5 shadow-xs">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{formatSecondsMmSs(currentVideoSeconds)}</span>
                        </span>
                        {!(
                          viewingLesson.videoUrl &&
                          !viewingLesson.videoUrl.includes('youtube') &&
                          !viewingLesson.videoUrl.includes('youtu.be')
                        ) && (
                          <button
                            type="button"
                            onClick={() => setIsWatchTimerRunning((v) => !v)}
                            className="p-1.5 rounded-xl border border-indigo-300 dark:border-indigo-700 bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-300 cursor-pointer"
                            title={isWatchTimerRunning ? 'إيقاف عداد الوقت مؤقتاً' : 'تشغيل عداد الوقت'}
                          >
                            {isWatchTimerRunning ? (
                              <Pause className="w-3.5 h-3.5" />
                            ) : (
                              <Play className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>

                    {!isParent && (
                      <form onSubmit={handleSaveTimestampedNote} className="flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={manualMmSsInput}
                          onChange={(e) => setManualMmSsInput(e.target.value)}
                          placeholder={formatSecondsMmSs(currentVideoSeconds)}
                          title="الوقت التلقائي (أو عدّله بصيغة MM:SS)"
                          className="w-full sm:w-24 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 text-xs font-mono-numbers text-center font-bold text-indigo-700 dark:text-indigo-300"
                        />
                        <input
                          type="text"
                          value={noteInputText}
                          onChange={(e) => setNoteInputText(e.target.value)}
                          placeholder={
                            isAr
                              ? 'اكتب ملاحظتك عند هذه الدقيقة (مثال: شرح قانون حساب التسارع)...'
                              : 'Write your study note at this timestamp...'
                          }
                          className="flex-1 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 text-xs font-tajawal"
                        />
                        <button
                          type="submit"
                          disabled={isSavingVideoNote || !noteInputText.trim()}
                          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                        >
                          <BookmarkPlus className="w-3.5 h-3.5" />
                          <span>{isSavingVideoNote ? 'جارِ الحفظ...' : 'حفظ الملاحظة'}</span>
                        </button>
                      </form>
                    )}

                    {videoNotes.length > 0 ? (
                      <div className="space-y-2 max-h-52 overflow-y-auto pr-0.5">
                        {[...videoNotes]
                          .sort((a, b) => a.timestampSeconds - b.timestampSeconds)
                          .map((note) => (
                            <div
                              key={note.id}
                              className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 flex items-center justify-between gap-2.5"
                            >
                              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                                <button
                                  type="button"
                                  onClick={() => handleSeekToVideoTimestamp(note.timestampSeconds)}
                                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-mono-numbers font-bold text-[11px] flex items-center gap-1 shrink-0 cursor-pointer shadow-xs"
                                  title="اضغط للانتقال مباشرة لهذه الدقيقة في الفيديو"
                                >
                                  <PlayCircle className="w-3.5 h-3.5" />
                                  <span>{note.formattedTime}</span>
                                </button>
                                <p className="text-xs text-slate-800 dark:text-slate-100 font-tajawal truncate">
                                  {note.noteText}
                                </p>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <span className="text-[10px] text-slate-400 hidden sm:inline">
                                  {note.studentName}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteTimestampedNote(note.id)}
                                  className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                                  title="حذف الملاحظة"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-500 text-center py-2">
                        لا توجد ملاحظات مسجلة لهذا الفيديو بعد — اكتب أول ملاحظة ليتم ربطها بالدقيقة الحالية!
                      </p>
                    )}
                  </div>
                </div>
              ) : viewingLesson.format === 'infographic' && viewingLesson.infographicData ? (
                <div className="space-y-3 relative overflow-hidden rounded-2xl">
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-cairo font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>{isAr ? 'طباعة / تصدير PDF' : 'Print PDF'}</span>
                    </button>
                  </div>
                  <InfographicRenderer
                    title={viewingLesson.title}
                    subject={viewingLesson.subject}
                    grade={viewingLesson.grade}
                    data={viewingLesson.infographicData}
                    language={language}
                  />
                </div>
              ) : (
                <div className="p-6 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-center space-y-3 relative overflow-hidden">
                  <AlSharifWatermark
                    studentName={currentUser?.name}
                    studentCode={currentUser?.studentId || currentUser?.id}
                    studentPhone={currentUser?.phone}
                    extraLabel={viewingLesson.title}
                    opacity="medium"
                    enableJumpingWatermark={securityConfig.enableJumpingWatermark}
                    jumpingIntervalSec={securityConfig.watermarkJumpingIntervalSec}
                    enableAudioWatermark={securityConfig.enableAudioWatermark}
                    audioIntervalSec={securityConfig.audioWatermarkIntervalSec}
                  />
                  <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center mx-auto relative z-30">
                    {viewingLesson.format === 'pdf' ? (
                      <FileText className="w-8 h-8 text-rose-500" />
                    ) : (
                      <FileCheck2 className="w-8 h-8 text-blue-500" />
                    )}
                  </div>
                  <div className="relative z-30">
                    <h4 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                      {viewingLesson.title}
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono-numbers">
                      {viewingLesson.durationOrPages} • العلامة المائية: منصة الشريف
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-2 pt-1 font-cairo relative z-30">
                    {viewingLesson.documentUrl && viewingLesson.documentUrl !== '#' && (
                      <a
                        href={viewingLesson.documentUrl}
                        download={viewingLesson.title}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{isAr ? 'فتح / تنزيل المذكرة المرفقة' : 'Open File'}</span>
                      </a>
                    )}
                    <button
                      type="button"
                      onClick={() => handleExportLessonWord(viewingLesson)}
                      className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <FileDown className="w-3.5 h-3.5" />
                      <span>{isAr ? 'تنزيل المذكرة Word (.doc)' : 'Download .doc'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>{isAr ? 'طباعة المذكرة PDF' : 'Print PDF'}</span>
                    </button>
                  </div>
                </div>
              )}

              {viewingLesson.format !== 'infographic' && viewingLesson.infographicData && (
                <div className="space-y-2 pt-2">
                  <h4 className="font-cairo font-bold text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                    <Layers className="w-4 h-4" />
                    <span>{isAr ? 'لوحة الانفوجرافيك المرفقة بالدرس:' : 'Attached Lesson Infographic:'}</span>
                  </h4>
                  <InfographicRenderer
                    title={viewingLesson.title}
                    subject={viewingLesson.subject}
                    grade={viewingLesson.grade}
                    data={viewingLesson.infographicData}
                    language={language}
                  />
                </div>
              )}

              {viewingLesson.contentHtml && (
                <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2 relative overflow-hidden">
                  <AlSharifWatermark
                    studentName={currentUser?.name}
                    studentCode={currentUser?.studentId || currentUser?.id}
                    studentPhone={currentUser?.phone}
                    extraLabel={viewingLesson.title}
                    opacity="medium"
                    enableJumpingWatermark={securityConfig.enableJumpingWatermark}
                    jumpingIntervalSec={securityConfig.watermarkJumpingIntervalSec}
                    enableAudioWatermark={securityConfig.enableAudioWatermark}
                    audioIntervalSec={securityConfig.audioWatermarkIntervalSec}
                  />
                  <h4 className="font-cairo font-bold text-xs text-slate-500 uppercase tracking-wider flex items-center justify-between gap-1.5 relative z-30">
                    <span className="flex items-center gap-1.5">
                      <FileCode className="w-4 h-4 text-emerald-600" />
                      <span>{isAr ? 'محتوى الدرس والمذكرة المكتوبة:' : 'Formatted Lesson & Study Notes:'}</span>
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-black">
                      علامة مائية: منصة الشريف
                    </span>
                  </h4>
                  <div
                    className="ck-rich-content max-w-none text-xs md:text-sm font-tajawal leading-relaxed text-slate-800 dark:text-slate-100 relative z-30"
                    dangerouslySetInnerHTML={{ __html: viewingLesson.contentHtml }}
                  />
                </div>
              )}

              {/* Metadata Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/80 text-xs">
                <div>
                  <span className="text-slate-400 block font-cairo">{isAr ? 'المادة' : 'Subject'}</span>
                  <span className="font-cairo font-bold text-slate-900 dark:text-white text-sm">
                    {viewingLesson.subject}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-cairo">{isAr ? 'المرحلة' : 'Grade'}</span>
                  <span className="font-cairo font-bold text-slate-900 dark:text-white text-sm">
                    {viewingLesson.grade}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-cairo">{isAr ? 'المعلم' : 'Teacher'}</span>
                  <span className="font-cairo font-bold text-slate-900 dark:text-white text-sm">
                    {viewingLesson.teacherName}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-cairo">{isAr ? 'الوحدة' : 'Unit'}</span>
                  <span className="font-cairo font-bold text-slate-900 dark:text-white text-sm">
                    {viewingLesson.unit || 'الوحدة الأولى'}
                  </span>
                </div>
              </div>

              {viewingLesson.description && hasMeaningfulHtmlContent(viewingLesson.description) && (
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 space-y-2">
                  <h4 className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                    {isAr ? 'ملخص الدرس والأهداف التعليمية:' : 'Lesson Summary & Objectives:'}
                  </h4>
                  {hasHtmlMarkup(viewingLesson.description) ? (
                    <div
                      className="ck-rich-content text-xs md:text-sm text-slate-700 dark:text-slate-200 font-tajawal leading-relaxed"
                      dangerouslySetInnerHTML={{ __html: viewingLesson.description }}
                    />
                  ) : (
                    <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 font-tajawal leading-relaxed whitespace-pre-line">
                      {viewingLesson.description}
                    </p>
                  )}
                </div>
              )}

              {/* Views & Likes */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-4 text-xs font-mono-numbers text-slate-600 dark:text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <ViewsIcon className="w-4 h-4 text-slate-400" />
                    <span>
                      {viewingLesson.viewsCount || 1} {isAr ? 'مشاهدة' : 'Views'}
                    </span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <ThumbsUp className="w-4 h-4 text-emerald-600" />
                    <span>
                      {viewingLesson.likesCount || 0} {isAr ? 'إعجاب' : 'Likes'}
                    </span>
                  </span>
                </div>

                {!isParent && (
                  <button
                    type="button"
                    onClick={() => handleLikeLesson(viewingLesson.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs shadow-xs cursor-pointer"
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إعجاب بالدرس' : 'Like Lesson'}</span>
                  </button>
                )}
              </div>

              {/* ================= QUICK STAR RATING SURVEY (استبيان تقييم الدرس) ================= */}
              {(() => {
                const stats = getLessonRatingStats(viewingLesson.id);
                const myExisting = ratingsList.find(
                  (r) => r.lessonId === viewingLesson.id && r.studentId === currentActorStudentId
                );

                return (
                  <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/50 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0">
                          <Star className="w-5 h-5 fill-slate-950" />
                        </div>
                        <div>
                          <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                            {isAr ? 'استبيان تقييم جودة الدرس' : 'Lesson Quality Star Survey'}
                          </h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 font-tajawal">
                            {isAr
                              ? 'تقييم سريع بالنجوم يتركه الطالب لمساعدة الإدارة والمشرفين في قياس جودة المحتوى'
                              : 'Quick student rating survey helping supervisors measure content quality'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 text-xs font-mono-numbers">
                        <div className="flex items-center gap-1 font-black text-amber-600 dark:text-amber-400 text-base">
                          <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                          <span>{stats.count > 0 ? stats.avg : '—'}</span>
                          <span className="text-xs text-slate-400 font-normal">/ 5</span>
                        </div>
                        <span className="text-slate-400">·</span>
                        <span className="font-cairo font-bold text-slate-600 dark:text-slate-300">
                          {stats.count} {isAr ? 'تقييم' : 'ratings'}
                        </span>
                      </div>
                    </div>

                    {stats.count > 0 && (
                      <div className="grid grid-cols-3 gap-2 text-center bg-white dark:bg-slate-900/80 rounded-xl p-3 border border-amber-100 dark:border-slate-800 text-xs">
                        <div>
                          <span className="text-[11px] text-slate-400 block font-cairo">
                            {isAr ? 'التقييم العام' : 'Overall'}
                          </span>
                          <strong className="font-mono-numbers text-sm text-amber-600 dark:text-amber-400">
                            ★ {stats.avg}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[11px] text-slate-400 block font-cairo">
                            {isAr ? 'وضوح الشرح' : 'Clarity'}
                          </span>
                          <strong className="font-mono-numbers text-sm text-emerald-700 dark:text-emerald-400">
                            ★ {stats.clarityAvg}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[11px] text-slate-400 block font-cairo">
                            {isAr ? 'الفائدة العلمية' : 'Benefit'}
                          </span>
                          <strong className="font-mono-numbers text-sm text-blue-700 dark:text-blue-400">
                            ★ {stats.benefitAvg}
                          </strong>
                        </div>
                      </div>
                    )}

                    {/* Interactive Survey Form for Students (and Admin preview) */}
                    {canSubmitSurvey && (
                      <form
                        onSubmit={handleSubmitLessonRating}
                        className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-cairo font-bold text-xs text-slate-800 dark:text-slate-200">
                            {myExisting
                              ? isAr
                                ? 'تحديث تقييمك السابق لهذا الدرس:'
                                : 'Update your previous rating:'
                              : isAr
                              ? 'شاركنا تقييمك السريع بعد مشاهدة الدرس:'
                              : 'Leave your quick star rating:'}
                          </span>
                          {!isStudent && (
                            <span className="text-[10px] font-cairo text-slate-400">
                              {isAr ? 'معاينة / اختبار الإدارة' : 'Admin Preview'}
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {[
                            {
                              label: isAr ? 'التقييم العام' : 'Overall',
                              val: surveyRating,
                              setVal: setSurveyRating,
                            },
                            {
                              label: isAr ? 'وضوح الشرح' : 'Clarity',
                              val: surveyClarity,
                              setVal: setSurveyClarity,
                            },
                            {
                              label: isAr ? 'الفائدة العلمية' : 'Benefit',
                              val: surveyBenefit,
                              setVal: setSurveyBenefit,
                            },
                          ].map((criterion) => (
                            <div
                              key={criterion.label}
                              className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex flex-col items-center gap-1.5"
                            >
                              <span className="text-[11px] font-cairo font-bold text-slate-600 dark:text-slate-300">
                                {criterion.label}
                              </span>
                              <div className="flex items-center gap-1" dir="ltr">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <button
                                    key={star}
                                    type="button"
                                    onClick={() => criterion.setVal(star)}
                                    className="p-0.5 hover:scale-110 transition-transform cursor-pointer"
                                    title={`${star} / 5`}
                                  >
                                    <Star
                                      className={`w-5 h-5 ${
                                        star <= criterion.val
                                          ? 'fill-amber-400 text-amber-500'
                                          : 'text-slate-300 dark:text-slate-600'
                                      }`}
                                    />
                                  </button>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="flex flex-col sm:flex-row gap-2">
                          <input
                            type="text"
                            value={surveyComment}
                            onChange={(e) => setSurveyComment(e.target.value)}
                            placeholder={
                              isAr
                                ? 'ملاحظة سريعة أو تعليق حول الدرس (اختياري)...'
                                : 'Optional comment on lesson quality...'
                            }
                            className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                          />
                          <button
                            type="submit"
                            disabled={isSubmittingRating}
                            className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>
                              {isSubmittingRating
                                ? isAr
                                  ? 'جارِ الحفظ...'
                                  : 'Saving...'
                                : myExisting
                                ? isAr
                                  ? 'تحديث التقييم'
                                  : 'Update Rating'
                                : isAr
                                ? 'إرسال التقييم'
                                : 'Submit Rating'}
                            </span>
                          </button>
                        </div>
                      </form>
                    )}

                    {/* Recent Reviews for this Lesson */}
                    {stats.reviews.length > 0 && (
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                        {stats.reviews.map((rev) => (
                          <div
                            key={rev.id}
                            className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-2 text-xs"
                          >
                            <div className="space-y-1 min-w-0">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-cairo font-bold text-slate-900 dark:text-white">
                                  {rev.studentName}
                                </span>
                                <span className="inline-flex items-center gap-0.5 text-amber-500 font-mono-numbers font-bold">
                                  <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                                  {rev.rating}/5
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono-numbers">
                                  {isAr
                                    ? `الشرح ${rev.clarityRating} · الفائدة ${rev.benefitRating}`
                                    : `Clarity ${rev.clarityRating} · Benefit ${rev.benefitRating}`}
                                </span>
                              </div>
                              {rev.comment && (
                                <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
                                  {rev.comment}
                                </p>
                              )}
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-[10px] text-slate-400 font-mono-numbers">
                                {rev.createdAt ? String(rev.createdAt).slice(0, 10) : ''}
                              </span>
                              {canModerateRatings && (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteLessonRating(rev.id)}
                                  className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                                  title={isAr ? 'حذف التقييم' : 'Delete Rating'}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Sequential Mastery Quiz Call-to-Action inside Lesson Viewer */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-900 to-teal-900 text-white flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="font-cairo font-black text-sm">
                    اختبار إتقان الدرس لفتح الدرس التالي (الحد الأدنى {sequentialConfig.minimumPassPercentage}%)
                  </h4>
                  <p className="text-xs text-emerald-100 font-tajawal">
                    بعد مشاهدة هذا الدرس، أجب عن 4 أسئلة سريعة لفتح الدرس التالي وتسجيل درجتك في قاعدة البيانات.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const target = viewingLesson;
                    setViewingLesson(null);
                    openLessonMasteryQuiz(target);
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-cairo font-black text-xs cursor-pointer shadow-md"
                >
                  بدء اختبار اجتياز الدرس الآن ({sequentialConfig.minimumPassPercentage}%)
                </button>
              </div>

              {/* Live Code Sandbox inside Lesson Viewer (مختبر الأكواد التفاعلي المباشر) */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 p-3.5 rounded-2xl bg-slate-900 text-white border border-slate-700">
                  <div className="flex items-center gap-2 font-cairo">
                    <Code2 className="w-5 h-5 text-emerald-400" />
                    <div>
                      <h4 className="font-black text-xs sm:text-sm">مختبر الأكواد التفاعلي المباشر (HTML / CSS / JS / Python)</h4>
                      <p className="text-[11px] text-slate-300 font-tajawal">طبّق الأكواد وشاهد المخرجات فوراً بجانب الدرس دون مغادرة المنصة.</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 font-cairo">
                    <button
                      type="button"
                      onClick={() =>
                        exportLessonNotesToPdf({
                          lessonTitle: viewingLesson.title,
                          subject: viewingLesson.subject,
                          grade: viewingLesson.grade,
                          studentName: currentUser?.name || 'طالب منصة الشريف',
                          summaryHtml: viewingLesson.description,
                          notes: videoNotes,
                        })
                      }
                      className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>تصدير الملاحظات والملخص PDF</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsLessonSandboxOpen((v) => !v)}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs cursor-pointer"
                    >
                      {isLessonSandboxOpen ? 'إخفاء المختبر' : 'تشغيل مختبر الأكواد'}
                    </button>
                  </div>
                </div>
                {isLessonSandboxOpen && (
                  <LiveCodeSandbox
                    title={`مختبر تطبيق: ${viewingLesson.title}`}
                    initialLanguage={
                      viewingLesson.subject.includes('برمج') || viewingLesson.title.toLowerCase().includes('python')
                        ? 'python'
                        : 'html'
                    }
                    onClose={() => setIsLessonSandboxOpen(false)}
                  />
                )}
              </div>

              {/* Lesson Q&A Thread («ركن اسأل المعلم أسفل كل درس») */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <span>{isAr ? 'ركن «اسأل المعلم» — استفسارات هذا الدرس' : 'Ask the Teacher — Lesson Q&A'}</span>
                  </h4>
                  <span className="text-[11px] font-mono-numbers text-slate-500">
                    {lessonQaList.length} {isAr ? 'استفسار' : 'questions'}
                  </span>
                </div>

                {!isParent && (
                  <div className="space-y-2">
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={qaInputText}
                        onChange={(e) => setQaInputText(e.target.value)}
                        placeholder={isAr ? 'اكتب سؤالك حول هذا الدرس ليظهر للمعلم وزملائك...' : 'Ask a question about this lesson...'}
                        className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                      <button
                        type="button"
                        disabled={isSubmittingQa || !qaInputText.trim()}
                        onClick={async () => {
                          setIsSubmittingQa(true);
                          try {
                            const res = await fetch('/api/lesson-qa', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
                              body: JSON.stringify({
                                lessonId: viewingLesson.id,
                                lessonTitle: viewingLesson.title,
                                subject: viewingLesson.subject,
                                questionText: qaInputText.trim(),
                                videoTimestampSec:
                                  qaLinkVideoTime && viewingLesson.format === 'video' ? currentVideoSeconds : null,
                                authorId: currentActorStudentId,
                                authorName: currentUser?.name || 'طالب',
                              }),
                            });
                            const item = await res.json();
                            if (res.ok) {
                              setLessonQaList((prev) => [item, ...prev]);
                              setQaInputText('');
                              showToast(isAr ? 'تم نشر سؤالك في ركن اسأل المعلم' : 'Question posted', 'success');
                            }
                          } finally {
                            setIsSubmittingQa(false);
                          }
                        }}
                        className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs cursor-pointer shrink-0"
                      >
                        {isAr ? 'إرسال السؤال' : 'Post Question'}
                      </button>
                    </div>
                    {viewingLesson.format === 'video' && (
                      <label className="inline-flex items-center gap-1.5 text-[11px] text-slate-500 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={qaLinkVideoTime}
                          onChange={(e) => setQaLinkVideoTime(e.target.checked)}
                          className="accent-emerald-600"
                        />
                        <span>
                          {isAr
                            ? `ربط السؤال بالدقيقة الحالية في الفيديو (${formatSecondsMmSs(currentVideoSeconds)})`
                            : `Link to timestamp (${formatSecondsMmSs(currentVideoSeconds)})`}
                        </span>
                      </label>
                    )}
                  </div>
                )}

                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                  {lessonQaList.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-3">
                      {isAr ? 'لا توجد استفسارات مسجلة لهذا الدرس بعد — كن أول من يسأل المعلم.' : 'No questions yet.'}
                    </p>
                  ) : (
                    lessonQaList.map((qa) => (
                      <div
                        key={qa.id}
                        className={`p-3 rounded-xl border text-xs space-y-2 ${
                          qa.isPinned
                            ? 'bg-emerald-50/60 dark:bg-emerald-950/25 border-emerald-300 dark:border-emerald-800'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-1.5">
                            {qa.isPinned && (
                              <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white font-cairo font-bold text-[10px] inline-flex items-center gap-1">
                                <Pin className="w-3 h-3" /> {isAr ? 'أفضل إجابة مثبّتة' : 'Pinned Best Answer'}
                              </span>
                            )}
                            <span className="font-cairo font-bold text-slate-800 dark:text-white">
                              {qa.authorName}
                            </span>
                            {qa.videoTimestampSec !== null && qa.videoTimestampSec !== undefined && (
                              <button
                                type="button"
                                onClick={() => setYoutubeSeekSeconds(qa.videoTimestampSec || 0)}
                                className="font-mono-numbers text-[11px] text-sky-600 hover:underline cursor-pointer"
                              >
                                @{formatSecondsMmSs(qa.videoTimestampSec)}
                              </button>
                            )}
                            <span className="text-slate-400 text-[10px]">{qa.createdAt}</span>
                          </div>
                          <button
                            type="button"
                            onClick={async () => {
                              const r = await fetch(`/api/lesson-qa/${encodeURIComponent(qa.id)}/upvote`, { method: 'PUT' });
                              if (r.ok) {
                                const upd = await r.json();
                                setLessonQaList((prev) => prev.map((x) => (x.id === qa.id ? upd : x)));
                              }
                            }}
                            className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-mono-numbers text-slate-600 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
                          >
                            ▲ {qa.upvotes || 0}
                          </button>
                        </div>

                        <p className="text-slate-900 dark:text-slate-100 font-semibold leading-relaxed">
                          {qa.questionText}
                        </p>

                        {qa.answerText && (
                          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-1">
                            <span className="text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-400 block">
                              {isAr ? `رد المعلم (${qa.answeredBy || 'هيئة التدريس'}):` : `Teacher Reply:`}
                            </span>
                            <p className="text-slate-700 dark:text-slate-200 leading-relaxed">{qa.answerText}</p>
                          </div>
                        )}

                        {canManageLessonItem(viewingLesson) && (
                          <div className="flex flex-wrap items-center gap-2 pt-1">
                            <input
                              type="text"
                              value={qaAnswerDrafts[qa.id] ?? qa.answerText ?? ''}
                              onChange={(e) => setQaAnswerDrafts((p) => ({ ...p, [qa.id]: e.target.value }))}
                              placeholder={isAr ? 'اكتب رد المعلم...' : 'Write official answer...'}
                              className="flex-1 min-w-[180px] px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                            />
                            <button
                              type="button"
                              onClick={async () => {
                                const res = await fetch(`/api/lesson-qa/${encodeURIComponent(qa.id)}/answer`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
                                  body: JSON.stringify({
                                    answerText: qaAnswerDrafts[qa.id] ?? qa.answerText ?? '',
                                  }),
                                });
                                if (res.ok) {
                                  const upd = await res.json();
                                  setLessonQaList((prev) => prev.map((x) => (x.id === qa.id ? upd : x)));
                                  showToast(isAr ? 'تم نشر الرد ✓' : 'Answer saved');
                                }
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-700 text-white font-cairo font-bold text-[11px] cursor-pointer"
                            >
                              {isAr ? 'حفظ الرد' : 'Save Reply'}
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                const res = await fetch(`/api/lesson-qa/${encodeURIComponent(qa.id)}/answer`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
                                  body: JSON.stringify({ isPinned: !qa.isPinned }),
                                });
                                if (res.ok) {
                                  const upd = await res.json();
                                  setLessonQaList((prev) => prev.map((x) => (x.id === qa.id ? upd : x)));
                                }
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-amber-100 text-amber-800 font-cairo font-bold text-[11px] cursor-pointer"
                            >
                              {qa.isPinned ? (isAr ? 'إلغاء التثبيت' : 'Unpin') : (isAr ? 'تثبيت كأفضل إجابة' : 'Pin Answer')}
                            </button>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 font-cairo">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleToggleLessonBookmark(viewingLesson.id)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl border font-bold text-xs cursor-pointer ${
                      bookmarkedLessonIds.includes(viewingLesson.id)
                        ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-400 text-amber-800 dark:text-amber-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${bookmarkedLessonIds.includes(viewingLesson.id) ? 'fill-amber-500 text-amber-500' : ''}`} />
                    <span>{bookmarkedLessonIds.includes(viewingLesson.id) ? 'محفوظ في المفضلة ★' : 'حفظ الدرس'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setReportingLesson(viewingLesson);
                      setReportCategory('needs_clarification');
                      setReportDetails('');
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/70 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-bold text-xs hover:bg-rose-100 cursor-pointer"
                  >
                    <Flag className="w-3.5 h-3.5" />
                    <span>إبلاغ عن مشكلة / خطأ بالدرس</span>
                  </button>

                  {canManageLessonItem(viewingLesson) && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          const target = viewingLesson;
                          setViewingLesson(null);
                          handleOpenEdit(target);
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5 text-blue-600" />
                        <span>{isAr ? 'تعديل الدرس' : 'Edit Lesson'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const target = viewingLesson;
                          setViewingLesson(null);
                          setLessonToDelete(target);
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 font-bold text-xs hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        <span>{isAr ? 'حذف الدرس' : 'Delete Lesson'}</span>
                      </button>
                    </>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setViewingLesson(null)}
                  className="px-5 py-2 rounded-xl bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 font-bold text-xs cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= ZEN STUDY OVERLAY (DISTRACTION-FREE MODE) ================= */}
      {viewingLesson && isZenStudyOpen && (
        <ZenStudyOverlay
          lesson={viewingLesson}
          currentUser={currentUser}
          teachers={teachers}
          language={language}
          onClose={() => setIsZenStudyOpen(false)}
          renderLessonBody={() => (
            <div className="space-y-4">
              {viewingLesson.format === 'video' && viewingLesson.videoUrl && (
                <div className="aspect-video w-full rounded-xl overflow-hidden bg-black">
                  {(viewingLesson.videoUrl.includes('youtube') || viewingLesson.videoUrl.includes('youtu.be')) ? (
                    <iframe
                      src={buildYouTubeEmbedSrc(viewingLesson.videoUrl, youtubeSeekSeconds)}
                      title={viewingLesson.title}
                      className="w-full h-full border-0"
                      allowFullScreen
                    />
                  ) : (
                    <video src={viewingLesson.videoUrl} controls className="w-full h-full" />
                  )}
                </div>
              )}
              {viewingLesson.infographicData && (
                <InfographicRenderer
                  title={viewingLesson.title}
                  subject={viewingLesson.subject}
                  grade={viewingLesson.grade}
                  data={viewingLesson.infographicData}
                  language={language}
                />
              )}
              {viewingLesson.contentHtml && (
                <div
                  className="ck-rich-content max-w-none text-sm leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: viewingLesson.contentHtml }}
                />
              )}
              {viewingLesson.description && hasMeaningfulHtmlContent(viewingLesson.description) && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs leading-relaxed">
                  {hasHtmlMarkup(viewingLesson.description) ? (
                    <div dangerouslySetInnerHTML={{ __html: viewingLesson.description }} />
                  ) : (
                    <p>{viewingLesson.description}</p>
                  )}
                </div>
              )}
            </div>
          )}
        />
      )}

      {/* ================= MODAL: DELETE CONFIRMATION ================= */}
      {lessonToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="font-cairo font-bold text-base md:text-lg text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف الدرس من قاعدة البيانات' : 'Confirm Deletion'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal">
                {isAr
                  ? 'هل أنت متأكد من حذف هذا الدرس نهائياً من قاعدة البيانات؟'
                  : 'Are you sure you want to permanently delete this lesson?'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-right space-y-1">
              <p className="font-cairo font-bold text-xs text-slate-900 dark:text-white truncate">
                {lessonToDelete.title}
              </p>
              <div className="flex items-center gap-2 text-[11px] text-slate-500 font-tajawal">
                <span>{lessonToDelete.subject}</span>
                <span>•</span>
                <span>{lessonToDelete.teacherName}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 font-cairo">
              <button
                type="button"
                onClick={() => setLessonToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                {isAr ? 'نعم، احذف الدرس' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CKEditor Modal (Empty on new, populated when editing) */}
      <CKEditorModal
        isOpen={isCKEditorOpen}
        onClose={() => {
          setIsCKEditorOpen(false);
          setCkEditorEditingLesson(null);
        }}
        onSaveLesson={handleSaveFromCKEditor}
        language={language}
        teachers={teachers}
        initialLesson={ckEditorEditingLesson}
      />

      {/* Infographic Studio Modal (10 Templates + 6 Themes) */}
      <InfographicLessonModal
        isOpen={isInfographicOpen}
        onClose={() => {
          setIsInfographicOpen(false);
          setInfographicEditingLesson(null);
        }}
        onSaveLesson={handleSaveFromInfographic}
        language={language}
        teachers={teachers}
        initialLesson={infographicEditingLesson}
      />

      {/* ================= MODAL: ADMIN / SUPERVISOR QUALITY REPORT ================= */}
      {isRatingsReportOpen && canModerateRatings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 bg-[#0c3d36] text-white flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-base">
                    {isAr ? 'مؤشرات جودة المحتوى وتقييمات الدروس' : 'Content Quality & Lesson Ratings'}
                  </h3>
                  <p className="text-xs text-emerald-100/80">
                    {isAr
                      ? `متوسط التقييم العام: ${overallRatingsAverage || '—'} / 5 · إجمالي الاستبيانات: ${ratingsList.length}`
                      : `Overall Average: ${overallRatingsAverage || '—'} / 5 · Total Surveys: ${ratingsList.length}`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsRatingsReportOpen(false)}
                className="p-1.5 rounded-xl text-emerald-100 hover:text-white hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              {ratingsList.length === 0 ? (
                <div className="p-10 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
                  {isAr
                    ? 'لم يتم تسجيل أي استبيانات تقييم للدروس بعد.'
                    : 'No lesson rating surveys submitted yet.'}
                </div>
              ) : (
                <>
                  {/* Per-lesson summary */}
                  <div className="space-y-2">
                    <h4 className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      {isAr ? 'ترتيب الدروس حسب تقييم الطلاب:' : 'Lessons ranked by student rating:'}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {lessonsList
                        .map((les) => ({ les, stats: getLessonRatingStats(les.id) }))
                        .filter((item) => item.stats.count > 0)
                        .sort((a, b) => b.stats.avg - a.stats.avg)
                        .map(({ les, stats }) => (
                          <div
                            key={les.id}
                            className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 text-xs"
                          >
                            <div className="min-w-0">
                              <p className="font-cairo font-bold text-slate-900 dark:text-white truncate">
                                {les.title}
                              </p>
                              <span className="text-[11px] text-slate-500">
                                {les.subject} · {les.teacherName}
                              </span>
                            </div>
                            <div className="text-left shrink-0 font-mono-numbers">
                              <span className="inline-flex items-center gap-1 font-black text-amber-600 dark:text-amber-400">
                                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                                {stats.avg}
                              </span>
                              <span className="block text-[10px] text-slate-400">
                                {stats.count} {isAr ? 'تقييم' : 'votes'}
                              </span>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* All recent reviews */}
                  <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <h4 className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      {isAr ? 'أحدث آراء وتقييمات الطلاب:' : 'Latest Student Feedback:'}
                    </h4>
                    <div className="space-y-2">
                      {ratingsList.map((rev) => (
                        <div
                          key={rev.id}
                          className="p-3 rounded-xl bg-white dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3 text-xs"
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-cairo font-bold text-slate-900 dark:text-white">
                                {rev.lessonTitle}
                              </span>
                              <span className="text-slate-400">·</span>
                              <span className="text-emerald-700 dark:text-emerald-400 font-bold">
                                {rev.studentName}
                              </span>
                              <span className="inline-flex items-center gap-0.5 text-amber-600 font-mono-numbers font-bold">
                                ★ {rev.rating}/5
                              </span>
                            </div>
                            {rev.comment && (
                              <p className="text-slate-600 dark:text-slate-300 text-[11px]">{rev.comment}</p>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => handleDeleteLessonRating(rev.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer shrink-0"
                            title={isAr ? 'حذف التقييم' : 'Delete Rating'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: QUICK ACTIVATION CODE UNLOCK FOR LOCKED LESSONS ================= */}
      {lockedLessonPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border-2 border-amber-500/60 shadow-2xl p-6 space-y-5 text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/15 border border-amber-400/50 text-amber-500 flex items-center justify-center mx-auto">
              <Lock className="w-8 h-8" />
            </div>
            <div className="space-y-1.5">
              <span className="px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-cairo font-bold text-xs">
                درس محمي بكود تفعيل — منصة الشريف
              </span>
              <h3 className="font-cairo font-black text-lg text-slate-900 dark:text-white pt-1">
                {lockedLessonPrompt.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                هذا الدرس متاح للطلاب المشتركين أو حاملي بطاقة التفعيل (Scratch Card). أدخل كود التفعيل الخاص بك لفتح الدرس فوراً:
              </p>
            </div>

            <form onSubmit={handleQuickRedeemLessonCode} className="space-y-3">
              <div className="relative">
                <KeyRound className="w-4 h-4 absolute top-3.5 right-3.5 text-amber-500" />
                <input
                  type="text"
                  required
                  dir="ltr"
                  value={quickActivationCode}
                  onChange={(e) => setQuickActivationCode(e.target.value.toUpperCase())}
                  placeholder="SHARIF-XXXX-XXXX"
                  className="w-full pr-10 pl-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 font-mono-numbers font-black text-sm text-center tracking-wider uppercase text-slate-900 dark:text-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setLockedLessonPrompt(null)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-cairo font-bold text-xs cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isRedeemingCode}
                  className="flex-2 py-2.5 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-cairo font-black text-xs shadow-md cursor-pointer"
                >
                  {isRedeemingCode ? 'جارِ التفعيل...' : 'تفعيل الكود وفتح الدرس الآن'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: SEQUENTIAL LOCK PROMPT (شرط اجتياز الدرس السابق) ================= */}
      {sequentialBlockedPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border-2 border-rose-500/60 shadow-2xl p-6 space-y-4 text-center">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/15 border border-rose-400/40 text-rose-600 flex items-center justify-center mx-auto">
              <Lock className="w-8 h-8" />
            </div>
            <span className="px-3 py-1 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 font-cairo font-bold text-xs">
              قفل التسلسل الأكاديمي — منصة الشريف
            </span>
            <h3 className="font-cairo font-black text-base md:text-lg text-slate-900 dark:text-white">
              لا يمكن فتح «{sequentialBlockedPrompt.targetLesson.title}» قبل إتقان الدرس السابق
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              لفتح هذا الدرس والانتقال إليه، يشترط مشاهدة الدرس السابق{' '}
              <strong className="text-emerald-700 dark:text-emerald-400">
                «{sequentialBlockedPrompt.prerequisiteLesson.title}»
              </strong>{' '}
              واجتياز اختباره القصير بنسبة لا تقل عن{' '}
              <strong className="font-mono-numbers text-rose-600">
                {sequentialConfig.minimumPassPercentage}%
              </strong>{' '}
              (أعلى نتيجة مسجلة لك حالياً: {sequentialBlockedPrompt.currentBestPct}%).
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-2 pt-2 font-cairo">
              <button
                type="button"
                onClick={() => {
                  const prereq = sequentialBlockedPrompt.prerequisiteLesson;
                  setSequentialBlockedPrompt(null);
                  handleOpenViewDetails(prereq);
                }}
                className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs cursor-pointer"
              >
                1. مشاهدة الدرس السابق الآن
              </button>
              <button
                type="button"
                onClick={() => {
                  const prereq = sequentialBlockedPrompt.prerequisiteLesson;
                  setSequentialBlockedPrompt(null);
                  openLessonMasteryQuiz(prereq);
                }}
                className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs cursor-pointer"
              >
                2. بدء اختبار الدرس السابق ({sequentialConfig.minimumPassPercentage}%)
              </button>
            </div>
            <button
              type="button"
              onClick={() => setSequentialBlockedPrompt(null)}
              className="text-xs font-cairo font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* ================= MODAL: SHORT LESSON MASTERY QUIZ (اختبار اجتياز الدرس لفتح الدرس التالي) ================= */}
      {masteryQuizLesson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-5 bg-emerald-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[11px] font-cairo font-bold text-amber-300">
                  اختبار الإتقان القصير لفتح الدرس التالي (الحد الأدنى {sequentialConfig.minimumPassPercentage}%)
                </span>
                <h3 className="font-cairo font-black text-base md:text-lg mt-0.5">
                  {masteryQuizLesson.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setMasteryQuizLesson(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitMasteryQuiz} className="p-5 overflow-y-auto space-y-4 text-xs md:text-sm">
              {masteryResult && (
                <div
                  className={`p-4 rounded-2xl border-2 text-center space-y-1.5 ${
                    masteryResult.passed
                      ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-900 dark:text-emerald-200'
                      : 'bg-rose-50 dark:bg-rose-950/50 border-rose-500 text-rose-900 dark:text-rose-200'
                  }`}
                >
                  <p className="font-cairo font-black text-base">
                    {masteryResult.passed
                      ? `🎉 مبروك! اجتزت الاختبار بنسبة ${masteryResult.scorePct}% (${masteryResult.earned}/${masteryResult.total}) وتم فتح الدرس التالي!`
                      : `حصلت على ${masteryResult.scorePct}% (${masteryResult.earned}/${masteryResult.total}) — يلزم ${sequentialConfig.minimumPassPercentage}% لفتح الدرس التالي`}
                  </p>
                </div>
              )}

              {buildLessonMasteryQuestions(masteryQuizLesson).map((item, qIdx) => (
                <div
                  key={qIdx}
                  className="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-950/30 border border-slate-200 dark:border-slate-800 space-y-3"
                >
                  <div className={MCQ_QUESTION_BOX_CLASS}>
                    <p className="font-cairo font-bold text-slate-900 dark:text-slate-100 leading-relaxed">
                      {qIdx + 1}. {item.q}
                    </p>
                  </div>
                  <div className="space-y-2">
                    {item.options.map((opt, oIdx) => (
                      <label
                        key={oIdx}
                        className={`flex items-center gap-2.5 p-3 rounded-xl border-2 cursor-pointer transition-all font-cairo font-bold text-xs sm:text-sm ${getMcqOptionSurfaceClass(
                          oIdx,
                          { isSelected: masteryAnswers[qIdx] === oIdx }
                        )}`}
                      >
                        <input
                          type="radio"
                          name={`mastery-q-${qIdx}`}
                          checked={masteryAnswers[qIdx] === oIdx}
                          onChange={() =>
                            setMasteryAnswers((prev) => ({ ...prev, [qIdx]: oIdx }))
                          }
                          className="accent-sky-600"
                        />
                        <span>{opt}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}

              <div className="pt-2 flex items-center justify-end gap-2 font-cairo">
                <button
                  type="button"
                  onClick={() => setMasteryQuizLesson(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-xs cursor-pointer"
                >
                  إغلاق
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingMastery}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs cursor-pointer shadow-md"
                >
                  {isSubmittingMastery ? 'جارِ التصحيح...' : 'اعتماد الإجابات وفتح الدرس التالي'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: REPORT LESSON PROBLEM ================= */}
      {reportingLesson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 bg-rose-600 text-white flex items-center justify-between font-cairo">
              <div className="flex items-center gap-2">
                <Flag className="w-5 h-5" />
                <h4 className="font-black text-sm">إبلاغ عن مشكلة في المحتوى</h4>
              </div>
              <button
                type="button"
                onClick={() => setReportingLesson(null)}
                className="p-1 rounded-lg bg-white/15 hover:bg-white/25"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleSubmitContentReport} className="p-5 space-y-4">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs font-cairo font-bold text-slate-800 dark:text-slate-200">
                الدرس: {reportingLesson.title}
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold font-cairo text-slate-600 dark:text-slate-300">
                  نوع المشكلة:
                </label>
                <select
                  value={reportCategory}
                  onChange={(e) => setReportCategory(e.target.value as ContentErrorReportCategory)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo font-bold"
                >
                  <option value="typo">خطأ مطبعي / إملائي</option>
                  <option value="broken_link">رابط فيديو أو ملف لا يعمل</option>
                  <option value="needs_clarification">نقطة أو سؤال يحتاج توضيح</option>
                  <option value="other">ملاحظة أخرى</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold font-cairo text-slate-600 dark:text-slate-300">
                  التفاصيل (اختياري):
                </label>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="صف المشكلة أو الدقيقة التي تحتاج مراجعة ليصل البلاغ للمعلم مباشرة..."
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-tajawal outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
              <div className="flex justify-end gap-2 font-cairo">
                <button
                  type="button"
                  onClick={() => setReportingLesson(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReport}
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black"
                >
                  {isSubmittingReport ? 'جارِ الإرسال...' : 'إرسال البلاغ للمعلم والأدمن'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: STAFF CONTENT ERROR REPORTS QUEUE ================= */}
      {isReportsQueueOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between font-cairo">
              <div className="flex items-center gap-2">
                <Flag className="w-5 h-5 text-rose-400" />
                <h4 className="font-black text-sm">سجل بلاغات أخطاء المحتوى والأسئلة ({contentReports.length})</h4>
              </div>
              <button
                type="button"
                onClick={() => setIsReportsQueueOpen(false)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 overflow-y-auto space-y-3">
              {contentReports.length === 0 ? (
                <p className="text-center text-sm text-slate-500 py-8 font-tajawal">
                  لا توجد بلاغات مسجلة حتى الآن.
                </p>
              ) : (
                contentReports.map((rep) => (
                  <div
                    key={rep.id}
                    className={`p-4 rounded-2xl border space-y-2 ${
                      rep.status === 'open'
                        ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800/60'
                        : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 opacity-80'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 font-cairo text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-md font-black ${rep.status === 'open' ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'}`}>
                          {rep.status === 'open' ? 'مفتوح' : 'تم الحل'}
                        </span>
                        <span className="font-bold text-slate-900 dark:text-white">{rep.targetTitle}</span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                          {rep.category === 'typo'
                            ? 'خطأ مطبعي'
                            : rep.category === 'broken_link'
                            ? 'رابط لا يعمل'
                            : rep.category === 'needs_clarification'
                            ? 'يحتاج توضيح'
                            : 'أخرى'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            handleResolveContentReport(rep.id, rep.status === 'open' ? 'resolved' : 'open')
                          }
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                        >
                          {rep.status === 'open' ? 'تمت المعالجة ✓' : 'إعادة فتح'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteContentReport(rep.id)}
                          className="p-1 text-rose-600 hover:bg-rose-100 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-tajawal">{rep.details}</p>
                    <div className="text-[11px] text-slate-400 font-cairo">
                      المُبلغ: {rep.reporterName} • المادة: {rep.subject}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
