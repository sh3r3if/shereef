import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Award,
  BookOpen,
  CheckCircle2,
  ChevronLeft,
  Code2,
  Compass,
  FileCheck2,
  GraduationCap,
  HelpCircle,
  Layers,
  Lock,
  Play,
  Plus,
  RotateCcw,
  Sparkles,
  Terminal,
  Trophy,
  XCircle,
  AlertTriangle,
  Atom,
  Calculator,
} from 'lucide-react';
import type { CurrentUser, Language } from '../types';
import type {
  CodeChallengeLanguage,
  CumulativeReviewMilestone,
  CurriculumChapter,
  CurriculumEssayQuestion,
  CurriculumLesson,
  CurriculumMcqQuestion,
  CurriculumReviewResult,
  CurriculumSubject,
  DigitalAwardInfo,
  EducationalStage,
  StudentSubjectProgress,
} from '../types/curriculum';
import { getAuthHeaders, isStudentRole } from '../utils/rbac';
import { runSubjectCodeSandbox, type CodeExecutionResult } from '../utils/codeSandboxRunner';
import { getMcqOptionSurfaceClass, MCQ_QUESTION_BOX_CLASS } from '../utils/mcqTheme';

interface CurriculumGuidedPathHubProps {
  currentUser: CurrentUser;
  language: Language;
}

type ViewStep = 'setup_overview' | 'chapters_map' | 'chapter_workspace' | 'review_exam';

function SubjectIcon({ iconKey, className = 'w-5 h-5' }: { iconKey: string; className?: string }) {
  if (iconKey === 'calc') return <Calculator className={className} />;
  if (iconKey === 'atom') return <Atom className={className} />;
  if (iconKey === 'book') return <BookOpen className={className} />;
  return <Code2 className={className} />;
}

function AwardTierBadge({ award }: { award: DigitalAwardInfo }) {
  const styles =
    award.tier === 'platinum'
      ? 'from-slate-800 via-indigo-950 to-slate-900 border-indigo-400 text-indigo-100'
      : award.tier === 'gold'
      ? 'from-amber-700 via-amber-800 to-slate-900 border-amber-400 text-amber-50'
      : award.tier === 'silver'
      ? 'from-slate-700 via-slate-800 to-slate-900 border-slate-400 text-slate-100'
      : 'from-emerald-800 via-emerald-900 to-slate-950 border-emerald-500/70 text-emerald-50';

  const progressPct = award.nextTierPoints
    ? Math.min(100, Math.round((award.points / award.nextTierPoints) * 100))
    : 100;

  return (
    <div className={`rounded-2xl bg-gradient-to-br ${styles} border-2 p-5 shadow-lg space-y-3`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0">
            <Trophy className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <span className="text-[11px] font-cairo font-bold text-amber-300 block">
              الجائزة الرقمية الحالية الحاصل عليها الطالب
            </span>
            <h4 className="font-cairo font-extrabold text-base sm:text-lg text-white">
              {award.title}
            </h4>
          </div>
        </div>
        <div className="text-left shrink-0 px-3 py-1.5 rounded-xl bg-black/30 border border-white/15">
          <span className="text-[10px] text-slate-300 block">نقاط الإتقان</span>
          <strong className="font-mono text-base font-black text-amber-300">
            {award.points} XP
          </strong>
        </div>
      </div>

      {award.nextTierTitle && award.nextTierPoints && (
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-[11px] text-slate-200">
            <span>الترقية القادمة: {award.nextTierTitle}</span>
            <span className="font-mono">
              {award.points} / {award.nextTierPoints}
            </span>
          </div>
          <div className="h-2 rounded-full bg-black/35 overflow-hidden">
            <div
              className="h-full bg-amber-400 transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      )}

      {award.unlockedTitles.length > 0 && (
        <div className="flex flex-wrap gap-1.5 pt-1">
          {award.unlockedTitles.slice(0, 4).map((t, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-white/10 border border-white/15 text-[11px] font-cairo font-bold text-white"
            >
              <Award className="w-3 h-3 text-amber-300" />
              {t}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

export const CurriculumGuidedPathHub: React.FC<CurriculumGuidedPathHubProps> = ({
  currentUser,
  language,
}) => {
  const isAr = language === 'ar';
  const isTeacherOrAdmin = !isStudentRole(currentUser.role) && currentUser.role !== 'parent' && currentUser.role !== 'visitor';
  const studentId = currentUser.studentId || currentUser.id || 'guest-student';

  const [loading, setLoading] = useState(true);
  const [stages, setStages] = useState<EducationalStage[]>([]);
  const [subjects, setSubjects] = useState<CurriculumSubject[]>([]);
  const [progress, setProgress] = useState<StudentSubjectProgress>({
    completedLessonIds: [],
    completedChapterIds: [],
    restudyRequiredChapterIds: [],
    passedCumulativeIds: [],
    chapterScores: {},
    cumulativeScores: {},
    totalXp: 0,
  });
  const [currentAward, setCurrentAward] = useState<DigitalAwardInfo>({
    id: 'award-bronze',
    title: 'وسام مستكشف المعرفة',
    tier: 'bronze',
    points: 0,
    unlockedTitles: ['وسام مستكشف المعرفة'],
  });

  // Sequential Navigation State
  const [step, setStep] = useState<ViewStep>('setup_overview');
  const [selectedStageId, setSelectedStageId] = useState<string>('stage-prep-1');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');
  const [selectedTerm, setSelectedTerm] = useState<1 | 2>(1);
  const [selectedChapterId, setSelectedChapterId] = useState<string>('');
  const [selectedLessonIndex, setSelectedLessonIndex] = useState<number>(0);

  // Inside Lesson Interactive State (Objective MCQs + True/False + Essays + Code Editor)
  const [lessonMcqAnswers, setLessonMcqAnswers] = useState<Record<string, number>>({});
  const [lessonMcqChecked, setLessonMcqChecked] = useState(false);
  const [tfAnswers, setTfAnswers] = useState<Record<string, boolean>>({});
  const [tfChecked, setTfChecked] = useState(false);
  const [essayAnswers, setEssayAnswers] = useState<Record<string, string>>({});
  const [essayCheckedIds, setEssayCheckedIds] = useState<Record<string, boolean>>({});
  const [codeInputs, setCodeInputs] = useState<Record<string, string>>({});
  const [codeResults, setCodeResults] = useState<Record<string, CodeExecutionResult>>({});
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({});
  const [savingLesson, setSavingLesson] = useState(false);

  // Chapter / Cumulative Review State
  const [activeReviewTarget, setActiveReviewTarget] = useState<
    | { kind: 'chapter'; chapter: CurriculumChapter }
    | { kind: 'cumulative'; milestone: CumulativeReviewMilestone }
    | null
  >(null);
  const [reviewAnswers, setReviewAnswers] = useState<Record<number, number>>({});
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [reviewOutcome, setReviewOutcome] = useState<CurriculumReviewResult | null>(null);

  // Teacher Quick Lesson Modal State
  const [isAddLessonOpen, setIsAddLessonOpen] = useState(false);
  const [newLessonChapterId, setNewLessonChapterId] = useState('');
  const [newLessonTitle, setNewLessonTitle] = useState('');
  const [newLessonSummary, setNewLessonSummary] = useState('');
  const [newMcqQuestion, setNewMcqQuestion] = useState('');
  const [newMcqOpts, setNewMcqOpts] = useState<[string, string, string, string]>(['', '', '', '']);
  const [newMcqCorrect, setNewMcqCorrect] = useState(0);
  const [newCodeLang, setNewCodeLang] = useState<CodeChallengeLanguage>('python');
  const [newCodeTitle, setNewCodeTitle] = useState('جرّب الكود التطبيقي');
  const [newCodePrompt, setNewCodePrompt] = useState('');
  const [newCodeStarter, setNewCodeStarter] = useState('x = 10\nprint(x)');
  const [newCodeExpected, setNewCodeExpected] = useState('10');

  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => setToastMsg(null), 3500);
  }, []);

  const fetchCurriculumState = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/curriculum-path/state?studentId=${encodeURIComponent(
          studentId
        )}&studentName=${encodeURIComponent(currentUser.name || '')}`
      );
      if (res.ok) {
        const data = await res.json();
        setStages(data.stages || []);
        setSubjects(data.subjects || []);
        if (data.progress) setProgress(data.progress);
        if (data.currentAward) setCurrentAward(data.currentAward);
        if (!selectedStageId && data.stages?.length > 0) {
          setSelectedStageId(data.stages[0].id);
        }
      }
    } finally {
      setLoading(false);
    }
  }, [studentId, currentUser.name, selectedStageId]);

  useEffect(() => {
    fetchCurriculumState();
  }, [fetchCurriculumState]);

  const stageSubjects = useMemo(
    () => subjects.filter((s) => s.stageId === selectedStageId),
    [subjects, selectedStageId]
  );

  // Auto-select first subject of selected stage when stage switches
  useEffect(() => {
    if (stageSubjects.length > 0 && !stageSubjects.some((s) => s.id === selectedSubjectId)) {
      setSelectedSubjectId(stageSubjects[0].id);
    }
  }, [stageSubjects, selectedSubjectId]);

  const activeSubject = useMemo(
    () => subjects.find((s) => s.id === selectedSubjectId) || stageSubjects[0] || null,
    [subjects, stageSubjects, selectedSubjectId]
  );

  const termChapters = useMemo(() => {
    if (!activeSubject) return [];
    return activeSubject.chapters
      .filter((c) => c.term === selectedTerm)
      .sort((a, b) => a.order - b.order);
  }, [activeSubject, selectedTerm]);

  const activeChapter = useMemo(
    () => activeSubject?.chapters.find((c) => c.id === selectedChapterId) || null,
    [activeSubject, selectedChapterId]
  );

  const activeLesson: CurriculumLesson | null = useMemo(() => {
    if (!activeChapter) return null;
    return activeChapter.lessons[selectedLessonIndex] || activeChapter.lessons[0] || null;
  }, [activeChapter, selectedLessonIndex]);

  // Reset per-lesson interaction buffers when opening a lesson
  useEffect(() => {
    if (!activeLesson) return;
    setLessonMcqAnswers({});
    setLessonMcqChecked(false);
    setTfAnswers({});
    setTfChecked(false);
    setEssayCheckedIds({});
    const starterMap: Record<string, string> = {};
    activeLesson.codeChallenges.forEach((c) => {
      starterMap[c.id] = codeInputs[c.id] ?? c.starterCode;
    });
    setCodeInputs((prev) => ({ ...starterMap, ...prev }));
  }, [activeLesson?.id]);

  const handleOpenChapter = (chapter: CurriculumChapter) => {
    setSelectedChapterId(chapter.id);
    const firstIncomplete = chapter.lessons.findIndex(
      (l) => !progress.completedLessonIds.includes(l.id)
    );
    setSelectedLessonIndex(firstIncomplete >= 0 ? firstIncomplete : 0);
    setStep('chapter_workspace');
  };

  const handleRunCodeChallenge = (challenge: CurriculumLesson['codeChallenges'][number]) => {
    const code = codeInputs[challenge.id] ?? '';
    const res = runSubjectCodeSandbox({
      code,
      language: challenge.language,
      expectedOutputContains: challenge.expectedOutputContains,
      requiredCodeSnippets: challenge.requiredCodeSnippets,
      validationExpression: challenge.validationExpression,
    });
    setCodeResults((prev) => ({ ...prev, [challenge.id]: res }));
  };

  const evaluateEssayMatch = (q: CurriculumEssayQuestion, rawAnswer: string) => {
    const normalized = rawAnswer.trim().toLowerCase();
    if (!normalized) return { matched: 0, total: q.keywords.length };
    const matched = q.keywords.filter((kw) => normalized.includes(kw.toLowerCase())).length;
    return { matched, total: q.keywords.length };
  };

  const handleCompleteLesson = async () => {
    if (!activeSubject || !activeChapter || !activeLesson) return;

    const allMcqsAnswered = activeLesson.mcqQuestions.every(
      (q) => lessonMcqAnswers[q.id] !== undefined
    );
    if (!allMcqsAnswered) {
      showToast('يرجى الإجابة على جميع أسئلة الاختيارات (4 خيارات) أولاً');
      return;
    }

    const tfList = activeLesson.trueFalseQuestions || [];
    const allTfAnswered = tfList.every((q) => tfAnswers[q.id] !== undefined);
    if (!allTfAnswered) {
      showToast('يرجى الإجابة على جميع أسئلة الصح والخطأ (✓ / ✗) أولاً');
      return;
    }

    const allCodePassed = activeLesson.codeChallenges.every(
      (c) => codeResults[c.id]?.passed === true
    );
    if (!allCodePassed) {
      showToast('يرجى تشغيل واجتياز تمرين «العملي — محرر الأكواد» بنجاح قبل الانتقال للدرس التالي');
      return;
    }

    let mcqScore = 0;
    activeLesson.mcqQuestions.forEach((q) => {
      if (lessonMcqAnswers[q.id] === q.correctIndex) mcqScore += 1;
    });
    tfList.forEach((q) => {
      if (tfAnswers[q.id] === q.isTrue) mcqScore += 1;
    });

    setSavingLesson(true);
    try {
      const res = await fetch('/api/curriculum-path/lesson/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId,
          studentName: currentUser.name,
          subjectId: activeSubject.id,
          chapterId: activeChapter.id,
          lessonId: activeLesson.id,
          mcqScore,
          mcqTotal: activeLesson.mcqQuestions.length,
          codePassed: true,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setProgress(data.progress);
        setCurrentAward(data.currentAward);

        if (selectedLessonIndex + 1 < activeChapter.lessons.length) {
          setSelectedLessonIndex(selectedLessonIndex + 1);
          showToast('تم إتمام الدرس بنجاح وفتح الدرس التالي!');
        } else {
          // Chapter lessons finished -> Launch Chapter Comprehensive Review automatically!
          setActiveReviewTarget({ kind: 'chapter', chapter: activeChapter });
          setReviewAnswers({});
          setReviewOutcome(null);
          setStep('review_exam');
        }
      }
    } finally {
      setSavingLesson(false);
    }
  };

  const handleStartChapterReview = (chapter: CurriculumChapter) => {
    setActiveReviewTarget({ kind: 'chapter', chapter });
    setReviewAnswers({});
    setReviewOutcome(null);
    setStep('review_exam');
  };

  const handleStartCumulativeReview = (milestone: CumulativeReviewMilestone) => {
    setActiveReviewTarget({ kind: 'cumulative', milestone });
    setReviewAnswers({});
    setReviewOutcome(null);
    setStep('review_exam');
  };

  const handleSubmitReviewExam = async () => {
    if (!activeSubject || !activeReviewTarget) return;
    const questions =
      activeReviewTarget.kind === 'chapter'
        ? activeReviewTarget.chapter.chapterReviewQuestions
        : activeReviewTarget.milestone.questions;

    if (Object.keys(reviewAnswers).length < questions.length) {
      showToast('يرجى الإجابة على كافة أسئلة المراجعة قبل التسليم');
      return;
    }

    const orderedAnswers = questions.map((_, idx) => reviewAnswers[idx] ?? -1);
    setReviewSubmitting(true);
    try {
      const url =
        activeReviewTarget.kind === 'chapter'
          ? '/api/curriculum-path/chapter/submit-review'
          : '/api/curriculum-path/cumulative/submit-review';

      const payload =
        activeReviewTarget.kind === 'chapter'
          ? {
              studentId,
              studentName: currentUser.name,
              subjectId: activeSubject.id,
              chapterId: activeReviewTarget.chapter.id,
              answers: orderedAnswers,
            }
          : {
              studentId,
              studentName: currentUser.name,
              subjectId: activeSubject.id,
              milestoneId: activeReviewTarget.milestone.id,
              answers: orderedAnswers,
            };

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (res.ok) {
        setProgress(data.progress);
        setReviewOutcome(data.result);
        if (data.result?.newAward) {
          setCurrentAward(data.result.newAward);
        }
      }
    } finally {
      setReviewSubmitting(false);
    }
  };

  const handleTeacherAddLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSubject || !newLessonChapterId || !newLessonTitle.trim()) return;
    const res = await fetch('/api/curriculum-path/author/lesson', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders(currentUser),
      },
      body: JSON.stringify({
        subjectId: activeSubject.id,
        chapterId: newLessonChapterId,
        lesson: {
          title: newLessonTitle.trim(),
          summary: newLessonSummary.trim() || 'شرح تفصيلي للدرس الجديد.',
          keyPoints: [newLessonSummary.trim() || 'نقطة أساسية للدرس'],
          mcqQuestions: newMcqQuestion.trim()
            ? [
                {
                  id: `custom-q-${Date.now()}`,
                  question: newMcqQuestion.trim(),
                  options: newMcqOpts.map((o, i) => o.trim() || `خيار ${i + 1}`) as [
                    string,
                    string,
                    string,
                    string,
                  ],
                  correctIndex: newMcqCorrect,
                  explanation: 'إجابة معتمدة من المعلم.',
                },
              ]
            : [],
          codeChallenges: newCodePrompt.trim()
            ? [
                {
                  id: `custom-code-${Date.now()}`,
                  language: newCodeLang,
                  title: newCodeTitle.trim() || 'جرّب الكود',
                  prompt: newCodePrompt.trim(),
                  subjectContext: activeSubject.name,
                  starterCode: newCodeStarter,
                  hint: `تأكد أن المخرج يتضمن: ${newCodeExpected}`,
                  expectedOutputContains: newCodeExpected.trim()
                    ? [newCodeExpected.trim()]
                    : [],
                },
              ]
            : [],
        },
      }),
    });

    if (res.ok) {
      showToast('تمت إضافة الدرس التفاعلي للفصل بنجاح!');
      setIsAddLessonOpen(false);
      setNewLessonTitle('');
      setNewLessonSummary('');
      setNewMcqQuestion('');
      setNewCodePrompt('');
      await fetchCurriculumState();
    } else {
      const err = await res.json();
      showToast(err.error || 'تعذر إضافة الدرس');
    }
  };

  if (loading) {
    return (
      <div className="p-10 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center font-cairo font-bold text-slate-600 dark:text-slate-300">
        جارِ تحميل مسار الدروس المنهجي والدرجات...
      </div>
    );
  }

  return (
    <div className="space-y-6 font-tajawal" dir={isAr ? 'rtl' : 'ltr'}>
      {toastMsg && (
        <div className="px-4 py-3 rounded-xl bg-slate-900 text-white border border-emerald-500/70 text-xs font-cairo font-bold shadow-lg flex items-center justify-between">
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Sequential Step Navigation Header */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 text-xs font-cairo font-bold">
          <button
            type="button"
            onClick={() => setStep('setup_overview')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
              step === 'setup_overview'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            1. المرحلة والمادة والجائزة
          </button>
          <ChevronLeft className="w-4 h-4 text-slate-400" />
          <button
            type="button"
            disabled={!activeSubject}
            onClick={() => activeSubject && setStep('chapters_map')}
            className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer disabled:opacity-40 ${
              step === 'chapters_map'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            2. فصول الترمين والمراجعات
          </button>
          {activeChapter && (
            <>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
              <button
                type="button"
                onClick={() => setStep('chapter_workspace')}
                className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                  step === 'chapter_workspace'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                3. دروس {activeChapter.title.split(':')[0]}
              </button>
            </>
          )}
          {step === 'review_exam' && (
            <>
              <ChevronLeft className="w-4 h-4 text-slate-400" />
              <span className="px-3 py-1.5 rounded-xl bg-amber-600 text-white">
                4. تقييم المراجعة
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-2 text-xs font-cairo font-bold text-slate-600 dark:text-slate-300">
          <Award className="w-4 h-4 text-amber-500" />
          <span>{currentAward.title}</span>
          <span className="font-mono text-emerald-700 dark:text-emerald-400">
            ({currentAward.points} XP)
          </span>
        </div>
      </div>

      {/* STEP 1: STAGE -> SUBJECT -> CURRENT DIGITAL AWARD -> START BUTTON */}
      {step === 'setup_overview' && (
        <div className="space-y-6">
          {/* 1. Select Educational Stage */}
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 flex items-center justify-center font-cairo font-black text-sm">
                1
              </div>
              <div>
                <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                  اختر المرحلة التعليمية
                </h3>
                <p className="text-xs text-slate-500">
                  حدد مرحلتك الدراسية لعرض المواد المقررة على الترمين الأول والثاني
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {stages.map((st) => {
                const isSelected = selectedStageId === st.id;
                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setSelectedStageId(st.id)}
                    className={`text-right p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-3.5 ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 dark:bg-emerald-950/40 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div
                      className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}
                    >
                      <GraduationCap className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                        {st.name}
                      </h4>
                      <p className="text-[11px] font-cairo font-semibold text-emerald-700 dark:text-emerald-400">
                        {st.gradeLabel}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {st.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 2. Select Subject */}
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-400 flex items-center justify-center font-cairo font-black text-sm">
                2
              </div>
              <div>
                <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                  اختر المادة الدراسية
                </h3>
                <p className="text-xs text-slate-500">
                  كل مادة مقسمة إلى الترم الأول والترم الثاني، وبكل فصل دروس وأسئلة اختيارات و«جرّب الكود»
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {stageSubjects.map((subj) => {
                const isSelected = activeSubject?.id === subj.id;
                const totalLessonsCount = subj.chapters.reduce(
                  (acc, ch) => acc + ch.lessons.length,
                  0
                );
                const doneInSubj = subj.chapters.filter((ch) =>
                  progress.completedChapterIds.includes(ch.id)
                ).length;

                return (
                  <button
                    key={subj.id}
                    type="button"
                    onClick={() => setSelectedSubjectId(subj.id)}
                    className={`text-right p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                      isSelected
                        ? 'border-sky-600 bg-sky-50/70 dark:bg-sky-950/40 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          isSelected
                            ? 'bg-sky-700 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        <SubjectIcon iconKey={subj.iconKey} />
                      </div>
                      <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {doneInSubj}/{subj.chapters.length} فصول
                      </span>
                    </div>

                    <div>
                      <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                        {subj.name}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                        {subj.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-300 font-cairo font-bold">
                      <span>الترم 1 + الترم 2</span>
                      <span>{totalLessonsCount} درس تفاعلي</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 3. Current Student Digital Award + 4. Start Button */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
            <div className="lg:col-span-7">
              <AwardTierBadge award={currentAward} />
            </div>

            <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between gap-4 shadow-xs">
              <div className="space-y-1.5">
                <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400">
                  جاهز للانطلاق
                </span>
                <h4 className="font-cairo font-extrabold text-base text-slate-900 dark:text-white">
                  {activeSubject ? `مادة: ${activeSubject.name}` : 'اختر مادة للمتابعة'}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  اضغط ابدأ لعرض فصول الترم الأول والترم الثاني، ومذاكرة الدروس وحل الأسئلة وتجربة الكود، مع المراجعة الشاملة بعد كل فصل وبعد كل 3 فصول.
                </p>
              </div>

              <button
                type="button"
                disabled={!activeSubject}
                onClick={() => setStep('chapters_map')}
                className="w-full py-3.5 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-extrabold text-sm flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>ابدأ الآن</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: TWO SEMESTERS (TERM 1 & TERM 2) + CHAPTERS + 3-CHAPTER MILESTONES */}
      {step === 'chapters_map' && activeSubject && (
        <div className="space-y-5">
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 shadow-xs">
            <div className="space-y-1">
              <h3 className="font-cairo font-extrabold text-lg text-slate-900 dark:text-white">
                فصول مادة {activeSubject.name}
              </h3>
              <p className="text-xs text-slate-500">
                اضغط على الفصل للدخول إلى الدروس، ثم اجتز مراجعة الفصل (مسموح بنقصان درجة أو درجتين فقط).
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setSelectedTerm(1)}
                  className={`px-4 py-2 rounded-lg text-xs font-cairo font-bold transition-colors cursor-pointer ${
                    selectedTerm === 1
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  الترم الأول
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTerm(2)}
                  className={`px-4 py-2 rounded-lg text-xs font-cairo font-bold transition-colors cursor-pointer ${
                    selectedTerm === 2
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  الترم الثاني
                </button>
              </div>

              {isTeacherOrAdmin && termChapters.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setNewLessonChapterId(termChapters[0].id);
                    setIsAddLessonOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة درس لفصل</span>
                </button>
              )}
            </div>
          </div>

          {/* Chapters List + Cumulative Review Milestones after every 3 chapters */}
          <div className="space-y-4">
            {termChapters.length === 0 ? (
              <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-center text-sm text-slate-500">
                لا توجد فصول مضافة لهذا الترم حالياً.
              </div>
            ) : (
              termChapters.map((chapter) => {
                const completedInChapter = chapter.lessons.filter((l) =>
                  progress.completedLessonIds.includes(l.id)
                ).length;
                const isChapterCompleted = progress.completedChapterIds.includes(chapter.id);
                const needsRestudy = progress.restudyRequiredChapterIds.includes(chapter.id);
                const lastScore = progress.chapterScores[chapter.id];

                // Check if there is a Cumulative Review right after this chapter order (e.g., Chapter 3 or 4)
                const milestoneAfter = activeSubject.cumulativeReviews.find(
                  (m) => m.term === selectedTerm && m.afterChapterOrder === chapter.order
                );
                const isMilestoneUnlocked = milestoneAfter
                  ? milestoneAfter.coversChapterOrders.every((ord) => {
                      const targetCh = activeSubject.chapters.find(
                        (c) => c.term === milestoneAfter.term && c.order === ord
                      );
                      return targetCh && progress.completedChapterIds.includes(targetCh.id);
                    })
                  : false;
                const isMilestonePassed = milestoneAfter
                  ? progress.passedCumulativeIds.includes(milestoneAfter.id)
                  : false;

                return (
                  <React.Fragment key={chapter.id}>
                    <div
                      className={`rounded-2xl bg-white dark:bg-slate-900 border-2 p-5 transition-all shadow-xs ${
                        needsRestudy
                          ? 'border-rose-400 dark:border-rose-700'
                          : isChapterCompleted
                          ? 'border-emerald-500/70'
                          : 'border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="space-y-1.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-cairo font-bold text-slate-700 dark:text-slate-300">
                              الترم {chapter.term === 1 ? 'الأول' : 'الثاني'}
                            </span>
                            {isChapterCompleted && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-cairo font-bold">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                فصل مجتاز ({lastScore?.score}/{lastScore?.total})
                              </span>
                            )}
                            {needsRestudy && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 text-xs font-cairo font-bold">
                                <RotateCcw className="w-3.5 h-3.5" />
                                مطلوب إعادة المذاكرة من الدرس الأول (نقصت {lastScore?.missedMarks} درجات)
                              </span>
                            )}
                          </div>

                          <h4 className="font-cairo font-extrabold text-base text-slate-900 dark:text-white">
                            {chapter.title}
                          </h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {chapter.description}
                          </p>
                          <p className="text-[11px] font-cairo font-bold text-slate-600 dark:text-slate-300">
                            الدروس المنجزة: {completedInChapter} / {chapter.lessons.length} • مراجعة الفصل:{' '}
                            {chapter.chapterReviewQuestions.length} أسئلة اختيار من متعدد
                          </p>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleOpenChapter(chapter)}
                            className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-cairo font-bold flex items-center gap-2 cursor-pointer"
                          >
                            <BookOpen className="w-4 h-4" />
                            <span>
                              {needsRestudy
                                ? 'إعادة مذاكرة الفصل من الأول'
                                : 'افتح دروس الفصل'}
                            </span>
                          </button>

                          <button
                            type="button"
                            disabled={completedInChapter < chapter.lessons.length}
                            onClick={() => handleStartChapterReview(chapter)}
                            className="px-4 py-2.5 rounded-xl border border-amber-500/70 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 disabled:opacity-45 text-amber-900 dark:text-amber-200 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
                          >
                            <FileCheck2 className="w-4 h-4" />
                            <span>مراجعة الفصل كامل</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Cumulative Review Milestone Card after 3 (or 4) Chapters */}
                    {milestoneAfter && (
                      <div
                        className={`rounded-2xl p-5 border-2 flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                          isMilestonePassed
                            ? 'bg-emerald-950 text-white border-emerald-500'
                            : isMilestoneUnlocked
                            ? 'bg-slate-900 text-white border-amber-400 shadow-lg'
                            : 'bg-slate-100 dark:bg-slate-800/50 border-slate-300 dark:border-slate-700 text-slate-500'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center shrink-0">
                            {isMilestoneUnlocked ? (
                              <Sparkles className="w-5 h-5 text-amber-400" />
                            ) : (
                              <Lock className="w-5 h-5 text-slate-400" />
                            )}
                          </div>
                          <div>
                            <span className="text-[11px] font-cairo font-bold text-amber-500 block">
                              مراجعة تراكمية كل {activeSubject.checkpointIntervalChapters} فصول
                            </span>
                            <h4 className="font-cairo font-extrabold text-sm sm:text-base">
                              {milestoneAfter.title}
                            </h4>
                            <p className="text-xs opacity-80 mt-0.5">
                              {milestoneAfter.questions.length} أسئلة اختيار من متعدد (4 اختيارات) — النقص المسموح: درجة أو درجتان فقط
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={!isMilestoneUnlocked}
                          onClick={() => handleStartCumulativeReview(milestoneAfter)}
                          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:text-slate-500 text-slate-950 font-cairo font-extrabold text-xs shrink-0 cursor-pointer"
                        >
                          {isMilestonePassed
                            ? 'إعادة المراجعة التراكمية ✓'
                            : isMilestoneUnlocked
                            ? 'ابدأ المراجعة التراكمية الآن'
                            : 'أتمم الفصول السابقة لفتح المراجعة'}
                        </button>
                      </div>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* STEP 3: INSIDE CHAPTER -> LESSONS + 4-OPTION MCQs + TRY-THE-CODE SANDBOX */}
      {step === 'chapter_workspace' && activeSubject && activeChapter && activeLesson && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Chapter Lessons Sidebar Deck */}
          <aside className="lg:col-span-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3 h-fit shadow-xs">
            <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
              <span className="text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-400">
                دروس الفصل
              </span>
              <h3 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                {activeChapter.title}
              </h3>
            </div>

            <div className="space-y-2">
              {activeChapter.lessons.map((les, idx) => {
                const isDone = progress.completedLessonIds.includes(les.id);
                const isActive = idx === selectedLessonIndex;
                return (
                  <button
                    key={les.id}
                    type="button"
                    onClick={() => setSelectedLessonIndex(idx)}
                    className={`w-full text-right p-3 rounded-xl border transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                      isActive
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-100'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <div className="min-w-0">
                      <span className="text-[11px] font-cairo font-bold text-slate-500 block">
                        الدرس {idx + 1} • {les.durationMinutes} دقيقة
                      </span>
                      <span className="text-xs font-cairo font-bold truncate block">
                        {les.title}
                      </span>
                    </div>
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <Compass className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                );
              })}

              {/* Chapter Review Button at bottom of chapter lessons */}
              {(() => {
                const allLessonsDone = activeChapter.lessons.every((l) =>
                  progress.completedLessonIds.includes(l.id)
                );
                return (
                  <button
                    type="button"
                    disabled={!allLessonsDone}
                    onClick={() => handleStartChapterReview(activeChapter)}
                    className="w-full p-3.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-100 dark:disabled:bg-slate-800 disabled:text-slate-400 text-slate-950 font-cairo font-extrabold text-xs flex items-center justify-between cursor-pointer mt-2"
                  >
                    <span>مراجعة الفصل كامل (اختيار من متعدد)</span>
                    {allLessonsDone ? <Play className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  </button>
                );
              })()}
            </div>
          </aside>

          {/* Active Lesson Interactive Zone */}
          <div className="lg:col-span-8 space-y-5">
            {/* Lesson Explanation */}
            <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3 shadow-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-cairo font-extrabold text-base sm:text-lg text-slate-900 dark:text-white">
                  {activeLesson.title}
                </h3>
                <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-cairo font-bold text-slate-600 dark:text-slate-300">
                  {activeSubject.name}
                </span>
              </div>

              <p className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
                {activeLesson.summary}
              </p>

              {activeLesson.keyPoints.length > 0 && (
                <ul className="space-y-1.5 pt-2">
                  {activeLesson.keyPoints.map((pt, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* Part 1A: 4-Option Multiple Choice Questions (Objective) */}
            <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Layers className="w-5 h-5 text-sky-600" />
                  <h4 className="font-cairo font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    {activeSubject?.id.endsWith('-practical') ||
                    (activeLesson.codeChallenges.length === 0 &&
                      !activeLesson.trueFalseQuestions?.length &&
                      !activeLesson.essayQuestions?.length)
                      ? 'الاختبار العملي على الأكواد — نظام 4 اختيارات (إجابة واحدة صحيحة)'
                      : 'أولاً: الأسئلة الموضوعية — الاختيار من متعدد (4 اختيارات)'}
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => setLessonMcqChecked(true)}
                  className="px-3 py-1.5 rounded-lg bg-sky-700 hover:bg-sky-800 text-white text-xs font-cairo font-bold cursor-pointer"
                >
                  تحقق من الاختيارات
                </button>
              </div>

              <div className="space-y-5">
                {activeLesson.mcqQuestions.map((q, qIdx) => {
                  const chosen = lessonMcqAnswers[q.id];
                  const hasCodeLines = q.question.includes('\n');
                  return (
                    <div
                      key={q.id}
                      className="space-y-3 p-3.5 sm:p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-950/30 border border-slate-200/80 dark:border-slate-800"
                    >
                      <div className={MCQ_QUESTION_BOX_CLASS}>
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg bg-emerald-700/10 dark:bg-emerald-400/15 text-emerald-800 dark:text-emerald-300 text-[11px] font-cairo font-extrabold">
                            السؤال {qIdx + 1}
                          </span>
                        </div>
                        <div
                          dir="auto"
                          className={`font-bold whitespace-pre-line ${
                            hasCodeLines
                              ? 'p-3.5 rounded-xl bg-slate-900/95 text-emerald-300 font-mono text-xs leading-relaxed border border-slate-800'
                              : 'font-cairo text-xs sm:text-sm text-slate-900 dark:text-slate-100 leading-relaxed'
                          }`}
                        >
                          {q.question}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = chosen === optIdx;
                          const isCorrect = q.correctIndex === optIdx;
                          const style = getMcqOptionSurfaceClass(optIdx, {
                            isSelected,
                            isChecked: lessonMcqChecked && (isSelected || isCorrect),
                            isCorrect,
                          });

                          return (
                            <button
                              key={optIdx}
                              type="button"
                              dir="auto"
                              onClick={() =>
                                setLessonMcqAnswers((prev) => ({ ...prev, [q.id]: optIdx }))
                              }
                              className={`text-right px-3.5 py-3 rounded-xl border-2 text-xs font-cairo font-bold transition-all flex items-center justify-between gap-2 cursor-pointer ${style}`}
                            >
                              <span>{opt}</span>
                              {lessonMcqChecked && isSelected && (
                                isCorrect ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                                ) : (
                                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                                )
                              )}
                            </button>
                          );
                        })}
                      </div>
                      {lessonMcqChecked && chosen !== undefined && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 px-3 py-2 rounded-lg">
                          <strong>التوضيح:</strong> {q.explanation}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Part 1B: True / False Questions (Objective) */}
            {activeLesson.trueFalseQuestions && activeLesson.trueFalseQuestions.length > 0 && (
              <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <FileCheck2 className="w-5 h-5 text-emerald-600" />
                    <h4 className="font-cairo font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                      الأسئلة الموضوعية — ضع علامة (✓) أو (✗)
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setTfChecked(true)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-cairo font-bold cursor-pointer"
                  >
                    تصحيح الصح والخطأ
                  </button>
                </div>

                <div className="space-y-4">
                  {activeLesson.trueFalseQuestions.map((tf, idx) => {
                    const chosen = tfAnswers[tf.id];
                    const isRight = chosen === tf.isTrue;
                    return (
                      <div
                        key={tf.id}
                        className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2.5"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <p className="font-cairo font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                            {idx + 1}. {tf.statement}
                          </p>
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() =>
                                setTfAnswers((prev) => ({ ...prev, [tf.id]: true }))
                              }
                              className={`px-3.5 py-1.5 rounded-lg border-2 text-xs font-cairo font-extrabold cursor-pointer transition-colors ${
                                chosen === true
                                  ? tfChecked
                                    ? isRight
                                      ? 'border-emerald-600 bg-emerald-100 text-emerald-900'
                                      : 'border-rose-600 bg-rose-100 text-rose-900'
                                    : 'border-emerald-600 bg-emerald-50 text-emerald-900'
                                  : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200'
                              }`}
                            >
                              ✓ صواب
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setTfAnswers((prev) => ({ ...prev, [tf.id]: false }))
                              }
                              className={`px-3.5 py-1.5 rounded-lg border-2 text-xs font-cairo font-extrabold cursor-pointer transition-colors ${
                                chosen === false
                                  ? tfChecked
                                    ? isRight
                                      ? 'border-emerald-600 bg-emerald-100 text-emerald-900'
                                      : 'border-rose-600 bg-rose-100 text-rose-900'
                                    : 'border-rose-600 bg-rose-50 text-rose-900'
                                  : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200'
                              }`}
                            >
                              ✗ خطأ
                            </button>
                          </div>
                        </div>
                        {tfChecked && chosen !== undefined && (
                          <p className="text-[11px] text-slate-600 dark:text-slate-300 pt-1">
                            <strong>التوضيح:</strong> {tf.explanation}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* Part 2: Theoretical Essay / Scientific Term / Complete Questions */}
            {activeLesson.essayQuestions && activeLesson.essayQuestions.length > 0 && (
              <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
                <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <BookOpen className="w-5 h-5 text-amber-600" />
                  <h4 className="font-cairo font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    ثانياً: الأسئلة المقالية والنظرية (المصطلح العلمي • أكمل • علل / اذكر)
                  </h4>
                </div>

                <div className="space-y-4">
                  {activeLesson.essayQuestions.map((es, idx) => {
                    const userAns = essayAnswers[es.id] || '';
                    const isChecked = essayCheckedIds[es.id];
                    const matchStats = isChecked ? evaluateEssayMatch(es, userAns) : null;
                    const badgeLabel =
                      es.questionType === 'scientific_term'
                        ? 'اكتب المصطلح العلمي'
                        : es.questionType === 'complete'
                        ? 'أكمل العبارة'
                        : 'سؤال مقالي نظري';

                    return (
                      <div
                        key={es.id}
                        className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2.5"
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="px-2.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 text-[11px] font-cairo font-bold">
                            {badgeLabel}
                          </span>
                        </div>
                        <p className="font-cairo font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                          {idx + 1}. {es.question}
                        </p>
                        <textarea
                          rows={2}
                          value={userAns}
                          onChange={(e) =>
                            setEssayAnswers((prev) => ({ ...prev, [es.id]: e.target.value }))
                          }
                          placeholder="اكتب إجابتك هنا للمقارنة مع الإجابة النموذجية..."
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
                        />
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              setEssayCheckedIds((prev) => ({ ...prev, [es.id]: true }))
                            }
                            className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-cairo font-bold cursor-pointer"
                          >
                            تحقق وعرض الإجابة النموذجية
                          </button>

                          {matchStats && (
                            <span className="text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-400">
                              تطابق الكلمات المفتاحية: {matchStats.matched} / {matchStats.total}
                            </span>
                          )}
                        </div>

                        {isChecked && (
                          <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-950 dark:text-emerald-100">
                            <strong>الإجابة النموذجية:</strong> {es.modelAnswer}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* Part 3: Practical Code Lab (Python / HTML+CSS Live Preview / JavaScript) */}
            {activeLesson.codeChallenges.map((challenge) => {
              const runRes = codeResults[challenge.id];
              const codeValue = codeInputs[challenge.id] ?? challenge.starterCode;
              const langLabel =
                challenge.language === 'python'
                  ? 'Python 3'
                  : challenge.language === 'html_css'
                  ? 'HTML5 + CSS3'
                  : 'JavaScript';

              return (
                <section
                  key={challenge.id}
                  className="rounded-2xl bg-slate-900 text-white border border-slate-800 p-5 space-y-3.5 shadow-lg"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-5 h-5 text-emerald-400" />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-cairo font-bold text-sm sm:text-base">
                            {challenge.title}
                          </h4>
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-400/40 font-mono text-[10px] font-bold text-emerald-300">
                            {langLabel}
                          </span>
                        </div>
                        <span className="text-[11px] text-emerald-400 font-cairo font-semibold">
                          {challenge.subjectContext}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setRevealedHints((prev) => ({
                            ...prev,
                            [challenge.id]: !prev[challenge.id],
                          }))
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-cairo font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                        <span>تلميح</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setCodeInputs((prev) => ({
                            ...prev,
                            [challenge.id]: challenge.starterCode,
                          }))
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-cairo font-bold cursor-pointer"
                      >
                        إعادة ضبط
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-200 leading-relaxed bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                    {challenge.prompt}
                  </p>

                  {revealedHints[challenge.id] && (
                    <p className="text-xs text-amber-200 bg-amber-950/50 border border-amber-700/60 p-2.5 rounded-xl">
                      تلميح: {challenge.hint}
                    </p>
                  )}

                  <textarea
                    dir="ltr"
                    rows={7}
                    value={codeValue}
                    onChange={(e) =>
                      setCodeInputs((prev) => ({ ...prev, [challenge.id]: e.target.value }))
                    }
                    spellCheck={false}
                    className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-700 font-mono text-xs sm:text-sm text-emerald-300 focus:outline-none focus:border-emerald-500"
                  />

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => handleRunCodeChallenge(challenge)}
                      className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-cairo font-bold flex items-center gap-2 cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>تشغيل واختبار الكود</span>
                    </button>

                    {runRes && (
                      <span
                        className={`px-3 py-1 rounded-lg text-xs font-cairo font-bold ${
                          runRes.passed
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                            : 'bg-rose-950 text-rose-300 border border-rose-700'
                        }`}
                      >
                        {runRes.feedback}
                      </span>
                    )}
                  </div>

                  {runRes && runRes.renderedHtml && (
                    <div className="space-y-1.5">
                      <span className="text-[11px] font-cairo font-bold text-sky-300 block">
                        المعاينة الحية لصفحة الويب (HTML + CSS Preview):
                      </span>
                      <iframe
                        title={`preview-${challenge.id}`}
                        srcDoc={runRes.renderedHtml}
                        sandbox=""
                        className="w-full h-56 rounded-xl border border-slate-700 bg-white"
                      />
                    </div>
                  )}

                  {runRes && (runRes.logs.length > 0 || runRes.error) && (
                    <div
                      dir="ltr"
                      className="p-3 rounded-xl bg-black/70 border border-slate-800 font-mono text-xs space-y-1"
                    >
                      <div className="text-slate-400 text-[10px]">
                        {langLabel} Output:
                      </div>
                      {runRes.error ? (
                        <div className="text-rose-400">{runRes.error}</div>
                      ) : (
                        runRes.logs.map((line, i) => (
                          <div key={i} className="text-sky-300">
                            &gt; {line}
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </section>
              );
            })}

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => setStep('chapters_map')}
                className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                عودة لقائمة الفصول
              </button>

              <button
                type="button"
                disabled={savingLesson}
                onClick={handleCompleteLesson}
                className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white text-xs sm:text-sm font-cairo font-extrabold shadow-sm cursor-pointer"
              >
                {savingLesson
                  ? 'جارِ تسجيل التقدم...'
                  : selectedLessonIndex + 1 < activeChapter.lessons.length
                  ? 'إتمام الدرس والانتقال للدرس التالي ←'
                  : 'إتمام الدرس وبدء مراجعة الفصل كامل ←'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 4: CHAPTER REVIEW OR 3-CHAPTER CUMULATIVE REVIEW */}
      {step === 'review_exam' && activeReviewTarget && (
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-4 space-y-2">
            <span className="inline-block px-3 py-1 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200 text-xs font-cairo font-bold">
              {activeReviewTarget.kind === 'chapter'
                ? 'مراجعة الفصل بالكامل (4 اختيارات — إجابة واحدة صحيحة)'
                : 'مراجعة تراكمية شاملة بعد كل 3 فصول'}
            </span>
            <h3 className="font-cairo font-extrabold text-lg text-slate-900 dark:text-white">
              {activeReviewTarget.kind === 'chapter'
                ? activeReviewTarget.chapter.title
                : activeReviewTarget.milestone.title}
            </h3>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-xs text-slate-700 dark:text-slate-200">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>نظام التقييم الصارم:</strong> في حالة نقصان درجة أو درجتين يتم الاجتياز بشكل عادي ✓، أما نقصان أكثر من درجتين يتطلب إعادة مذاكرة الفصل بالكامل من الدرس الأول.
              </span>
            </div>
          </div>

          {!reviewOutcome ? (
            <>
              <div className="space-y-6">
                {(activeReviewTarget.kind === 'chapter'
                  ? activeReviewTarget.chapter.chapterReviewQuestions
                  : activeReviewTarget.milestone.questions
                ).map((q: CurriculumMcqQuestion, idx: number) => {
                  const hasCodeLines = q.question.includes('\n');
                  return (
                  <div
                    key={q.id}
                    className="space-y-3 p-3.5 sm:p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-950/30 border border-slate-200/80 dark:border-slate-800"
                  >
                    <div className={MCQ_QUESTION_BOX_CLASS}>
                      <div className="mb-2">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg bg-emerald-700/10 dark:bg-emerald-400/15 text-emerald-800 dark:text-emerald-300 text-[11px] font-cairo font-extrabold">
                          السؤال {idx + 1}
                        </span>
                      </div>
                      <p
                        dir="auto"
                        className={`font-bold whitespace-pre-line ${
                          hasCodeLines
                            ? 'p-3.5 rounded-xl bg-slate-900/95 text-emerald-300 font-mono text-xs leading-relaxed border border-slate-800'
                            : 'font-cairo text-sm text-slate-900 dark:text-slate-100 leading-relaxed'
                        }`}
                      >
                        {q.question}
                      </p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {q.options.map((opt, optIdx) => {
                        const selected = reviewAnswers[idx] === optIdx;
                        const style = getMcqOptionSurfaceClass(optIdx, {
                          isSelected: selected,
                        });
                        return (
                          <button
                            key={optIdx}
                            type="button"
                            onClick={() =>
                              setReviewAnswers((prev) => ({ ...prev, [idx]: optIdx }))
                            }
                            dir="auto"
                            className={`text-right px-4 py-3 rounded-xl border-2 text-xs font-cairo font-bold transition-all cursor-pointer ${style}`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep('chapters_map')}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  عودة للفصول
                </button>
                <button
                  type="button"
                  disabled={reviewSubmitting}
                  onClick={handleSubmitReviewExam}
                  className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white text-xs sm:text-sm font-cairo font-extrabold cursor-pointer"
                >
                  {reviewSubmitting ? 'جارِ تصحيح المراجعة...' : 'تسليم إجابات المراجعة واعتماد النتيجة'}
                </button>
              </div>
            </>
          ) : (
            <div className="space-y-5">
              <div
                className={`p-5 rounded-2xl border-2 space-y-2 ${
                  reviewOutcome.passed
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-950 dark:text-emerald-100'
                    : 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-950 dark:text-rose-100'
                }`}
              >
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <h4 className="font-cairo font-extrabold text-base sm:text-lg flex items-center gap-2">
                    {reviewOutcome.passed ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                    ) : (
                      <RotateCcw className="w-6 h-6 text-rose-600" />
                    )}
                    <span>
                      {reviewOutcome.passed
                        ? 'نتيجة المراجعة: اجتياز ناجح ✓'
                        : 'نتيجة المراجعة: يجب إعادة مذاكرة الفصل كامل من الأول ↺'}
                    </span>
                  </h4>
                  <span className="font-mono text-base font-black px-3 py-1 rounded-xl bg-white/80 dark:bg-slate-900">
                    {reviewOutcome.score} / {reviewOutcome.totalQuestions} (مفقود: {reviewOutcome.missedMarks})
                  </span>
                </div>
                <p className="text-xs sm:text-sm leading-relaxed">{reviewOutcome.message}</p>
              </div>

              <AwardTierBadge award={reviewOutcome.newAward} />

              <div className="flex flex-wrap items-center justify-end gap-3">
                {reviewOutcome.mustRestudyChapter && activeReviewTarget.kind === 'chapter' ? (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedChapterId(activeReviewTarget.chapter.id);
                      setSelectedLessonIndex(0);
                      setStep('chapter_workspace');
                    }}
                    className="px-6 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-cairo font-extrabold flex items-center gap-2 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>البدء في إعادة مذاكرة الفصل من الدرس الأول</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setStep('chapters_map')}
                    className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-cairo font-extrabold cursor-pointer"
                  >
                    متابعة الفصول والمراحل التالية
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Teacher Authoring Modal for Adding New Curriculum Lesson */}
      {isAddLessonOpen && activeSubject && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleTeacherAddLesson}
            className="w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-2xl"
          >
            <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
              إضافة درس منهجي جديد + سؤال اختيارات + جرّب الكود ({activeSubject.name})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-cairo font-bold mb-1">الفصل المستهدف</label>
                <select
                  value={newLessonChapterId}
                  onChange={(e) => setNewLessonChapterId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                >
                  {activeSubject.chapters.map((c) => (
                    <option key={c.id} value={c.id}>
                      (ترم {c.term}) {c.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-cairo font-bold mb-1">عنوان الدرس</label>
                <input
                  type="text"
                  required
                  value={newLessonTitle}
                  onChange={(e) => setNewLessonTitle(e.target.value)}
                  placeholder="مثال: الدرس الثالث — الدوال المتقدمة"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-cairo font-bold mb-1">ملخص وشرح الدرس</label>
              <textarea
                rows={2}
                value={newLessonSummary}
                onChange={(e) => setNewLessonSummary(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <label className="block text-xs font-cairo font-bold">سؤال اختيارات (4 خيارات)</label>
              <input
                type="text"
                value={newMcqQuestion}
                onChange={(e) => setNewMcqQuestion(e.target.value)}
                placeholder="نص السؤال..."
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />
              <div className="grid grid-cols-2 gap-2">
                {newMcqOpts.map((opt, idx) => (
                  <input
                    key={idx}
                    type="text"
                    value={opt}
                    onChange={(e) => {
                      const copy = [...newMcqOpts] as [string, string, string, string];
                      copy[idx] = e.target.value;
                      setNewMcqOpts(copy);
                    }}
                    placeholder={`الاختيار ${idx + 1}`}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                  />
                ))}
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span>الإجابة الصحيحة:</span>
                <select
                  value={newMcqCorrect}
                  onChange={(e) => setNewMcqCorrect(Number(e.target.value))}
                  className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                >
                  <option value={0}>الاختيار 1</option>
                  <option value={1}>الاختيار 2</option>
                  <option value={2}>الاختيار 3</option>
                  <option value={3}>الاختيار 4</option>
                </select>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 text-white border border-slate-800 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label className="block text-xs font-cairo font-bold text-emerald-400">
                  تمرين «جرّب الكود» المرتبط بالمادة
                </label>
                <select
                  value={newCodeLang}
                  onChange={(e) => setNewCodeLang(e.target.value as CodeChallengeLanguage)}
                  className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-700 text-[11px] font-mono text-sky-300"
                >
                  <option value="python">Python 3</option>
                  <option value="html_css">HTML5 + CSS3</option>
                  <option value="javascript">JavaScript</option>
                </select>
              </div>
              <input
                type="text"
                value={newCodeTitle}
                onChange={(e) => setNewCodeTitle(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs"
              />
              <input
                type="text"
                value={newCodePrompt}
                onChange={(e) => setNewCodePrompt(e.target.value)}
                placeholder="المطلوب من الطالب تنفيذه في الكود..."
                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs"
              />
              <textarea
                dir="ltr"
                rows={3}
                value={newCodeStarter}
                onChange={(e) => setNewCodeStarter(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs text-emerald-300"
              />
              <input
                dir="ltr"
                type="text"
                value={newCodeExpected}
                onChange={(e) => setNewCodeExpected(e.target.value)}
                placeholder="الناتج المتوقع في console.log"
                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddLessonOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-cairo font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-cairo font-bold cursor-pointer"
              >
                حفظ الدرس في الفصل
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
