import { useEffect, useState, useCallback } from 'react';
import { CurrentUser } from '../types';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const install = useCallback(async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  }, [deferredPrompt]);

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    install,
  };
}

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}

export function usePushNotifications(currentUser?: CurrentUser | null) {
  const isSupported =
    typeof window !== 'undefined' &&
    'Notification' in window &&
    'serviceWorker' in navigator;

  const [permission, setPermission] = useState<NotificationPermission | 'unsupported'>(
    isSupported ? Notification.permission : 'unsupported'
  );
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isBusy, setIsBusy] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const syncSubscriptionState = useCallback(async () => {
    if (!isSupported) return;
    setPermission(Notification.permission);
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && 'pushManager' in reg) {
        const existingSub = await reg.pushManager.getSubscription();
        setIsSubscribed(Boolean(existingSub));
      }
    } catch {
      // ignore inside restricted frames
    }
  }, [isSupported]);

  useEffect(() => {
    syncSubscriptionState();
  }, [syncSubscriptionState]);

  const enablePushNotifications = useCallback(async () => {
    if (!isSupported) {
      setStatusMessage('متصفحك الحالي لا يدعم إشعارات الخلفية.');
      return false;
    }
    setIsBusy(true);
    setStatusMessage(null);
    try {
      const perm = await Notification.requestPermission();
      setPermission(perm);
      if (perm !== 'granted') {
        setStatusMessage('تم رفض إذن الإشعارات من المتصفح. يمكنك السماح بها من إعدادات الموقع.');
        return false;
      }

      const reg = await navigator.serviceWorker.ready;
      if (!('pushManager' in reg)) {
        setStatusMessage('تم منح إذن الإشعارات بنجاح (إشعارات محلية).');
        setIsSubscribed(true);
        return true;
      }

      const keyRes = await fetch('/api/push/vapid-public-key');
      if (!keyRes.ok) throw new Error('تعذر جلب مفتاح الإشعارات من الخادم');
      const { publicKey } = await keyRes.json();

      let sub = await reg.pushManager.getSubscription();
      if (!sub) {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey) as BufferSource,
        });
      }

      const subRes = await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscription: sub.toJSON(),
          userId: currentUser?.id || '',
          userRole: currentUser?.role || 'visitor',
          userName: currentUser?.name || '',
          deviceLabel: navigator.userAgent.slice(0, 80),
        }),
      });

      if (!subRes.ok) throw new Error('تعذر حفظ اشتراك الإشعارات في قاعدة البيانات');
      setIsSubscribed(true);
      setStatusMessage('تم تفعيل إشعارات المتصفح الفورية بنجاح (تعمل حتى عند إغلاق التطبيق).');
      return true;
    } catch (err: any) {
      setStatusMessage(
        err?.message ||
          'ملاحظة: قد يتطلب Push الكامل فتح المنصة في تبويب مستقل خارج الإطار المدمج.'
      );
      return false;
    } finally {
      setIsBusy(false);
    }
  }, [isSupported, currentUser]);

  const disablePushNotifications = useCallback(async () => {
    if (!isSupported) return;
    setIsBusy(true);
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = reg && 'pushManager' in reg ? await reg.pushManager.getSubscription() : null;
      if (sub) {
        await fetch('/api/push/unsubscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ endpoint: sub.endpoint }),
        }).catch(() => {});
        await sub.unsubscribe();
      }
      setIsSubscribed(false);
      setStatusMessage('تم إيقاف اشتراك إشعارات الخلفية لهذا الجهاز.');
    } catch {
      setStatusMessage('تعذر إلغاء الاشتراك.');
    } finally {
      setIsBusy(false);
    }
  }, [isSupported]);

  const sendTestNotification = useCallback(async () => {
    setIsBusy(true);
    setStatusMessage(null);
    try {
      const res = await fetch('/api/push/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: '🔔 إشعار فوري من منصة نوابغ التعليمية',
          body: 'تصل تنبيهات الدروس والواجبات والاختبارات والرسائل مباشرة لجهازك حتى عند إغلاق التطبيق.',
          target: 'all',
        }),
      });
      const data = await res.json().catch(() => ({}));

      // Also show via active Service Worker for instant visual verification
      if (isSupported && Notification.permission === 'granted') {
        const reg = await navigator.serviceWorker.getRegistration();
        if (reg?.active) {
          reg.active.postMessage({
            type: 'SHOW_LOCAL_NOTIFICATION',
            payload: {
              title: '🔔 إشعار تجريبي — منصة نوابغ التعليمية',
              body: 'تم التحقق من عمل إشعارات المتصفح والتطبيق PWA بنجاح.',
              url: '/',
            },
          });
        } else {
          new Notification('🔔 إشعار تجريبي — منصة نوابغ التعليمية', {
            body: 'تم التحقق من عمل إشعارات المتصفح بنجاح.',
            icon: '/pwa-192x192.png',
          });
        }
      }

      setStatusMessage(
        data?.sent > 0
          ? `تم إرسال إشعار Push حقيقي إلى ${data.sent} جهاز مشترك.`
          : 'تم عرض الإشعار التجريبي على هذا المتصفح بنجاح.'
      );
      return true;
    } catch {
      setStatusMessage('تعذر إرسال الإشعار التجريبي.');
      return false;
    } finally {
      setIsBusy(false);
    }
  }, [isSupported]);

  return {
    isSupported,
    permission,
    isSubscribed,
    isBusy,
    statusMessage,
    enablePushNotifications,
    disablePushNotifications,
    sendTestNotification,
  };
}
