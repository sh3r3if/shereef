import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  CameraOff,
  Mic,
  MicOff,
  Video,
  X,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import type { LiveRoomInfo } from '../../types/classroom';

export interface PreJoinSettings {
  micEnabled: boolean;
  camEnabled: boolean;
  audioDeviceId: string;
  videoDeviceId: string;
  guestName?: string;
}

interface PreJoinCheckModalProps {
  room: LiveRoomInfo;
  defaultDisplayName: string;
  requiresGuestName?: boolean;
  isJoining: boolean;
  joinError?: string | null;
  onConfirmJoin: (settings: PreJoinSettings) => void;
  onCancel: () => void;
}

export const PreJoinCheckModal: React.FC<PreJoinCheckModalProps> = ({
  room,
  defaultDisplayName,
  requiresGuestName = false,
  isJoining,
  joinError,
  onConfirmJoin,
  onCancel,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number | null>(null);

  const [micEnabled, setMicEnabled] = useState(true);
  const [camEnabled, setCamEnabled] = useState(true);
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [audioDeviceId, setAudioDeviceId] = useState('');
  const [videoDeviceId, setVideoDeviceId] = useState('');
  const [guestName, setGuestName] = useState(defaultDisplayName);
  const [micLevel, setMicLevel] = useState(0);
  const [deviceWarning, setDeviceWarning] = useState<string | null>(null);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onCancel]);

  useEffect(() => {
    let mounted = true;

    const cleanupMedia = () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
        audioCtxRef.current.close().catch(() => {});
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };

    const startPreview = async () => {
      cleanupMedia();
      if (!navigator.mediaDevices?.getUserMedia) {
        setDeviceWarning('المتصفح الحالي لا يدعم معاينة الكاميرا/الميكروفون — يمكنك الدخول كمستمع.');
        setCamEnabled(false);
        setMicEnabled(false);
        return;
      }

      if (!micEnabled && !camEnabled) {
        if (videoRef.current) videoRef.current.srcObject = null;
        setMicLevel(0);
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: micEnabled
            ? {
                deviceId: audioDeviceId ? { exact: audioDeviceId } : undefined,
                echoCancellation: true,
              }
            : false,
          video: camEnabled
            ? {
                deviceId: videoDeviceId ? { exact: videoDeviceId } : undefined,
                width: { ideal: 1280 },
                height: { ideal: 720 },
              }
            : false,
        });

        if (!mounted) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        setDeviceWarning(null);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }

        // Real Web Audio API volume meter
        if (micEnabled && stream.getAudioTracks().length > 0) {
          const AudioContextCtor =
            window.AudioContext || (window as any).webkitAudioContext;
          if (AudioContextCtor) {
            const ctx = new AudioContextCtor();
            audioCtxRef.current = ctx;
            const src = ctx.createMediaStreamSource(stream);
            const analyser = ctx.createAnalyser();
            analyser.fftSize = 128;
            src.connect(analyser);
            const dataArray = new Uint8Array(analyser.frequencyBinCount);

            const tick = () => {
              if (!mounted) return;
              analyser.getByteFrequencyData(dataArray);
              const avg =
                dataArray.reduce((acc, v) => acc + v, 0) / Math.max(1, dataArray.length);
              setMicLevel(Math.min(100, Math.round((avg / 140) * 100)));
              rafRef.current = requestAnimationFrame(tick);
            };
            tick();
          }
        } else {
          setMicLevel(0);
        }

        const devs = await navigator.mediaDevices.enumerateDevices();
        if (mounted) {
          setAudioDevices(devs.filter((d) => d.kind === 'audioinput'));
          setVideoDevices(devs.filter((d) => d.kind === 'videoinput'));
        }
      } catch {
        if (!mounted) return;
        setDeviceWarning(
          'تعذر الوصول للكاميرا أو الميكروفون. يمكنك إيقافهما والدخول للمشاهدة والاستماع.'
        );
        setCamEnabled(false);
        setMicEnabled(false);
      }
    };

    startPreview();
    return () => {
      mounted = false;
      cleanupMedia();
    };
  }, [micEnabled, camEnabled, audioDeviceId, videoDeviceId]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-tajawal"
      dir="rtl"
      role="dialog"
      aria-modal="true"
      aria-labelledby="prejoin-title"
    >
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h3 id="prejoin-title" className="font-cairo font-bold text-base">
                فحص الكاميرا والصوت قبل دخول الفصل
              </h3>
              <p className="text-xs text-slate-300">
                {room.title} — <span className="font-mono text-emerald-400">{room.roomCode}</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="إغلاق نافذة الفحص"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Camera Preview Box */}
          <div className="md:col-span-7 space-y-3">
            <div className="relative aspect-video rounded-xl bg-slate-950 overflow-hidden border border-slate-800 flex items-center justify-center">
              {camEnabled ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover scale-x-[-1]"
                />
              ) : (
                <div className="text-center text-slate-400 space-y-2 p-4">
                  <CameraOff className="w-10 h-10 mx-auto text-slate-500" />
                  <p className="text-xs font-cairo font-semibold">الكاميرا مغلقة حالياً</p>
                </div>
              )}

              <div className="absolute bottom-3 inset-x-3 flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => setMicEnabled((v) => !v)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-cairo font-bold shadow-md transition-colors cursor-pointer ${
                    micEnabled
                      ? 'bg-slate-900/90 text-white border border-slate-700 hover:bg-slate-800'
                      : 'bg-rose-600 text-white hover:bg-rose-700'
                  }`}
                >
                  {micEnabled ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4" />}
                  <span>{micEnabled ? 'الميكروفون يعمل' : 'الميكروفون مكتوم'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCamEnabled((v) => !v)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-cairo font-bold shadow-md transition-colors cursor-pointer ${
                    camEnabled
                      ? 'bg-slate-900/90 text-white border border-slate-700 hover:bg-slate-800'
                      : 'bg-rose-600 text-white hover:bg-rose-700'
                  }`}
                >
                  {camEnabled ? (
                    <Camera className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <CameraOff className="w-4 h-4" />
                  )}
                  <span>{camEnabled ? 'الكاميرا مفتوحة' : 'الكاميرا مغلقة'}</span>
                </button>
              </div>
            </div>

            {/* Real Mic Level Bar */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-cairo font-bold text-slate-700 dark:text-slate-200">
                  مستوى التقط الصوت (الميكروفون)
                </span>
                <span className="font-mono text-slate-500">{micEnabled ? `${micLevel}%` : 'مكتوم'}</span>
              </div>
              <div className="h-2 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-600 transition-all duration-75"
                  style={{ width: `${micEnabled ? micLevel : 0}%` }}
                />
              </div>
            </div>
          </div>

          {/* Device Selectors & Join Action */}
          <div className="md:col-span-5 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              {requiresGuestName && (
                <div>
                  <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 mb-1">
                    الاسم الظاهر داخل الفصل
                  </label>
                  <input
                    type="text"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="اكتب اسمك الثلاثي"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 mb-1">
                  مصدر الميكروفون
                </label>
                <select
                  value={audioDeviceId}
                  onChange={(e) => setAudioDeviceId(e.target.value)}
                  disabled={audioDevices.length === 0}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                >
                  {audioDevices.length === 0 ? (
                    <option value="">الميكروفون الافتراضي</option>
                  ) : (
                    audioDevices.map((d, i) => (
                      <option key={d.deviceId || i} value={d.deviceId}>
                        {d.label || `ميكروفون ${i + 1}`}
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 mb-1">
                  مصدر الكاميرا
                </label>
                <select
                  value={videoDeviceId}
                  onChange={(e) => setVideoDeviceId(e.target.value)}
                  disabled={videoDevices.length === 0}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                >
                  {videoDevices.length === 0 ? (
                    <option value="">الكاميرا الافتراضية</option>
                  ) : (
                    videoDevices.map((d, i) => (
                      <option key={d.deviceId || i} value={d.deviceId}>
                        {d.label || `كاميرا ${i + 1}`}
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <p className="text-[11px] text-emerald-900 dark:text-emerald-200 leading-relaxed">
                  اتصال مشفر بتوقيع JWT وبث تكيّفي Simulcast لضمان استقرار الصوت والصورة.
                </p>
              </div>

              {(deviceWarning || joinError) && (
                <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 flex items-start gap-2 text-[11px] text-amber-900 dark:text-amber-200">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>{joinError || deviceWarning}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={isJoining}
                onClick={() =>
                  onConfirmJoin({
                    micEnabled,
                    camEnabled,
                    audioDeviceId,
                    videoDeviceId,
                    guestName: guestName.trim() || defaultDisplayName,
                  })
                }
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white text-xs font-cairo font-bold shadow-sm transition-colors cursor-pointer"
              >
                {isJoining ? 'جارِ تأمين الدخول للفصل...' : 'دخول الفصل الافتراضي الآن'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
