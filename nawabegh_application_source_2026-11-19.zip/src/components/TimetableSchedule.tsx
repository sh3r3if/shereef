import React, { useEffect, useMemo, useState } from 'react';
import {
  CalendarDays,
  Clock,
  Plus,
  Wifi,
  Building2,
  ExternalLink,
  MapPin,
  Trash2,
  Edit2,
  Eye,
  Search,
  X,
  RefreshCw,
  BookOpen,
  Users,
  CheckCircle2,
  AlertCircle,
  LayoutGrid,
  Table2,
  Layers,
  GraduationCap,
  FileText,
  Sparkles,
  Radio,
  UserCheck,
  Activity,
} from 'lucide-react';
import {
  TimetableSlot,
  TimetableDay,
  TimetableStatus,
  EnrollmentType,
  Teacher,
  Lesson,
  Language,
  CurrentUser,
  LiveSessionAttendanceLog,
} from '../types';

interface TimetableScheduleProps {
  slots: TimetableSlot[];
  teachers: Teacher[];
  lessons?: Lesson[];
  onAddSlot: (slot: Omit<TimetableSlot, 'id'>) => Promise<TimetableSlot> | void;
  onUpdateSlot?: (slot: TimetableSlot) => Promise<TimetableSlot> | void;
  onDeleteSlot: (id: string) => Promise<void> | void;
  onRefreshSlots?: () => Promise<TimetableSlot[]>;
  language: Language;
  readOnly?: boolean;
  currentUser?: CurrentUser | null;
}

const DAYS_LIST: { key: TimetableDay; ar: string; shortAr: string }[] = [
  { key: 'Saturday', ar: 'السبت', shortAr: 'السبت' },
  { key: 'Sunday', ar: 'الأحد', shortAr: 'الأحد' },
  { key: 'Monday', ar: 'الاثنين', shortAr: 'الاثنين' },
  { key: 'Tuesday', ar: 'الثلاثاء', shortAr: 'الثلاثاء' },
  { key: 'Wednesday', ar: 'الأربعاء', shortAr: 'الأربعاء' },
  { key: 'Thursday', ar: 'الخميس', shortAr: 'الخميس' },
  { key: 'Friday', ar: 'الجمعة', shortAr: 'الجمعة' },
];

const GRADE_OPTIONS = [
  'الصف الأول الإعدادي',
  'الصف الثاني الإعدادي',
  'الصف الثالث الإعدادي',
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
];

const SEMESTER_OPTIONS = [
  'الفصل الدراسي الأول',
  'الفصل الدراسي الثاني',
  'المراجعة النهائية المكثفة',
  'البرنامج الصيفي',
];

const QUICK_TIMES = [
  '03:00 م - 04:30 م',
  '04:00 م - 05:30 م',
  '05:30 م - 07:00 م',
  '07:00 م - 08:30 م',
  '08:30 م - 10:00 م',
];

export const TimetableSchedule: React.FC<TimetableScheduleProps> = ({
  slots,
  teachers,
  lessons = [],
  onAddSlot,
  onUpdateSlot,
  onDeleteSlot,
  onRefreshSlots,
  language,
  readOnly = false,
  currentUser = null,
}) => {
  const isAr = language === 'ar';

  // Filters & View Mode
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDay, setSelectedDay] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<'all' | EnrollmentType>('all');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'cards' | 'weekly'>('cards');

  // Async & Feedback States
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Live Classes Auto-Attendance State
  const [activeAttendanceLog, setActiveAttendanceLog] = useState<LiveSessionAttendanceLog | null>(null);
  const [activeLiveSlot, setActiveLiveSlot] = useState<TimetableSlot | null>(null);
  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false);
  const [attendanceLogs, setAttendanceLogs] = useState<LiveSessionAttendanceLog[]>([]);
  const [attendanceFilterSlotId, setAttendanceFilterSlotId] = useState<string>('all');
  const [loadingAttendance, setLoadingAttendance] = useState(false);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSlot, setEditingSlot] = useState<TimetableSlot | null>(null);
  const [viewingSlot, setViewingSlot] = useState<TimetableSlot | null>(null);
  const [deletingSlot, setDeletingSlot] = useState<TimetableSlot | null>(null);

  // Form State (100% clean, zero fake defaults)
  const [formDay, setFormDay] = useState<TimetableDay>('Saturday');
  const [formTime, setFormTime] = useState('04:00 م - 05:30 م');
  const [formSubject, setFormSubject] = useState('');
  const [formCourseTitle, setFormCourseTitle] = useState('');
  const [formTeacherId, setFormTeacherId] = useState('');
  const [formTeacherName, setFormTeacherName] = useState('');
  const [useCustomTeacher, setUseCustomTeacher] = useState(false);
  const [formLessonId, setFormLessonId] = useState('');
  const [formLessonTitle, setFormLessonTitle] = useState('');
  const [formGrade, setFormGrade] = useState('الصف الثالث الثانوي');
  const [formSemester, setFormSemester] = useState('الفصل الدراسي الأول');
  const [formType, setFormType] = useState<EnrollmentType>('online');
  const [formRoomOrLink, setFormRoomOrLink] = useState('');
  const [formStatus, setFormStatus] = useState<TimetableStatus>('scheduled');
  const [formCapacity, setFormCapacity] = useState<number>(30);
  const [formNotes, setFormNotes] = useState('');

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 4500);
  };

  // Heartbeat interval to track live session duration automatically every 60s
  useEffect(() => {
    if (!activeAttendanceLog?.id) return;
    const timer = window.setInterval(async () => {
      try {
        const res = await fetch('/api/live-attendance/heartbeat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ logId: activeAttendanceLog.id, addMinutes: 1 }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.log) setActiveAttendanceLog(data.log);
        }
      } catch {
        // silent heartbeat retry on next minute
      }
    }, 60000);
    return () => window.clearInterval(timer);
  }, [activeAttendanceLog?.id]);

  const detectLivePlatform = (link?: string): LiveSessionAttendanceLog['platform'] => {
    const val = (link || '').toLowerCase();
    if (val.includes('zoom.us')) return 'zoom';
    if (val.includes('meet.google')) return 'meet';
    if (val.includes('jit.si') || val.includes('jitsi')) return 'jitsi';
    return 'in_app';
  };

  const handleJoinLiveSession = async (slot: TimetableSlot) => {
    try {
      const res = await fetch('/api/live-attendance/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slotId: slot.id,
          slotTitle: slot.courseTitle || slot.subject,
          subject: slot.subject,
          grade: slot.grade,
          platform: detectLivePlatform(slot.roomOrLink),
          studentId: currentUser?.studentId || currentUser?.id || 'guest',
          studentCode: currentUser?.username || '',
          studentName: currentUser?.name || 'مشارك المنصة',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تسجيل الحضور الآلي');
      setActiveAttendanceLog(data.log);
      setActiveLiveSlot(slot);
      showToast(
        isAr
          ? `تم تسجيل حضورك تلقائياً في حصة (${slot.subject}) وبدأ احتساب مدة التواجد ✓`
          : `Auto-attendance recorded for ${slot.subject} ✓`
      );
    } catch (err: any) {
      showToast(err.message || 'تعذر تسجيل الحضور', 'error');
    }
  };

  const handleOpenAttendanceLogs = async (slotId = 'all') => {
    setAttendanceFilterSlotId(slotId);
    setIsAttendanceModalOpen(true);
    setLoadingAttendance(true);
    try {
      const url = slotId !== 'all' ? `/api/live-attendance?slotId=${encodeURIComponent(slotId)}` : '/api/live-attendance';
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setAttendanceLogs(Array.isArray(data.logs) ? data.logs : []);
      }
    } catch {
      showToast('تعذر تحميل سجل الحضور', 'error');
    } finally {
      setLoadingAttendance(false);
    }
  };

  // Dynamic grade list from DB + standard options
  const availableGrades = useMemo(() => {
    const set = new Set<string>(GRADE_OPTIONS);
    slots.forEach((s) => {
      if (s.grade) set.add(s.grade);
    });
    return Array.from(set);
  }, [slots]);

  // Filtered slots
  const filteredSlots = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return slots.filter((slot) => {
      if (selectedDay !== 'all' && slot.day !== selectedDay) return false;
      if (selectedType !== 'all' && slot.type !== selectedType) return false;
      if (selectedGrade !== 'all' && slot.grade !== selectedGrade) return false;
      if (selectedStatus !== 'all' && (slot.status || 'scheduled') !== selectedStatus) return false;
      if (q) {
        const hay = [
          slot.subject,
          slot.courseTitle,
          slot.teacherName,
          slot.lessonTitle,
          slot.grade,
          slot.semester,
          slot.roomOrLink,
          slot.time,
          slot.notes,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [slots, selectedDay, selectedType, selectedGrade, selectedStatus, searchQuery]);

  // Real DB Stats
  const stats = useMemo(() => {
    const onlineCount = slots.filter((s) => s.type === 'online').length;
    const offlineCount = slots.filter((s) => s.type === 'offline').length;
    const uniqueSubjects = new Set(slots.map((s) => s.subject.trim()).filter(Boolean)).size;
    return {
      total: slots.length,
      online: onlineCount,
      offline: offlineCount,
      subjects: uniqueSubjects,
    };
  }, [slots]);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedDay !== 'all' ||
    selectedType !== 'all' ||
    selectedGrade !== 'all' ||
    selectedStatus !== 'all';

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedDay('all');
    setSelectedType('all');
    setSelectedGrade('all');
    setSelectedStatus('all');
  };

  const handleRefresh = async () => {
    if (!onRefreshSlots) return;
    setIsRefreshing(true);
    try {
      const fresh = await onRefreshSlots();
      showToast(
        isAr
          ? `تم تحديث الجدول الدراسي من قاعدة البيانات (${Array.isArray(fresh) ? fresh.length : 0} حصة) ✓`
          : `Synced timetable from DB (${Array.isArray(fresh) ? fresh.length : 0} slots) ✓`
      );
    } catch (err: any) {
      showToast(err?.message || (isAr ? 'تعذر التحديث من قاعدة البيانات' : 'Sync failed'), 'error');
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingSlot(null);
    setFormError(null);
    setFormDay('Saturday');
    setFormTime('04:00 م - 05:30 م');
    setFormSubject(lessons[0]?.subject || teachers[0]?.specialty || '');
    setFormCourseTitle('');
    const firstTeacher = teachers[0];
    setFormTeacherId(firstTeacher?.id || '');
    setFormTeacherName(firstTeacher?.name || '');
    setUseCustomTeacher(teachers.length === 0);
    setFormLessonId('');
    setFormLessonTitle('');
    setFormGrade(lessons[0]?.grade || 'الصف الثالث الثانوي');
    setFormSemester('الفصل الدراسي الأول');
    setFormType('online');
    setFormRoomOrLink('');
    setFormStatus('scheduled');
    setFormCapacity(30);
    setFormNotes('');
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (slot: TimetableSlot) => {
    setEditingSlot(slot);
    setFormError(null);
    setFormDay(slot.day);
    setFormTime(slot.time);
    setFormSubject(slot.subject);
    setFormCourseTitle(slot.courseTitle || '');
    const matchedTeacher = teachers.find(
      (t) => (slot.teacherId && t.id === slot.teacherId) || t.name === slot.teacherName
    );
    setFormTeacherId(matchedTeacher?.id || slot.teacherId || '');
    setFormTeacherName(slot.teacherName);
    setUseCustomTeacher(!matchedTeacher);
    setFormLessonId(slot.lessonId || '');
    setFormLessonTitle(slot.lessonTitle || '');
    setFormGrade(slot.grade);
    setFormSemester(slot.semester || 'الفصل الدراسي الأول');
    setFormType(slot.type);
    setFormRoomOrLink(slot.roomOrLink);
    setFormStatus(slot.status || 'scheduled');
    setFormCapacity(Number(slot.capacity) || 30);
    setFormNotes(slot.notes || '');
    setIsAddModalOpen(true);
  };

  const handleSelectTeacher = (teacherId: string) => {
    setFormTeacherId(teacherId);
    const t = teachers.find((item) => item.id === teacherId);
    if (t) {
      setFormTeacherName(t.name);
      if (!formSubject.trim() && t.specialty) {
        setFormSubject(t.specialty);
      }
    }
  };

  const handleSelectLesson = (lessonId: string) => {
    setFormLessonId(lessonId);
    const les = lessons.find((l) => l.id === lessonId);
    if (les) {
      setFormLessonTitle(les.title);
      if (!formSubject.trim()) setFormSubject(les.subject);
      if (!formCourseTitle.trim()) setFormCourseTitle(les.unit ? `${les.unit} — ${les.title}` : les.title);
      if (les.grade) setFormGrade(les.grade);
      if (les.teacherName && !formTeacherName.trim()) {
        const matchedT = teachers.find((t) => t.id === les.teacherId || t.name === les.teacherName);
        if (matchedT) {
          setFormTeacherId(matchedT.id);
          setFormTeacherName(matchedT.name);
          setUseCustomTeacher(false);
        } else {
          setFormTeacherName(les.teacherName);
          setUseCustomTeacher(true);
        }
      }
    } else {
      setFormLessonTitle('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formSubject.trim() || !formTeacherName.trim() || !formTime.trim() || !formRoomOrLink.trim()) {
      setFormError(
        isAr
          ? 'يرجى استيفاء جميع الحقول الأساسية: المادة الدراسية، اسم المعلم، التوقيت، والقاعة أو الرابط.'
          : 'Please complete all required fields: Subject, Teacher, Time, and Room/Link.'
      );
      return;
    }

    const dayObj = DAYS_LIST.find((d) => d.key === formDay);
    const dayAr = dayObj ? dayObj.ar : formDay;

    const payload: Omit<TimetableSlot, 'id'> = {
      day: formDay,
      dayAr,
      time: formTime.trim(),
      subject: formSubject.trim(),
      courseTitle: formCourseTitle.trim(),
      teacherId: useCustomTeacher ? '' : formTeacherId,
      teacherName: formTeacherName.trim(),
      lessonId: formLessonId,
      lessonTitle: formLessonTitle.trim(),
      grade: formGrade.trim(),
      semester: formSemester.trim(),
      type: formType,
      roomOrLink: formRoomOrLink.trim(),
      status: formStatus,
      capacity: Math.max(1, Number(formCapacity) || 30),
      notes: formNotes.trim(),
    };

    setIsSubmitting(true);
    try {
      if (editingSlot && onUpdateSlot) {
        await onUpdateSlot({ ...payload, id: editingSlot.id });
        showToast(
          isAr
            ? `تم تعديل وحفظ الحصة "${payload.subject}" في قاعدة البيانات ✓`
            : `Updated schedule slot "${payload.subject}" ✓`
        );
      } else {
        await onAddSlot(payload);
        showToast(
          isAr
            ? `تمت إضافة وجدولة الحصة "${payload.subject}" في قاعدة البيانات ✓`
            : `Added schedule slot "${payload.subject}" ✓`
        );
      }
      setIsAddModalOpen(false);
      setEditingSlot(null);
    } catch (err: any) {
      setFormError(err?.message || (isAr ? 'حدث خطأ أثناء الحفظ في قاعدة البيانات' : 'Failed to save to database'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingSlot) return;
    setIsDeleting(true);
    try {
      await onDeleteSlot(deletingSlot.id);
      showToast(
        isAr
          ? `تم حذف الحصة "${deletingSlot.subject}" من الجدول وقاعدة البيانات ✓`
          : `Deleted "${deletingSlot.subject}" from DB ✓`
      );
      if (viewingSlot?.id === deletingSlot.id) {
        setViewingSlot(null);
      }
      setDeletingSlot(null);
    } catch (err: any) {
      showToast(err?.message || (isAr ? 'تعذر حذف الحصة من قاعدة البيانات' : 'Delete failed'), 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusBadge = (status?: TimetableStatus) => {
    switch (status) {
      case 'live':
        return {
          label: isAr ? 'مباشرة الآن' : 'Live Now',
          cls: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800',
        };
      case 'completed':
        return {
          label: isAr ? 'مكتملة' : 'Completed',
          cls: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
        };
      case 'cancelled':
        return {
          label: isAr ? 'ملغاة' : 'Cancelled',
          cls: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-200 dark:border-rose-800',
        };
      default:
        return {
          label: isAr ? 'مجدولة' : 'Scheduled',
          cls: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
        };
    }
  };

  const isUrl = (value: string) => /^https?:\/\//i.test(value.trim());

  return (
    <div className="space-y-6">
      {/* Toast Notification Banner */}
      {toast && (
        <div
          className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 shadow-sm ${
            toast.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2 text-xs md:text-sm font-cairo font-bold">
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{toast.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-lg relative overflow-hidden">
        <div className="space-y-1.5 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-200 text-xs font-bold border border-blue-400/30">
            <CalendarDays className="w-4 h-4" />
            <span>{isAr ? 'الجدول الدراسي والمقررات — مرتبط بقاعدة البيانات' : 'DB Academic Timetable & Courses'}</span>
          </div>
          <h2 className="text-2xl font-bold font-cairo">
            {isAr ? 'تنظيم وجدولة الحصص والمقررات الدراسية' : 'Class Schedule & Courses Timetable'}
          </h2>
          <p className="text-xs md:text-sm text-slate-300 font-tajawal max-w-2xl">
            {isAr
              ? 'إدارة كاملة للحصص المباشرة والحضورية والمقررات الدراسية المرتبطة بالمعلمين والدروس في قاعدة البيانات، مع دعم الإضافة والتعديل والحذف والبحث وعرض التفاصيل.'
              : 'Manage live online & physical center classes and courses directly synced with the database.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 relative z-10">
          {!readOnly && (
            <button
              type="button"
              onClick={() => handleOpenAttendanceLogs('all')}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-600/80 hover:bg-emerald-500 text-white border border-emerald-400/40 font-cairo font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
            >
              <UserCheck className="w-4 h-4" />
              <span>{isAr ? 'سجل الحضور الآلي للحصص' : 'Auto-Attendance Log'}</span>
            </button>
          )}
          {onRefreshSlots && (
            <button
              type="button"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 font-cairo font-bold text-xs flex items-center gap-2 transition-all cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isAr ? 'تحديث من الداتا بيز' : 'Sync DB'}</span>
            </button>
          )}
          {!readOnly && (
            <button
              type="button"
              onClick={handleOpenAdd}
              className="px-4 py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-slate-950 font-cairo font-bold text-xs md:text-sm flex items-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة حصة أو مقرر جديد' : 'Add Class / Course'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Live Session Auto-Attendance Tracker Banner */}
      {activeAttendanceLog && activeLiveSlot && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h4 className="font-cairo font-bold text-sm text-emerald-950 dark:text-emerald-100">
                {isAr
                  ? `حضور مباشر مسجل آلياً: ${activeLiveSlot.subject} (${activeLiveSlot.teacherName})`
                  : `Live Attendance Active: ${activeLiveSlot.subject}`}
              </h4>
              <p className="text-xs text-emerald-700 dark:text-emerald-300 font-tajawal flex items-center gap-2">
                <Activity className="w-3.5 h-3.5" />
                <span>
                  {isAr ? 'مدة بقائك المحتسبة:' : 'Tracked Duration:'}{' '}
                  <strong className="font-mono-numbers">{activeAttendanceLog.durationMinutes}</strong>{' '}
                  {isAr ? 'دقيقة (يتجدد تلقائياً كل دقيقة)' : 'min'}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isUrl(activeLiveSlot.roomOrLink) && (
              <a
                href={activeLiveSlot.roomOrLink}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>{isAr ? 'فتح رابط الحصة (Zoom / Meet / Jitsi)' : 'Open Session Link'}</span>
              </a>
            )}
            <button
              type="button"
              onClick={() => {
                setActiveAttendanceLog(null);
                setActiveLiveSlot(null);
              }}
              className="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-cairo font-bold cursor-pointer"
            >
              {isAr ? 'مغادرة الجلسة' : 'Leave Session'}
            </button>
          </div>
        </div>
      )}

      {/* Live DB KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
            <CalendarDays className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] text-slate-500 font-tajawal">{isAr ? 'إجمالي الحصص المجدولة' : 'Total Classes'}</p>
            <p className="text-xl font-black font-mono-numbers text-slate-900 dark:text-white">{stats.total}</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Wifi className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] text-slate-500 font-tajawal">{isAr ? 'حصص أونلاين' : 'Online Classes'}</p>
            <p className="text-xl font-black font-mono-numbers text-slate-900 dark:text-white">{stats.online}</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] text-slate-500 font-tajawal">{isAr ? 'حصص السنتر الحضورية' : 'Center Classes'}</p>
            <p className="text-xl font-black font-mono-numbers text-slate-900 dark:text-white">{stats.offline}</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] text-slate-500 font-tajawal">{isAr ? 'المقررات والمواد' : 'Active Subjects'}</p>
            <p className="text-xl font-black font-mono-numbers text-slate-900 dark:text-white">{stats.subjects}</p>
          </div>
        </div>
      </div>

      {/* Filter, Search, and View Toggle Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 right-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isAr
                  ? 'ابحث بالمادة، اسم المقرر، المعلم، الصف الدراسي، القاعة أو الملاحظات...'
                  : 'Search by subject, course, teacher, grade, room, or notes...'
              }
              className="w-full pr-10 pl-4 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 font-tajawal"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedDay}
              onChange={(e) => setSelectedDay(e.target.value)}
              className="px-3 py-2 rounded-xl text-xs font-cairo bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="all">{isAr ? 'كافة أيام الأسبوع' : 'All Days'}</option>
              {DAYS_LIST.map((d) => (
                <option key={d.key} value={d.key}>
                  {isAr ? d.ar : d.key}
                </option>
              ))}
            </select>

            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as any)}
              className="px-3 py-2 rounded-xl text-xs font-cairo bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="all">{isAr ? 'كافة الأنظمة' : 'All Types'}</option>
              <option value="online">{isAr ? 'أونلاين (افتراضي)' : 'Online'}</option>
              <option value="offline">{isAr ? 'سنتر (حضوري)' : 'Center (Offline)'}</option>
            </select>

            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="px-3 py-2 rounded-xl text-xs font-cairo bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="all">{isAr ? 'كافة الصفوف' : 'All Grades'}</option>
              {availableGrades.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 rounded-xl text-xs font-cairo bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="all">{isAr ? 'كافة الحالات' : 'All Statuses'}</option>
              <option value="scheduled">{isAr ? 'مجدولة' : 'Scheduled'}</option>
              <option value="live">{isAr ? 'مباشرة الآن' : 'Live'}</option>
              <option value="completed">{isAr ? 'مكتملة' : 'Completed'}</option>
              <option value="cancelled">{isAr ? 'ملغاة' : 'Cancelled'}</option>
            </select>

            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setViewMode('cards')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  viewMode === 'cards'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title={isAr ? 'عرض البطاقات' : 'Cards View'}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('weekly')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  viewMode === 'weekly'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title={isAr ? 'الجدول الأسبوعي المنظم' : 'Weekly Schedule'}
              >
                <Table2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {hasActiveFilters && (
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs font-tajawal">
            <span className="text-slate-500">
              {isAr
                ? `عرض ${filteredSlots.length} من أصل ${slots.length} حصة مسجلة`
                : `Showing ${filteredSlots.length} of ${slots.length} slots`}
            </span>
            <button
              type="button"
              onClick={resetFilters}
              className="text-blue-600 dark:text-blue-400 font-cairo font-bold hover:underline cursor-pointer"
            >
              {isAr ? 'مسح الفلاتر' : 'Reset Filters'}
            </button>
          </div>
        )}
      </div>

      {/* Empty State vs Cards vs Weekly Matrix */}
      {filteredSlots.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 space-y-3">
          <CalendarDays className="w-12 h-12 mx-auto text-slate-400" />
          <h3 className="font-cairo font-bold text-base text-slate-800 dark:text-white">
            {slots.length === 0
              ? isAr
                ? 'لا توجد حصص أو مقررات مجدولة في قاعدة البيانات بعد'
                : 'No scheduled classes or courses in DB yet'
              : isAr
              ? 'لا توجد حصص مطابقة لخيارات البحث الحالية'
              : 'No classes match your current filters'}
          </h3>
          <p className="text-xs text-slate-500 font-tajawal max-w-md mx-auto">
            {slots.length === 0
              ? isAr
                ? 'ابدأ بإضافة أول حصة دراسية أو ربطها بأحد المعلمين والدروس المرفوعة ليتم حفظها في قاعدة البيانات.'
                : 'Click below to schedule the first real class session or course in the database.'
              : isAr
              ? 'جرّب تعديل كلمات البحث أو مسح الفلاتر لإظهار الحصص المسجلة.'
              : 'Try adjusting your search or resetting active filters.'}
          </p>
          <div className="pt-2 flex items-center justify-center gap-2">
            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إعادة ضبط البحث' : 'Reset Search'}
              </button>
            )}
            {!readOnly && (
              <button
                type="button"
                onClick={handleOpenAdd}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-cairo font-bold inline-flex items-center gap-2 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إضافة حصة دراسية الآن' : 'Schedule First Class'}</span>
              </button>
            )}
          </div>
        </div>
      ) : viewMode === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSlots.map((slot) => {
            const isOnline = slot.type === 'online';
            const statusMeta = getStatusBadge(slot.status);

            return (
              <div
                key={slot.id}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 transition-all shadow-xs flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="px-2.5 py-1 rounded-xl text-xs font-cairo font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                      {isAr ? slot.dayAr : slot.day}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.cls}`}
                      >
                        {statusMeta.label}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          isOnline
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {isOnline ? (
                          <>
                            <Wifi className="w-3 h-3" />
                            <span>{isAr ? 'أونلاين' : 'Online'}</span>
                          </>
                        ) : (
                          <>
                            <Building2 className="w-3 h-3" />
                            <span>{isAr ? 'سنتر' : 'Center'}</span>
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white leading-snug">
                      {slot.subject}
                    </h3>
                    {slot.courseTitle && (
                      <p className="text-xs text-indigo-600 dark:text-indigo-400 font-cairo font-semibold mt-0.5 line-clamp-1">
                        {slot.courseTitle}
                      </p>
                    )}
                    <p className="text-xs text-slate-500 font-tajawal mt-0.5">
                      {slot.grade}
                      {slot.semester ? ` · ${slot.semester}` : ''}
                    </p>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-tajawal pt-2 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-mono-numbers">{slot.time}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <GraduationCap className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-bold font-cairo text-slate-700 dark:text-slate-200">
                        {slot.teacherName}
                      </span>
                    </div>

                    {slot.lessonTitle && (
                      <div className="flex items-center gap-1.5 text-[11px] text-emerald-700 dark:text-emerald-400 truncate">
                        <BookOpen className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{slot.lessonTitle}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 truncate">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{slot.roomOrLink}</span>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setViewingSlot(slot)}
                      className="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 font-cairo font-bold hover:underline cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isAr ? 'التفاصيل' : 'Details'}</span>
                    </button>

                    {isOnline && (
                      <button
                        type="button"
                        onClick={() => handleJoinLiveSession(slot)}
                        className="px-2.5 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-cairo font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Radio className="w-3 h-3" />
                        <span>{isAr ? 'دخول وتسجيل الحضور' : 'Join & Attend'}</span>
                      </button>
                    )}
                  </div>

                  {!readOnly && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleOpenAttendanceLogs(slot.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 transition-colors cursor-pointer"
                        title={isAr ? 'سجل حضور الحصة الآلي' : 'Session Attendance'}
                      >
                        <UserCheck className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(slot)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/60 transition-colors cursor-pointer"
                        title={isAr ? 'تعديل الحصة' : 'Edit'}
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeletingSlot(slot)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors cursor-pointer"
                        title={isAr ? 'حذف الحصة' : 'Delete'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Weekly Organized Grid by Day */
        <div className="space-y-4">
          {DAYS_LIST.map((dayObj) => {
            const daySlots = filteredSlots.filter((s) => s.day === dayObj.key);
            if (selectedDay !== 'all' && selectedDay !== dayObj.key) return null;
            if (daySlots.length === 0) return null;

            return (
              <div
                key={dayObj.key}
                className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs"
              >
                <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CalendarDays className="w-4 h-4 text-blue-600" />
                    <h3 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                      {isAr ? dayObj.ar : dayObj.key}
                    </h3>
                  </div>
                  <span className="text-xs font-mono-numbers font-bold text-slate-500">
                    {daySlots.length} {isAr ? 'حصص' : 'sessions'}
                  </span>
                </div>

                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {daySlots.map((slot) => {
                    const statusMeta = getStatusBadge(slot.status);
                    return (
                      <div
                        key={slot.id}
                        className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-50/70 dark:hover:bg-slate-800/30 transition-colors"
                      >
                        <div className="flex items-start md:items-center gap-4 min-w-0">
                          <div className="px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-mono-numbers text-xs font-bold shrink-0">
                            {slot.time}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                                {slot.subject}
                              </h4>
                              {slot.courseTitle && (
                                <span className="text-xs text-indigo-600 dark:text-indigo-400 font-tajawal">
                                  ({slot.courseTitle})
                                </span>
                              )}
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.cls}`}>
                                {statusMeta.label}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-tajawal mt-0.5">
                              {slot.teacherName} · {slot.grade} · {slot.roomOrLink}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => setViewingSlot(slot)}
                            className="px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 text-xs font-cairo font-bold hover:bg-blue-100 cursor-pointer flex items-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{isAr ? 'التفاصيل' : 'Details'}</span>
                          </button>
                          {!readOnly && (
                            <>
                              <button
                                type="button"
                                onClick={() => handleOpenEdit(slot)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/60 cursor-pointer"
                                title={isAr ? 'تعديل' : 'Edit'}
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingSlot(slot)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 cursor-pointer"
                                title={isAr ? 'حذف' : 'Delete'}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ADD / EDIT MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4 my-auto max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-blue-600" />
                <h3 className="font-cairo font-bold text-lg text-slate-900 dark:text-white">
                  {editingSlot
                    ? isAr
                      ? 'تعديل بيانات الحصة والمقرر الدراسي'
                      : 'Edit Class & Course Slot'
                    : isAr
                    ? 'إضافة وجدولة حصة أو مقرر دراسي جديد'
                    : 'Schedule New Class / Course'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingSlot(null);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-cairo font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 font-tajawal text-xs md:text-sm">
              {/* Optional Link to DB Lesson / Course */}
              {lessons.length > 0 && (
                <div className="p-3 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/80 dark:border-indigo-800/50 space-y-1.5">
                  <label className="flex items-center gap-1.5 text-xs font-bold text-indigo-800 dark:text-indigo-300 font-cairo">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isAr ? 'ربط اختياري بمقرر/درس من المكتبة (يملأ الحقول تلقائياً)' : 'Optional: Link to DB Lesson'}</span>
                  </label>
                  <select
                    value={formLessonId}
                    onChange={(e) => handleSelectLesson(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 text-xs font-cairo focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  >
                    <option value="">{isAr ? '— بدون ربط مباشر بدرس محدد —' : '— No linked lesson —'}</option>
                    {lessons.map((les) => (
                      <option key={les.id} value={les.id}>
                        {les.title} ({les.subject} - {les.grade})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'اليوم *' : 'Day *'}
                  </label>
                  <select
                    value={formDay}
                    onChange={(e) => setFormDay(e.target.value as TimetableDay)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    {DAYS_LIST.map((d) => (
                      <option key={d.key} value={d.key}>
                        {isAr ? d.ar : d.key}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'نظام الحصة *' : 'Class Type *'}
                  </label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as EnrollmentType)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    <option value="online">{isAr ? 'أونلاين (بث افتراضي)' : 'Online'}</option>
                    <option value="offline">{isAr ? 'سنتر (حضوري)' : 'Center (Offline)'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'الحالة' : 'Status'}
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as TimetableStatus)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    <option value="scheduled">{isAr ? 'مجدولة' : 'Scheduled'}</option>
                    <option value="live">{isAr ? 'مباشرة الآن' : 'Live Now'}</option>
                    <option value="completed">{isAr ? 'مكتملة' : 'Completed'}</option>
                    <option value="cancelled">{isAr ? 'ملغاة' : 'Cancelled'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'المادة الدراسية *' : 'Subject *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formSubject}
                    onChange={(e) => setFormSubject(e.target.value)}
                    placeholder={isAr ? 'مثال: الرياضيات، الفيزياء، الكيمياء...' : 'e.g. Mathematics'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'عنوان المقرر / الوحدة الدراسية' : 'Course / Unit Title'}
                  </label>
                  <input
                    type="text"
                    value={formCourseTitle}
                    onChange={(e) => setFormCourseTitle(e.target.value)}
                    placeholder={isAr ? 'مثال: الوحدة الأولى - التفاضل والتكامل' : 'e.g. Unit 1: Calculus'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Teacher from DB or custom */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 font-cairo">
                    {isAr ? 'المعلم المسؤول *' : 'Teacher *'}
                  </label>
                  {teachers.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        const nextCustom = !useCustomTeacher;
                        setUseCustomTeacher(nextCustom);
                        if (!nextCustom && teachers[0]) {
                          setFormTeacherId(teachers[0].id);
                          setFormTeacherName(teachers[0].name);
                        }
                      }}
                      className="text-[11px] font-cairo font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      {useCustomTeacher
                        ? isAr
                          ? 'اختيار من قائمة المعلمين المسجلين'
                          : 'Pick from DB Teachers'
                        : isAr
                        ? 'إدخال اسم معلم يدوياً'
                        : 'Type Teacher Name'}
                    </button>
                  )}
                </div>

                {!useCustomTeacher && teachers.length > 0 ? (
                  <select
                    value={formTeacherId}
                    onChange={(e) => handleSelectTeacher(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    <option value="">{isAr ? '— اختر المعلم من قاعدة البيانات —' : '— Select Teacher —'}</option>
                    {teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.specialty})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    required
                    value={formTeacherName}
                    onChange={(e) => setFormTeacherName(e.target.value)}
                    placeholder={
                      teachers.length === 0
                        ? isAr
                          ? 'أدخل اسم المعلم (أو أضف معلمين أولاً من قسم هيئة التدريس)'
                          : 'Enter teacher name'
                        : isAr
                        ? 'أدخل اسم المعلم...'
                        : 'Enter teacher name...'
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'الصف الدراسي *' : 'Grade *'}
                  </label>
                  <select
                    value={formGrade}
                    onChange={(e) => setFormGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    {availableGrades.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'الفصل الدراسي' : 'Semester'}
                  </label>
                  <select
                    value={formSemester}
                    onChange={(e) => setFormSemester(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    {SEMESTER_OPTIONS.map((sem) => (
                      <option key={sem} value={sem}>
                        {sem}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                    {isAr ? 'السعة الاستيعابية' : 'Capacity'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={formCapacity}
                    onChange={(e) => setFormCapacity(Number(e.target.value) || 30)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono-numbers"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                  {isAr ? 'التوقيت *' : 'Time Slot *'}
                </label>
                <input
                  type="text"
                  required
                  value={formTime}
                  onChange={(e) => setFormTime(e.target.value)}
                  placeholder="04:00 م - 05:30 م"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono-numbers"
                />
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {QUICK_TIMES.map((qt) => (
                    <button
                      key={qt}
                      type="button"
                      onClick={() => setFormTime(qt)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-mono-numbers border cursor-pointer transition-colors ${
                        formTime === qt
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400'
                      }`}
                    >
                      {qt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                  {isAr ? 'القاعة الحضورية أو رابط البث المباشر *' : 'Room / Virtual Link *'}
                </label>
                <input
                  type="text"
                  required
                  value={formRoomOrLink}
                  onChange={(e) => setFormRoomOrLink(e.target.value)}
                  placeholder={
                    formType === 'online'
                      ? isAr
                        ? 'مثال: القاعة الافتراضية 1 أو رابط الحصة المباشرة'
                        : 'Virtual Room 1 or URL'
                      : isAr
                      ? 'مثال: مقر السنتر الرئيسي - قاعة 3'
                      : 'Center Building - Room 3'
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 font-cairo">
                  {isAr ? 'ملاحظات وخطة المقرر' : 'Course Notes & Objectives'}
                </label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder={isAr ? 'أهداف الحصة، الواجب المطلوب، أو تعليمات للطلاب...' : 'Optional notes or homework instructions...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingSlot(null);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
                >
                  {isSubmitting
                    ? isAr
                      ? 'جارٍ الحفظ...'
                      : 'Saving...'
                    : editingSlot
                    ? isAr
                      ? 'حفظ التعديلات في الداتا بيز'
                      : 'Save Changes'
                    : isAr
                    ? 'حفظ وجدولة الحصة'
                    : 'Schedule Slot'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW DETAILS MODAL */}
      {viewingSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-600" />
                <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                  {isAr ? 'تفاصيل الحصة والمقرر الدراسي' : 'Class & Course Details'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setViewingSlot(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <h4 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                  {viewingSlot.subject}
                </h4>
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${getStatusBadge(viewingSlot.status).cls}`}>
                  {getStatusBadge(viewingSlot.status).label}
                </span>
              </div>
              {viewingSlot.courseTitle && (
                <p className="text-xs text-indigo-600 dark:text-indigo-400 font-cairo font-semibold">
                  {viewingSlot.courseTitle}
                </p>
              )}
            </div>

            <div className="space-y-2.5 text-xs md:text-sm font-tajawal">
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'المعلم المسؤول:' : 'Teacher:'}</span>
                <span className="font-bold text-slate-900 dark:text-white">{viewingSlot.teacherName}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'الصف الدراسي:' : 'Grade:'}</span>
                <span className="font-semibold">{viewingSlot.grade}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'الفصل الدراسي:' : 'Semester:'}</span>
                <span>{viewingSlot.semester || (isAr ? 'الفصل الدراسي الأول' : 'Term 1')}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'اليوم والتوقيت:' : 'Day & Time:'}</span>
                <span className="font-mono-numbers font-bold text-blue-600 dark:text-blue-400">
                  {viewingSlot.dayAr} · {viewingSlot.time}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'نظام الحصة:' : 'Mode:'}</span>
                <span className="font-bold">
                  {viewingSlot.type === 'online' ? (isAr ? 'أونلاين (بث افتراضي)' : 'Online') : isAr ? 'سنتر حضوري' : 'Center Offline'}
                </span>
              </div>
              <div className="flex justify-between items-center gap-3 py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 shrink-0">{isAr ? 'القاعة / الرابط:' : 'Location:'}</span>
                {isUrl(viewingSlot.roomOrLink) ? (
                  <a
                    href={viewingSlot.roomOrLink}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 font-semibold hover:underline truncate"
                  >
                    <span className="truncate">{viewingSlot.roomOrLink}</span>
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  </a>
                ) : (
                  <span className="font-semibold text-blue-600 dark:text-blue-400 text-left">
                    {viewingSlot.roomOrLink}
                  </span>
                )}
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">{isAr ? 'الطاقة الاستيعابية:' : 'Capacity:'}</span>
                <span className="font-mono-numbers flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  {viewingSlot.capacity || 30} {isAr ? 'طالب' : 'students'}
                </span>
              </div>
              {viewingSlot.lessonTitle && (
                <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">{isAr ? 'الدرس المرتبط:' : 'Linked Lesson:'}</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-bold">{viewingSlot.lessonTitle}</span>
                </div>
              )}
              {viewingSlot.notes && (
                <div className="pt-1 space-y-1">
                  <span className="text-slate-500 flex items-center gap-1 text-xs">
                    <FileText className="w-3.5 h-3.5" />
                    <span>{isAr ? 'ملاحظات المقرر:' : 'Notes:'}</span>
                  </span>
                  <p className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
                    {viewingSlot.notes}
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                {!readOnly && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        const target = viewingSlot;
                        setViewingSlot(null);
                        handleOpenEdit(target);
                      }}
                      className="px-3.5 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-xs font-cairo font-bold hover:bg-blue-100 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'تعديل' : 'Edit'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeletingSlot(viewingSlot)}
                      className="px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs font-cairo font-bold hover:bg-rose-100 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'حذف' : 'Delete'}</span>
                    </button>
                  </>
                )}
              </div>
              <button
                type="button"
                onClick={() => setViewingSlot(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-cairo font-bold hover:bg-slate-200 cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRM MODAL */}
      {deletingSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف الحصة الدراسية' : 'Confirm Slot Deletion'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal leading-relaxed">
                {isAr
                  ? `هل أنت متأكد من حذف حصة "${deletingSlot.subject}" (${deletingSlot.dayAr} - ${deletingSlot.time}) نهائياً من قاعدة البيانات؟`
                  : `Are you sure you want to delete "${deletingSlot.subject}" from the database?`}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeletingSlot(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
              >
                {isDeleting ? (isAr ? 'جارٍ الحذف...' : 'Deleting...') : isAr ? 'نعم، حذف نهائي' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LIVE ATTENDANCE LOGS MODAL */}
      {isAttendanceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 backdrop-blur-xs p-4">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[88vh] flex flex-col">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <UserCheck className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-cairo font-bold text-base">
                    {isAr ? 'سجل الحضور الآلي للحصص المباشرة' : 'Live Classes Auto-Attendance Log'}
                  </h3>
                  <p className="text-xs text-slate-300 font-tajawal">
                    {isAr
                      ? 'رصد لحظي لدخول الطلاب إلى جلسات Zoom / Meet / Jitsi واحتساب مدة البقاء بالدقائق'
                      : 'Real-time student join logs and session duration tracking'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAttendanceModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between gap-3">
                <select
                  value={attendanceFilterSlotId}
                  onChange={(e) => handleOpenAttendanceLogs(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-cairo cursor-pointer"
                >
                  <option value="all">{isAr ? 'جميع الحصص المجدولة' : 'All Scheduled Sessions'}</option>
                  {slots.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.subject} — {s.dayAr} ({s.time})
                    </option>
                  ))}
                </select>
                <span className="text-xs font-mono-numbers font-bold text-slate-500">
                  {attendanceLogs.length} {isAr ? 'سجل حضور' : 'records'}
                </span>
              </div>

              {loadingAttendance ? (
                <div className="p-8 text-center text-xs text-slate-500 font-cairo">
                  {isAr ? 'جاري تحميل سجل الحضور الآلي...' : 'Loading attendance logs...'}
                </div>
              ) : attendanceLogs.length === 0 ? (
                <div className="p-8 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400 font-tajawal">
                  {isAr
                    ? 'لم يتم تسجيل دخول أي طالب عبر رابط الحصة المباشرة حتى الآن.'
                    : 'No live attendance logs recorded yet.'}
                </div>
              ) : (
                <div className="space-y-2">
                  {attendanceLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-0.5">
                        <p className="font-cairo font-bold text-slate-900 dark:text-white">
                          {log.studentName}
                          {log.studentCode && (
                            <span className="text-slate-500 font-mono-numbers mr-2">({log.studentCode})</span>
                          )}
                        </p>
                        <p className="text-[11px] text-slate-500 font-tajawal">
                          {log.subject} · {log.slotTitle} · <span className="uppercase">{log.platform}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-3 font-mono-numbers">
                        <span className="text-[11px] text-slate-500">
                          {new Date(log.joinedAt).toLocaleString('ar-EG', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        <span className="px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-cairo font-bold">
                          {log.durationMinutes} {isAr ? 'دقيقة' : 'min'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
