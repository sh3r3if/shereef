import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ConnectionQuality,
  Room,
  RoomEvent,
  Track,
  VideoPresets,
  type RemoteParticipant,
  type RemoteTrack,
} from 'livekit-client';
import type { Socket } from 'socket.io-client';
import type { ClassroomRole, ConnectionQualityLevel } from '../../types/classroom';

export interface RemoteMediaTile {
  participantId: string;
  userName: string;
  role: string;
  cameraStream: MediaStream | null;
  screenStream: MediaStream | null;
  audioStream: MediaStream | null;
  connectionQuality: ConnectionQualityLevel;
}

interface UseLiveKitMediaOptions {
  mode: 'livekit' | 'webrtc-p2p';
  livekitUrl: string | null;
  livekitToken: string | null;
  socket: Socket | null;
  selfSocketId?: string;
  userRole: ClassroomRole;
  initialMicEnabled: boolean;
  initialCamEnabled: boolean;
  selectedAudioDeviceId?: string;
  selectedVideoDeviceId?: string;
  onMediaStateChange?: (state: {
    isMicEnabled?: boolean;
    isCamEnabled?: boolean;
    isScreenSharing?: boolean;
  }) => void;
  onQualityChange?: (quality: ConnectionQualityLevel) => void;
}

function mapLiveKitQuality(q: ConnectionQuality): ConnectionQualityLevel {
  switch (q) {
    case ConnectionQuality.Excellent:
      return 'excellent';
    case ConnectionQuality.Good:
      return 'good';
    case ConnectionQuality.Poor:
      return 'poor';
    case ConnectionQuality.Lost:
      return 'lost';
    default:
      return 'unknown';
  }
}

export function useLiveKitMedia({
  mode,
  livekitUrl,
  livekitToken,
  socket,
  selfSocketId,
  userRole,
  initialMicEnabled,
  initialCamEnabled,
  selectedAudioDeviceId,
  selectedVideoDeviceId,
  onMediaStateChange,
  onQualityChange,
}: UseLiveKitMediaOptions) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [localScreenStream, setLocalScreenStream] = useState<MediaStream | null>(null);
  const [remoteTiles, setRemoteTiles] = useState<RemoteMediaTile[]>([]);
  const [isMicEnabled, setIsMicEnabled] = useState<boolean>(initialMicEnabled);
  const [isCamEnabled, setIsCamEnabled] = useState<boolean>(initialCamEnabled);
  const [isScreenSharing, setIsScreenSharing] = useState<boolean>(false);
  const [localQuality, setLocalQuality] = useState<ConnectionQualityLevel>('excellent');
  const [mediaError, setMediaError] = useState<string | null>(null);

  const lkRoomRef = useRef<Room | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const localScreenRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());

  const updateLocalStream = useCallback((next: MediaStream | null) => {
    localStreamRef.current = next;
    setLocalStream(next);
  }, []);

  const stopTracks = (stream: MediaStream | null) => {
    if (!stream) return;
    stream.getTracks().forEach((t) => t.stop());
  };

  // Helper to attach/rebuild LiveKit remote tracks cleanly
  const syncLiveKitRemotes = useCallback((room: Room) => {
    const tiles: RemoteMediaTile[] = [];
    room.remoteParticipants.forEach((p: RemoteParticipant) => {
      let camStream: MediaStream | null = null;
      let screenStream: MediaStream | null = null;
      let audioStream: MediaStream | null = null;
      let role = 'student';
      try {
        if (p.metadata) {
          const parsed = JSON.parse(p.metadata);
          if (parsed.role) role = parsed.role;
        }
      } catch {
        role = 'student';
      }

      p.trackPublications.forEach((pub) => {
        const track = pub.track as RemoteTrack | undefined;
        if (!track || !track.mediaStreamTrack) return;
        if (pub.source === Track.Source.ScreenShare) {
          screenStream = new MediaStream([track.mediaStreamTrack]);
        } else if (pub.source === Track.Source.Camera) {
          camStream = new MediaStream([track.mediaStreamTrack]);
        } else if (pub.source === Track.Source.Microphone) {
          audioStream = new MediaStream([track.mediaStreamTrack]);
        }
      });

      tiles.push({
        participantId: p.identity,
        userName: p.name || p.identity,
        role,
        cameraStream: camStream,
        screenStream,
        audioStream,
        connectionQuality: mapLiveKitQuality(p.connectionQuality),
      });
    });
    setRemoteTiles(tiles);
  }, []);

  // Engine A: LiveKit SFU with Simulcast & Adaptive Bitrate
  useEffect(() => {
    if (mode !== 'livekit' || !livekitUrl || !livekitToken) return;

    let cancelled = false;
    const lkRoom = new Room({
      adaptiveStream: true,
      dynacast: true,
      publishDefaults: {
        simulcast: true,
        videoSimulcastLayers: [VideoPresets.h180, VideoPresets.h360, VideoPresets.h720],
      },
    });
    lkRoomRef.current = lkRoom;

    const handleSync = () => {
      if (!cancelled) syncLiveKitRemotes(lkRoom);
    };

    lkRoom
      .on(RoomEvent.TrackSubscribed, handleSync)
      .on(RoomEvent.TrackUnsubscribed, handleSync)
      .on(RoomEvent.ParticipantConnected, handleSync)
      .on(RoomEvent.ParticipantDisconnected, handleSync)
      .on(RoomEvent.ConnectionQualityChanged, (quality, participant) => {
        if (participant.isLocal) {
          const mapped = mapLiveKitQuality(quality);
          setLocalQuality(mapped);
          onQualityChange?.(mapped);
        } else {
          handleSync();
        }
      });

    (async () => {
      try {
        await lkRoom.connect(livekitUrl, livekitToken);
        if (cancelled) return;

        if (initialMicEnabled) {
          await lkRoom.localParticipant.setMicrophoneEnabled(true, {
            deviceId: selectedAudioDeviceId || undefined,
          });
        }
        if (initialCamEnabled) {
          await lkRoom.localParticipant.setCameraEnabled(true, {
            deviceId: selectedVideoDeviceId || undefined,
          });
        }

        const camPub = lkRoom.localParticipant.getTrackPublication(Track.Source.Camera);
        if (camPub?.track?.mediaStreamTrack) {
          updateLocalStream(new MediaStream([camPub.track.mediaStreamTrack]));
        }
        onMediaStateChange?.({
          isMicEnabled: initialMicEnabled,
          isCamEnabled: initialCamEnabled,
        });
        handleSync();
      } catch (err: any) {
        if (!cancelled) {
          setMediaError(err?.message || 'تعذر الاتصال بخادم البث SFU');
        }
      }
    })();

    return () => {
      cancelled = true;
      lkRoom.removeAllListeners();
      lkRoom.disconnect();
      lkRoomRef.current = null;
    };
  }, [
    mode,
    livekitUrl,
    livekitToken,
    initialCamEnabled,
    initialMicEnabled,
    selectedAudioDeviceId,
    selectedVideoDeviceId,
    syncLiveKitRemotes,
    updateLocalStream,
    onMediaStateChange,
    onQualityChange,
  ]);

  // Engine B: Real WebRTC P2P Mesh via Socket.IO when LiveKit server URL isn't configured
  useEffect(() => {
    if (mode !== 'webrtc-p2p') return;
    let active = true;

    const initLocalDevices = async () => {
      if (!initialCamEnabled && !initialMicEnabled) {
        updateLocalStream(null);
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        setMediaError('المتصفح الحالي لا يدعم الوصول للكاميرا والميكروفون');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: initialMicEnabled
            ? {
                deviceId: selectedAudioDeviceId ? { exact: selectedAudioDeviceId } : undefined,
                echoCancellation: true,
                noiseSuppression: true,
              }
            : false,
          video: initialCamEnabled
            ? {
                deviceId: selectedVideoDeviceId ? { exact: selectedVideoDeviceId } : undefined,
                width: { ideal: 1280 },
                height: { ideal: 720 },
              }
            : false,
        });
        if (!active) {
          stopTracks(stream);
          return;
        }
        updateLocalStream(stream);
        setIsMicEnabled(stream.getAudioTracks().some((t) => t.enabled));
        setIsCamEnabled(stream.getVideoTracks().some((t) => t.enabled));
        onMediaStateChange?.({
          isMicEnabled: stream.getAudioTracks().some((t) => t.enabled),
          isCamEnabled: stream.getVideoTracks().some((t) => t.enabled),
        });
      } catch (err: any) {
        if (active) {
          setIsCamEnabled(false);
          setIsMicEnabled(false);
          setMediaError(
            err?.name === 'NotAllowedError'
              ? 'تم رفض إذن الكاميرا/الميكروفون من المتصفح (يمكنك التفعيل من إعدادات الموقع)'
              : 'لم يتم العثور على كاميرا أو ميكروفون متصل، يمكنك المتابعة كمستمع'
          );
        }
      }
    };

    initLocalDevices();

    return () => {
      active = false;
      stopTracks(localStreamRef.current);
      stopTracks(localScreenRef.current);
      updateLocalStream(null);
    };
  }, [
    mode,
    initialCamEnabled,
    initialMicEnabled,
    selectedAudioDeviceId,
    selectedVideoDeviceId,
    updateLocalStream,
  ]);

  // WebRTC Peer Connection Signaling over Socket.IO in webrtc-p2p mode
  useEffect(() => {
    if (mode !== 'webrtc-p2p' || !socket) return;

    const rtcConfig: RTCConfiguration = {
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    };

    const createPeer = (targetSocketId: string, userName: string, role: string) => {
      const existing = peerConnectionsRef.current.get(targetSocketId);
      if (existing) return existing;

      const pc = new RTCPeerConnection(rtcConfig);
      peerConnectionsRef.current.set(targetSocketId, pc);

      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => {
          pc.addTrack(track, localStreamRef.current!);
        });
      }
      if (localScreenRef.current) {
        localScreenRef.current.getTracks().forEach((track) => {
          pc.addTrack(track, localScreenRef.current!);
        });
      }

      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          socket.emit('webrtc:ice_candidate', {
            targetSocketId,
            candidate: ev.candidate.toJSON(),
          });
        }
      };

      pc.ontrack = (ev) => {
        const incomingStream = ev.streams?.[0] || new MediaStream([ev.track]);
        setRemoteTiles((prev) => {
          const found = prev.find((t) => t.participantId === targetSocketId);
          if (found) {
            return prev.map((t) =>
              t.participantId === targetSocketId
                ? { ...t, cameraStream: incomingStream }
                : t
            );
          }
          return [
            ...prev,
            {
              participantId: targetSocketId,
              userName,
              role,
              cameraStream: incomingStream,
              screenStream: null,
              audioStream: null,
              connectionQuality: 'good',
            },
          ];
        });
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
          peerConnectionsRef.current.delete(targetSocketId);
          setRemoteTiles((prev) => prev.filter((t) => t.participantId !== targetSocketId));
        }
      };

      return pc;
    };

    const onPeerReady = async (data: {
      fromSocketId: string;
      userName: string;
      role: string;
    }) => {
      if (data.fromSocketId === selfSocketId) return;
      const pc = createPeer(data.fromSocketId, data.userName, data.role);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.emit('webrtc:offer', {
        targetSocketId: data.fromSocketId,
        sdp: offer,
      });
    };

    const onOffer = async (data: {
      fromSocketId: string;
      userName: string;
      role: string;
      sdp: RTCSessionDescriptionInit;
    }) => {
      const pc = createPeer(data.fromSocketId, data.userName, data.role);
      await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit('webrtc:answer', {
        targetSocketId: data.fromSocketId,
        sdp: answer,
      });
    };

    const onAnswer = async (data: {
      fromSocketId: string;
      sdp: RTCSessionDescriptionInit;
    }) => {
      const pc = peerConnectionsRef.current.get(data.fromSocketId);
      if (pc && pc.signalingState === 'have-local-offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
      }
    };

    const onIce = async (data: {
      fromSocketId: string;
      candidate: RTCIceCandidateInit;
    }) => {
      const pc = peerConnectionsRef.current.get(data.fromSocketId);
      if (pc && data.candidate) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
        } catch {
          // Ignore stale ICE candidates
        }
      }
    };

    socket.on('webrtc:peer_ready', onPeerReady);
    socket.on('webrtc:offer', onOffer);
    socket.on('webrtc:answer', onAnswer);
    socket.on('webrtc:ice_candidate', onIce);
    socket.emit('webrtc:peer_ready');

    // Measure RTT stats periodically for Connection Quality indicator
    const qualityTimer = window.setInterval(async () => {
      const navConn = (navigator as any).connection;
      let computed: ConnectionQualityLevel = navigator.onLine ? 'excellent' : 'lost';
      if (navConn?.rtt > 350 || navConn?.effectiveType === '2g') {
        computed = 'poor';
      } else if (navConn?.rtt > 150 || navConn?.effectiveType === '3g') {
        computed = 'good';
      }
      for (const pc of peerConnectionsRef.current.values()) {
        try {
          const stats = await pc.getStats();
          stats.forEach((report) => {
            if (report.type === 'candidate-pair' && report.state === 'succeeded') {
              const rttMs = (report.currentRoundTripTime || 0) * 1000;
              if (rttMs > 350) computed = 'poor';
              else if (rttMs > 140) computed = 'good';
              else computed = 'excellent';
            }
          });
        } catch {
          // Ignore stats error
        }
      }
      setLocalQuality(computed);
      onQualityChange?.(computed);
    }, 5000);

    return () => {
      window.clearInterval(qualityTimer);
      socket.off('webrtc:peer_ready', onPeerReady);
      socket.off('webrtc:offer', onOffer);
      socket.off('webrtc:answer', onAnswer);
      socket.off('webrtc:ice_candidate', onIce);
      peerConnectionsRef.current.forEach((pc) => pc.close());
      peerConnectionsRef.current.clear();
    };
  }, [mode, socket, selfSocketId, onQualityChange]);

  const toggleMic = useCallback(async () => {
    const next = !isMicEnabled;
    setMediaError(null);

    if (mode === 'livekit' && lkRoomRef.current) {
      await lkRoomRef.current.localParticipant.setMicrophoneEnabled(next, {
        deviceId: selectedAudioDeviceId || undefined,
      });
      setIsMicEnabled(next);
      onMediaStateChange?.({ isMicEnabled: next });
      return;
    }

    if (!localStreamRef.current || localStreamRef.current.getAudioTracks().length === 0) {
      if (next && navigator.mediaDevices?.getUserMedia) {
        try {
          const audioStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              deviceId: selectedAudioDeviceId ? { exact: selectedAudioDeviceId } : undefined,
              echoCancellation: true,
              noiseSuppression: true,
            },
          });
          const audioTrack = audioStream.getAudioTracks()[0];
          const combined = localStreamRef.current
            ? new MediaStream([...localStreamRef.current.getTracks(), audioTrack])
            : audioStream;
          updateLocalStream(combined);
          peerConnectionsRef.current.forEach((pc) => pc.addTrack(audioTrack, combined));
          setIsMicEnabled(true);
          onMediaStateChange?.({ isMicEnabled: true });
        } catch {
          setMediaError('تعذر تشغيل الميكروفون — تحقق من أذونات المتصفح');
        }
      }
      return;
    }

    localStreamRef.current.getAudioTracks().forEach((t) => {
      t.enabled = next;
    });
    setIsMicEnabled(next);
    onMediaStateChange?.({ isMicEnabled: next });
  }, [isMicEnabled, mode, selectedAudioDeviceId, updateLocalStream, onMediaStateChange]);

  const toggleCam = useCallback(async () => {
    const next = !isCamEnabled;
    setMediaError(null);

    if (mode === 'livekit' && lkRoomRef.current) {
      await lkRoomRef.current.localParticipant.setCameraEnabled(next, {
        deviceId: selectedVideoDeviceId || undefined,
      });
      const camPub = lkRoomRef.current.localParticipant.getTrackPublication(
        Track.Source.Camera
      );
      if (next && camPub?.track?.mediaStreamTrack) {
        updateLocalStream(new MediaStream([camPub.track.mediaStreamTrack]));
      } else if (!next) {
        updateLocalStream(null);
      }
      setIsCamEnabled(next);
      onMediaStateChange?.({ isCamEnabled: next });
      return;
    }

    if (!localStreamRef.current || localStreamRef.current.getVideoTracks().length === 0) {
      if (next && navigator.mediaDevices?.getUserMedia) {
        try {
          const vidStream = await navigator.mediaDevices.getUserMedia({
            video: {
              deviceId: selectedVideoDeviceId ? { exact: selectedVideoDeviceId } : undefined,
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
          });
          const vidTrack = vidStream.getVideoTracks()[0];
          const combined = localStreamRef.current
            ? new MediaStream([...localStreamRef.current.getTracks(), vidTrack])
            : vidStream;
          updateLocalStream(combined);
          peerConnectionsRef.current.forEach((pc) => pc.addTrack(vidTrack, combined));
          setIsCamEnabled(true);
          onMediaStateChange?.({ isCamEnabled: true });
        } catch {
          setMediaError('تعذر فتح الكاميرا — تأكد من توصيل الكاميرا ومنح الإذن');
        }
      }
      return;
    }

    localStreamRef.current.getVideoTracks().forEach((t) => {
      t.enabled = next;
    });
    setIsCamEnabled(next);
    onMediaStateChange?.({ isCamEnabled: next });
  }, [isCamEnabled, mode, selectedVideoDeviceId, updateLocalStream, onMediaStateChange]);

  const toggleScreenShare = useCallback(async () => {
    if (userRole === 'student') return;
    setMediaError(null);
    const next = !isScreenSharing;

    if (mode === 'livekit' && lkRoomRef.current) {
      try {
        await lkRoomRef.current.localParticipant.setScreenShareEnabled(next);
        const pub = lkRoomRef.current.localParticipant.getTrackPublication(
          Track.Source.ScreenShare
        );
        if (next && pub?.track?.mediaStreamTrack) {
          const s = new MediaStream([pub.track.mediaStreamTrack]);
          localScreenRef.current = s;
          setLocalScreenStream(s);
        } else {
          localScreenRef.current = null;
          setLocalScreenStream(null);
        }
        setIsScreenSharing(next);
        onMediaStateChange?.({ isScreenSharing: next });
      } catch {
        setMediaError('تم إلغاء مشاركة الشاشة');
      }
      return;
    }

    if (!next) {
      stopTracks(localScreenRef.current);
      localScreenRef.current = null;
      setLocalScreenStream(null);
      setIsScreenSharing(false);
      onMediaStateChange?.({ isScreenSharing: false });
      return;
    }

    if (!navigator.mediaDevices?.getDisplayMedia) {
      setMediaError('المتصفح الحالي لا يدعم مشاركة الشاشة');
      return;
    }

    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true,
      });
      localScreenRef.current = displayStream;
      setLocalScreenStream(displayStream);
      setIsScreenSharing(true);
      onMediaStateChange?.({ isScreenSharing: true });

      const videoTrack = displayStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.onended = () => {
          localScreenRef.current = null;
          setLocalScreenStream(null);
          setIsScreenSharing(false);
          onMediaStateChange?.({ isScreenSharing: false });
        };
      }
    } catch {
      setMediaError('تم إلغاء مشاركة الشاشة من قِبل المستخدم');
    }
  }, [isScreenSharing, mode, userRole, onMediaStateChange]);

  const leaveMedia = useCallback(() => {
    stopTracks(localStreamRef.current);
    stopTracks(localScreenRef.current);
    updateLocalStream(null);
    localScreenRef.current = null;
    setLocalScreenStream(null);
    setIsMicEnabled(false);
    setIsCamEnabled(false);
    setIsScreenSharing(false);
    peerConnectionsRef.current.forEach((pc) => pc.close());
    peerConnectionsRef.current.clear();
    if (lkRoomRef.current) {
      lkRoomRef.current.disconnect();
      lkRoomRef.current = null;
    }
  }, [updateLocalStream]);

  return {
    localStream,
    localScreenStream,
    remoteTiles,
    isMicEnabled,
    isCamEnabled,
    isScreenSharing,
    localQuality,
    mediaError,
    toggleMic,
    toggleCam,
    toggleScreenShare,
    leaveMedia,
  };
}
