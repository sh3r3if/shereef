import React, { useState, useEffect } from 'react';
import {
  INITIAL_SCHOOL_SETTINGS,
  INITIAL_INVOICES,
} from './data/mockData';
import {
  Language,
  SchoolSettings,
  CurrentUser,
  Lesson,
  Teacher,
  Student,
  Quiz,
  QuizAttempt,
  Certificate,
  ParentConversation,
  TimetableSlot,
  TuitionInvoice,
  AppNotification,
  AssistantAdmin,
  SystemAuditLog,
  FaqItem,
  InquiryItem,
  Assignment,
  AssignmentSubmission,
  ChatDirectoryUser,
  LessonRating,
} from './types';
import { Bell, ShieldAlert, X, Sparkles, Wifi, CheckCircle2, QrCode } from 'lucide-react';
import { realtimeSync } from './services/realtimeSync';
import {
  getAllowedTabsForRole,
  getAuthHeaders,
  getDefaultTabForRole,
  isAdminStaffRole,
  isConversationVisibleForUser,
  isNotificationVisibleForRole,
  isParentRole,
  isStudentRole,
  isTeacherRole,
} from './utils/rbac';

// Components
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { PublicWebsite } from './components/PublicWebsite';
import { AuthModal } from './components/AuthModal';
import { AdminDashboard } from './components/AdminDashboard';
import { LessonsManager } from './components/LessonsManager';
import { AssignmentsManager } from './components/AssignmentsManager';
import { TeachersDirectory } from './components/TeachersDirectory';
import { StudentsManager } from './components/StudentsManager';
import { WeeklyTriage } from './components/WeeklyTriage';
import { InteractiveWhiteboard } from './components/InteractiveWhiteboard';
import { QuizzesSystem } from './components/QuizzesSystem';
import { CertificatesCenter } from './components/CertificatesCenter';
import { ParentCommunication } from './components/ParentCommunication';
import { TimetableSchedule } from './components/TimetableSchedule';
import { PaymentCenter } from './components/PaymentCenter';
import { FaqNotifications } from './components/FaqNotifications';
import { SchoolCustomizer } from './components/SchoolCustomizer';
import { MobileSimulatorModal } from './components/MobileSimulatorModal';
import { MembersAndRolesManager } from './components/MembersAndRolesManager';
import { BackupsAndExportManager } from './components/BackupsAndExportManager';
import { OfflineIndicator } from './components/PWAInstallButton';
import { ScreenProtectionGuard } from './components/ScreenProtectionGuard';
import { FlashcardsAndCompetitionsHub } from './components/FlashcardsAndCompetitionsHub';
import { ContentSecurityAndCodesHub } from './components/ContentSecurityAndCodesHub';
import { ParentReportsAndAttendanceHub } from './components/ParentReportsAndAttendanceHub';
import { StudentStudyAndPomodoroHub } from './components/StudentStudyAndPomodoroHub';
import { LiveClassroomModule } from './classroom/LiveClassroomModule';
import { CurriculumGuidedPathHub } from './components/CurriculumGuidedPathHub';
import { BookletsStoreHub } from './components/BookletsStoreHub';

export default function App() {
  const [language, setLanguage] = useState<Language>('ar');
  const [isDark, setIsDark] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [isMobileSimOpen, setIsMobileSimOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Toggle between Public Platform Website and Admin Dashboard / Portals
  const [isPublicView, setIsPublicView] = useState<boolean>(true);

  // User Authentication & Roles State - Super Admin Mo-NewFolder
  const [currentUser, setCurrentUser] = useState<CurrentUser>({
    id: 'usr-super-admin',
    name: 'Mo-NewFolder (الأدمن العام)',
    nameEn: 'Mo-NewFolder (Super Admin)',
    username: 'Mo-NewFolder',
    email: 'Mo-NewFolder@nawabegh.edu',
    role: 'admin',
    isSuperAdmin: true,
    permissions: ['*'],
    avatar: '/assets/images/certificate_crest_gold_1794403367581.jpg',
  });

  // App Data State (Shared in real time across the public website & dashboard)
  const [settings, setSettings] = useState<SchoolSettings>(INITIAL_SCHOOL_SETTINGS);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [assignmentSubmissions, setAssignmentSubmissions] = useState<AssignmentSubmission[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [conversations, setConversations] = useState<ParentConversation[]>([]);
  const [timetableSlots, setTimetableSlots] = useState<TimetableSlot[]>([]);
  const [invoices, setInvoices] = useState<TuitionInvoice[]>(INITIAL_INVOICES);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [faqs, setFaqs] = useState<FaqItem[]>([]);
  const [inquiries, setInquiries] = useState<InquiryItem[]>([]);
  const [assistants, setAssistants] = useState<AssistantAdmin[]>([]);
  const [directoryUsers, setDirectoryUsers] = useState<ChatDirectoryUser[]>([]);
  const [pendingUsersCount, setPendingUsersCount] = useState<number>(0);
  const [auditLogs, setAuditLogs] = useState<SystemAuditLog[]>([]);
  const [lessonRatings, setLessonRatings] = useState<LessonRating[]>([]);
  const [liveAdminToast, setLiveAdminToast] = useState<{ title: string; details: string } | null>(null);
  const [qrScannedCertData, setQrScannedCertData] = useState<{
    loading: boolean;
    code: string;
    result: any | null;
  } | null>(null);
  const [deepLinkedClassroom, setDeepLinkedClassroom] = useState<{
    roomCode: string;
    inviteToken: string | null;
  } | null>(null);
  const currentUserRef = React.useRef<CurrentUser>(currentUser);

  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);

  // Handle ?verifyCert=SERIAL from scanning a Certificate QR Code with a phone camera
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const certCode = params.get('verifyCert');
    if (certCode && certCode.trim()) {
      const cleanCode = certCode.trim();
      setQrScannedCertData({ loading: true, code: cleanCode, result: null });
      fetch(`/api/certificates/verify/${encodeURIComponent(cleanCode)}`)
        .then((r) => r.json())
        .then((data) => {
          setQrScannedCertData({ loading: false, code: cleanCode, result: data });
        })
        .catch(() => {
          setQrScannedCertData({
            loading: false,
            code: cleanCode,
            result: { verified: false, message: 'تعذر التحقق من قاعدة البيانات حالياً' },
          });
        });
    }

    const liveRoomCode = params.get('liveRoom');
    if (liveRoomCode && liveRoomCode.trim()) {
      setDeepLinkedClassroom({
        roomCode: liveRoomCode.trim(),
        inviteToken: params.get('invite'),
      });
      setIsPublicView(false);
      setActiveTab('live_classroom');
    }
  }, []);

  // Sync RTL / LTR with language
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  // Sync dark theme class on document element
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const mapMemberToAssistant = (m: any): AssistantAdmin => {
    let parsedPerms: string[] = [];
    try {
      parsedPerms =
        typeof m.permissions === 'string'
          ? JSON.parse(m.permissions || '[]')
          : Array.isArray(m.permissions)
          ? m.permissions
          : [];
    } catch {
      parsedPerms = [];
    }
    return {
      id: m.uid || `usr-${m.id}`,
      dbId: typeof m.id === 'number' ? m.id : undefined,
      name: m.displayName || m.username || m.email,
      nameEn: m.displayNameEn || m.displayName || m.email,
      username: m.username || (m.email ? m.email.split('@')[0] : ''),
      email: m.email || '',
      phone: m.phone || '',
      roleTitle: m.roleTitle || (m.role === 'admin' ? 'مدير النظام' : 'مشرف إداري'),
      permissions: parsedPerms,
      createdAt: m.createdAt ? String(m.createdAt).split('T')[0] : new Date().toISOString().split('T')[0],
      isActive: m.isActive !== false,
      avatar: m.avatar || undefined,
    };
  };

  const fetchDatabaseState = async () => {
    try {
      const [
        stuRes,
        tchRes,
        lesRes,
        asgRes,
        subRes,
        qzRes,
        attRes,
        certRes,
        convRes,
        ttRes,
        invRes,
        notifRes,
        faqRes,
        inqRes,
        memRes,
        auditRes,
        setRes,
        ratRes,
      ] = await Promise.all([
        fetch('/api/students'),
        fetch('/api/teachers'),
        fetch('/api/lessons'),
        fetch('/api/assignments'),
        fetch('/api/assignment-submissions'),
        fetch('/api/quizzes'),
        fetch('/api/quiz-attempts'),
        fetch('/api/certificates'),
        fetch('/api/parent-conversations'),
        fetch('/api/timetable'),
        fetch('/api/invoices'),
        fetch('/api/notifications'),
        fetch('/api/faqs'),
        fetch('/api/inquiries'),
        fetch('/api/members'),
        fetch('/api/audit-logs'),
        fetch('/api/school-settings'),
        fetch('/api/lesson-ratings'),
      ]);

      if (stuRes.ok) {
        const stuData = await stuRes.json();
        if (Array.isArray(stuData)) setStudents(stuData);
      }
      if (asgRes.ok) {
        const asgData = await asgRes.json();
        if (Array.isArray(asgData)) setAssignments(asgData);
      }
      if (subRes.ok) {
        const subData = await subRes.json();
        if (Array.isArray(subData)) setAssignmentSubmissions(subData);
      }
      if (tchRes.ok) {
        const tchData = await tchRes.json();
        if (Array.isArray(tchData)) {
          setTeachers(
            tchData.map((t: any) => ({
              ...t,
              grades: typeof t.grades === 'string' ? JSON.parse(t.grades || '[]') : t.grades || [],
              rating: Number(t.rating) || 4.9,
            }))
          );
        }
      }
      if (lesRes.ok) {
        const lesData = await lesRes.json();
        if (Array.isArray(lesData)) {
          setLessons(
            lesData.map((l: any) => ({
              ...l,
              infographicData:
                typeof l.infographicData === 'string' && l.infographicData.trim()
                  ? JSON.parse(l.infographicData)
                  : l.infographicData || undefined,
            }))
          );
        }
      }
      if (qzRes.ok) {
        const qzData = await qzRes.json();
        if (Array.isArray(qzData)) {
          setQuizzes(
            qzData.map((q: any) => ({
              ...q,
              questions:
                typeof q.questions === 'string'
                  ? JSON.parse(q.questions || '[]')
                  : Array.isArray(q.questions)
                  ? q.questions
                  : [],
            }))
          );
        }
      }
      if (attRes.ok) {
        const attData = await attRes.json();
        if (Array.isArray(attData)) setQuizAttempts(attData);
      }
      if (certRes.ok) {
        const certData = await certRes.json();
        if (Array.isArray(certData)) setCertificates(certData);
      }
      if (convRes.ok) {
        const convData = await convRes.json();
        if (Array.isArray(convData)) setConversations(convData);
      }
      if (ttRes.ok) {
        const ttData = await ttRes.json();
        if (Array.isArray(ttData)) setTimetableSlots(ttData);
      }
      if (invRes.ok) {
        const invData = await invRes.json();
        if (Array.isArray(invData)) setInvoices(invData);
      }
      if (notifRes.ok) {
        const notifData = await notifRes.json();
        if (Array.isArray(notifData)) setNotifications(notifData);
      }
      if (faqRes.ok) {
        const faqData = await faqRes.json();
        if (Array.isArray(faqData)) setFaqs(faqData);
      }
      if (inqRes.ok) {
        const inqData = await inqRes.json();
        if (Array.isArray(inqData)) setInquiries(inqData);
      }
      if (memRes.ok) {
        const memData = await memRes.json();
        if (Array.isArray(memData)) {
          setPendingUsersCount(memData.filter((m: any) => m.isActive === false).length);
          setDirectoryUsers(
            memData.map((m: any) => ({
              id: m.uid || `usr-${m.id}`,
              uid: m.uid,
              name: m.displayName || m.username || m.email || 'عضو',
              role: m.role,
              roleTitle: m.roleTitle || undefined,
              email: m.email || undefined,
              avatar: m.avatar || undefined,
            }))
          );
          const adminMembers = memData
            .filter(
              (m: any) =>
                (m.role === 'admin' || m.role === 'supervisor' || m.role === 'secretary') &&
                m.uid !== 'usr-super-admin'
            )
            .map(mapMemberToAssistant);
          setAssistants(adminMembers);
        }
      }
      if (auditRes.ok) {
        const auditData = await auditRes.json();
        if (Array.isArray(auditData)) {
          setAuditLogs(
            auditData.filter((row: any) => {
              const combined = `${row.entityName || ''} ${row.performedBy || ''} ${row.details || ''} ${row.actionAr || ''}`.toLowerCase();
              const isSuperAdminTarget =
                combined.includes('mo-newfolder') ||
                combined.includes('الأدمن العام') ||
                combined.includes('المدير العام');
              const isPenalty =
                row.action === 'account_delete_piracy' ||
                row.action === 'screen_record_warning' ||
                combined.includes('ممنوع السرقه') ||
                combined.includes('حذف حساب نهائياً لتكرار تصوير');
              return !(isSuperAdminTarget && isPenalty);
            })
          );
        }
      }
      if (setRes.ok) {
        const setData = await setRes.json();
        if (setData && setData.schoolName) {
          const isLegacyName =
            setData.schoolName === 'تعلّمنوفا' ||
            setData.schoolName === 'تعلمنوفا' ||
            setData.schoolName === 'أكاديمية نوابغ التعليمية';
          setSettings({
            ...setData,
            schoolName: isLegacyName ? 'منصة الشريف' : setData.schoolName,
            schoolNameEn:
              setData.schoolNameEn === 'LearnNova Edu Platform' ||
              setData.schoolNameEn === 'Nawabegh Educational Academy'
                ? 'Al-Sharif Edu Platform'
                : setData.schoolNameEn,
          });
        }
      }
      if (ratRes.ok) {
        const ratData = await ratRes.json();
        if (Array.isArray(ratData)) setLessonRatings(ratData);
      }
    } catch (err) {
      console.warn('Initial live DB fetch error:', err);
    }
  };

  // Load live data from Cloud SQL backend
  useEffect(() => {
    fetchDatabaseState();
  }, []);

  // Metrics
  const weakStudentsCount = students.filter(
    (s) => s.status === 'weak' || s.overallScore < 60 || s.attendanceRate < 70
  ).length;

  const unreadChatsCount = React.useMemo(
    () =>
      conversations
        .filter((c) => isConversationVisibleForUser(c, currentUser, teachers, students))
        .reduce((acc, c) => acc + c.unreadCount, 0),
    [conversations, currentUser, teachers, students]
  );
  const visibleNotifications = React.useMemo(
    () => notifications.filter((n) => isNotificationVisibleForRole(n, currentUser.role)),
    [notifications, currentUser.role]
  );
  const unreadNotifsCount = visibleNotifications.filter((n) => !n.read).length;

  // Enforce strict RBAC tab boundaries whenever user or activeTab changes
  useEffect(() => {
    if (isPublicView) return;
    const isStrictRole =
      isStudentRole(currentUser.role) ||
      isParentRole(currentUser.role) ||
      isTeacherRole(currentUser.role) ||
      currentUser.role === 'visitor';
    if (!isStrictRole) return;
    const allowed = getAllowedTabsForRole(currentUser);
    if (!allowed.includes(activeTab)) {
      setActiveTab(getDefaultTabForRole(currentUser));
    }
  }, [currentUser, activeTab, isPublicView]);

  // Handle Login & Role Switch
  const handleLogin = (user: CurrentUser) => {
    setCurrentUser(user);
    if (user.role === 'visitor') {
      setIsPublicView(true);
    } else {
      setIsPublicView(false);
      setActiveTab(getDefaultTabForRole(user));
    }
  };

  const handleLogout = () => {
    setCurrentUser({
      id: 'usr-visitor',
      name: 'زائر المنصة',
      nameEn: 'Platform Guest',
      email: 'guest@nawabegh.edu',
      role: 'visitor',
    });
    setIsPublicView(true);
  };

  // Real-time Audit Logger persisted to Cloud SQL + Super Admin Toast
  const logSystemChange = (actionAr: string, entityType: string, entityName: string, details: string) => {
    const timestampLabel = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    const newLog: SystemAuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      action: entityType,
      actionAr,
      entityType,
      entityName,
      performedBy: currentUser.username ? `${currentUser.username} (${currentUser.name})` : currentUser.name,
      timestamp: timestampLabel,
      details,
      severity: 'info',
    };

    setAuditLogs((prev) => [newLog, ...prev]);
    fetch('/api/audit-logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newLog),
    }).catch(console.warn);

    // Flash real-time toast
    setLiveAdminToast({
      title: isAdminStaffRole(currentUser.role)
        ? `إشعار فوري للإدارة العامة: ${actionAr}`
        : actionAr,
      details,
    });
    setTimeout(() => setLiveAdminToast(null), 5000);
  };

  // Handlers for Lessons CRUD (synchronized with state & audit log; DB call handled directly by LessonsManager)
  const handleAddLesson = (newLesson: any) => {
    const lesson: Lesson = {
      ...newLesson,
      id: newLesson.id || `les-${Date.now()}`,
      createdAt: newLesson.createdAt || new Date().toISOString().split('T')[0],
      viewsCount: newLesson.viewsCount ?? 1,
      likesCount: newLesson.likesCount ?? 0,
    };
    setLessons((prev) => {
      if (prev.some((l) => l.id === lesson.id)) {
        return prev.map((l) => (l.id === lesson.id ? lesson : l));
      }
      return [lesson, ...prev];
    });
    logSystemChange('إضافة ونشر درس جديد', 'lesson', lesson.title, `تمت إضافة الدرس بنجاح بصيغة (${lesson.format}) بواسطة ${lesson.teacherName}`);
  };

  const handleUpdateLesson = (updatedLesson: Lesson) => {
    setLessons((prev) => prev.map((l) => (l.id === updatedLesson.id ? updatedLesson : l)));
    logSystemChange('تعديل بيانات درس', 'lesson', updatedLesson.title, 'تم حفظ التعديلات وتحديث محتوى الدرس');
  };

  const handleDeleteLesson = (id: string) => {
    setLessons((prev) => prev.filter((l) => l.id !== id));
  };

  // Handlers for Teachers CRUD (synchronized with state & audit log; DB call handled directly by TeachersDirectory)
  const handleAddTeacher = (
    newTeacher: Teacher | Omit<Teacher, 'id' | 'rating' | 'totalStudents' | 'activeLessonsCount' | 'joinedDate'>
  ) => {
    const existing = newTeacher as Teacher;
    const teacher: Teacher = {
      ...newTeacher,
      id: existing.id || `tch-${Date.now()}`,
      rating: existing.rating ?? 5.0,
      totalStudents: existing.totalStudents ?? 0,
      activeLessonsCount: existing.activeLessonsCount ?? 0,
      joinedDate: existing.joinedDate || new Date().toISOString().split('T')[0],
    };
    setTeachers((prev) => {
      if (prev.some((t) => t.id === teacher.id)) {
        return prev.map((t) => (t.id === teacher.id ? teacher : t));
      }
      return [teacher, ...prev];
    });
    logSystemChange('تسجيل معلم جديد', 'teacher', teacher.name, `تم تعيين المعلم في تخصص ${teacher.specialty}`);
  };

  const handleUpdateTeacher = (updatedTeacher: Teacher) => {
    setTeachers((prev) => prev.map((t) => (t.id === updatedTeacher.id ? updatedTeacher : t)));
    logSystemChange('تعديل ملف معلم', 'teacher', updatedTeacher.name, 'تم تحديث بيانات المعلم والتخصصات');
  };

  const handleDeleteTeacher = (id: string) => {
    const tch = teachers.find((t) => t.id === id);
    setTeachers((prev) => prev.filter((t) => t.id !== id));
    logSystemChange('حذف معلم', 'teacher', tch?.name || id, 'تم إلغاء ملف المعلم من الدليل');
  };

  // Handlers for Students CRUD (synchronized with state, WebSockets & audit log; DB call handled directly by StudentsManager)
  const handleAddStudent = (newStudent: Student | Omit<Student, 'id' | 'registeredDate'>) => {
    const existing = newStudent as Student;
    const student: Student = {
      ...newStudent,
      id: existing.id || `stu-${Date.now()}`,
      registeredDate: existing.registeredDate || new Date().toISOString().split('T')[0],
    };
    setStudents((prev) => {
      if (prev.some((s) => s.id === student.id)) {
        return prev.map((s) => (s.id === student.id ? student : s));
      }
      return [student, ...prev];
    });
    logSystemChange('تسجيل طالب جديد', 'student', student.name, `تم قيد الطالب بنظام (${student.type === 'online' ? 'أونلاين' : 'سنتر حضوري'})`);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents((prev) => prev.map((s) => (s.id === updatedStudent.id ? updatedStudent : s)));
    logSystemChange('تحديث بيانات طالب', 'student', updatedStudent.name, 'تم رصد وتحديث درجات وحضور الطالب');
    realtimeSync.sendStudentFullUpdate(
      updatedStudent,
      currentUser.username ? `${currentUser.username} (${currentUser.name})` : currentUser.name
    );
  };

  // WebSocket Real-time Listener for synchronized grades & student updates across devices
  useEffect(() => {
    const unsubGrade = realtimeSync.on('grade:update', (data: any) => {
      if (data && data.studentId) {
        setStudents((prev) =>
          prev.map((s) =>
            s.id === data.studentId
              ? {
                  ...s,
                  overallScore: data.overallScore,
                  status:
                    data.overallScore >= 95 ? 'top' : data.overallScore < 60 ? 'weak' : 'regular',
                }
              : s
          )
        );

        setLiveAdminToast({
          title: `⚡ مزامنة درجات فورية عبر WebSocket: ${data.studentName || data.studentId}`,
          details: `تم تحديث النتيجة إلى ${data.overallScore}% بواسطة (${data.updatedBy}) متزامناً عبر الأجهزة.`,
        });
        setTimeout(() => setLiveAdminToast(null), 5000);
      }
    });

    const unsubStudent = realtimeSync.on('student:full_update', (data: any) => {
      if (data && data.student) {
        setStudents((prev) =>
          prev.map((s) => (s.id === data.student.id ? data.student : s))
        );

        setLiveAdminToast({
          title: `⚡ مزامنة سجل طالب لحظياً: ${data.student.name}`,
          details: `تم تحديث درجات وسجل الطالب متزامناً بين كافة الأجهزة المتصلة بواسطة (${data.updatedBy}).`,
        });
        setTimeout(() => setLiveAdminToast(null), 5000);
      }
    });

    const unsubQuizCreated = realtimeSync.on('quiz:created', (data: any) => {
      if (data?.quiz) {
        const parsed = {
          ...data.quiz,
          questions:
            typeof data.quiz.questions === 'string'
              ? JSON.parse(data.quiz.questions || '[]')
              : Array.isArray(data.quiz.questions)
              ? data.quiz.questions
              : [],
        };
        setQuizzes((prev) =>
          prev.some((q) => q.id === parsed.id) ? prev.map((q) => (q.id === parsed.id ? parsed : q)) : [parsed, ...prev]
        );
      }
    });

    const unsubQuizUpdated = realtimeSync.on('quiz:updated', (data: any) => {
      if (data?.quiz) {
        const parsed = {
          ...data.quiz,
          questions:
            typeof data.quiz.questions === 'string'
              ? JSON.parse(data.quiz.questions || '[]')
              : Array.isArray(data.quiz.questions)
              ? data.quiz.questions
              : [],
        };
        setQuizzes((prev) => prev.map((q) => (q.id === parsed.id ? parsed : q)));
      }
    });

    const unsubQuizDeleted = realtimeSync.on('quiz:deleted', (data: any) => {
      if (data?.id) {
        setQuizzes((prev) => prev.filter((q) => q.id !== data.id));
      }
    });

    const unsubLessonCreated = realtimeSync.on('lesson:created', (data: any) => {
      if (data?.lesson) {
        const parsed = {
          ...data.lesson,
          infographicData:
            typeof data.lesson.infographicData === 'string' && data.lesson.infographicData.trim()
              ? JSON.parse(data.lesson.infographicData)
              : data.lesson.infographicData || undefined,
        };
        setLessons((prev) =>
          prev.some((l) => l.id === parsed.id) ? prev.map((l) => (l.id === parsed.id ? parsed : l)) : [parsed, ...prev]
        );
      }
    });

    const unsubLessonUpdated = realtimeSync.on('lesson:updated', (data: any) => {
      if (data?.lesson) {
        const parsed = {
          ...data.lesson,
          infographicData:
            typeof data.lesson.infographicData === 'string' && data.lesson.infographicData.trim()
              ? JSON.parse(data.lesson.infographicData)
              : data.lesson.infographicData || undefined,
        };
        setLessons((prev) => prev.map((l) => (l.id === parsed.id ? parsed : l)));
      }
    });

    const unsubLessonDeleted = realtimeSync.on('lesson:deleted', (data: any) => {
      if (data?.id) {
        setLessons((prev) => prev.filter((l) => l.id !== data.id));
      }
    });

    const unsubStudentUpdated = realtimeSync.on('student:updated', (data: any) => {
      if (data?.student) {
        setStudents((prev) => prev.map((s) => (s.id === data.student.id ? data.student : s)));
      }
    });

    const unsubAttemptCreated = realtimeSync.on('quiz_attempt:created', (data: any) => {
      if (data?.attempt) {
        setQuizAttempts((prev) =>
          prev.some((a) => a.id === data.attempt.id) ? prev : [data.attempt, ...prev]
        );
      }
    });

    const unsubAttemptUpdated = realtimeSync.on('quiz_attempt:updated', (data: any) => {
      if (data?.attempt) {
        setQuizAttempts((prev) =>
          prev.map((a) => (a.id === data.attempt.id ? data.attempt : a))
        );
      }
    });

    const unsubAttemptDeleted = realtimeSync.on('quiz_attempt:deleted', (data: any) => {
      if (data?.id) {
        setQuizAttempts((prev) => prev.filter((a) => a.id !== data.id));
      }
    });

    const unsubCertCreated = realtimeSync.on('certificate:created', (data: any) => {
      if (data?.certificate) {
        setCertificates((prev) =>
          prev.some((c) => c.id === data.certificate.id)
            ? prev.map((c) => (c.id === data.certificate.id ? data.certificate : c))
            : [data.certificate, ...prev]
        );
      }
    });

    const unsubCertUpdated = realtimeSync.on('certificate:updated', (data: any) => {
      if (data?.certificate) {
        setCertificates((prev) =>
          prev.map((c) => (c.id === data.certificate.id ? data.certificate : c))
        );
      }
    });

    const unsubCertDeleted = realtimeSync.on('certificate:deleted', (data: any) => {
      if (data?.id) {
        setCertificates((prev) => prev.filter((c) => c.id !== data.id));
      }
    });

    const unsubCertsSynced = realtimeSync.on('certificates:synced', (data: any) => {
      if (Array.isArray(data?.certificates)) {
        // Re-fetch complete sorted list to stay exact with DB
        fetch('/api/certificates')
          .then((r) => (r.ok ? r.json() : null))
          .then((rows) => {
            if (Array.isArray(rows)) setCertificates(rows);
          })
          .catch(console.warn);
      }
    });

    const unsubParentConvCreated = realtimeSync.on('parent_conv:created', (data: any) => {
      if (data?.conversation) {
        setConversations((prev) =>
          prev.some((c) => c.id === data.conversation.id)
            ? prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
            : [data.conversation, ...prev]
        );
      }
    });

    const unsubParentConvUpdated = realtimeSync.on('parent_conv:updated', (data: any) => {
      if (data?.conversation) {
        setConversations((prev) =>
          prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
        );
      }
    });

    const unsubParentConvDeleted = realtimeSync.on('parent_conv:deleted', (data: any) => {
      if (data?.id) {
        setConversations((prev) => prev.filter((c) => c.id !== data.id));
      }
    });

    const unsubParentMsgEvent = realtimeSync.on('parent_msg:created', (data: any) => {
      if (data?.conversation) {
        setConversations((prev) =>
          prev.some((c) => c.id === data.conversation.id)
            ? prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
            : [data.conversation, ...prev]
        );
      }
    });

    const unsubParentMsgUpdated = realtimeSync.on('parent_msg:updated', (data: any) => {
      if (data?.conversation) {
        setConversations((prev) =>
          prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
        );
      }
    });

    const unsubParentMsgDeleted = realtimeSync.on('parent_msg:deleted', (data: any) => {
      if (data?.conversation) {
        setConversations((prev) =>
          prev.map((c) => (c.id === data.conversation.id ? data.conversation : c))
        );
      }
    });

    const unsubAssignmentCreated = realtimeSync.on('assignment:created', (data: any) => {
      if (data?.assignment) {
        setAssignments((prev) =>
          prev.some((a) => a.id === data.assignment.id)
            ? prev.map((a) => (a.id === data.assignment.id ? data.assignment : a))
            : [data.assignment, ...prev]
        );
      }
    });

    const unsubAssignmentUpdated = realtimeSync.on('assignment:updated', (data: any) => {
      if (data?.assignment) {
        setAssignments((prev) =>
          prev.map((a) => (a.id === data.assignment.id ? data.assignment : a))
        );
      }
    });

    const unsubAssignmentDeleted = realtimeSync.on('assignment:deleted', (data: any) => {
      if (data?.id) {
        setAssignments((prev) => prev.filter((a) => a.id !== data.id));
      }
    });

    const unsubSubCreated = realtimeSync.on('assignment_submission:created', (data: any) => {
      if (data?.submission) {
        setAssignmentSubmissions((prev) =>
          prev.some((s) => s.id === data.submission.id)
            ? prev.map((s) => (s.id === data.submission.id ? data.submission : s))
            : [data.submission, ...prev]
        );
      }
    });

    const unsubSubUpdated = realtimeSync.on('assignment_submission:updated', (data: any) => {
      if (data?.submission) {
        setAssignmentSubmissions((prev) =>
          prev.map((s) => (s.id === data.submission.id ? data.submission : s))
        );
      }
    });

    const unsubSubDeleted = realtimeSync.on('assignment_submission:deleted', (data: any) => {
      if (data?.id) {
        setAssignmentSubmissions((prev) => prev.filter((s) => s.id !== data.id));
      }
    });

    const unsubNotifCreated = realtimeSync.on('notification:created', (data: any) => {
      if (data?.notification) {
        setNotifications((prev) =>
          prev.some((n) => n.id === data.notification.id)
            ? prev.map((n) => (n.id === data.notification.id ? data.notification : n))
            : [data.notification, ...prev]
        );
        if (isNotificationVisibleForRole(data.notification, currentUserRef.current?.role)) {
          setLiveAdminToast({
            title: data.notification.title,
            details: data.notification.message,
          });
          setTimeout(() => setLiveAdminToast(null), 6000);
        }
      }
    });

    const unsubNotifUpdated = realtimeSync.on('notification:updated', (data: any) => {
      if (data?.notification) {
        setNotifications((prev) =>
          prev.map((n) => (n.id === data.notification.id ? data.notification : n))
        );
      }
    });

    const unsubNotifDeleted = realtimeSync.on('notification:deleted', (data: any) => {
      if (data?.id) {
        setNotifications((prev) => prev.filter((n) => n.id !== data.id));
      }
    });

    const unsubInquiryCreated = realtimeSync.on('inquiry:created', (data: any) => {
      if (data?.inquiry) {
        setInquiries((prev) =>
          prev.some((i) => i.id === data.inquiry.id)
            ? prev.map((i) => (i.id === data.inquiry.id ? data.inquiry : i))
            : [data.inquiry, ...prev]
        );
      }
    });

    const unsubInquiryUpdated = realtimeSync.on('inquiry:updated', (data: any) => {
      if (data?.inquiry) {
        setInquiries((prev) =>
          prev.map((i) => (i.id === data.inquiry.id ? data.inquiry : i))
        );
      }
    });

    const unsubInquiryDeleted = realtimeSync.on('inquiry:deleted', (data: any) => {
      if (data?.id) {
        setInquiries((prev) => prev.filter((i) => i.id !== data.id));
      }
    });

    const unsubAuditLogCreated = realtimeSync.on('audit_log:created', (data: any) => {
      if (data?.log) {
        setAuditLogs((prev) =>
          prev.some((l) => l.id === data.log.id) ? prev : [data.log, ...prev]
        );
      }
    });

    const unsubLessonRatingUpserted = realtimeSync.on('lesson_rating:upserted', (data: any) => {
      if (data?.rating) {
        setLessonRatings((prev) =>
          prev.some((r) => r.id === data.rating.id)
            ? prev.map((r) => (r.id === data.rating.id ? data.rating : r))
            : [data.rating, ...prev]
        );
      }
    });

    const unsubLessonRatingDeleted = realtimeSync.on('lesson_rating:deleted', (data: any) => {
      if (data?.id) {
        setLessonRatings((prev) => prev.filter((r) => r.id !== data.id));
      }
    });

    const unsubSettingsUpdated = realtimeSync.on('settings:updated', (data: any) => {
      if (data?.settings) {
        setSettings((prev) => ({
          ...prev,
          ...data.settings,
        }));
      }
    });

    const unsubAttendanceRecorded = realtimeSync.on('attendance:recorded', (data: any) => {
      if (data?.student) {
        setStudents((prev) =>
          prev.map((s) => (s.id === data.student.id ? data.student : s))
        );
      }
    });

    return () => {
      unsubAttendanceRecorded();
      unsubSettingsUpdated();
      unsubGrade();
      unsubStudent();
      unsubQuizCreated();
      unsubQuizUpdated();
      unsubQuizDeleted();
      unsubLessonCreated();
      unsubLessonUpdated();
      unsubLessonDeleted();
      unsubStudentUpdated();
      unsubAttemptCreated();
      unsubAttemptUpdated();
      unsubAttemptDeleted();
      unsubCertCreated();
      unsubCertUpdated();
      unsubCertDeleted();
      unsubCertsSynced();
      unsubParentConvCreated();
      unsubParentConvUpdated();
      unsubParentConvDeleted();
      unsubParentMsgEvent();
      unsubParentMsgUpdated();
      unsubParentMsgDeleted();
      unsubAssignmentCreated();
      unsubAssignmentUpdated();
      unsubAssignmentDeleted();
      unsubSubCreated();
      unsubSubUpdated();
      unsubSubDeleted();
      unsubNotifCreated();
      unsubNotifUpdated();
      unsubNotifDeleted();
      unsubInquiryCreated();
      unsubInquiryUpdated();
      unsubInquiryDeleted();
      unsubAuditLogCreated();
      unsubLessonRatingUpserted();
      unsubLessonRatingDeleted();
    };
  }, []);

  // Always keep quizzes & lessons synced from database when opening the quizzes tab
  useEffect(() => {
    if (activeTab !== 'quizzes') return;
    Promise.all([fetch('/api/quizzes'), fetch('/api/lessons'), fetch('/api/students')])
      .then(async ([qzRes, lesRes, stuRes]) => {
        if (qzRes.ok) {
          const qzData = await qzRes.json();
          if (Array.isArray(qzData)) {
            setQuizzes(
              qzData.map((q: any) => ({
                ...q,
                questions:
                  typeof q.questions === 'string'
                    ? JSON.parse(q.questions || '[]')
                    : Array.isArray(q.questions)
                    ? q.questions
                    : [],
              }))
            );
          }
        }
        if (lesRes.ok) {
          const lesData = await lesRes.json();
          if (Array.isArray(lesData)) {
            setLessons(
              lesData.map((l: any) => ({
                ...l,
                infographicData:
                  typeof l.infographicData === 'string' && l.infographicData.trim()
                    ? JSON.parse(l.infographicData)
                    : l.infographicData || undefined,
              }))
            );
          }
        }
        if (stuRes.ok) {
          const stuData = await stuRes.json();
          if (Array.isArray(stuData)) setStudents(stuData);
        }
      })
      .catch(console.warn);
  }, [activeTab]);

  // Always keep assignments & submissions synced from DB when opening assignments tab
  useEffect(() => {
    if (activeTab !== 'assignments') return;
    Promise.all([
      fetch('/api/assignments'),
      fetch('/api/assignment-submissions'),
      fetch('/api/lessons'),
      fetch('/api/students'),
    ])
      .then(async ([asgRes, subRes, lesRes, stuRes]) => {
        if (asgRes.ok) {
          const asgData = await asgRes.json();
          if (Array.isArray(asgData)) setAssignments(asgData);
        }
        if (subRes.ok) {
          const subData = await subRes.json();
          if (Array.isArray(subData)) setAssignmentSubmissions(subData);
        }
        if (lesRes.ok) {
          const lesData = await lesRes.json();
          if (Array.isArray(lesData)) {
            setLessons(
              lesData.map((l: any) => ({
                ...l,
                infographicData:
                  typeof l.infographicData === 'string' && l.infographicData.trim()
                    ? JSON.parse(l.infographicData)
                    : l.infographicData || undefined,
              }))
            );
          }
        }
        if (stuRes.ok) {
          const stuData = await stuRes.json();
          if (Array.isArray(stuData)) setStudents(stuData);
        }
      })
      .catch(console.warn);
  }, [activeTab]);

  // Always keep certificates & quiz attempts synced from database when opening the certificates tab
  useEffect(() => {
    if (activeTab !== 'certificates') return;
    Promise.all([
      fetch('/api/certificates'),
      fetch('/api/quiz-attempts'),
      fetch('/api/students'),
      fetch('/api/quizzes'),
    ])
      .then(async ([cRes, aRes, sRes, qRes]) => {
        if (cRes.ok) {
          const cData = await cRes.json();
          if (Array.isArray(cData)) setCertificates(cData);
        }
        if (aRes.ok) {
          const aData = await aRes.json();
          if (Array.isArray(aData)) setQuizAttempts(aData);
        }
        if (sRes.ok) {
          const sData = await sRes.json();
          if (Array.isArray(sData)) setStudents(sData);
        }
        if (qRes.ok) {
          const qData = await qRes.json();
          if (Array.isArray(qData)) {
            setQuizzes(
              qData.map((q: any) => ({
                ...q,
                questions:
                  typeof q.questions === 'string'
                    ? JSON.parse(q.questions || '[]')
                    : Array.isArray(q.questions)
                    ? q.questions
                    : [],
              }))
            );
          }
        }
      })
      .catch(console.warn);
  }, [activeTab]);

  // Always keep parent conversations & students synced from DB when opening parent communication tab
  useEffect(() => {
    if (activeTab !== 'parents') return;
    Promise.all([fetch('/api/parent-conversations'), fetch('/api/students')])
      .then(async ([cRes, sRes]) => {
        if (cRes.ok) {
          const cData = await cRes.json();
          if (Array.isArray(cData)) setConversations(cData);
        }
        if (sRes.ok) {
          const sData = await sRes.json();
          if (Array.isArray(sData)) setStudents(sData);
        }
      })
      .catch(console.warn);
  }, [activeTab]);

  const handleDeleteStudent = (id: string) => {
    const stu = students.find((s) => s.id === id);
    setStudents((prev) => prev.filter((s) => s.id !== id));
    logSystemChange('حذف قيد طالب', 'student', stu?.name || id, 'تم حذف سجل الطالب من قاعدة البيانات');
  };

  // Handlers for Quizzes (synchronized with state & audit log; DB call handled directly by QuizzesSystem)
  const handleAddQuiz = (
    newQuiz: Quiz | Omit<Quiz, 'id' | 'completedStudentsCount' | 'averageScore'>
  ) => {
    const existing = newQuiz as Quiz;
    const quiz: Quiz = {
      ...newQuiz,
      id: existing.id || `qz-${Date.now()}`,
      completedStudentsCount: existing.completedStudentsCount ?? 0,
      averageScore: existing.averageScore ?? 0,
      questions: Array.isArray(existing.questions) ? existing.questions : [],
    };
    setQuizzes((prev) => {
      if (prev.some((q) => q.id === quiz.id)) {
        return prev.map((q) => (q.id === quiz.id ? quiz : q));
      }
      return [quiz, ...prev];
    });
    logSystemChange(
      'نشر اختبار دوري جديد',
      'quiz',
      quiz.title,
      `تم نشر الاختبار (${quiz.type === 'weekly' ? 'أسبوعي' : 'شهري'}) بعدد ${quiz.questions.length} أسئلة`
    );
  };

  const handleUpdateQuiz = (updatedQuiz: Quiz) => {
    setQuizzes((prev) => prev.map((q) => (q.id === updatedQuiz.id ? updatedQuiz : q)));
    logSystemChange(
      'تحديث بيانات ونتائج اختبار',
      'quiz',
      updatedQuiz.title,
      `تم تحديث الاختبار (${updatedQuiz.questions.length} أسئلة · متوسط الدرجات ${updatedQuiz.averageScore})`
    );
  };

  const handleDeleteQuiz = (id: string) => {
    setQuizzes((prev) => prev.filter((q) => q.id !== id));
  };

  // Handlers for Assignments & Submissions (DB call handled by AssignmentsManager)
  const handleAddAssignment = (newAssignment: Assignment) => {
    setAssignments((prev) =>
      prev.some((a) => a.id === newAssignment.id)
        ? prev.map((a) => (a.id === newAssignment.id ? newAssignment : a))
        : [newAssignment, ...prev]
    );
    logSystemChange(
      'نشر واجب منزلي جديد',
      'assignment',
      newAssignment.title,
      `تم نشر واجب ${newAssignment.subject} بواسطة ${newAssignment.teacherName}`
    );
  };

  const handleUpdateAssignment = (updatedAssignment: Assignment) => {
    setAssignments((prev) =>
      prev.map((a) => (a.id === updatedAssignment.id ? updatedAssignment : a))
    );
    logSystemChange(
      'تعديل واجب منزلي',
      'assignment',
      updatedAssignment.title,
      `تم تحديث تفاصيل الواجب (${updatedAssignment.subject})`
    );
  };

  const handleDeleteAssignment = (id: string) => {
    const target = assignments.find((a) => a.id === id);
    setAssignments((prev) => prev.filter((a) => a.id !== id));
    logSystemChange(
      'حذف واجب منزلي',
      'assignment',
      target?.title || id,
      'تم حذف الواجب من قاعدة البيانات'
    );
  };

  const handleUpsertSubmission = (submission: AssignmentSubmission) => {
    setAssignmentSubmissions((prev) =>
      prev.some((s) => s.id === submission.id)
        ? prev.map((s) => (s.id === submission.id ? submission : s))
        : [submission, ...prev]
    );
    logSystemChange(
      submission.status === 'graded' ? 'تصحيح وتقييم واجب' : 'تسليم حل واجب',
      'assignment_submission',
      submission.studentName,
      submission.status === 'graded'
        ? `تم رصد درجة ${submission.score ?? 0} للطالب ${submission.studentName}`
        : `قام الطالب ${submission.studentName} بتسليم حل الواجب`
    );
  };

  // Always refresh dashboard tables from Cloud SQL when entering dashboard tab
  useEffect(() => {
    if (activeTab === 'dashboard' && !isPublicView) {
      fetchDatabaseState();
    }
  }, [activeTab, isPublicView]);

  // Super Admin Assistant Management (persisted to Cloud SQL users table)
  const handleAddAssistant = async (newAssistant: AssistantAdmin) => {
    const res = await fetch('/api/members', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify({
        uid: newAssistant.id || `usr-${Date.now()}`,
        username: newAssistant.username,
        email: newAssistant.email,
        displayName: newAssistant.name,
        displayNameEn: newAssistant.nameEn || newAssistant.name,
        password: newAssistant.password || '123456',
        role: 'supervisor',
        roleTitle: newAssistant.roleTitle,
        phone: newAssistant.phone,
        permissions: JSON.stringify(newAssistant.permissions || []),
        isActive: newAssistant.isActive ?? true,
      }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'تعذر حفظ حساب المساعد في قاعدة البيانات');
    }
    const saved = await res.json();
    const mapped = mapMemberToAssistant(saved);
    setAssistants((prev) => [mapped, ...prev]);
    logSystemChange(
      'تعيين مساعد إداري جديد',
      'permission',
      mapped.name,
      `تم تعيين ${mapped.name} (${mapped.roleTitle}) ومنحه ${mapped.permissions.length} صلاحيات في قاعدة البيانات`
    );
    return mapped;
  };

  const handleDeleteAssistant = async (id: string) => {
    const asst = assistants.find((a) => a.id === id);
    if (asst?.dbId) {
      const res = await fetch(`/api/members/${asst.dbId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser, teachers),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'تعذر حذف المساعد من قاعدة البيانات');
      }
    }
    setAssistants((prev) => prev.filter((a) => a.id !== id));
  };

  const handleToggleAssistantActive = async (id: string) => {
    const asst = assistants.find((a) => a.id === id);
    if (!asst) return;
    const nextActive = !asst.isActive;
    if (asst.dbId) {
      const res = await fetch(`/api/members/${asst.dbId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({ isActive: nextActive }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'تعذر تعديل حالة المساعد في قاعدة البيانات');
      }
    }
    setAssistants((prev) =>
      prev.map((a) => (a.id === id ? { ...a, isActive: nextActive } : a))
    );
  };

  const handleDeleteAuditLog = async (id: string) => {
    const res = await fetch(`/api/audit-logs/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (!res.ok) throw new Error('تعذر حذف السجل من قاعدة البيانات');
    setAuditLogs((prev) => prev.filter((l) => l.id !== id));
  };

  const handleClearAuditLogs = async () => {
    const res = await fetch('/api/audit-logs', {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (!res.ok) throw new Error('تعذر مسح سجل الرقابة من قاعدة البيانات');
    setAuditLogs([]);
  };

  const handleDeleteLessonRating = async (id: string) => {
    const res = await fetch(`/api/lesson-ratings/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (res.ok) {
      setLessonRatings((prev) => prev.filter((r) => r.id !== id));
    }
  };

  // Super Admin Backup & Restore System (Requested: انشاء نسخه احتياطيه واستعاده نسخه احتياطيه)
  const handleCreateBackup = () => {
    const backupSnapshot = {
      timestamp: new Date().toISOString(),
      superAdmin: 'Mo-NewFolder',
      settings,
      lessons,
      teachers,
      students,
      quizzes,
      certificates,
      conversations,
      timetableSlots,
      invoices,
      notifications,
      assistants,
      auditLogs,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupSnapshot, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `nawabegh_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    logSystemChange('إنشاء وتنزيل نسخة احتياطية كاملة', 'backup', 'nawabegh_backup.json', 'تم تصدير ملف النسخة الاحتياطية بنجاح لكافة بيانات المنصة');
  };

  const handleRestoreBackup = (jsonContent: string) => {
    try {
      if (jsonContent && jsonContent !== '{}') {
        const parsed = JSON.parse(jsonContent);
        if (parsed.lessons) setLessons(parsed.lessons);
        if (parsed.teachers) setTeachers(parsed.teachers);
        if (parsed.students) setStudents(parsed.students);
        if (parsed.quizzes) setQuizzes(parsed.quizzes);
        if (parsed.certificates) setCertificates(parsed.certificates);
        if (parsed.invoices) setInvoices(parsed.invoices);
        if (parsed.assistants) setAssistants(parsed.assistants);
        if (parsed.settings) setSettings(parsed.settings);
      }
      logSystemChange('استعادة نسخة احتياطية للنظام', 'backup', 'استعادة قاعدة البيانات', 'تم استرجاع وتحديث كافة السجلات والبيانات بنجاح');
    } catch (err) {
      console.error('Failed to parse backup JSON', err);
    }
  };

  // Handlers for Certificates (persisted to Cloud SQL)
  const handleIssueCertificateForStudent = async (student: Student) => {
    const serial = `CERT-${new Date().getFullYear()}-EX-${Math.floor(1000 + Math.random() * 9000)}`;
    const certPayload = {
      id: `cert-${Date.now()}`,
      studentId: student.id,
      studentName: student.name,
      studentGrade: student.grade,
      type: 'excellence' as const,
      subjectOrTrack: 'لوحة الشرف للأكاديمية والتميز العام',
      score: student.overallScore,
      issueDate: new Date().toISOString().split('T')[0],
      academicYear: settings.academicYear,
      principalName: `إدارة ${settings.schoolName}`,
      notes: `تقديراً لتفوقه الباهر وحصوله على معدل ${student.overallScore}% ودخوله قائمة الطلاب الفائقين.`,
      serialNumber: serial,
      examPeriod: 'all' as const,
      isAutoGenerated: false,
    };
    try {
      const res = await fetch('/api/certificates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify(certPayload),
      });
      const saved = res.ok ? await res.json() : certPayload;
      setCertificates((prev) => [saved, ...prev]);
      logSystemChange('إصدار شهادة تقدير', 'certificate', student.name, `تم إصدار وحفظ شهادة التقدير (${serial}) في قاعدة البيانات`);
    } catch (err) {
      console.warn('Certificate save fallback:', err);
      setCertificates((prev) => [certPayload, ...prev]);
    }
    setIsPublicView(false);
    setActiveTab('certificates');
  };

  // Handlers for Timetable CRUD (persisted directly to Cloud SQL)
  const handleRefreshTimetable = async () => {
    const res = await fetch('/api/timetable');
    if (!res.ok) throw new Error('تعذر جلب الجدول الدراسي من قاعدة البيانات');
    const data = await res.json();
    if (Array.isArray(data)) setTimetableSlots(data);
    return data;
  };

  const handleAddSlot = async (newSlot: Omit<TimetableSlot, 'id'>) => {
    const payload: TimetableSlot = {
      ...newSlot,
      id: `slot-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    };
    const res = await fetch('/api/timetable', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حفظ الحصة الدراسية في قاعدة البيانات');
    }
    const saved: TimetableSlot = await res.json();
    setTimetableSlots((prev) => [...prev, saved]);
    logSystemChange(
      'إضافة حصة دراسية',
      'timetable',
      saved.subject,
      `تمت إضافة حصة ${saved.subject} يوم ${saved.dayAr} للمدرس ${saved.teacherName}`
    );
    return saved;
  };

  const handleUpdateSlot = async (updatedSlot: TimetableSlot) => {
    const res = await fetch(`/api/timetable/${updatedSlot.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(updatedSlot),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر تحديث بيانات الحصة في قاعدة البيانات');
    }
    const saved: TimetableSlot = await res.json();
    setTimetableSlots((prev) => prev.map((s) => (s.id === saved.id ? saved : s)));
    logSystemChange(
      'تعديل حصة دراسية',
      'timetable',
      saved.subject,
      `تم تعديل موعد حصة ${saved.subject} إلى ${saved.time}`
    );
    return saved;
  };

  const handleDeleteSlot = async (id: string) => {
    const slot = timetableSlots.find((s) => s.id === id);
    const res = await fetch(`/api/timetable/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حذف الحصة من قاعدة البيانات');
    }
    setTimetableSlots((prev) => prev.filter((s) => s.id !== id));
    logSystemChange(
      'حذف حصة دراسية',
      'timetable',
      slot?.subject || id,
      'تم حذف الحصة من الجدول وقاعدة البيانات'
    );
  };

  // Handlers for Payments & Invoices CRUD
  const handlePayInvoice = (
    invoiceId: string,
    method: 'mada' | 'visa' | 'apple_pay' | 'cash'
  ) => {
    const paidDate = new Date().toISOString().split('T')[0];
    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === invoiceId
          ? {
              ...inv,
              status: 'paid',
              paymentMethod: method,
              paidDate,
            }
          : inv
      )
    );
    const inv = invoices.find((i) => i.id === invoiceId);
    logSystemChange('سداد فاتورة إلكترونياً', 'invoice', inv?.invoiceNumber || invoiceId, `تم استلام سداد ${inv?.amount || ''} ريال بنجاح عبر (${method})`);
    fetch(`/api/invoices/${invoiceId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify({ status: 'paid', paymentMethod: method, paidDate }),
    }).catch(console.warn);
  };

  const handleAddInvoice = (newInvoice: Omit<TuitionInvoice, 'id' | 'status'>) => {
    const inv: TuitionInvoice = {
      ...newInvoice,
      id: `inv-${Date.now()}`,
      status: 'pending',
    };
    setInvoices((prev) => [inv, ...prev]);
    logSystemChange('إصدار مطالبة مالية', 'invoice', inv.invoiceNumber, `تم إصدار فاتورة بقيمة ${inv.amount} ريال للطالب ${inv.studentName}`);
    fetch('/api/invoices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(inv),
    }).catch(console.warn);
  };

  const handleUpdateInvoice = (updatedInvoice: TuitionInvoice) => {
    setInvoices((prev) => prev.map((i) => (i.id === updatedInvoice.id ? updatedInvoice : i)));
    logSystemChange('تعديل مطالبة مالية', 'invoice', updatedInvoice.invoiceNumber, 'تم تحديث بيانات ومبلغ الفاتورة');
    fetch(`/api/invoices/${updatedInvoice.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(updatedInvoice),
    }).catch(console.warn);
  };

  const handleDeleteInvoice = (id: string) => {
    const inv = invoices.find((i) => i.id === id);
    setInvoices((prev) => prev.filter((i) => i.id !== id));
    logSystemChange('حذف فاتورة', 'invoice', inv?.invoiceNumber || id, 'تم حذف الفاتورة من منظومة الدفع');
    fetch(`/api/invoices/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    }).catch(console.warn);
  };

  // Handlers for Notifications CRUD (Cloud SQL backed)
  const handleRefreshNotifications = async () => {
    const res = await fetch('/api/notifications');
    if (!res.ok) throw new Error('تعذر جلب الإشعارات من قاعدة البيانات');
    const data = await res.json();
    if (Array.isArray(data)) setNotifications(data);
    return data;
  };

  const handleAddNotification = async (
    newNotif: Omit<AppNotification, 'id' | 'createdAt' | 'read'>
  ) => {
    const payload: AppNotification = {
      ...newNotif,
      id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      createdAt: new Date().toLocaleString('ar-EG', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      read: false,
    };
    const res = await fetch('/api/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حفظ الإشعار في قاعدة البيانات');
    }
    const saved: AppNotification = await res.json();
    setNotifications((prev) =>
      prev.some((n) => n.id === saved.id) ? prev : [saved, ...prev]
    );
    logSystemChange('بث إشعار دوري', 'notification', saved.title, `تم إرسال الإشعار للفئة (${saved.target})`);
    return saved;
  };

  const handleUpdateNotification = async (updatedNotif: AppNotification) => {
    const res = await fetch(`/api/notifications/${updatedNotif.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(updatedNotif),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر تحديث الإشعار في قاعدة البيانات');
    }
    const saved: AppNotification = await res.json();
    setNotifications((prev) => prev.map((n) => (n.id === saved.id ? saved : n)));
    logSystemChange('تعديل إشعار دوري', 'notification', saved.title, 'تم حفظ تعديلات محتوى وتصنيف الإشعار');
    return saved;
  };

  const handleDeleteNotification = async (id: string) => {
    const notif = notifications.find((n) => n.id === id);
    const res = await fetch(`/api/notifications/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حذف الإشعار من قاعدة البيانات');
    }
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    logSystemChange('حذف إشعار', 'notification', notif?.title || id, 'تم حذف الإشعار من السجل وقاعدة البيانات');
  };

  // Handlers for FAQs CRUD (Cloud SQL backed)
  const handleRefreshFaqs = async () => {
    const res = await fetch('/api/faqs');
    if (!res.ok) throw new Error('تعذر جلب الأسئلة الشائعة من قاعدة البيانات');
    const data = await res.json();
    if (Array.isArray(data)) setFaqs(data);
    return data;
  };

  const handleAddFaq = async (newFaq: Omit<FaqItem, 'id'>) => {
    const payload: FaqItem = {
      ...newFaq,
      id: `faq-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    };
    const res = await fetch('/api/faqs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حفظ السؤال الشائع في قاعدة البيانات');
    }
    const saved: FaqItem = await res.json();
    setFaqs((prev) => [saved, ...prev]);
    logSystemChange('إضافة سؤال شائع', 'faq', saved.questionAr, `تمت إضافة السؤال بتصنيف (${saved.category})`);
    return saved;
  };

  const handleUpdateFaq = async (updatedFaq: FaqItem) => {
    const res = await fetch(`/api/faqs/${updatedFaq.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(updatedFaq),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر تحديث السؤال الشائع في قاعدة البيانات');
    }
    const saved: FaqItem = await res.json();
    setFaqs((prev) => prev.map((f) => (f.id === saved.id ? saved : f)));
    logSystemChange('تعديل سؤال شائع', 'faq', saved.questionAr, 'تم حفظ تعديلات السؤال والإجابة');
    return saved;
  };

  const handleDeleteFaq = async (id: string) => {
    const faq = faqs.find((f) => f.id === id);
    const res = await fetch(`/api/faqs/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حذف السؤال الشائع من قاعدة البيانات');
    }
    setFaqs((prev) => prev.filter((f) => f.id !== id));
    logSystemChange('حذف سؤال شائع', 'faq', faq?.questionAr || id, 'تم حذف السؤال من قاعدة البيانات');
  };

  // Handlers for Direct Inquiries CRUD (Cloud SQL backed)
  const handleRefreshInquiries = async () => {
    const res = await fetch('/api/inquiries');
    if (!res.ok) throw new Error('تعذر جلب الاستفسارات من قاعدة البيانات');
    const data = await res.json();
    if (Array.isArray(data)) setInquiries(data);
    return data;
  };

  const handleAddInquiry = async (newInq: Omit<InquiryItem, 'id' | 'createdAt'>) => {
    const res = await fetch('/api/inquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(newInq),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حفظ الاستفسار في قاعدة البيانات');
    }
    const saved: InquiryItem = await res.json();
    setInquiries((prev) =>
      prev.some((i) => i.id === saved.id) ? prev : [saved, ...prev]
    );
    logSystemChange('تسجيل استفسار / مقترح', 'inquiry', saved.subject, `من: ${saved.senderName}`);
    return saved;
  };

  const handleUpdateInquiry = async (updatedInq: InquiryItem) => {
    const res = await fetch(`/api/inquiries/${updatedInq.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(updatedInq),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر تحديث الاستفسار والرد في قاعدة البيانات');
    }
    const saved: InquiryItem = await res.json();
    setInquiries((prev) => prev.map((inq) => (inq.id === saved.id ? saved : inq)));
    logSystemChange('تحديث استفسار والرد عليه', 'inquiry', saved.subject, `الحالة: ${saved.status}`);
    return saved;
  };

  const handleDeleteInquiry = async (id: string) => {
    const target = inquiries.find((i) => i.id === id);
    const res = await fetch(`/api/inquiries/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(currentUser, teachers),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'تعذر حذف الاستفسار من قاعدة البيانات');
    }
    setInquiries((prev) => prev.filter((i) => i.id !== id));
    logSystemChange('حذف استفسار', 'inquiry', target?.subject || id, 'تم حذف الاستفسار من قاعدة البيانات');
  };

  // Handler for School Identity Settings
  const handleUpdateSettings = (newSettings: SchoolSettings) => {
    setSettings(newSettings);
    logSystemChange('تحديث هوية المدرسة', 'settings', newSettings.schoolName, 'تم حفظ وتطبيق ألوان وهوية المدرسة الجديدة');
    fetch('/api/school-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
      body: JSON.stringify(newSettings),
    }).catch(console.warn);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200 overflow-x-clip w-full">
      {/* Top Header */}
      <Header
        settings={settings}
        currentUser={currentUser}
        language={language}
        onLanguageChange={setLanguage}
        isDark={isDark}
        onToggleDark={() => setIsDark((prev) => !prev)}
        onOpenMobileSim={() => setIsMobileSimOpen(true)}
        onOpenSidebar={() => setIsSidebarOpen(true)}
        unreadNotifsCount={unreadNotifsCount}
        notifications={visibleNotifications}
        onOpenNotifications={() => {
          setIsPublicView(false);
          setActiveTab('faqs');
        }}
        activeTab={activeTab}
        onTabChange={(tab) => {
          setIsPublicView(false);
          setActiveTab(tab);
        }}
        isPublicView={isPublicView}
        onTogglePublicView={setIsPublicView}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Workspace Area */}
      {isPublicView ? (
        /* 1. PUBLIC WEBSITE VIEW */
        <main className="flex-1 max-w-[1440px] w-full min-w-0 mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
          <PublicWebsite
            settings={settings}
            lessons={lessons}
            teachers={teachers}
            students={students}
            certificates={certificates}
            timetableSlots={timetableSlots}
            faqs={faqs}
            currentUser={currentUser}
            onUpdateSettings={handleUpdateSettings}
            onNavigateTab={(tab) => {
              setIsPublicView(false);
              setActiveTab(tab as any);
            }}
            onOpenAuth={() => setIsAuthModalOpen(true)}
            onOpenLessonDetails={(les) => {
              setIsPublicView(false);
              setActiveTab('lessons');
            }}
            onOpenCertificateDetails={(cert) => {
              setIsPublicView(false);
              setActiveTab('certificates');
            }}
            language={language}
          />
        </main>
      ) : (
        /* 2. ADMIN DASHBOARD & USER PORTALS VIEW */
        <div className="flex-1 flex max-w-[1600px] w-full mx-auto min-w-0">
          <Sidebar
            activeTab={activeTab}
            onTabChange={setActiveTab}
            language={language}
            isOpen={isSidebarOpen}
            onClose={() => setIsSidebarOpen(false)}
            weakStudentsCount={weakStudentsCount}
            unreadChatsCount={unreadChatsCount}
            currentUser={currentUser}
            onTogglePublicView={setIsPublicView}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
            onLogout={handleLogout}
          />

          <main className="flex-1 p-3 sm:p-5 lg:p-8 min-w-0 w-full overflow-x-clip">
            {/* Mobile & Tablet Horizontal Quick-Nav Bar (Non-sticky to preserve mobile viewport) */}
            <div className="lg:hidden mb-4 flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 font-cairo">
              {[
                { id: 'dashboard', ar: 'لوحة القيادة', en: 'Dashboard', roles: ['admin'] },
                { id: 'members', ar: 'الأعضاء والصلاحيات', en: 'Members', roles: ['admin'], perm: 'manage_members' },
                { id: 'lessons', ar: 'الدروس', en: 'Lessons', roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'], perm: 'manage_lessons' },
                { id: 'study_hub', ar: 'مؤقت المذاكرة', en: 'Pomodoro', roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'] },
                { id: 'assignments', ar: 'الواجبات', en: 'Homework', roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'], perm: 'manage_lessons' },
                { id: 'teachers', ar: 'المعلمون', en: 'Teachers', roles: ['admin', 'supervisor', 'secretary'], perm: 'manage_teachers' },
                { id: 'students', ar: 'الطلاب', en: 'Students', roles: ['admin', 'secretary', 'supervisor'], perm: 'manage_students' },
                { id: 'triage', ar: 'الجرد', en: 'Triage', roles: ['admin', 'supervisor', 'secretary', 'parent'], perm: 'manage_triage' },
                { id: 'whiteboard', ar: 'السبورة', en: 'Whiteboard', roles: ['admin', 'supervisor'], perm: 'manage_whiteboard' },
                { id: 'quizzes', ar: 'الاختبارات', en: 'Quizzes', roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'], perm: 'manage_quizzes' },
                { id: 'competitions', ar: 'الفلاش كارد ومسابقة الشريف', en: 'Flashcards & Al-Sharif Arena', roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'], perm: 'manage_quizzes' },
                { id: 'booklets_store', ar: 'متجر الملازم والكتب', en: 'Booklets Store', roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent', 'visitor'] },
                { id: 'certificates', ar: 'الشهادات', en: 'Certificates', roles: ['admin', 'secretary', 'supervisor', 'student', 'female_student', 'parent'], perm: 'manage_certificates' },
                { id: 'parent_reports', ar: 'التقارير والحضور QR', en: 'Parent Reports & QR', roles: ['admin', 'secretary', 'supervisor', 'teacher', 'student', 'female_student', 'parent'] },
                { id: 'parents', ar: 'الشات والمجموعات', en: 'Chat & Groups', roles: ['admin', 'secretary', 'supervisor', 'teacher', 'student', 'female_student', 'parent'] },
                { id: 'timetable', ar: 'الجدول', en: 'Schedule', roles: ['admin', 'secretary', 'supervisor', 'student', 'female_student', 'parent'], perm: 'manage_timetable' },
                { id: 'payments', ar: 'الرسوم', en: 'Payments', roles: ['admin', 'secretary', 'parent'], perm: 'manage_finances' },
                { id: 'faqs', ar: 'الإشعارات والاستفسارات', en: 'Alerts & Help', roles: ['admin', 'secretary', 'supervisor', 'teacher', 'student', 'female_student', 'parent'], perm: 'manage_faqs' },
                { id: 'backups', ar: 'النسخ الاحتياطي', en: 'Backups', roles: ['admin'], perm: 'manage_backups' },
                { id: 'settings', ar: 'الإعدادات', en: 'Settings', roles: ['admin'], perm: 'manage_settings' },
              ]
                .filter((item) => {
                  const allowedTabs = getAllowedTabsForRole(currentUser);
                  const isStrictRole =
                    isStudentRole(currentUser.role) ||
                    isParentRole(currentUser.role) ||
                    isTeacherRole(currentUser.role) ||
                    currentUser.role === 'visitor';
                  if (isStrictRole) {
                    return allowedTabs.includes(item.id);
                  }
                  const perms = currentUser.permissions || [];
                  const hasAll = perms.includes('*') || perms.includes('all');
                  return (
                    allowedTabs.includes(item.id) ||
                    item.roles.includes(currentUser.role) ||
                    (item.perm && (hasAll || perms.includes(item.perm)))
                  );
                })
                .map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`shrink-0 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                      activeTab === item.id
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {language === 'ar' ? item.ar : item.en}
                  </button>
                ))}
            </div>
            {activeTab === 'dashboard' && currentUser.role === 'admin' && (
              <AdminDashboard
                students={students}
                teachers={teachers}
                lessons={lessons}
                lessonRatings={lessonRatings}
                quizzes={quizzes}
                quizAttempts={quizAttempts}
                certificates={certificates}
                invoices={invoices}
                timetableCount={timetableSlots.length}
                inquiriesCount={inquiries.length}
                pendingUsersCount={pendingUsersCount}
                onNavigateTab={setActiveTab}
                language={language}
                currentUser={currentUser}
                assistants={assistants}
                onAddAssistant={handleAddAssistant}
                onDeleteAssistant={handleDeleteAssistant}
                onToggleAssistantActive={handleToggleAssistantActive}
                onCreateBackup={handleCreateBackup}
                onRestoreBackup={handleRestoreBackup}
                auditLogs={auditLogs}
                onDeleteAuditLog={handleDeleteAuditLog}
                onClearAuditLogs={handleClearAuditLogs}
                onDeleteLessonRating={handleDeleteLessonRating}
                onRefreshDashboard={fetchDatabaseState}
              />
            )}

            {activeTab === 'members' &&
              (currentUser.role === 'admin' ||
                currentUser.permissions?.includes('manage_members') ||
                currentUser.permissions?.includes('*') ||
                currentUser.permissions?.includes('all')) && (
                <MembersAndRolesManager
                  language={language}
                  currentUser={currentUser}
                  onLogAction={logSystemChange}
                />
              )}

            {activeTab === 'backups' &&
              (currentUser.role === 'admin' ||
                currentUser.permissions?.includes('manage_backups') ||
                currentUser.permissions?.includes('*') ||
                currentUser.permissions?.includes('all')) && (
                <BackupsAndExportManager
                  language={language}
                  currentUser={currentUser}
                  onLogAction={logSystemChange}
                />
              )}

            {activeTab === 'security_codes' && (
              <ContentSecurityAndCodesHub
                currentUser={currentUser}
                language={language}
                lessons={lessons}
              />
            )}

            {activeTab === 'lessons' && (
              <LessonsManager
                lessons={lessons}
                teachers={teachers}
                lessonRatings={lessonRatings}
                currentUser={currentUser}
                onAddLesson={handleAddLesson}
                onUpdateLesson={handleUpdateLesson}
                onDeleteLesson={handleDeleteLesson}
                onRatingSubmitted={(saved) =>
                  setLessonRatings((prev) =>
                    prev.some((r) => r.id === saved.id)
                      ? prev.map((r) => (r.id === saved.id ? saved : r))
                      : [saved, ...prev]
                  )
                }
                onRatingDeleted={(id) =>
                  setLessonRatings((prev) => prev.filter((r) => r.id !== id))
                }
                language={language}
              />
            )}

            {activeTab === 'curriculum_path' && (
              <CurriculumGuidedPathHub
                currentUser={currentUser}
                language={language}
              />
            )}

            {activeTab === 'study_hub' && (
              <StudentStudyAndPomodoroHub
                students={students}
                lessons={lessons}
                teachers={teachers}
                currentUser={currentUser}
                language={language}
                onNavigateToLessons={() => setActiveTab('lessons')}
              />
            )}

            {activeTab === 'assignments' && (
              <AssignmentsManager
                assignments={assignments}
                submissions={assignmentSubmissions}
                lessons={lessons}
                teachers={teachers}
                students={students}
                currentUser={currentUser}
                language={language}
                onAddAssignment={handleAddAssignment}
                onUpdateAssignment={handleUpdateAssignment}
                onDeleteAssignment={handleDeleteAssignment}
                onUpsertSubmission={handleUpsertSubmission}
              />
            )}

            {activeTab === 'teachers' && (
              <TeachersDirectory
                teachers={teachers}
                lessons={lessons}
                currentUser={currentUser}
                onAddTeacher={handleAddTeacher}
                onUpdateTeacher={handleUpdateTeacher}
                onDeleteTeacher={handleDeleteTeacher}
                onLessonsAdded={(created) => created.forEach((les) => handleAddLesson(les))}
                onQuizAdded={handleAddQuiz}
                language={language}
              />
            )}

            {activeTab === 'students' && (
              <StudentsManager
                students={students}
                currentUser={currentUser}
                onAddStudent={handleAddStudent}
                onUpdateStudent={handleUpdateStudent}
                onDeleteStudent={handleDeleteStudent}
                language={language}
              />
            )}

            {activeTab === 'triage' && (
              <WeeklyTriage
                students={students}
                language={language}
                readOnly={!isAdminStaffRole(currentUser.role)}
                onNavigateToChat={(stuId) => {
                  setActiveTab('parents');
                }}
                onIssueCertificate={handleIssueCertificateForStudent}
                onSendAlert={(title, message, target) => {
                  handleAddNotification({
                    title,
                    message,
                    target,
                    category: 'academic',
                  });
                }}
              />
            )}

            {activeTab === 'whiteboard' && (
              <InteractiveWhiteboard
                language={language}
                currentUser={currentUser}
                onLogActivity={(action, entity, details) => {
                  logSystemChange(action, 'whiteboard', entity, details);
                }}
              />
            )}

            {activeTab === 'competitions' && (
              <FlashcardsAndCompetitionsHub
                lessons={lessons}
                quizzes={quizzes}
                students={students}
                teachers={teachers}
                currentUser={currentUser}
                language={language}
                onNavigateToLessons={() => setActiveTab('lessons')}
                onNavigateToStudents={() => setActiveTab('students')}
              />
            )}

            {activeTab === 'booklets_store' && (
              <BookletsStoreHub
                currentUser={currentUser}
                teachers={teachers}
                language={language}
              />
            )}

            {activeTab === 'quizzes' && (
              <QuizzesSystem
                quizzes={quizzes}
                lessons={lessons}
                students={students}
                onAddQuiz={handleAddQuiz}
                onUpdateQuiz={handleUpdateQuiz}
                onDeleteQuiz={handleDeleteQuiz}
                onNavigateToLessons={() => setActiveTab('lessons')}
                onNavigateToCertificates={() => setActiveTab('certificates')}
                onExamRecorded={(payload) => {
                  if (payload?.attempt) {
                    setQuizAttempts((prev) => [payload.attempt, ...prev]);
                  }
                  if (payload?.updatedStudent) {
                    setStudents((prev) =>
                      prev.map((s) => (s.id === payload.updatedStudent.id ? payload.updatedStudent : s))
                    );
                  }
                  fetch('/api/certificates')
                    .then((r) => (r.ok ? r.json() : null))
                    .then((rows) => {
                      if (Array.isArray(rows)) setCertificates(rows);
                    })
                    .catch(console.warn);
                }}
                language={language}
                currentUser={currentUser}
                teachers={teachers}
              />
            )}

            {activeTab === 'certificates' && (
              <CertificatesCenter
                certificates={certificates}
                quizAttempts={quizAttempts}
                students={students}
                quizzes={quizzes}
                settings={settings}
                readOnly={!isAdminStaffRole(currentUser.role)}
                currentUser={currentUser}
                onSyncFromDb={(updatedCerts, updatedAttempts) => {
                  setCertificates(updatedCerts);
                  if (updatedAttempts) setQuizAttempts(updatedAttempts);
                }}
                onNavigateTab={setActiveTab}
                language={language}
              />
            )}

            {activeTab === 'parent_reports' && (
              <ParentReportsAndAttendanceHub
                students={students}
                lessons={lessons}
                quizzes={quizzes}
                quizAttempts={quizAttempts}
                teachers={teachers}
                settings={settings}
                currentUser={currentUser}
                language={language}
                onStudentUpdated={(updatedStu) => {
                  setStudents((prev) =>
                    prev.map((s) => (s.id === updatedStu.id ? updatedStu : s))
                  );
                }}
              />
            )}

            {activeTab === 'live_classroom' && (
              <LiveClassroomModule
                currentUser={currentUser}
                teachers={teachers}
                initialRoomCode={deepLinkedClassroom?.roomCode || null}
                initialInviteToken={deepLinkedClassroom?.inviteToken || null}
                onClearDeepLink={() => setDeepLinkedClassroom(null)}
              />
            )}

            {activeTab === 'parents' && (
              <ParentCommunication
                conversations={conversations}
                students={students}
                teachers={teachers}
                directoryUsers={directoryUsers}
                currentUser={currentUser}
                onConversationsSync={setConversations}
                onLogActivity={(actionAr, entityName, details) =>
                  logSystemChange(actionAr, 'parent_chat', entityName, details)
                }
                language={language}
              />
            )}

            {activeTab === 'timetable' && (
              <TimetableSchedule
                slots={timetableSlots}
                teachers={teachers}
                lessons={lessons}
                currentUser={currentUser}
                readOnly={!isAdminStaffRole(currentUser.role)}
                onAddSlot={handleAddSlot}
                onUpdateSlot={handleUpdateSlot}
                onDeleteSlot={handleDeleteSlot}
                onRefreshSlots={handleRefreshTimetable}
                language={language}
              />
            )}

            {activeTab === 'payments' && (
              <PaymentCenter
                invoices={invoices}
                readOnly={!isAdminStaffRole(currentUser.role)}
                onPayInvoice={handlePayInvoice}
                onAddInvoice={handleAddInvoice}
                onUpdateInvoice={handleUpdateInvoice}
                onDeleteInvoice={handleDeleteInvoice}
                language={language}
              />
            )}

            {activeTab === 'faqs' && (
              <FaqNotifications
                faqs={faqs}
                notifications={visibleNotifications}
                inquiries={inquiries}
                currentUserName={currentUser.name}
                currentUser={currentUser}
                onAddFaq={handleAddFaq}
                onUpdateFaq={handleUpdateFaq}
                onDeleteFaq={handleDeleteFaq}
                onAddNotification={handleAddNotification}
                onUpdateNotification={handleUpdateNotification}
                onDeleteNotification={handleDeleteNotification}
                onAddInquiry={handleAddInquiry}
                onUpdateInquiry={handleUpdateInquiry}
                onDeleteInquiry={handleDeleteInquiry}
                onRefreshAll={async () => {
                  const [f, n, i] = await Promise.all([
                    handleRefreshFaqs(),
                    handleRefreshNotifications(),
                    handleRefreshInquiries(),
                  ]);
                  return { faqs: f, notifications: n, inquiries: i };
                }}
                language={language}
              />
            )}

            {activeTab === 'settings' &&
              (currentUser.role === 'admin' ||
                currentUser.permissions?.includes('manage_settings') ||
                currentUser.permissions?.includes('*') ||
                currentUser.permissions?.includes('all')) && (
                <SchoolCustomizer
                  settings={settings}
                  onUpdateSettings={handleUpdateSettings}
                  language={language}
                />
              )}
          </main>
        </div>
      )}

      {/* User Login & Role Switcher Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
        language={language}
      />

      {/* Interactive Mobile Simulator Modal (Android & iOS) */}
      <MobileSimulatorModal
        isOpen={isMobileSimOpen}
        onClose={() => setIsMobileSimOpen(false)}
        lessons={lessons}
        students={students}
        certificates={certificates}
        language={language}
      />

      {/* Real-time Push Notification Banner for Super Admin (Mo-NewFolder) */}
      {liveAdminToast && (
        <div className="fixed bottom-3 inset-x-3 sm:bottom-6 sm:left-6 sm:right-auto z-50 max-w-md sm:w-full">
          <div className="bg-slate-900/95 text-white p-4 rounded-2xl shadow-2xl border-2 border-emerald-500/80 backdrop-blur-md flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <ShieldAlert className="w-5 h-5 text-emerald-400 animate-pulse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-emerald-500 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full font-cairo">
                  {currentUser.isSuperAdmin || currentUser.role === 'admin'
                    ? language === 'ar'
                      ? 'إشعار فوري للأدمن العام'
                      : 'Super Admin Alert'
                    : language === 'ar'
                    ? 'إشعار أكاديمي جديد'
                    : 'New Academic Alert'}
                </span>
                <span className="text-emerald-400 font-mono text-xs font-bold">
                  {currentUser.isSuperAdmin || currentUser.role === 'admin'
                    ? 'Mo-NewFolder'
                    : currentUser.name}
                </span>
              </div>
              <h4 className="font-bold font-cairo text-sm text-slate-100">
                {liveAdminToast.title}
              </h4>
              <p className="text-xs text-slate-300 font-tajawal mt-0.5 line-clamp-2">
                {liveAdminToast.details}
              </p>
            </div>
            <button
              onClick={() => setLiveAdminToast(null)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
              title={language === 'ar' ? 'إغلاق' : 'Close'}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
      {/* Anti-Screen-Recording & Anti-Theft Protection Guard */}
      <ScreenProtectionGuard
        currentUser={currentUser}
        language={language}
        onAccountTerminated={(reason) => {
          const targetId = currentUser.id;
          const targetStudentId = currentUser.studentId;
          setStudents((prev) =>
            prev.filter((s) => s.id !== targetId && s.id !== targetStudentId)
          );
          setAssistants((prev) => prev.filter((a) => a.id !== targetId));
          handleLogout();
          setLiveAdminToast({
            title: 'ممنوع السرقه — تم حذف الحساب نهائياً',
            details: reason,
          });
        }}
      />
      {/* Official QR Code Scanned Certificate Verification Modal (when opening ?verifyCert=...) */}
      {qrScannedCertData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/60 shadow-2xl overflow-hidden">
            <div className="p-5 bg-emerald-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <QrCode className="w-6 h-6 text-amber-300" />
                <div>
                  <h3 className="font-cairo font-black text-base">
                    بوابة التحقق من صحة الشهادات (QR Code) — منصة الشريف
                  </h3>
                  <p className="text-xs text-emerald-100 font-mono-numbers">{qrScannedCertData.code}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setQrScannedCertData(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs md:text-sm">
              {qrScannedCertData.loading ? (
                <div className="py-8 text-center font-cairo font-bold text-slate-600 dark:text-slate-300">
                  جارِ فحص صحة الشهادة من قاعدة البيانات مباشرة...
                </div>
              ) : qrScannedCertData.result?.verified && qrScannedCertData.result?.certificate ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border-2 border-emerald-500 flex items-center gap-3">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
                    <div>
                      <p className="font-cairo font-black text-emerald-900 dark:text-emerald-200 text-sm">
                        ✓ شهادة رسمية صحيحة ومعتمدة في قاعدة بيانات منصة الشريف
                      </p>
                      <p className="text-xs text-emerald-700 dark:text-emerald-300">
                        الجهة المصدرة: {qrScannedCertData.result.platform || 'منصة الشريف التعليمية'}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                    <div>
                      <span className="text-[11px] text-slate-400 block">اسم الطالب / الطالبة</span>
                      <strong className="font-cairo text-slate-900 dark:text-white">
                        {qrScannedCertData.result.certificate.studentName}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">المرحلة الدراسية</span>
                      <strong className="font-cairo text-slate-900 dark:text-white">
                        {qrScannedCertData.result.certificate.studentGrade}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">المعدل المعتمد</span>
                      <strong className="font-mono-numbers text-emerald-600 font-black text-base">
                        {qrScannedCertData.result.certificate.score}%
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">تاريخ الإصدار</span>
                      <strong className="font-mono-numbers text-slate-800 dark:text-slate-200">
                        {qrScannedCertData.result.certificate.issueDate}
                      </strong>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-400 text-center font-cairo font-bold text-rose-800 dark:text-rose-200">
                  {qrScannedCertData.result?.message || 'الشهادة غير مسجلة في قاعدة البيانات'}
                </div>
              )}
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setQrScannedCertData(null)}
                  className="px-5 py-2 rounded-xl bg-emerald-700 text-white font-cairo font-bold text-xs cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PWA Offline Indicator */}
      <OfflineIndicator language={language} />
    </div>
  );
}
