import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Clock,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Sparkles,
  X,
} from 'lucide-react';
import { CurrentUser, Language, Lesson, Teacher, TimestampedLessonNote } from '../types';
import { getAuthHeaders } from '../utils/rbac';

interface ZenStudyOverlayProps {
  lesson: Lesson;
  currentUser: CurrentUser | null;
  teachers: Teacher[];
  language: Language;
  onClose: () => void;
  renderLessonBody: () => React.ReactNode;
}

export const ZenStudyOverlay: React.FC<ZenStudyOverlayProps> = ({
  lesson,
  currentUser,
  teachers,
  language,
  onClose,
  renderLessonBody,
}) => {
  const isAr = language === 'ar';
  const studentId = currentUser?.studentId || currentUser?.id || 'guest';
  const studentName = currentUser?.name || 'طالب';

  // Pomodoro 25 / 5 focus timer
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [elapsedStudySecs, setElapsedStudySecs] = useState(0);

  // Notes state
  const [notes, setNotes] = useState<TimestampedLessonNote[]>([]);
  const [noteText, setNoteText] = useState('');
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => {
    fetch(`/api/lesson-notes?lessonId=${encodeURIComponent(lesson.id)}&studentId=${encodeURIComponent(studentId)}`)
      .then((r) => r.json())
      .then((d) => {
        if (Array.isArray(d.notes)) setNotes(d.notes);
      })
      .catch(() => {});
  }, [lesson.id, studentId]);

  useEffect(() => {
    if (!isRunning) return;
    const t = window.setInterval(() => {
      setElapsedStudySecs((p) => p + 1);
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setIsRunning(false);
          const mins = mode === 'focus' ? 25 : 5;
          fetch('/api/study-hub/pomodoro', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
            body: JSON.stringify({
              studentId,
              studentName,
              subject: lesson.subject,
              lessonId: lesson.id,
              lessonTitle: lesson.title,
              durationMinutes: mins,
              mode,
            }),
          }).catch(() => {});
          if (mode === 'focus') {
            fetch('/api/study-streaks/checkin', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
              body: JSON.stringify({ studentId, studentName, points: 25 }),
            }).catch(() => {});
          }
          showToast(
            mode === 'focus'
              ? isAr ? 'انتهت جلسة التركيز وسُجّلت نقاط سلسلتك!' : 'Focus session logged!'
              : isAr ? 'انتهى وقت الراحة — مستعد للجولة التالية!' : 'Break finished!'
          );
          const nextMode = mode === 'focus' ? 'break' : 'focus';
          setMode(nextMode);
          return (nextMode === 'focus' ? 25 : 5) * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(t);
  }, [isRunning, mode, lesson.id, lesson.subject, lesson.title, studentId, studentName, currentUser, teachers, isAr]);

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteText.trim()) return;
    try {
      const res = await fetch('/api/lesson-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
        body: JSON.stringify({
          lessonId: lesson.id,
          lessonTitle: lesson.title,
          subject: lesson.subject,
          studentId,
          studentName,
          timestampSeconds: elapsedStudySecs,
          formattedTime: formatTimer(elapsedStudySecs),
          noteText: noteText.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok && data.note) {
        setNotes((prev) => [data.note, ...prev]);
        setNoteText('');
        showToast(isAr ? 'تم حفظ الملاحظة الموقوتة' : 'Note saved');
      }
    } catch {
      showToast(isAr ? 'تعذر حفظ الملاحظة' : 'Failed to save note');
    }
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-[70] bg-slate-950 text-slate-100 flex flex-col font-tajawal"
    >
      {/* Top Focus Bar */}
      <div className="px-4 md:px-6 py-3 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-cairo font-bold text-emerald-400 block">
              {isAr ? 'وضع المذاكرة المركّز (خالٍ من المشتتات)' : 'Zen Focus Study Mode'} · {lesson.subject}
            </span>
            <h2 className="text-sm md:text-base font-cairo font-black text-white truncate">
              {lesson.title}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {toast && (
            <span className="px-3 py-1 rounded-lg bg-emerald-800/80 border border-emerald-600 text-xs font-cairo font-bold text-emerald-100 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {toast}
            </span>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>{isAr ? 'خروج من وضع التركيز' : 'Exit Zen Mode'}</span>
          </button>
        </div>
      </div>

      {/* Main Split Workspace */}
      <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
        {/* Lesson Canvas */}
        <div className="lg:col-span-8 xl:col-span-9 overflow-y-auto p-4 md:p-6 bg-slate-950">
          <div className="max-w-4xl mx-auto bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl p-4 md:p-6 border border-slate-800">
            {renderLessonBody()}
          </div>
        </div>

        {/* Focused Pomodoro + Notes Sidebar */}
        <div className="lg:col-span-4 xl:col-span-3 border-t lg:border-t-0 lg:border-r border-slate-800 bg-slate-900/90 flex flex-col overflow-hidden">
          {/* Embedded Pomodoro Widget */}
          <div className="p-4 border-b border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-cairo font-bold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-rose-400" />
                {mode === 'focus'
                  ? isAr ? 'مؤقت التركيز (25د)' : 'Focus (25m)'
                  : isAr ? 'استراحة قصيرة (5د)' : 'Break (5m)'}
              </span>
              <span className="font-mono-numbers text-2xl font-black text-white">
                {formatTimer(secondsLeft)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsRunning((r) => !r)}
                className={`flex-1 py-2 rounded-xl font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                  isRunning ? 'bg-amber-500 text-slate-950' : 'bg-emerald-600 text-white'
                }`}
              >
                {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isRunning ? (isAr ? 'إيقاف مؤقت' : 'Pause') : (isAr ? 'ابدأ الجلسة' : 'Start')}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsRunning(false);
                  setSecondsLeft((mode === 'focus' ? 25 : 5) * 60);
                }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                title={isAr ? 'إعادة ضبط' : 'Reset'}
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Timestamped Personal Notes */}
          <div className="flex-1 flex flex-col p-4 space-y-3 overflow-hidden">
            <h4 className="text-xs font-cairo font-bold text-slate-300 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-sky-400" />
              <span>{isAr ? 'دفتر ملاحظات الجلسة السريع' : 'Quick Focus Notes'}</span>
            </h4>

            <form onSubmit={handleSaveNote} className="space-y-2">
              <textarea
                rows={3}
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder={isAr ? 'سجّل فكرة أو قانوناً أثناء المذاكرة...' : 'Write a timestamped note...'}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder-slate-400"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-cairo font-bold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAr ? `حفظ الملاحظة (${formatTimer(elapsedStudySecs)})` : 'Save Note'}</span>
              </button>
            </form>

            <div className="flex-1 overflow-y-auto space-y-2 pt-1">
              {notes.length === 0 ? (
                <p className="text-[11px] text-slate-500 text-center py-6">
                  {isAr ? 'لا توجد ملاحظات مسجلة بعد في هذا الدرس.' : 'No notes yet.'}
                </p>
              ) : (
                notes.map((n) => (
                  <div key={n.id} className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs space-y-1">
                    <span className="font-mono-numbers text-[10px] font-bold text-sky-400 block">
                      {n.formattedTime} · {n.createdAt}
                    </span>
                    <p className="text-slate-200 leading-relaxed">{n.noteText}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
