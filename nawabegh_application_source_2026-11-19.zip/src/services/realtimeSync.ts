// Real-time WebSocket Data Synchronization Service
// nawabegh Academy - Live synchronizer for Whiteboard & Student Grades

export interface SyncStroke {
  id: string;
  tool: string;
  color: string;
  size: number;
  points: { x: number; y: number }[];
  text?: string;
}

export interface SyncGradePayload {
  studentId: string;
  studentName?: string;
  overallScore: number;
  notes?: string;
  updatedBy: string;
}

type SyncEventListener = (data: any) => void;

class RealtimeSyncService {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<SyncEventListener>> = new Map();
  private isConnecting = false;
  private reconnectTimer: any = null;
  public isConnected = false;
  public connectedClients = 1;

  constructor() {
    this.connect();
  }

  public connect() {
    if (typeof window === 'undefined') return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.isConnecting = true;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws`;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnected = true;
        this.isConnecting = false;
        console.log('⚡ [RealtimeSync] WebSocket connected successfully');
        this.emit('connection:status', { isConnected: true });
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          if (!message || !message.type) return;

          if (message.type === 'presence:update') {
            this.connectedClients = message.data.connectedClients;
          }

          // Dispatch event to registered listeners
          this.emit(message.type, message.data || message);
        } catch (err) {
          console.error('[RealtimeSync] Failed to parse message', err);
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        this.isConnecting = false;
        this.emit('connection:status', { isConnected: false });
        // Attempt auto-reconnection after 3 seconds
        if (!this.reconnectTimer) {
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.connect();
          }, 3000);
        }
      };

      this.ws.onerror = (err) => {
        console.warn('[RealtimeSync] WebSocket encountered error', err);
        this.isConnected = false;
      };
    } catch (e) {
      console.warn('[RealtimeSync] Unable to open WebSocket', e);
      this.isConnected = false;
    }
  }

  public on(event: string, callback: SyncEventListener) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => this.off(event, callback);
  }

  public off(event: string, callback: SyncEventListener) {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      eventListeners.delete(callback);
    }
  }

  private emit(event: string, data: any) {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      eventListeners.forEach((callback) => {
        try {
          callback(data);
        } catch (err) {
          console.error(`Error in listener for ${event}:`, err);
        }
      });
    }
  }

  public send(type: string, payload: any = {}) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      // Re-trigger connection if needed
      this.connect();
      return;
    }
    try {
      this.ws.send(JSON.stringify({ type, ...payload }));
    } catch (err) {
      console.error('[RealtimeSync] Failed to send WebSocket message', err);
    }
  }

  // Whiteboard specific transmitters
  public sendWhiteboardStroke(stroke: SyncStroke) {
    this.send('whiteboard:stroke', { stroke });
  }

  public sendWhiteboardClear() {
    this.send('whiteboard:clear');
  }

  public sendWhiteboardUndo() {
    this.send('whiteboard:undo');
  }

  public sendWhiteboardCodeUpdate(code: string, updatedBy = 'Mo-NewFolder') {
    this.send('whiteboard:code_update', { code, updatedBy });
  }

  public sendWhiteboardTimer(timer: { sessionSeconds: number; isRunning: boolean; mode: 'elapsed' | 'countdown' }) {
    this.send('whiteboard:timer_update', { timer });
  }

  public sendHandRaise(studentId: string, studentName: string, topic: string) {
    this.send('whiteboard:hand_raise', { studentId, studentName, topic });
  }

  public sendHandLower(studentId: string) {
    this.send('whiteboard:hand_lower', { studentId });
  }

  public sendHandLowerAll() {
    this.send('whiteboard:hand_lower_all');
  }

  public sendHandPermit(studentId: string, studentName: string) {
    this.send('whiteboard:hand_permit', { studentId, studentName });
  }

  public sendChatMessage(sender: string, text: string) {
    this.send('whiteboard:chat', { sender, text });
  }

  // Student grades specific transmitters
  public sendGradeUpdate(payload: SyncGradePayload) {
    this.send('grade:update', payload);
  }

  public sendStudentFullUpdate(student: any, updatedBy: string) {
    this.send('student:full_update', { student, updatedBy });
  }

  // Parent communication live typing & WebRTC audio call signaling
  public sendParentTyping(conversationId: string, senderName: string, senderRole: string, isTyping: boolean) {
    this.send('parent_chat:typing', { conversationId, senderName, senderRole, isTyping });
  }

  public sendParentCallOffer(payload: {
    conversationId: string;
    callId: string;
    callerName: string;
    callerRole: string;
    sdp: RTCSessionDescriptionInit;
  }) {
    this.send('parent_call:offer', payload);
  }

  public sendParentCallAnswer(payload: {
    conversationId: string;
    callId: string;
    calleeName: string;
    sdp: RTCSessionDescriptionInit;
  }) {
    this.send('parent_call:answer', payload);
  }

  public sendParentCallIce(payload: {
    conversationId: string;
    callId: string;
    candidate: RTCIceCandidateInit;
  }) {
    this.send('parent_call:ice', payload);
  }

  public sendParentCallReject(conversationId: string, callId: string, reason = 'declined') {
    this.send('parent_call:reject', { conversationId, callId, reason });
  }

  public sendParentCallEnd(conversationId: string, callId: string, durationSeconds: number, endedBy: string) {
    this.send('parent_call:end', { conversationId, callId, durationSeconds, endedBy });
  }
}

export const realtimeSync = new RealtimeSyncService();
