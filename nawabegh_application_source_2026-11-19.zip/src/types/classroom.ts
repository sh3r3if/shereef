export type ClassroomRole = 'teacher' | 'assistant' | 'student' | 'admin';

export type ConnectionQualityLevel = 'excellent' | 'good' | 'poor' | 'lost' | 'unknown';

export interface LiveRoomInfo {
  id: string;
  roomCode: string;
  title: string;
  subject: string;
  grade: string;
  hostId: string;
  hostName: string;
  status: 'scheduled' | 'live' | 'ended';
  isLocked: boolean;
  waitingRoomEnabled: boolean;
  chatMuted: boolean;
  hlsStreamUrl?: string | null;
  maxParticipants: number;
  scheduledAt?: string | null;
  startedAt?: string | null;
  endedAt?: string | null;
  createdAt?: string | null;
  activeParticipantsCount?: number;
}

export interface ClassroomParticipant {
  userId: string;
  socketId: string;
  userName: string;
  role: ClassroomRole;
  isMicEnabled: boolean;
  isCamEnabled: boolean;
  isScreenSharing: boolean;
  canDraw: boolean;
  canSpeak: boolean;
  handRaised: boolean;
  handRaisedAt?: number;
  connectionQuality: ConnectionQualityLevel;
  joinedAt: number;
}

export interface WaitingRoomEntry {
  userId: string;
  socketId: string;
  userName: string;
  role: ClassroomRole;
  requestedAt: number;
}

export interface ClassroomTokenPayload {
  userId: string;
  userName: string;
  role: ClassroomRole;
  roomId: string;
  roomCode?: string;
  iat?: number;
  exp?: number;
}

export interface ClassroomJoinResponse {
  ok: boolean;
  status: 'joined' | 'waiting_approval';
  room: LiveRoomInfo;
  roomToken: string;
  role: ClassroomRole;
  mediaConfig: {
    mode: 'livekit' | 'webrtc-p2p';
    livekitUrl: string | null;
    livekitToken: string | null;
    hlsStreamUrl: string | null;
    simulcastEnabled: boolean;
  };
}
