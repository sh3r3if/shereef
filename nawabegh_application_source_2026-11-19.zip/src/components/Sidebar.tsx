import React from 'react';
import {
  LayoutDashboard,
  Video,
  Users2,
  GraduationCap,
  PenTool,
  AlertTriangle,
  Award,
  MessageSquareText,
  CalendarDays,
  CreditCard,
  FileQuestion,
  Palette,
  X,
  FileText,
  ShieldCheck,
  Database,
  ChevronRight,
  ChevronLeft,
  Globe,
  LogOut,
  BookCheck,
  Trophy,
  KeyRound,
  QrCode,
  Timer,
  Radio,
  Code2,
  ShoppingBag,
} from 'lucide-react';
import { Language, CurrentUser } from '../types';
import {
  getAllowedTabsForRole,
  isParentRole,
  isStudentRole,
  isTeacherRole,
} from '../utils/rbac';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  weakStudentsCount: number;
  unreadChatsCount: number;
  currentUser: CurrentUser;
  onTogglePublicView: (val: boolean) => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  language,
  isOpen,
  onClose,
  weakStudentsCount,
  unreadChatsCount,
  currentUser,
  onTogglePublicView,
  isCollapsed = false,
  onToggleCollapse,
  onLogout,
}) => {
  const isAr = language === 'ar';

  const isStudent = isStudentRole(currentUser.role);
  const isParent = isParentRole(currentUser.role);
  const isTeacher = isTeacherRole(currentUser.role);

  const allMenuItems = [
    {
      id: 'dashboard',
      label: isAr ? 'لوحة التحكم والتحليلات' : 'Analytics Dashboard',
      icon: LayoutDashboard,
      roles: ['admin'],
    },
    {
      id: 'live_classroom',
      label: isAr ? 'الفصل الافتراضي المباشر' : 'Live Virtual Classroom',
      icon: Radio,
      badge: isAr ? 'بث مباشر' : 'LIVE',
      badgeColor: 'bg-rose-600 text-white',
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'visitor'],
    },
    {
      id: 'security_codes',
      label: isStudent
        ? isAr
          ? 'كود التفعيل وأجهزتي'
          : 'Redeem Code & Devices'
        : isAr
        ? 'أمان وأكواد التفعيل'
        : 'Security & Codes',
      icon: KeyRound,
      badge: isAr ? 'حماية' : 'SEC',
      badgeColor: 'bg-emerald-600 text-white',
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student'],
      perm: 'manage_lessons',
    },
    {
      id: 'members',
      label: isAr ? 'تسجيل الأعضاء وتفعيل الحسابات' : 'Members & Activation',
      icon: ShieldCheck,
      roles: ['admin'],
      perm: 'manage_members',
    },
    {
      id: 'backups',
      label: isAr ? 'النسخ الاحتياطي وتصدير النظام' : 'Database & App Backups',
      icon: Database,
      roles: ['admin'],
      perm: 'manage_backups',
    },
    {
      id: 'lessons',
      label: isTeacher
        ? isAr
          ? 'دروسي الخاصة (إضافة وتعديل)'
          : 'My Lessons'
        : isStudent || isParent
        ? isAr
          ? 'الدروس التعليمية (للقراءة)'
          : 'Lessons (View)'
        : isAr
        ? 'إدارة الدروس (فيديو وملفات)'
        : 'Lessons Management',
      icon: Video,
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'],
      perm: 'manage_lessons',
    },
    {
      id: 'curriculum_path',
      label: isAr ? 'مسار الدروس المنهجي' : 'Curriculum Path',
      icon: Code2,
      badge: isAr ? 'منهجي' : 'PATH',
      badgeColor: 'bg-sky-600 text-white',
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent', 'visitor'],
    },
    {
      id: 'study_hub',
      label: isStudent
        ? isAr
          ? 'جدولي والمذاكرة'
          : 'My Study Timer'
        : isAr
        ? 'مؤقت المذاكرة والالتزام'
        : 'Study Timer & Top Students',
      icon: Timer,
      badge: isAr ? 'بومودورو' : 'POMODORO',
      badgeColor: 'bg-rose-600 text-white',
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'],
    },
    {
      id: 'assignments',
      label: isStudent
        ? isAr
          ? 'حل وتسليم الواجبات'
          : 'Homework (Solve)'
        : isParent
        ? isAr
          ? 'الواجبات (متابعة فقط)'
          : 'Homework (View)'
        : isAr
        ? 'الواجبات المنزلية والتكليفات'
        : 'Homework & Assignments',
      icon: BookCheck,
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'],
      perm: 'manage_lessons',
    },
    {
      id: 'quizzes',
      label: isStudent
        ? isAr
          ? 'حل الاختبارات الأسبوعية والشهرية'
          : 'Take Weekly & Monthly Quizzes'
        : isParent
        ? isAr
          ? 'الاختبارات (متابعة فقط)'
          : 'Quizzes (View)'
        : isAr
        ? 'الاختبارات الأسبوعية والشهرية'
        : 'Quizzes & Exams',
      icon: FileText,
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'],
      perm: 'manage_quizzes',
    },
    {
      id: 'competitions',
      label: isAr ? 'الفلاش كارد والمسابقات' : 'Flashcards & Contests',
      icon: Trophy,
      badge: isAr ? 'الشريف' : 'AL-SHARIF',
      badgeColor: 'bg-amber-500 text-slate-950',
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent'],
      perm: 'manage_quizzes',
    },
    {
      id: 'booklets_store',
      label: isAr ? 'متجر الملازم والكتب المطبوعة' : 'Booklets & Books Store',
      icon: ShoppingBag,
      badge: isAr ? 'مطبوع' : 'STORE',
      badgeColor: 'bg-indigo-600 text-white',
      roles: ['admin', 'supervisor', 'secretary', 'teacher', 'student', 'female_student', 'parent', 'visitor'],
    },
    {
      id: 'teachers',
      label: isAr ? 'ملفات المدرسين' : 'Teachers Directory',
      icon: Users2,
      roles: ['admin', 'supervisor', 'secretary', 'teacher'],
      perm: 'manage_teachers',
    },
    {
      id: 'students',
      label: isAr ? 'إدارة الطلاب (أونلاين وأوفلاين)' : 'Students Management',
      icon: GraduationCap,
      roles: ['admin', 'secretary', 'supervisor'],
      perm: 'manage_students',
    },
    {
      id: 'triage',
      label: isAr ? 'الجرد الأسبوعي للمستويات' : 'Weekly Triage & Alerts',
      icon: AlertTriangle,
      badge: weakStudentsCount > 0 ? `${weakStudentsCount}` : undefined,
      badgeColor: 'bg-rose-500 text-white',
      roles: ['admin', 'supervisor', 'secretary', 'parent'],
      perm: 'manage_triage',
    },
    {
      id: 'whiteboard',
      label: isAr ? 'السبورة التفاعلية الحية' : 'Interactive Whiteboard',
      icon: PenTool,
      roles: ['admin', 'supervisor'],
      perm: 'manage_whiteboard',
    },
    {
      id: 'certificates',
      label: isAr ? 'شهادات التقدير والدرجات' : 'Honors & Certificates',
      icon: Award,
      roles: ['admin', 'secretary', 'supervisor', 'student', 'female_student', 'parent'],
      perm: 'manage_certificates',
    },
    {
      id: 'parent_reports',
      label: isStudent
        ? isAr
          ? 'بطاقتي الرقمية (QR)'
          : 'My QR & Report'
        : isParent
        ? isAr
          ? 'التقرير الأسبوعي'
          : 'Weekly Report'
        : isAr
        ? 'متابعة الأهل والحضور'
        : 'Parents & QR Attendance',
      icon: QrCode,
      badge: isAr ? 'واتساب + QR' : 'QR + WA',
      badgeColor: 'bg-teal-600 text-white',
      roles: ['admin', 'secretary', 'supervisor', 'teacher', 'student', 'female_student', 'parent'],
    },
    {
      id: 'parents',
      label: isStudent
        ? isAr
          ? 'شات الطالب والمجموعات'
          : 'Student Chat & Groups'
        : isParent
        ? isAr
          ? 'شات ولي الأمر والمجموعات'
          : 'Parent Chat & Groups'
        : isTeacher
        ? isAr
          ? 'الشات والمجموعات المنظّمة'
          : 'Chat & Groups'
        : isAr
        ? 'منظومة الشات والمجموعات'
        : 'Organized Chat & Groups',
      icon: MessageSquareText,
      badge: unreadChatsCount > 0 ? `${unreadChatsCount}` : undefined,
      badgeColor: 'bg-blue-600 text-white',
      roles: ['admin', 'secretary', 'supervisor', 'teacher', 'student', 'female_student', 'parent'],
    },
    {
      id: 'timetable',
      label: isAr ? 'جدول الحصص والمواعيد' : 'Timetable & Schedule',
      icon: CalendarDays,
      roles: ['admin', 'secretary', 'supervisor', 'student', 'female_student', 'parent'],
      perm: 'manage_timetable',
    },
    {
      id: 'payments',
      label: isAr ? 'الرسوم والدفع الإلكتروني' : 'Tuition & Payments',
      icon: CreditCard,
      roles: ['admin', 'secretary', 'parent'],
      perm: 'manage_finances',
    },
    {
      id: 'faqs',
      label: isParent
        ? isAr
          ? 'الإشعارات والشكاوى والاقتراحات'
          : 'Notices & Complaints to Admin'
        : isStudent || isTeacher
        ? isAr
          ? 'الإشعارات والأسئلة الشائعة'
          : 'Notifications & FAQ'
        : isAr
        ? 'الأسئلة الشائعة والإشعارات'
        : 'FAQ & Notifications',
      icon: FileQuestion,
      roles: ['admin', 'secretary', 'supervisor', 'teacher', 'student', 'female_student', 'parent'],
      perm: 'manage_faqs',
    },
    {
      id: 'settings',
      label: isAr ? 'تخصيص هوية المدرسة' : 'School Branding & Setup',
      icon: Palette,
      roles: ['admin'],
      perm: 'manage_settings',
    },
  ];

  const allowedTabs = getAllowedTabsForRole(currentUser);
  const userPerms = currentUser.permissions || [];
  const hasAllPerms = userPerms.includes('*') || userPerms.includes('all');
  const isStrictRole = isStudent || isParent || isTeacher || currentUser.role === 'visitor';

  const menuItems = allMenuItems.filter((item) => {
    if (isStrictRole) {
      return allowedTabs.includes(item.id);
    }
    return (
      allowedTabs.includes(item.id) ||
      item.roles.includes(currentUser.role) ||
      (item.perm && (hasAllPerms || userPerms.includes(item.perm)))
    );
  });

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 lg:top-[61px] ${
          isAr ? 'right-0' : 'left-0'
        } z-40 h-full lg:h-[calc(100vh-61px)] ${
          isCollapsed ? 'lg:w-20' : 'lg:w-72'
        } w-72 bg-white dark:bg-slate-900 border-x border-slate-200 dark:border-slate-800 flex flex-col transition-all duration-300 ease-in-out ${
          isOpen
            ? 'translate-x-0'
            : isAr
            ? 'translate-x-full lg:translate-x-0'
            : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Mobile & Desktop Header with Collapse Toggle */}
        <div className="flex items-center justify-between p-3.5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 overflow-hidden">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
              ن
            </div>
            {!isCollapsed && (
              <span className="font-cairo font-bold text-sm text-slate-900 dark:text-white truncate">
                {isAr ? 'لوحة تحكم نوابغ' : 'Nawabegh Admin'}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            {/* Desktop Collapse / Expand Button */}
            {onToggleCollapse && (
              <button
                onClick={onToggleCollapse}
                title={
                  isCollapsed
                    ? isAr
                      ? 'توسيع القائمة الجانبية'
                      : 'Expand Sidebar'
                    : isAr
                    ? 'طي القائمة الجانبية (Collapse)'
                    : 'Collapse Sidebar'
                }
                className="hidden lg:flex items-center justify-center p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-400 transition-colors cursor-pointer"
              >
                {isAr ? (
                  isCollapsed ? (
                    <ChevronLeft className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )
                ) : isCollapsed ? (
                  <ChevronRight className="w-4 h-4 text-emerald-600" />
                ) : (
                  <ChevronLeft className="w-4 h-4" />
                )}
              </button>
            )}

            {/* Mobile close button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Items List */}
        <div className="flex-1 overflow-y-auto px-2.5 py-3 space-y-1 smooth-scroll">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  if (window.innerWidth < 1024) onClose();
                }}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center ${
                  isCollapsed ? 'justify-center px-2' : 'justify-between px-3'
                } py-2.5 rounded-xl text-xs font-cairo font-semibold transition-all group relative cursor-pointer ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 font-bold shadow-xs border-r-3 border-emerald-600 dark:border-emerald-500'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'gap-2.5'} truncate`}>
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-colors ${
                      isActive
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-slate-400 group-hover:text-slate-600 dark:text-slate-500'
                    }`}
                  />
                  {!isCollapsed && <span className="truncate">{item.label}</span>}
                </div>

                {!isCollapsed && item.badge && (
                  <span
                    className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full shrink-0 ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}

                {/* Collapsed Badge Dot Indicator */}
                {isCollapsed && item.badge && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900" />
                )}
              </button>
            );
          })}
        </div>

        {/* User Card & Public Website Link */}
        <div className={`p-2.5 m-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 transition-all ${isCollapsed ? 'text-center' : 'space-y-2'}`}>
          <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'gap-2.5'}`}>
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-700 to-teal-800 text-white flex items-center justify-center text-xs font-cairo font-bold shrink-0 shadow-xs">
              {currentUser.name.slice(0, 2)}
            </div>
            {!isCollapsed && (
              <div className="overflow-hidden text-right min-w-0">
                <p className="text-xs font-cairo font-bold text-slate-800 dark:text-slate-200 truncate">
                  {currentUser.name}
                </p>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-cairo font-bold truncate">
                  {currentUser.roleTitle ||
                    ({
                      admin: isAr ? 'مدير عام' : 'Admin',
                      secretary: isAr ? 'سكرتارية' : 'Secretary',
                      supervisor: isAr ? 'مشرف' : 'Supervisor',
                      teacher: isAr ? 'معلم' : 'Teacher',
                      student: isAr ? 'طالب' : 'Student',
                      female_student: isAr ? 'طالبة' : 'Female Student',
                      parent: isAr ? 'ولي أمر' : 'Parent',
                      visitor: isAr ? 'زائر' : 'Visitor',
                    }[currentUser.role] || currentUser.role.toUpperCase())}
                </p>
              </div>
            )}
          </div>

          <button
            onClick={() => onTogglePublicView(true)}
            title={isAr ? 'عرض الموقع العام للمنصة' : 'View Public Website'}
            className={`w-full py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 text-[11px] font-cairo font-bold text-slate-700 dark:text-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${isCollapsed ? 'px-1 mt-2' : 'px-2'}`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            {!isCollapsed && <span>{isAr ? 'الموقع العام' : 'Public Site'}</span>}
          </button>

          {onLogout && currentUser.role !== 'visitor' && (
            <button
              onClick={onLogout}
              title={isAr ? 'تسجيل الخروج من المنظومة' : 'Sign Out'}
              className={`w-full py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 hover:bg-rose-100 dark:hover:bg-rose-900/80 text-[11px] font-cairo font-bold text-rose-700 dark:text-rose-300 transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                isCollapsed ? 'px-1 mt-1.5' : 'px-2 mt-1.5'
              }`}
            >
              <LogOut className="w-3.5 h-3.5 text-rose-600 shrink-0" />
              {!isCollapsed && <span>{isAr ? 'تسجيل الخروج' : 'Sign Out'}</span>}
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
