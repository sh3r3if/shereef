import { describe, expect, it } from 'vitest';
import {
  buildCurriculumChapterFromExtracted,
  buildFormattedLessonHtml,
  extractCurriculumAndQuizFromPdf,
  mapGradeToCurriculumSubjectId,
  normalizeExtractedPayload,
  PdfFeedApiError,
  validatePdfPayloadOrThrow,
} from '../../server/teachers/pdfCurriculumFeedService';

describe('Teacher PDF Library & Automatic Lessons/Quiz Feed Service', () => {
  it('validates real PDF base64 payloads and rejects non-PDF uploads', () => {
    const samplePdfRaw = '%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF';
    const b64 = Buffer.from(samplePdfRaw, 'utf8').toString('base64');
    const dataUrl = `data:application/pdf;base64,${b64}`;

    const clean = validatePdfPayloadOrThrow(dataUrl, 'physics_ch1.pdf');
    expect(clean).toBe(b64);

    const badB64 = Buffer.from('not-a-pdf-file-hello-world-123456', 'utf8').toString('base64');
    expect(() => validatePdfPayloadOrThrow(badB64, 'fake.pdf')).toThrow(PdfFeedApiError);
    expect(() => validatePdfPayloadOrThrow('', 'empty.pdf')).toThrow(PdfFeedApiError);
  });

  it('normalizes extracted lessons and MCQ/TrueFalse questions cleanly', () => {
    const normalized = normalizeExtractedPayload(
      {
        unitTitle: 'الوحدة الأولى: أساسيات الشبكات',
        lessons: [
          {
            title: 'بروتوكول HTTPS وطبقة TLS',
            titleEn: 'HTTPS and TLS',
            summary: 'يشرح هذا الدرس آلية التشفير المتماثل وغير المتماثل أثناء مصافحة TLS.',
            keyPoints: ['مصافحة TLS', 'الشهادة الرقمية', 'المفتاح العام'],
            durationMinutes: 25,
            pageRange: 'ص 1 - ص 4',
          },
          {
            title: 'المصادقة الثنائية 2FA',
            titleEn: 'Two-Factor Authentication',
            summary: 'تجمع بين فئتين مختلفتين مثل المعرفة والحيازة.',
            keyPoints: ['المعرفة', 'الحيازة', 'السمات الحيوية'],
            durationMinutes: 20,
            pageRange: 'ص 5 - ص 8',
          },
        ],
        questions: [
          {
            questionType: 'mcq',
            question: 'أيٌّ مما يلي يحقق المصادقة الثنائية الصحيحة؟',
            options: [
              'كلمة مرور + رمز OTP عبر الهاتف',
              'كلمتا مرور مختلفتان',
              'اسم المستخدم فقط',
              'تاريخ الميلاد فقط',
            ],
            correctOptionIndex: 0,
            explanation: 'تجمع بين فئة المعرفة وفئة الحيازة.',
            sourceLessonIndex: 1,
            sourcePdfPage: 6,
          },
          {
            questionType: 'true_false',
            question: 'تبدأ مصافحة TLS بالتحقق من الشهادة الرقمية للخادم.',
            options: ['نعم', 'لا'],
            correctOptionIndex: 0,
            explanation: 'صحيح — التحقق من الهوية يتم عبر الشهادة الرقمية.',
            sourceLessonIndex: 0,
            sourcePdfPage: 2,
          },
        ],
      },
      'sec2_security.pdf'
    );

    expect(normalized.unitTitle).toBe('الوحدة الأولى: أساسيات الشبكات');
    expect(normalized.lessons).toHaveLength(2);
    expect(normalized.questions).toHaveLength(2);
    expect(normalized.questions[0].options).toHaveLength(4);
    expect(normalized.questions[1].options).toEqual(['صح', 'خطأ']);

    const html = buildFormattedLessonHtml({
      title: normalized.lessons[0].title,
      unit: normalized.unitTitle,
      summary: normalized.lessons[0].summary,
      keyPoints: normalized.lessons[0].keyPoints,
      pageRange: normalized.lessons[0].pageRange,
      fileName: 'sec2_security.pdf',
    });
    expect(html).toContain('مصافحة TLS');
    expect(html).toContain('sec2_security.pdf');
  });

  it('builds a syncable Guided Curriculum chapter and maps grades accurately', () => {
    expect(mapGradeToCurriculumSubjectId('الصف الثاني الثانوي')).toBe('subj-sec2-theory');
    expect(mapGradeToCurriculumSubjectId('الصف الأول الثانوي')).toBe('subj-sec1-theory');
    expect(mapGradeToCurriculumSubjectId('الصف الثالث الإعدادي')).toBe('subj-prep3-ict');

    const extracted = normalizeExtractedPayload(
      {
        unitTitle: 'وحدة تجريبية',
        lessons: [
          {
            title: 'الدرس الأول',
            titleEn: 'Lesson 1',
            summary: 'ملخص علمي مستخرج.',
            keyPoints: ['نقطة 1', 'نقطة 2'],
            durationMinutes: 15,
            pageRange: 'ص 1-2',
          },
        ],
        questions: [
          {
            questionType: 'mcq',
            question: 'سؤال اختباري؟',
            options: ['أ', 'ب', 'ج', 'د'],
            correctOptionIndex: 2,
            explanation: 'تفسير ج.',
            sourceLessonIndex: 0,
            sourcePdfPage: 1,
          },
        ],
      },
      'unit.pdf'
    );

    const chapter = buildCurriculumChapterFromExtracted({
      chapterId: 'ch-tpdf-1',
      order: 5,
      term: 1,
      pdfName: 'unit.pdf',
      extracted,
    });

    expect(chapter.lessons).toHaveLength(1);
    expect(chapter.lessons[0].mcqQuestions).toHaveLength(1);
    expect(chapter.lessons[0].mcqQuestions[0].correctIndex).toBe(2);
    expect(chapter.chapterReviewQuestions).toHaveLength(1);
  });

  it('returns an explicit configuration error rather than mocking when GEMINI_API_KEY is absent', async () => {
    const prevKey = process.env.GEMINI_API_KEY;
    delete process.env.GEMINI_API_KEY;
    try {
      const samplePdfRaw = '%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF';
      await expect(
        extractCurriculumAndQuizFromPdf({
          pdfBase64: Buffer.from(samplePdfRaw, 'utf8').toString('base64'),
          fileName: 'test.pdf',
          teacherName: 'أ. محمد الشريف',
          subject: 'البرمجة',
          grade: 'الصف الثاني الثانوي',
        })
      ).rejects.toMatchObject({
        code: 'GEMINI_API_KEY_MISSING',
        statusCode: 400,
      });
    } finally {
      if (prevKey !== undefined) process.env.GEMINI_API_KEY = prevKey;
    }
  });
});
