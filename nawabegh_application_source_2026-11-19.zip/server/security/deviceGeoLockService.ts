import type express from 'express';

export interface GeoSnapshot {
  country?: string;
  countryCode?: string;
  governorate?: string;
  city?: string;
  village?: string;
  lat?: number;
  lon?: number;
  timezone?: string;
}

export interface ClientNetworkContext {
  ip: string;
  geo: GeoSnapshot;
  geoLabelAr: string;
}

export interface BoundDeviceEntry {
  deviceId: string;
  deviceLabel: string;
  userAgent: string;
  firstBoundAt: string;
  lastActiveAt: string;
  boundIp?: string;
  boundGeo?: GeoSnapshot;
  boundGeoLabel?: string;
  adminApproved?: boolean;
  approvedAt?: string;
  approvedBy?: string;
}

export interface PendingDeviceRequest {
  deviceId: string;
  deviceLabel: string;
  userAgent: string;
  ip: string;
  geo?: GeoSnapshot;
  geoLabel?: string;
  requestedAt: string;
  reasonCode: 'device_limit_exceeded' | 'ip_changed' | 'geo_changed';
  reasonMessageAr: string;
}

export interface StudentDeviceRecord {
  userKey: string;
  studentId?: string;
  studentName: string;
  username?: string;
  studentUsername?: string;
  email?: string;
  phone?: string;
  role: string;
  maxAllowedDevices?: number;
  devices: BoundDeviceEntry[];
  blockedAttemptsCount: number;
  blockedAttempts?: number;
  lastBlockedDeviceLabel?: string;
  lastBlockedIp?: string;
  lastBlockedGeo?: GeoSnapshot;
  lastBlockedGeoLabel?: string;
  lastBlockedAt?: string;
  lockStatus?: 'active' | 'locked';
  lockReasonCode?: 'device_limit_exceeded' | 'ip_changed' | 'geo_changed' | null;
  lockReasonMessageAr?: string | null;
  pendingDeviceRequest?: PendingDeviceRequest | null;
}

export interface SecurityDrmConfig {
  requireActivationCodeForStudents: boolean;
  lockedLessonIds: string[];
  lockedSubjects: string[];
  enableDeviceBinding: boolean;
  maxDevicesPerStudent: number;
  enforceStrictIpBinding: boolean;
  enforceStrictGeoBinding: boolean;
  enableJumpingCornerWatermark: boolean;
  jumpingWatermarkIntervalSec: number;
  enableAudioWatermark: boolean;
  audioWatermarkIntervalSec: number;
  audioWatermarkMode: string;
}

// In-memory IP -> Geo cache (max 1000 entries, 6h TTL)
const ipGeoCache = new Map<string, { geo: GeoSnapshot; expiresAt: number }>();
const IP_GEO_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

export function normalizeIpAddress(rawIp: string | undefined | null): string {
  let ip = String(rawIp || '').trim();
  if (!ip) return '127.0.0.1';
  if (ip.includes(',')) {
    ip = ip.split(',')[0].trim();
  }
  if (ip.startsWith('::ffff:')) {
    ip = ip.slice(7);
  }
  if (ip === '::1' || ip === '0:0:0:0:0:0:0:1') {
    return '127.0.0.1';
  }
  // Strip IPv4 port suffix if present (e.g. "1.2.3.4:56789")
  const ipv4PortMatch = ip.match(/^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/);
  if (ipv4PortMatch) {
    ip = ipv4PortMatch[1];
  }
  return ip;
}

export function isPrivateOrLoopbackIp(ip: string): boolean {
  const clean = normalizeIpAddress(ip);
  if (
    clean === '127.0.0.1' ||
    clean === 'localhost' ||
    clean.startsWith('10.') ||
    clean.startsWith('192.168.') ||
    clean.startsWith('169.254.') ||
    clean === '::' ||
    clean.startsWith('fc') ||
    clean.startsWith('fd') ||
    clean.startsWith('fe80')
  ) {
    return true;
  }
  const m172 = clean.match(/^172\.(\d+)\./);
  if (m172) {
    const second = Number(m172[1]);
    if (second >= 16 && second <= 31) return true;
  }
  return false;
}

function cleanGeoStr(val: unknown): string | undefined {
  const s = String(val || '').trim();
  if (!s || s.toLowerCase() === 'unknown' || s.toLowerCase() === 'zz') return undefined;
  return s;
}

function normalizeGeoToken(val: string | undefined): string {
  return String(val || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

export function formatGeoLabelAr(geo: GeoSnapshot | undefined): string {
  if (!geo) return 'النطاق المحلي';
  const parts = [geo.country, geo.governorate, geo.city, geo.village].filter(Boolean);
  if (parts.length > 0) return parts.join(' • ');
  if (geo.timezone) return geo.timezone;
  return 'النطاق المحلي';
}

export function calculateHaversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export async function lookupPublicIpGeo(ip: string): Promise<GeoSnapshot | null> {
  const normalized = normalizeIpAddress(ip);
  if (!normalized || isPrivateOrLoopbackIp(normalized)) return null;

  const cached = ipGeoCache.get(normalized);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.geo;
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1200);
    const res = await fetch(
      `http://ip-api.com/json/${encodeURIComponent(normalized)}?fields=status,country,countryCode,regionName,city,district,lat,lon,timezone`,
      { signal: controller.signal }
    );
    clearTimeout(timer);
    if (!res.ok) return null;
    const data: any = await res.json();
    if (data?.status !== 'success') return null;

    const geo: GeoSnapshot = {
      country: cleanGeoStr(data.country),
      countryCode: cleanGeoStr(data.countryCode),
      governorate: cleanGeoStr(data.regionName),
      city: cleanGeoStr(data.city),
      village: cleanGeoStr(data.district),
      lat: typeof data.lat === 'number' ? data.lat : undefined,
      lon: typeof data.lon === 'number' ? data.lon : undefined,
      timezone: cleanGeoStr(data.timezone),
    };

    if (ipGeoCache.size >= 1000) {
      const oldestKey = ipGeoCache.keys().next().value;
      if (oldestKey) ipGeoCache.delete(oldestKey);
    }
    ipGeoCache.set(normalized, { geo, expiresAt: Date.now() + IP_GEO_CACHE_TTL_MS });
    return geo;
  } catch {
    return null;
  }
}

export async function extractClientNetworkContext(
  req: express.Request,
  body: Record<string, any> = {}
): Promise<ClientNetworkContext> {
  const headers = req.headers || {};
  const rawForwarded = String(headers['x-forwarded-for'] || '');
  const rawCfIp = String(headers['cf-connecting-ip'] || '');
  const rawRealIp = String(headers['x-real-ip'] || '');
  const socketIp = String(req.ip || req.socket?.remoteAddress || '');

  const ip = normalizeIpAddress(rawForwarded || rawCfIp || rawRealIp || socketIp);

  // Extract proxy / reverse-proxy geographic headers (Cloudflare, App Engine / Cloud Run, Vercel, custom)
  const headerCountry =
    cleanGeoStr(headers['x-geo-country']) ||
    cleanGeoStr(headers['cf-ipcountry']) ||
    cleanGeoStr(headers['x-appengine-country']) ||
    cleanGeoStr(headers['x-vercel-ip-country']);

  const headerGov =
    cleanGeoStr(headers['x-geo-governorate']) ||
    cleanGeoStr(headers['x-geo-region']) ||
    cleanGeoStr(headers['x-appengine-region']) ||
    cleanGeoStr(headers['x-vercel-ip-country-region']);

  const headerCity =
    cleanGeoStr(headers['x-geo-city']) ||
    cleanGeoStr(headers['x-appengine-city']) ||
    cleanGeoStr(headers['x-vercel-ip-city']);

  const headerVillage =
    cleanGeoStr(headers['x-geo-village']) ||
    cleanGeoStr(headers['x-geo-district']) ||
    cleanGeoStr(headers['x-geo-locality']);

  let headerLat: number | undefined;
  let headerLon: number | undefined;
  const latLongRaw = cleanGeoStr(headers['x-appengine-citylatlong']);
  if (latLongRaw && latLongRaw.includes(',')) {
    const [la, lo] = latLongRaw.split(',').map(Number);
    if (Number.isFinite(la) && Number.isFinite(lo)) {
      headerLat = la;
      headerLon = lo;
    }
  }

  const clientGeo = (body?.geoSnapshot && typeof body.geoSnapshot === 'object'
    ? body.geoSnapshot
    : {}) as GeoSnapshot;

  const hasEnoughHeaderGeo = Boolean(headerCountry && headerGov && headerCity);
  const lookedUpGeo =
    !hasEnoughHeaderGeo && !isPrivateOrLoopbackIp(ip) ? await lookupPublicIpGeo(ip) : null;

  const geo: GeoSnapshot = {
    country: headerCountry || lookedUpGeo?.country || cleanGeoStr(clientGeo.country),
    countryCode:
      cleanGeoStr(headers['cf-ipcountry']) ||
      cleanGeoStr(headers['x-appengine-country']) ||
      lookedUpGeo?.countryCode ||
      cleanGeoStr(clientGeo.countryCode),
    governorate: headerGov || lookedUpGeo?.governorate || cleanGeoStr(clientGeo.governorate),
    city: headerCity || lookedUpGeo?.city || cleanGeoStr(clientGeo.city),
    village: headerVillage || lookedUpGeo?.village || cleanGeoStr(clientGeo.village),
    lat: headerLat ?? lookedUpGeo?.lat ?? (typeof clientGeo.lat === 'number' ? clientGeo.lat : undefined),
    lon: headerLon ?? lookedUpGeo?.lon ?? (typeof clientGeo.lon === 'number' ? clientGeo.lon : undefined),
    timezone: cleanGeoStr(body?.clientTimezone) || lookedUpGeo?.timezone || cleanGeoStr(clientGeo.timezone),
  };

  return {
    ip,
    geo,
    geoLabelAr: formatGeoLabelAr(geo),
  };
}

export function detectGeoChange(
  boundGeo: GeoSnapshot | undefined,
  currentGeo: GeoSnapshot | undefined
): { changed: boolean; reasonType?: string; reasonAr?: string } {
  if (!boundGeo || !currentGeo) {
    return { changed: false };
  }

  const bCountry = normalizeGeoToken(boundGeo.country || boundGeo.countryCode);
  const cCountry = normalizeGeoToken(currentGeo.country || currentGeo.countryCode);
  if (bCountry && cCountry && bCountry !== cCountry) {
    return {
      changed: true,
      reasonType: 'country_changed',
      reasonAr: `تم رصد انتقال من دولة (${boundGeo.country || boundGeo.countryCode}) إلى دولة (${currentGeo.country || currentGeo.countryCode})`,
    };
  }

  const bGov = normalizeGeoToken(boundGeo.governorate);
  const cGov = normalizeGeoToken(currentGeo.governorate);
  if (bGov && cGov && bGov !== cGov) {
    return {
      changed: true,
      reasonType: 'governorate_changed',
      reasonAr: `تم رصد انتقال من محافظة (${boundGeo.governorate}) إلى محافظة (${currentGeo.governorate})`,
    };
  }

  const bCity = normalizeGeoToken(boundGeo.city);
  const cCity = normalizeGeoToken(currentGeo.city);
  if (bCity && cCity && bCity !== cCity) {
    return {
      changed: true,
      reasonType: 'city_changed',
      reasonAr: `تم رصد انتقال من مدينة (${boundGeo.city}) إلى مدينة (${currentGeo.city})`,
    };
  }

  const bVillage = normalizeGeoToken(boundGeo.village);
  const cVillage = normalizeGeoToken(currentGeo.village);
  if (bVillage && cVillage && bVillage !== cVillage) {
    return {
      changed: true,
      reasonType: 'village_changed',
      reasonAr: `تم رصد انتقال من قرية/منطقة (${boundGeo.village}) إلى (${currentGeo.village})`,
    };
  }

  // Catch village-to-village / neighborhood movement via coordinates (> 3 km shift)
  if (
    typeof boundGeo.lat === 'number' &&
    typeof boundGeo.lon === 'number' &&
    typeof currentGeo.lat === 'number' &&
    typeof currentGeo.lon === 'number'
  ) {
    const distKm = calculateHaversineKm(boundGeo.lat, boundGeo.lon, currentGeo.lat, currentGeo.lon);
    if (distKm > 3) {
      return {
        changed: true,
        reasonType: 'coordinates_moved',
        reasonAr: `تم رصد انتقال جغرافي خارج النطاق المعتمد بمقدار ${distKm.toFixed(1)} كم`,
      };
    }
  }

  const bTz = normalizeGeoToken(boundGeo.timezone);
  const cTz = normalizeGeoToken(currentGeo.timezone);
  if (bTz && cTz && bTz !== cTz) {
    return {
      changed: true,
      reasonType: 'timezone_changed',
      reasonAr: `تم رصد تغيير في النطاق الزمني والجغرافي (${boundGeo.timezone} ← ${currentGeo.timezone})`,
    };
  }

  return { changed: false };
}

export function isAccountExemptFromDeviceLock(user: {
  userId?: string;
  uid?: string;
  role?: string;
  username?: string;
  email?: string;
  name?: string;
  displayName?: string;
  isSuperAdmin?: boolean;
}): boolean {
  const role = String(user.role || '').trim().toLowerCase();
  const uid = String(user.userId || user.uid || '').trim();
  const username = String(user.username || '').toLowerCase();
  const email = String(user.email || '').toLowerCase();
  const name = String(user.name || user.displayName || '');

  // Only Admin / Super Admin (Mo-NewFolder) and unauthenticated visitors are exempt.
  // All non-admin user accounts (students, parents, teachers, etc.) follow strict 1-device + IP + Geo binding.
  return (
    Boolean(user.isSuperAdmin) ||
    uid === 'usr-super-admin' ||
    role === 'admin' ||
    role === 'visitor' ||
    username.includes('mo-newfolder') ||
    email.includes('mo-newfolder') ||
    name.includes('Mo-NewFolder') ||
    name.includes('الأدمن العام') ||
    name.includes('المدير العام')
  );
}

export interface EvaluateAccessInput {
  records: StudentDeviceRecord[];
  config: Partial<SecurityDrmConfig>;
  user: {
    userKey: string;
    studentId?: string;
    studentName: string;
    username?: string;
    email?: string;
    phone?: string;
    role: string;
  };
  deviceId: string;
  deviceLabel?: string;
  userAgent?: string;
  networkCtx: ClientNetworkContext;
  nowStr?: string;
}

export interface EvaluateAccessResult {
  allowed: boolean;
  status:
    | 'disabled'
    | 'bound_new'
    | 'verified_existing'
    | 'device_limit_blocked'
    | 'ip_changed_blocked'
    | 'geo_changed_blocked'
    | 'account_locked_blocked';
  blockReasonCode?: 'device_limit_exceeded' | 'ip_changed' | 'geo_changed';
  messageAr?: string;
  messageEn?: string;
  requiresAdminActivation: boolean;
  maxDevices: number;
  record: StudentDeviceRecord;
  records: StudentDeviceRecord[];
}

export function evaluateDeviceAndNetworkAccess(
  input: EvaluateAccessInput
): EvaluateAccessResult {
  const {
    records,
    config,
    user,
    deviceId,
    deviceLabel,
    userAgent,
    networkCtx,
    nowStr = new Date().toLocaleString('ar-EG'),
  } = input;

  const enableDeviceBinding = config.enableDeviceBinding !== false;
  const enforceStrictIp = config.enforceStrictIpBinding !== false;
  const enforceStrictGeo = config.enforceStrictGeoBinding !== false;
  // Default strictly to 1 device unless explicitly approved/raised by Admin
  const globalMax = Math.max(1, Number(config.maxDevicesPerStudent) || 1);

  const nextRecords = Array.isArray(records) ? [...records] : [];
  const cleanKey = String(user.userKey || '').toLowerCase();

  let rec = nextRecords.find((r) => String(r.userKey || '').toLowerCase() === cleanKey);
  if (!rec) {
    rec = {
      userKey: cleanKey,
      studentId: user.studentId || cleanKey,
      studentName: user.studentName || user.username || 'مستخدم',
      username: user.username || '',
      studentUsername: user.username || '',
      email: user.email || '',
      phone: user.phone || '',
      role: user.role || 'student',
      maxAllowedDevices: globalMax,
      devices: [],
      blockedAttemptsCount: 0,
      lockStatus: 'active',
      lockReasonCode: null,
      lockReasonMessageAr: null,
      pendingDeviceRequest: null,
    };
    nextRecords.unshift(rec);
  }

  if (user.phone && !rec.phone) rec.phone = user.phone;
  if (!Array.isArray(rec.devices)) rec.devices = [];

  if (!enableDeviceBinding) {
    return {
      allowed: true,
      status: 'disabled',
      requiresAdminActivation: false,
      maxDevices: Math.max(1, Number(rec.maxAllowedDevices) || globalMax),
      record: rec,
      records: nextRecords,
    };
  }

  const effectiveMax = Math.max(1, Number(rec.maxAllowedDevices) || globalMax);
  const existingDevice = rec.devices.find((d) => d.deviceId === deviceId);

  // If the account was previously locked by a security violation, keep it blocked until Admin activates/unlocks it
  if (rec.lockStatus === 'locked' && rec.lockReasonMessageAr) {
    rec.blockedAttemptsCount = (Number(rec.blockedAttemptsCount) || 0) + 1;
    rec.lastBlockedDeviceLabel = deviceLabel || 'جهاز مقيد';
    rec.lastBlockedIp = networkCtx.ip;
    rec.lastBlockedGeo = networkCtx.geo;
    rec.lastBlockedGeoLabel = networkCtx.geoLabelAr;
    rec.lastBlockedAt = nowStr;

    return {
      allowed: false,
      status: 'account_locked_blocked',
      blockReasonCode: rec.lockReasonCode || 'ip_changed',
      messageAr: `${rec.lockReasonMessageAr} الحساب مقيد حالياً ولا يُعاد فتحه إلا بتفعيل من قِبل الأدمن.`,
      messageEn: 'Account is security-locked pending Admin activation.',
      requiresAdminActivation: true,
      maxDevices: effectiveMax,
      record: rec,
      records: nextRecords,
    };
  }

  // Case A: Same registered device -> verify strict IP & Geo lock!
  if (existingDevice) {
    // 1. Check strict geographic movement (country / governorate / city / village) first
    if (enforceStrictGeo && existingDevice.boundGeo) {
      const geoDiff = detectGeoChange(existingDevice.boundGeo, networkCtx.geo);
      if (geoDiff.changed) {
        const msg = `تم إيقاف الحساب: ${geoDiff.reasonAr}. غير مسموح بفتح الحساب عند الانتقال من قرية أو مدينة أو محافظة أو دولة لأخرى إلا بتفعيل من قِبل الأدمن.`;
        rec.blockedAttemptsCount = (Number(rec.blockedAttemptsCount) || 0) + 1;
        rec.lastBlockedDeviceLabel = deviceLabel || existingDevice.deviceLabel;
        rec.lastBlockedIp = networkCtx.ip;
        rec.lastBlockedGeo = networkCtx.geo;
        rec.lastBlockedGeoLabel = networkCtx.geoLabelAr;
        rec.lastBlockedAt = nowStr;
        rec.lockStatus = 'locked';
        rec.lockReasonCode = 'geo_changed';
        rec.lockReasonMessageAr = msg;
        rec.pendingDeviceRequest = {
          deviceId,
          deviceLabel: deviceLabel || existingDevice.deviceLabel,
          userAgent: userAgent || '',
          ip: networkCtx.ip,
          geo: networkCtx.geo,
          geoLabel: networkCtx.geoLabelAr,
          requestedAt: nowStr,
          reasonCode: 'geo_changed',
          reasonMessageAr: msg,
        };

        return {
          allowed: false,
          status: 'geo_changed_blocked',
          blockReasonCode: 'geo_changed',
          messageAr: msg,
          messageEn: 'Geographic location changed. Admin activation is required.',
          requiresAdminActivation: true,
          maxDevices: effectiveMax,
          record: rec,
          records: nextRecords,
        };
      }
    }

    // 2. Check strict IP binding on the same device
    if (enforceStrictIp && existingDevice.boundIp && existingDevice.boundIp !== networkCtx.ip) {
      const msg = `تم إيقاف الحساب: غير مسموح بفتح نفس الحساب من نفس الجهاز بعد تغيير عنوان الـ IP (المعتمد: ${existingDevice.boundIp} ← الحالي: ${networkCtx.ip}) إلا بالتفعيل من قِبل الأدمن.`;
      rec.blockedAttemptsCount = (Number(rec.blockedAttemptsCount) || 0) + 1;
      rec.lastBlockedDeviceLabel = deviceLabel || existingDevice.deviceLabel;
      rec.lastBlockedIp = networkCtx.ip;
      rec.lastBlockedGeo = networkCtx.geo;
      rec.lastBlockedGeoLabel = networkCtx.geoLabelAr;
      rec.lastBlockedAt = nowStr;
      rec.lockStatus = 'locked';
      rec.lockReasonCode = 'ip_changed';
      rec.lockReasonMessageAr = msg;
      rec.pendingDeviceRequest = {
        deviceId,
        deviceLabel: deviceLabel || existingDevice.deviceLabel,
        userAgent: userAgent || '',
        ip: networkCtx.ip,
        geo: networkCtx.geo,
        geoLabel: networkCtx.geoLabelAr,
        requestedAt: nowStr,
        reasonCode: 'ip_changed',
        reasonMessageAr: msg,
      };

      return {
        allowed: false,
        status: 'ip_changed_blocked',
        blockReasonCode: 'ip_changed',
        messageAr: msg,
        messageEn: 'IP address changed for this device. Admin activation is required.',
        requiresAdminActivation: true,
        maxDevices: effectiveMax,
        record: rec,
        records: nextRecords,
      };
    }

    // Backfill boundIp / boundGeo if missing on legacy entry
    if (!existingDevice.boundIp) existingDevice.boundIp = networkCtx.ip;
    if (!existingDevice.boundGeo) {
      existingDevice.boundGeo = networkCtx.geo;
      existingDevice.boundGeoLabel = networkCtx.geoLabelAr;
    }
    existingDevice.lastActiveAt = nowStr;
    if (deviceLabel) existingDevice.deviceLabel = deviceLabel;

    return {
      allowed: true,
      status: 'verified_existing',
      requiresAdminActivation: false,
      maxDevices: effectiveMax,
      record: rec,
      records: nextRecords,
    };
  }

  // Case B: New device and within allowed device limit (default 1 device -> only first bind allowed automatically)
  if (rec.devices.length < effectiveMax) {
    rec.devices.push({
      deviceId,
      deviceLabel: deviceLabel || 'الجهاز الأساسي المعتمد',
      userAgent: userAgent || '',
      firstBoundAt: nowStr,
      lastActiveAt: nowStr,
      boundIp: networkCtx.ip,
      boundGeo: networkCtx.geo,
      boundGeoLabel: networkCtx.geoLabelAr,
      adminApproved: rec.devices.length === 0 ? true : false,
    });
    return {
      allowed: true,
      status: 'bound_new',
      requiresAdminActivation: false,
      maxDevices: effectiveMax,
      record: rec,
      records: nextRecords,
    };
  }

  // Case C: Attempted login from a second/extra device -> BLOCK until Admin explicitly activates!
  const blockMsg = `غير مسموح بفتح نفس الحساب على أكثر من جهاز (${effectiveMax === 1 ? 'جهاز واحد فقط مسموح' : `الحد الأقصى ${effectiveMax} أجهزة`}) إلا بالتفعيل والموافقة من قِبل الأدمن.`;
  rec.blockedAttemptsCount = (Number(rec.blockedAttemptsCount) || 0) + 1;
  rec.lastBlockedDeviceLabel = deviceLabel || 'جهاز إضافي غير مصرح';
  rec.lastBlockedIp = networkCtx.ip;
  rec.lastBlockedGeo = networkCtx.geo;
  rec.lastBlockedGeoLabel = networkCtx.geoLabelAr;
  rec.lastBlockedAt = nowStr;
  rec.pendingDeviceRequest = {
    deviceId,
    deviceLabel: deviceLabel || 'جهاز إضافي غير مصرح',
    userAgent: userAgent || '',
    ip: networkCtx.ip,
    geo: networkCtx.geo,
    geoLabel: networkCtx.geoLabelAr,
    requestedAt: nowStr,
    reasonCode: 'device_limit_exceeded',
    reasonMessageAr: blockMsg,
  };

  return {
    allowed: false,
    status: 'device_limit_blocked',
    blockReasonCode: 'device_limit_exceeded',
    messageAr: blockMsg,
    messageEn: 'Cannot open the same account on more than one device without Admin activation.',
    requiresAdminActivation: true,
    maxDevices: effectiveMax,
    record: rec,
    records: nextRecords,
  };
}

export function applyAdminDeviceApproval(params: {
  records: StudentDeviceRecord[];
  userKey: string;
  mode:
    | 'approve_pending_device'
    | 'approve_ip_or_geo'
    | 'reject_pending_request'
    | 'remove_device'
    | 'reset_all';
  deviceId?: string;
  maxAllowedDevices?: number;
  adminName?: string;
  nowStr?: string;
}): { updated: boolean; records: StudentDeviceRecord[]; target?: StudentDeviceRecord } {
  const {
    records,
    userKey,
    mode,
    deviceId,
    maxAllowedDevices,
    adminName = 'Mo-NewFolder (الأدمن العام)',
    nowStr = new Date().toLocaleString('ar-EG'),
  } = params;

  const cleanKey = String(userKey || '').toLowerCase();
  const nextRecords = Array.isArray(records) ? [...records] : [];
  const target = nextRecords.find(
    (r) =>
      String(r.userKey || '').toLowerCase() === cleanKey ||
      String(r.studentId || '').toLowerCase() === cleanKey
  );

  if (!target) {
    return { updated: false, records: nextRecords };
  }

  if (mode === 'reset_all') {
    target.devices = [];
    target.blockedAttemptsCount = 0;
    target.lockStatus = 'active';
    target.lockReasonCode = null;
    target.lockReasonMessageAr = null;
    target.pendingDeviceRequest = null;
    if (maxAllowedDevices !== undefined) {
      target.maxAllowedDevices = Math.max(1, Number(maxAllowedDevices) || 1);
    }
    return { updated: true, records: nextRecords, target };
  }

  if (mode === 'reject_pending_request') {
    const prevReq = target.pendingDeviceRequest;
    target.pendingDeviceRequest = null;
    if (prevReq && prevReq.reasonCode !== 'device_limit_exceeded') {
      target.lockStatus = 'locked';
      target.lockReasonMessageAr = `تم رفض طلب فك الحظر من قِبل (${adminName}) بتاريخ ${nowStr}.`;
    }
    return { updated: true, records: nextRecords, target };
  }

  if (mode === 'remove_device' && deviceId) {
    target.devices = (target.devices || []).filter((d) => d.deviceId !== deviceId);
    target.lockStatus = 'active';
    target.lockReasonCode = null;
    target.lockReasonMessageAr = null;
    if (target.pendingDeviceRequest?.deviceId === deviceId) {
      target.pendingDeviceRequest = null;
    }
    if (maxAllowedDevices !== undefined) {
      target.maxAllowedDevices = Math.max(1, Number(maxAllowedDevices) || 1);
    }
    return { updated: true, records: nextRecords, target };
  }

  if (mode === 'approve_ip_or_geo') {
    const req = target.pendingDeviceRequest;
    const targetDevId = deviceId || req?.deviceId;
    const dev = target.devices.find((d) => d.deviceId === targetDevId) || target.devices[0];
    if (dev) {
      if (req?.ip || target.lastBlockedIp) {
        dev.boundIp = req?.ip || target.lastBlockedIp;
      }
      if (req?.geo || target.lastBlockedGeo) {
        dev.boundGeo = req?.geo || target.lastBlockedGeo;
        dev.boundGeoLabel = req?.geoLabel || target.lastBlockedGeoLabel;
      }
      dev.lastActiveAt = nowStr;
      dev.adminApproved = true;
      dev.approvedAt = nowStr;
      dev.approvedBy = adminName;
    }
    target.lockStatus = 'active';
    target.lockReasonCode = null;
    target.lockReasonMessageAr = null;
    target.pendingDeviceRequest = null;
    return { updated: true, records: nextRecords, target };
  }

  if (mode === 'approve_pending_device') {
    const pending = target.pendingDeviceRequest;
    if (pending) {
      const existing = target.devices.find((d) => d.deviceId === pending.deviceId);
      if (existing) {
        existing.boundIp = pending.ip;
        existing.boundGeo = pending.geo;
        existing.boundGeoLabel = pending.geoLabel;
        existing.lastActiveAt = nowStr;
        existing.adminApproved = true;
        existing.approvedAt = nowStr;
        existing.approvedBy = adminName;
      } else {
        target.devices.push({
          deviceId: pending.deviceId,
          deviceLabel: pending.deviceLabel,
          userAgent: pending.userAgent,
          firstBoundAt: nowStr,
          lastActiveAt: nowStr,
          boundIp: pending.ip,
          boundGeo: pending.geo,
          boundGeoLabel: pending.geoLabel,
          adminApproved: true,
          approvedAt: nowStr,
          approvedBy: adminName,
        });
        target.maxAllowedDevices = Math.max(
          Number(target.maxAllowedDevices) || 1,
          target.devices.length
        );
      }
    }
    target.lockStatus = 'active';
    target.lockReasonCode = null;
    target.lockReasonMessageAr = null;
    target.pendingDeviceRequest = null;
    return { updated: true, records: nextRecords, target };
  }

  return { updated: false, records: nextRecords, target };
}
