import {
  AppNotification,
  Assignment,
  ChatChannelType,
  CurrentUser,
  Language,
  Lesson,
  ParentConversation,
  Quiz,
  Student,
  Teacher,
  UserRole,
} from '../types';

export function isStudentRole(role?: UserRole | string): boolean {
  return role === 'student' || role === 'female_student';
}

export function isParentRole(role?: UserRole | string): boolean {
  return role === 'parent';
}

export function isTeacherRole(role?: UserRole | string): boolean {
  return role === 'teacher';
}

export function isAdminStaffRole(role?: UserRole | string): boolean {
  return role === 'admin' || role === 'secretary' || role === 'supervisor';
}

export function isPlatformAdminRole(currentUser?: CurrentUser | null): boolean {
  if (!currentUser) return false;
  return (
    Boolean(currentUser.isSuperAdmin) ||
    currentUser.role === 'admin' ||
    currentUser.role === 'secretary' ||
    currentUser.role === 'supervisor'
  );
}

/**
 * Allowed navigation tabs strictly per role:
 * - student / female_student: ONLY lessons, assignments, quizzes, timetable, certificates, faqs (notifications & help)
 *   (No add/edit/delete; only solve assignments & quizzes)
 * - parent: ONLY faqs (notifications & suggestions/complaints to Admin), lessons, assignments, quizzes, timetable, certificates, triage, payments (all read-only except sending suggestions/complaints to Admin)
 * - teacher: ONLY lessons (own lessons CRUD), assignments (CRUD + grading), quizzes (CRUD weekly/monthly), faqs (read-only notifications/FAQs)
 *   (No wider platform management)
 */
export function getAllowedTabsForRole(currentUser?: CurrentUser | null): string[] {
  const role = currentUser?.role;
  if (!role || role === 'visitor') {
    return ['lessons', 'curriculum_path', 'live_classroom', 'competitions', 'booklets_store', 'faqs'];
  }
  if (isStudentRole(role)) {
    return [
      'lessons',
      'curriculum_path',
      'live_classroom',
      'study_hub',
      'security_codes',
      'assignments',
      'quizzes',
      'competitions',
      'booklets_store',
      'parent_reports',
      'parents',
      'timetable',
      'certificates',
      'faqs',
    ];
  }
  if (isParentRole(role)) {
    return [
      'faqs',
      'parent_reports',
      'curriculum_path',
      'study_hub',
      'parents',
      'lessons',
      'assignments',
      'quizzes',
      'competitions',
      'booklets_store',
      'timetable',
      'certificates',
      'triage',
      'payments',
    ];
  }
  if (isTeacherRole(role)) {
    return [
      'lessons',
      'curriculum_path',
      'live_classroom',
      'study_hub',
      'security_codes',
      'assignments',
      'quizzes',
      'competitions',
      'booklets_store',
      'parent_reports',
      'parents',
      'faqs',
    ];
  }
  if (role === 'secretary') {
    return [
      'dashboard',
      'lessons',
      'curriculum_path',
      'live_classroom',
      'study_hub',
      'security_codes',
      'assignments',
      'quizzes',
      'competitions',
      'booklets_store',
      'teachers',
      'students',
      'triage',
      'parent_reports',
      'parents',
      'timetable',
      'certificates',
      'payments',
      'faqs',
    ];
  }
  if (role === 'supervisor') {
    return [
      'dashboard',
      'lessons',
      'curriculum_path',
      'live_classroom',
      'study_hub',
      'security_codes',
      'assignments',
      'quizzes',
      'competitions',
      'booklets_store',
      'whiteboard',
      'teachers',
      'students',
      'triage',
      'parent_reports',
      'parents',
      'timetable',
      'certificates',
      'faqs',
    ];
  }
  // Super Admin / Admin: full platform
  return [
    'dashboard',
    'live_classroom',
    'curriculum_path',
    'security_codes',
    'lessons',
    'study_hub',
    'assignments',
    'quizzes',
    'competitions',
    'booklets_store',
    'whiteboard',
    'teachers',
    'students',
    'triage',
    'parent_reports',
    'parents',
    'timetable',
    'certificates',
    'payments',
    'faqs',
    'members',
    'backups',
    'settings',
  ];
}

export function getDefaultTabForRole(currentUser?: CurrentUser | null): string {
  const role = currentUser?.role;
  if (isStudentRole(role)) return 'assignments';
  if (isParentRole(role)) return 'faqs';
  if (isTeacherRole(role)) return 'lessons';
  if (!role || role === 'visitor') return 'lessons';
  return 'dashboard';
}

export function resolveMatchedTeacher(
  currentUser: CurrentUser | null | undefined,
  teachers: Teacher[]
): Teacher | null {
  if (!currentUser || !isTeacherRole(currentUser.role)) return null;
  const emailLower = (currentUser.email || '').trim().toLowerCase();
  const nameLower = (currentUser.name || '').trim().toLowerCase();
  return (
    teachers.find((t) => t.id === currentUser.teacherId) ||
    teachers.find((t) => emailLower && t.email.trim().toLowerCase() === emailLower) ||
    teachers.find((t) => nameLower && t.name.trim().toLowerCase() === nameLower) ||
    null
  );
}

export function resolveMatchedStudent(
  currentUser: CurrentUser | null | undefined,
  students: Student[]
): Student | null {
  if (!currentUser) return null;
  if (currentUser.studentId) {
    const byId = students.find((s) => s.id === currentUser.studentId);
    if (byId) return byId;
  }
  const emailLower = (currentUser.email || '').trim().toLowerCase();
  const nameLower = (currentUser.name || '').trim().toLowerCase();
  return (
    students.find((s) => emailLower && s.parentEmail?.trim().toLowerCase() === emailLower) ||
    students.find((s) => nameLower && s.name.trim().toLowerCase() === nameLower) ||
    null
  );
}

export function canTeacherManageLesson(
  lesson: Lesson,
  currentUser: CurrentUser | null | undefined,
  teachers: Teacher[]
): boolean {
  if (!currentUser) return false;
  if (currentUser.isSuperAdmin || currentUser.role === 'admin' || currentUser.role === 'supervisor') {
    return true;
  }
  if (!isTeacherRole(currentUser.role)) return false;

  const matched = resolveMatchedTeacher(currentUser, teachers);
  const lessonTeacherId = (lesson.teacherId || '').trim();
  const lessonTeacherName = (lesson.teacherName || '').trim().toLowerCase();

  if (currentUser.teacherId && lessonTeacherId === currentUser.teacherId) return true;
  if (currentUser.id && lessonTeacherId === currentUser.id) return true;
  if (matched && lessonTeacherId === matched.id) return true;
  if (currentUser.name && lessonTeacherName === currentUser.name.trim().toLowerCase()) return true;
  if (matched && lessonTeacherName === matched.name.trim().toLowerCase()) return true;
  return false;
}

export function canTeacherManageAssignment(
  assignment: Assignment,
  currentUser: CurrentUser | null | undefined,
  teachers: Teacher[]
): boolean {
  if (!currentUser) return false;
  if (currentUser.isSuperAdmin || currentUser.role === 'admin' || currentUser.role === 'supervisor') {
    return true;
  }
  if (!isTeacherRole(currentUser.role)) return false;

  const matched = resolveMatchedTeacher(currentUser, teachers);
  const asgTeacherId = (assignment.teacherId || '').trim();
  const asgTeacherName = (assignment.teacherName || '').trim().toLowerCase();
  if (!asgTeacherId && !asgTeacherName) return true;
  if (currentUser.teacherId && asgTeacherId === currentUser.teacherId) return true;
  if (currentUser.id && asgTeacherId === currentUser.id) return true;
  if (matched && asgTeacherId === matched.id) return true;
  if (currentUser.name && asgTeacherName === currentUser.name.trim().toLowerCase()) return true;
  if (matched && asgTeacherName === matched.name.trim().toLowerCase()) return true;
  return false;
}

export function canTeacherManageQuiz(
  quiz: Quiz,
  currentUser: CurrentUser | null | undefined,
  teachers: Teacher[]
): boolean {
  if (!currentUser) return false;
  if (currentUser.isSuperAdmin || currentUser.role === 'admin' || currentUser.role === 'supervisor') {
    return true;
  }
  if (!isTeacherRole(currentUser.role)) return false;

  // Legacy quizzes created before teacherId tracking remain editable by teachers,
  // while newly attributed quizzes match owner teacher.
  const qTeacherId = (quiz.teacherId || '').trim();
  const qTeacherName = (quiz.teacherName || '').trim().toLowerCase();
  if (!qTeacherId && !qTeacherName) return true;
  const matched = resolveMatchedTeacher(currentUser, teachers);
  if (currentUser.teacherId && qTeacherId === currentUser.teacherId) return true;
  if (currentUser.id && qTeacherId === currentUser.id) return true;
  if (matched && qTeacherId === matched.id) return true;
  if (currentUser.name && qTeacherName === currentUser.name.trim().toLowerCase()) return true;
  if (matched && qTeacherName === matched.name.trim().toLowerCase()) return true;
  return false;
}

export function isNotificationVisibleForRole(
  notif: AppNotification,
  role?: UserRole | string
): boolean {
  if (!role || role === 'admin' || role === 'secretary' || role === 'supervisor') return true;
  if (isStudentRole(role)) {
    return (
      notif.target === 'all' ||
      notif.target === 'students' ||
      notif.target === 'students_parents' ||
      notif.target === 'top_students' ||
      notif.target === 'weak_students'
    );
  }
  if (isParentRole(role)) {
    return (
      notif.target === 'all' ||
      notif.target === 'parents' ||
      notif.target === 'students_parents' ||
      notif.target === 'weak_students' ||
      notif.target === 'top_students'
    );
  }
  if (isTeacherRole(role)) {
    return notif.target === 'all' || notif.target === 'students_parents';
  }
  return notif.target === 'all';
}

export function getAuthHeaders(
  currentUser?: CurrentUser | null,
  teachers: Teacher[] = []
): Record<string, string> {
  if (!currentUser) return {};
  const matchedTeacher = resolveMatchedTeacher(currentUser, teachers);
  return {
    'x-user-role': currentUser.role,
    'x-user-id': encodeURIComponent(currentUser.id || ''),
    'x-user-name': encodeURIComponent(currentUser.name || ''),
    'x-teacher-id': encodeURIComponent(
      matchedTeacher?.id || currentUser.teacherId || currentUser.id || ''
    ),
  };
}

export function isConversationVisibleForUser(
  conv: ParentConversation,
  currentUser: CurrentUser | null | undefined,
  teachers: Teacher[] = [],
  students: Student[] = []
): boolean {
  if (!currentUser || currentUser.role === 'visitor') return false;
  if (
    currentUser.isSuperAdmin ||
    currentUser.role === 'admin' ||
    currentUser.role === 'supervisor' ||
    currentUser.role === 'secretary'
  ) {
    return true;
  }

  const channel: ChatChannelType = conv.channelType || 'parent_teacher';
  const userIds = new Set<string>(
    [currentUser.id, currentUser.username, currentUser.studentId, currentUser.teacherId]
      .filter(Boolean)
      .map((v) => String(v).trim().toLowerCase())
  );
  const userNameLower = (currentUser.name || '').trim().toLowerCase();
  const userEmailLower = (currentUser.email || '').trim().toLowerCase();

  const memberIdsLower = (conv.memberIds || []).map((m) => String(m).trim().toLowerCase());
  const memberNamesLower = (conv.memberNames || []).map((m) => String(m).trim().toLowerCase());

  const isExplicitMember =
    (conv.createdById && userIds.has(conv.createdById.trim().toLowerCase())) ||
    memberIdsLower.some((m) => userIds.has(m)) ||
    (userNameLower && memberNamesLower.includes(userNameLower));

  if (channel === 'private_group') {
    if (isExplicitMember) return true;
    if (isTeacherRole(currentUser.role)) {
      const matchedTeacher = resolveMatchedTeacher(currentUser, teachers);
      const tId = (conv.teacherId || '').trim().toLowerCase();
      if (matchedTeacher && tId && tId === matchedTeacher.id.toLowerCase()) return true;
    }
    return false;
  }

  if (channel === 'public_group') {
    if (isExplicitMember) return true;
    const aud = conv.targetAudience || 'all';
    if (aud === 'all') return true;
    if (isStudentRole(currentUser.role)) return aud === 'students';
    if (isParentRole(currentUser.role)) return aud === 'parents';
    if (isTeacherRole(currentUser.role)) return aud === 'teachers' || aud === 'staff';
    return false;
  }

  if (isTeacherRole(currentUser.role)) {
    const matchedTeacher = resolveMatchedTeacher(currentUser, teachers);
    const tId = (conv.teacherId || '').trim().toLowerCase();
    const tName = (conv.teacherName || '').trim().toLowerCase();
    const myTeacherIds = new Set(
      [currentUser.id, currentUser.teacherId, matchedTeacher?.id]
        .filter(Boolean)
        .map((v) => String(v).trim().toLowerCase())
    );
    const myTeacherNames = new Set(
      [currentUser.name, matchedTeacher?.name]
        .filter(Boolean)
        .map((v) => String(v).trim().toLowerCase())
    );

    if (channel === 'student_teacher' || channel === 'parent_teacher' || channel === 'teacher_admin') {
      if (isExplicitMember) return true;
      if (!tId && !tName) return true; // Unassigned legacy or open thread for teachers
      if (tId && myTeacherIds.has(tId)) return true;
      if (tName && myTeacherNames.has(tName)) return true;
      return false;
    }
    return false;
  }

  if (isStudentRole(currentUser.role)) {
    if (channel !== 'student_teacher') return false;
    if (isExplicitMember) return true;
    const matchedStu = resolveMatchedStudent(currentUser, students);
    const convStuId = (conv.studentId || '').trim().toLowerCase();
    const convStuName = (conv.studentName || '').trim().toLowerCase();
    if (convStuId && (userIds.has(convStuId) || (matchedStu && convStuId === matchedStu.id.toLowerCase()))) {
      return true;
    }
    if (convStuName && (convStuName === userNameLower || (matchedStu && convStuName === matchedStu.name.trim().toLowerCase()))) {
      return true;
    }
    return false;
  }

  if (isParentRole(currentUser.role)) {
    if (channel !== 'parent_teacher') return false;
    if (isExplicitMember) return true;
    const matchedStu = resolveMatchedStudent(currentUser, students);
    const convStuId = (conv.studentId || '').trim().toLowerCase();
    const convParentName = (conv.parentName || '').trim().toLowerCase();
    const convParentEmail = (conv.parentEmail || '').trim().toLowerCase();
    if (matchedStu && convStuId && convStuId === matchedStu.id.toLowerCase()) return true;
    if (convParentName && convParentName === userNameLower) return true;
    if (convParentEmail && userEmailLower && convParentEmail === userEmailLower) return true;
    return false;
  }

  return false;
}

export function getChannelTypeLabel(channelType: ChatChannelType, language: Language): string {
  const isAr = language === 'ar';
  switch (channelType) {
    case 'student_teacher':
      return isAr ? 'طالب ↔ معلم' : 'Student ↔ Teacher';
    case 'parent_teacher':
      return isAr ? 'ولي أمر ↔ معلم' : 'Parent ↔ Teacher';
    case 'teacher_admin':
      return isAr ? 'معلم ↔ إدارة' : 'Teacher ↔ Admin';
    case 'private_group':
      return isAr ? 'مجموعة خاصة' : 'Private Group';
    case 'public_group':
      return isAr ? 'مجموعة عامة' : 'Public Group';
    default:
      return isAr ? 'محادثة' : 'Chat';
  }
}

export function getRoleBadgeLabel(role: string, language: Language): string {
  const isAr = language === 'ar';
  switch (role) {
    case 'admin':
      return isAr ? 'المدير العام' : 'Admin';
    case 'supervisor':
      return isAr ? 'مشرف' : 'Supervisor';
    case 'secretary':
      return isAr ? 'سكرتارية' : 'Secretary';
    case 'teacher':
      return isAr ? 'معلم' : 'Teacher';
    case 'student':
      return isAr ? 'طالب' : 'Student';
    case 'female_student':
      return isAr ? 'طالبة' : 'Female Student';
    case 'parent':
      return isAr ? 'ولي أمر' : 'Parent';
    default:
      return isAr ? 'مشارك' : 'Member';
  }
}

