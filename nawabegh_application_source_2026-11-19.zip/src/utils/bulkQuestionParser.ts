import type { QuizQuestion } from '../types';

export interface BulkQuestionParseResult {
  questions: QuizQuestion[];
  errors: string[];
}

function splitDelimitedLine(line: string, delimiter: string): string[] {
  if (delimiter === '\t' || delimiter === '|') {
    return line.split(delimiter).map((c) => c.trim());
  }
  // CSV quote-aware splitter
  const cells: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      cells.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  cells.push(current.trim());
  return cells;
}

function resolveCorrectIndex(rawAnswer: string, options: string[]): number {
  const clean = String(rawAnswer || '').trim();
  if (!clean) return 0;

  const upper = clean.toUpperCase();
  const letterMap: Record<string, number> = {
    A: 0,
    B: 1,
    C: 2,
    D: 3,
    أ: 0,
    ا: 0,
    ب: 1,
    ج: 2,
    د: 3,
  };
  if (letterMap[upper] !== undefined) return Math.min(options.length - 1, letterMap[upper]);
  if (letterMap[clean] !== undefined) return Math.min(options.length - 1, letterMap[clean]);

  const numeric = Number(clean);
  if (Number.isInteger(numeric) && numeric >= 1 && numeric <= options.length) {
    return numeric - 1;
  }

  const normalized = clean.toLowerCase();
  const matchedIdx = options.findIndex((o) => o.trim().toLowerCase() === normalized);
  return matchedIdx >= 0 ? matchedIdx : 0;
}

/**
 * Parses CSV, TSV (Excel copy-paste), Pipe-delimited, or structured Word-style multi-line question blocks:
 * Formats supported:
 * 1) Tabular (CSV / TSV / Pipe):
 *    Question | Option1 | Option2 | Option3 | Option4 | Correct(1-4 / A-D / أ-د / ExactText) | Explanation(optional)
 * 2) Word / Block format separated by blank lines:
 *    س: نص السؤال...
 *    أ) الاختيار الأول
 *    ب) الاختيار الثاني
 *    ج) الاختيار الثالث
 *    د) الاختيار الرابع
 *    الإجابة: ب
 *    التفسير: ...
 */
export function parseBulkQuestionsText(rawInput: string): BulkQuestionParseResult {
  const text = String(rawInput || '').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').trim();
  if (!text) {
    return { questions: [], errors: ['النص المدخل فارغ — الصق الأسئلة أو ارفع ملف CSV/TSV أولاً.'] };
  }

  const lines = text.split('\n').map((l) => l.trim());
  const nonEmptyLines = lines.filter(Boolean);
  if (nonEmptyLines.length === 0) {
    return { questions: [], errors: ['لم يتم العثور على أسطر صالحة.'] };
  }

  // Detect tabular vs Word block mode
  const sampleFirst = nonEmptyLines[0];
  const isTabular =
    sampleFirst.includes('\t') ||
    sampleFirst.includes('|') ||
    (sampleFirst.includes(',') && splitDelimitedLine(sampleFirst, ',').length >= 4);

  const questions: QuizQuestion[] = [];
  const errors: string[] = [];

  if (isTabular) {
    const delimiter = sampleFirst.includes('\t') ? '\t' : sampleFirst.includes('|') ? '|' : ',';
    nonEmptyLines.forEach((line, idx) => {
      const cells = splitDelimitedLine(line, delimiter);
      // Skip header row automatically
      if (
        idx === 0 &&
        /^(question|السؤال|نص السؤال)/i.test(cells[0] || '')
      ) {
        return;
      }
      if (cells.length < 4 || !cells[0]) {
        errors.push(`السطر ${idx + 1}: عدد الأعمدة غير كافٍ (المطلوب: السؤال + 4 اختيارات + الإجابة الصحيحة).`);
        return;
      }

      const question = cells[0];
      const options = [cells[1], cells[2], cells[3], cells[4]].filter((o) => o !== undefined && o !== '');
      if (options.length < 2) {
        errors.push(`السطر ${idx + 1}: يجب توفير اختيارين على الأقل.`);
        return;
      }
      while (options.length < 4 && cells.length >= 5) {
        options.push('-');
      }

      const answerCell = cells[5] ?? cells[cells.length - 1] ?? '1';
      const explanation = cells[6] || 'تمت إضافة التفسير عند الاستيراد الجماعي.';
      const correctOptionIndex = resolveCorrectIndex(answerCell, options);

      questions.push({
        id: `q-bulk-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
        questionType: 'mcq',
        question,
        options,
        correctOptionIndex,
        explanation,
        points: 2,
      });
    });

    return { questions, errors };
  }

  // Word-paste structured blocks separated by blank lines or "س:" / numbered questions
  const blocks: string[][] = [];
  let currentBlock: string[] = [];
  for (const line of lines) {
    if (!line) {
      if (currentBlock.length > 0) {
        blocks.push(currentBlock);
        currentBlock = [];
      }
    } else if (/^(س\s*\d*\s*[:\-]|Q\s*\d*\s*[:\-.]|\d+\s*[\.\)\-])\s+/i.test(line) && currentBlock.length >= 3) {
      blocks.push(currentBlock);
      currentBlock = [line];
    } else {
      currentBlock.push(line);
    }
  }
  if (currentBlock.length > 0) blocks.push(currentBlock);

  blocks.forEach((blk, bIdx) => {
    const qLine = blk[0]
      .replace(/^(سؤال\s*\d*\s*[:\-]|س\s*\d*\s*[:\-]|Q\s*\d*\s*[:\-.]|\d+\s*[\.\)\-])\s*/i, '')
      .trim();

    const options: string[] = [];
    let answerRaw = '';
    let explanation = '';

    for (let i = 1; i < blk.length; i++) {
      const l = blk[i];
      if (/^(الإجابة|الاجابة|الجواب|Answer|Correct)\s*[:\-]/i.test(l)) {
        answerRaw = l.replace(/^(الإجابة|الاجابة|الجواب|Answer|Correct)\s*[:\-]\s*/i, '').trim();
      } else if (/^(التفسير|الشرح|Explanation)\s*[:\-]/i.test(l)) {
        explanation = l.replace(/^(التفسير|الشرح|Explanation)\s*[:\-]\s*/i, '').trim();
      } else {
        const cleanedOpt = l.replace(/^([A-Da-dأبجدهـ1-4][\)\.\:\-])\s*/, '').trim();
        if (cleanedOpt) options.push(cleanedOpt);
      }
    }

    if (!qLine || options.length < 2) {
      errors.push(`الفقرة ${bIdx + 1}: تعذر استخراج السؤال أو الاختيارات (تأكد من وجود السؤال والاختيارات في أسطر منفصلة).`);
      return;
    }

    const correctOptionIndex = resolveCorrectIndex(answerRaw || '1', options);
    questions.push({
      id: `q-word-${Date.now()}-${bIdx}-${Math.random().toString(36).slice(2, 5)}`,
      questionType: 'mcq',
      question: qLine,
      options: options.slice(0, 4),
      correctOptionIndex,
      explanation: explanation || 'راجع الشرح المرتبط بهذا السؤال.',
      points: 2,
    });
  });

  return { questions, errors };
}

export function downloadBulkQuestionsSampleCsv(): void {
  const csvRows = [
    ['السؤال', 'الاختيار 1', 'الاختيار 2', 'الاختيار 3', 'الاختيار 4', 'الإجابة الصحيحة (رقم أو حرف)', 'التفسير'],
    ['ما هو ناتج 5 + 3 × 2 ؟', '16', '11', '13', '10', '2', 'أولوية العمليات الحسابية تبدأ بالضرب قبل الجمع: 3×2=6 ثم +5=11'],
    ['تُسمى القوة التي تقاوم حركة الأجسام المتلامسة بـ:', 'الجاذبية', 'الاحتكاك', 'القصور الذاتي', 'الدفع', 'ب', 'الاحتكاك قوة تنشأ بين سطحي جسمين متلامسين وتعاكس الحركة'],
  ];
  const content =
    '\uFEFF' +
    csvRows
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'alsharif-bulk-questions-template.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
