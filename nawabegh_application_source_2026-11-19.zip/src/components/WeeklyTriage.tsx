import React, { useState } from 'react';
import {
  AlertTriangle,
  Award,
  BellRing,
  Send,
  CheckCircle2,
  Phone,
  MessageSquare,
  Calendar,
  FileCheck,
  Sparkles,
  Users,
  Clock,
  ArrowUpRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Student, Language } from '../types';

interface WeeklyTriageProps {
  students: Student[];
  language: Language;
  onNavigateToChat: (studentId: string) => void;
  onIssueCertificate: (student: Student) => void;
  onSendAlert: (title: string, message: string, target: any) => void;
  readOnly?: boolean;
}

export const WeeklyTriage: React.FC<WeeklyTriageProps> = ({
  students,
  language,
  onNavigateToChat,
  onIssueCertificate,
  onSendAlert,
  readOnly = false,
}) => {
  const isAr = language === 'ar';

  const [activeTab, setActiveTab] = useState<'weak' | 'top'>('weak');

  // Track simulated sent notifications
  const [notifiedStudents, setNotifiedStudents] = useState<Record<string, string>>({});
  const [batchSentStatus, setBatchSentStatus] = useState<string | null>(null);

  const weakStudents = students.filter((s) => s.status === 'weak' || s.overallScore < 60 || s.attendanceRate < 70);
  const topStudents = students.filter((s) => s.status === 'top' || s.overallScore >= 90);

  const handleNotifySingle = (student: Student, type: 'weak' | 'top') => {
    const timestamp = new Date().toLocaleTimeString(isAr ? 'ar-SA' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });

    setNotifiedStudents((prev) => ({
      ...prev,
      [student.id]: timestamp,
    }));

    if (type === 'weak') {
      onSendAlert(
        isAr ? `تنبيه أكاديمي لولي أمر ${student.name}` : `Academic Notice: ${student.name}`,
        isAr
          ? `نحيطكم علماً بأن الطالب حصل على معدل ${student.overallScore}% ونسبة حضور ${student.attendanceRate}%. يرجى مراجعة إدارة المتابعة لتنسيق حصة تعويضية.`
          : `Student scored ${student.overallScore}% with ${student.attendanceRate}% attendance. Catch-up session required.`,
        'weak_students'
      );
    } else {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
      onSendAlert(
        isAr ? `تهنئة تفوق لولي أمر ${student.name}` : `Honors Congratulations: ${student.name}`,
        isAr
          ? `يسر الأكاديمية تهنئتكم بحصول ابنكم/ابنتكم على نسبة ${student.overallScore}% ودخوله لوحة الشرف الأسبوعية للمتميزين.`
          : `Congratulations! Student scored ${student.overallScore}% and made the weekly honors board.`,
        'top_students'
      );
    }
  };

  const handleBatchNotify = (type: 'weak' | 'top') => {
    const targets = type === 'weak' ? weakStudents : topStudents;
    const now = new Date().toLocaleTimeString(isAr ? 'ar-SA' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });

    const newMap: Record<string, string> = { ...notifiedStudents };
    targets.forEach((s) => {
      newMap[s.id] = now;
    });
    setNotifiedStudents(newMap);

    if (type === 'top') {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.5 },
      });
    }

    setBatchSentStatus(
      isAr
        ? `تم إرسال الإشعارات التلقائية بنجاح إلى جميع أولياء أمور الدفعة (${targets.length} طالب)`
        : `Automated notifications sent successfully to all parents (${targets.length} students)`
    );

    setTimeout(() => {
      setBatchSentStatus(null);
    }, 4500);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>{isAr ? 'منظومة الجرد الأسبوعي للمستويات الدراسية' : 'Weekly Academic Triage System'}</span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isAr
              ? 'فرز آلي أسبوعي للطلاب ضعاف المستوى والطلاب الفائقين مع إرسال إشعارات فورية وتلقائية لأولياء الأمور لتنسيق المتابعة'
              : 'Automated weekly triage for weak & top students with direct parent notifications and coordination'}
          </p>
        </div>

        {/* Global Batch Action */}
        {!readOnly && (
          <button
            onClick={() => handleBatchNotify(activeTab)}
            className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white transition-colors shadow-sm self-start md:self-auto ${
              activeTab === 'weak'
                ? 'bg-rose-600 hover:bg-rose-700'
                : 'bg-amber-600 hover:bg-amber-700'
            }`}
          >
            <BellRing className="w-4 h-4" />
            <span>
              {activeTab === 'weak'
                ? isAr
                  ? 'إرسال تنبيهات جماعية لكافة أولياء أمور الضعاف'
                  : 'Notify All Parents of Struggling Students'
                : isAr
                ? 'إرسال بطاقات تهنئة جماعية لكافة أولياء أمور الفائقين'
                : 'Send Honor Notices to All Top Parents'}
            </span>
          </button>
        )}
      </div>

      {/* Batch Notification Feedback Banner */}
      {batchSentStatus && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs md:text-sm font-semibold flex items-center gap-2.5 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{batchSentStatus}</span>
        </div>
      )}

      {/* Triage Tabs Switcher */}
      <div className="grid grid-cols-2 gap-3 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-xl">
        <button
          onClick={() => setActiveTab('weak')}
          className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs md:text-sm font-black transition-all ${
            activeTab === 'weak'
              ? 'bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-rose-500" />
          <span>{isAr ? 'جرد الطلاب ضعاف المستوى' : 'Struggling Students Triage'}</span>
          <span className="px-1.5 py-0.5 rounded-full text-[11px] bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-mono-numbers">
            {weakStudents.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('top')}
          className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs md:text-sm font-black transition-all ${
            activeTab === 'top'
              ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Award className="w-4 h-4 text-amber-500" />
          <span>{isAr ? 'جرد الطلاب الفائقين (المتميزين)' : 'Honors & Top Students'}</span>
          <span className="px-1.5 py-0.5 rounded-full text-[11px] bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-mono-numbers">
            {topStudents.length}
          </span>
        </button>
      </div>

      {/* Weak Students List */}
      {activeTab === 'weak' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-300 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">
                {isAr ? 'معايير فرز الطلاب ضعاف المستوى لهذا الأسبوع' : 'Struggling Students Triage Criteria'}
              </p>
              <p className="mt-1 leading-relaxed">
                {isAr
                  ? 'تم حصر الطلاب الحاصلين على معدل أقل من 60% في الاختبارات الأسبوعية أو تجاوزت نسبة غيابهم 30%. يتطلب ذلك إشعاراً عاجلاً لولي الأمر وجدولة حصة دعم إضافية.'
                  : 'Students with overall score below 60% or attendance below 70% require immediate parent alert and remediation schedule.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {weakStudents.map((student) => {
              const isNotified = Boolean(notifiedStudents[student.id]);

              return (
                <div
                  key={student.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-base text-slate-900 dark:text-white">
                            {student.name}
                          </span>
                          <span className="text-[11px] font-mono-numbers text-slate-400">
                            {student.code}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          {student.grade} · {student.type === 'online' ? (isAr ? 'أونلاين' : 'Online') : (isAr ? 'سنتر' : 'Center')}
                        </p>
                      </div>

                      <span className="px-2.5 py-1 rounded-lg text-xs font-black bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-300 font-mono-numbers">
                        {student.overallScore}%
                      </span>
                    </div>

                    {/* Stats metrics */}
                    <div className="grid grid-cols-2 gap-2 mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs font-mono-numbers">
                      <div>
                        <span className="text-slate-400 block">{isAr ? 'نسبة الحضور' : 'Attendance'}</span>
                        <span className="font-black text-rose-600 dark:text-rose-400 text-sm">
                          {student.attendanceRate}%
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">{isAr ? 'ولي الأمر' : 'Parent'}</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200 truncate block">
                          {student.parentName}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 leading-relaxed">
                      <span className="font-bold text-slate-700 dark:text-slate-200">
                        {isAr ? 'الملاحظة:' : 'Note:'}
                      </span>{' '}
                      {student.notes}
                    </p>
                  </div>

                  {/* Notification Status & Actions */}
                  <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
                    {isNotified ? (
                      <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/40 p-2 rounded-lg">
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <span>
                          {isAr
                            ? `تم إرسال إشعار التنبيه لولي الأمر (${notifiedStudents[student.id]})`
                            : `Parent notified at ${notifiedStudents[student.id]}`}
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400 font-medium">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{isAr ? 'بانتظار إرسال التنبيه الأسبوعي' : 'Pending weekly alert'}</span>
                      </div>
                    )}

                    {!readOnly && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleNotifySingle(student, 'weak')}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors shadow-xs"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>{isAr ? 'إرسال إشعار فوري لولي الأمر' : 'Send Parent Alert'}</span>
                        </button>

                        <button
                          onClick={() => onNavigateToChat(student.id)}
                          className="flex items-center justify-center gap-1 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold transition-colors"
                          title={isAr ? 'فتح المحادثة المباشرة مع ولي الأمر' : 'Direct Chat'}
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="hidden sm:inline">{isAr ? 'محادثة' : 'Chat'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Top Students List */}
      {activeTab === 'top' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-3">
            <Award className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">
                {isAr ? 'لوحة الشرف الأسبوعية للطلاب الفائقين والمتميزين' : 'Weekly Honors Board'}
              </p>
              <p className="mt-1 leading-relaxed">
                {isAr
                  ? 'تم حصر الطلاب الحاصلين على معدل 90% فأعلى مع نسبة حضور وانضباط استثنائية. يشمل ذلك إرسال بطاقات تهنئة فورية لأولياء الأمور وإصدار شهادات التقدير المعتمدة.'
                  : 'Students with 90%+ scores and exceptional discipline receive automatic congratulatory cards and honors certificates.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {topStudents.map((student) => {
              const isNotified = Boolean(notifiedStudents[student.id]);

              return (
                <div
                  key={student.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-base text-slate-900 dark:text-white">
                            {student.name}
                          </span>
                          <span className="text-[11px] font-mono-numbers text-slate-400">
                            {student.code}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          {student.grade} · {student.type === 'online' ? (isAr ? 'أونلاين' : 'Online') : (isAr ? 'سنتر' : 'Center')}
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-mono-numbers font-black text-sm border border-amber-200 dark:border-amber-800">
                        <Award className="w-4 h-4 text-amber-500 fill-amber-400" />
                        <span>{student.overallScore}%</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs font-mono-numbers">
                      <div>
                        <span className="text-slate-400 block">{isAr ? 'نسبة الانضباط' : 'Discipline'}</span>
                        <span className="font-black text-emerald-600 dark:text-emerald-400 text-sm">
                          {student.attendanceRate}%
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">{isAr ? 'ولي الأمر' : 'Parent'}</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200 truncate block">
                          {student.parentName}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 leading-relaxed">
                      {student.notes}
                    </p>
                  </div>

                  {/* Actions & Honors */}
                  <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
                    {isNotified && (
                      <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/40 p-2 rounded-lg">
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <span>
                          {isAr
                            ? `تم إرسال بطاقة التهنئة لولي الأمر بنجاح (${notifiedStudents[student.id]})`
                            : `Parent congratulations sent (${notifiedStudents[student.id]})`}
                        </span>
                      </div>
                    )}

                    {!readOnly && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleNotifySingle(student, 'top')}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-colors shadow-xs"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{isAr ? 'إرسال بطاقة تهنئة لولي الأمر' : 'Send Congrats'}</span>
                        </button>

                        <button
                          onClick={() => onIssueCertificate(student)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-xs"
                        >
                          <FileCheck className="w-3.5 h-3.5" />
                          <span>{isAr ? 'إصدار شهادة تقدير' : 'Issue Certificate'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
