import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ShieldAlert,
  Lock,
  AlertOctagon,
  Trash2,
  EyeOff,
  ShieldCheck,
  Volume2,
  VolumeX,
  Smartphone,
  Phone,
  LogOut,
} from 'lucide-react';
import { CurrentUser, Language } from '../types';
import { getAuthHeaders } from '../utils/rbac';

/**
 * Generates or retrieves a persistent unique device fingerprint for Device Binding
 */
export function getOrCreateClientDeviceInfo(): {
  deviceId: string;
  deviceLabel: string;
  userAgent: string;
} {
  const storageKey = 'alsharif_device_fingerprint_v1';
  let deviceId = '';
  try {
    deviceId = localStorage.getItem(storageKey) || '';
    if (!deviceId) {
      const randPart = () =>
        Math.random().toString(36).substring(2, 6).toUpperCase() +
        Math.floor(10 + Math.random() * 89);
      deviceId = `DEV-${randPart()}-${randPart()}`;
      localStorage.setItem(storageKey, deviceId);
    }
  } catch {
    deviceId = 'DEV-FALLBACK-SESSION';
  }

  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : 'Browser';
  let browser = 'متصفح ويب';
  if (/Edg\//i.test(ua)) browser = 'Microsoft Edge';
  else if (/Chrome\//i.test(ua)) browser = 'Google Chrome';
  else if (/Firefox\//i.test(ua)) browser = 'Mozilla Firefox';
  else if (/Safari\//i.test(ua) && !/Chrome\//i.test(ua)) browser = 'Apple Safari';

  let os = 'جهاز';
  if (/Windows/i.test(ua)) os = 'Windows PC';
  else if (/Android/i.test(ua)) os = 'هاتف Android';
  else if (/iPhone|iPad|iPod/i.test(ua)) os = 'جهاز iPhone/iPad';
  else if (/Mac OS/i.test(ua)) os = 'Mac';
  else if (/Linux/i.test(ua)) os = 'Linux';

  return {
    deviceId,
    deviceLabel: `${browser} (${os})`,
    userAgent: ua.slice(0, 180),
  };
}

/**
 * Plays a subtle intermittent audio watermark (Speech Synthesis + soft harmonic chime fallback)
 */
export function playAudioWatermarkSample(studentPhoneOrCode?: string, studentName?: string) {
  try {
    // 1. Soft Web Audio API watermark tone (subtle double-pulse)
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioCtx) {
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(528, ctx.currentTime);
      osc.frequency.setValueAtTime(660, ctx.currentTime + 0.14);
      gain.gain.setValueAtTime(0.035, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.36);
    }
  } catch {
    // ignore audio context restrictions
  }

  try {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const digitsSpaced = (studentPhoneOrCode || '')
        .replace(/[^\dA-Za-z]/g, '')
        .slice(-6)
        .split('')
        .join(' ');
      const text = digitsSpaced
        ? `منصة الشريف التعليمية. كود الطالب ${digitsSpaced}`
        : `منصة الشريف التعليمية ${studentName ? `الطالب ${studentName}` : ''}`;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.volume = 0.25; // Low non-intrusive volume that still gets captured in video recordings
      utterance.rate = 1.05;
      utterance.pitch = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  } catch {
    // ignore speech synthesis restrictions
  }
}

interface ScreenProtectionGuardProps {
  currentUser: CurrentUser;
  language: Language;
  onAccountTerminated: (reason: string) => void;
}

export interface WatermarkProps {
  studentName?: string;
  studentCode?: string;
  studentPhone?: string;
  extraLabel?: string;
  opacity?: 'light' | 'medium' | 'strong';
  enableJumpingWatermark?: boolean;
  jumpingIntervalSec?: number;
  enableAudioWatermark?: boolean;
  audioIntervalSec?: number;
}

const JUMPING_POSITIONS = [
  'top-3 right-3',
  'bottom-14 left-4',
  'top-1/3 left-6',
  'bottom-16 right-6',
  'top-14 left-1/3',
  'bottom-1/3 right-8',
];

/**
 * العلامة المائية الرسمية لمنصة الشريف على الدروس والمذكرات
 * 1) شبكة مائلة ثابتة باسم «منصة الشريف»
 * 2) علامة مائية قافزة ومتحركة في زوايا الفيديو كل عدة ثوانٍ برقم هاتف الطالب أو كوده
 * 3) علامة مائية صوتية متقطعة اختيارية لحماية الفيديو من السرقة
 */
export const AlSharifWatermark: React.FC<WatermarkProps> = ({
  studentName,
  studentCode,
  studentPhone,
  extraLabel,
  opacity = 'medium',
  enableJumpingWatermark = true,
  jumpingIntervalSec = 4,
  enableAudioWatermark = false,
  audioIntervalSec = 35,
}) => {
  const [jumpIndex, setJumpIndex] = useState(0);
  const [audioMutedByPreview, setAudioMutedByPreview] = useState(false);

  const opacityClass =
    opacity === 'strong'
      ? 'opacity-[0.16] dark:opacity-[0.20]'
      : opacity === 'light'
      ? 'opacity-[0.08] dark:opacity-[0.11]'
      : 'opacity-[0.12] dark:opacity-[0.15]';

  const stamps = Array.from({ length: 18 });

  // Jumping corner watermark timer (changes corner every jumpingIntervalSec seconds)
  useEffect(() => {
    if (!enableJumpingWatermark) return;
    const ms = Math.max(2, jumpingIntervalSec) * 1000;
    const timer = window.setInterval(() => {
      setJumpIndex((prev) => (prev + 1) % JUMPING_POSITIONS.length);
    }, ms);
    return () => window.clearInterval(timer);
  }, [enableJumpingWatermark, jumpingIntervalSec]);

  // Intermittent Audio Watermark timer
  useEffect(() => {
    if (!enableAudioWatermark || audioMutedByPreview) return;
    const ms = Math.max(15, audioIntervalSec) * 1000;
    const timer = window.setInterval(() => {
      playAudioWatermarkSample(studentPhone || studentCode, studentName);
    }, ms);
    return () => window.clearInterval(timer);
  }, [enableAudioWatermark, audioMutedByPreview, audioIntervalSec, studentPhone, studentCode, studentName]);

  const phoneOrCodeDisplay = studentPhone || studentCode || 'SHARIF-PROTECTED';

  return (
    <div
      className="pointer-events-none select-none absolute inset-0 overflow-hidden z-20 print:opacity-100"
      aria-hidden="true"
    >
      {/* 1. Diagonal Repeating Watermark Grid */}
      <div
        className={`w-[140%] h-[140%] -top-[20%] -left-[20%] absolute grid grid-cols-3 sm:grid-cols-4 gap-8 sm:gap-12 items-center justify-items-center -rotate-24 ${opacityClass}`}
      >
        {stamps.map((_, idx) => (
          <div
            key={idx}
            className="flex flex-col items-center justify-center text-center whitespace-nowrap font-cairo"
          >
            <span className="text-base sm:text-xl md:text-2xl font-black tracking-wider text-emerald-950 dark:text-emerald-200 drop-shadow-xs">
              منصة الشريف
            </span>
            <span className="text-[10px] sm:text-xs font-bold text-rose-800 dark:text-rose-300">
              {studentName
                ? `${studentName} ${studentPhone ? `• 📱 ${studentPhone}` : studentCode ? `(${studentCode})` : ''}`
                : 'حقوق النشر محفوظة — ممنوع التصوير'}
            </span>
            {extraLabel && (
              <span className="text-[9px] font-mono-numbers text-slate-700 dark:text-slate-300">
                {extraLabel}
              </span>
            )}
          </div>
        ))}
      </div>

      {/* 2. Jumping Dynamic Corner Watermark (يقفز في زوايا الفيديو كل عدة ثوانٍ برقم هاتف الطالب وكوده) */}
      {enableJumpingWatermark && (
        <div
          className={`absolute ${JUMPING_POSITIONS[jumpIndex]} transition-all duration-700 ease-in-out px-3 py-1.5 rounded-xl bg-slate-950/60 text-white border border-amber-400/50 backdrop-blur-xs shadow-md flex flex-col gap-0.5 text-[11px] font-cairo`}
        >
          <div className="flex items-center gap-1.5 font-black text-amber-300">
            <span>🛡️ منصة الشريف</span>
            {studentName && <span className="text-white font-bold">• {studentName}</span>}
          </div>
          <div className="flex items-center gap-2 text-[10px] font-mono-numbers text-emerald-300 font-bold">
            <span className="inline-flex items-center gap-1">
              <Phone className="w-2.5 h-2.5 text-amber-400" />
              {phoneOrCodeDisplay}
            </span>
            {studentCode && studentPhone && (
              <span className="text-slate-300">• ID: {studentCode}</span>
            )}
          </div>
        </div>
      )}

      {/* 3. Static Top-Left Official Stamp Badge */}
      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-emerald-950/75 text-white border border-amber-400/50 backdrop-blur-xs shadow-sm flex items-center gap-1.5 text-[11px] font-cairo font-black">
        <span>منصة الشريف</span>
        {studentName && (
          <span className="text-[10px] text-amber-200 font-normal">• {studentName}</span>
        )}
      </div>

      {/* 4. Bottom-Right Stamp + Audio Watermark Test / Toggle Button */}
      <div className="absolute bottom-3 right-3 flex items-center gap-1.5 pointer-events-auto">
        {enableAudioWatermark && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (audioMutedByPreview) {
                setAudioMutedByPreview(false);
                playAudioWatermarkSample(studentPhone || studentCode, studentName);
              } else {
                playAudioWatermarkSample(studentPhone || studentCode, studentName);
              }
            }}
            onContextMenu={(e) => {
              e.preventDefault();
              setAudioMutedByPreview((prev) => !prev);
            }}
            title="علامة مائية صوتية متقطعة نشطة — اضغط لسماع النبضة الصوتية التعريفية"
            className="px-2.5 py-1 rounded-lg bg-amber-500/85 hover:bg-amber-500 text-slate-950 font-cairo font-black text-[10px] flex items-center gap-1 shadow-xs cursor-pointer transition-all"
          >
            {audioMutedByPreview ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3 animate-pulse" />}
            <span>بصمة صوتية: {phoneOrCodeDisplay}</span>
          </button>
        )}
        <div className="pointer-events-none px-2.5 py-1 rounded-lg bg-black/65 text-amber-300 border border-white/15 backdrop-blur-xs text-[10px] font-cairo font-bold">
          علامة مائية متحركة • {phoneOrCodeDisplay}
        </div>
      </div>
    </div>
  );
};

export const ScreenProtectionGuard: React.FC<ScreenProtectionGuardProps> = ({
  currentUser,
  language,
  onAccountTerminated,
}) => {
  const isAr = language === 'ar';
  const [isRecordingDetected, setIsRecordingDetected] = useState(false);
  const [violationCount, setViolationCount] = useState<number>(0);
  const [isAccountDeleted, setIsAccountDeleted] = useState(false);
  const [detectionReason, setDetectionReason] = useState<string>('');
  const [isProcessingViolation, setIsProcessingViolation] = useState(false);
  const [deviceBlockedModal, setDeviceBlockedModal] = useState<{
    blocked: boolean;
    message: string;
    maxDevices: number;
    currentDevicesCount: number;
    blockReasonCode?: 'device_limit_exceeded' | 'ip_changed' | 'geo_changed';
    currentIp?: string;
    currentGeoLabel?: string;
  } | null>(null);
  const lastTriggerRef = useRef<number>(0);

  // التحقق الصارم مما إذا كان المستخدم هو المدير العام / الأدمن العام (Mo-NewFolder)
  // لا يعاقب Mo-NewFolder (الأدمن العام / المدير العام) بأي حال من الأحوال
  const isExemptSuperAdmin =
    Boolean(currentUser.isSuperAdmin) ||
    currentUser.id === 'usr-super-admin' ||
    currentUser.role === 'admin' ||
    String(currentUser.username || '').toLowerCase().includes('mo-newfolder') ||
    String(currentUser.email || '').toLowerCase().includes('mo-newfolder') ||
    String(currentUser.name || '').includes('Mo-NewFolder') ||
    String(currentUser.name || '').includes('الأدمن العام') ||
    String(currentUser.name || '').includes('المدير العام');

  const storageKey = `alsharif_screen_violations_${currentUser.id || currentUser.username || 'guest'}`;

  // التحقق الصارم من الجهاز (جهاز واحد فقط) والـ IP والموقع الجغرافي لجميع الحسابات غير الإدارية
  useEffect(() => {
    if (isExemptSuperAdmin || currentUser.role === 'visitor') {
      setDeviceBlockedModal(null);
      return;
    }

    let cancelled = false;
    const verifyStudentDevice = async () => {
      try {
        const deviceInfo = getOrCreateClientDeviceInfo();
        const clientTimezone =
          typeof Intl !== 'undefined'
            ? Intl.DateTimeFormat().resolvedOptions().timeZone
            : undefined;
        const res = await fetch('/api/content-security/verify-device', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            studentId: currentUser.studentId || currentUser.id,
            name: currentUser.name,
            username: currentUser.username,
            email: currentUser.email,
            phone: currentUser.phone,
            role: currentUser.role,
            isSuperAdmin: Boolean(currentUser.isSuperAdmin),
            clientTimezone,
            ...deviceInfo,
          }),
        });
        if (cancelled) return;
        const data = await res.json().catch(() => ({}));
        if (res.status === 403 || (data.blocked && !data.allowed)) {
          setDeviceBlockedModal({
            blocked: true,
            message:
              data.message ||
              data.error ||
              'تم تقييد فتح الحساب! غير مسموح بفتح الحساب على أكثر من جهاز أو بعد تغيير الـ IP أو الموقع الجغرافي إلا بالتفعيل من قِبل الأدمن.',
            maxDevices: data.maxDevices || 1,
            currentDevicesCount: Array.isArray(data.devices) ? data.devices.length : 1,
            blockReasonCode: data.blockReasonCode,
            currentIp: data.currentIp,
            currentGeoLabel: data.currentGeoLabel,
          });
        } else if (res.ok) {
          setDeviceBlockedModal(null);
        }
      } catch {
        // ignore network errors
      }
    };

    verifyStudentDevice();
    const interval = window.setInterval(verifyStudentDevice, 30000);
    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [currentUser, isExemptSuperAdmin]);

  // مسح أي عقاب أو إنذار سابق على المدير العام (Mo-NewFolder) تلقائياً
  useEffect(() => {
    if (isExemptSuperAdmin) {
      try {
        localStorage.removeItem(storageKey);
        localStorage.removeItem('alsharif_screen_violations_usr-super-admin');
        localStorage.removeItem('alsharif_screen_violations_Mo-NewFolder');
        localStorage.removeItem('alsharif_screen_violations_mo-newfolder');
      } catch {
        // ignore
      }
      setViolationCount(0);
      setIsAccountDeleted(false);
      setIsRecordingDetected(false);

      // تنظيف أي سجل أو إنذار سابق في قاعدة البيانات للمدير العام
      fetch('/api/security/clear-super-admin-penalties', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      }).catch(() => {});
      return;
    }

    try {
      const saved = Number(localStorage.getItem(storageKey) || '0');
      if (!Number.isNaN(saved) && saved > 0) {
        setViolationCount(saved);
      } else {
        setViolationCount(0);
      }
      setIsAccountDeleted(false);
      setIsRecordingDetected(false);
    } catch {
      setViolationCount(0);
    }
  }, [storageKey, isExemptSuperAdmin]);

  const triggerSecurityViolation = useCallback(
    async (reasonAr: string, reasonEn: string, isManualAdminPreview = false) => {
      // إذا كان المستخدم هو المدير العام (Mo-NewFolder) فلا يُعاقب ولا يُنذر أبداً عند التصوير
      if (isExemptSuperAdmin && !isManualAdminPreview) {
        return;
      }

      const now = Date.now();
      if (now - lastTriggerRef.current < 1500) return;
      lastTriggerRef.current = now;

      const reasonText = isAr ? reasonAr : reasonEn;
      setDetectionReason(reasonText);
      setIsRecordingDetected(true);

      // إذا كان المدير العام يضغط زر المعاينة فقط ليرى شكل الشاشة السوداء التي تظهر للطلاب:
      // لا نسجل عليه أي مخالفة ولا نحذف حسابه ولا نرفع العداد نهائياً
      if (isExemptSuperAdmin) {
        setViolationCount(0);
        setIsAccountDeleted(false);
        setIsProcessingViolation(false);
        return;
      }

      setIsProcessingViolation(true);

      // إيقاف الفيديوهات مؤقتاً للمستخدمين غير المعفيين
      try {
        const videos = document.querySelectorAll('video');
        videos.forEach((v) => {
          v.pause();
        });
      } catch {
        // ignore
      }

      let nextCount = violationCount + 1;
      try {
        const stored = Number(localStorage.getItem(storageKey) || '0');
        nextCount = Math.max(nextCount, stored + 1);
        localStorage.setItem(storageKey, String(nextCount));
      } catch {
        // ignore storage errors
      }
      setViolationCount(nextCount);

      try {
        const res = await fetch('/api/security/screen-capture-violation', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getAuthHeaders(currentUser),
          },
          body: JSON.stringify({
            userId: currentUser.id,
            username: currentUser.username,
            email: currentUser.email,
            name: currentUser.name,
            role: currentUser.role,
            studentId: currentUser.studentId,
            teacherId: currentUser.teacherId,
            isSuperAdmin: Boolean(currentUser.isSuperAdmin),
            reason: reasonAr,
            clientViolationCount: nextCount,
          }),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.exempt || data.isSuperAdminExempt) {
            setViolationCount(0);
            setIsAccountDeleted(false);
            return;
          }
          if (typeof data.violationCount === 'number') {
            setViolationCount(data.violationCount);
            try {
              localStorage.setItem(storageKey, String(data.violationCount));
            } catch {
              // ignore
            }
          }
          if (data.accountDeleted || nextCount >= 2) {
            setIsAccountDeleted(true);
            if (currentUser.role !== 'visitor') {
              onAccountTerminated(
                isAr
                  ? 'تم حذف حسابك نهائياً من منصة الشريف بسبب تكرار محاولة تصوير الشاشة بالفيديو.'
                  : 'Your account has been permanently deleted due to repeated screen recording attempts.'
              );
            }
          }
        } else if (nextCount >= 2) {
          setIsAccountDeleted(true);
          if (currentUser.role !== 'visitor') {
            onAccountTerminated(
              isAr
                ? 'تم حذف حسابك نهائياً من منصة الشريف بسبب تكرار محاولة تصوير الشاشة بالفيديو.'
                : 'Your account has been permanently deleted due to repeated screen recording attempts.'
            );
          }
        }
      } catch {
        if (nextCount >= 2) {
          setIsAccountDeleted(true);
          if (currentUser.role !== 'visitor') {
            onAccountTerminated(
              isAr
                ? 'تم حذف حسابك نهائياً من منصة الشريف بسبب تكرار محاولة تصوير الشاشة بالفيديو.'
                : 'Your account has been permanently deleted due to repeated screen recording attempts.'
            );
          }
        }
      } finally {
        setIsProcessingViolation(false);
      }
    },
    [currentUser, isAr, isExemptSuperAdmin, onAccountTerminated, storageKey, violationCount]
  );

  useEffect(() => {
    // المدير العام (Mo-NewFolder) مسموح له بتصوير الفيديوهات والشاشة بحرية تامة دون أي منع أو عقاب
    if (isExemptSuperAdmin) {
      return;
    }

    // 1. Intercept navigator.mediaDevices.getDisplayMedia (Browser Screen Recording / Sharing API)
    const mediaDevices = navigator.mediaDevices as any;
    let origGetDisplayMedia: any = null;

    if (mediaDevices && typeof mediaDevices.getDisplayMedia === 'function') {
      origGetDisplayMedia = mediaDevices.getDisplayMedia.bind(mediaDevices);
      mediaDevices.getDisplayMedia = async () => {
        triggerSecurityViolation(
          'محاولة تشغيل تصوير أو مشاركة الشاشة بالفيديو (getDisplayMedia)',
          'Attempted screen video capture (getDisplayMedia)'
        );
        throw new DOMException(
          'Screen recording is strictly prohibited on Al-Sharif Platform',
          'NotAllowedError'
        );
      };
    }

    // 2. Intercept Keyboard Screen Recording & Capture Shortcuts for non-exempt users
    const handleKeyDown = (e: KeyboardEvent) => {
      const keyLower = (e.key || '').toLowerCase();

      if (e.key === 'PrintScreen' || e.code === 'PrintScreen') {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityViolation(
          'محاولة التقاط أو تصوير الشاشة عبر زر PrintScreen',
          'Screen capture key (PrintScreen) detected'
        );
        return;
      }

      if (e.metaKey && e.altKey && keyLower === 'r') {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityViolation(
          'محاولة بدء تسجيل فيديو للشاشة (Win+Alt+R)',
          'Screen video recorder shortcut (Win+Alt+R) detected'
        );
        return;
      }

      if (
        (e.metaKey || e.ctrlKey) &&
        e.shiftKey &&
        (keyLower === '5' || keyLower === '4' || keyLower === '3' || keyLower === 'r')
      ) {
        e.preventDefault();
        e.stopPropagation();
        triggerSecurityViolation(
          'محاولة تشغيل أداة تسجيل فيديو الشاشة (اختصار التصوير)',
          'Screen recording shortcut detected'
        );
        return;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'PrintScreen' || e.code === 'PrintScreen') {
        e.preventDefault();
        try {
          navigator.clipboard?.writeText('ممنوع السرقه - منصة الشريف');
        } catch {
          // ignore
        }
        triggerSecurityViolation('محاولة التقاط الشاشة', 'Screen capture detected');
      }
    };

    // 3. Enforce disablePictureInPicture and nodownload on all video elements
    const protectVideos = () => {
      const videos = document.querySelectorAll('video');
      videos.forEach((v) => {
        v.setAttribute('controlsList', 'nodownload noplaybackrate');
        v.setAttribute('disablePictureInPicture', 'true');
        (v as any).disablePictureInPicture = true;
      });
    };

    const observer = new MutationObserver(() => {
      protectVideos();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    protectVideos();

    // 4. Prevent contextmenu on video/canvas/protected elements
    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'VIDEO' || target.closest('.protected-lesson-area'))) {
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    window.addEventListener('keyup', handleKeyUp, true);
    window.addEventListener('contextmenu', handleContextMenu, true);

    return () => {
      if (mediaDevices && origGetDisplayMedia) {
        mediaDevices.getDisplayMedia = origGetDisplayMedia;
      }
      observer.disconnect();
      window.removeEventListener('keydown', handleKeyDown, true);
      window.removeEventListener('keyup', handleKeyUp, true);
      window.removeEventListener('contextmenu', handleContextMenu, true);
    };
  }, [triggerSecurityViolation, isExemptSuperAdmin]);

  return (
    <>
      {/* Floating Security Shield Status in bottom-left corner (shown only when a capture/theft attempt occurs) */}
      {(isRecordingDetected || violationCount > 0) && (
        <div className="fixed bottom-4 left-4 z-40 print:hidden flex items-center gap-1.5">
          <button
            type="button"
            onClick={() =>
              triggerSecurityViolation(
                'معاينة شاشة الحماية السوداء (ممنوع السرقه)',
                'Preview Anti-Recording Blackout Screen',
                true
              )
            }
            title={
              isExemptSuperAdmin
                ? 'المدير العام (Mo-NewFolder) معفى تماماً من العقاب والإنذار — اضغط لمعاينة الشاشة السوداء التي تظهر للطلاب فقط'
                : 'نظام منع تصوير الشاشة بالفيديو (يعرض الشاشة السوداء باللون الأحمر: ممنوع السرقه)'
            }
            className={`group flex items-center gap-2 px-3 py-2 rounded-2xl text-white border shadow-lg backdrop-blur-md transition-all cursor-pointer text-xs font-cairo ${
              isExemptSuperAdmin
                ? 'bg-slate-950/90 hover:bg-black border-emerald-500/60'
                : 'bg-slate-950/90 hover:bg-black border-red-600/60'
            }`}
          >
            {isExemptSuperAdmin ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            ) : (
              <EyeOff className="w-3.5 h-3.5 text-red-500" />
            )}
            <span className="font-bold text-[11px]">
              {isExemptSuperAdmin
                ? isAr
                  ? 'حماية التصوير (المدير العام Mo-NewFolder معفى من العقاب)'
                  : 'Super Admin Exempt (Preview Only)'
                : isAr
                ? 'تم رصد محاولة تصوير الشاشة'
                : 'Screen Capture Attempt Detected'}
            </span>
            {!isExemptSuperAdmin && violationCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-md bg-red-600 text-white text-[10px] font-mono-numbers font-black">
                {violationCount}/2
              </span>
            )}
          </button>
        </div>
      )}

      {/* DEVICE / IP / GEO LOCK OVERLAY FOR NON-ADMIN ACCOUNTS */}
      {deviceBlockedModal?.blocked && !isExemptSuperAdmin && (
        <div className="fixed inset-0 z-[99990] bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-6 text-center font-cairo">
          <div className="max-w-lg w-full bg-slate-900 border-2 border-amber-500/70 rounded-3xl p-7 shadow-2xl space-y-5 text-white">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center mx-auto text-amber-400">
              <Smartphone className="w-8 h-8" />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-amber-400">
              {deviceBlockedModal.blockReasonCode === 'ip_changed'
                ? isAr
                  ? 'تم إيقاف الحساب لتغيير عنوان الـ IP'
                  : 'Blocked: IP Address Changed'
                : deviceBlockedModal.blockReasonCode === 'geo_changed'
                ? isAr
                  ? 'تم إيقاف الحساب للانتقال الجغرافي خارج النطاق المعتمد'
                  : 'Blocked: Geographic Relocation Detected'
                : isAr
                ? 'الحساب مرتبط بجهاز آخر — يلزم تفعيل الأدمن'
                : 'Device Limit Reached — Admin Activation Required'}
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed font-tajawal">
              {deviceBlockedModal.message}
            </p>
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 space-y-1.5">
              <div className="flex items-center justify-between">
                <span>{isAr ? 'الحد المسموح بدون تفعيل:' : 'Allowed Devices:'}</span>
                <span className="font-mono-numbers font-black text-amber-400">
                  {deviceBlockedModal.maxDevices}{' '}
                  {deviceBlockedModal.maxDevices === 1
                    ? isAr
                      ? 'جهاز واحد فقط'
                      : 'device only'
                    : isAr
                    ? 'أجهزة'
                    : 'devices'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>{isAr ? 'بصمة هذا الجهاز:' : 'Current Device ID:'}</span>
                <span className="font-mono-numbers font-bold text-emerald-400">
                  {getOrCreateClientDeviceInfo().deviceId}
                </span>
              </div>
              {deviceBlockedModal.currentIp && (
                <div className="flex items-center justify-between">
                  <span>{isAr ? 'عنوان الـ IP الحالي:' : 'Current IP:'}</span>
                  <span className="font-mono-numbers font-bold text-rose-400" dir="ltr">
                    {deviceBlockedModal.currentIp}
                  </span>
                </div>
              )}
              {deviceBlockedModal.currentGeoLabel && (
                <div className="flex items-center justify-between gap-2">
                  <span>{isAr ? 'النطاق الجغرافي المرصود:' : 'Detected Location:'}</span>
                  <span className="font-bold text-amber-300 truncate">
                    {deviceBlockedModal.currentGeoLabel}
                  </span>
                </div>
              )}
            </div>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => onAccountTerminated(deviceBlockedModal.message)}
                className="px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-2 cursor-pointer transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>{isAr ? 'تسجيل الخروج والعودة للرئيسية' : 'Sign Out'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULL-SCREEN SOLID BLACK OVERLAY WITH RED "ممنوع السرقه" WHEN RECORDING IS DETECTED */}
      {isRecordingDetected && (
        <div
          className="fixed inset-0 z-[99999] bg-black flex flex-col items-center justify-center p-6 text-center select-none font-cairo"
          style={{ backgroundColor: '#000000' }}
        >
          <div className="max-w-2xl w-full space-y-6 flex flex-col items-center">
            {isExemptSuperAdmin && (
              <div className="px-4 py-2 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-300 text-xs font-bold flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  معاينة للمدير العام (Mo-NewFolder — الأدمن العام): حسابك معفى ومحصّن تماماً ولا يُسجَّل عليك أي إنذار أو عقاب أو حذف.
                </span>
              </div>
            )}

            {/* Flashing Red Siren Icon */}
            <div className="w-24 h-24 rounded-full bg-red-950/80 border-4 border-red-600 flex items-center justify-center animate-pulse shadow-[0_0_60px_rgba(220,38,38,0.8)]">
              {isAccountDeleted && !isExemptSuperAdmin ? (
                <Trash2 className="w-12 h-12 text-red-500" />
              ) : (
                <AlertOctagon className="w-12 h-12 text-red-500" />
              )}
            </div>

            {/* Huge Red "ممنوع السرقه" Text so any video recording only records this on the black screen */}
            <h1
              className="text-5xl sm:text-7xl md:text-8xl font-black tracking-wide text-red-600 drop-shadow-[0_0_25px_rgba(220,38,38,0.95)]"
              style={{ color: '#ef4444' }}
            >
              ممنوع السرقه
            </h1>

            <p
              className="text-xl sm:text-2xl md:text-3xl font-black text-red-500"
              style={{ color: '#dc2626' }}
            >
              {isExemptSuperAdmin
                ? 'هذه معاينة لشاشة الحماية التي تظهر للطالب عند محاولة تصوير الفيديو'
                : isAccountDeleted
                ? 'تم حذف حسابك نهائياً من المنصة كلها لتكرار محاولة تصوير الشاشة!'
                : 'تحذير نهائي: ممنوع تصوير دروس ومحتوى منصة الشريف بالفيديو!'}
            </p>

            <div className="p-5 rounded-2xl bg-red-950/40 border-2 border-red-600/80 text-red-400 space-y-2.5 max-w-xl w-full">
              {isExemptSuperAdmin ? (
                <p className="text-xs sm:text-sm font-bold text-emerald-300 leading-relaxed">
                  أنت مسجل الدخول بصلاحية المدير العام (Mo-NewFolder — الأدمن العام). يمكنك تصوير الفيديوهات والشاشة بحرية تامة دون أي عقاب أو إنذار أو حذف للحساب.
                </p>
              ) : (
                <>
                  <div className="flex items-center justify-center gap-2 text-sm sm:text-base font-black text-red-500">
                    <ShieldAlert className="w-5 h-5 shrink-0" />
                    <span>
                      {isAr
                        ? `المخالفة الأمنية رقم (${violationCount} من 2) — ${detectionReason}`
                        : `Security Strike (${violationCount} of 2) — ${detectionReason}`}
                    </span>
                  </div>

                  {isAccountDeleted ? (
                    <p className="text-xs sm:text-sm font-bold text-red-300 leading-relaxed">
                      {isAr
                        ? 'لقد قمت بتكرار محاولة تصوير الشاشة بالفيديو رغم التحذير السابق. تم تلقائياً حذف حسابك وبياناتك بالكامل من قاعدة بيانات منصة الشريف وإبلاغ الإدارة العامة.'
                        : 'You repeated the screen recording attempt after the first warning. Your account has been permanently deleted from Al-Sharif Platform.'}
                    </p>
                  ) : (
                    <p className="text-xs sm:text-sm font-bold text-red-300 leading-relaxed">
                      {isAr
                        ? 'تم تعتيم الشاشة بالكامل لمنع تسجيل الفيديو. في حال تكرار محاولة تصوير الشاشة مرة أخرى سيتم حذف حسابك فوراً ونهائياً من المنصة كلها!'
                        : 'Screen blacked out to block video capture. If you repeat this attempt, your account will be permanently deleted from the entire platform!'}
                    </p>
                  )}
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
              {!isAccountDeleted || isExemptSuperAdmin ? (
                <button
                  type="button"
                  disabled={isProcessingViolation}
                  onClick={() => setIsRecordingDetected(false)}
                  className="px-6 py-3 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-cairo font-black text-sm shadow-lg transition-all cursor-pointer flex items-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>
                    {isExemptSuperAdmin
                      ? isAr
                        ? 'إغلاق شاشة المعاينة والعودة للوحة المدير العام'
                        : 'Close Preview'
                      : isAr
                      ? 'أتعهد بعدم تصوير الشاشة مرة أخرى (إغلاق التحذير)'
                      : 'I understand — Close Warning'}
                  </span>
                </button>
              ) : (
                <div className="space-y-3 text-center">
                  <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-red-600 text-white font-black text-sm">
                    <Trash2 className="w-4 h-4" />
                    <span>
                      {isAr
                        ? 'تم إلغاء وحذف الحساب من المنصة بالكامل'
                        : 'Account Permanently Deleted from Platform'}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
