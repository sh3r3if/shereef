import React, { useRef, useState, useEffect } from 'react';
import {
  PenTool,
  Eraser,
  Square,
  Circle,
  Minus,
  RotateCcw,
  Trash2,
  Download,
  Sparkles,
  Radio,
  Users,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Share2,
  Hand,
  MessageSquare,
  Send,
  Sliders,
  Check,
  Eye,
  Volume2,
  VolumeX,
  Shield,
  Lock,
  Key,
  Copy,
  CheckCircle2,
  Play,
  Pause,
  RefreshCw,
  AlertCircle,
  Clock,
  Activity,
  UserCheck,
  UserPlus,
  HelpCircle,
  X,
  Volume1,
  Sparkle,
  Wifi,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, CurrentUser } from '../types';
import { realtimeSync, SyncStroke } from '../services/realtimeSync';

interface InteractiveWhiteboardProps {
  language: Language;
  currentUser?: CurrentUser;
  onLogActivity?: (action: string, entity: string, details: string) => void;
}

type ToolType = 'pen' | 'highlighter' | 'eraser' | 'line' | 'rect' | 'circle' | 'arrow';
type BoardTheme = 'chalkboard' | 'whiteboard' | 'grid';

interface LiveParticipant {
  id: string;
  name: string;
  role: 'teacher' | 'student';
  type: 'online' | 'center';
  avatar?: string;
  isMuted: boolean;
  hasRaisedHand: boolean;
  handRaiseTopic?: string;
  isStreamingVideo: boolean;
  audioLevel: number; // 0 to 100
}

const INITIAL_PARTICIPANTS: LiveParticipant[] = [];

export const InteractiveWhiteboard: React.FC<InteractiveWhiteboardProps> = ({
  language,
  currentUser,
  onLogActivity,
}) => {
  const isAr = language === 'ar';
  const isSuperAdmin =
    currentUser?.isSuperAdmin ||
    currentUser?.username === 'Mo-NewFolder' ||
    currentUser?.role === 'admin';

  // 1. WEBSOCKET REAL-TIME SYNC STATE
  const [isWsConnected, setIsWsConnected] = useState<boolean>(realtimeSync.isConnected);
  const [connectedDevicesCount, setConnectedDevicesCount] = useState<number>(realtimeSync.connectedClients || 1);
  const [syncToastMessage, setSyncToastMessage] = useState<string | null>(null);

  // 2. ACCESS CODE SECURITY STATE (Set by Super Admin)
  const [accessCode, setAccessCode] = useState<string>('NW-2026');
  const [isUnlocked, setIsUnlocked] = useState<boolean>(isSuperAdmin); // Super admin enters automatically
  const [enteredCode, setEnteredCode] = useState<string>('');
  const [codeError, setCodeError] = useState<string>('');
  const [isEditingCodeModalOpen, setIsEditingCodeModalOpen] = useState<boolean>(false);
  const [newCodeInput, setNewCodeInput] = useState<string>(accessCode);
  const [codeCopiedToast, setCodeCopiedToast] = useState<boolean>(false);

  // 3. LIVE SESSION TIMER STATE
  const [sessionSeconds, setSessionSeconds] = useState<number>(34 * 60 + 20); // starts at 34m 20s
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);
  const [timerMode, setTimerMode] = useState<'elapsed' | 'countdown'>('elapsed');
  const TARGET_DURATION = 45 * 60; // 45 minutes target

  // 4. PARTICIPANTS & ATTENDEES STATE
  const [participants, setParticipants] = useState<LiveParticipant[]>(INITIAL_PARTICIPANTS);
  const [isAttendeesDrawerOpen, setIsAttendeesDrawerOpen] = useState<boolean>(false);
  const [activeHandAlert, setActiveHandAlert] = useState<{
    studentName: string;
    studentId: string;
    topic: string;
  } | null>(null);

  // 5. STUDENT RAISE HAND DIALOG & STATE
  const [myHandRaised, setMyHandRaised] = useState<boolean>(false);
  const [isRaiseHandModalOpen, setIsRaiseHandModalOpen] = useState<boolean>(false);
  const [raiseHandTopic, setRaiseHandTopic] = useState<string>('استفسار حول خطوات حل المسألة الحالية');

  // 6. AUDIO WAVEFORM & VOLUME METER STATE
  const [isMicOn, setIsMicOn] = useState<boolean>(true);
  const [isVideoOn, setIsVideoOn] = useState<boolean>(true);
  const [volumeLevel, setVolumeLevel] = useState<number>(68); // 0 to 100
  const [frequencyBars, setFrequencyBars] = useState<number[]>([
    12, 28, 45, 62, 78, 85, 92, 70, 54, 42, 60, 75, 88, 65, 48, 35, 52, 69, 84, 73, 58, 41, 30, 22,
  ]);
  const waveformCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // 7. CANVAS & DRAWING TOOLS STATE
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const currentStrokePoints = useRef<{ x: number; y: number }[]>([]);
  const [currentTool, setCurrentTool] = useState<ToolType>('pen');
  const [currentColor, setCurrentColor] = useState<string>('#ffffff');
  const [penSize, setPenSize] = useState<number>(3); // 1px to 36px
  const [eraserSize, setEraserSize] = useState<number>(26); // 8px to 80px
  const [boardTheme, setBoardTheme] = useState<BoardTheme>('chalkboard');
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [cursorPos, setCursorPos] = useState<{ x: number; y: number } | null>(null);
  const [history, setHistory] = useState<ImageData[]>([]);

  // 8. LIVE CHAT STATE
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<{ sender: string; text: string; time: string }[]>([
    {
      sender: 'أ. د. طارق عبد الرحمن',
      text: 'أهلاً بكم في جلسة المراجعة التفاعلية المباشرة، سنبدأ بتطبيق قاعدة السلسلة.',
      time: '04:02 م',
    },
    {
      sender: 'سارة الشمري',
      text: 'الصوت والسبورة واضحين جداً يا أستاذ 👍',
      time: '04:03 م',
    },
  ]);

  // Keep admin unlocked
  useEffect(() => {
    if (isSuperAdmin) {
      setIsUnlocked(true);
    }
  }, [isSuperAdmin]);

  // FLASH SYNC TOAST HELPER
  const flashSyncToast = (msg: string) => {
    setSyncToastMessage(msg);
    setTimeout(() => setSyncToastMessage(null), 3500);
  };

  // DRAW REMOTE STROKE (Received from WebSocket)
  const drawRemoteStroke = (stroke: SyncStroke) => {
    const canvas = canvasRef.current;
    if (!canvas || !stroke || !stroke.points || stroke.points.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (stroke.tool === 'eraser') {
      ctx.strokeStyle = boardTheme === 'chalkboard' ? '#0c2e28' : '#ffffff';
      ctx.lineWidth = stroke.size;
    } else if (stroke.tool === 'highlighter') {
      ctx.strokeStyle = stroke.color + '55';
      ctx.lineWidth = stroke.size * 3;
    } else {
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.size;
    }

    if (stroke.points.length === 1) {
      ctx.beginPath();
      ctx.arc(stroke.points[0].x, stroke.points[0].y, stroke.size / 2, 0, Math.PI * 2);
      ctx.fillStyle = ctx.strokeStyle;
      ctx.fill();
    } else if (['pen', 'highlighter', 'eraser'].includes(stroke.tool)) {
      ctx.beginPath();
      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }
      ctx.stroke();
    } else if (stroke.points.length >= 2) {
      const start = stroke.points[0];
      const end = stroke.points[stroke.points.length - 1];
      if (stroke.tool === 'line') {
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();
      } else if (stroke.tool === 'rect') {
        ctx.strokeRect(start.x, start.y, end.x - start.x, end.y - start.y);
      } else if (stroke.tool === 'circle') {
        const radius = Math.hypot(end.x - start.x, end.y - start.y);
        ctx.beginPath();
        ctx.arc(start.x, start.y, radius, 0, Math.PI * 2);
        ctx.stroke();
      }
    }

    ctx.restore();
    saveState();
  };

  // WEBSOCKET SUBSCRIPTION & SYNC HANDLERS
  useEffect(() => {
    // Connection status listener
    const unsubConn = realtimeSync.on('connection:status', (data) => {
      setIsWsConnected(data.isConnected);
    });

    // Active peers presence
    const unsubPresence = realtimeSync.on('presence:update', (data) => {
      if (data && data.connectedClients) {
        setConnectedDevicesCount(data.connectedClients);
      }
    });

    // Remote stroke drawn on another device
    const unsubStroke = realtimeSync.on('whiteboard:stroke', (data) => {
      if (data && data.stroke) {
        drawRemoteStroke(data.stroke);
        flashSyncToast(isAr ? '⚡ رُسم خط جديد متزامن من جهاز آخر' : '⚡ Synchronized stroke received');
      }
    });

    // Remote clear board
    const unsubClear = realtimeSync.on('whiteboard:clear', () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const rect = canvas.getBoundingClientRect();
      drawBoardBackground(ctx, rect.width, rect.height, boardTheme);
      saveState();
      flashSyncToast(isAr ? '⚡ تم مسح السبورة متزامناً عبر الأجهزة' : '⚡ Whiteboard cleared by peer');
    });

    // Remote undo
    const unsubUndo = realtimeSync.on('whiteboard:undo', () => {
      handleUndoLocal();
      flashSyncToast(isAr ? '⚡ تراجع متزامن عبر الأجهزة' : '⚡ Remote undo received');
    });

    // Remote access code update (by Super Admin on another tab/device)
    const unsubCode = realtimeSync.on('whiteboard:code_update', (data) => {
      if (data && data.code) {
        setAccessCode(data.code);
        flashSyncToast(isAr ? `⚡ تم تحديث رمز الجلسة إلى (${data.code}) فوراً!` : `⚡ Room code updated to (${data.code})`);
      }
    });

    // Remote timer update
    const unsubTimer = realtimeSync.on('whiteboard:timer_update', (data) => {
      if (data && data.timer) {
        setSessionSeconds(data.timer.sessionSeconds);
        setIsTimerRunning(data.timer.isRunning);
      }
    });

    // Remote student raise hand
    const unsubHand = realtimeSync.on('whiteboard:hand_raise', (data) => {
      if (data && data.hand) {
        setActiveHandAlert({
          studentName: data.hand.studentName,
          studentId: data.hand.studentId,
          topic: data.hand.topic,
        });
        setParticipants((prev) => [
          {
            id: data.hand.studentId,
            name: data.hand.studentName,
            role: 'student',
            type: 'online',
            isMuted: true,
            hasRaisedHand: true,
            handRaiseTopic: data.hand.topic,
            isStreamingVideo: true,
            audioLevel: 0,
          },
          ...prev.filter((p) => p.id !== data.hand.studentId),
        ]);
        flashSyncToast(isAr ? `✋ طالب رفع يده: ${data.hand.studentName}` : `✋ Hand raised: ${data.hand.studentName}`);
      }
    });

    // Remote hand lower
    const unsubLower = realtimeSync.on('whiteboard:hand_lower', (data) => {
      if (data && data.studentId) {
        setParticipants((prev) =>
          prev.map((p) => (p.id === data.studentId ? { ...p, hasRaisedHand: false } : p))
        );
        if (data.studentId === activeHandAlert?.studentId) {
          setActiveHandAlert(null);
        }
      }
    });

    // Remote hand permit
    const unsubPermit = realtimeSync.on('whiteboard:hand_permit', (data) => {
      if (data && data.studentId) {
        setParticipants((prev) =>
          prev.map((p) =>
            p.id === data.studentId ? { ...p, isMuted: false, hasRaisedHand: false, audioLevel: 65 } : p
          )
        );
        setActiveHandAlert(null);
        flashSyncToast(isAr ? `🎙️ سُمح للطالب ${data.studentName || ''} بالمشاركة` : '🎙️ Student granted mic');
      }
    });

    // Remote chat message
    const unsubChat = realtimeSync.on('whiteboard:chat', (data) => {
      if (data && data.message) {
        setChatMessages((prev) => [...prev, data.message]);
      }
    });

    // Initial state on connect
    const unsubInit = realtimeSync.on('init:state', (data) => {
      if (data.whiteboardCode) setAccessCode(data.whiteboardCode);
      if (data.timer) {
        setSessionSeconds(data.timer.sessionSeconds);
        setIsTimerRunning(data.timer.isRunning);
      }
      if (data.connectedClients) {
        setConnectedDevicesCount(data.connectedClients);
      }
      if (data.strokes && data.strokes.length > 0) {
        data.strokes.forEach((s: SyncStroke) => drawRemoteStroke(s));
      }
    });

    return () => {
      unsubConn();
      unsubPresence();
      unsubStroke();
      unsubClear();
      unsubUndo();
      unsubCode();
      unsubTimer();
      unsubHand();
      unsubLower();
      unsubPermit();
      unsubChat();
      unsubInit();
    };
  }, [boardTheme, isAr]);

  // LIVE TIMER TICK EFFECT
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setSessionSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  // AUDIO WAVEFORM ANIMATION EFFECT (Dynamic Speech Cadence Simulation)
  useEffect(() => {
    if (!isMicOn) {
      setVolumeLevel(0);
      setFrequencyBars(new Array(24).fill(4));
      return;
    }

    let animationFrameId: number;
    let phase = 0;

    const animateWaveform = () => {
      phase += 0.08;
      const speechEnvelope = Math.max(
        0.15,
        Math.sin(phase * 0.4) * 0.5 + Math.sin(phase * 0.9) * 0.3 + 0.4
      );

      const newLevel = Math.round(speechEnvelope * 85 + Math.random() * 10);
      setVolumeLevel(newLevel);

      const newBars = Array.from({ length: 24 }).map((_, idx) => {
        const baseHeight = Math.sin(phase + idx * 0.4) * 35 + 45;
        const jitter = (Math.random() - 0.5) * 18;
        return Math.max(6, Math.min(100, Math.round((baseHeight + jitter) * speechEnvelope)));
      });
      setFrequencyBars(newBars);

      const canvas = waveformCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.lineWidth = 2;
          ctx.strokeStyle = '#10b981';
          ctx.beginPath();
          const sliceWidth = canvas.width / 24;
          let x = 0;
          for (let i = 0; i < 24; i++) {
            const v = (newBars[i] / 100) * (canvas.height / 2);
            const y = canvas.height / 2 + (i % 2 === 0 ? v : -v) * 0.8;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
            x += sliceWidth;
          }
          ctx.stroke();
        }
      }

      animationFrameId = requestAnimationFrame(animateWaveform);
    };

    animationFrameId = requestAnimationFrame(animateWaveform);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isMicOn]);

  // CANVAS RESOLUTION & REDRAW (Responsive across resize / orientation)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const syncCanvasSize = (preserveExisting: boolean) => {
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const dpr = window.devicePixelRatio || 1;
      const targetW = Math.round(rect.width * dpr);
      const targetH = Math.round(rect.height * dpr);

      if (canvas.width === targetW && canvas.height === targetH && preserveExisting) return;

      let snapshot: HTMLCanvasElement | null = null;
      if (preserveExisting && canvas.width > 0 && canvas.height > 0) {
        snapshot = document.createElement('canvas');
        snapshot.width = canvas.width;
        snapshot.height = canvas.height;
        const sCtx = snapshot.getContext('2d');
        sCtx?.drawImage(canvas, 0, 0);
      }

      canvas.width = targetW;
      canvas.height = targetH;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      drawBoardBackground(ctx, rect.width, rect.height, boardTheme);
      if (snapshot) {
        ctx.drawImage(snapshot, 0, 0, rect.width, rect.height);
      }
      if (!preserveExisting) {
        saveState();
      }
    };

    syncCanvasSize(false);

    const parent = canvas.parentElement;
    let ro: ResizeObserver | null = null;
    if (parent && typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => syncCanvasSize(true));
      ro.observe(parent);
    }

    return () => {
      ro?.disconnect();
    };
  }, [boardTheme]);

  const drawBoardBackground = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    theme: BoardTheme
  ) => {
    if (theme === 'chalkboard') {
      ctx.fillStyle = '#0c2e28';
      ctx.fillRect(0, 0, width, height);

      ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
      for (let i = 0; i < 400; i++) {
        const x = Math.random() * width;
        const y = Math.random() * height;
        ctx.fillRect(x, y, 1, 1);
      }
    } else if (theme === 'whiteboard') {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
    } else if (theme === 'grid') {
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      const step = 28;
      for (let x = 0; x < width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    }
  };

  const saveState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => [...prev.slice(-15), data]);
  };

  const handleUndoLocal = () => {
    if (history.length <= 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const newHistory = [...history];
    newHistory.pop();
    const previous = newHistory[newHistory.length - 1];
    ctx.putImageData(previous, 0, 0);
    setHistory(newHistory);
  };

  const handleUndo = () => {
    handleUndoLocal();
    realtimeSync.sendWhiteboardUndo();
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    drawBoardBackground(ctx, rect.width, rect.height, boardTheme);
    saveState();
    realtimeSync.sendWhiteboardClear();
  };

  const handleExport = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `nawabegh_live_whiteboard_${Date.now()}.png`;
    link.href = url;
    link.click();
  };

  const insertFormula = (formulaText: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.font = 'bold 22px "Cairo", "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = currentColor;
    ctx.fillText(formulaText, 60, 90);
    ctx.restore();
    saveState();

    // Broadcast formula stroke over WebSocket
    realtimeSync.sendWhiteboardStroke({
      id: `strk-formula-${Date.now()}`,
      tool: 'pen',
      color: currentColor,
      size: 3,
      points: [{ x: 60, y: 90 }],
      text: formulaText,
    });
  };

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    let clientX = 0;
    let clientY = 0;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const pos = getPos(e);
    setIsDrawing(true);
    setStartPos(pos);
    setCursorPos(pos);
    currentStrokePoints.current = [pos];

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (currentTool === 'pen' || currentTool === 'highlighter' || currentTool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    const pos = getPos(e);
    setCursorPos(pos);

    if (!isDrawing || !startPos) return;
    e.preventDefault();
    currentStrokePoints.current.push(pos);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (currentTool === 'eraser') {
      ctx.strokeStyle = boardTheme === 'chalkboard' ? '#0c2e28' : '#ffffff';
      ctx.lineWidth = eraserSize;
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (currentTool === 'highlighter') {
      ctx.strokeStyle = currentColor + '55';
      ctx.lineWidth = penSize * 3;
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (currentTool === 'pen') {
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = penSize;
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    }
  };

  const stopDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !startPos) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const endPos = getPos(e);
    currentStrokePoints.current.push(endPos);

    if (['line', 'rect', 'circle', 'arrow'].includes(currentTool)) {
      ctx.strokeStyle = currentColor;
      ctx.fillStyle = currentColor + '22';
      ctx.lineWidth = penSize;

      if (currentTool === 'line') {
        ctx.beginPath();
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(endPos.x, endPos.y);
        ctx.stroke();
      } else if (currentTool === 'rect') {
        const w = endPos.x - startPos.x;
        const h = endPos.y - startPos.y;
        ctx.strokeRect(startPos.x, startPos.y, w, h);
      } else if (currentTool === 'circle') {
        const radius = Math.hypot(endPos.x - startPos.x, endPos.y - startPos.y);
        ctx.beginPath();
        ctx.arc(startPos.x, startPos.y, radius, 0, Math.PI * 2);
        ctx.stroke();
      } else if (currentTool === 'arrow') {
        const headlen = 14;
        const dx = endPos.x - startPos.x;
        const dy = endPos.y - startPos.y;
        const angle = Math.atan2(dy, dx);
        ctx.beginPath();
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(endPos.x, endPos.y);
        ctx.lineTo(
          endPos.x - headlen * Math.cos(angle - Math.PI / 6),
          endPos.y - headlen * Math.sin(angle - Math.PI / 6)
        );
        ctx.moveTo(endPos.x, endPos.y);
        ctx.lineTo(
          endPos.x - headlen * Math.cos(angle + Math.PI / 6),
          endPos.y - headlen * Math.sin(angle + Math.PI / 6)
        );
        ctx.stroke();
      }
    }

    setIsDrawing(false);
    setStartPos(null);
    saveState();

    // ⚡ BROADCAST STROKE VIA WEBSOCKET TO ALL DEVICES IMMEDIATELY
    if (currentStrokePoints.current.length > 0) {
      realtimeSync.sendWhiteboardStroke({
        id: `strk-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        tool: currentTool,
        color: currentColor,
        size: currentTool === 'eraser' ? eraserSize : penSize,
        points: currentStrokePoints.current,
      });
    }
    currentStrokePoints.current = [];
  };

  // ACCESS CODE VALIDATION HANDLER
  const handleVerifyAccessCode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (enteredCode.trim().toUpperCase() === accessCode.trim().toUpperCase()) {
      setIsUnlocked(true);
      setCodeError('');
      confetti({ particleCount: 40, spread: 60 });
    } else {
      setCodeError(isAr ? 'رمز الدخول غير صحيح! تأكد من الرمز المحدد من الأدمن العام.' : 'Incorrect access code!');
    }
  };

  // SUPER ADMIN SAVE NEW ACCESS CODE
  const handleSaveNewAccessCode = () => {
    if (!newCodeInput.trim()) return;
    const code = newCodeInput.trim().toUpperCase();
    setAccessCode(code);
    setIsEditingCodeModalOpen(false);

    // Broadcast updated code to all connected clients immediately
    realtimeSync.sendWhiteboardCodeUpdate(code, currentUser?.username || 'Mo-NewFolder');

    if (onLogActivity) {
      onLogActivity(
        'تحديث كود أمان السبورة التفاعلية لحظياً',
        code,
        `قام الأدمن العام (Mo-NewFolder) بتعيين رمز الدخول الجديد للجلسة: ${code} (تمت المزامنة عبر WebSockets)`
      );
    }
  };

  // SUPER ADMIN GENERATE RANDOM ACCESS CODE
  const handleGenerateRandomCode = () => {
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const generated = `NW-${randomDigits}`;
    setNewCodeInput(generated);
  };

  // COPY ACCESS CODE
  const handleCopyCode = () => {
    navigator.clipboard?.writeText(accessCode);
    setCodeCopiedToast(true);
    setTimeout(() => setCodeCopiedToast(false), 2500);
  };

  // FORMAT TIME STRING
  const formatTimer = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) {
      return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // STUDENT SUBMITS RAISE HAND
  const handleSubmitRaiseHand = (e: React.FormEvent) => {
    e.preventDefault();
    setMyHandRaised(true);
    setIsRaiseHandModalOpen(false);

    const myName = currentUser?.name || (isAr ? 'طالب (أنت)' : 'Student (You)');
    const myId = currentUser?.id || 'p-me';

    setActiveHandAlert({
      studentName: myName,
      studentId: myId,
      topic: raiseHandTopic,
    });

    setParticipants((prev) => [
      {
        id: myId,
        name: myName,
        role: 'student',
        type: 'online',
        isMuted: true,
        hasRaisedHand: true,
        handRaiseTopic: raiseHandTopic,
        isStreamingVideo: true,
        audioLevel: 0,
      },
      ...prev.filter((p) => p.id !== myId),
    ]);

    // Broadcast hand raise via WebSocket
    realtimeSync.sendHandRaise(myId, myName, raiseHandTopic);
    confetti({ particleCount: 25, spread: 45 });
  };

  // LOWER HAND
  const handleLowerHand = (studentId: string) => {
    setParticipants((prev) =>
      prev.map((p) => (p.id === studentId ? { ...p, hasRaisedHand: false, handRaiseTopic: undefined } : p))
    );
    if (studentId === 'p-me' || studentId === activeHandAlert?.studentId) {
      setMyHandRaised(false);
      setActiveHandAlert(null);
    }
    realtimeSync.sendHandLower(studentId);
  };

  // PERMIT STUDENT TO SPEAK
  const handlePermitStudentSpeak = (studentId: string) => {
    const targetStudent = participants.find((p) => p.id === studentId);
    setParticipants((prev) =>
      prev.map((p) =>
        p.id === studentId
          ? { ...p, isMuted: false, hasRaisedHand: false, audioLevel: 65 }
          : p
      )
    );
    setActiveHandAlert(null);
    realtimeSync.sendHandPermit(studentId, targetStudent?.name || '');
    confetti({ particleCount: 35, spread: 70 });
  };

  // LOWER ALL HANDS
  const handleLowerAllHands = () => {
    setParticipants((prev) => prev.map((p) => ({ ...p, hasRaisedHand: false })));
    setMyHandRaised(false);
    setActiveHandAlert(null);
    realtimeSync.sendHandLowerAll();
  };

  // CHAT HANDLER
  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const now = new Date().toLocaleTimeString(isAr ? 'ar-SA' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const sender = currentUser?.name || (isAr ? 'أنت' : 'You');
    setChatMessages((prev) => [
      ...prev,
      { sender, text: chatInput.trim(), time: now },
    ]);
    realtimeSync.sendChatMessage(sender, chatInput.trim());
    setChatInput('');
  };

  const colors = [
    { label: 'White', value: '#ffffff' },
    { label: 'Gold', value: '#facc15' },
    { label: 'Cyan', value: '#38bdf8' },
    { label: 'Emerald', value: '#34d399' },
    { label: 'Rose', value: '#f87171' },
    { label: 'Purple', value: '#c084fc' },
  ];

  const raisedHandsCount = participants.filter((p) => p.hasRaisedHand).length;

  // -------------------------------------------------------------
  // IF ACCESS LOCKED: DISPLAY SUPER ADMIN SECURITY GATE
  // -------------------------------------------------------------
  if (!isUnlocked) {
    return (
      <div className="min-h-[600px] flex items-center justify-center p-4 font-cairo">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border-2 border-emerald-500/40 shadow-2xl space-y-6 text-center relative overflow-hidden">
          <div className="absolute -top-20 -left-20 w-44 h-44 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />
          <div className="absolute -bottom-20 -right-20 w-44 h-44 rounded-full bg-teal-500/10 blur-2xl pointer-events-none" />

          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30">
            <Lock className="w-10 h-10 animate-pulse" />
          </div>

          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 text-xs font-bold mb-2">
              <Shield className="w-3.5 h-3.5" />
              <span>{isAr ? 'حماية مشددة بإشراف الأدمن العام' : 'Super Admin Protected'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {isAr ? 'السبورة التفاعلية الحية مؤمنة برمز دخول' : 'Live Whiteboard is Protected'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 font-tajawal mt-2 leading-relaxed">
              {isAr
                ? 'يتطلب دخول هذه الجلسة الحية إدخال رمز الوصول الأمني المعتمد من قبل الأدمن العام (Mo-NewFolder). التحديثات متزامنة لحظياً عبر كافة الأجهزة بواسطة خدمة WebSockets.'
                : 'Access to this interactive classroom requires the authorization code set by Super Admin.'}
            </p>
          </div>

          <form onSubmit={handleVerifyAccessCode} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 text-right mb-1.5">
                {isAr ? 'أدخل رمز الجلسة (Session Access Code)' : 'Enter Session Code'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={enteredCode}
                  onChange={(e) => {
                    setEnteredCode(e.target.value);
                    setCodeError('');
                  }}
                  placeholder="مثال: NW-2026"
                  className="w-full text-center tracking-widest font-mono text-xl font-bold uppercase py-3.5 px-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:border-emerald-500 focus:bg-white dark:focus:bg-slate-900 text-slate-900 dark:text-white transition-all outline-none"
                  autoFocus
                />
                <Key className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              {codeError && (
                <p className="text-xs text-rose-600 dark:text-rose-400 font-bold mt-2 flex items-center justify-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{codeError}</span>
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isAr ? 'التحقق والدخول للجلسة الحية' : 'Verify & Enter Live Session'}</span>
            </button>
          </form>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <p className="text-[11px] text-slate-400 font-tajawal mb-2">
              {isAr ? 'رمز الجلسة الافتراضي المحدد من الأدمن العام:' : 'Default session code:'}
            </p>
            <button
              onClick={() => {
                setEnteredCode(accessCode);
                setCodeError('');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 font-mono font-bold text-xs hover:bg-emerald-50 dark:hover:bg-emerald-950 transition-colors"
            >
              <span>{accessCode}</span>
              <span className="text-[10px] text-slate-400 font-tajawal">({isAr ? 'اضغط للتعبئة الفورية' : 'Click to autofill'})</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // UNLOCKED VIEW: FULL LIVE WHITEBOARD WORKSPACE
  // -------------------------------------------------------------
  return (
    <div className="space-y-4 font-cairo">
      {/* Real-time sync floating alert toast */}
      {syncToastMessage && (
        <div className="fixed top-16 inset-x-3 sm:top-20 sm:right-6 sm:left-auto z-50 max-w-sm animate-bounce">
          <div className="bg-emerald-950/95 text-emerald-300 border-2 border-emerald-500/80 px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold backdrop-blur-md">
            <Zap className="w-4 h-4 text-emerald-400 animate-pulse shrink-0" />
            <span>{syncToastMessage}</span>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 1. SUPER ADMIN SESSION CODE BANNER (Visible for Super Admin) */}
      {/* ============================================================ */}
      {isSuperAdmin && (
        <div className="p-3 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 border-2 border-emerald-500/70 rounded-2xl text-white shadow-md flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">
                  {isAr ? 'إدارة كود أمان السبورة الحية (الأدمن العام Mo-NewFolder)' : 'Live Whiteboard Security (Mo-NewFolder)'}
                </span>
                <span className="bg-emerald-500 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full">
                  SUPER ADMIN
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-tajawal">
                {isAr
                  ? 'يحدد الأدمن العام هذا الرمز ويشاركه مع الطلاب للدخول للغرفة التفاعلية. التعديل يتزامن فوراً عبر WebSockets.'
                  : 'Manage and update the student room security PIN.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/90 border border-emerald-500/50">
              <span className="text-slate-400 text-[11px] font-tajawal">{isAr ? 'الرمز النشط:' : 'Active Code:'}</span>
              <span className="font-mono font-black text-sm text-emerald-400 tracking-wider">
                {accessCode}
              </span>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors"
              title="نسخ رمز الجلسة لمشاركته مع الطلاب"
            >
              {codeCopiedToast ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{codeCopiedToast ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ الرمز' : 'Copy Code')}</span>
            </button>

            <button
              onClick={() => {
                setNewCodeInput(accessCode);
                setIsEditingCodeModalOpen(true);
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold transition-colors"
            >
              <Key className="w-3.5 h-3.5" />
              <span>{isAr ? 'تغيير الرمز' : 'Change PIN'}</span>
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 2. LIVE BROADCAST RIBBON (Timer + Audio Waveform + WebSockets Sync) */}
      {/* ============================================================ */}
      <div className="p-3.5 md:p-4 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-800/80 text-white shadow-md flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
        {/* Left/Start: Live Status & Lesson Topic */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center shrink-0">
            <span className="w-3.5 h-3.5 rounded-full bg-red-500 animate-ping absolute" />
            <span className="w-3.5 h-3.5 rounded-full bg-red-600 relative" />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-black text-sm md:text-base text-white">
                {isAr ? 'بث مباشر حي بين المعلم والطلاب (Interactive Live Classroom)' : 'Live Synchronized Classroom'}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-[10px] font-bold">
                LIVE
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono">
                CODE: {accessCode}
              </span>

              {/* WEBSOCKET SYNCHRONIZATION BADGE */}
              <div
                className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                  isWsConnected
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                }`}
                title="حالة خادم المزامنة اللحظية عبر WebSockets"
              >
                <span className={`w-2 h-2 rounded-full ${isWsConnected ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
                <Wifi className="w-3 h-3" />
                <span>
                  {isWsConnected
                    ? (isAr ? `مزامنة WebSockets لحظية (${connectedDevicesCount} أجهزة)` : `WS Synced (${connectedDevicesCount} peers)`)
                    : (isAr ? 'جارِ الاتصال بالخادم...' : 'Connecting WS...')}
                </span>
              </div>
            </div>
            <p className="text-xs text-emerald-200/80 font-tajawal mt-0.5">
              {isAr
                ? 'الحصة المباشرة: حل تمارين التفاضل والتكامل مع أ. د. طارق عبد الرحمن - متزامن على كافة الأجهزة فورياً'
                : 'Active Lecture: Calculus & Geometry with Prof. Tarek - Real-time sync enabled'}
            </p>
          </div>
        </div>

        {/* Middle: LIVE SESSION TIMER */}
        <div className="flex items-center gap-2 bg-slate-900/90 border border-emerald-500/40 rounded-xl px-3 py-1.5 shrink-0 self-start xl:self-center shadow-inner">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isTimerRunning ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <Clock className="w-4 h-4 text-emerald-400" />
            <span className="text-[11px] text-slate-300 font-tajawal hidden sm:inline">
              {timerMode === 'elapsed'
                ? (isAr ? 'عداد وقت الجلسة:' : 'Elapsed Time:')
                : (isAr ? 'الوقت المتبقي:' : 'Remaining:')}
            </span>
          </div>

          <span className="font-mono text-base md:text-lg font-black text-white tracking-wider">
            {timerMode === 'elapsed'
              ? formatTimer(sessionSeconds)
              : formatTimer(Math.max(0, TARGET_DURATION - sessionSeconds))}
          </span>

          <div className="flex items-center gap-1 border-r border-slate-700 pr-1.5 mr-1.5">
            <button
              onClick={() => {
                const next = !isTimerRunning;
                setIsTimerRunning(next);
                realtimeSync.sendWhiteboardTimer({ sessionSeconds, isRunning: next, mode: timerMode });
              }}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              title={isTimerRunning ? 'إيقاف مؤقت' : 'استئناف العداد'}
            >
              {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => {
                setSessionSeconds(0);
                realtimeSync.sendWhiteboardTimer({ sessionSeconds: 0, isRunning: isTimerRunning, mode: timerMode });
              }}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              title="إعادة تعيين العداد للصفر"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
            <button
              onClick={() => {
                const nextMode = timerMode === 'elapsed' ? 'countdown' : 'elapsed';
                setTimerMode(nextMode);
                realtimeSync.sendWhiteboardTimer({ sessionSeconds, isRunning: isTimerRunning, mode: nextMode });
              }}
              className="text-[10px] text-emerald-400 hover:underline font-bold px-1"
              title="التبديل بين عداد تصاعدي ومؤقت تنازلي"
            >
              {timerMode === 'elapsed' ? (isAr ? 'مؤقت 45د' : 'Countdown') : (isAr ? 'عداد تصاعدي' : 'Elapsed')}
            </button>
          </div>
        </div>

        {/* Right/End: AUDIO WAVEFORM + ACTIONS */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Audio Waveform Equalizer Display */}
          <div className="flex items-center gap-2 bg-slate-900/90 border border-emerald-500/40 rounded-xl px-3 py-1.5">
            <div className="flex items-center gap-1">
              <Volume2 className={`w-4 h-4 ${isMicOn ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
              <div className="text-[10px] font-mono-numbers">
                <span className="text-slate-400">{isMicOn ? `${volumeLevel}%` : 'MUTED'}</span>
              </div>
            </div>

            <div className="flex items-end gap-0.5 h-5 w-16 sm:w-28 md:w-36 px-1">
              {frequencyBars.map((height, idx) => (
                <div
                  key={idx}
                  className={`flex-1 rounded-t-xs transition-all duration-75 ${
                    !isMicOn
                      ? 'bg-slate-700'
                      : height > 80
                      ? 'bg-rose-500'
                      : height > 60
                      ? 'bg-amber-400'
                      : height > 35
                      ? 'bg-teal-400'
                      : 'bg-emerald-400'
                  }`}
                  style={{ height: `${height}%` }}
                />
              ))}
            </div>

            <canvas
              ref={waveformCanvasRef}
              width={40}
              height={20}
              className="w-10 h-5 hidden sm:block opacity-80"
            />
          </div>

          {/* Connected Participants Counter */}
          <button
            onClick={() => setIsAttendeesDrawerOpen((p) => !p)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
              isAttendeesDrawerOpen
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
            title="إظهار أسماء الحاضرين في الجلسة"
          >
            <Users className="w-4 h-4" />
            <span>{isAr ? `الحاضرون (${participants.length})` : `Attendees (${participants.length})`}</span>
            {raisedHandsCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[11px] font-black flex items-center justify-center animate-bounce">
                {raisedHandsCount}
              </span>
            )}
          </button>

          {/* Student Raise Hand Button */}
          <button
            onClick={() => {
              if (myHandRaised) {
                handleLowerHand('p-me');
              } else {
                setIsRaiseHandModalOpen(true);
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm ${
              myHandRaised
                ? 'bg-amber-400 text-slate-950 font-black ring-2 ring-amber-300'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold'
            }`}
          >
            <Hand className="w-4 h-4 animate-bounce" />
            <span>
              {myHandRaised
                ? (isAr ? 'تم رفع يدك ✋ (إنزال)' : 'Hand Raised ✋')
                : (isAr ? 'رفع اليد للاستفسار' : 'Raise Hand')}
            </span>
          </button>

          {/* Quick Mic & Video Controls */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsMicOn((p) => !p)}
              className={`p-2 rounded-xl transition-colors ${
                isMicOn ? 'bg-emerald-600/80 hover:bg-emerald-600 text-white' : 'bg-red-600/80 hover:bg-red-600 text-white'
              }`}
              title={isMicOn ? 'كتم المايكروفون' : 'تشغيل المايكروفون'}
            >
              {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setIsVideoOn((p) => !p)}
              className={`p-2 rounded-xl transition-colors ${
                isVideoOn ? 'bg-emerald-600/80 hover:bg-emerald-600 text-white' : 'bg-red-600/80 hover:bg-red-600 text-white'
              }`}
              title={isVideoOn ? 'إيقاف الكاميرا' : 'تشغيل الكاميرا'}
            >
              {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setIsChatOpen((p) => !p)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors relative"
              title="محادثة البث المباشر"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="w-2 h-2 rounded-full bg-emerald-400 absolute top-1 right-1" />
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3. ACTIVE HAND RAISE ALERT BANNER FOR TEACHER/ADMIN */}
      {/* ============================================================ */}
      {activeHandAlert && (
        <div className="p-3 bg-gradient-to-r from-amber-500/20 via-amber-600/20 to-slate-900 border-2 border-amber-500 rounded-2xl flex items-center justify-between gap-3 text-xs animate-pulse">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-base shrink-0">
              ✋
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-amber-900 dark:text-amber-300">
                  {isAr ? 'طلب مشاركة أو استفسار جديد (متزامن عبر WebSockets):' : 'New Question / Hand Raised (Synced):'}
                </span>
                <span className="font-black text-slate-900 dark:text-white">
                  {activeHandAlert.studentName}
                </span>
              </div>
              <p className="text-[11px] text-slate-700 dark:text-slate-300 font-tajawal mt-0.5">
                «{activeHandAlert.topic}»
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => handlePermitStudentSpeak(activeHandAlert.studentId)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 transition-colors"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>{isAr ? 'السماح بالمشاركة والتحدث' : 'Allow Mic'}</span>
            </button>
            <button
              onClick={() => handleLowerHand(activeHandAlert.studentId)}
              className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-300 font-bold transition-colors"
            >
              {isAr ? 'إنزال اليد' : 'Lower Hand'}
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 4. MAIN WHITEBOARD WORKSPACE + ATTENDEES & CHAT DRAWERS */}
      {/* ============================================================ */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm flex flex-col">
        {/* Controls Toolbar with Pen & Eraser Resizing Sliders & WebSocket Indicator */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Tool Segmented Buttons */}
          <div className="flex items-center gap-1 p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setCurrentTool('pen')}
              className={`p-2 rounded-lg transition-colors flex items-center gap-1 font-bold ${
                currentTool === 'pen'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isAr ? 'القلم' : 'Pen'}
            >
              <PenTool className="w-4 h-4" />
              <span className="hidden sm:inline">{isAr ? 'القلم' : 'Pen'}</span>
            </button>

            <button
              onClick={() => setCurrentTool('eraser')}
              className={`p-2 rounded-lg transition-colors flex items-center gap-1 font-bold ${
                currentTool === 'eraser'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isAr ? 'الممحاة' : 'Eraser'}
            >
              <Eraser className="w-4 h-4" />
              <span className="hidden sm:inline">{isAr ? 'الممحاة' : 'Eraser'}</span>
            </button>

            <button
              onClick={() => setCurrentTool('highlighter')}
              className={`p-2 rounded-lg transition-colors ${
                currentTool === 'highlighter'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
              title={isAr ? 'قلم التظليل' : 'Highlighter'}
            >
              <Sparkles className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentTool('line')}
              className={`p-2 rounded-lg transition-colors ${
                currentTool === 'line'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
              title={isAr ? 'خط مستقيم' : 'Line'}
            >
              <Minus className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentTool('rect')}
              className={`p-2 rounded-lg transition-colors ${
                currentTool === 'rect'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
              title={isAr ? 'مستطيل' : 'Rectangle'}
            >
              <Square className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentTool('circle')}
              className={`p-2 rounded-lg transition-colors ${
                currentTool === 'circle'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
              title={isAr ? 'دائرة' : 'Circle'}
            >
              <Circle className="w-4 h-4" />
            </button>
          </div>

          {/* DEDICATED PEN & ERASER RESIZING CONTROLS */}
          <div className="flex items-center gap-3 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
            {currentTool === 'eraser' ? (
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Eraser className="w-3.5 h-3.5 text-rose-500" />
                  <span>{isAr ? 'حجم الممحاة:' : 'Eraser Size:'}</span>
                </span>
                <input
                  type="range"
                  min="8"
                  max="80"
                  value={eraserSize}
                  onChange={(e) => setEraserSize(Number(e.target.value))}
                  className="w-24 accent-rose-500 cursor-pointer"
                />
                <span className="font-mono text-xs font-bold text-rose-500 w-8 text-center">
                  {eraserSize}px
                </span>
                <div className="hidden md:flex items-center gap-1">
                  {[12, 26, 48, 70].map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setEraserSize(sz)}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                        eraserSize === sz
                          ? 'bg-rose-500 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <PenTool className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isAr ? 'سُمك القلم:' : 'Pen Size:'}</span>
                </span>
                <input
                  type="range"
                  min="1"
                  max="36"
                  value={penSize}
                  onChange={(e) => setPenSize(Number(e.target.value))}
                  className="w-24 accent-emerald-600 cursor-pointer"
                />
                <span className="font-mono text-xs font-bold text-emerald-600 w-8 text-center">
                  {penSize}px
                </span>
                <div className="hidden md:flex items-center gap-1">
                  {[2, 4, 10, 20].map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setPenSize(sz)}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                        penSize === sz
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Color Palette */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
            {colors.map((c) => (
              <button
                key={c.value}
                onClick={() => setCurrentColor(c.value)}
                className={`w-6 h-6 rounded-full border border-black/20 transition-transform ${
                  currentColor === c.value ? 'scale-110 ring-2 ring-emerald-500 ring-offset-1' : ''
                }`}
                style={{ backgroundColor: c.value }}
                title={c.label}
              />
            ))}
          </div>

          {/* Themes, Undo & Clear */}
          <div className="flex items-center gap-1.5">
            <select
              value={boardTheme}
              onChange={(e) => setBoardTheme(e.target.value as BoardTheme)}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300"
            >
              <option value="chalkboard">{isAr ? 'سبورة زمردية' : 'Emerald Slate'}</option>
              <option value="whiteboard">{isAr ? 'لوح أبيض' : 'Whiteboard'}</option>
              <option value="grid">{isAr ? 'شبكة هندسية' : 'Grid Sheet'}</option>
            </select>

            <button
              onClick={handleUndo}
              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
              title={isAr ? 'تراجع (متزامن عبر الأجهزة)' : 'Undo (Synced)'}
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={handleClear}
              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-rose-50 text-rose-600 dark:hover:bg-rose-950/40"
              title={isAr ? 'مسح السبورة لكافة الأجهزة' : 'Clear Board (Synced)'}
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={handleExport}
              className="p-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white"
              title={isAr ? 'تصدير كصورة PNG' : 'Save Image'}
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Canvas Area with Drawers */}
        <div className="relative flex flex-1 min-h-[340px] sm:min-h-[460px] lg:min-h-[580px] bg-slate-950 overflow-hidden">
          {/* Main Drawing Canvas */}
          <div className="relative flex-1 h-[340px] sm:h-[460px] lg:h-[580px] cursor-crosshair touch-none">
            <canvas
              ref={canvasRef}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="w-full h-full block touch-none"
            />

            {/* Eraser / Pen dynamic hover cursor circle indicator */}
            {cursorPos && currentTool === 'eraser' && (
              <div
                className="absolute rounded-full border-2 border-rose-400 bg-rose-400/20 pointer-events-none transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: cursorPos.x,
                  top: cursorPos.y,
                  width: `${eraserSize}px`,
                  height: `${eraserSize}px`,
                }}
              />
            )}

            {/* Live Streaming & Sync Badge on Canvas */}
            <div className="absolute top-3 right-3 flex items-center gap-2 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl bg-slate-900/80 backdrop-blur-md text-white text-[10px] sm:text-[11px] font-bold border border-white/10 pointer-events-none">
              <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span>{isAr ? 'مزامنة لحظية نشطة بالـ WebSockets' : 'Real-time WebSocket Sync'}</span>
            </div>

            {/* Educational Formula Quick Buttons */}
            <div className="absolute bottom-3 right-3 left-3 flex items-center gap-1.5 flex-wrap">
              <button
                onClick={() => insertFormula('f(x) = ∫ 2x dx = x² + C')}
                className="px-2 sm:px-2.5 py-1 text-[10px] sm:text-[11px] font-mono-numbers rounded-lg bg-slate-900/80 hover:bg-emerald-800 text-white backdrop-blur-md border border-white/10 transition-colors"
              >
                ∫ 2x dx = x² + C
              </button>
              <button
                onClick={() => insertFormula('a² + b² = c²')}
                className="px-2 sm:px-2.5 py-1 text-[10px] sm:text-[11px] font-mono-numbers rounded-lg bg-slate-900/80 hover:bg-emerald-800 text-white backdrop-blur-md border border-white/10 transition-colors"
              >
                a² + b² = c²
              </button>
              <button
                onClick={() => insertFormula('F = m · a')}
                className="px-2 sm:px-2.5 py-1 text-[10px] sm:text-[11px] font-mono-numbers rounded-lg bg-slate-900/80 hover:bg-emerald-800 text-white backdrop-blur-md border border-white/10 transition-colors"
              >
                F = m · a
              </button>
            </div>
          </div>

          {/* ============================================================ */}
          {/* ATTENDEES DRAWER (إظهار أسماء الحاضرين في جلسة السبورة الحية) */}
          {/* ============================================================ */}
          {isAttendeesDrawerOpen && (
            <div className="absolute inset-0 lg:static lg:w-80 xl:w-96 h-full border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col z-20 shadow-2xl">
              <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/90">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center font-bold">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xs text-slate-900 dark:text-white">
                      {isAr ? 'أسماء الحاضرين في الجلسة الحية' : 'Live Class Attendees'}
                    </h3>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                      {isAr ? `${participants.length} متواجدون الآن` : `${participants.length} Active Participants`}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsAttendeesDrawerOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-2.5 bg-slate-100/60 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-1 text-[11px]">
                <button
                  onClick={handleLowerAllHands}
                  className="flex-1 py-1 px-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 text-slate-700 dark:text-slate-300 font-bold flex items-center justify-center gap-1"
                >
                  <Hand className="w-3 h-3 text-amber-500" />
                  <span>{isAr ? 'إنزال الأيدي' : 'Lower All'}</span>
                </button>
              </div>

              <div className="flex-1 p-3 overflow-y-auto space-y-2 text-xs">
                {participants.map((p) => {
                  const isTeacher = p.role === 'teacher';
                  return (
                    <div
                      key={p.id}
                      className={`p-2.5 rounded-xl border transition-all ${
                        p.hasRaisedHand
                          ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-300 dark:border-amber-700/60 shadow-xs'
                          : isTeacher
                          ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800'
                          : 'bg-white dark:bg-slate-800/60 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="relative shrink-0">
                            <div
                              className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                                isTeacher
                                  ? 'bg-emerald-700 text-white'
                                  : p.hasRaisedHand
                                  ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-300'
                                  : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white'
                              }`}
                            >
                              {p.avatar ? (
                                <img
                                  src={p.avatar}
                                  alt={p.name}
                                  className="w-full h-full rounded-xl object-cover"
                                />
                              ) : (
                                p.name.charAt(0)
                              )}
                            </div>
                            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900 absolute -bottom-0.5 -right-0.5" />
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <h4 className="font-bold text-slate-900 dark:text-white truncate text-xs">
                                {p.name}
                              </h4>
                              {isTeacher ? (
                                <span className="bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 text-[9px] px-1.5 py-0.2 rounded font-bold">
                                  {isAr ? 'المعلم' : 'Host'}
                                </span>
                              ) : (
                                <span className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[9px] px-1.5 py-0.2 rounded font-bold">
                                  {p.type === 'online' ? (isAr ? 'أونلاين' : 'Online') : (isAr ? 'سنتر' : 'Center')}
                                </span>
                              )}
                            </div>
                            {p.hasRaisedHand && (
                              <p className="text-[10px] text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1 mt-0.5">
                                <span>✋</span>
                                <span className="truncate">{p.handRaiseTopic || (isAr ? 'طلب استفسار' : 'Hand Raised')}</span>
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {p.hasRaisedHand && (
                            <button
                              onClick={() => handlePermitStudentSpeak(p.id)}
                              className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] flex items-center gap-1 shadow-xs"
                              title="السماح بالمشاركة والتحدث"
                            >
                              <Mic className="w-3 h-3" />
                              <span>{isAr ? 'سماح' : 'Allow'}</span>
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setParticipants((prev) =>
                                prev.map((item) =>
                                  item.id === p.id ? { ...item, isMuted: !item.isMuted } : item
                                )
                              );
                            }}
                            className={`p-1.5 rounded-lg transition-colors ${
                              p.isMuted
                                ? 'bg-slate-100 dark:bg-slate-700 text-slate-400 hover:text-slate-600'
                                : 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-600'
                            }`}
                            title={p.isMuted ? 'الصوت مكتوم' : 'الصوت نشط'}
                          >
                            {p.isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Interactive Live Chat Drawer */}
          {isChatOpen && (
            <div className="absolute inset-0 lg:static lg:w-72 xl:w-80 h-full border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col z-20 shadow-lg">
              <div className="p-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/80">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-emerald-600" />
                  <span className="font-bold text-xs text-slate-900 dark:text-white">
                    {isAr ? 'محادثة البث المباشر (متزامنة)' : 'Live Class Chat (Synced)'}
                  </span>
                </div>
                <button
                  onClick={() => setIsChatOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 p-3 overflow-y-auto space-y-2.5 text-xs font-tajawal">
                {chatMessages.map((msg, i) => (
                  <div
                    key={i}
                    className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-0.5"
                  >
                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono-numbers">
                      <span className="font-bold text-emerald-700 dark:text-emerald-400">{msg.sender}</span>
                      <span>{msg.time}</span>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200 text-xs leading-relaxed">{msg.text}</p>
                  </div>
                ))}
              </div>

              <form onSubmit={handleSendChat} className="p-2 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1.5">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder={isAr ? 'اطرح سؤالاً على المعلم...' : 'Ask the educator...'}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
                <button
                  type="submit"
                  className="p-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* ============================================================ */}
      {/* 5. STUDENT RAISE HAND TOPIC MODAL */}
      {/* ============================================================ */}
      {isRaiseHandModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl p-6 border-2 border-amber-500/50 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-500 flex items-center justify-center font-bold text-xl">
                  ✋
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900 dark:text-white">
                    {isAr ? 'رفع اليد لطلب المشاركة أو الاستفسار' : 'Raise Hand for Inquiry'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal">
                    {isAr ? 'سيصل إشعار فوري للمعلم مع موضوع استفسارك متزامناً عبر WebSockets' : 'The educator will receive your question'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsRaiseHandModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitRaiseHand} className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'اختر نوع الاستفسار أو اكتب سؤالك:' : 'Select Topic or Question:'}
                </label>
                <div className="space-y-1.5 mb-2.5">
                  {[
                    'استفسار حول خطوات حل المسألة الحالية',
                    'طلب فتح المايك والتحدث المباشر مع المعلم',
                    'طلب حل التمرين التالي على السبورة',
                    'إعادة شرح قاعدة السلسلة في التفاضل',
                  ].map((topic) => (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => setRaiseHandTopic(topic)}
                      className={`w-full text-right p-2 rounded-xl text-xs font-tajawal transition-colors ${
                        raiseHandTopic === topic
                          ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 font-bold border border-amber-400'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      • {topic}
                    </button>
                  ))}
                </div>

                <input
                  type="text"
                  value={raiseHandTopic}
                  onChange={(e) => setRaiseHandTopic(e.target.value)}
                  placeholder={isAr ? 'أو اكتب موضوع استفسارك هنا...' : 'Or type your question...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Hand className="w-4 h-4" />
                  <span>{isAr ? 'تأكيد رفع اليد وإرسال الاستفسار' : 'Confirm Raise Hand'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsRaiseHandModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 6. SUPER ADMIN EDIT ACCESS CODE MODAL */}
      {/* ============================================================ */}
      {isEditingCodeModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl p-6 border-2 border-emerald-500/70 shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center font-bold">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900 dark:text-white">
                    {isAr ? 'تعديل كود أمان السبورة التفاعلية' : 'Edit Whiteboard Security PIN'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-tajawal">
                    {isAr ? 'خاص بالأدمن العام (Mo-NewFolder) - يتزامن فورياً على كافة الأجهزة' : 'Super Admin Only - Synchronized via WebSockets'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditingCodeModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'رمز الدخول الجديد للجلسة:' : 'New Session Code:'}
                </label>
                <input
                  type="text"
                  value={newCodeInput}
                  onChange={(e) => setNewCodeInput(e.target.value.toUpperCase())}
                  placeholder="مثال: MATH-2026"
                  className="w-full text-center font-mono text-xl font-black uppercase py-3 px-4 rounded-xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:border-emerald-500 outline-none text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleGenerateRandomCode}
                  className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Sparkle className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{isAr ? 'توليد كود عشوائي جديد' : 'Generate Random PIN'}</span>
                </button>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-[11px] text-emerald-800 dark:text-emerald-300 font-tajawal">
                {isAr
                  ? '🔒 فور حفظ الكود الجديد، سيتطلب من أي طالب أو زائر إدخال هذا الرمز للانضمام للبث المباشر، وسيصل تحديث الكود لحظياً لكافة الأجهزة المتصلة.'
                  : 'Updating this PIN will require all attendees to authenticate with the new code.'}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={handleSaveNewAccessCode}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors shadow-md"
              >
                {isAr ? 'حفظ وتفعيل الكود الجديد' : 'Save & Activate PIN'}
              </button>
              <button
                type="button"
                onClick={() => setIsEditingCodeModalOpen(false)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
