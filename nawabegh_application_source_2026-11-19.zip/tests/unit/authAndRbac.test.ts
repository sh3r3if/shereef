import { describe, expect, it } from 'vitest';
import {
  mapPlatformRoleToClassroomRole,
  signClassroomToken,
  signRoomInviteToken,
  verifyClassroomToken,
  verifyRoomInviteToken,
} from '../../server/classroom/authMiddleware';
import {
  canAdministerPlatformRooms,
  canCreateOrConfigureRoom,
  canModerateRoom,
} from '../../server/classroom/config';
import { SlidingWindowRateLimiter } from '../../server/classroom/rateLimiter';

describe('Phase 1 Live Classroom Auth, RBAC, and Rate Limiter', () => {
  it('signs and verifies room session JWT tokens accurately', () => {
    const token = signClassroomToken({
      userId: 'usr-101',
      userName: 'أحمد الشريف',
      role: 'teacher',
      roomId: 'room-1',
      roomCode: 'SHF-123456',
    });

    const decoded = verifyClassroomToken(token);
    expect(decoded.userId).toBe('usr-101');
    expect(decoded.userName).toBe('أحمد الشريف');
    expect(decoded.role).toBe('teacher');
    expect(decoded.roomId).toBe('room-1');
  });

  it('rejects tampered or expired room tokens', () => {
    const token = signClassroomToken({
      userId: 'stu-1',
      userName: 'طالب',
      role: 'student',
      roomId: 'room-2',
    });
    const tampered = `${token.slice(0, -4)}xxxx`;
    expect(() => verifyClassroomToken(tampered)).toThrow();

    const expiredInvite = signRoomInviteToken(
      {
        roomId: 'room-2',
        roomCode: 'SHF-999111',
        grantedRole: 'student',
        issuedBy: 'teacher-1',
      },
      -10
    );
    expect(() => verifyRoomInviteToken(expiredInvite)).toThrow();
  });

  it('signs and verifies valid expiring room invite tokens', () => {
    const invite = signRoomInviteToken(
      {
        roomId: 'room-42',
        roomCode: 'SHF-420420',
        grantedRole: 'assistant',
        issuedBy: 'teacher-1',
      },
      300
    );
    const decoded = verifyRoomInviteToken(invite);
    expect(decoded.type).toBe('room_invite');
    expect(decoded.grantedRole).toBe('assistant');
    expect(decoded.roomCode).toBe('SHF-420420');
  });

  it('enforces platform-to-classroom role mapping and moderation privileges', () => {
    expect(mapPlatformRoleToClassroomRole('admin')).toBe('admin');
    expect(mapPlatformRoleToClassroomRole('supervisor')).toBe('admin');
    expect(mapPlatformRoleToClassroomRole('teacher')).toBe('teacher');
    expect(mapPlatformRoleToClassroomRole('secretary')).toBe('assistant');
    expect(mapPlatformRoleToClassroomRole('female_student')).toBe('student');

    expect(canCreateOrConfigureRoom('teacher')).toBe(true);
    expect(canCreateOrConfigureRoom('assistant')).toBe(true);
    expect(canCreateOrConfigureRoom('student')).toBe(false);

    expect(canModerateRoom('teacher')).toBe(true);
    expect(canModerateRoom('student')).toBe(false);

    expect(canAdministerPlatformRooms('admin')).toBe(true);
    expect(canAdministerPlatformRooms('teacher')).toBe(false);
  });

  it('enforces sliding-window rate limits per key', () => {
    const limiter = new SlidingWindowRateLimiter(3, 1000);
    const baseTime = 10_000;

    expect(limiter.check('user-a', baseTime).allowed).toBe(true);
    expect(limiter.check('user-a', baseTime + 100).allowed).toBe(true);
    expect(limiter.check('user-a', baseTime + 200).allowed).toBe(true);

    const blocked = limiter.check('user-a', baseTime + 300);
    expect(blocked.allowed).toBe(false);
    expect(blocked.retryAfterMs).toBeGreaterThan(0);

    // Different key remains independent
    expect(limiter.check('user-b', baseTime + 300).allowed).toBe(true);

    // After window slides past 1000ms, user-a is allowed again
    expect(limiter.check('user-a', baseTime + 1100).allowed).toBe(true);
  });
});
