import React, { useEffect, useRef, useState } from 'react';
import {
  CameraOff,
  GripHorizontal,
  Maximize2,
  Minimize2,
  Mic,
  MicOff,
  Signal,
  SignalHigh,
  SignalLow,
  WifiOff,
} from 'lucide-react';
import type { ConnectionQualityLevel } from '../../types/classroom';

export function QualityBadge({ quality }: { quality: ConnectionQualityLevel }) {
  switch (quality) {
    case 'excellent':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 text-[10px] font-cairo font-bold">
          <Signal className="w-3 h-3" />
          ممتاز
        </span>
      );
    case 'good':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-sky-950/80 text-sky-300 border border-sky-700/60 text-[10px] font-cairo font-bold">
          <SignalHigh className="w-3 h-3" />
          جيد
        </span>
      );
    case 'poor':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-950/80 text-amber-300 border border-amber-700/60 text-[10px] font-cairo font-bold">
          <SignalLow className="w-3 h-3" />
          ضعيف
        </span>
      );
    case 'lost':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-950/80 text-rose-300 border border-rose-700/60 text-[10px] font-cairo font-bold">
          <WifiOff className="w-3 h-3" />
          منقطع
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-900/80 text-slate-300 border border-slate-700 text-[10px] font-cairo font-bold">
          <SignalHigh className="w-3 h-3" />
          مستقر
        </span>
      );
  }
}

interface StreamVideoProps {
  stream: MediaStream | null;
  muted?: boolean;
  mirror?: boolean;
  className?: string;
}

export const StreamVideo: React.FC<StreamVideoProps> = ({
  stream,
  muted = false,
  mirror = false,
  className = 'w-full h-full object-cover',
}) => {
  const ref = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (stream) {
      el.srcObject = stream;
    } else {
      el.srcObject = null;
    }
  }, [stream]);

  return (
    <video
      ref={ref}
      autoPlay
      playsInline
      muted={muted}
      className={`${className} ${mirror ? 'scale-x-[-1]' : ''}`}
    />
  );
};

interface VideoStageFloatingProps {
  stream: MediaStream | null;
  userName: string;
  roleLabel: string;
  isMicEnabled: boolean;
  isCamEnabled: boolean;
  quality: ConnectionQualityLevel;
  isSelf?: boolean;
}

export const VideoStageFloating: React.FC<VideoStageFloatingProps> = ({
  stream,
  userName,
  roleLabel,
  isMicEnabled,
  isCamEnabled,
  quality,
  isSelf = false,
}) => {
  const [pos, setPos] = useState({ x: 16, y: 16 });
  const [expanded, setExpanded] = useState(false);
  const draggingRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(
    null
  );

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    draggingRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      origX: pos.x,
      origY: pos.y,
    };
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingRef.current) return;
    const dx = e.clientX - draggingRef.current.startX;
    const dy = e.clientY - draggingRef.current.startY;
    setPos({
      x: Math.max(8, draggingRef.current.origX + dx),
      y: Math.max(8, draggingRef.current.origY + dy),
    });
  };

  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (draggingRef.current) {
      e.currentTarget.releasePointerCapture(e.pointerId);
      draggingRef.current = null;
    }
  };

  return (
    <div
      style={{ transform: `translate3d(${pos.x}px, ${pos.y}px, 0)` }}
      className={`absolute top-0 left-0 z-20 ${
        expanded ? 'w-80 sm:w-96' : 'w-56 sm:w-64'
      } rounded-2xl overflow-hidden bg-slate-950 border-2 border-emerald-500/70 shadow-2xl select-none transition-[width]`}
    >
      {/* Drag Handle Bar */}
      <div
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        className="px-2.5 py-1.5 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between cursor-grab active:cursor-grabbing touch-none"
      >
        <div className="flex items-center gap-1.5 min-w-0">
          <GripHorizontal className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="text-[11px] font-cairo font-bold text-white truncate">
            {userName}
          </span>
          <span className="text-[10px] font-cairo text-emerald-400 shrink-0">
            ({roleLabel})
          </span>
        </div>
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-label={expanded ? 'تصغير نافذة الفيديو' : 'تكبير نافذة الفيديو'}
          className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
        >
          {expanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Video Surface */}
      <div className="relative aspect-video bg-slate-900 flex items-center justify-center">
        {isCamEnabled && stream ? (
          <StreamVideo stream={stream} muted={isSelf} mirror={isSelf} />
        ) : (
          <div className="flex flex-col items-center justify-center gap-1.5 text-slate-400 p-3">
            <div className="w-11 h-11 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-sm font-cairo font-bold text-emerald-400">
              {userName.slice(0, 2)}
            </div>
            <span className="inline-flex items-center gap-1 text-[10px] font-cairo text-slate-400">
              <CameraOff className="w-3 h-3" /> الكاميرا مغلقة
            </span>
          </div>
        )}

        <div className="absolute bottom-2 inset-x-2 flex items-center justify-between gap-2 pointer-events-none">
          <QualityBadge quality={quality} />
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${
              isMicEnabled
                ? 'bg-emerald-950/85 text-emerald-300 border border-emerald-700/60'
                : 'bg-rose-950/85 text-rose-300 border border-rose-700/60'
            }`}
          >
            {isMicEnabled ? <Mic className="w-3 h-3" /> : <MicOff className="w-3 h-3" />}
            {isMicEnabled ? 'صوت' : 'مكتوم'}
          </span>
        </div>
      </div>
    </div>
  );
};
