import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Layers,
  Award,
  Target,
  TrendingUp,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
  Zap,
  Compass,
  BookOpen,
  Calculator,
  Atom,
  FlaskConical,
  Globe,
  Code2,
  Cpu,
  Clock,
  Bookmark,
  Star,
  Flag,
  RotateCw,
  UserCheck,
  PieChart,
} from 'lucide-react';
import { InfographicData, InfographicSection, Language } from '../types';
import { AlSharifWatermark } from './ScreenProtectionGuard';

export interface ThemePalette {
  id: string;
  labelAr: string;
  labelEn: string;
  bannerGradient: string;
  badgeBg: string;
  badgeText: string;
  accentBg: string;
  accentSoft: string;
  accentText: string;
  border: string;
  ring: string;
  barBg: string;
  hex: string;
}

export const INFOGRAPHIC_THEMES: Record<string, ThemePalette> = {
  emerald: {
    id: 'emerald',
    labelAr: 'الزمردي الأكاديمي',
    labelEn: 'Academic Emerald',
    bannerGradient: 'from-emerald-950 via-teal-900 to-emerald-800',
    badgeBg: 'bg-amber-400 text-slate-950',
    badgeText: 'text-emerald-100',
    accentBg: 'bg-emerald-700',
    accentSoft: 'bg-emerald-50 dark:bg-emerald-950/50',
    accentText: 'text-emerald-700 dark:text-emerald-300',
    border: 'border-emerald-300 dark:border-emerald-800',
    ring: 'ring-emerald-500/20',
    barBg: 'bg-emerald-600',
    hex: '#047857',
  },
  indigo: {
    id: 'indigo',
    labelAr: 'النيلي التقني',
    labelEn: 'Tech Indigo',
    bannerGradient: 'from-slate-950 via-indigo-950 to-blue-900',
    badgeBg: 'bg-cyan-400 text-slate-950',
    badgeText: 'text-indigo-100',
    accentBg: 'bg-indigo-600',
    accentSoft: 'bg-indigo-50 dark:bg-indigo-950/50',
    accentText: 'text-indigo-700 dark:text-indigo-300',
    border: 'border-indigo-300 dark:border-indigo-800',
    ring: 'ring-indigo-500/20',
    barBg: 'bg-indigo-600',
    hex: '#4f46e5',
  },
  sky: {
    id: 'sky',
    labelAr: 'السماوي المشرق',
    labelEn: 'Ocean Sky',
    bannerGradient: 'from-sky-950 via-blue-900 to-cyan-800',
    badgeBg: 'bg-amber-300 text-slate-950',
    badgeText: 'text-sky-100',
    accentBg: 'bg-sky-600',
    accentSoft: 'bg-sky-50 dark:bg-sky-950/50',
    accentText: 'text-sky-700 dark:text-sky-300',
    border: 'border-sky-300 dark:border-sky-800',
    ring: 'ring-sky-500/20',
    barBg: 'bg-sky-600',
    hex: '#0284c7',
  },
  amber: {
    id: 'amber',
    labelAr: 'الذهبي الملكي',
    labelEn: 'Royal Amber',
    bannerGradient: 'from-stone-950 via-amber-950 to-orange-900',
    badgeBg: 'bg-amber-300 text-stone-950',
    badgeText: 'text-amber-100',
    accentBg: 'bg-amber-600',
    accentSoft: 'bg-amber-50 dark:bg-amber-950/50',
    accentText: 'text-amber-700 dark:text-amber-300',
    border: 'border-amber-300 dark:border-amber-800',
    ring: 'ring-amber-500/20',
    barBg: 'bg-amber-600',
    hex: '#d97706',
  },
  rose: {
    id: 'rose',
    labelAr: 'الروبي الحيوي',
    labelEn: 'Vibrant Rose',
    bannerGradient: 'from-slate-950 via-rose-950 to-pink-900',
    badgeBg: 'bg-rose-300 text-slate-950',
    badgeText: 'text-rose-100',
    accentBg: 'bg-rose-600',
    accentSoft: 'bg-rose-50 dark:bg-rose-950/50',
    accentText: 'text-rose-700 dark:text-rose-300',
    border: 'border-rose-300 dark:border-rose-800',
    ring: 'ring-rose-500/20',
    barBg: 'bg-rose-600',
    hex: '#e11d48',
  },
  crimson: {
    id: 'crimson',
    labelAr: 'العنابي الجامعي',
    labelEn: 'Academic Crimson',
    bannerGradient: 'from-neutral-950 via-red-950 to-rose-900',
    badgeBg: 'bg-amber-300 text-neutral-950',
    badgeText: 'text-red-100',
    accentBg: 'bg-red-700',
    accentSoft: 'bg-red-50 dark:bg-red-950/50',
    accentText: 'text-red-700 dark:text-red-300',
    border: 'border-red-300 dark:border-red-800',
    ring: 'ring-red-500/20',
    barBg: 'bg-red-700',
    hex: '#b91c1c',
  },
  teal: {
    id: 'teal',
    labelAr: 'الفيروزي العلمي',
    labelEn: 'Scientific Teal',
    bannerGradient: 'from-slate-950 via-cyan-950 to-teal-900',
    badgeBg: 'bg-teal-300 text-slate-950',
    badgeText: 'text-cyan-100',
    accentBg: 'bg-teal-600',
    accentSoft: 'bg-teal-50 dark:bg-teal-950/50',
    accentText: 'text-teal-700 dark:text-teal-300',
    border: 'border-teal-300 dark:border-teal-800',
    ring: 'ring-teal-500/20',
    barBg: 'bg-teal-600',
    hex: '#0d9488',
  },
  violet: {
    id: 'violet',
    labelAr: 'البنفسجي الإبداعي',
    labelEn: 'Creative Violet',
    bannerGradient: 'from-slate-950 via-violet-950 to-purple-900',
    badgeBg: 'bg-violet-300 text-slate-950',
    badgeText: 'text-violet-100',
    accentBg: 'bg-violet-600',
    accentSoft: 'bg-violet-50 dark:bg-violet-950/50',
    accentText: 'text-violet-700 dark:text-violet-300',
    border: 'border-violet-300 dark:border-violet-800',
    ring: 'ring-violet-500/20',
    barBg: 'bg-violet-600',
    hex: '#7c3aed',
  },
};

export const INFOGRAPHIC_ICON_MAP: Record<
  string,
  { labelAr: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  sparkles: { labelAr: 'مميز', Icon: Sparkles },
  book: { labelAr: 'كتاب', Icon: BookOpen },
  lightbulb: { labelAr: 'فكرة', Icon: Lightbulb },
  target: { labelAr: 'هدف', Icon: Target },
  award: { labelAr: 'إنجاز', Icon: Award },
  check: { labelAr: 'تحقق', Icon: CheckCircle2 },
  zap: { labelAr: 'طاقة', Icon: Zap },
  compass: { labelAr: 'بوصلة', Icon: Compass },
  calc: { labelAr: 'حساب', Icon: Calculator },
  atom: { labelAr: 'ذرة/فيزياء', Icon: Atom },
  flask: { labelAr: 'كيمياء', Icon: FlaskConical },
  globe: { labelAr: 'جغرافيا', Icon: Globe },
  code: { labelAr: 'برمجة', Icon: Code2 },
  cpu: { labelAr: 'تقنية', Icon: Cpu },
  layers: { labelAr: 'طبقات', Icon: Layers },
  trend: { labelAr: 'تقدم', Icon: TrendingUp },
  shield: { labelAr: 'حماية', Icon: ShieldCheck },
  clock: { labelAr: 'وقت', Icon: Clock },
  bookmark: { labelAr: 'مرجع', Icon: Bookmark },
  star: { labelAr: 'نجمة', Icon: Star },
  flag: { labelAr: 'محطة', Icon: Flag },
  pie: { labelAr: 'إحصاء', Icon: PieChart },
};

interface InfographicRendererProps {
  title: string;
  subject: string;
  grade?: string;
  data: InfographicData;
  language?: Language;
  printableId?: string;
}

const SECTION_COLORS = [
  '#059669',
  '#2563eb',
  '#d97706',
  '#7c3aed',
  '#e11d48',
  '#0d9488',
  '#0284c7',
  '#b91c1c',
];

const escapeHtml = (str: string) =>
  (str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

export function buildInfographicEmbedHtml(
  title: string,
  subject: string,
  grade: string | undefined,
  data: InfographicData,
  isAr = true
): string {
  const theme = INFOGRAPHIC_THEMES[data.themeColor] || INFOGRAPHIC_THEMES.emerald;
  const sections = data.sections || [];
  const dir = isAr ? 'rtl' : 'ltr';
  const cardsHtml = sections
    .map((sec, idx) => {
      const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
      const highlightsHtml =
        sec.highlights && sec.highlights.length > 0
          ? `<ul style="margin: 6px 0 0; padding-${isAr ? 'right' : 'left'}: 18px; font-size: 12px; color: #334155;">
              ${sec.highlights.map((h) => `<li>${escapeHtml(h)}</li>`).join('')}
            </ul>`
          : '';
      return `
        <div style="background: #ffffff; border: 1px solid #e2e8f0; border-top: 4px solid ${color}; border-radius: 14px; padding: 14px; box-shadow: 0 2px 6px rgba(15,23,42,0.04);">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 6px;">
            <span style="display: inline-block; background: ${color}; color: #fff; font-weight: 800; font-size: 11px; padding: 2px 10px; border-radius: 999px;">
              ${sec.badge ? escapeHtml(sec.badge) : `#${idx + 1}`}
            </span>
            ${
              sec.value
                ? `<span style="font-family: monospace; font-weight: 800; font-size: 12px; color: ${color}; background: #f8fafc; padding: 2px 8px; border-radius: 8px; border: 1px solid #e2e8f0;">${escapeHtml(sec.value)}</span>`
                : ''
            }
          </div>
          <h4 style="margin: 4px 0; font-size: 15px; font-weight: 800; color: #0f172a;">${escapeHtml(sec.title)}</h4>
          <p style="margin: 0; font-size: 13px; color: #475569; line-height: 1.7;">${escapeHtml(sec.description)}</p>
          ${highlightsHtml}
        </div>
      `;
    })
    .join('');

  return `
    <div dir="${dir}" style="margin: 18px 0; border-radius: 18px; border: 1px solid #cbd5e1; background: #f8fafc; padding: 18px; font-family: 'Tajawal', 'Cairo', Arial, sans-serif;">
      <div style="background: linear-gradient(135deg, ${theme.hex}, #0f172a); color: #ffffff; padding: 16px 20px; border-radius: 14px; margin-bottom: 14px;">
        <div style="font-size: 11px; font-weight: 700; opacity: 0.9; margin-bottom: 4px;">
          ${isAr ? `انفوجرافيك تعليمي · ${escapeHtml(subject)}` : `Educational Infographic · ${escapeHtml(subject)}`} ${grade ? `· ${escapeHtml(grade)}` : ''}
        </div>
        <h3 style="margin: 0 0 6px; font-size: 18px; font-weight: 900; color: #ffffff;">${escapeHtml(title)}</h3>
        ${data.summary ? `<p style="margin: 0; font-size: 13px; opacity: 0.92; line-height: 1.6;">${escapeHtml(data.summary)}</p>` : ''}
      </div>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px;">
        ${cardsHtml}
      </div>
    </div>
    <p><br/></p>
  `;
}

export const InfographicRenderer: React.FC<InfographicRendererProps> = ({
  title,
  subject,
  grade,
  data,
  language = 'ar',
  printableId,
}) => {
  const isAr = language === 'ar';
  const theme = INFOGRAPHIC_THEMES[data.themeColor] || INFOGRAPHIC_THEMES.emerald;
  const sections = data.sections || [];
  const template = data.template || 'steps';
  const surfaceStyle = data.surfaceStyle || 'modern';
  const columns = data.columns || 2;
  const showNumbers = data.showNumbers !== false;

  // Interactive state for Flashcards & Donut chart
  const [flippedCardIds, setFlippedCardIds] = useState<Record<string, boolean>>({});
  const [activeSliceIdx, setActiveSliceIdx] = useState<number | null>(null);

  const toggleFlipCard = (key: string) => {
    setFlippedCardIds((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const gridColClass =
    columns === 1
      ? 'grid-cols-1'
      : columns === 3
      ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
      : 'grid-cols-1 sm:grid-cols-2';

  const containerSurfaceClass =
    surfaceStyle === 'dark'
      ? 'bg-slate-950 text-slate-100 border-slate-800 shadow-xl'
      : surfaceStyle === 'academic'
      ? 'bg-stone-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-stone-300 dark:border-slate-700 shadow-xs'
      : surfaceStyle === 'glass'
      ? 'bg-gradient-to-br from-white via-slate-50/90 to-emerald-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/30 border-slate-200/80 dark:border-slate-700/80 shadow-md'
      : surfaceStyle === 'minimal'
      ? 'bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-none'
      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm';

  const cardSurfaceClass =
    surfaceStyle === 'dark'
      ? 'bg-slate-900/90 border-slate-800 text-slate-100'
      : surfaceStyle === 'academic'
      ? 'bg-white dark:bg-slate-800/60 border-stone-200 dark:border-slate-700'
      : surfaceStyle === 'minimal'
      ? 'bg-transparent border-slate-200 dark:border-slate-800'
      : 'bg-slate-50/80 dark:bg-slate-800/45 border-slate-200 dark:border-slate-800';

  const extractNumeric = (val?: string, idx = 0): number => {
    if (val) {
      const pctMatch = val.match(/(\d+(?:\.\d+)?)\s*%/);
      if (pctMatch) return Math.max(4, Number(pctMatch[1]));
      const numMatch = val.match(/(\d+(?:\.\d+)?)/);
      if (numMatch) return Math.max(4, Number(numMatch[1]));
    }
    return Math.max(15, 85 - idx * 14);
  };

  const extractPercentage = (val?: string, idx = 0): number => {
    if (val) {
      const match = val.match(/(\d+(?:\.\d+)?)\s*%/);
      if (match) {
        return Math.min(100, Math.max(8, Number(match[1])));
      }
      const numMatch = val.match(/\b(\d+)\b/);
      if (numMatch && Number(numMatch[1]) <= 100 && Number(numMatch[1]) >= 10) {
        return Number(numMatch[1]);
      }
    }
    return Math.max(35, 95 - idx * 14);
  };

  const renderSectionGlyph = (sec: InfographicSection, fallbackIdx: number) => {
    const entry = sec.iconName ? INFOGRAPHIC_ICON_MAP[sec.iconName] : null;
    if (entry) {
      const IconComp = entry.Icon;
      return <IconComp className="w-4 h-4" />;
    }
    return showNumbers ? <span>{fallbackIdx + 1}</span> : <Sparkles className="w-3.5 h-3.5" />;
  };

  const renderHighlightsAndMedia = (sec: InfographicSection, color: string) => (
    <>
      {sec.imageUrl && (
        <div className="mt-2.5 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/70">
          <img
            src={sec.imageUrl}
            alt={sec.title}
            referrerPolicy="no-referrer"
            className="w-full h-32 object-cover"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>
      )}
      {sec.highlights && sec.highlights.filter(Boolean).length > 0 && (
        <ul className="mt-2.5 space-y-1">
          {sec.highlights.filter(Boolean).map((item, i) => (
            <li key={i} className="flex items-start gap-1.5 text-[11px] font-tajawal opacity-90">
              <span
                className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0"
                style={{ backgroundColor: color }}
              />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      )}
    </>
  );

  // Compute Donut Chart Segments
  const numericValues = sections.map((s, i) => extractNumeric(s.value, i));
  const totalNumeric = Math.max(1, numericValues.reduce((a, b) => a + b, 0));

  // Compute Bar Chart Max
  const maxBarVal = Math.max(10, ...numericValues);

  return (
    <div
      id={printableId}
      className={`rounded-2xl p-5 md:p-7 space-y-6 font-tajawal relative overflow-hidden protected-lesson-area ${containerSurfaceClass}`}
    >
      <AlSharifWatermark extraLabel={title} opacity="light" />
      {/* Header Banner */}
      <div
        className={`p-5 md:p-6 rounded-2xl bg-gradient-to-r ${theme.bannerGradient} text-white relative overflow-hidden shadow-md`}
      >
        <div className="absolute -top-12 -left-12 w-40 h-40 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-40 h-40 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="relative z-10 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-cairo">
            <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full ${theme.badgeBg} font-bold shadow-xs`}>
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                {isAr
                  ? `انفوجرافيك تعليمي معتمد · ${subject}`
                  : `Certified Infographic · ${subject}`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {data.authorName && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/15 text-white text-[11px] font-bold">
                  <UserCheck className="w-3 h-3" />
                  <span>{data.authorName}</span>
                </span>
              )}
              {grade && (
                <span className="px-2.5 py-0.5 rounded-full bg-white/15 text-white text-[11px] font-bold">
                  {grade}
                </span>
              )}
            </div>
          </div>
          <h2 className="text-lg md:text-2xl font-cairo font-black leading-snug text-white">
            {title || (isAr ? 'عنوان الانفوجرافيك التعليمي' : 'Infographic Title')}
          </h2>
          {data.summary && (
            <p className={`text-xs md:text-sm ${theme.badgeText} font-tajawal leading-relaxed`}>
              {data.summary}
            </p>
          )}
        </div>
      </div>

      {/* 1. STEPS FLOW */}
      {template === 'steps' && (
        <div className="space-y-3">
          {sections.map((sec, idx) => {
            const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
            return (
              <React.Fragment key={sec.id || idx}>
                <div className={`relative flex items-start gap-4 p-4 rounded-2xl border hover:shadow-sm transition-all ${cardSurfaceClass}`}>
                  <div
                    className="w-10 h-10 rounded-2xl text-white font-mono-numbers font-black flex items-center justify-center text-sm shrink-0 shadow-sm"
                    style={{ backgroundColor: color }}
                  >
                    {renderSectionGlyph(sec, idx)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-cairo font-bold text-sm">
                          {sec.title}
                        </h4>
                        {sec.badge && (
                          <span className="text-[10px] font-cairo font-bold px-2 py-0.5 rounded-md bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                            {sec.badge}
                          </span>
                        )}
                      </div>
                      {sec.value && (
                        <span
                          className={`px-2.5 py-0.5 rounded-lg ${theme.accentSoft} ${theme.accentText} font-mono-numbers font-black text-xs border ${theme.border}`}
                        >
                          {sec.value}
                        </span>
                      )}
                    </div>
                    <p className="text-xs opacity-80 font-tajawal leading-relaxed">
                      {sec.description}
                    </p>
                    {renderHighlightsAndMedia(sec, color)}
                  </div>
                </div>
                {idx < sections.length - 1 && (
                  <div className="flex justify-center -my-1.5">
                    <ArrowDown className={`w-4 h-4 ${theme.accentText} opacity-60`} />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      )}

      {/* 2. KNOWLEDGE CARDS GRID */}
      {template === 'cards' && (
        <div className={`grid ${gridColClass} gap-3.5`}>
          {sections.map((sec, idx) => {
            const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
            return (
              <div
                key={sec.id || idx}
                className={`rounded-2xl border overflow-hidden shadow-xs flex flex-col justify-between ${cardSurfaceClass}`}
              >
                <div className="h-1.5 w-full" style={{ backgroundColor: color }} />
                <div className="p-4 space-y-2 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className="w-8 h-8 rounded-xl text-white font-mono-numbers font-black text-xs flex items-center justify-center shadow-xs"
                      style={{ backgroundColor: color }}
                    >
                      {renderSectionGlyph(sec, idx)}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {sec.badge && (
                        <span className="text-[10px] font-cairo font-bold px-2 py-0.5 rounded-md bg-slate-200/70 dark:bg-slate-700">
                          {sec.badge}
                        </span>
                      )}
                      {sec.value && (
                        <span
                          className={`px-2.5 py-0.5 rounded-md ${theme.accentSoft} ${theme.accentText} font-mono-numbers font-bold text-xs`}
                        >
                          {sec.value}
                        </span>
                      )}
                    </div>
                  </div>
                  <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                  <p className="text-xs opacity-80 font-tajawal leading-relaxed">
                    {sec.description}
                  </p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 3. DUAL COMPARISON VS */}
      {template === 'comparison' && (
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-3">
            <span className="flex-1 h-px bg-slate-200 dark:bg-slate-700" />
            <span
              className={`px-3.5 py-1 rounded-full ${theme.accentBg} text-white font-cairo font-black text-xs shadow-sm`}
            >
              {isAr ? 'مقارنة تحليلية شاملة (VS)' : 'Analytical Comparison (VS)'}
            </span>
            <span className="flex-1 h-px bg-slate-200 dark:bg-slate-700" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 relative">
            {sections.map((sec, idx) => {
              const isFirstCol = idx % 2 === 0;
              const color = sec.color || (isFirstCol ? '#059669' : '#4f46e5');
              return (
                <div
                  key={sec.id || idx}
                  className={`p-4 rounded-2xl border-2 transition-all ${
                    isFirstCol
                      ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50/40 dark:bg-emerald-950/30'
                      : 'border-indigo-300 dark:border-indigo-800 bg-indigo-50/40 dark:bg-indigo-950/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className={`text-[10px] font-cairo font-black px-2 py-0.5 rounded-full text-white`}
                      style={{ backgroundColor: color }}
                    >
                      {sec.badge ||
                        (isFirstCol
                          ? isAr
                            ? `الجانب الأول #${Math.floor(idx / 2) + 1}`
                            : `Side A #${Math.floor(idx / 2) + 1}`
                          : isAr
                          ? `الجانب المقابل #${Math.floor(idx / 2) + 1}`
                          : `Side B #${Math.floor(idx / 2) + 1}`)}
                    </span>
                    <span className="text-[11px] font-mono-numbers opacity-60">
                      0{idx + 1}
                    </span>
                  </div>
                  <h4 className="font-cairo font-bold text-sm mb-1.5">{sec.title}</h4>
                  <p className="text-xs opacity-80 font-tajawal leading-relaxed mb-3">
                    {sec.description}
                  </p>
                  {sec.value && (
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center font-mono-numbers font-bold text-xs text-slate-800 dark:text-slate-100">
                      {sec.value}
                    </div>
                  )}
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. STATS & KPI PROGRESS BARS */}
      {template === 'stats' && (
        <div className={`grid ${gridColClass} gap-3.5`}>
          {sections.map((sec, idx) => {
            const pct = extractPercentage(sec.value, idx);
            const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
            return (
              <div
                key={sec.id || idx}
                className={`p-4 rounded-2xl border space-y-2.5 ${cardSurfaceClass}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-cairo font-bold opacity-60">
                      {sec.badge || (isAr ? `مؤشر #${idx + 1}` : `Metric #${idx + 1}`)}
                    </span>
                    <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                  </div>
                  <span
                    className="text-xl font-mono-numbers font-black shrink-0"
                    style={{ color }}
                  >
                    {sec.value || `${pct}%`}
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${pct}%`, backgroundColor: color }}
                  />
                </div>
                <p className="text-xs opacity-80 font-tajawal leading-relaxed">
                  {sec.description}
                </p>
                {renderHighlightsAndMedia(sec, color)}
              </div>
            );
          })}
        </div>
      )}

      {/* 5. VERTICAL MILESTONE TIMELINE */}
      {template === 'timeline' && (
        <div
          className={`relative ${
            isAr ? 'border-r-2 pr-6 mr-3' : 'border-l-2 pl-6 ml-3'
          } ${theme.border} space-y-5`}
        >
          {sections.map((sec, idx) => {
            const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
            return (
              <div key={sec.id || idx} className="relative">
                <div
                  className={`w-4 h-4 rounded-full border-2 border-white dark:border-slate-900 shadow-sm absolute top-3 ${
                    isAr ? '-right-[33px]' : '-left-[33px]'
                  }`}
                  style={{ backgroundColor: color }}
                />
                <div className={`p-4 rounded-2xl border space-y-1.5 ${cardSurfaceClass}`}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-7 h-7 rounded-lg text-white flex items-center justify-center text-xs font-bold"
                        style={{ backgroundColor: color }}
                      >
                        {renderSectionGlyph(sec, idx)}
                      </span>
                      <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                    </div>
                    {sec.value && (
                      <span
                        className="px-2.5 py-0.5 rounded-full text-[11px] font-mono-numbers font-bold text-white"
                        style={{ backgroundColor: color }}
                      >
                        {sec.value}
                      </span>
                    )}
                  </div>
                  <p className="text-xs opacity-80 font-tajawal leading-relaxed">
                    {sec.description}
                  </p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 6. HIERARCHICAL PYRAMID */}
      {template === 'pyramid' && (
        <div className="flex flex-col items-center gap-2.5 py-2">
          {sections.map((sec, idx) => {
            const total = Math.max(sections.length, 1);
            const widthPct = Math.round(52 + ((idx + 1) / total) * 48);
            const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
            return (
              <div
                key={sec.id || idx}
                style={{ width: `${widthPct}%`, borderColor: color }}
                className={`mx-auto p-3.5 rounded-2xl border-2 shadow-xs transition-all text-center ${cardSurfaceClass}`}
              >
                <div className="flex items-center justify-center gap-2 mb-1">
                  <span
                    className="px-2.5 py-0.5 rounded-full text-white font-mono-numbers font-black text-[11px] inline-flex items-center gap-1"
                    style={{ backgroundColor: color }}
                  >
                    {sec.badge || (isAr ? `المستوى ${idx + 1}` : `Tier ${idx + 1}`)}
                  </span>
                  {sec.value && (
                    <span className="font-mono-numbers font-bold text-xs bg-slate-200/70 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                      {sec.value}
                    </span>
                  )}
                </div>
                <h4 className="font-cairo font-bold text-xs md:text-sm">{sec.title}</h4>
                <p className="text-[11px] md:text-xs opacity-80 font-tajawal mt-0.5 leading-relaxed">
                  {sec.description}
                </p>
                {renderHighlightsAndMedia(sec, color)}
              </div>
            );
          })}
        </div>
      )}

      {/* 7. CENTRAL MIND MAP */}
      {template === 'mindmap' && (
        <div className="space-y-4">
          <div className="flex justify-center">
            <div
              className={`px-6 py-4 rounded-3xl bg-gradient-to-r ${theme.bannerGradient} text-white text-center shadow-lg border-4 border-white dark:border-slate-800 max-w-md`}
            >
              <div className="flex items-center justify-center gap-1.5 text-[11px] font-cairo font-bold opacity-85 mb-1">
                <Compass className="w-4 h-4" />
                <span>{isAr ? 'المحور المركزي للخريطة الذهنية' : 'Central Mind Map Node'}</span>
              </div>
              <h3 className="font-cairo font-black text-base md:text-lg">{title}</h3>
            </div>
          </div>

          <div className="flex justify-center">
            <div className={`w-0.5 h-5 ${theme.accentBg} opacity-50`} />
          </div>

          <div className={`grid ${gridColClass} gap-3.5`}>
            {sections.map((sec, idx) => {
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              return (
                <div
                  key={sec.id || idx}
                  className={`relative p-4 rounded-2xl border-2 shadow-xs ${cardSurfaceClass}`}
                  style={{ borderColor: color }}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span
                      className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-white text-[11px] font-cairo font-bold"
                      style={{ backgroundColor: color }}
                    >
                      {renderSectionGlyph(sec, idx)}
                      <span>{sec.badge || (isAr ? `فرع ${idx + 1}` : `Branch ${idx + 1}`)}</span>
                    </span>
                    {sec.value && (
                      <span className="font-mono-numbers font-bold text-xs opacity-80">
                        {sec.value}
                      </span>
                    )}
                  </div>
                  <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                  <p className="text-xs opacity-80 font-tajawal mt-1 leading-relaxed">
                    {sec.description}
                  </p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 8. CONTINUOUS CYCLE LOOP */}
      {template === 'cycle' && (
        <div className="space-y-4">
          <div className={`p-3 rounded-2xl ${theme.accentSoft} border ${theme.border} text-center`}>
            <span className={`font-cairo font-bold text-xs ${theme.accentText}`}>
              {isAr
                ? '↻ دورة متكاملة ومستمرة التفاعل (تنتقل من كل مرحلة إلى التالية وصولاً لإعادة التغذية)'
                : '↻ Continuous Interactive Cycle Loop'}
            </span>
          </div>
          <div className={`grid ${gridColClass} gap-3.5`}>
            {sections.map((sec, idx) => {
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              const nextIdx = (idx + 1) % sections.length;
              return (
                <div
                  key={sec.id || idx}
                  className={`p-4 rounded-2xl border shadow-xs space-y-2 relative ${cardSurfaceClass}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-8 h-8 rounded-full text-white font-mono-numbers font-black text-xs flex items-center justify-center"
                        style={{ backgroundColor: color }}
                      >
                        {renderSectionGlyph(sec, idx)}
                      </span>
                      {sec.value && (
                        <span className="text-xs font-mono-numbers font-bold opacity-70">
                          {sec.value}
                        </span>
                      )}
                    </div>
                    <span className="inline-flex items-center gap-1 text-[10px] font-cairo font-bold px-2 py-0.5 rounded-full bg-slate-200/70 dark:bg-slate-800">
                      {isAr ? `يؤدي إلى #${nextIdx + 1}` : `Next #${nextIdx + 1}`}
                      {isAr ? <ArrowLeft className="w-3 h-3" /> : <ArrowRight className="w-3 h-3" />}
                    </span>
                  </div>
                  <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                  <p className="text-xs opacity-80 font-tajawal leading-relaxed">
                    {sec.description}
                  </p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 9. QUADRANT MATRIX / SWOT (2x2 GRID) */}
      {template === 'swot' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {sections.map((sec, idx) => {
            const quadrantStyles = [
              {
                label: isAr ? 'الربع الأول: الأساس / نقاط القوة' : 'Quadrant 1: Core / Strengths',
                bg: 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800',
                badge: 'bg-emerald-600 text-white',
                color: '#059669',
                Icon: ShieldCheck,
              },
              {
                label: isAr ? 'الربع الثاني: التحليل / الفرص' : 'Quadrant 2: Analysis / Opportunities',
                bg: 'bg-blue-50/70 dark:bg-blue-950/30 border-blue-300 dark:border-blue-800',
                badge: 'bg-blue-600 text-white',
                color: '#2563eb',
                Icon: Lightbulb,
              },
              {
                label: isAr ? 'الربع الثالث: التحديات / الفروق' : 'Quadrant 3: Challenges / Gaps',
                bg: 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800',
                badge: 'bg-amber-600 text-white',
                color: '#d97706',
                Icon: Target,
              },
              {
                label: isAr ? 'الربع الرابع: التنبيهات / الأخطاء الشائعة' : 'Quadrant 4: Pitfalls / Alerts',
                bg: 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800',
                badge: 'bg-rose-600 text-white',
                color: '#e11d48',
                Icon: AlertTriangle,
              },
            ];
            const q = quadrantStyles[idx % 4];
            const QIcon = q.Icon;
            return (
              <div key={sec.id || idx} className={`p-4 rounded-2xl border-2 ${q.bg} space-y-2`}>
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-cairo font-bold ${q.badge}`}
                  >
                    <QIcon className="w-3 h-3" />
                    <span>{sec.badge || q.label}</span>
                  </span>
                  {sec.value && (
                    <span className="font-mono-numbers font-bold text-xs opacity-80">
                      {sec.value}
                    </span>
                  )}
                </div>
                <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                <p className="text-xs opacity-80 font-tajawal leading-relaxed">
                  {sec.description}
                </p>
                {renderHighlightsAndMedia(sec, q.color)}
              </div>
            );
          })}
        </div>
      )}

      {/* 10. GOLDEN LAWS & CHECKLIST */}
      {template === 'checklist' && (
        <div className="space-y-2.5">
          {sections.map((sec, idx) => {
            const color = sec.color || theme.hex;
            return (
              <div
                key={sec.id || idx}
                className={`flex items-start gap-3.5 p-4 rounded-2xl border ${theme.border} shadow-xs ${cardSurfaceClass}`}
              >
                <div
                  className="w-8 h-8 rounded-xl text-white flex items-center justify-center shrink-0 mt-0.5"
                  style={{ backgroundColor: color }}
                >
                  {sec.iconName ? renderSectionGlyph(sec, idx) : <CheckCircle2 className="w-4 h-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                    {sec.value && (
                      <span
                        className={`px-2.5 py-0.5 rounded-lg ${theme.accentSoft} ${theme.accentText} font-mono-numbers font-bold text-xs`}
                      >
                        {sec.value}
                      </span>
                    )}
                  </div>
                  <p className="text-xs opacity-80 font-tajawal mt-1 leading-relaxed">
                    {sec.description}
                  </p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 11. SVG DONUT / PIE ANALYTICS CHART */}
      {template === 'donut' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          <div className="md:col-span-5 flex flex-col items-center justify-center p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60">
            <svg viewBox="0 0 220 220" className="w-52 h-52 overflow-visible">
              <circle
                cx="110"
                cy="110"
                r="76"
                fill="none"
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeWidth="30"
              />
              {(() => {
                const radius = 76;
                const circumference = 2 * Math.PI * radius;
                let cumulativeOffset = 0;
                return sections.map((sec, idx) => {
                  const val = numericValues[idx] || 0;
                  const ratio = val / totalNumeric;
                  const arcLen = ratio * circumference;
                  const dashArray = `${Math.max(2, arcLen - 2)} ${circumference}`;
                  const dashOffset = -cumulativeOffset;
                  cumulativeOffset += arcLen;
                  const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
                  const isActive = activeSliceIdx === idx;
                  return (
                    <circle
                      key={sec.id || idx}
                      cx="110"
                      cy="110"
                      r={radius}
                      fill="none"
                      stroke={color}
                      strokeWidth={isActive ? 36 : 30}
                      strokeDasharray={dashArray}
                      strokeDashoffset={dashOffset}
                      transform="rotate(-90 110 110)"
                      className="transition-all duration-300 cursor-pointer"
                      onMouseEnter={() => setActiveSliceIdx(idx)}
                      onMouseLeave={() => setActiveSliceIdx(null)}
                    />
                  );
                });
              })()}
              <text
                x="110"
                y="104"
                textAnchor="middle"
                className="fill-slate-900 dark:fill-white font-mono-numbers font-black text-xl"
              >
                {activeSliceIdx !== null
                  ? `${Math.round((numericValues[activeSliceIdx] / totalNumeric) * 100)}%`
                  : `${sections.length}`}
              </text>
              <text
                x="110"
                y="126"
                textAnchor="middle"
                className="fill-slate-500 dark:fill-slate-400 font-cairo text-[11px] font-bold"
              >
                {activeSliceIdx !== null
                  ? sections[activeSliceIdx]?.title.slice(0, 16)
                  : isAr
                  ? 'محاور النسب'
                  : 'Segments'}
              </text>
            </svg>
            <span className="text-[11px] opacity-65 mt-1 font-tajawal">
              {isAr ? 'مرر المؤشر على أجزاء الحلقة لعرض التفاصيل' : 'Hover segments to inspect values'}
            </span>
          </div>

          <div className="md:col-span-7 space-y-2.5">
            {sections.map((sec, idx) => {
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              const share = Math.round(((numericValues[idx] || 0) / totalNumeric) * 100);
              return (
                <div
                  key={sec.id || idx}
                  onMouseEnter={() => setActiveSliceIdx(idx)}
                  onMouseLeave={() => setActiveSliceIdx(null)}
                  className={`p-3.5 rounded-2xl border transition-all ${cardSurfaceClass} ${
                    activeSliceIdx === idx ? 'ring-2 ring-emerald-500/40' : ''
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-3.5 h-3.5 rounded-full shrink-0"
                        style={{ backgroundColor: color }}
                      />
                      <h4 className="font-cairo font-bold text-sm truncate">{sec.title}</h4>
                    </div>
                    <span className="font-mono-numbers font-black text-xs px-2 py-0.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shrink-0" style={{ color }}>
                      {sec.value || `${share}%`} ({share}%)
                    </span>
                  </div>
                  <p className="text-xs opacity-80 mt-1 font-tajawal">{sec.description}</p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 12. VERTICAL BAR CHART */}
      {template === 'barchart' && (
        <div className="space-y-5">
          <div className="p-4 md:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50">
            <div className="h-56 flex items-end justify-around gap-3 border-b-2 border-slate-300 dark:border-slate-700 pb-2 px-2 relative">
              {/* Background horizontal reference gridlines */}
              <div className="absolute inset-x-0 bottom-[25%] border-t border-dashed border-slate-200 dark:border-slate-800 pointer-events-none" />
              <div className="absolute inset-x-0 bottom-[50%] border-t border-dashed border-slate-200 dark:border-slate-800 pointer-events-none" />
              <div className="absolute inset-x-0 bottom-[75%] border-t border-dashed border-slate-200 dark:border-slate-800 pointer-events-none" />

              {sections.map((sec, idx) => {
                const val = numericValues[idx] || 0;
                const heightPct = Math.max(12, Math.round((val / maxBarVal) * 100));
                const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
                return (
                  <div
                    key={sec.id || idx}
                    className="flex-1 flex flex-col items-center justify-end h-full min-w-[44px] max-w-[110px] z-10"
                  >
                    <span
                      className="text-[11px] font-mono-numbers font-black mb-1"
                      style={{ color }}
                    >
                      {sec.value || val}
                    </span>
                    <div
                      className="w-full max-w-[48px] rounded-t-xl shadow-sm transition-all duration-500 flex items-start justify-center pt-1.5 text-white text-[10px] font-bold"
                      style={{ height: `${heightPct}%`, backgroundColor: color }}
                    >
                      #{idx + 1}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-around gap-3 pt-2 px-2">
              {sections.map((sec, idx) => (
                <div
                  key={sec.id || idx}
                  className="flex-1 text-center text-[11px] font-cairo font-bold truncate"
                  title={sec.title}
                >
                  {sec.title}
                </div>
              ))}
            </div>
          </div>

          <div className={`grid ${gridColClass} gap-3`}>
            {sections.map((sec, idx) => {
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              return (
                <div
                  key={sec.id || idx}
                  className={`p-3.5 rounded-2xl border ${cardSurfaceClass}`}
                  style={{ borderTopWidth: '3px', borderTopColor: color }}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h4 className="font-cairo font-bold text-xs md:text-sm">{sec.title}</h4>
                    {sec.value && (
                      <span className="font-mono-numbers font-bold text-xs" style={{ color }}>
                        {sec.value}
                      </span>
                    )}
                  </div>
                  <p className="text-xs opacity-80 font-tajawal">{sec.description}</p>
                  {renderHighlightsAndMedia(sec, color)}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 13. ANALYTICAL FUNNEL */}
      {template === 'funnel' && (
        <div className="flex flex-col items-center gap-2 py-2">
          {sections.map((sec, idx) => {
            const total = Math.max(sections.length, 1);
            const widthPct = Math.round(100 - (idx / total) * 46);
            const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
            return (
              <React.Fragment key={sec.id || idx}>
                <div
                  style={{ width: `${widthPct}%`, backgroundColor: color }}
                  className="mx-auto px-5 py-3.5 rounded-2xl text-white shadow-md transition-all text-center"
                >
                  <div className="flex flex-wrap items-center justify-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded-full bg-white/20 text-[10px] font-mono-numbers font-black">
                      {sec.badge || (isAr ? `مرحلة ${idx + 1}` : `Stage ${idx + 1}`)}
                    </span>
                    <h4 className="font-cairo font-black text-xs md:text-sm">{sec.title}</h4>
                    {sec.value && (
                      <span className="px-2 py-0.5 rounded-md bg-black/25 font-mono-numbers font-bold text-xs">
                        {sec.value}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] md:text-xs text-white/90 font-tajawal leading-relaxed">
                    {sec.description}
                  </p>
                </div>
                {idx < sections.length - 1 && (
                  <ArrowDown className={`w-4 h-4 ${theme.accentText} opacity-60`} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      )}

      {/* 14. FISHBONE (ISHIKAWA CAUSE & EFFECT) */}
      {template === 'fishbone' && (
        <div className="space-y-4">
          <div className={`p-4 rounded-2xl bg-gradient-to-r ${theme.bannerGradient} text-white flex items-center justify-between gap-3 shadow-md`}>
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                <Target className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <span className="text-[10px] font-cairo font-bold opacity-80 block">
                  {isAr ? 'رأس المخطط (النتيجة / المفهوم الجامع)' : 'Primary Effect / Core Outcome'}
                </span>
                <h4 className="font-cairo font-black text-sm md:text-base">{title}</h4>
              </div>
            </div>
            <span className="text-xs font-mono-numbers bg-white/15 px-2.5 py-1 rounded-lg">
              {sections.length} {isAr ? 'أسباب / فروع' : 'Branches'}
            </span>
          </div>

          <div className="relative py-2">
            {/* Horizontal spine on desktop */}
            <div className={`hidden md:block absolute top-1/2 inset-x-4 h-1 rounded-full ${theme.accentBg} opacity-35 -translate-y-1/2`} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
              {sections.map((sec, idx) => {
                const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
                return (
                  <div
                    key={sec.id || idx}
                    className={`p-4 rounded-2xl border-2 shadow-xs ${cardSurfaceClass}`}
                    style={{ borderColor: color }}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span
                        className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-white text-[11px] font-cairo font-bold"
                        style={{ backgroundColor: color }}
                      >
                        {renderSectionGlyph(sec, idx)}
                        <span>{sec.badge || (isAr ? `سبب / عامل #${idx + 1}` : `Factor #${idx + 1}`)}</span>
                      </span>
                      {sec.value && (
                        <span className="font-mono-numbers font-bold text-xs" style={{ color }}>
                          {sec.value}
                        </span>
                      )}
                    </div>
                    <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                    <p className="text-xs opacity-80 font-tajawal mt-1 leading-relaxed">
                      {sec.description}
                    </p>
                    {renderHighlightsAndMedia(sec, color)}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 15. VENN OVERLAP DIAGRAM */}
      {template === 'venn' && (
        <div className="space-y-5">
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-0 py-3">
            {sections.slice(0, 3).map((sec, idx) => {
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              return (
                <div
                  key={sec.id || idx}
                  style={{ borderColor: color, backgroundColor: `${color}15` }}
                  className={`w-56 h-56 rounded-full border-2 flex flex-col items-center justify-center p-5 text-center shadow-sm backdrop-blur-[1px] ${
                    idx > 0 ? 'md:-mr-10 rtl:md:-ml-10 rtl:md:mr-0' : ''
                  }`}
                >
                  <span
                    className="px-2 py-0.5 rounded-full text-white text-[10px] font-cairo font-bold mb-1.5"
                    style={{ backgroundColor: color }}
                  >
                    {sec.badge || `#${idx + 1}`}
                  </span>
                  <h4 className="font-cairo font-black text-xs md:text-sm line-clamp-2">
                    {sec.title}
                  </h4>
                  {sec.value && (
                    <span className="font-mono-numbers font-bold text-xs mt-1" style={{ color }}>
                      {sec.value}
                    </span>
                  )}
                  <p className="text-[11px] opacity-80 font-tajawal mt-1 line-clamp-3 leading-snug">
                    {sec.description}
                  </p>
                </div>
              );
            })}
          </div>

          {sections.length > 3 && (
            <div className={`grid ${gridColClass} gap-3`}>
              {sections.slice(3).map((sec, idx) => {
                const realIdx = idx + 3;
                const color = sec.color || SECTION_COLORS[realIdx % SECTION_COLORS.length];
                return (
                  <div
                    key={sec.id || realIdx}
                    className={`p-3.5 rounded-2xl border ${cardSurfaceClass}`}
                    style={{ borderColor: color }}
                  >
                    <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                    <p className="text-xs opacity-80 font-tajawal mt-1">{sec.description}</p>
                    {renderHighlightsAndMedia(sec, color)}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 16. WINDING LEARNING ROADMAP */}
      {template === 'roadmap' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sections.map((sec, idx) => {
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              return (
                <div
                  key={sec.id || idx}
                  className={`p-4 rounded-2xl border relative overflow-hidden ${cardSurfaceClass}`}
                >
                  <div
                    className="absolute inset-y-0 right-0 rtl:right-0 ltr:left-0 w-1.5"
                    style={{ backgroundColor: color }}
                  />
                  <div className="flex items-start justify-between gap-2 ps-2">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-9 h-9 rounded-full text-white flex items-center justify-center font-mono-numbers font-black text-xs shadow-sm shrink-0"
                        style={{ backgroundColor: color }}
                      >
                        {renderSectionGlyph(sec, idx)}
                      </div>
                      <div>
                        <span className="text-[10px] font-cairo font-bold opacity-60 block">
                          {sec.badge || (isAr ? `المحطة ${idx + 1}` : `Milestone ${idx + 1}`)}
                        </span>
                        <h4 className="font-cairo font-bold text-sm">{sec.title}</h4>
                      </div>
                    </div>
                    {sec.value && (
                      <span className="px-2 py-0.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono-numbers font-bold text-xs shrink-0" style={{ color }}>
                        {sec.value}
                      </span>
                    )}
                  </div>
                  <p className="text-xs opacity-80 font-tajawal mt-2 ps-2 leading-relaxed">
                    {sec.description}
                  </p>
                  <div className="ps-2">{renderHighlightsAndMedia(sec, color)}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 17. INTERACTIVE STUDY FLASHCARDS */}
      {template === 'flashcards' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs opacity-75 font-cairo">
            <span>
              {isAr
                ? 'اضغط على أي بطاقة لقلبها واستعراض الشرح والإجابة التفصيلية:'
                : 'Click any flashcard to flip and reveal the explanation:'}
            </span>
          </div>
          <div className={`grid ${gridColClass} gap-3.5`}>
            {sections.map((sec, idx) => {
              const key = sec.id || String(idx);
              const isFlipped = Boolean(flippedCardIds[key]);
              const color = sec.color || SECTION_COLORS[idx % SECTION_COLORS.length];
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => toggleFlipCard(key)}
                  className={`text-start p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between min-h-[148px] ${
                    isFlipped
                      ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-500'
                      : cardSurfaceClass
                  }`}
                  style={!isFlipped ? { borderColor: color } : undefined}
                >
                  <div className="flex items-center justify-between gap-2 w-full">
                    <span
                      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-white text-[10px] font-cairo font-bold"
                      style={{ backgroundColor: color }}
                    >
                      {isFlipped
                        ? isAr
                          ? 'الشرح / الإجابة'
                          : 'Answer'
                        : sec.badge || (isAr ? `بطاقة #${idx + 1}` : `Card #${idx + 1}`)}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] font-cairo font-bold opacity-65">
                      <RotateCw className="w-3 h-3" />
                      <span>{isAr ? 'اقلب البطاقة' : 'Flip'}</span>
                    </span>
                  </div>

                  {!isFlipped ? (
                    <div className="my-2 space-y-1.5">
                      <h4 className="font-cairo font-black text-sm md:text-base">{sec.title}</h4>
                      {sec.value && (
                        <span className="inline-block font-mono-numbers font-bold text-xs px-2.5 py-0.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700" style={{ color }}>
                          {sec.value}
                        </span>
                      )}
                    </div>
                  ) : (
                    <div className="my-2 space-y-1.5">
                      <p className="text-xs font-tajawal leading-relaxed">{sec.description}</p>
                      {renderHighlightsAndMedia(sec, color)}
                    </div>
                  )}

                  <span className="text-[10px] opacity-55 font-tajawal">
                    {isFlipped
                      ? isAr
                        ? 'اضغط للعودة للسؤال/المصطلح'
                        : 'Click to flip back'
                      : isAr
                      ? 'اضغط لكشف الإجابة والتفاصيل'
                      : 'Click to reveal details'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Footer Accreditation */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs opacity-75 font-tajawal relative z-30">
        <span className="flex items-center gap-1.5">
          <Award className={`w-4 h-4 ${theme.accentText}`} />
          <span className="font-bold">
            {isAr
              ? 'منصة الشريف التعليمية · العلامة المائية الرسمية للدروس والمذكرات'
              : 'Al-Sharif Platform · Official Watermarked Lesson & Study Notes'}
          </span>
        </span>
        <span className="font-mono-numbers flex items-center gap-1">
          <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
          <span>{isAr ? 'معتمد للطباعة والنشر • منصة الشريف ✓' : 'Print & Publish Certified • Al-Sharif ✓'}</span>
        </span>
      </div>
    </div>
  );
};
