import React, { useState, useRef } from 'react';
import {
  Plus,
  Trash2,
  GitBranch,
  BarChart,
  Calendar,
  Grid,
  Triangle,
  Compass,
  RefreshCw,
  LayoutGrid,
  CheckSquare,
  ArrowUp,
  ArrowDown,
  Palette,
  Wand2,
  PieChart,
  BarChart3,
  Filter,
  Network,
  CircleDot,
  MapPin,
  CreditCard,
  Layers,
  Image as ImageIcon,
  Printer,
  FileCode2,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  InfographicData,
  InfographicSection,
  InfographicSurfaceStyle,
  InfographicTemplate,
  Language,
} from '../types';
import {
  InfographicRenderer,
  INFOGRAPHIC_THEMES,
  INFOGRAPHIC_ICON_MAP,
  buildInfographicEmbedHtml,
} from './InfographicRenderer';

export const TEMPLATE_CATALOG: Array<{
  id: InfographicTemplate;
  category: 'charts' | 'flows' | 'analysis';
  labelAr: string;
  labelEn: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'steps', category: 'flows', labelAr: 'مسار خطوات', labelEn: 'Steps Flow', icon: GitBranch },
  { id: 'roadmap', category: 'flows', labelAr: 'خارطة طريق', labelEn: 'Roadmap', icon: MapPin },
  { id: 'timeline', category: 'flows', labelAr: 'خط زمني', labelEn: 'Timeline', icon: Calendar },
  { id: 'cycle', category: 'flows', labelAr: 'دورة مستمرة', labelEn: 'Cycle Loop', icon: RefreshCw },
  { id: 'pyramid', category: 'analysis', labelAr: 'الهرم المعرفي', labelEn: 'Pyramid', icon: Triangle },
  { id: 'funnel', category: 'charts', labelAr: 'القمع التحليلي', labelEn: 'Funnel', icon: Filter },
  { id: 'donut', category: 'charts', labelAr: 'مخطط دائري SVG', labelEn: 'Donut Chart', icon: PieChart },
  { id: 'barchart', category: 'charts', labelAr: 'أعمدة بيانية', labelEn: 'Bar Chart', icon: BarChart3 },
  { id: 'stats', category: 'charts', labelAr: 'مؤشرات ونسب', labelEn: 'KPI Stats', icon: BarChart },
  { id: 'cards', category: 'analysis', labelAr: 'شبكة بطاقات', labelEn: 'Cards Grid', icon: Grid },
  { id: 'comparison', category: 'analysis', labelAr: 'مقارنة VS', labelEn: 'VS Compare', icon: Layers },
  { id: 'venn', category: 'analysis', labelAr: 'مخطط فين', labelEn: 'Venn Overlap', icon: CircleDot },
  { id: 'mindmap', category: 'analysis', labelAr: 'خريطة ذهنية', labelEn: 'Mind Map', icon: Compass },
  { id: 'fishbone', category: 'analysis', labelAr: 'عظمة السمكة', labelEn: 'Fishbone', icon: Network },
  { id: 'swot', category: 'analysis', labelAr: 'مصفوفة SWOT', labelEn: 'SWOT Matrix', icon: LayoutGrid },
  { id: 'checklist', category: 'flows', labelAr: 'قوانين ذهبية', labelEn: 'Checklist', icon: CheckSquare },
  { id: 'flashcards', category: 'analysis', labelAr: 'بطاقات استذكار', labelEn: 'Flashcards', icon: CreditCard },
];

export const SURFACE_OPTIONS: Array<{
  id: InfographicSurfaceStyle;
  labelAr: string;
  labelEn: string;
}> = [
  { id: 'modern', labelAr: 'حديث متوازن', labelEn: 'Modern' },
  { id: 'glass', labelAr: 'زجاجي متدرج', labelEn: 'Gradient' },
  { id: 'academic', labelAr: 'ورق أكاديمي', labelEn: 'Academic' },
  { id: 'dark', labelAr: 'ليلي احترافي', labelEn: 'Dark Pro' },
  { id: 'minimal', labelAr: 'خطوط مبسطة', labelEn: 'Minimal' },
];

export const INFOGRAPHIC_PRESETS: Array<{
  id: string;
  labelAr: string;
  template: InfographicTemplate;
  themeColor: string;
  title: string;
  summary: string;
  sections: InfographicSection[];
}> = [
  {
    id: 'preset-donut',
    labelAr: 'توزيع الدرجات (مخطط دائري)',
    template: 'donut',
    themeColor: 'sky',
    title: 'توزيع درجات التقييم الفصلي والاختبارات المعتمدة',
    summary: 'تمثيل بصري نسبي لمكونات التقييم التراكمي لمساعدة الطالب على التخطيط للمذاكرة.',
    sections: [
      { id: 'd-1', title: 'الاختبار النهائي التحريري', description: 'يغطي وحدات المنهج الأساسية والمهارات التحليلية العليا.', value: '50%', iconName: 'award', color: '#0284c7', badge: 'أساسي' },
      { id: 'd-2', title: 'الاختبارات الشهرية والأسبوعية', description: 'تقييمات دورية لقياس التقدم المرحلي ومعالجة نقاط الضعف.', value: '25%', iconName: 'pie', color: '#059669', badge: 'تراكمي' },
      { id: 'd-3', title: 'المشاريع والتطبيقات العملية', description: 'أوراق العمل والتجارب المخبرية والعروض التقديمية.', value: '15%', iconName: 'flask', color: '#d97706', badge: 'تطبيقي' },
      { id: 'd-4', title: 'المشاركة والحضور والانضباط', description: 'التفاعل داخل الحصص الإلكترونية والحضور المنتظم.', value: '10%', iconName: 'check', color: '#7c3aed', badge: 'انضباط' },
    ],
  },
  {
    id: 'preset-barchart',
    labelAr: 'مقارنة بيانية بالأعمدة',
    template: 'barchart',
    themeColor: 'indigo',
    title: 'معدلات التقدم الأسبوعي في حل التدريبات النموذجية',
    summary: 'قراءة بيانية واضحة لتطور مستوى الإتقان عبر أسابيع المراجعة المكثفة.',
    sections: [
      { id: 'b-1', title: 'الأسبوع 1: التأسيس', description: 'مراجعة المفاهيم الأساسية وحل مسائل الفهم المباشر.', value: '62', iconName: 'book', color: '#2563eb' },
      { id: 'b-2', title: 'الأسبوع 2: التطبيق', description: 'التدرب على المسائل متعددة الخطوات والربط بين القوانين.', value: '75', iconName: 'calc', color: '#0d9488' },
      { id: 'b-3', title: 'الأسبوع 3: التحليل', description: 'حل نماذج اختبارات سابقة تحت ضغط الوقت الفعلي.', value: '88', iconName: 'target', color: '#d97706' },
      { id: 'b-4', title: 'الأسبوع 4: الإتقان', description: 'الوصول لدرجة الجاهزية الكاملة وحل مسائل التحدي.', value: '96', iconName: 'award', color: '#059669' },
    ],
  },
  {
    id: 'preset-fishbone',
    labelAr: 'عظمة السمكة (أسباب ونتائج)',
    template: 'fishbone',
    themeColor: 'rose',
    title: 'تحليل أسباب التفوق العلمي وتفادي فقدان الدرجات',
    summary: 'مخطط إيشيكاوا لتحديد العوامل الرئيسية المؤثرة في الأداء الأكاديمي المتميز.',
    sections: [
      { id: 'f-1', title: 'التخطيط الزمني والجدول اليومي', description: 'تقسيم ساعات المذاكرة بوضوح دون تكديس الدروس.', value: 'عامل 1', iconName: 'clock', color: '#059669', highlights: ['تخصيص 45 دقيقة لكل مادة', 'فواصل راحة قصيرة'] },
      { id: 'f-2', title: 'تلخيص القوانين والخرائط الذهنية', description: 'تجميع المعادلات والرسوم التوضيحية في بطاقات مراجعة.', value: 'عامل 2', iconName: 'layers', color: '#2563eb', highlights: ['ربط المفهوم بالمثال', 'تمييز الثوابت والوحدات'] },
      { id: 'f-3', title: 'التدريب العملي والاختبارات القصيرة', description: 'قياس الفهم فوراً بعد كل درس وتصحيح الأخطاء.', value: 'عامل 3', iconName: 'check', color: '#d97706', highlights: ['حل 10 مسائل يومياً', 'توثيق الأخطاء المتكررة'] },
      { id: 'f-4', title: 'التركيز في الحصة وتدوين الملاحظات', description: 'تفاعل مباشر مع المعلم وطرح الأسئلة حول النقاط الغامضة.', value: 'عامل 4', iconName: 'lightbulb', color: '#e11d48', highlights: ['مراجعة الدرس قبل النوم', 'سؤال المعلم عن أي لبس'] },
    ],
  },
  {
    id: 'preset-pyramid',
    labelAr: 'الهرم المعرفي (مستويات)',
    template: 'pyramid',
    themeColor: 'violet',
    title: 'هرم بلوم المعرفي لإتقان حل المسائل العلمية',
    summary: 'تدرج منهجي من قاعدة التذكر والفهم الأساسي حتى قمة الإبداع وحل المشكلات المركبة.',
    sections: [
      { id: 'p-1', title: 'القمة: الإبداع والابتكار الرياضي', description: 'تصميم حلول جديدة وربط القوانين في مسائل غير مألوفة.', value: 'مستوى 1', iconName: 'sparkles', color: '#7c3aed' },
      { id: 'p-2', title: 'التحليل والتقويم المنطقي', description: 'مقارنة طرق الحل المختلفة واكتشاف الأخطاء الشائعة.', value: 'مستوى 2', iconName: 'compass', color: '#2563eb' },
      { id: 'p-3', title: 'التطبيق العملي المباشر', description: 'استخدام القوانين لحل التمارين النموذجية خطوة بخطوة.', value: 'مستوى 3', iconName: 'calc', color: '#0d9488' },
      { id: 'p-4', title: 'القاعدة: الفهم واستيعاب المفاهيم', description: 'إدراك التعريفات الأساسية والرموز القياسية للمادة.', value: 'مستوى 4', iconName: 'book', color: '#059669' },
    ],
  },
  {
    id: 'preset-flashcards',
    labelAr: 'بطاقات استذكار تفاعلية',
    template: 'flashcards',
    themeColor: 'emerald',
    title: 'بطاقات المراجعة السريعة لأهم القوانين والمصطلحات',
    summary: 'بطاقات تفاعلية قابلة للقلب لاختبار استرجاع الطالب للمعلومة وتثبيتها قبل الامتحان.',
    sections: [
      { id: 'fl-1', title: 'ما قانون حساب معدل التغير اللحظي؟', description: 'هو المشتقة الأولى للدالة f\'(x) وتقيس ميل المماس عند نقطة محددة على المنحنى.', value: "f'(x)", iconName: 'calc', color: '#059669', badge: 'سؤال 1' },
      { id: 'fl-2', title: 'متى تكون الدالة متزايدة تماماً؟', description: 'عندما تكون قيمة المشتقة الأولى موجبة f\'(x) > 0 على كامل الفترة المفتوحة.', value: "f'(x) > 0", iconName: 'trend', color: '#2563eb', badge: 'سؤال 2' },
      { id: 'fl-3', title: 'ما الشرط اللازم للنقاط الحرجة؟', description: 'أن تنعدم المشتقة الأولى f\'(x) = 0 أو تكون غير معرفة عند تلك النقطة.', value: "f'(x) = 0", iconName: 'target', color: '#d97706', badge: 'سؤال 3' },
      { id: 'fl-4', title: 'كيف نحدد نقاط الانقلاب؟', description: 'بمساواة المشتقة الثانية بالصفر f\'\'(x) = 0 مع تغير إشارة التقعر قبلها وبعدها.', value: "f''(x) = 0", iconName: 'zap', color: '#7c3aed', badge: 'سؤال 4' },
    ],
  },
  {
    id: 'preset-swot',
    labelAr: 'مصفوفة SWOT الرباعية',
    template: 'swot',
    themeColor: 'teal',
    title: 'مصفوفة التحليل الشامل للاستعداد للاختبارات النهائية',
    summary: 'رؤية رباعية متوازنة لتعزيز نقاط القوة وتلافي الأخطاء المتكررة في قاعة الامتحان.',
    sections: [
      { id: 's-1', title: 'نقاط القوة والتمكن', description: 'إتقان القوانين الأساسية والتدرب على نماذج الأعوام السابقة.', value: '85%', color: '#059669' },
      { id: 's-2', title: 'الفرص والمهارات المساندة', description: 'استغلال بنك الأسئلة التفاعلي وخرائط المفاهيم المختصرة.', value: '4 أدوات', color: '#2563eb' },
      { id: 's-3', title: 'التحديات وضيق الوقت', description: 'إدارة زمن الاختبار وتخصيص وقت مناسب للأسئلة المقالية.', value: '45 دقيقة', color: '#d97706' },
      { id: 's-4', title: 'تنبيهات الأخطاء الشائعة', description: 'مراجعة إشارات المعادلات وتحويل الوحدات قبل اعتماد الإجابة.', value: 'تنبيه هام', color: '#e11d48' },
    ],
  },
];

const CARD_SWATCHES = ['#059669', '#2563eb', '#0284c7', '#d97706', '#7c3aed', '#e11d48', '#0d9488'];

export interface InfographicStudioPanelProps {
  title: string;
  subject: string;
  grade: string;
  authorName?: string;
  data: InfographicData;
  onChange: (nextData: InfographicData) => void;
  onApplyPresetMeta?: (meta: { title: string; summary: string }) => void;
  onInsertHtmlIntoEditor?: (html: string) => void;
  language: Language;
  printableId?: string;
}

export const InfographicStudioPanel: React.FC<InfographicStudioPanelProps> = ({
  title,
  subject,
  grade,
  authorName,
  data,
  onChange,
  onApplyPresetMeta,
  onInsertHtmlIntoEditor,
  language,
  printableId = 'infographic-studio-preview',
}) => {
  const isAr = language === 'ar';
  const [tplCategory, setTplCategory] = useState<'all' | 'charts' | 'flows' | 'analysis'>('all');
  const [expandedNodeId, setExpandedNodeId] = useState<string | null>(null);
  const nodeImageFileRef = useRef<HTMLInputElement | null>(null);
  const [uploadTargetSectionId, setUploadTargetSectionId] = useState<string | null>(null);

  const sections = data.sections || [];

  const updateData = (patch: Partial<InfographicData>) => {
    onChange({ ...data, ...patch });
  };

  const applyPreset = (presetId: string) => {
    const found = INFOGRAPHIC_PRESETS.find((p) => p.id === presetId);
    if (!found) return;
    onChange({
      ...data,
      template: found.template,
      themeColor: found.themeColor,
      summary: found.summary,
      sections: found.sections.map((s, i) => ({ ...s, id: `sec-${Date.now()}-${i}` })),
    });
    if (onApplyPresetMeta) {
      onApplyPresetMeta({ title: found.title, summary: found.summary });
    }
  };

  const handleAddSection = () => {
    const nextIdx = sections.length + 1;
    const newId = `sec-${Date.now()}`;
    updateData({
      sections: [
        ...sections,
        {
          id: newId,
          title: isAr ? `المحطة ${nextIdx}: مفهوم تعليمي` : `Node ${nextIdx}`,
          description: isAr
            ? 'أضف شرح المفهوم التعليمي بأسلوب بصري واضح ومباشر.'
            : 'Add concise explanation for this concept node.',
          value: `${Math.min(100, nextIdx * 20)}%`,
          color: CARD_SWATCHES[(nextIdx - 1) % CARD_SWATCHES.length],
          iconName: 'sparkles',
        },
      ],
    });
    setExpandedNodeId(newId);
  };

  const handleRemoveSection = (id: string) => {
    if (sections.length <= 1) return;
    updateData({ sections: sections.filter((s) => s.id !== id) });
  };

  const handleMoveSection = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= sections.length) return;
    const copy = [...sections];
    const temp = copy[index];
    copy[index] = copy[target];
    copy[target] = temp;
    updateData({ sections: copy });
  };

  const handleUpdateSection = (id: string, patch: Partial<InfographicSection>) => {
    updateData({
      sections: sections.map((s) => (s.id === id ? { ...s, ...patch } : s)),
    });
  };

  const handleNodeImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !uploadTargetSectionId) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        handleUpdateSection(uploadTargetSectionId, { imageUrl: reader.result });
      }
      setUploadTargetSectionId(null);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleDownloadHtmlPoster = () => {
    const embedHtml = buildInfographicEmbedHtml(
      title || 'انفوجرافيك تعليمي',
      subject,
      grade,
      { ...data, authorName: data.authorName || authorName },
      isAr
    );
    const fullDoc = `<!DOCTYPE html><html lang="${isAr ? 'ar' : 'en'}" dir="${isAr ? 'rtl' : 'ltr'}"><head><meta charset="utf-8" /><title>${title || 'Infographic'}</title></head><body style="max-width:960px;margin:24px auto;padding:16px;background:#f1f5f9;">${embedHtml}</body></html>`;
    const blob = new Blob(['\ufeff', fullDoc], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(title || 'infographic').replace(/\s+/g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const visibleTemplates =
    tplCategory === 'all'
      ? TEMPLATE_CATALOG
      : TEMPLATE_CATALOG.filter((t) => t.category === tplCategory);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 flex-1 overflow-hidden">
      <input
        ref={nodeImageFileRef}
        type="file"
        accept="image/*"
        onChange={handleNodeImageUpload}
        className="hidden"
      />

      {/* Controls Sidebar */}
      <div className="lg:col-span-5 p-4 overflow-y-auto border-b lg:border-b-0 lg:border-l border-slate-200 dark:border-slate-800 space-y-4 bg-slate-50/70 dark:bg-slate-950/40 text-xs max-h-[60vh] lg:max-h-full">
        {/* Quick Curriculum Presets */}
        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-200 text-xs">
            <Wand2 className="w-3.5 h-3.5 text-amber-500" />
            <span>{isAr ? 'قوالب انفوجرافيك جاهزة ذكية (تطبيق فوري):' : 'Smart Starter Presets:'}</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {INFOGRAPHIC_PRESETS.map((preset) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => applyPreset(preset.id)}
                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-emerald-950/50 text-slate-700 dark:text-slate-200 hover:text-emerald-700 border border-slate-200 dark:border-slate-700 text-[11px] font-bold transition-colors cursor-pointer"
              >
                {preset.labelAr}
              </button>
            ))}
          </div>
        </div>

        {/* Core Summary Concept */}
        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
            {isAr ? 'ملخص الفكرة الجوهرية للانفوجرافيك' : 'Infographic Core Summary'}
          </label>
          <textarea
            rows={2}
            value={data.summary}
            onChange={(e) => updateData({ summary: e.target.value })}
            placeholder={isAr ? 'اكتب ملخصاً بصرياً مقتضباً يظهر في رأس اللوحة...' : 'Short infographic banner summary...'}
            className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs font-tajawal"
          />
        </div>

        {/* 17 Templates Selector with Category Tabs */}
        <div className="space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <label className="font-bold text-slate-700 dark:text-slate-300">
              {isAr ? `نماذج التصميم (${TEMPLATE_CATALOG.length} قالب):` : `Templates (${TEMPLATE_CATALOG.length}):`}
            </label>
            <div className="flex items-center gap-1 bg-slate-200/70 dark:bg-slate-800 p-0.5 rounded-lg text-[10px] font-bold">
              {[
                { id: 'all', ar: 'الكل', en: 'All' },
                { id: 'charts', ar: 'بيانية', en: 'Charts' },
                { id: 'flows', ar: 'مسارات', en: 'Flows' },
                { id: 'analysis', ar: 'تحليل', en: 'Analysis' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setTplCategory(cat.id as typeof tplCategory)}
                  className={`px-2 py-0.5 rounded-md cursor-pointer transition-colors ${
                    tplCategory === cat.id
                      ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {isAr ? cat.ar : cat.en}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {visibleTemplates.map((tpl) => {
              const Icon = tpl.icon;
              const isSelected = data.template === tpl.id;
              return (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => updateData({ template: tpl.id })}
                  className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-950 dark:text-emerald-100 ring-2 ring-emerald-500/20 font-bold'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span className="text-[11px] truncate w-full">
                    {isAr ? tpl.labelAr : tpl.labelEn}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Themes & Visual Surface Style + Columns */}
        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <div>
            <label className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              <Palette className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isAr ? 'الهوية اللونية (8 سمات):' : 'Visual Color Theme (8):'}</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {Object.values(INFOGRAPHIC_THEMES).map((t) => {
                const active = data.themeColor === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => updateData({ themeColor: t.id })}
                    className={`px-2 py-1.5 rounded-xl border text-[10px] font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      active
                        ? 'border-slate-900 dark:border-white bg-slate-100 dark:bg-slate-800 shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 opacity-80 hover:opacity-100'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full shrink-0 border border-white shadow-xs"
                      style={{ backgroundColor: t.hex }}
                    />
                    <span className="truncate">{isAr ? t.labelAr : t.labelEn}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-[11px]">
                {isAr ? 'نمط خلفية اللوحة:' : 'Canvas Surface Style:'}
              </label>
              <select
                value={data.surfaceStyle || 'modern'}
                onChange={(e) =>
                  updateData({ surfaceStyle: e.target.value as InfographicSurfaceStyle })
                }
                className="w-full px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold cursor-pointer"
              >
                {SURFACE_OPTIONS.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {isAr ? opt.labelAr : opt.labelEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1 text-[11px]">
                {isAr ? 'توزيع الأعمدة الشبكية:' : 'Grid Columns:'}
              </label>
              <div className="grid grid-cols-3 gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl">
                {([1, 2, 3] as const).map((col) => (
                  <button
                    key={col}
                    type="button"
                    onClick={() => updateData({ columns: col })}
                    className={`py-1 rounded-lg text-[11px] font-mono-numbers font-bold cursor-pointer ${
                      (data.columns || 2) === col
                        ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 shadow-xs'
                        : 'text-slate-500'
                    }`}
                  >
                    {col} {isAr ? 'عمود' : 'col'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Rich Nodes & Stations Editor */}
        <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-800 dark:text-slate-200 text-xs">
              {isAr ? `عناصر ومحطات الانفوجرافيك (${sections.length}):` : `Nodes (${sections.length}):`}
            </span>
            <button
              type="button"
              onClick={handleAddSection}
              className="px-2.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة محطة' : 'Add Node'}</span>
            </button>
          </div>

          <div className="space-y-2">
            {sections.map((sec, idx) => {
              const isExpanded = expandedNodeId === sec.id;
              return (
                <div
                  key={sec.id}
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2"
                >
                  <div className="flex items-center justify-between gap-1.5">
                    <span className="font-mono-numbers font-black text-emerald-600 text-xs w-6">
                      #{idx + 1}
                    </span>
                    <input
                      type="text"
                      value={sec.title}
                      onChange={(e) => handleUpdateSection(sec.id, { title: e.target.value })}
                      placeholder="عنوان المحطة..."
                      className="flex-1 min-w-0 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={() => handleMoveSection(idx, -1)}
                      disabled={idx === 0}
                      className="p-1 text-slate-400 hover:text-slate-700 disabled:opacity-25 cursor-pointer"
                      title="تحريك للأعلى"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleMoveSection(idx, 1)}
                      disabled={idx === sections.length - 1}
                      className="p-1 text-slate-400 hover:text-slate-700 disabled:opacity-25 cursor-pointer"
                      title="تحريك للأسفل"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setExpandedNodeId(isExpanded ? null : sec.id)}
                      className="p-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                      title={isAr ? 'خيارات متقدمة (أيقونة، نقاط، صورة)' : 'Advanced node options'}
                    >
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSection(sec.id)}
                      disabled={sections.length <= 1}
                      className="p-1 text-slate-400 hover:text-rose-500 disabled:opacity-30 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div className="sm:col-span-2">
                      <textarea
                        rows={2}
                        value={sec.description}
                        onChange={(e) => handleUpdateSection(sec.id, { description: e.target.value })}
                        placeholder="شرح وتفاصيل المحطة..."
                        className="w-full px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-tajawal text-slate-800 dark:text-slate-200"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={sec.value || ''}
                        onChange={(e) => handleUpdateSection(sec.id, { value: e.target.value })}
                        placeholder="قيمة / نسبة / قانون"
                        className="w-full px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-mono-numbers font-bold text-center text-emerald-700 dark:text-emerald-300"
                      />
                      <div className="flex items-center justify-center gap-1 flex-wrap">
                        {CARD_SWATCHES.map((hex) => (
                          <button
                            key={hex}
                            type="button"
                            onClick={() => handleUpdateSection(sec.id, { color: hex })}
                            className={`w-3.5 h-3.5 rounded-full cursor-pointer ${
                              sec.color === hex ? 'ring-2 ring-offset-1 ring-slate-900 dark:ring-white' : ''
                            }`}
                            style={{ backgroundColor: hex }}
                            title="لون البطاقة"
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Per-Node Advanced Tools: Icon, Badge, Image, Sub-bullets */}
                  {isExpanded && (
                    <div className="pt-2.5 mt-2 border-t border-slate-200 dark:border-slate-800 space-y-2.5 text-[11px]">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">
                            {isAr ? 'وسم / تصنيف البطاقة:' : 'Card Badge:'}
                          </label>
                          <input
                            type="text"
                            value={sec.badge || ''}
                            onChange={(e) => handleUpdateSection(sec.id, { badge: e.target.value })}
                            placeholder={isAr ? 'مثال: قانون هام' : 'e.g. Key Rule'}
                            className="w-full px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">
                            {isAr ? 'صورة / رسم توضيحي للمحطة:' : 'Node Image URL:'}
                          </label>
                          <div className="flex items-center gap-1">
                            <input
                              type="text"
                              value={sec.imageUrl || ''}
                              onChange={(e) => handleUpdateSection(sec.id, { imageUrl: e.target.value })}
                              placeholder="https://..."
                              className="flex-1 min-w-0 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-[10px]"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                setUploadTargetSectionId(sec.id);
                                nodeImageFileRef.current?.click();
                              }}
                              className="px-2 py-1 rounded-lg bg-blue-600 text-white font-bold cursor-pointer shrink-0 flex items-center gap-1"
                              title="رفع صورة"
                            >
                              <ImageIcon className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Icon Picker */}
                      <div>
                        <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'أيقونة المحطة:' : 'Node Icon:'}
                        </label>
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(INFOGRAPHIC_ICON_MAP).map(([key, item]) => {
                            const IconComp = item.Icon;
                            const active = sec.iconName === key;
                            return (
                              <button
                                key={key}
                                type="button"
                                onClick={() => handleUpdateSection(sec.id, { iconName: active ? undefined : key })}
                                title={item.labelAr}
                                className={`p-1.5 rounded-lg border cursor-pointer ${
                                  active
                                    ? 'bg-emerald-600 text-white border-emerald-600'
                                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                                }`}
                              >
                                <IconComp className="w-3.5 h-3.5" />
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Sub-bullets Highlights */}
                      <div>
                        <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'نقاط فرعية (سطر لكل نقطة):' : 'Highlights (one per line):'}
                        </label>
                        <textarea
                          rows={2}
                          value={(sec.highlights || []).join('\n')}
                          onChange={(e) =>
                            handleUpdateSection(sec.id, {
                              highlights: e.target.value
                                .split('\n')
                                .map((l) => l.trimStart()),
                            })
                          }
                          placeholder={isAr ? 'نقطة فرعية 1\nنقطة فرعية 2' : 'Bullet 1\nBullet 2'}
                          className="w-full px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-tajawal"
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Live Preview Canvas */}
      <div className="lg:col-span-7 p-4 md:p-6 overflow-y-auto bg-slate-100 dark:bg-slate-950 flex flex-col justify-between gap-4">
        <InfographicRenderer
          title={title}
          subject={subject}
          grade={grade}
          data={{ ...data, authorName: data.authorName || authorName }}
          language={language}
          printableId={printableId}
        />

        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 font-cairo">
          <span className="text-xs text-slate-500 font-tajawal">
            {isAr
              ? 'معاينة فورية تفاعلية تدعم التصدير كـ HTML و PDF'
              : 'Live interactive preview supporting HTML & PDF export'}
          </span>

          <div className="flex flex-wrap items-center gap-2">
            {onInsertHtmlIntoEditor && (
              <button
                type="button"
                onClick={() => {
                  const html = buildInfographicEmbedHtml(
                    title || 'انفوجرافيك الدرس',
                    subject,
                    grade,
                    { ...data, authorName: data.authorName || authorName },
                    isAr
                  );
                  onInsertHtmlIntoEditor(html);
                }}
                className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{isAr ? 'إدراج في شاشة كتابة الدرس' : 'Insert into Lesson Editor'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleDownloadHtmlPoster}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <FileCode2 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تصدير بوستر HTML' : 'Export HTML'}</span>
            </button>

            <button
              type="button"
              onClick={() => window.print()}
              className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isAr ? 'طباعة / PDF' : 'Print PDF'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
