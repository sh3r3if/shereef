import React, { useState, useMemo, useEffect } from 'react';
import {
  Users2,
  Plus,
  Search,
  Trash2,
  Edit,
  Eye,
  Star,
  BookOpen,
  Phone,
  Mail,
  GraduationCap,
  X,
  ChevronLeft,
  ChevronRight,
  UserCheck,
  RefreshCw,
  Database,
  AlertTriangle,
  CheckCircle2,
  Check,
  Filter,
  Download,
  Award,
  Calendar,
  Upload,
  Camera,
  FileText,
  Sparkles,
  Clock,
  ExternalLink,
  Loader2,
} from 'lucide-react';
import { Teacher, Lesson, Quiz, CurrentUser, Language } from '../types';
import {
  DEFAULT_TEACHER_AVATAR,
  DEFAULT_TEACHER_FEMALE_AVATAR,
  CERTIFICATE_CREST_IMAGE,
  getSafeAvatarUrl,
  handleImageErrorToTeacherAvatar,
  readAndResizeImageFile,
} from '../utils/avatarFallback';

export interface TeacherPdfMetadata {
  id: string;
  teacherId: string;
  fileName: string;
  fileSizeBytes: number;
  subject: string;
  grade: string;
  uploadedAt: string;
  uploadedBy: string;
  status: 'uploaded_pending' | 'fed';
  fedAt?: string;
  fedLessonsCount?: number;
  fedQuizId?: string;
  fedQuestionsCount?: number;
  fedChapterId?: string;
}

interface QueuedPdfFile {
  tempId: string;
  fileName: string;
  fileSizeBytes: number;
  base64Data: string;
  subject: string;
  grade: string;
}

interface TeachersDirectoryProps {
  teachers: Teacher[];
  lessons?: Lesson[];
  currentUser?: CurrentUser;
  onAddTeacher: (teacher: Teacher | Omit<Teacher, 'id' | 'rating' | 'totalStudents' | 'activeLessonsCount' | 'joinedDate'>) => void;
  onUpdateTeacher: (teacher: Teacher) => void;
  onDeleteTeacher: (id: string) => void;
  onLessonsAdded?: (createdLessons: Lesson[]) => void;
  onQuizAdded?: (createdQuiz: Quiz) => void;
  language: Language;
}

const ITEMS_PER_PAGE = 6;

const AVATAR_PRESETS = [
  { label: 'أستاذ (صورة 1)', url: DEFAULT_TEACHER_AVATAR },
  { label: 'أستاذة (صورة 2)', url: DEFAULT_TEACHER_FEMALE_AVATAR },
  { label: 'شعار التميز', url: CERTIFICATE_CREST_IMAGE },
];

export const TeachersDirectory: React.FC<TeachersDirectoryProps> = ({
  teachers: propTeachers,
  lessons = [],
  currentUser,
  onAddTeacher,
  onUpdateTeacher,
  onDeleteTeacher,
  onLessonsAdded,
  onQuizAdded,
  language,
}) => {
  const isAr = language === 'ar';
  const canManageStaffCrud =
    !currentUser || ['admin', 'supervisor', 'secretary'].includes(currentUser.role);
  const canManagePdfFeeding =
    !currentUser ||
    ['admin', 'supervisor', 'secretary', 'teacher'].includes(currentUser.role);

  const buildAuthHeaders = (includeJson = true): Record<string, string> => {
    const headers: Record<string, string> = {};
    if (includeJson) headers['Content-Type'] = 'application/json';
    if (currentUser) {
      headers['x-user-role'] = String(currentUser.role || '');
      headers['x-user-id'] = encodeURIComponent(String(currentUser.id || ''));
      headers['x-user-name'] = encodeURIComponent(String(currentUser.name || ''));
      if (currentUser.teacherId) {
        headers['x-teacher-id'] = encodeURIComponent(String(currentUser.teacherId));
      }
    }
    return headers;
  };

  // Local state synchronized strictly with Cloud SQL
  const [teachersList, setTeachersList] = useState<Teacher[]>(propTeachers);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Teacher PDF Library + Automatic Lesson & Quiz Feeding States
  const [pdfByTeacher, setPdfByTeacher] = useState<Record<string, TeacherPdfMetadata[]>>({});
  const [queuedPdfs, setQueuedPdfs] = useState<QueuedPdfFile[]>([]);
  const [feedSubject, setFeedSubject] = useState('');
  const [feedGrade, setFeedGrade] = useState('الصف الثاني الثانوي');
  const [feedQuizType, setFeedQuizType] = useState<'weekly' | 'monthly'>('weekly');
  const [feedLessonCount, setFeedLessonCount] = useState<number>(4);
  const [feedQuestionsCount, setFeedQuestionsCount] = useState<number>(10);
  const [feedSyncCurriculum, setFeedSyncCurriculum] = useState<boolean>(true);
  const [isUploadingPdfs, setIsUploadingPdfs] = useState(false);
  const [isFeedingPdfs, setIsFeedingPdfs] = useState(false);
  const [feedStatusText, setFeedStatusText] = useState('');
  const [feedErrorText, setFeedErrorText] = useState('');
  const [feedSuccessSummary, setFeedSuccessSummary] = useState<{
    lessonsCount: number;
    questionsCount: number;
    quizzesCount: number;
    curriculumSyncedCount: number;
  } | null>(null);

  useEffect(() => {
    setTeachersList(propTeachers);
  }, [propTeachers]);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Search, Filters, Pagination
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [viewingTeacher, setViewingTeacher] = useState<Teacher | null>(null);
  const [teacherToDelete, setTeacherToDelete] = useState<Teacher | null>(null);

  // Form States
  const [formName, setFormName] = useState('');
  const [formSpecialty, setFormSpecialty] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formGrades, setFormGrades] = useState<string>('الصف الأول الثانوي, الصف الثاني الثانوي, الصف الثالث الثانوي');
  const [formBio, setFormBio] = useState('');
  const [formRating, setFormRating] = useState<string>('5.0');
  const [formTotalStudents, setFormTotalStudents] = useState<string>('0');
  const [formAvatar, setFormAvatar] = useState(DEFAULT_TEACHER_AVATAR);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  // Unique Specialties list
  const specialtiesList = useMemo(() => {
    const set = new Set<string>();
    teachersList.forEach((t) => {
      if (t.specialty) set.add(t.specialty);
    });
    return Array.from(set);
  }, [teachersList]);

  // Direct DB Load & Refresh
  const fetchPdfSummary = async () => {
    try {
      const pdfRes = await fetch('/api/teachers/pdfs/summary');
      if (pdfRes.ok) {
        const payload = await pdfRes.json();
        if (payload?.byTeacher && typeof payload.byTeacher === 'object') {
          setPdfByTeacher(payload.byTeacher);
        }
      }
    } catch (err) {
      console.warn('Failed to load teacher PDF summary:', err);
    }
  };

  const handleRefreshFromDb = async (silent = false) => {
    setIsLoading(true);
    try {
      const [res] = await Promise.all([fetch('/api/teachers'), fetchPdfSummary()]);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const parsed: Teacher[] = data.map((t: any) => ({
            ...t,
            grades: typeof t.grades === 'string' ? JSON.parse(t.grades || '[]') : t.grades || [],
            rating: Number(t.rating) || 4.9,
          }));
          setTeachersList(parsed);
          if (!silent) {
            showToast(isAr ? 'تم تحديث دليل المعلمين من قاعدة البيانات بنجاح ✓' : 'Refreshed from database ✓', 'info');
          }
        }
      }
    } catch (err) {
      console.error('Failed to reload teachers:', err);
      if (!silent) {
        showToast(isAr ? 'تعذر الاتصال بقاعدة البيانات' : 'Failed to refresh', 'error');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    handleRefreshFromDb(true);
  }, []);

  // Export CSV
  const handleExportCsv = () => {
    const headers = ['المعرف', 'الاسم الكامل', 'التخصص', 'البريد الإلكتروني', 'رقم الهاتف', 'التقييم', 'عدد الطلاب', 'المراحل الدراسية', 'تاريخ الانضمام'];
    const rows = filteredTeachers.map((t) => [
      t.id,
      t.name,
      t.specialty,
      t.email,
      t.phone,
      t.rating,
      t.totalStudents,
      t.grades.join(' | '),
      t.joinedDate,
    ]);
    const csvContent =
      '\uFEFF' +
      [headers, ...rows]
        .map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','))
        .join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `teachers_directory_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(isAr ? 'تم تصدير ملف الكادر التعليمي بصيغة Excel/CSV ✓' : 'Exported CSV ✓');
  };

  // Filter
  const filteredTeachers = useMemo(() => {
    return teachersList.filter((t) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        t.name.toLowerCase().includes(q) ||
        (t.nameEn && t.nameEn.toLowerCase().includes(q)) ||
        t.specialty.toLowerCase().includes(q) ||
        (t.email && t.email.toLowerCase().includes(q)) ||
        (t.phone && t.phone.toLowerCase().includes(q)) ||
        (t.bio && t.bio.toLowerCase().includes(q)) ||
        t.grades.some((g) => g.toLowerCase().includes(q));

      const matchesSpecialty = selectedSpecialty === 'all' || t.specialty === selectedSpecialty;
      return matchesSearch && matchesSpecialty;
    });
  }, [teachersList, searchQuery, selectedSpecialty]);

  // Pagination
  const totalPages = Math.ceil(filteredTeachers.length / ITEMS_PER_PAGE) || 1;
  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages);
  }, [currentPage, totalPages]);

  const paginatedTeachers = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredTeachers.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredTeachers, currentPage]);

  // Open Create
  const handleOpenAdd = () => {
    setFormName('');
    setFormSpecialty('');
    setFormEmail('');
    setFormPhone('');
    setFormGrades('الصف الأول الثانوي, الصف الثاني الثانوي, الصف الثالث الثانوي');
    setFormBio('');
    setFormRating('5.0');
    setFormTotalStudents('0');
    setFormAvatar(DEFAULT_TEACHER_AVATAR);
    setQueuedPdfs([]);
    setFeedSubject('');
    setFeedGrade('الصف الثاني الثانوي');
    setFeedErrorText('');
    setFeedSuccessSummary(null);
    setIsAddModalOpen(true);
  };

  // Open Edit
  const handleOpenEdit = (t: Teacher) => {
    setEditingTeacher(t);
    setFormName(t.name);
    setFormSpecialty(t.specialty);
    setFormEmail(t.email);
    setFormPhone(t.phone);
    setFormGrades(Array.isArray(t.grades) ? t.grades.join(', ') : '');
    setFormBio(t.bio || '');
    setFormRating(String(t.rating || 5.0));
    setFormTotalStudents(String(t.totalStudents || 0));
    setFormAvatar(getSafeAvatarUrl(t.avatar));
    setQueuedPdfs([]);
    setFeedSubject(t.specialty || '');
    setFeedGrade(Array.isArray(t.grades) && t.grades[0] ? t.grades[0] : 'الصف الثاني الثانوي');
    setFeedErrorText('');
    setFeedSuccessSummary(null);
  };

  const handleOpenViewTeacher = (t: Teacher) => {
    setViewingTeacher(t);
    setQueuedPdfs([]);
    setFeedSubject(t.specialty || '');
    setFeedGrade(Array.isArray(t.grades) && t.grades[0] ? t.grades[0] : 'الصف الثاني الثانوي');
    setFeedErrorText('');
    setFeedSuccessSummary(null);
  };

  const handleTeacherPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingAvatar(true);
    try {
      const dataUrl = await readAndResizeImageFile(file, 420, 0.85);
      setFormAvatar(dataUrl);
      showToast(isAr ? 'تم تجهيز صورة المعلم بنجاح ✓' : 'Teacher photo ready ✓', 'info');
    } catch (err: any) {
      showToast(err?.message || (isAr ? 'تعذر رفع الصورة' : 'Upload failed'), 'error');
    } finally {
      setIsUploadingAvatar(false);
      e.target.value = '';
    }
  };

  // Helper: Read selected PDF files cleanly (Strictly queues/uploads ONLY; does NOT auto-feed until button press!)
  const readFileAsDataUrl = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error(`تعذر قراءة الملف: ${file.name}`));
      reader.readAsDataURL(file);
    });

  const handleSelectPdfFilesForModal = async (
    e: React.ChangeEvent<HTMLInputElement>,
    directTeacherId?: string
  ) => {
    const fileList = Array.from(e.target.files || []);
    e.target.value = '';
    if (fileList.length === 0) return;

    const validPdfs = fileList.filter(
      (f) => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf')
    );
    if (validPdfs.length === 0) {
      showToast(isAr ? 'يرجى اختيار ملفات بصيغة PDF فقط.' : 'PDF files only.', 'error');
      return;
    }

    const tooLarge = validPdfs.find((f) => f.size > 32 * 1024 * 1024);
    if (tooLarge) {
      showToast(
        isAr
          ? `حجم الملف (${tooLarge.name}) يتجاوز الحد الأقصى المسموح (32 ميجابايت).`
          : `File too large: ${tooLarge.name}`,
        'error'
      );
      return;
    }

    setFeedErrorText('');
    setFeedSuccessSummary(null);
    const defaultSubj = (feedSubject || formSpecialty || 'المادة الدراسية').trim();
    const defaultGrd =
      (feedGrade || formGrades.split(',')[0] || 'الصف الثاني الثانوي').trim();

    if (directTeacherId) {
      // Upload directly to teacher's server library with status = 'uploaded_pending' (NO automatic feeding yet!)
      setIsUploadingPdfs(true);
      try {
        const prepared = await Promise.all(
          validPdfs.map(async (f) => ({
            fileName: f.name,
            fileSizeBytes: f.size,
            base64Data: await readFileAsDataUrl(f),
            subject: defaultSubj,
            grade: defaultGrd,
          }))
        );
        const res = await fetch(`/api/teachers/${directTeacherId}/pdfs`, {
          method: 'POST',
          headers: buildAuthHeaders(true),
          body: JSON.stringify({
            files: prepared,
            subject: defaultSubj,
            grade: defaultGrd,
            uploadedBy: currentUser?.name || formName || 'المعلم',
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data?.error || 'تعذر رفع ملفات PDF');
        }
        setPdfByTeacher((prev) => ({
          ...prev,
          [directTeacherId]: Array.isArray(data.pdfs) ? data.pdfs : prev[directTeacherId] || [],
        }));
        showToast(
          isAr
            ? `تم رفع ${prepared.length} ملف PDF ✓ اضغط زر «تغذية الدروس والاختبارات» لتوليدها الآن.`
            : `Uploaded ${prepared.length} PDF(s). Click Feed button to generate.`,
          'info'
        );
      } catch (err: any) {
        showToast(err?.message || 'فشل رفع ملف PDF', 'error');
      } finally {
        setIsUploadingPdfs(false);
      }
      return;
    }

    // Queue locally inside Add Teacher modal until saved or fed
    setIsUploadingPdfs(true);
    try {
      const nextItems: QueuedPdfFile[] = await Promise.all(
        validPdfs.map(async (f) => ({
          tempId: `qpdf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          fileName: f.name,
          fileSizeBytes: f.size,
          base64Data: await readFileAsDataUrl(f),
          subject: defaultSubj,
          grade: defaultGrd,
        }))
      );
      setQueuedPdfs((prev) => [...prev, ...nextItems]);
      showToast(
        isAr
          ? `تم إرفاق ${nextItems.length} ملف PDF ✓ اضغط زر «تغذية الدروس والاختبارات» بعد الحفظ لتوليد المحتوى.`
          : `Attached ${nextItems.length} PDF(s).`,
        'info'
      );
    } catch (err: any) {
      showToast(err?.message || 'تعذر قراءة ملف PDF', 'error');
    } finally {
      setIsUploadingPdfs(false);
    }
  };

  const handleDeleteSavedTeacherPdf = async (teacherId: string, pdfId: string) => {
    try {
      const res = await fetch(`/api/teachers/${teacherId}/pdfs/${pdfId}`, {
        method: 'DELETE',
        headers: buildAuthHeaders(false),
      });
      const data = await res.json();
      if (res.ok) {
        setPdfByTeacher((prev) => ({
          ...prev,
          [teacherId]: Array.isArray(data.pdfs) ? data.pdfs : [],
        }));
        showToast(isAr ? 'تم حذف ملف PDF من مكتبة المعلم' : 'PDF removed', 'info');
      }
    } catch {
      showToast(isAr ? 'تعذر حذف ملف PDF' : 'Delete failed', 'error');
    }
  };

  // Helper to upload queued PDFs for a newly created/edited teacher (stays uploaded_pending!)
  const uploadQueuedPdfsForTeacher = async (
    teacherId: string,
    files: QueuedPdfFile[],
    subject: string,
    grade: string
  ) => {
    if (files.length === 0) return [];
    const res = await fetch(`/api/teachers/${teacherId}/pdfs`, {
      method: 'POST',
      headers: buildAuthHeaders(true),
      body: JSON.stringify({
        files: files.map((f) => ({
          fileName: f.fileName,
          fileSizeBytes: f.fileSizeBytes,
          base64Data: f.base64Data,
          subject: subject || f.subject,
          grade: grade || f.grade,
        })),
        subject,
        grade,
        uploadedBy: currentUser?.name || formName || 'المعلم',
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error || 'تعذر حفظ ملفات PDF المرفقة للمعلم');
    }
    setPdfByTeacher((prev) => ({
      ...prev,
      [teacherId]: Array.isArray(data.pdfs) ? data.pdfs : [],
    }));
    return Array.isArray(data.uploaded) ? (data.uploaded as TeacherPdfMetadata[]) : [];
  };

  // Helper to create teacher in DB and return normalized object
  const persistNewTeacher = async (): Promise<Teacher | null> => {
    const parsedGrades = formGrades
      .split(',')
      .map((g) => g.trim())
      .filter(Boolean);

    const newTeacherId = `tch-${Date.now()}`;
    const newTeacherObj: Teacher = {
      id: newTeacherId,
      name: formName.trim() || 'أستاذ المادة',
      nameEn: formName.trim() || 'Educator',
      specialty: formSpecialty.trim() || 'المواد العلمية',
      specialtyEn: formSpecialty.trim() || 'Academic',
      email: formEmail.trim() || `teacher.${Date.now()}@nawabegh.edu`,
      phone: formPhone.trim() || '+966 50 000 0000',
      grades: parsedGrades.length > 0 ? parsedGrades : ['الصف الثاني الثانوي'],
      bio: formBio.trim() || 'معلم معتمد في منصة نوابغ التعليمية.',
      avatar: formAvatar,
      rating: Number(formRating) || 5.0,
      totalStudents: Number(formTotalStudents) || 0,
      activeLessonsCount: 0,
      joinedDate: new Date().toISOString().split('T')[0],
    };

    const res = await fetch('/api/teachers', {
      method: 'POST',
      headers: buildAuthHeaders(true),
      body: JSON.stringify({
        ...newTeacherObj,
        grades: JSON.stringify(newTeacherObj.grades),
        rating: String(newTeacherObj.rating),
      }),
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson?.error || 'تعذر حفظ ملف المعلم في قاعدة البيانات');
    }

    const saved = await res.json();
    const normalized: Teacher = {
      ...saved,
      grades: typeof saved.grades === 'string' ? JSON.parse(saved.grades || '[]') : saved.grades || [],
      rating: Number(saved.rating) || 5.0,
    };
    setTeachersList((prev) => [normalized, ...prev]);
    onAddTeacher(normalized);
    return normalized;
  };

  // Explicit Trigger Button Handler: "تغذية الدروس والاختبارات"
  const handleTriggerPdfFeed = async (targetTeacherId?: string, closeModalAfter = false) => {
    setFeedErrorText('');
    setFeedSuccessSummary(null);

    let effectiveTeacherId = targetTeacherId || editingTeacher?.id || '';
    let effectiveSubject = (feedSubject || formSpecialty || 'المادة الدراسية').trim();
    let effectiveGrade = (feedGrade || formGrades.split(',')[0] || 'الصف الثاني الثانوي').trim();

    if (!effectiveTeacherId && isAddModalOpen) {
      if (!formName.trim() || !formSpecialty.trim() || !formEmail.trim() || !formPhone.trim()) {
        const msg = isAr
          ? 'يرجى استكمال الحقول الأساسية للمعلم (الاسم، التخصص، البريد، الهاتف) قبل الضغط على تغذية الدروس والاختبارات.'
          : 'Please complete required teacher fields first.';
        setFeedErrorText(msg);
        showToast(msg, 'error');
        return;
      }
      if (queuedPdfs.length === 0) {
        const msg = isAr
          ? 'يرجى رفع ملف PDF واحد على الأقل أولاً.'
          : 'Please upload at least one PDF file first.';
        setFeedErrorText(msg);
        showToast(msg, 'error');
        return;
      }
    }

    setIsFeedingPdfs(true);
    try {
      // 1) If creating a brand-new teacher from Add modal, persist the teacher record first
      let newlyCreatedTeacher: Teacher | null = null;
      if (!effectiveTeacherId && isAddModalOpen) {
        setFeedStatusText(isAr ? '1/3 جارِ حفظ ملف المعلم الجديد في قاعدة البيانات...' : 'Saving teacher...');
        newlyCreatedTeacher = await persistNewTeacher();
        if (!newlyCreatedTeacher) throw new Error('تعذر إنشاء ملف المعلم');
        effectiveTeacherId = newlyCreatedTeacher.id;
        effectiveSubject = feedSubject.trim() || newlyCreatedTeacher.specialty;
        effectiveGrade =
          feedGrade.trim() || newlyCreatedTeacher.grades[0] || 'الصف الثاني الثانوي';
      }

      // 2) Upload any queued PDFs for that teacher first (if queued)
      let uploadedIds: string[] = [];
      if (queuedPdfs.length > 0 && effectiveTeacherId) {
        setFeedStatusText(isAr ? '2/3 جارِ حفظ ملفات PDF المرفوعة...' : 'Uploading PDFs...');
        const uploadedList = await uploadQueuedPdfsForTeacher(
          effectiveTeacherId,
          queuedPdfs,
          effectiveSubject,
          effectiveGrade
        );
        uploadedIds = uploadedList.map((u) => u.id);
        setQueuedPdfs([]);
      }

      const existingSaved = pdfByTeacher[effectiveTeacherId] || [];
      if (uploadedIds.length === 0 && existingSaved.length === 0) {
        throw new Error('يرجى رفع ملف PDF واحد على الأقل أولاً قبل الضغط على زر تغذية الدروس والاختبارات.');
      }

      // 3) Explicitly call Gemini AI Feed endpoint ONLY when button clicked
      setFeedStatusText(
        isAr
          ? '3/3 جارِ قراءة ملفات PDF وتوليد الدروس وأسئلة الاختبارات تلقائياً...'
          : 'Generating lessons & quizzes from PDFs...'
      );

      const feedRes = await fetch(`/api/teachers/${effectiveTeacherId}/feed-from-pdfs`, {
        method: 'POST',
        headers: buildAuthHeaders(true),
        body: JSON.stringify({
          pdfIds: uploadedIds.length > 0 ? uploadedIds : undefined,
          subject: effectiveSubject,
          grade: effectiveGrade,
          quizType: feedQuizType,
          lessonCount: feedLessonCount,
          questionsCount: feedQuestionsCount,
          alsoSyncCurriculumPath: feedSyncCurriculum,
        }),
      });

      const feedJson = await feedRes.json();
      if (!feedRes.ok) {
        throw new Error(feedJson?.error || 'تعذر توليد الدروس وأسئلة الاختبارات من PDF');
      }

      if (feedJson.pdfs) {
        setPdfByTeacher((prev) => ({
          ...prev,
          [effectiveTeacherId]: feedJson.pdfs,
        }));
      }

      if (feedJson.updatedTeacher) {
        const normTch: Teacher = {
          ...feedJson.updatedTeacher,
          grades:
            typeof feedJson.updatedTeacher.grades === 'string'
              ? JSON.parse(feedJson.updatedTeacher.grades || '[]')
              : feedJson.updatedTeacher.grades || [],
          rating: Number(feedJson.updatedTeacher.rating) || 5.0,
        };
        setTeachersList((prev) => prev.map((t) => (t.id === normTch.id ? normTch : t)));
        onUpdateTeacher(normTch);
        if (viewingTeacher?.id === normTch.id) setViewingTeacher(normTch);
        if (editingTeacher?.id === normTch.id) setEditingTeacher(normTch);
      }

      const newLessons = Array.isArray(feedJson.createdLessons) ? feedJson.createdLessons : [];
      const newQuizzes = Array.isArray(feedJson.createdQuizzes)
        ? feedJson.createdQuizzes.map((qz: any) => ({
            ...qz,
            questions:
              typeof qz.questions === 'string'
                ? JSON.parse(qz.questions || '[]')
                : qz.questions || [],
          }))
        : [];

      if (newLessons.length > 0 && onLessonsAdded) {
        onLessonsAdded(newLessons);
      }
      if (newQuizzes.length > 0 && onQuizAdded) {
        newQuizzes.forEach((qz: Quiz) => onQuizAdded(qz));
      }

      const totalGeneratedQuestions = newQuizzes.reduce(
        (sum: number, qz: any) => sum + (Array.isArray(qz.questions) ? qz.questions.length : 0),
        0
      );
      const syncedCount = Array.isArray(feedJson.curriculumSynced)
        ? feedJson.curriculumSynced.length
        : 0;

      setFeedSuccessSummary({
        lessonsCount: newLessons.length,
        quizzesCount: newQuizzes.length,
        questionsCount: totalGeneratedQuestions,
        curriculumSyncedCount: syncedCount,
      });

      showToast(
        isAr
          ? `تمت التغذية بنجاح ✓ توليد ${newLessons.length} دروس و${totalGeneratedQuestions} سؤال اختبار تلقائياً!`
          : `Generated ${newLessons.length} lessons & ${totalGeneratedQuestions} quiz questions!`,
        'success'
      );

      if (newlyCreatedTeacher && closeModalAfter) {
        setIsAddModalOpen(false);
      } else if (newlyCreatedTeacher && !closeModalAfter) {
        setIsAddModalOpen(false);
        setViewingTeacher(feedJson.updatedTeacher ? {
          ...feedJson.updatedTeacher,
          grades: typeof feedJson.updatedTeacher.grades === 'string'
            ? JSON.parse(feedJson.updatedTeacher.grades || '[]')
            : feedJson.updatedTeacher.grades || [],
          rating: Number(feedJson.updatedTeacher.rating) || 5.0,
        } : newlyCreatedTeacher);
      }
    } catch (err: any) {
      const msg = err?.message || 'حدث خطأ أثناء التغذية التلقائية';
      setFeedErrorText(msg);
      showToast(msg, 'error');
    } finally {
      setIsFeedingPdfs(false);
      setFeedStatusText('');
    }
  };

  // Save Add to DB (saves teacher + queued PDFs as pending without auto-feeding until button click!)
  const handleSaveAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      const normalized = await persistNewTeacher();
      if (normalized && queuedPdfs.length > 0) {
        await uploadQueuedPdfsForTeacher(
          normalized.id,
          queuedPdfs,
          feedSubject.trim() || normalized.specialty,
          feedGrade.trim() || normalized.grades[0] || 'الصف الثاني الثانوي'
        );
        setQueuedPdfs([]);
        showToast(
          isAr
            ? 'تم تسجيل المعلم ورفع ملفات PDF ✓ افتح التفاصيل واضغط «تغذية الدروس والاختبارات» عندما تكون جاهزاً.'
            : 'Teacher & PDFs saved (awaiting Feed button click).'
        );
      } else {
        showToast(isAr ? 'تمت إضافة ملف المعلم في قاعدة البيانات بنجاح ✓' : 'Teacher saved to DB ✓');
      }
      setIsAddModalOpen(false);
    } catch (err: any) {
      console.error('Failed to add teacher:', err);
      showToast(err?.message || (isAr ? 'تعذر حفظ المعلم في قاعدة البيانات' : 'Failed to save teacher'), 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Edit to DB
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeacher) return;
    setIsSaving(true);

    const parsedGrades = formGrades
      .split(',')
      .map((g) => g.trim())
      .filter(Boolean);

    const updatedTeacher: Teacher = {
      ...editingTeacher,
      name: formName.trim(),
      specialty: formSpecialty.trim(),
      email: formEmail.trim(),
      phone: formPhone.trim(),
      grades: parsedGrades.length > 0 ? parsedGrades : ['الصف الثاني الثانوي'],
      bio: formBio.trim(),
      avatar: formAvatar,
      rating: Number(formRating) || editingTeacher.rating,
      totalStudents: Number(formTotalStudents) || 0,
    };

    try {
      const res = await fetch(`/api/teachers/${editingTeacher.id}`, {
        method: 'PUT',
        headers: buildAuthHeaders(true),
        body: JSON.stringify({
          ...updatedTeacher,
          grades: JSON.stringify(updatedTeacher.grades),
          rating: String(updatedTeacher.rating),
        }),
      });

      if (res.ok) {
        const saved = await res.json();
        const normalized: Teacher = {
          ...saved,
          grades: typeof saved.grades === 'string' ? JSON.parse(saved.grades || '[]') : saved.grades || [],
          rating: Number(saved.rating) || 5.0,
        };
        if (queuedPdfs.length > 0) {
          await uploadQueuedPdfsForTeacher(
            normalized.id,
            queuedPdfs,
            feedSubject.trim() || normalized.specialty,
            feedGrade.trim() || normalized.grades[0] || 'الصف الثاني الثانوي'
          );
          setQueuedPdfs([]);
        }
        setTeachersList((prev) => prev.map((t) => (t.id === editingTeacher.id ? normalized : t)));
        onUpdateTeacher(normalized);
        if (viewingTeacher && viewingTeacher.id === editingTeacher.id) {
          setViewingTeacher(normalized);
        }
        showToast(isAr ? 'تم تحديث بيانات المعلم في قاعدة البيانات بنجاح ✓' : 'Teacher updated in DB ✓');
        setEditingTeacher(null);
      } else {
        showToast(isAr ? 'فشل تحديث بيانات المعلم' : 'Failed to update teacher', 'error');
      }
    } catch (err) {
      console.error('Failed to update teacher:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database error', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Confirm Delete from DB
  const handleConfirmDelete = async () => {
    if (!teacherToDelete) return;
    const id = teacherToDelete.id;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/teachers/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setTeachersList((prev) => prev.filter((t) => t.id !== id));
        onDeleteTeacher(id);
        if (viewingTeacher && viewingTeacher.id === id) {
          setViewingTeacher(null);
        }
        showToast(isAr ? 'تم حذف ملف المعلم نهائياً من قاعدة البيانات ✓' : 'Teacher deleted from DB ✓');
      } else {
        showToast(isAr ? 'تعذر حذف ملف المعلم' : 'Delete failed', 'error');
      }
    } catch (err) {
      console.error('Failed to delete teacher:', err);
      showToast(isAr ? 'خطأ في الاتصال بقاعدة البيانات' : 'Network error', 'error');
    } finally {
      setIsSaving(false);
      setTeacherToDelete(null);
    }
  };

  // Linked lessons helper for teacher
  const getTeacherLessons = (teacherId: string, teacherName: string) => {
    return lessons.filter((l) => l.teacherId === teacherId || l.teacherName === teacherName);
  };

  return (
    <div className="space-y-6 font-tajawal">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          <div
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl shadow-xl text-xs md:text-sm font-bold font-cairo ${
              toastMessage.type === 'error'
                ? 'bg-rose-600 text-white'
                : toastMessage.type === 'info'
                ? 'bg-blue-700 text-white'
                : 'bg-emerald-600 text-white'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-mono-numbers">
              <Database className="w-3 h-3 text-indigo-600" />
              <span>SQL Directory Live</span>
            </span>
            <span className="text-xs text-slate-400 font-cairo">
              ({teachersList.length} {isAr ? 'معلم مسجل' : 'Registered Teachers'})
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white font-cairo">
            {isAr ? 'دليل وملفات الكادر التعليمي' : 'Teachers Directory & Profiles'}
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 font-tajawal">
            {isAr
              ? 'إدارة حقيقية متصلة بقاعدة البيانات لإضافة، تعديل، حذف، بحث، وعرض تفاصيل ملفات المعلمين وتخصصاتهم.'
              : 'Real database-backed management for educators, specialties, ratings, and profiles.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto font-cairo">
          <button
            onClick={() => handleRefreshFromDb(false)}
            title={isAr ? 'تحديث السجلات من قاعدة البيانات' : 'Refresh from DB'}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 font-bold text-xs md:text-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>{isAr ? 'تصدير Excel / CSV' : 'Export CSV'}</span>
          </button>

          {canManageStaffCrud && (
            <button
              onClick={handleOpenAdd}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-all shadow-sm cursor-pointer hover:scale-105"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة معلم جديد' : 'Add New Teacher'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Search, Specialty Filter, and Summary */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder={
                isAr
                  ? 'ابحث بالاسم، التخصص، البريد، الهاتف، أو المرحلة...'
                  : 'Search by teacher name, specialty, email, phone...'
              }
              className="w-full pl-8 pr-9 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-tajawal"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute top-2.5 left-2.5 p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={selectedSpecialty}
              onChange={(e) => {
                setSelectedSpecialty(e.target.value);
                setCurrentPage(1);
              }}
              className="px-3 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 font-cairo cursor-pointer"
            >
              <option value="all">{isAr ? 'جميع التخصصات' : 'All Specialties'}</option>
              {specialtiesList.map((sp) => (
                <option key={sp} value={sp}>
                  {sp}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 font-mono-numbers shrink-0">
          <span>
            {isAr
              ? `عرض ${filteredTeachers.length} من ${teachersList.length}`
              : `${filteredTeachers.length} of ${teachersList.length}`}
          </span>
          <span>•</span>
          <span>
            {isAr ? `صفحة ${currentPage} من ${totalPages}` : `Page ${currentPage}/${totalPages}`}
          </span>
        </div>
      </div>

      {/* Teachers Cards Grid */}
      {isLoading && teachersList.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 space-y-3">
          <RefreshCw className="w-10 h-10 mx-auto text-indigo-600 animate-spin" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 font-cairo">
            {isAr ? 'جارِ تحميل ملفات الكادر التعليمي من قاعدة البيانات...' : 'Loading teachers from database...'}
          </h3>
        </div>
      ) : paginatedTeachers.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 space-y-3">
          <Users2 className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300 font-cairo">
            {teachersList.length === 0
              ? isAr
                ? 'قاعدة البيانات لا تحتوي على ملفات معلمين مسجلة حتى الآن'
                : 'No teachers registered in database yet'
              : isAr
              ? 'لم يتم العثور على معلمين مطابقين للبحث'
              : 'No teachers found'}
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto font-tajawal">
            {teachersList.length === 0
              ? isAr
                ? 'تم ربط دليل الكادر التعليمي بقاعدة البيانات فقط دون أي بيانات وهمية. اضغط أدناه لإضافة أول معلم.'
                : 'Database-only mode active. Click below to add your first teacher.'
              : isAr
              ? 'جرّب تعديل كلمات البحث أو اختيار تخصص آخر.'
              : 'Try adjusting your search or specialty filter.'}
          </p>
          {teachersList.length === 0 ? (
            <button
              type="button"
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة أول معلم الآن' : 'Add First Teacher'}</span>
            </button>
          ) : (
            (searchQuery || selectedSpecialty !== 'all') && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedSpecialty('all');
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-cairo font-bold text-xs cursor-pointer"
              >
                {isAr ? 'إعادة ضبط البحث' : 'Reset Search'}
              </button>
            )
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {paginatedTeachers.map((teacher) => {
            const linkedLessons = getTeacherLessons(teacher.id, teacher.name);
            const activeCount = Math.max(teacher.activeLessonsCount || 0, linkedLessons.length);
            const teacherPdfs = pdfByTeacher[teacher.id] || [];
            const pendingPdfsCount = teacherPdfs.filter((p) => p.status === 'uploaded_pending').length;

            return (
              <div
                key={teacher.id}
                className="flex flex-col justify-between p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-700 transition-all hover:shadow-md transform hover:-translate-y-0.5"
              >
                <div>
                  <div className="flex items-start gap-4">
                    <img
                      src={getSafeAvatarUrl(teacher.avatar)}
                      onError={handleImageErrorToTeacherAvatar}
                      alt={teacher.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-xs shrink-0"
                    />
                    <div className="overflow-hidden">
                      <h3 className="text-base font-bold text-slate-900 dark:text-white truncate font-cairo">
                        {teacher.name}
                      </h3>
                      <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 mt-0.5 truncate font-tajawal">
                        {teacher.specialty}
                      </p>
                      <div className="flex items-center gap-1 mt-1 text-xs text-amber-500 font-mono-numbers">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span className="font-bold">{teacher.rating}</span>
                        <span className="text-slate-400 text-[11px] font-normal">/ 5.0</span>
                      </div>
                    </div>
                  </div>

                  {/* Bio snippet */}
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-4 line-clamp-2 leading-relaxed font-tajawal">
                    {teacher.bio}
                  </p>

                  {/* Grades Pills */}
                  {teacher.grades && teacher.grades.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {teacher.grades.slice(0, 3).map((g, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-300 font-tajawal"
                        >
                          {g}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* PDF Library status pill */}
                  {teacherPdfs.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-[11px] font-cairo font-bold">
                        <FileText className="w-3.5 h-3.5" />
                        <span>{teacherPdfs.length} {isAr ? 'ملفات PDF' : 'PDFs'}</span>
                      </span>
                      {pendingPdfsCount > 0 && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-[11px] font-cairo font-bold">
                          <Clock className="w-3 h-3" />
                          <span>{isAr ? `${pendingPdfsCount} بانتظار التغذية` : `${pendingPdfsCount} pending feed`}</span>
                        </span>
                      )}
                    </div>
                  )}

                  {/* Stats Bar */}
                  <div className="grid grid-cols-2 gap-2 mt-4 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-center font-mono-numbers">
                    <div>
                      <span className="text-[11px] text-slate-400 block font-cairo">{isAr ? 'الطلاب' : 'Students'}</span>
                      <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                        {teacher.totalStudents}
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block font-cairo">{isAr ? 'الدروس النشطة' : 'Lessons'}</span>
                      <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                        {activeCount}
                      </span>
                    </div>
                  </div>

                  {/* Contact metadata */}
                  <div className="mt-3 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-2 truncate">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate font-mono-numbers">{teacher.email}</span>
                    </div>
                    <div className="flex items-center gap-2 truncate">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate font-mono-numbers">{teacher.phone}</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 font-cairo">
                  <button
                    onClick={() => handleOpenViewTeacher(teacher)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 text-xs font-bold hover:bg-indigo-100 transition-colors cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isAr ? 'التفاصيل وملفات PDF' : 'View & PDFs'}</span>
                  </button>

                  {canManageStaffCrud && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(teacher)}
                        className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title={isAr ? 'تعديل بيانات المعلم' : 'Edit Teacher'}
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setTeacherToDelete(teacher)}
                        className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:bg-rose-50 hover:border-rose-400 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                        title={isAr ? 'حذف ملف المعلم' : 'Delete Teacher'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-5 py-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold font-cairo rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <ChevronRight className={`w-4 h-4 ${!isAr ? 'rotate-180' : ''}`} />
            <span>{isAr ? 'السابق' : 'Previous'}</span>
          </button>

          <div className="flex items-center gap-1">
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx + 1}
                onClick={() => setCurrentPage(idx + 1)}
                className={`w-8 h-8 rounded-xl text-xs font-bold font-mono-numbers transition-colors cursor-pointer ${
                  currentPage === idx + 1
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {idx + 1}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold font-cairo rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <span>{isAr ? 'التالي' : 'Next'}</span>
            <ChevronLeft className={`w-4 h-4 ${!isAr ? 'rotate-180' : ''}`} />
          </button>
        </div>
      )}

      {/* ================= MODAL: ADD / EDIT TEACHER ================= */}
      {(isAddModalOpen || editingTeacher) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                  {editingTeacher ? <Edit className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-bold text-slate-900 dark:text-white font-cairo">
                    {editingTeacher
                      ? isAr
                        ? 'تعديل بيانات المعلم في قاعدة البيانات'
                        : 'Edit Teacher Profile'
                      : isAr
                      ? 'إضافة معلم جديد للكادر التعليمي'
                      : 'Add New Teacher'}
                  </h3>
                  <p className="text-xs text-slate-500 font-tajawal">
                    {isAr ? 'حفظ وتحديث فوري في قاعدة بيانات الأكاديمية' : 'Real-time database persistence'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingTeacher(null);
                }}
                className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={editingTeacher ? handleSaveEdit : handleSaveAdd}
              className="p-6 overflow-y-auto space-y-4 text-xs md:text-sm font-tajawal"
            >
              {/* Teacher Photo Upload & Avatar Presets */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                  {isAr ? 'صورة المعلم الشخصية (رفع من الجهاز أو اختيار افتراضي)' : 'Teacher Photo (Upload or Preset)'}
                </label>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="relative shrink-0 w-16 h-16">
                    <img
                      src={getSafeAvatarUrl(formAvatar)}
                      onError={handleImageErrorToTeacherAvatar}
                      alt="Preview"
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-200 dark:border-indigo-700 shadow-xs"
                    />
                    <span className="absolute -bottom-1 -left-1 w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow">
                      <Camera className="w-3.5 h-3.5" />
                    </span>
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-cairo font-bold text-xs cursor-pointer shadow-xs">
                        <Upload className="w-3.5 h-3.5" />
                        <span>
                          {isUploadingAvatar
                            ? isAr ? 'جاري الرفع...' : 'Uploading...'
                            : isAr ? 'رفع صورة من الجهاز' : 'Upload Photo'}
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleTeacherPhotoUpload}
                          className="hidden"
                        />
                      </label>
                      {AVATAR_PRESETS.map((preset) => (
                        <button
                          key={preset.url}
                          type="button"
                          onClick={() => setFormAvatar(preset.url)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold border transition-all cursor-pointer ${
                            formAvatar === preset.url
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                    <input
                      type="text"
                      value={formAvatar.startsWith('data:') ? '' : formAvatar}
                      onChange={(e) => setFormAvatar(e.target.value || DEFAULT_TEACHER_AVATAR)}
                      placeholder={
                        formAvatar.startsWith('data:')
                          ? isAr ? 'تم إرفاق صورة من جهازك (اضغط على أي خيار لتغييرها)' : 'Uploaded image attached'
                          : isAr ? 'أو الصق رابط صورة مباشر (HTTPS)...' : 'Or paste image URL...'
                      }
                      className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 font-mono-numbers"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم المعلم الكامل (بالعربية) *' : 'Teacher Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder={isAr ? 'مثال: أ. د. طارق عبد الرحمن' : 'e.g. Dr. Tarek'}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'التخصص والمادة العلمية *' : 'Specialty & Subject *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formSpecialty}
                    onChange={(e) => setFormSpecialty(e.target.value)}
                    placeholder={isAr ? 'مثال: الرياضيات والتفاضل والتكامل' : 'e.g. Mathematics'}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'البريد الإلكتروني الرسمي *' : 'Email *'}
                  </label>
                  <input
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="teacher@nawabegh.edu"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'رقم الهاتف / الجوال *' : 'Phone *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="+966 50 123 4567"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المراحل الدراسية المسندة (بفاصلة)' : 'Assigned Grades'}
                  </label>
                  <input
                    type="text"
                    value={formGrades}
                    onChange={(e) => setFormGrades(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'عدد الطلاب' : 'Students'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formTotalStudents}
                    onChange={(e) => setFormTotalStudents(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'التقييم (من 5)' : 'Rating'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    max="5"
                    value={formRating}
                    onChange={(e) => setFormRating(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'نبذة عن الخبرة والمسيرة التعليمية' : 'Bio & Experience'}
                </label>
                <textarea
                  rows={3}
                  value={formBio}
                  onChange={(e) => setFormBio(e.target.value)}
                  placeholder={isAr ? 'اذكر سنوات الخبرة، المؤهلات العلمية، والشهادات الحاصل عليها المعلم...' : 'Teacher bio...'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              {/* PDF Upload & Explicit Feed Trigger Section inside Add / Edit Teacher */}
              {canManagePdfFeeding && (
                <div className="p-4 rounded-2xl bg-sky-50/80 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800/70 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-sky-700 dark:text-sky-300 shrink-0" />
                      <div>
                        <h4 className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                          {isAr
                            ? 'إرفاق ملفات PDF وتغذية الدروس والاختبارات تلقائياً'
                            : 'Attach PDF Files & Feed Lessons/Quizzes'}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {isAr
                            ? 'ارفع ملفات PDF أولاً، ولن يبدأ التوليد التلقائي للدروس والأسئلة إلا بعد الضغط على زر «تغذية الدروس والاختبارات».'
                            : 'Upload PDF(s) first, then click the Feed button to generate lessons & quizzes.'}
                        </p>
                      </div>
                    </div>

                    <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-cairo font-bold text-xs cursor-pointer shadow-xs">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{isAr ? 'إضافة ملفات PDF' : 'Upload PDFs'}</span>
                      <input
                        type="file"
                        accept=".pdf,application/pdf"
                        multiple
                        onChange={(e) => handleSelectPdfFilesForModal(e, editingTeacher?.id)}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Feed Target Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-[11px]">
                    <div className="sm:col-span-2">
                      <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                        {isAr ? 'المادة المستهدفة للتوليد' : 'Target Subject'}
                      </label>
                      <input
                        type="text"
                        value={feedSubject}
                        onChange={(e) => setFeedSubject(e.target.value)}
                        placeholder={formSpecialty || (isAr ? 'تؤخذ تلقائياً من تخصص المعلم' : 'Auto from specialty')}
                        className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                        {isAr ? 'المرحلة الدراسية' : 'Grade'}
                      </label>
                      <input
                        type="text"
                        value={feedGrade}
                        onChange={(e) => setFeedGrade(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                        {isAr ? 'نوع الاختبار التلقائي' : 'Quiz Type'}
                      </label>
                      <select
                        value={feedQuizType}
                        onChange={(e) => setFeedQuizType(e.target.value as 'weekly' | 'monthly')}
                        className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 font-cairo"
                      >
                        <option value="weekly">{isAr ? 'اختبار أسبوعي' : 'Weekly Quiz'}</option>
                        <option value="monthly">{isAr ? 'اختبار شهري' : 'Monthly Quiz'}</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-600 dark:text-slate-300">
                    <label className="flex items-center gap-1.5 font-cairo">
                      <span>{isAr ? 'عدد الدروس:' : 'Lessons:'}</span>
                      <input
                        type="number"
                        min={2}
                        max={8}
                        value={feedLessonCount}
                        onChange={(e) => setFeedLessonCount(Number(e.target.value) || 4)}
                        className="w-14 px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center font-mono-numbers"
                      />
                    </label>
                    <label className="flex items-center gap-1.5 font-cairo">
                      <span>{isAr ? 'عدد أسئلة الاختبار:' : 'Questions:'}</span>
                      <input
                        type="number"
                        min={4}
                        max={20}
                        value={feedQuestionsCount}
                        onChange={(e) => setFeedQuestionsCount(Number(e.target.value) || 10)}
                        className="w-14 px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center font-mono-numbers"
                      />
                    </label>
                    <label className="flex items-center gap-1.5 font-cairo cursor-pointer">
                      <input
                        type="checkbox"
                        checked={feedSyncCurriculum}
                        onChange={(e) => setFeedSyncCurriculum(e.target.checked)}
                        className="rounded border-slate-300 text-sky-600"
                      />
                      <span>{isAr ? 'إضافة أيضاً إلى مسار الدروس المنهجي' : 'Sync to Curriculum Path'}</span>
                    </label>
                  </div>

                  {/* Queued PDFs List */}
                  {queuedPdfs.length > 0 && (
                    <div className="space-y-1.5">
                      {queuedPdfs.map((qf) => (
                        <div
                          key={qf.tempId}
                          className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-sky-200 dark:border-sky-800 text-xs"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                            <span className="font-bold text-slate-800 dark:text-slate-100 truncate">
                              {qf.fileName}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono-numbers shrink-0">
                              ({Math.max(1, Math.round(qf.fileSizeBytes / 1024))} KB)
                            </span>
                            <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[10px] font-cairo font-bold shrink-0">
                              {isAr ? 'بانتظار الضغط على زر التغذية' : 'Pending Feed'}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              setQueuedPdfs((prev) => prev.filter((item) => item.tempId !== qf.tempId))
                            }
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Already stored PDFs in Edit Mode */}
                  {editingTeacher && (pdfByTeacher[editingTeacher.id] || []).length > 0 && (
                    <div className="space-y-1.5">
                      {(pdfByTeacher[editingTeacher.id] || []).map((pf) => (
                        <div
                          key={pf.id}
                          className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                            <span className="font-bold text-slate-800 dark:text-slate-100 truncate">
                              {pf.fileName}
                            </span>
                            {pf.status === 'fed' ? (
                              <span className="px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-cairo font-bold shrink-0">
                                {isAr
                                  ? `تمت التغذية (${pf.fedLessonsCount || 0} درس · ${pf.fedQuestionsCount || 0} سؤال)`
                                  : `Fed (${pf.fedLessonsCount || 0}L / ${pf.fedQuestionsCount || 0}Q)`}
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[10px] font-cairo font-bold shrink-0">
                                {isAr ? 'بانتظار زر التغذية' : 'Pending'}
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => handleDeleteSavedTeacherPdf(editingTeacher.id, pf.id)}
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {feedErrorText && (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-cairo">
                      {feedErrorText}
                    </div>
                  )}

                  {feedSuccessSummary && (
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-cairo font-bold">
                      {isAr
                        ? `تم بنجاح: توليد ${feedSuccessSummary.lessonsCount} دروس و${feedSuccessSummary.quizzesCount} اختباراً (${feedSuccessSummary.questionsCount} سؤال متنوع) وحفظها تلقائياً في المنصة.`
                        : `Created ${feedSuccessSummary.lessonsCount} lessons & ${feedSuccessSummary.questionsCount} questions.`}
                    </div>
                  )}

                  {/* EXPLICIT TRIGGER BUTTON: تغذية الدروس والاختبارات */}
                  <div className="pt-1 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-500 font-cairo">
                      {isFeedingPdfs && feedStatusText
                        ? feedStatusText
                        : isAr
                        ? 'يبدأ التوليد التلقائي فقط عند الضغط هنا:'
                        : 'Explicit trigger required after PDF upload:'}
                    </span>
                    <button
                      type="button"
                      disabled={
                        isFeedingPdfs ||
                        isUploadingPdfs ||
                        (queuedPdfs.length === 0 &&
                          (!editingTeacher || (pdfByTeacher[editingTeacher.id] || []).length === 0))
                      }
                      onClick={() => handleTriggerPdfFeed(editingTeacher?.id, false)}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-45 text-white font-cairo font-bold text-xs shadow-sm cursor-pointer transition-all"
                    >
                      {isFeedingPdfs ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>{isAr ? 'جارِ التغذية...' : 'Feeding...'}</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>{isAr ? 'تغذية الدروس والاختبارات' : 'Feed Lessons & Quizzes'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 font-cairo">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingTeacher(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving || isFeedingPdfs}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-md"
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>{isAr ? 'جارِ الحفظ...' : 'Saving...'}</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{editingTeacher ? (isAr ? 'حفظ التعديلات' : 'Update Teacher') : isAr ? 'تسجيل المعلم' : 'Save Teacher'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: VIEW TEACHER PROFILE DETAILS ================= */}
      {viewingTeacher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between">
              <div className="flex items-center gap-4">
                <img
                  src={getSafeAvatarUrl(viewingTeacher.avatar)}
                  onError={handleImageErrorToTeacherAvatar}
                  alt={viewingTeacher.name}
                  referrerPolicy="no-referrer"
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-white dark:border-slate-700 shadow-md"
                />
                <div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white font-cairo">
                    {viewingTeacher.name}
                  </h3>
                  <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 font-cairo">
                    {viewingTeacher.specialty}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1 font-mono-numbers text-amber-500 font-bold">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      {viewingTeacher.rating} / 5.0
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {isAr ? 'انضم للأكاديمية:' : 'Joined:'} {viewingTeacher.joinedDate}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setViewingTeacher(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 text-xs md:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center font-mono-numbers">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-cairo">{isAr ? 'الطلاب المسجلين' : 'Students'}</span>
                  <span className="text-lg font-black text-slate-800 dark:text-slate-100">
                    {viewingTeacher.totalStudents}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-cairo">{isAr ? 'الدروس المنشورة' : 'Lessons'}</span>
                  <span className="text-lg font-black text-slate-800 dark:text-slate-100">
                    {Math.max(viewingTeacher.activeLessonsCount || 0, getTeacherLessons(viewingTeacher.id, viewingTeacher.name).length)}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs text-slate-400 block font-cairo">{isAr ? 'حالة الاعتماد' : 'Status'}</span>
                  <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400 flex items-center justify-center gap-1 mt-1 font-cairo">
                    <UserCheck className="w-4 h-4" />
                    {isAr ? 'معتمد رسمياً' : 'Verified'}
                  </span>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2 font-cairo">
                  {isAr ? 'المراحل والفصول الدراسية المسندة:' : 'Assigned Grades:'}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {viewingTeacher.grades.map((g, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded-xl text-xs font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900 font-cairo"
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2 font-cairo">
                  {isAr ? 'النبذة المهنية والخبرات:' : 'Professional Biography:'}
                </h4>
                <p className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 leading-relaxed text-slate-600 dark:text-slate-300 font-tajawal">
                  {viewingTeacher.bio}
                </p>
              </div>

              {/* Teacher PDF Files Library & Explicit "تغذية الدروس والاختبارات" Button */}
              {canManagePdfFeeding && (
                <div className="p-4 rounded-2xl bg-sky-50/75 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800/70 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-sky-700 dark:text-sky-300" />
                      <div>
                        <h4 className="font-cairo font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                          {isAr
                            ? 'مكتبة ملفات PDF للمعلم والتغذية التلقائية للدروس والاختبارات'
                            : 'Teacher PDF Library & Auto-Feed'}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {isAr
                            ? 'يمكن للمعلم رفع ملفات المذكرات PDF هنا ثم الضغط على «تغذية الدروس والاختبارات» لتوليدها تلقائياً.'
                            : 'Upload PDF files here, then click Feed Lessons & Quizzes.'}
                        </p>
                      </div>
                    </div>

                    <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-cairo font-bold text-xs cursor-pointer shadow-xs">
                      {isUploadingPdfs ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Upload className="w-3.5 h-3.5" />
                      )}
                      <span>{isAr ? 'رفع ملفات PDF' : 'Upload PDFs'}</span>
                      <input
                        type="file"
                        accept=".pdf,application/pdf"
                        multiple
                        onChange={(e) => handleSelectPdfFilesForModal(e, viewingTeacher.id)}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                    <div>
                      <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                        {isAr ? 'المادة' : 'Subject'}
                      </label>
                      <input
                        type="text"
                        value={feedSubject}
                        onChange={(e) => setFeedSubject(e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                        {isAr ? 'المرحلة الدراسية' : 'Grade'}
                      </label>
                      <input
                        type="text"
                        value={feedGrade}
                        onChange={(e) => setFeedGrade(e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                        {isAr ? 'نوع الاختبار' : 'Quiz Type'}
                      </label>
                      <select
                        value={feedQuizType}
                        onChange={(e) => setFeedQuizType(e.target.value as 'weekly' | 'monthly')}
                        className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-cairo"
                      >
                        <option value="weekly">{isAr ? 'اختبار أسبوعي' : 'Weekly'}</option>
                        <option value="monthly">{isAr ? 'اختبار شهري' : 'Monthly'}</option>
                      </select>
                    </div>
                  </div>

                  {(pdfByTeacher[viewingTeacher.id] || []).length === 0 ? (
                    <div className="p-3 rounded-xl bg-white/80 dark:bg-slate-900/60 border border-dashed border-sky-300 dark:border-sky-800 text-center text-xs text-slate-500">
                      {isAr
                        ? 'لا توجد ملفات PDF مرفوعة لهذا المعلم بعد. ارفع ملفاً واضغط على «تغذية الدروس والاختبارات».'
                        : 'No PDF files uploaded for this teacher yet.'}
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {(pdfByTeacher[viewingTeacher.id] || []).map((pf) => (
                        <div
                          key={pf.id}
                          className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2 text-xs"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                            <div className="min-w-0">
                              <p className="font-bold text-slate-800 dark:text-slate-100 truncate font-cairo">
                                {pf.fileName}
                              </p>
                              <p className="text-[11px] text-slate-400">
                                {pf.subject} · {pf.grade} · {Math.max(1, Math.round(pf.fileSizeBytes / 1024))} KB
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {pf.status === 'fed' ? (
                              <span className="px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-cairo font-bold">
                                {isAr
                                  ? `تمت التغذية (${pf.fedLessonsCount || 0} درس / ${pf.fedQuestionsCount || 0} سؤال)`
                                  : `Fed (${pf.fedLessonsCount || 0}L)`}
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-[10px] font-cairo font-bold">
                                {isAr ? 'بانتظار التغذية' : 'Pending Feed'}
                              </span>
                            )}
                            <a
                              href={`/api/teachers/${viewingTeacher.id}/pdfs/${pf.id}/file`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-sky-600 hover:bg-sky-50"
                              title={isAr ? 'فتح ملف PDF' : 'Open PDF'}
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                            <button
                              type="button"
                              onClick={() => handleDeleteSavedTeacherPdf(viewingTeacher.id, pf.id)}
                              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600"
                              title={isAr ? 'حذف الملف' : 'Delete PDF'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {feedErrorText && (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-cairo">
                      {feedErrorText}
                    </div>
                  )}

                  {feedSuccessSummary && (
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-cairo font-bold">
                      {isAr
                        ? `تم بنجاح: توليد ${feedSuccessSummary.lessonsCount} دروس و${feedSuccessSummary.quizzesCount} اختباراً (${feedSuccessSummary.questionsCount} سؤال تلقائي) وحفظها في قاعدة البيانات.`
                        : `Generated ${feedSuccessSummary.lessonsCount} lessons & ${feedSuccessSummary.questionsCount} questions.`}
                    </div>
                  )}

                  <div className="pt-1 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-500 font-cairo">
                      {isFeedingPdfs && feedStatusText
                        ? feedStatusText
                        : isAr
                        ? 'لتوليد الدروس وأسئلة الاختبارات من ملفات PDF المرفوعة:'
                        : 'Click to generate lessons & quizzes from uploaded PDFs:'}
                    </span>
                    <button
                      type="button"
                      disabled={
                        isFeedingPdfs ||
                        isUploadingPdfs ||
                        (pdfByTeacher[viewingTeacher.id] || []).length === 0
                      }
                      onClick={() => handleTriggerPdfFeed(viewingTeacher.id, false)}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-45 text-white font-cairo font-bold text-xs shadow-sm cursor-pointer transition-all"
                    >
                      {isFeedingPdfs ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>{isAr ? 'جارِ التغذية...' : 'Feeding...'}</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>{isAr ? 'تغذية الدروس والاختبارات' : 'Feed Lessons & Quizzes'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Linked Lessons list if available */}
              {getTeacherLessons(viewingTeacher.id, viewingTeacher.name).length > 0 && (
                <div>
                  <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2 font-cairo flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-emerald-600" />
                    <span>{isAr ? 'الدروس والمحاضرات المرتبطة بالمعلم:' : 'Linked Lessons:'}</span>
                  </h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {getTeacherLessons(viewingTeacher.id, viewingTeacher.name).map((les) => (
                      <div
                        key={les.id}
                        className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs"
                      >
                        <span className="font-bold text-slate-800 dark:text-slate-200 truncate font-cairo">
                          {les.title}
                        </span>
                        <span className="px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono-numbers text-[11px] shrink-0">
                          {les.format.toUpperCase()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-indigo-500 shrink-0" />
                  <span className="font-mono-numbers truncate">{viewingTeacher.email}</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span className="font-mono-numbers truncate">{viewingTeacher.phone}</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between font-cairo">
              <div className="flex items-center gap-2">
                {canManageStaffCrud && (
                  <>
                    <button
                      onClick={() => {
                        const target = viewingTeacher;
                        setViewingTeacher(null);
                        handleOpenEdit(target);
                      }}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <Edit className="w-3.5 h-3.5 text-blue-600" />
                      <span>{isAr ? 'تعديل الملف' : 'Edit'}</span>
                    </button>
                    <button
                      onClick={() => {
                        const target = viewingTeacher;
                        setViewingTeacher(null);
                        setTeacherToDelete(target);
                      }}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 font-bold text-xs hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isAr ? 'حذف' : 'Delete'}</span>
                    </button>
                  </>
                )}
              </div>

              <button
                onClick={() => setViewingTeacher(null)}
                className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: SAFE DELETE CONFIRMATION ================= */}
      {teacherToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="font-cairo font-bold text-base md:text-lg text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف ملف المعلم' : 'Confirm Teacher Deletion'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isAr
                  ? 'هل أنت متأكد من حذف ملف المعلم نهائياً من قاعدة البيانات؟'
                  : 'Are you sure you want to delete this teacher from the database?'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-right space-y-1">
              <p className="font-cairo font-bold text-xs text-slate-900 dark:text-white">
                {teacherToDelete.name}
              </p>
              <p className="text-[11px] text-slate-500">{teacherToDelete.specialty} · {teacherToDelete.email}</p>
            </div>

            <div className="flex items-center gap-2 pt-2 font-cairo">
              <button
                type="button"
                onClick={() => setTeacherToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold text-xs"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs shadow-md"
              >
                {isAr ? 'نعم، احذف الملف' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
