import React, { useState, useEffect, useMemo } from 'react';
import {
  Award,
  FileText,
  Printer,
  Download,
  Sparkles,
  Search,
  X,
  RefreshCw,
  Database,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Calendar,
  BookOpen,
  TrendingUp,
  BarChart3,
  ExternalLink,
  AlertTriangle,
  Edit3,
  QrCode,
  ShieldCheck,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import QRCode from 'qrcode';
import {
  Certificate,
  QuizAttempt,
  Student,
  Quiz,
  SchoolSettings,
  Language,
  CurrentUser,
  WeeklyClassChallenge,
} from '../types';
import { getAuthHeaders } from '../utils/rbac';
import {
  CERTIFICATE_CREST_IMAGE,
  DEFAULT_TEACHER_AVATAR,
  getSafeAvatarUrl,
  handleImageErrorToTeacherAvatar,
} from '../utils/avatarFallback';

interface CertificatesCenterProps {
  certificates: Certificate[];
  quizAttempts?: QuizAttempt[];
  students?: Student[];
  quizzes?: Quiz[];
  settings?: SchoolSettings;
  onSyncFromDb?: (updatedCerts: Certificate[], updatedAttempts?: QuizAttempt[]) => void;
  onNavigateTab?: (tab: string) => void;
  language: Language;
  readOnly?: boolean;
  currentUser?: CurrentUser | null;
}

export const CertificatesCenter: React.FC<CertificatesCenterProps> = ({
  certificates,
  quizAttempts = [],
  students = [],
  quizzes = [],
  settings,
  onSyncFromDb,
  onNavigateTab,
  language,
  readOnly = false,
  currentUser = null,
}) => {
  const isAr = language === 'ar';

  const [localCerts, setLocalCerts] = useState<Certificate[]>(certificates);
  const [localAttempts, setLocalAttempts] = useState<QuizAttempt[]>(quizAttempts);
  const [localStudents, setLocalStudents] = useState<Student[]>(students);
  const [localQuizzes, setLocalQuizzes] = useState<Quiz[]>(quizzes);

  const [viewMode, setViewMode] = useState<'certificates' | 'ledger'>('certificates');
  const [activeType, setActiveType] = useState<'all' | 'excellence' | 'grades_report'>('all');
  const [activePeriod, setActivePeriod] = useState<'all' | 'weekly' | 'monthly'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(certificates[0] || null);

  // Sync & Auto-Generate Controls
  const [syncPeriod, setSyncPeriod] = useState<'all' | 'weekly' | 'monthly'>('all');
  const [excellenceThreshold, setExcellenceThreshold] = useState<number>(80);
  const [onlyAboveThresholdReports, setOnlyAboveThresholdReports] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Toast Feedback
  const [statusBanner, setStatusBanner] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Record Exam Score Modal
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [recStudentId, setRecStudentId] = useState('');
  const [recQuizId, setRecQuizId] = useState('');
  const [recQuizTitle, setRecQuizTitle] = useState('');
  const [recQuizType, setRecQuizType] = useState<'weekly' | 'monthly'>('weekly');
  const [recSubject, setRecSubject] = useState('الرياضيات');
  const [recEarnedMarks, setRecEarnedMarks] = useState<number>(27);
  const [recTotalMarks, setRecTotalMarks] = useState<number>(30);
  const [recTakenDate, setRecTakenDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [recError, setRecError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);

  // Delete Modals (No window.confirm)
  const [certToDelete, setCertToDelete] = useState<Certificate | null>(null);
  const [attemptToDelete, setAttemptToDelete] = useState<QuizAttempt | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Edit Certificate & Edit Attempt Modals
  const [editingCert, setEditingCert] = useState<Certificate | null>(null);
  const [certEditForm, setCertEditForm] = useState({
    type: 'excellence' as 'excellence' | 'grades_report',
    subjectOrTrack: '',
    score: 90,
    principalName: '',
    academicYear: '',
    notes: '',
  });
  const [editingAttempt, setEditingAttempt] = useState<QuizAttempt | null>(null);
  const [attemptEditForm, setAttemptEditForm] = useState({
    quizTitle: '',
    quizType: 'weekly' as 'weekly' | 'monthly',
    subject: '',
    earnedMarks: 0,
    totalMarks: 100,
    takenDate: '',
  });
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // QR Code & Live Database Verification State
  const [selectedCertQrUrl, setSelectedCertQrUrl] = useState<string>('');
  const [verifySerialInput, setVerifySerialInput] = useState<string>('');
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState<boolean>(false);
  const [isVerifyingCert, setIsVerifyingCert] = useState<boolean>(false);
  const [verifyResult, setVerifyResult] = useState<any | null>(null);
  const [classChallenges, setClassChallenges] = useState<WeeklyClassChallenge[]>([]);

  useEffect(() => {
    setLocalCerts(certificates);
    if (certificates.length > 0 && (!selectedCert || !certificates.some((c) => c.id === selectedCert.id))) {
      setSelectedCert(certificates[0]);
    } else if (certificates.length === 0) {
      setSelectedCert(null);
    }
  }, [certificates]);

  useEffect(() => {
    if (!selectedCert) {
      setSelectedCertQrUrl('');
      return;
    }
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://alsharif.edu';
    const verifyUrl = `${origin}/?verifyCert=${encodeURIComponent(
      selectedCert.serialNumber || selectedCert.id
    )}`;
    QRCode.toDataURL(verifyUrl, {
      width: 160,
      margin: 1,
      color: { dark: '#064e3b', light: '#ffffff' },
    })
      .then((url) => setSelectedCertQrUrl(url))
      .catch(() => setSelectedCertQrUrl(''));
  }, [selectedCert]);

  const handleVerifyCertificateFromDb = async (serialOrId?: string) => {
    const code = (serialOrId ?? verifySerialInput).trim();
    if (!code) return;
    setVerifySerialInput(code);
    setIsVerifyModalOpen(true);
    setIsVerifyingCert(true);
    setVerifyResult(null);
    try {
      const res = await fetch(`/api/certificates/verify/${encodeURIComponent(code)}`);
      const data = await res.json();
      setVerifyResult(data);
    } catch {
      setVerifyResult({
        verified: false,
        message: 'تعذر الاتصال بقاعدة البيانات للتحقق من الشهادة',
      });
    } finally {
      setIsVerifyingCert(false);
    }
  };

  useEffect(() => {
    setLocalAttempts(quizAttempts);
  }, [quizAttempts]);

  useEffect(() => {
    setLocalStudents(students);
  }, [students]);

  useEffect(() => {
    setLocalQuizzes(quizzes);
  }, [quizzes]);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusBanner({ type, text });
    setTimeout(() => setStatusBanner(null), 5000);
  };

  const fetchLatestFromDb = async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      const [cRes, aRes, sRes, qRes, chRes] = await Promise.all([
        fetch('/api/certificates'),
        fetch('/api/quiz-attempts'),
        fetch('/api/students'),
        fetch('/api/quizzes'),
        fetch('/api/class-challenges').catch(() => null),
      ]);
      const [cData, aData, sData, qData, chData] = await Promise.all([
        cRes.ok ? cRes.json() : [],
        aRes.ok ? aRes.json() : [],
        sRes.ok ? sRes.json() : [],
        qRes.ok ? qRes.json() : [],
        chRes && chRes.ok ? chRes.json() : { challenges: [] },
      ]);

      const nextCerts = Array.isArray(cData) ? cData : [];
      const nextAttempts = Array.isArray(aData) ? aData : [];
      setLocalCerts(nextCerts);
      setLocalAttempts(nextAttempts);
      if (Array.isArray(sData)) setLocalStudents(sData);
      if (Array.isArray(qData)) setLocalQuizzes(qData);
      if (Array.isArray(chData?.challenges)) setClassChallenges(chData.challenges);

      setSelectedCert((prev) =>
        prev ? nextCerts.find((c: Certificate) => c.id === prev.id) || nextCerts[0] || null : nextCerts[0] || null
      );
      onSyncFromDb?.(nextCerts, nextAttempts);

      if (!silent) {
        showToast(
          isAr
            ? `تم التحديث من قاعدة البيانات: ${nextCerts.length} وثيقة و ${nextAttempts.length} درجة امتحان ✓`
            : `Synced from DB: ${nextCerts.length} documents and ${nextAttempts.length} exam records ✓`
        );
      }
    } catch (err: any) {
      if (!silent) {
        showToast(isAr ? `تعذر جلب البيانات: ${err.message}` : `Failed to load DB: ${err.message}`, 'error');
      }
    } finally {
      if (!silent) setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLatestFromDb(true);
  }, []);

  const handleAutoGenerateFromDb = async () => {
    setIsSyncing(true);
    try {
      const res = await fetch('/api/certificates/auto-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify({
          period: syncPeriod,
          excellenceThreshold,
          onlyQualifiedForReports: onlyAboveThresholdReports,
          academicYear: settings?.academicYear,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const updatedCerts: Certificate[] = Array.isArray(data.allCertificates) ? data.allCertificates : [];
      setLocalCerts(updatedCerts);
      setSelectedCert((prev) =>
        prev ? updatedCerts.find((c) => c.id === prev.id) || updatedCerts[0] || null : updatedCerts[0] || null
      );
      onSyncFromDb?.(updatedCerts);

      if (updatedCerts.length > 0 && data.totalStudentsProcessed > 0) {
        confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
        showToast(
          data.message ||
            (isAr
              ? `تم توليد وتحديث الشهادات وبيانات الدرجات أوتوماتيك للدرجات ${excellenceThreshold}% فما فوق ✓`
              : `Auto-generated certificates and transcripts for ${excellenceThreshold}%+ ✓`)
        );
      } else {
        showToast(
          data.message ||
            (isAr
              ? `لا توجد درجات امتحانات مستوفية لشرط ${excellenceThreshold}% فما فوق في قاعدة البيانات بعد.`
              : `No recorded exam scores >= ${excellenceThreshold}% in DB yet.`),
          'error'
        );
      }
    } catch (err: any) {
      showToast(
        isAr ? `تعذر التوليد التلقائي: ${err.message}` : `Auto-generation failed: ${err.message}`,
        'error'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const handleOpenRecordModal = () => {
    setRecError(null);
    setRecStudentId(localStudents[0]?.id || '');
    const firstQuiz = localQuizzes[0];
    setRecQuizId(firstQuiz?.id || '');
    setRecQuizTitle(firstQuiz?.title || '');
    setRecQuizType(firstQuiz?.type === 'monthly' ? 'monthly' : 'weekly');
    setRecSubject(firstQuiz?.subject || 'الرياضيات');
    setRecTotalMarks(firstQuiz?.totalMarks || 30);
    setRecEarnedMarks(Math.round((firstQuiz?.totalMarks || 30) * 0.9));
    setRecTakenDate(new Date().toISOString().split('T')[0]);
    setIsRecordModalOpen(true);
  };

  const handleSelectQuizInModal = (qId: string) => {
    setRecQuizId(qId);
    const qz = localQuizzes.find((q) => q.id === qId);
    if (qz) {
      setRecQuizTitle(qz.title);
      setRecQuizType(qz.type);
      setRecSubject(qz.subject);
      setRecTotalMarks(qz.totalMarks || 30);
      setRecEarnedMarks(Math.round((qz.totalMarks || 30) * 0.9));
    }
  };

  const handleSaveRecordedScore = async (e: React.FormEvent) => {
    e.preventDefault();
    setRecError(null);
    const stu = localStudents.find((s) => s.id === recStudentId);
    if (!stu) {
      setRecError(isAr ? 'يرجى اختيار الطالب من قاعدة البيانات.' : 'Please select a DB student.');
      return;
    }
    if (!recQuizTitle.trim()) {
      setRecError(isAr ? 'يرجى إدخال اسم الاختبار الأسبوعي أو الشهري.' : 'Please enter exam title.');
      return;
    }
    if (recTotalMarks <= 0 || recEarnedMarks < 0 || recEarnedMarks > recTotalMarks) {
      setRecError(
        isAr
          ? 'يرجى التأكد من أن الدرجة المستحقة بين 0 والدرجة النهائية.'
          : 'Earned marks must be between 0 and total marks.'
      );
      return;
    }

    setIsRecording(true);
    try {
      const pct = Math.round((recEarnedMarks / recTotalMarks) * 100);
      const res = await fetch('/api/quiz-attempts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify({
          quizId: recQuizId || `manual-${recQuizType}-${Date.now()}`,
          quizTitle: recQuizTitle.trim(),
          quizType: recQuizType,
          subject: recSubject.trim() || 'عام',
          grade: stu.grade,
          studentId: stu.id,
          studentName: stu.name,
          studentCode: stu.code,
          earnedMarks: recEarnedMarks,
          totalMarks: recTotalMarks,
          percentage: pct,
          correctCount: recEarnedMarks,
          totalQuestions: recTotalMarks,
          takenDate: recTakenDate,
          excellenceThreshold,
          onlyQualifiedForReports: onlyAboveThresholdReports,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = await res.json();
      await fetchLatestFromDb(true);
      setIsRecordModalOpen(false);
      const issuedCount = Array.isArray(payload.autoCertificates) ? payload.autoCertificates.length : 0;
      if (issuedCount > 0) {
        confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
        showToast(
          isAr
            ? `تم رصد درجة «${stu.name}» (${pct}%) وإصدار الشهادة وبيان الدرجات أوتوماتيك (${excellenceThreshold}% فما فوق) ✓`
            : `Recorded score for ${stu.name} (${pct}%) and auto-issued certificates ✓`
        );
      } else {
        showToast(
          isAr
            ? `تم رصد درجة «${stu.name}» (${pct}%) في سجل الامتحانات. الشهادات تصدر أوتوماتيك للدرجات ${excellenceThreshold}% فما فوق فقط.`
            : `Recorded score (${pct}%). Auto-certificates are issued for ${excellenceThreshold}%+ only.`
        );
      }
    } catch (err: any) {
      setRecError(isAr ? `تعذر حفظ الدرجة: ${err.message}` : `Failed to save score: ${err.message}`);
    } finally {
      setIsRecording(false);
    }
  };

  const handleConfirmDeleteCert = async () => {
    if (!certToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/certificates/${certToDelete.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const next = localCerts.filter((c) => c.id !== certToDelete.id);
      setLocalCerts(next);
      if (selectedCert?.id === certToDelete.id) {
        setSelectedCert(next[0] || null);
      }
      onSyncFromDb?.(next, localAttempts);
      showToast(isAr ? 'تم حذف الوثيقة من قاعدة البيانات ✓' : 'Certificate deleted ✓');
      setCertToDelete(null);
    } catch (err: any) {
      showToast(isAr ? `تعذر الحذف: ${err.message}` : `Delete failed: ${err.message}`, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConfirmDeleteAttempt = async () => {
    if (!attemptToDelete) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/quiz-attempts/${attemptToDelete.id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(currentUser),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await fetchLatestFromDb(true);
      showToast(
        isAr
          ? 'تم حذف درجة الاختبار وإعادة احتساب معدلات الشهادات أوتوماتيك ✓'
          : 'Deleted exam attempt and recalculated certificates ✓'
      );
      setAttemptToDelete(null);
    } catch (err: any) {
      showToast(isAr ? `تعذر الحذف: ${err.message}` : `Delete failed: ${err.message}`, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const openEditCertModal = (cert: Certificate) => {
    setEditingCert(cert);
    setCertEditForm({
      type: cert.type,
      subjectOrTrack: cert.subjectOrTrack || '',
      score: cert.score,
      principalName: cert.principalName || '',
      academicYear: cert.academicYear || '',
      notes: cert.notes || '',
    });
  };

  const handleSaveCertificateEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCert) return;
    setIsSavingEdit(true);
    try {
      const res = await fetch(`/api/certificates/${editingCert.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify(certEditForm),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const updated = await res.json();
      const next = localCerts.map((c) => (c.id === updated.id ? updated : c));
      setLocalCerts(next);
      if (selectedCert?.id === updated.id) setSelectedCert(updated);
      onSyncFromDb?.(next, localAttempts);
      setEditingCert(null);
      showToast(isAr ? 'تم تحديث بيانات الوثيقة في قاعدة البيانات ✓' : 'Certificate updated in DB ✓');
    } catch (err: any) {
      showToast(isAr ? `تعذر التحديث: ${err.message}` : `Update failed: ${err.message}`, 'error');
    } finally {
      setIsSavingEdit(false);
    }
  };

  const openEditAttemptModal = (att: QuizAttempt) => {
    setEditingAttempt(att);
    setAttemptEditForm({
      quizTitle: att.quizTitle,
      quizType: att.quizType,
      subject: att.subject,
      earnedMarks: att.earnedMarks,
      totalMarks: att.totalMarks,
      takenDate: att.takenDate,
    });
  };

  const handleSaveAttemptEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAttempt) return;
    setIsSavingEdit(true);
    try {
      const res = await fetch(`/api/quiz-attempts/${editingAttempt.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser) },
        body: JSON.stringify({
          ...attemptEditForm,
          excellenceThreshold,
          onlyQualifiedForReports: onlyAboveThresholdReports,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await fetchLatestFromDb(true);
      setEditingAttempt(null);
      showToast(
        isAr
          ? 'تم تعديل الدرجة وإعادة احتساب الشهادات وبيانات الدرجات أوتوماتيك من قاعدة البيانات ✓'
          : 'Updated score and recalculated certificates from DB ✓'
      );
    } catch (err: any) {
      showToast(isAr ? `تعذر التعديل: ${err.message}` : `Edit failed: ${err.message}`, 'error');
    } finally {
      setIsSavingEdit(false);
    }
  };

  const studentAvatarById = useMemo(() => {
    const map = new Map<string, string>();
    for (const s of localStudents) {
      if (s.avatar) {
        map.set(s.id, s.avatar);
      }
    }
    return map;
  }, [localStudents]);

  const getCertStudentAvatar = (cert: Certificate) => {
    return getSafeAvatarUrl(cert.studentAvatar || studentAvatarById.get(cert.studentId));
  };

  const handleDownloadCertificateHtml = async (cert: Certificate, autoPrintPdf = false) => {
    const schoolTitle = settings?.schoolName || (isAr ? 'منصة الشريف التعليمية' : 'Al-Sharif Educational Platform');
    const rawStudentPhoto = getCertStudentAvatar(cert);
    const originPrefix = typeof window !== 'undefined' ? window.location.origin : '';
    const studentPhotoUrl = rawStudentPhoto.startsWith('/') ? `${originPrefix}${rawStudentPhoto}` : rawStudentPhoto;
    const fallbackTeacherUrl = `${originPrefix}${DEFAULT_TEACHER_AVATAR}`;
    const verifyUrl = `${originPrefix}/?verifyCert=${encodeURIComponent(cert.serialNumber || cert.id)}`;
    let qrDataUrl = selectedCert?.id === cert.id ? selectedCertQrUrl : '';
    if (!qrDataUrl) {
      try {
        qrDataUrl = await QRCode.toDataURL(verifyUrl, {
          width: 150,
          margin: 1,
          color: { dark: '#064e3b', light: '#ffffff' },
        });
      } catch {
        qrDataUrl = '';
      }
    }
    const breakdownRowsHtml = (cert.breakdown || [])
      .map(
        (b) => `
        <tr>
          <td style="padding:8px 10px;border:1px solid #e2e8f0;">${b.quizTitle}</td>
          <td style="padding:8px 10px;border:1px solid #e2e8f0;text-align:center;">${b.quizType === 'monthly' ? 'شهري' : 'أسبوعي'}</td>
          <td style="padding:8px 10px;border:1px solid #e2e8f0;text-align:center;">${b.subject}</td>
          <td style="padding:8px 10px;border:1px solid #e2e8f0;text-align:center;">${b.earnedMarks} / ${b.totalMarks}</td>
          <td style="padding:8px 10px;border:1px solid #e2e8f0;text-align:center;font-weight:bold;">${b.percentage}%</td>
          <td style="padding:8px 10px;border:1px solid #e2e8f0;text-align:center;">${b.takenDate}</td>
        </tr>`
      )
      .join('');

    const htmlDoc = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<title>${cert.type === 'excellence' ? 'شهادة تقدير وتفوق' : 'بيان درجات معتمد'} - ${cert.studentName}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@700;900&family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
<style>
  body { font-family: 'Tajawal', sans-serif; background:#f8fafc; margin:0; padding:32px; color:#0f172a; }
  .frame { max-width:840px; margin:0 auto; background:#fff; border:6px double #d97706; border-radius:20px; padding:40px; text-align:center; }
  h1, h2, h3 { font-family: 'Cairo', sans-serif; }
  table { width:100%; border-collapse:collapse; margin-top:20px; font-size:13px; text-align:right; }
  th { background:#f1f5f9; padding:9px 10px; border:1px solid #e2e8f0; font-family:'Cairo',sans-serif; }
  @media print { body { background:#fff; padding:0; } .no-print { display:none !important; } }
</style>
</head>
<body ${autoPrintPdf ? 'onload="window.print()"' : ''}>
  <div class="frame">
    <p style="color:#b45309;font-weight:bold;font-size:13px;margin:0;">${schoolTitle}</p>
    <h1 style="margin:8px 0 4px;font-size:28px;">${cert.type === 'excellence' ? 'شهادة شرف وتقدير وتفوق' : 'بيان درجات وتقييم معتمد'}</h1>
    <p style="color:#64748b;font-size:13px;margin:0 0 20px;">العام الدراسي: ${cert.academicYear} · الرقم التسلسلي: ${cert.serialNumber}</p>
    <div style="margin:0 auto 16px;width:104px;height:104px;border-radius:50%;overflow:hidden;border:4px solid #f59e0b;box-shadow:0 6px 18px rgba(0,0,0,0.12);">
      <img src="${studentPhotoUrl}" onerror="this.onerror=null;this.src='${fallbackTeacherUrl}'" alt="${cert.studentName}" style="width:100%;height:100%;object-fit:cover;display:block;" />
    </div>
    <p style="font-size:15px;">تشهد إدارة منصة الشريف وهيئة التدريس بأن الطالب / الطالبة:</p>
    <h2 style="color:#4338ca;font-size:26px;border-bottom:2px solid #f59e0b;display:inline-block;padding:4px 28px;margin:6px 0;">${cert.studentName}</h2>
    <p style="color:#475569;font-size:14px;">${cert.studentGrade}</p>
    <p style="max-width:640px;margin:16px auto;line-height:1.8;font-size:14px;">${cert.notes}</p>
    <div style="display:inline-block;background:#fef3c7;border:1px solid #f59e0b;border-radius:12px;padding:10px 24px;font-family:'Cairo',sans-serif;font-weight:900;font-size:18px;color:#92400e;margin:12px 0;">
      المعدل المعتمد: ${cert.score}% ${cert.weeklyAverage !== null && cert.weeklyAverage !== undefined ? `· الأسبوعي: ${cert.weeklyAverage}%` : ''} ${cert.monthlyAverage !== null && cert.monthlyAverage !== undefined ? `· الشهري: ${cert.monthlyAverage}%` : ''}
    </div>
    ${breakdownRowsHtml ? `
    <h3 style="text-align:right;margin-top:24px;font-size:15px;">تفاصيل درجات الاختبارات الأسبوعية والشهرية:</h3>
    <table>
      <thead>
        <tr><th>الاختبار</th><th>التصنيف</th><th>المادة</th><th>الدرجة</th><th>النسبة</th><th>التاريخ</th></tr>
      </thead>
      <tbody>${breakdownRowsHtml}</tbody>
    </table>` : ''}
    <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-top:36px;padding-top:20px;border-top:1px solid #e2e8f0;font-size:13px;color:#475569;">
      <div style="text-align:right;">
        <strong>إدارة منصة الشريف</strong><br/>${cert.principalName}<br/>
        <span style="color:#059669;font-weight:bold;">✓ معتمد إلكترونياً من قاعدة البيانات</span>
      </div>
      ${
        qrDataUrl
          ? `<div style="text-align:center;background:#f8fafc;border:2px solid #10b981;border-radius:14px;padding:8px 12px;">
              <img src="${qrDataUrl}" alt="QR Code Verification" style="width:96px;height:96px;display:block;margin:0 auto;" />
              <div style="font-size:10px;font-family:'Cairo',sans-serif;font-weight:bold;color:#065f46;margin-top:4px;">امسح رمز QR للتحقق من الشهادة</div>
              <a href="${verifyUrl}" style="font-size:10px;color:#0284c7;text-decoration:none;">${cert.serialNumber}</a>
            </div>`
          : ''
      }
      <div style="text-align:left;">
        <strong>تاريخ الإصدار</strong><br/>${cert.issueDate}<br/>${cert.serialNumber}
      </div>
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlDoc], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${cert.serialNumber || cert.id}-QR.html`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);

    showToast(
      isAr
        ? `تم تنزيل الشهادة المعتمدة برمز تحقق QR (${cert.serialNumber}) — جاهزة للطباعة أو الحفظ كـ PDF ✓`
        : `Downloaded official QR-verified certificate (${cert.serialNumber}) ✓`
    );
  };

  const triggerCelebration = () => {
    confetti({ particleCount: 120, spread: 80, origin: { y: 0.5 } });
  };

  // Filtered Certificates
  const filteredCerts = useMemo(() => {
    return localCerts.filter((c) => {
      if (activeType !== 'all' && c.type !== activeType) return false;
      if (activePeriod !== 'all' && (c.examPeriod || 'all') !== activePeriod) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matches =
          c.studentName.toLowerCase().includes(q) ||
          c.studentGrade.toLowerCase().includes(q) ||
          c.serialNumber.toLowerCase().includes(q) ||
          (c.subjectOrTrack || '').toLowerCase().includes(q);
        if (!matches) return false;
      }
      return true;
    });
  }, [localCerts, activeType, activePeriod, searchQuery]);

  // Filtered Exam Attempts
  const filteredAttempts = useMemo(() => {
    return localAttempts.filter((a) => {
      if (activePeriod !== 'all' && a.quizType !== activePeriod) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          a.studentName.toLowerCase().includes(q) ||
          a.quizTitle.toLowerCase().includes(q) ||
          a.subject.toLowerCase().includes(q) ||
          (a.studentCode || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [localAttempts, activePeriod, searchQuery]);

  // Student-level Weekly vs Monthly Stats computed from real DB attempts
  const studentSummaries = useMemo(() => {
    const map = new Map<
      string,
      {
        studentId: string;
        studentName: string;
        studentCode?: string | null;
        grade: string;
        weeklyScores: number[];
        monthlyScores: number[];
        allScores: number[];
      }
    >();

    for (const a of localAttempts) {
      const existing = map.get(a.studentId) || {
        studentId: a.studentId,
        studentName: a.studentName,
        studentCode: a.studentCode,
        grade: a.grade,
        weeklyScores: [],
        monthlyScores: [],
        allScores: [],
      };
      existing.allScores.push(Number(a.percentage) || 0);
      if (a.quizType === 'monthly') existing.monthlyScores.push(Number(a.percentage) || 0);
      else existing.weeklyScores.push(Number(a.percentage) || 0);
      map.set(a.studentId, existing);
    }

    return Array.from(map.values()).map((item) => ({
      ...item,
      weeklyAvg:
        item.weeklyScores.length > 0
          ? Math.round(item.weeklyScores.reduce((s, x) => s + x, 0) / item.weeklyScores.length)
          : null,
      monthlyAvg:
        item.monthlyScores.length > 0
          ? Math.round(item.monthlyScores.reduce((s, x) => s + x, 0) / item.monthlyScores.length)
          : null,
      overallAvg:
        item.allScores.length > 0
          ? Math.round(item.allScores.reduce((s, x) => s + x, 0) / item.allScores.length)
          : 0,
    }));
  }, [localAttempts]);

  const excellenceCount = localCerts.filter((c) => c.type === 'excellence').length;
  const reportsCount = localCerts.filter((c) => c.type === 'grades_report').length;
  const weeklyAttemptsCount = localAttempts.filter((a) => a.quizType === 'weekly').length;
  const monthlyAttemptsCount = localAttempts.filter((a) => a.quizType === 'monthly').length;

  const getPeriodBadgeLabel = (period?: string) => {
    if (period === 'weekly') return isAr ? 'اختبارات أسبوعية' : 'Weekly Exams';
    if (period === 'monthly') return isAr ? 'اختبارات شهرية' : 'Monthly Exams';
    return isAr ? 'شامل (أسبوعي + شهري)' : 'Weekly + Monthly';
  };

  const getScoreTierLabel = (score: number) => {
    if (score >= 95) return isAr ? 'امتياز مع مرتبة الشرف العليا (95% - 100%)' : 'Highest Honors (95% - 100%)';
    if (score >= 90) return isAr ? 'امتياز وتفوق رفيع (90% - 94%)' : 'High Honors (90% - 94%)';
    if (score >= 85) return isAr ? 'تفوق متميز (85% - 89%)' : 'Distinction (85% - 89%)';
    if (score >= 80) return isAr ? 'تقدير جيد جداً متقدم (80% - 84%)' : 'Merit (80% - 84%)';
    return isAr ? `نتيجة (${score}%)` : `Score (${score}%)`;
  };

  return (
    <div className="space-y-6">
      {/* Status Toast Banner */}
      {statusBanner && (
        <div
          className={`p-4 rounded-xl border text-xs md:text-sm flex items-center justify-between gap-3 shadow-sm font-cairo ${
            statusBanner.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-300 dark:border-rose-700 text-rose-900 dark:text-rose-200'
              : 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusBanner.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            )}
            <span className="font-bold">{statusBanner.text}</span>
          </div>
          <button onClick={() => setStatusBanner(null)} className="p-1 hover:opacity-75">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Banner */}
      <div className="p-5 md:p-6 rounded-2xl bg-gradient-to-l from-amber-900 via-emerald-900 to-slate-900 text-white shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-72 h-72 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-5">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-amber-200 text-xs font-bold font-cairo">
              <Database className="w-3.5 h-3.5 text-amber-300" />
              <span>
                {isAr
                  ? 'توليد أوتوماتيك 100% من درجات الامتحانات المسجلة في قاعدة البيانات (بدون بيانات وهمية)'
                  : '100% Auto-Generated from Recorded DB Exam Scores (Zero Mock Data)'}
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-black font-cairo flex items-center gap-2">
              <Award className="w-6 h-6 text-amber-400 shrink-0" />
              <span>
                {isAr
                  ? 'منظومة شهادات التقدير وبيانات الدرجات الأوتوماتيك'
                  : 'Automated Certificates & Exam Grade Transcripts'}
              </span>
            </h2>
            <p className="text-xs md:text-sm text-emerald-100/90 font-tajawal leading-relaxed">
              {isAr
                ? `تصدر الشهادات وبيانات الدرجات وتُحدَّث أوتوماتيك من قاعدة البيانات بدون أي بيانات وهمية، للطلاب الحاصلين على ${excellenceThreshold}% إلى 100% حسب درجات الاختبارات الأسبوعية والشهرية.`
                : `Honors certificates and official transcripts are generated automatically from DB with zero mock data for exam scores from ${excellenceThreshold}% to 100%.`}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0 font-cairo">
            {!readOnly && (
              <button
                type="button"
                onClick={handleOpenRecordModal}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-black text-xs md:text-sm bg-amber-400 hover:bg-amber-300 text-slate-950 transition-colors shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'رصد درجة اختبار (أسبوعي/شهري)' : 'Record Exam Score'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => fetchLatestFromDb(false)}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm bg-white/15 hover:bg-white/25 text-white border border-white/25 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>{isAr ? 'تحديث من قاعدة البيانات' : 'Sync DB'}</span>
            </button>

            {!readOnly && (
              <a
                href="/api/backups/export/database?dialect=mysql"
                download
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold text-xs bg-white/15 hover:bg-white/25 text-white border border-white/25 transition-colors"
              >
                <Download className="w-4 h-4 text-emerald-300" />
                <span>{isAr ? 'تصدير SQL (MySQL)' : 'Export MySQL (.sql)'}</span>
              </a>
            )}

            <button
              type="button"
              onClick={triggerCelebration}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold text-xs bg-amber-500/30 hover:bg-amber-500/40 text-amber-200 border border-amber-400/30 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isAr ? 'احتفال' : 'Celebrate'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 font-cairo">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 font-tajawal block">
            {isAr ? 'شهادات التقدير والتفوق' : 'Honors Certificates'}
          </span>
          <span className="text-2xl font-black font-mono-numbers text-amber-600 dark:text-amber-400 mt-1 block">
            {excellenceCount}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 font-tajawal block">
            {isAr ? 'بيانات الدرجات المعتمدة' : 'Grade Reports'}
          </span>
          <span className="text-2xl font-black font-mono-numbers text-indigo-600 dark:text-indigo-400 mt-1 block">
            {reportsCount}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 font-tajawal block">
            {isAr ? 'درجات الاختبارات الأسبوعية' : 'Weekly Exam Scores'}
          </span>
          <span className="text-2xl font-black font-mono-numbers text-emerald-600 dark:text-emerald-400 mt-1 block">
            {weeklyAttemptsCount}
          </span>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 font-tajawal block">
            {isAr ? 'درجات الاختبارات الشهرية' : 'Monthly Exam Scores'}
          </span>
          <span className="text-2xl font-black font-mono-numbers text-purple-600 dark:text-purple-400 mt-1 block">
            {monthlyAttemptsCount}
          </span>
        </div>
      </div>

      {/* QR Code Database Verification Bar */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 text-white border border-emerald-700/40 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-300 flex items-center justify-center shrink-0">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-cairo font-black text-sm text-white">
              بوابة التحقق الفوري من الشهادات برمز (QR Code) من قاعدة البيانات
            </h3>
            <p className="text-xs text-emerald-100/90 font-tajawal">
              كل شهادة تصدرها منصة الشريف مزودة برمز QR رسمي؛ امسحه بالكاميرا أو أدخل الرقم التسلسلي للتحقق المباشر من قاعدة البيانات.
            </p>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleVerifyCertificateFromDb(verifySerialInput);
          }}
          className="flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            dir="ltr"
            value={verifySerialInput}
            onChange={(e) => setVerifySerialInput(e.target.value)}
            placeholder="CERT-2025-XXXX"
            className="px-3.5 py-2 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-slate-400 text-xs font-mono-numbers w-44 sm:w-52 focus:outline-hidden focus:border-amber-400"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>تحقق الآن</span>
          </button>
        </form>
      </div>

      {/* Auto-Generation Control Bar */}
      {!readOnly && (
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 font-cairo">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-200">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>{isAr ? 'نطاق التوليد التلقائي:' : 'Auto-Sync Scope:'}</span>
          </div>
          <select
            value={syncPeriod}
            onChange={(e) => setSyncPeriod(e.target.value as 'all' | 'weekly' | 'monthly')}
            className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
          >
            <option value="all">{isAr ? 'جميع الاختبارات (الأسبوعية + الشهرية)' : 'All (Weekly + Monthly)'}</option>
            <option value="weekly">{isAr ? 'الاختبارات الأسبوعية فقط' : 'Weekly Exams Only'}</option>
            <option value="monthly">{isAr ? 'الاختبارات الشهرية فقط' : 'Monthly Exams Only'}</option>
          </select>

          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-600 dark:text-slate-300">
              {isAr ? 'شرط الدرجة للإصدار التلقائي:' : 'Minimum Grade:'}
            </span>
            <select
              value={excellenceThreshold}
              onChange={(e) => setExcellenceThreshold(Number(e.target.value))}
              className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold font-mono-numbers"
            >
              <option value={80}>{isAr ? '80% فما فوق (الافتراضي)' : '80%+'}</option>
              <option value={85}>85%+</option>
              <option value={90}>90%+</option>
              <option value={95}>95%+</option>
            </select>
          </div>

          <label className="flex items-center gap-1.5 cursor-pointer text-xs text-slate-600 dark:text-slate-300 font-tajawal">
            <input
              type="checkbox"
              checked={onlyAboveThresholdReports}
              onChange={(e) => setOnlyAboveThresholdReports(e.target.checked)}
              className="rounded accent-emerald-700"
            />
            <span>{isAr ? `حصر بيانات الدرجات على ${excellenceThreshold}% فما فوق` : `Reports only >= ${excellenceThreshold}%`}</span>
          </label>
        </div>

        <button
          type="button"
          onClick={handleAutoGenerateFromDb}
          disabled={isSyncing}
          className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs"
        >
          <Sparkles className={`w-4 h-4 text-amber-300 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>
            {isSyncing
              ? isAr
                ? 'جاري التوليد من قاعدة البيانات...'
                : 'Auto-Generating...'
              : isAr
              ? 'توليد وتحديث الشهادات وبيانات الدرجات أوتوماتيك'
              : 'Auto-Generate Certificates & Transcripts Now'}
          </span>
        </button>
      </div>
      )}

      {/* Primary View Switcher & Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 font-cairo">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setViewMode('certificates')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
                viewMode === 'certificates'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-amber-500" />
              <span>{isAr ? `الشهادات والبيانات (${localCerts.length})` : `Certificates (${localCerts.length})`}</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('ledger')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
                viewMode === 'ledger'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-600" />
              <span>
                {isAr
                  ? `سجل درجات الامتحانات (${localAttempts.length})`
                  : `Exam Scores Ledger (${localAttempts.length})`}
              </span>
            </button>
          </div>

          {viewMode === 'certificates' && (
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setActiveType('all')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg ${
                  activeType === 'all'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                {isAr ? 'الكل' : 'All'}
              </button>
              <button
                type="button"
                onClick={() => setActiveType('excellence')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg ${
                  activeType === 'excellence'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                {isAr ? 'شهادات التقدير' : 'Honors'}
              </button>
              <button
                type="button"
                onClick={() => setActiveType('grades_report')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg ${
                  activeType === 'grades_report'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                {isAr ? 'بيانات الدرجات' : 'Transcripts'}
              </button>
            </div>
          )}

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setActivePeriod('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg ${
                activePeriod === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500'
              }`}
            >
              {isAr ? 'أسبوعي + شهري' : 'All Exams'}
            </button>
            <button
              type="button"
              onClick={() => setActivePeriod('weekly')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg ${
                activePeriod === 'weekly'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-xs'
                  : 'text-slate-500'
              }`}
            >
              {isAr ? 'أسبوعي' : 'Weekly'}
            </button>
            <button
              type="button"
              onClick={() => setActivePeriod('monthly')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg ${
                activePeriod === 'monthly'
                  ? 'bg-white dark:bg-slate-900 text-purple-600 shadow-xs'
                  : 'text-slate-500'
              }`}
            >
              {isAr ? 'شهري' : 'Monthly'}
            </button>
          </div>
        </div>

        <div className="relative w-full lg:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'بحث باسم الطالب أو الاختبار أو الرقم...' : 'Search student, exam, serial...'}
            className="w-full pr-9 pl-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-tajawal focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* ===================================================================== */}
      {/* VIEW 1: ISSUED CERTIFICATES & GRADE REPORTS */}
      {/* ===================================================================== */}
      {viewMode === 'certificates' ? (
        localCerts.length === 0 ? (
          <div className="p-10 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-4">
            <Award className="w-12 h-12 text-amber-500 mx-auto" />
            <h3 className="text-lg font-black font-cairo text-slate-900 dark:text-white">
              {isAr
                ? 'لا توجد شهادات تقدير أو بيانات درجات صادرة في قاعدة البيانات بعد'
                : 'No Certificates or Grade Reports Generated Yet'}
            </h3>
            <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 font-tajawal max-w-xl mx-auto leading-relaxed">
              {isAr
                ? `تم حذف جميع الشهادات الوهمية. تصدر الشهادات وبيانات الدرجات أوتوماتيك من قاعدة البيانات للطلاب الحاصلين على ${excellenceThreshold}% فما فوق في الاختبارات الأسبوعية والشهرية المسجلة.`
                : `All mock certificates have been removed. Certificates and transcripts are generated automatically from DB for weekly & monthly exam scores >= ${excellenceThreshold}%.`}
            </p>
            {!readOnly && (
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2 font-cairo">
                <button
                  type="button"
                  onClick={handleOpenRecordModal}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-2 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isAr ? 'رصد درجة امتحان لطالب الآن' : 'Record Exam Score'}</span>
                </button>
                {onNavigateTab && (
                  <button
                    type="button"
                    onClick={() => onNavigateTab('quizzes')}
                    className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>{isAr ? 'الانتقال إلى الاختبارات الأسبوعية والشهرية' : 'Go to Quizzes & Exams'}</span>
                  </button>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Certificates Selector Column */}
            <div className="lg:col-span-4 space-y-3">
              <h3 className="text-xs font-bold font-cairo text-slate-500 uppercase tracking-wider px-1">
                {isAr
                  ? `الوثائق الصادرة من قاعدة البيانات (${filteredCerts.length})`
                  : `Issued DB Documents (${filteredCerts.length})`}
              </h3>

              <div className="space-y-2.5 max-h-[700px] overflow-y-auto pr-1">
                {filteredCerts.map((cert) => {
                  const isSelected = selectedCert?.id === cert.id;
                  const isExcellence = cert.type === 'excellence';

                  return (
                    <div
                      key={cert.id}
                      onClick={() => {
                        setSelectedCert(cert);
                        if (cert.type === 'excellence') triggerCelebration();
                      }}
                      className={`cursor-pointer w-full text-right p-4 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-indigo-50/70 dark:bg-indigo-950/60 border-indigo-500 shadow-sm'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span
                          className={`font-bold font-cairo ${
                            isExcellence
                              ? 'text-amber-600 dark:text-amber-400'
                              : 'text-indigo-600 dark:text-indigo-400'
                          }`}
                        >
                          {isExcellence
                            ? isAr
                              ? 'شهادة تقدير وتفوق'
                              : 'Honors Award'
                            : isAr
                            ? 'بيان درجات معتمد'
                            : 'Grade Report'}
                        </span>

                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-600 dark:text-slate-300">
                            {getPeriodBadgeLabel(cert.examPeriod)}
                          </span>
                          {!readOnly && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setCertToDelete(cert);
                              }}
                              className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-950 text-slate-400 hover:text-rose-600"
                              title={isAr ? 'حذف الوثيقة' : 'Delete'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-3 mt-1">
                        <img
                          src={getCertStudentAvatar(cert)}
                          onError={handleImageErrorToTeacherAvatar}
                          alt={cert.studentName}
                          referrerPolicy="no-referrer"
                          className="w-11 h-11 rounded-xl object-cover border border-amber-300 dark:border-amber-700 shrink-0 shadow-xs"
                        />
                        <div className="min-w-0">
                          <p className="font-bold font-cairo text-slate-900 dark:text-white text-sm truncate">
                            {cert.studentName}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-tajawal truncate">
                            {cert.studentGrade}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] font-mono-numbers text-slate-400">
                        <span>{cert.serialNumber}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">
                            {cert.examsCount || 0} {isAr ? 'اختبار' : 'exams'}
                          </span>
                          <span className="font-black text-emerald-600 dark:text-emerald-400">
                            {cert.score}%
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Official Certificate & Grade Transcript Viewer */}
            <div className="lg:col-span-8">
              {selectedCert ? (
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-3.5 sm:p-6 md:p-8 space-y-5 sm:space-y-6 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono-numbers">
                      <span className="break-all">
                        {isAr ? 'الرقم التسلسلي المعتمد:' : 'Serial:'} {selectedCert.serialNumber}
                      </span>
                      {selectedCert.isAutoGenerated && (
                        <span className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-cairo font-bold text-[10px]">
                          ⚡ {isAr ? 'صادرة أوتوماتيك من الدرجات' : 'Auto-Generated'}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 font-cairo">
                      {!readOnly && (
                        <button
                          type="button"
                          onClick={() => openEditCertModal(selectedCert)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>{isAr ? 'تعديل' : 'Edit'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          handleVerifyCertificateFromDb(selectedCert.serialNumber || selectedCert.id)
                        }
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-colors cursor-pointer"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>{isAr ? 'فحص صحة الشهادة (QR)' : 'Verify QR'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => window.print()}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>{isAr ? 'طباعة PDF' : 'Print PDF'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadCertificateHtml(selectedCert, true)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{isAr ? 'تنزيل شهادة PDF برمز QR' : 'Download QR Certificate'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Certificate Border Frame */}
                  <div className="relative p-4 sm:p-6 md:p-10 rounded-2xl border-4 border-double border-amber-400/60 dark:border-amber-500/40 bg-radial from-amber-50/20 via-white to-slate-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 text-center space-y-5 sm:space-y-6 overflow-hidden">
                    <div className="flex items-center justify-center gap-3 sm:gap-4">
                      <div className="relative w-12 h-12 sm:w-16 sm:h-16">
                        <img
                          src={CERTIFICATE_CREST_IMAGE}
                          onError={handleImageErrorToTeacherAvatar}
                          alt="Gold Crest Seal"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain drop-shadow-md rounded-full border-2 border-amber-400/50"
                        />
                      </div>
                      <div className="relative w-20 h-20 sm:w-24 sm:h-24">
                        <img
                          src={getCertStudentAvatar(selectedCert)}
                          onError={handleImageErrorToTeacherAvatar}
                          alt={selectedCert.studentName}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover rounded-full border-4 border-amber-400 shadow-lg"
                        />
                        <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black font-cairo whitespace-nowrap shadow">
                          {selectedCert.score}%
                        </span>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-xs uppercase tracking-widest text-amber-700 dark:text-amber-400 font-bold font-cairo">
                        {settings?.schoolName ||
                          (isAr ? 'أكاديمية نوابغ التعليمية الدولية' : 'Nawabegh International Academy')}
                      </h4>
                      <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-slate-900 dark:text-white mt-1 font-cairo">
                        {selectedCert.type === 'excellence'
                          ? isAr
                            ? 'شهادة شرف وتقدير وتفوق'
                            : 'Certificate of Academic Excellence'
                          : isAr
                          ? 'بيان درجات وتقييم معتمد'
                          : 'Certified Academic Transcript'}
                      </h2>
                      <p className="text-xs text-slate-500 mt-1 font-tajawal">
                        {isAr ? 'للعام الدراسي' : 'Academic Year'} {selectedCert.academicYear} ·{' '}
                        {getPeriodBadgeLabel(selectedCert.examPeriod)}
                      </p>
                    </div>

                    <div className="max-w-xl mx-auto space-y-2">
                      <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 font-tajawal">
                        {isAr
                          ? 'تشهد إدارة الأكاديمية وهيئة التدريس بأن الطالب / الطالبة:'
                          : 'This is to officially certify that:'}
                      </p>
                      <p className="text-lg sm:text-xl md:text-2xl font-black font-cairo text-indigo-700 dark:text-indigo-400 py-1 border-b-2 border-amber-400/40 inline-block px-4 sm:px-8 max-w-full break-words">
                        {selectedCert.studentName}
                      </p>
                      <p className="text-xs text-slate-500 font-tajawal">{selectedCert.studentGrade}</p>
                      {selectedCert.score >= 80 && (
                        <div className="pt-1">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-200 text-xs font-bold font-cairo">
                            <Award className="w-3.5 h-3.5 text-amber-600" />
                            <span>{getScoreTierLabel(selectedCert.score)}</span>
                          </span>
                        </div>
                      )}
                      {(() => {
                        const studentEarnedChallenges = classChallenges.filter((ch) =>
                          ch.winners.some(
                            (w) =>
                              w.studentId === selectedCert.studentId ||
                              (w.studentName && w.studentName.trim() === selectedCert.studentName.trim())
                          )
                        );
                        if (studentEarnedChallenges.length === 0) return null;
                        return (
                          <div className="pt-1.5 flex flex-wrap items-center justify-center gap-1.5">
                            {studentEarnedChallenges.map((ch) => (
                              <span
                                key={ch.id}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-950/70 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200 text-[11px] font-black font-cairo"
                              >
                                <Sparkles className="w-3 h-3 text-amber-500" />
                                <span>{ch.badgeTitle}</span>
                              </span>
                            ))}
                          </div>
                        );
                      })()}
                    </div>

                    <div className="max-w-xl mx-auto">
                      <p className="text-xs md:text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-tajawal font-medium">
                        {selectedCert.notes}
                      </p>
                    </div>

                    {/* Automatic Scores Summary Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center font-mono-numbers pt-2">
                      <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-400/40">
                        <span className="text-[11px] font-tajawal text-amber-800 dark:text-amber-300 block">
                          {isAr ? 'المعدل المعتمد' : 'Certified Avg'}
                        </span>
                        <span className="text-lg font-black text-amber-700 dark:text-amber-300">
                          {selectedCert.score}%
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-400/30">
                        <span className="text-[11px] font-tajawal text-emerald-800 dark:text-emerald-300 block">
                          {isAr ? 'متوسط الأسبوعي' : 'Weekly Avg'}
                        </span>
                        <span className="text-lg font-black text-emerald-700 dark:text-emerald-300">
                          {selectedCert.weeklyAverage !== null && selectedCert.weeklyAverage !== undefined
                            ? `${selectedCert.weeklyAverage}%`
                            : '—'}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-400/30">
                        <span className="text-[11px] font-tajawal text-purple-800 dark:text-purple-300 block">
                          {isAr ? 'متوسط الشهري' : 'Monthly Avg'}
                        </span>
                        <span className="text-lg font-black text-purple-700 dark:text-purple-300">
                          {selectedCert.monthlyAverage !== null && selectedCert.monthlyAverage !== undefined
                            ? `${selectedCert.monthlyAverage}%`
                            : '—'}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                        <span className="text-[11px] font-tajawal text-slate-500 block">
                          {isAr ? 'الامتحانات المرصودة' : 'Exams Count'}
                        </span>
                        <span className="text-lg font-black text-slate-900 dark:text-white">
                          {selectedCert.examsCount || selectedCert.breakdown?.length || 0}
                        </span>
                      </div>
                    </div>

                    {/* Recorded Exam Breakdown Table (from quiz_attempts) */}
                    {selectedCert.breakdown && selectedCert.breakdown.length > 0 && (
                      <div className="text-right space-y-2 pt-2">
                        <h5 className="text-xs font-bold font-cairo text-slate-700 dark:text-slate-200">
                          {isAr
                            ? 'كشف درجات الاختبارات الأسبوعية والشهرية المسجلة:'
                            : 'Recorded Weekly & Monthly Exams Breakdown:'}
                        </h5>
                        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                          <table className="w-full text-xs text-right font-tajawal">
                            <thead className="bg-slate-100 dark:bg-slate-800 font-cairo text-slate-700 dark:text-slate-200">
                              <tr>
                                <th className="p-2.5">{isAr ? 'الاختبار' : 'Exam'}</th>
                                <th className="p-2.5">{isAr ? 'النوع' : 'Type'}</th>
                                <th className="p-2.5">{isAr ? 'المادة' : 'Subject'}</th>
                                <th className="p-2.5">{isAr ? 'الدرجة' : 'Score'}</th>
                                <th className="p-2.5">{isAr ? 'النسبة' : '%'}</th>
                                <th className="p-2.5">{isAr ? 'التاريخ' : 'Date'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 bg-white/80 dark:bg-slate-900/60">
                              {selectedCert.breakdown.map((row, idx) => (
                                <tr key={row.attemptId || idx}>
                                  <td className="p-2.5 font-bold text-slate-900 dark:text-white">
                                    {row.quizTitle}
                                  </td>
                                  <td className="p-2.5">
                                    <span
                                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-cairo ${
                                        row.quizType === 'monthly'
                                          ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/70 dark:text-purple-300'
                                          : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300'
                                      }`}
                                    >
                                      {row.quizType === 'monthly'
                                        ? isAr
                                          ? 'شهري'
                                          : 'Monthly'
                                        : isAr
                                        ? 'أسبوعي'
                                        : 'Weekly'}
                                    </span>
                                  </td>
                                  <td className="p-2.5 text-slate-600 dark:text-slate-300">{row.subject}</td>
                                  <td className="p-2.5 font-mono-numbers">
                                    {row.earnedMarks} / {row.totalMarks}
                                  </td>
                                  <td className="p-2.5 font-mono-numbers font-bold text-emerald-600 dark:text-emerald-400">
                                    {row.percentage}%
                                  </td>
                                  <td className="p-2.5 font-mono-numbers text-slate-400">{row.takenDate}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {/* Signatures, Official QR Code & Seal Row */}
                    <div className="pt-5 sm:pt-6 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 items-center gap-4 sm:gap-6 text-xs text-slate-500 font-mono-numbers">
                      <div>
                        <span className="block text-slate-400 mb-1 font-tajawal">
                          {isAr ? 'إدارة منصة الشريف' : 'Platform Administration'}
                        </span>
                        <span className="font-bold text-slate-800 dark:text-slate-200 block text-sm font-cairo">
                          {selectedCert.principalName}
                        </span>
                        <span className="text-[11px] text-emerald-600 block mt-0.5 font-tajawal">
                          ✓ {isAr ? 'معتمدة تلقائياً من قاعدة البيانات' : 'DB Auto-Verified'}
                        </span>
                      </div>

                      {/* Scannable QR Code Box */}
                      <div className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white dark:bg-slate-900 border-2 border-emerald-500/60 shadow-sm mx-auto">
                        {selectedCertQrUrl ? (
                          <img
                            src={selectedCertQrUrl}
                            alt="QR Verification Code"
                            onClick={() =>
                              handleVerifyCertificateFromDb(selectedCert.serialNumber || selectedCert.id)
                            }
                            className="w-24 h-24 object-contain cursor-pointer"
                            title="امسح الكود بالكاميرا أو اضغط للتحقق المباشر من قاعدة البيانات"
                          />
                        ) : (
                          <QrCode className="w-16 h-16 text-emerald-700" />
                        )}
                        <span className="text-[10px] font-cairo font-bold text-emerald-800 dark:text-emerald-300 mt-1">
                          رمز التحقق الرسمي (QR Code)
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            handleVerifyCertificateFromDb(selectedCert.serialNumber || selectedCert.id)
                          }
                          className="text-[10px] font-cairo font-bold text-indigo-600 dark:text-indigo-400 hover:underline mt-0.5 cursor-pointer"
                        >
                          تحقق من قاعدة البيانات الآن
                        </button>
                      </div>

                      <div>
                        <span className="block text-slate-400 mb-1 font-tajawal">
                          {isAr ? 'تاريخ الإصدار' : 'Issue Date'}
                        </span>
                        <span className="font-bold text-slate-800 dark:text-slate-200 block text-sm">
                          {selectedCert.issueDate}
                        </span>
                        <span className="text-[11px] text-slate-400 block mt-0.5">
                          {selectedCert.serialNumber}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-sm text-slate-500 font-tajawal">
                  {isAr ? 'اختر شهادة أو بيان درجات لعرض التفاصيل.' : 'Select a document to preview.'}
                </div>
              )}
            </div>
          </div>
        )
      ) : (
        /* ===================================================================== */
        /* VIEW 2: RECORDED EXAM GRADES LEDGER (WEEKLY & MONTHLY) */
        /* ===================================================================== */
        <div className="space-y-6">
          {/* Student Weekly & Monthly Averages Table */}
          {studentSummaries.length > 0 && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <h3 className="text-sm md:text-base font-bold font-cairo text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span>
                  {isAr
                    ? 'ملخص متوسطات الطلاب من الامتحانات المسجلة (أسبوعي / شهري)'
                    : 'Student Exam Averages Summary (Weekly / Monthly)'}
                </span>
              </h3>
              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-xs text-right font-tajawal">
                  <thead className="bg-slate-50 dark:bg-slate-800 font-cairo text-slate-600 dark:text-slate-300">
                    <tr>
                      <th className="p-3">{isAr ? 'الطالب' : 'Student'}</th>
                      <th className="p-3">{isAr ? 'الصف' : 'Grade'}</th>
                      <th className="p-3">{isAr ? 'عدد الأسبوعي' : 'Weekly Count'}</th>
                      <th className="p-3">{isAr ? 'متوسط الأسبوعي' : 'Weekly Avg'}</th>
                      <th className="p-3">{isAr ? 'عدد الشهري' : 'Monthly Count'}</th>
                      <th className="p-3">{isAr ? 'متوسط الشهري' : 'Monthly Avg'}</th>
                      <th className="p-3">{isAr ? 'المعدل الإجمالي' : 'Overall Avg'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {studentSummaries.map((s) => (
                      <tr key={s.studentId} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-bold text-slate-900 dark:text-white font-cairo">
                          {s.studentName}
                          {s.studentCode && (
                            <span className="text-[10px] text-slate-400 font-mono-numbers mr-1.5">
                              ({s.studentCode})
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-slate-600 dark:text-slate-300">{s.grade}</td>
                        <td className="p-3 font-mono-numbers">{s.weeklyScores.length}</td>
                        <td className="p-3 font-mono-numbers font-bold text-emerald-600">
                          {s.weeklyAvg !== null ? `${s.weeklyAvg}%` : '—'}
                        </td>
                        <td className="p-3 font-mono-numbers">{s.monthlyScores.length}</td>
                        <td className="p-3 font-mono-numbers font-bold text-purple-600">
                          {s.monthlyAvg !== null ? `${s.monthlyAvg}%` : '—'}
                        </td>
                        <td className="p-3 font-mono-numbers font-black text-amber-600">{s.overallAvg}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Individual Recorded Exam Attempts Table */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm md:text-base font-bold font-cairo text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                <span>
                  {isAr
                    ? `سجل درجات الامتحانات المسجلة في قاعدة البيانات (${filteredAttempts.length})`
                    : `Recorded Exam Scores in DB (${filteredAttempts.length})`}
                </span>
              </h3>
            </div>

            {filteredAttempts.length === 0 ? (
              <div className="p-8 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 text-center space-y-3">
                <p className="text-xs md:text-sm text-slate-500 font-tajawal">
                  {isAr
                    ? 'لا توجد درجات امتحانات مسجلة في قاعدة البيانات بعد. قم برصد درجة اختبار أسبوعي أو شهري أو ادعُ الطلاب لإتمام الاختبارات التفاعلية.'
                    : 'No exam attempts recorded yet.'}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-xs text-right font-tajawal">
                  <thead className="bg-slate-50 dark:bg-slate-800 font-cairo text-slate-600 dark:text-slate-300">
                    <tr>
                      <th className="p-3">{isAr ? 'الطالب' : 'Student'}</th>
                      <th className="p-3">{isAr ? 'الاختبار' : 'Quiz'}</th>
                      <th className="p-3">{isAr ? 'التصنيف' : 'Type'}</th>
                      <th className="p-3">{isAr ? 'المادة' : 'Subject'}</th>
                      <th className="p-3">{isAr ? 'الدرجة' : 'Score'}</th>
                      <th className="p-3">{isAr ? 'النسبة' : '%'}</th>
                      <th className="p-3">{isAr ? 'التاريخ' : 'Date'}</th>
                      {!readOnly && <th className="p-3">{isAr ? 'إجراء' : 'Action'}</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredAttempts.map((att) => (
                      <tr key={att.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-bold font-cairo text-slate-900 dark:text-white">
                          {att.studentName}
                        </td>
                        <td className="p-3 text-slate-700 dark:text-slate-200">{att.quizTitle}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold font-cairo ${
                              att.quizType === 'monthly'
                                ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/70 dark:text-purple-300'
                                : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300'
                            }`}
                          >
                            {att.quizType === 'monthly'
                              ? isAr
                                ? 'اختبار شهري'
                                : 'Monthly'
                              : isAr
                              ? 'اختبار أسبوعي'
                              : 'Weekly'}
                          </span>
                        </td>
                        <td className="p-3">{att.subject}</td>
                        <td className="p-3 font-mono-numbers">
                          {att.earnedMarks} / {att.totalMarks}
                        </td>
                        <td className="p-3 font-mono-numbers font-black text-emerald-600 dark:text-emerald-400">
                          {att.percentage}%
                        </td>
                        <td className="p-3 font-mono-numbers text-slate-400">{att.takenDate}</td>
                        {!readOnly && (
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditAttemptModal(att)}
                                className="p-1.5 rounded-lg text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40"
                                title={isAr ? 'تعديل الدرجة' : 'Edit Score'}
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setAttemptToDelete(att)}
                                className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                                title={isAr ? 'حذف الدرجة' : 'Delete Attempt'}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL: RECORD EXAM SCORE FOR REAL DB STUDENT */}
      {/* ===================================================================== */}
      {isRecordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/80">
              <h3 className="font-bold text-sm md:text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-500" />
                <span>
                  {isAr
                    ? 'رصد درجة امتحان (أسبوعي / شهري) وإصدار الشهادة أوتوماتيك'
                    : 'Record Exam Score & Auto-Issue Certificate'}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setIsRecordModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveRecordedScore} className="p-5 space-y-4 text-xs">
              {recError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 font-bold">
                  {recError}
                </div>
              )}

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                  {isAr ? 'الطالب (من قاعدة البيانات)' : 'DB Student'}
                </label>
                {localStudents.length > 0 ? (
                  <select
                    value={recStudentId}
                    onChange={(e) => setRecStudentId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  >
                    <option value="">{isAr ? '-- اختر الطالب --' : '-- Select Student --'}</option>
                    {localStudents.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code} · {s.grade})
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 flex items-center justify-between gap-2">
                    <span>{isAr ? 'لا يوجد طلاب مسجلون في قاعدة البيانات بعد.' : 'No DB students yet.'}</span>
                    {onNavigateTab && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsRecordModalOpen(false);
                          onNavigateTab('students');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-[11px]"
                      >
                        {isAr ? 'إضافة طالب' : 'Add Student'}
                      </button>
                    )}
                  </div>
                )}
              </div>

              {localQuizzes.length > 0 && (
                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'اختر من الاختبارات المسجلة (اختياري)' : 'Select DB Quiz (Optional)'}
                  </label>
                  <select
                    value={recQuizId}
                    onChange={(e) => handleSelectQuizInModal(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="">{isAr ? '-- إدخال يدوي لبيانات الاختبار --' : '-- Manual Exam Entry --'}</option>
                    {localQuizzes.map((qz) => (
                      <option key={qz.id} value={qz.id}>
                        {qz.title} ({qz.type === 'monthly' ? 'شهري' : 'أسبوعي'} · {qz.subject})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'اسم الاختبار' : 'Exam Title'}
                  </label>
                  <input
                    type="text"
                    value={recQuizTitle}
                    onChange={(e) => setRecQuizTitle(e.target.value)}
                    placeholder={isAr ? 'مثال: الاختبار الأسبوعي الأول - الوحدة الأولى' : 'Weekly Exam #1'}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'تصنيف الاختبار' : 'Exam Period'}
                  </label>
                  <select
                    value={recQuizType}
                    onChange={(e) => setRecQuizType(e.target.value as 'weekly' | 'monthly')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  >
                    <option value="weekly">{isAr ? 'اختبار أسبوعي' : 'Weekly Exam'}</option>
                    <option value="monthly">{isAr ? 'اختبار شهري' : 'Monthly Exam'}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'المادة الدراسية' : 'Subject'}
                  </label>
                  <input
                    type="text"
                    value={recSubject}
                    onChange={(e) => setRecSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'درجة الطالب' : 'Earned Marks'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={recEarnedMarks}
                    onChange={(e) => setRecEarnedMarks(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono-numbers font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'الدرجة النهائية' : 'Total Marks'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={recTotalMarks}
                    onChange={(e) => setRecTotalMarks(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono-numbers font-bold"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-200">
                    {isAr ? 'تاريخ الامتحان' : 'Exam Date'}
                  </label>
                  <input
                    type="date"
                    value={recTakenDate}
                    onChange={(e) => setRecTakenDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono-numbers"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRecordModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isRecording || localStudents.length === 0}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-45 text-white font-black"
                >
                  {isRecording
                    ? isAr
                      ? 'جاري الحفظ...'
                      : 'Saving...'
                    : isAr
                    ? 'حفظ وإصدار الشهادة أوتوماتيك'
                    : 'Save & Auto-Issue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* EDIT CERTIFICATE MODAL */}
      {/* ===================================================================== */}
      {editingCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-black text-base text-slate-900 dark:text-white">
                {isAr ? `تعديل وثيقة: ${editingCert.studentName}` : `Edit Document: ${editingCert.studentName}`}
              </h3>
              <button type="button" onClick={() => setEditingCert(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveCertificateEdit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'نوع الوثيقة' : 'Document Type'}</label>
                  <select
                    value={certEditForm.type}
                    onChange={(e) => setCertEditForm({ ...certEditForm, type: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="excellence">{isAr ? 'شهادة تقدير وتفوق' : 'Honors Certificate'}</option>
                    <option value="grades_report">{isAr ? 'بيان درجات معتمد' : 'Grades Transcript'}</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'المعدل (%)' : 'Score (%)'}</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={certEditForm.score}
                    onChange={(e) => setCertEditForm({ ...certEditForm, score: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono-numbers"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold mb-1">{isAr ? 'المسار / التوصيف' : 'Track / Title'}</label>
                <input
                  type="text"
                  value={certEditForm.subjectOrTrack}
                  onChange={(e) => setCertEditForm({ ...certEditForm, subjectOrTrack: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'اعتماد المدير / الجهة' : 'Principal'}</label>
                  <input
                    type="text"
                    value={certEditForm.principalName}
                    onChange={(e) => setCertEditForm({ ...certEditForm, principalName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'العام الدراسي' : 'Academic Year'}</label>
                  <input
                    type="text"
                    value={certEditForm.academicYear}
                    onChange={(e) => setCertEditForm({ ...certEditForm, academicYear: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold mb-1">{isAr ? 'نص وملاحظات الشهادة' : 'Certificate Notes'}</label>
                <textarea
                  rows={3}
                  value={certEditForm.notes}
                  onChange={(e) => setCertEditForm({ ...certEditForm, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-tajawal"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingCert(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-bold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSavingEdit}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black"
                >
                  {isSavingEdit ? (isAr ? 'جاري الحفظ...' : 'Saving...') : isAr ? 'حفظ التعديلات' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* EDIT RECORDED EXAM SCORE MODAL */}
      {/* ===================================================================== */}
      {editingAttempt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-black text-base text-slate-900 dark:text-white">
                {isAr ? `تعديل درجة: ${editingAttempt.studentName}` : `Edit Score: ${editingAttempt.studentName}`}
              </h3>
              <button type="button" onClick={() => setEditingAttempt(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveAttemptEdit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1">{isAr ? 'اسم الاختبار' : 'Quiz Title'}</label>
                <input
                  type="text"
                  value={attemptEditForm.quizTitle}
                  onChange={(e) => setAttemptEditForm({ ...attemptEditForm, quizTitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'التصنيف' : 'Period'}</label>
                  <select
                    value={attemptEditForm.quizType}
                    onChange={(e) => setAttemptEditForm({ ...attemptEditForm, quizType: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="weekly">{isAr ? 'أسبوعي' : 'Weekly'}</option>
                    <option value="monthly">{isAr ? 'شهري' : 'Monthly'}</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'المادة' : 'Subject'}</label>
                  <input
                    type="text"
                    value={attemptEditForm.subject}
                    onChange={(e) => setAttemptEditForm({ ...attemptEditForm, subject: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'درجة الطالب' : 'Earned'}</label>
                  <input
                    type="number"
                    min={0}
                    value={attemptEditForm.earnedMarks}
                    onChange={(e) => setAttemptEditForm({ ...attemptEditForm, earnedMarks: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">{isAr ? 'الدرجة النهائية' : 'Total'}</label>
                  <input
                    type="number"
                    min={1}
                    value={attemptEditForm.totalMarks}
                    onChange={(e) => setAttemptEditForm({ ...attemptEditForm, totalMarks: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono-numbers"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold mb-1">{isAr ? 'تاريخ الامتحان' : 'Date'}</label>
                <input
                  type="date"
                  value={attemptEditForm.takenDate}
                  onChange={(e) => setAttemptEditForm({ ...attemptEditForm, takenDate: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono-numbers"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingAttempt(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-bold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSavingEdit}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black"
                >
                  {isSavingEdit ? (isAr ? 'جاري التحديث...' : 'Saving...') : isAr ? 'حفظ وإعادة احتساب الشهادات' : 'Save & Recalculate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* DELETE CONFIRMATION MODALS (INLINE) */}
      {/* ===================================================================== */}
      {(certToDelete || attemptToDelete) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="font-black text-base">
                {certToDelete
                  ? isAr
                    ? 'تأكيد حذف الوثيقة من قاعدة البيانات'
                    : 'Confirm Delete Certificate'
                  : isAr
                  ? 'تأكيد حذف درجة الاختبار'
                  : 'Confirm Delete Exam Score'}
              </h3>
            </div>
            <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 font-tajawal">
              {certToDelete
                ? isAr
                  ? `هل تريد حذف وثيقة «${certToDelete.studentName}» (${certToDelete.serialNumber})؟`
                  : `Delete certificate for ${certToDelete.studentName}?`
                : isAr
                ? `هل تريد حذف درجة اختبار «${attemptToDelete?.quizTitle}» للطالب «${attemptToDelete?.studentName}»؟ سيتم إعادة احتساب معدلات الشهادات تلقائياً.`
                : `Delete exam attempt for ${attemptToDelete?.studentName}?`}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setCertToDelete(null);
                  setAttemptToDelete(null);
                }}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={certToDelete ? handleConfirmDeleteCert : handleConfirmDeleteAttempt}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black"
              >
                {isDeleting ? (isAr ? 'جاري الحذف...' : 'Deleting...') : isAr ? 'تأكيد الحذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* QR CODE LIVE DATABASE VERIFICATION MODAL */}
      {/* ===================================================================== */}
      {isVerifyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-tajawal">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-5 bg-emerald-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-6 h-6 text-amber-300" />
                <div>
                  <h3 className="font-cairo font-black text-base">
                    التحقق الإلكتروني من الشهادة (QR Code) — قاعدة بيانات منصة الشريف
                  </h3>
                  <p className="text-xs text-emerald-100 font-mono-numbers">{verifySerialInput}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsVerifyModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs md:text-sm">
              {isVerifyingCert ? (
                <div className="py-8 text-center space-y-2">
                  <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
                  <p className="font-cairo font-bold text-slate-600 dark:text-slate-300">
                    جارِ فحص ومطابقة الشهادة من قاعدة البيانات مباشرة...
                  </p>
                </div>
              ) : verifyResult?.verified && verifyResult?.certificate ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border-2 border-emerald-500 flex items-center gap-3">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
                    <div>
                      <p className="font-cairo font-black text-emerald-900 dark:text-emerald-200 text-sm">
                        ✓ شهادة رسمية صحيحة وموثقة في قاعدة بيانات منصة الشريف
                      </p>
                      <p className="text-xs text-emerald-700 dark:text-emerald-300">
                        تاريخ الفحص اللحظي: {new Date(verifyResult.verifiedAt).toLocaleString('ar-EG')}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                    <div>
                      <span className="text-[11px] text-slate-400 block">اسم الطالب / الطالبة</span>
                      <strong className="font-cairo text-slate-900 dark:text-white">
                        {verifyResult.certificate.studentName}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">المرحلة الدراسية</span>
                      <strong className="font-cairo text-slate-900 dark:text-white">
                        {verifyResult.certificate.studentGrade}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">المعدل المعتمد</span>
                      <strong className="font-mono-numbers text-emerald-600 font-black text-base">
                        {verifyResult.certificate.score}%
                      </strong>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">الرقم التسلسلي وتاريخ الإصدار</span>
                      <strong className="font-mono-numbers text-slate-800 dark:text-slate-200 text-xs">
                        {verifyResult.certificate.serialNumber} • {verifyResult.certificate.issueDate}
                      </strong>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border-2 border-rose-500 text-center space-y-2">
                  <AlertTriangle className="w-8 h-8 text-rose-600 mx-auto" />
                  <p className="font-cairo font-black text-rose-800 dark:text-rose-200">
                    {verifyResult?.message || 'الشهادة غير موجودة في قاعدة البيانات'}
                  </p>
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setIsVerifyModalOpen(false)}
                  className="px-5 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-cairo font-bold text-xs cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
