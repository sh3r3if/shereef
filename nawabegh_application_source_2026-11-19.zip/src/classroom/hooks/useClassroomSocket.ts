import { useCallback, useEffect, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import type {
  ClassroomParticipant,
  ConnectionQualityLevel,
  LiveRoomInfo,
} from '../../types/classroom';

export type SocketConnectionStatus =
  | 'idle'
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'disconnected'
  | 'error';

interface UseClassroomSocketOptions {
  roomToken: string | null;
  enabled: boolean;
}

export function useClassroomSocket({ roomToken, enabled }: UseClassroomSocketOptions) {
  const socketRef = useRef<Socket | null>(null);
  const [status, setStatus] = useState<SocketConnectionStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [room, setRoom] = useState<LiveRoomInfo | null>(null);
  const [self, setSelf] = useState<ClassroomParticipant | null>(null);
  const [participants, setParticipants] = useState<ClassroomParticipant[]>([]);

  useEffect(() => {
    if (!enabled || !roomToken) {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
      setStatus('idle');
      return;
    }

    setStatus('connecting');
    setErrorMessage(null);

    const socket = io('/classroom', {
      path: '/socket.io-classroom',
      auth: { token: roomToken },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 800,
      reconnectionDelayMax: 4000,
    });

    socketRef.current = socket;

    socket.on('connect', () => {
      setStatus('connected');
      setErrorMessage(null);
    });

    socket.io.on('reconnect_attempt', () => {
      setStatus('reconnecting');
    });

    socket.on('disconnect', () => {
      setStatus('disconnected');
    });

    socket.on('connect_error', (err: Error) => {
      setStatus('error');
      setErrorMessage(err.message || 'تعذر الاتصال بخادم الفصل المباشر');
    });

    socket.on(
      'classroom:state_sync',
      (payload: {
        room: LiveRoomInfo | null;
        self: ClassroomParticipant;
        participants: ClassroomParticipant[];
      }) => {
        if (payload.room) setRoom(payload.room);
        if (payload.self) setSelf(payload.self);
        if (Array.isArray(payload.participants)) {
          setParticipants(payload.participants);
        }
      }
    );

    socket.on('classroom:room_updated', (updatedRoom: LiveRoomInfo) => {
      setRoom(updatedRoom);
    });

    socket.on('classroom:participant_joined', (joined: ClassroomParticipant) => {
      setParticipants((prev) => {
        const filtered = prev.filter(
          (p) => p.socketId !== joined.socketId && p.userId !== joined.userId
        );
        return [...filtered, joined];
      });
    });

    socket.on('classroom:participant_updated', (updated: ClassroomParticipant) => {
      setParticipants((prev) =>
        prev.map((p) => (p.socketId === updated.socketId ? updated : p))
      );
      setSelf((curr) => (curr && curr.socketId === updated.socketId ? updated : curr));
    });

    socket.on(
      'classroom:participant_left',
      (payload: { socketId: string; userId: string }) => {
        setParticipants((prev) =>
          prev.filter(
            (p) => p.socketId !== payload.socketId && p.userId !== payload.userId
          )
        );
      }
    );

    return () => {
      socket.removeAllListeners();
      socket.disconnect();
      socketRef.current = null;
    };
  }, [enabled, roomToken]);

  const emitMediaState = useCallback(
    (payload: {
      isMicEnabled?: boolean;
      isCamEnabled?: boolean;
      isScreenSharing?: boolean;
    }) => {
      socketRef.current?.emit('media:state_changed', payload);
    },
    []
  );

  const emitQualityReport = useCallback((quality: ConnectionQualityLevel) => {
    socketRef.current?.emit('media:quality_report', { quality });
  }, []);

  return {
    socket: socketRef.current,
    socketRef,
    status,
    errorMessage,
    room,
    self,
    participants,
    emitMediaState,
    emitQualityReport,
  };
}
