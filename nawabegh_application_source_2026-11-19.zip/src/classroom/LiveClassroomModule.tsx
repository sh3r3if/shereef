import React, { useCallback, useEffect, useState } from 'react';
import { getAuthHeaders } from '../utils/rbac';
import type { CurrentUser, Teacher } from '../types';
import type {
  ClassroomJoinResponse,
  ClassroomRole,
  LiveRoomInfo,
} from '../types/classroom';
import { RoomsLobbyView } from './components/RoomsLobbyView';
import {
  PreJoinCheckModal,
  type PreJoinSettings,
} from './components/PreJoinCheckModal';
import { ClassroomShell } from './components/ClassroomShell';

interface LiveClassroomModuleProps {
  currentUser: CurrentUser;
  teachers?: Teacher[];
  initialRoomCode?: string | null;
  initialInviteToken?: string | null;
  onClearDeepLink?: () => void;
}

function mapCurrentUserToClassroomRole(role?: string): ClassroomRole {
  const clean = String(role || '').toLowerCase();
  if (clean === 'admin' || clean === 'supervisor') return 'admin';
  if (clean === 'teacher') return 'teacher';
  if (clean === 'secretary') return 'assistant';
  return 'student';
}

export const LiveClassroomModule: React.FC<LiveClassroomModuleProps> = ({
  currentUser,
  teachers = [],
  initialRoomCode,
  initialInviteToken,
  onClearDeepLink,
}) => {
  const [rooms, setRooms] = useState<LiveRoomInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [mediaMode, setMediaMode] = useState<'livekit' | 'webrtc-p2p'>('webrtc-p2p');
  const [redisConnected, setRedisConnected] = useState(false);

  const [pendingRoom, setPendingRoom] = useState<LiveRoomInfo | null>(null);
  const [activeInviteToken, setActiveInviteToken] = useState<string | null>(
    initialInviteToken || null
  );
  const [isJoining, setIsJoining] = useState(false);
  const [joinError, setJoinError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [activeSession, setActiveSession] = useState<{
    joinData: ClassroomJoinResponse & {
      user: { userId: string; userName: string; role: ClassroomRole };
    };
    preJoinSettings: PreJoinSettings;
  } | null>(null);

  const userRole = mapCurrentUserToClassroomRole(currentUser?.role);
  const authHeaders = getAuthHeaders(currentUser, teachers);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => setToastMessage(null), 3500);
  }, []);

  const fetchLobbyData = useCallback(async () => {
    setLoading(true);
    try {
      const [healthRes, roomsRes] = await Promise.all([
        fetch('/api/classroom/health'),
        fetch('/api/classroom/rooms'),
      ]);
      if (healthRes.ok) {
        const h = await healthRes.json();
        setMediaMode(h.mediaMode === 'livekit' ? 'livekit' : 'webrtc-p2p');
        setRedisConnected(Boolean(h.redisConnected));
      }
      if (roomsRes.ok) {
        const r = await roomsRes.json();
        setRooms(Array.isArray(r.rooms) ? r.rooms : []);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLobbyData();
  }, [fetchLobbyData]);

  // Handle deep-link ?liveRoom=...&invite=...
  useEffect(() => {
    if (!initialRoomCode) return;
    fetch(`/api/classroom/rooms/${encodeURIComponent(initialRoomCode)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.room) {
          setPendingRoom(data.room);
          setActiveInviteToken(initialInviteToken || null);
        } else {
          showToast('غرفة الفصل المطلوبة غير متوفرة أو تم حذفها');
        }
      })
      .catch(() => {});
  }, [initialRoomCode, initialInviteToken, showToast]);

  const handleCreateRoom = async (payload: {
    title: string;
    subject: string;
    grade: string;
    waitingRoomEnabled: boolean;
    maxParticipants: number;
  }) => {
    const res = await fetch('/api/classroom/rooms', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders,
      },
      body: JSON.stringify({ ...payload, startImmediately: true }),
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'تعذر إنشاء الغرفة');
      return;
    }
    showToast(`تم إنشاء الفصل بنجاح (${data.room.roomCode})`);
    await fetchLobbyData();
  };

  const handleJoinByCode = async (roomCode: string) => {
    const res = await fetch(`/api/classroom/rooms/${encodeURIComponent(roomCode)}`);
    if (!res.ok) {
      showToast('لم يتم العثور على غرفة بهذا الرمز');
      return;
    }
    const data = await res.json();
    if (data?.room) {
      setJoinError(null);
      setPendingRoom(data.room);
    }
  };

  const handleConfirmPreJoin = async (settings: PreJoinSettings) => {
    if (!pendingRoom) return;
    setIsJoining(true);
    setJoinError(null);

    try {
      const res = await fetch(
        `/api/classroom/rooms/${encodeURIComponent(pendingRoom.id)}/join`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeaders,
          },
          body: JSON.stringify({
            inviteToken: activeInviteToken || undefined,
            guestName: settings.guestName,
          }),
        }
      );

      const data = await res.json();
      if (!res.ok) {
        setJoinError(data.error || 'تعذر الدخول إلى الفصل الافتراضي');
        return;
      }

      setActiveSession({
        joinData: data,
        preJoinSettings: settings,
      });
      setPendingRoom(null);
      onClearDeepLink?.();
    } catch {
      setJoinError('حدث خطأ في الشبكة أثناء تأمين الدخول للغرفة');
    } finally {
      setIsJoining(false);
    }
  };

  const handleGenerateInviteLink = async (
    roomId: string,
    role: ClassroomRole,
    ttlMinutes: number
  ): Promise<string | null> => {
    const res = await fetch(
      `/api/classroom/rooms/${encodeURIComponent(roomId)}/invite-link`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        body: JSON.stringify({ role, ttlMinutes }),
      }
    );
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'تعذر توليد رابط الدعوة');
      return null;
    }
    return data.inviteUrl;
  };

  const handleToggleLockRoom = async (room: LiveRoomInfo) => {
    const res = await fetch(
      `/api/classroom/rooms/${encodeURIComponent(room.id)}/settings`,
      {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        body: JSON.stringify({ isLocked: !room.isLocked }),
      }
    );
    if (res.ok) {
      showToast(!room.isLocked ? 'تم قفل الغرفة بنجاح' : 'تم فتح الغرفة للطلاب');
      await fetchLobbyData();
    }
  };

  const handleEndRoomForAll = async (roomId: string) => {
    await fetch(`/api/classroom/rooms/${encodeURIComponent(roomId)}/settings`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders,
      },
      body: JSON.stringify({ status: 'ended' }),
    });
    setActiveSession(null);
    showToast('تم إنهاء الحصة المباشرة وحفظ حالة الغرفة');
    await fetchLobbyData();
  };

  const handleDeleteRoom = async (roomId: string) => {
    const res = await fetch(`/api/classroom/rooms/${encodeURIComponent(roomId)}`, {
      method: 'DELETE',
      headers: authHeaders,
    });
    if (res.ok) {
      showToast('تم حذف الغرفة');
      await fetchLobbyData();
    }
  };

  if (activeSession) {
    return (
      <ClassroomShell
        session={activeSession.joinData}
        preJoinSettings={activeSession.preJoinSettings}
        onGenerateInviteLink={handleGenerateInviteLink}
        onToggleLockRoom={handleToggleLockRoom}
        onEndRoomForAll={handleEndRoomForAll}
        onLeave={() => {
          setActiveSession(null);
          fetchLobbyData();
        }}
      />
    );
  }

  return (
    <div className="relative">
      {toastMessage && (
        <div className="mb-4 px-4 py-2.5 rounded-xl bg-slate-900 text-white border border-emerald-500/60 text-xs font-cairo font-bold shadow-md">
          {toastMessage}
        </div>
      )}

      <RoomsLobbyView
        rooms={rooms}
        loading={loading}
        userRole={userRole}
        mediaMode={mediaMode}
        redisConnected={redisConnected}
        onCreateRoom={handleCreateRoom}
        onSelectRoomToJoin={(room) => {
          setJoinError(null);
          setActiveInviteToken(null);
          setPendingRoom(room);
        }}
        onJoinByCode={handleJoinByCode}
        onGenerateInviteLink={handleGenerateInviteLink}
        onToggleLockRoom={handleToggleLockRoom}
        onDeleteRoom={handleDeleteRoom}
      />

      {pendingRoom && (
        <PreJoinCheckModal
          room={pendingRoom}
          defaultDisplayName={currentUser?.name || 'طالب'}
          requiresGuestName={!currentUser || currentUser.role === 'visitor'}
          isJoining={isJoining}
          joinError={joinError}
          onConfirmJoin={handleConfirmPreJoin}
          onCancel={() => {
            setPendingRoom(null);
            setJoinError(null);
            onClearDeepLink?.();
          }}
        />
      )}
    </div>
  );
};
