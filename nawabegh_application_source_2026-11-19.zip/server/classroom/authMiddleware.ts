import jwt from 'jsonwebtoken';
import type { Request, Response, NextFunction } from 'express';
import { classroomConfig, canCreateOrConfigureRoom } from './config.ts';
import type { ClassroomRole, ClassroomTokenPayload } from '../../src/types/classroom.ts';

export interface InviteTokenPayload {
  type: 'room_invite';
  roomId: string;
  roomCode: string;
  grantedRole: ClassroomRole;
  issuedBy: string;
  iat?: number;
  exp?: number;
}

export function mapPlatformRoleToClassroomRole(platformRole?: string): ClassroomRole {
  const normalized = String(platformRole || '').trim().toLowerCase();
  if (normalized === 'admin' || normalized === 'supervisor') return 'admin';
  if (normalized === 'teacher') return 'teacher';
  if (normalized === 'secretary' || normalized === 'assistant') return 'assistant';
  return 'student';
}

export function signClassroomToken(
  payload: Omit<ClassroomTokenPayload, 'iat' | 'exp'>,
  expiresInSeconds = classroomConfig.defaultSessionTtlSeconds
): string {
  return jwt.sign(payload, classroomConfig.jwtSecret, {
    expiresIn: expiresInSeconds,
    issuer: 'alsharif-classroom',
  });
}

export function verifyClassroomToken(token: string): ClassroomTokenPayload {
  const decoded = jwt.verify(token, classroomConfig.jwtSecret, {
    issuer: 'alsharif-classroom',
  });
  if (!decoded || typeof decoded === 'string') {
    throw new Error('Invalid classroom token payload');
  }
  return decoded as ClassroomTokenPayload;
}

export function signRoomInviteToken(
  payload: Omit<InviteTokenPayload, 'type' | 'iat' | 'exp'>,
  expiresInSeconds = classroomConfig.defaultInviteTtlSeconds
): string {
  return jwt.sign(
    { ...payload, type: 'room_invite' },
    classroomConfig.jwtSecret,
    {
      expiresIn: expiresInSeconds,
      issuer: 'alsharif-classroom-invite',
    }
  );
}

export function verifyRoomInviteToken(token: string): InviteTokenPayload {
  const decoded = jwt.verify(token, classroomConfig.jwtSecret, {
    issuer: 'alsharif-classroom-invite',
  });
  if (!decoded || typeof decoded === 'string') {
    throw new Error('Invalid invite token');
  }
  const typed = decoded as InviteTokenPayload;
  if (typed.type !== 'room_invite') {
    throw new Error('Malformed invite token type');
  }
  return typed;
}

export interface ClassroomRequestActor {
  userId: string;
  userName: string;
  role: ClassroomRole;
  rawRole: string;
  fromToken: boolean;
}

export function extractClassroomActor(req: Request): ClassroomRequestActor | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    try {
      const payload = verifyClassroomToken(token);
      return {
        userId: payload.userId,
        userName: payload.userName,
        role: payload.role,
        rawRole: payload.role,
        fromToken: true,
      };
    } catch {
      return null;
    }
  }

  const headerRole = String(req.headers['x-user-role'] || '').trim().toLowerCase();
  const headerUserId = decodeURIComponent(String(req.headers['x-user-id'] || '')).trim();
  const headerUserName = decodeURIComponent(String(req.headers['x-user-name'] || '')).trim();

  if (!headerRole && !headerUserId) {
    return null;
  }

  return {
    userId: headerUserId || `guest-${Date.now()}`,
    userName: headerUserName || 'مستخدم المنصة',
    role: mapPlatformRoleToClassroomRole(headerRole),
    rawRole: headerRole || 'student',
    fromToken: false,
  };
}

export function requireClassroomActor(req: Request, res: Response, next: NextFunction) {
  const actor = extractClassroomActor(req);
  if (!actor) {
    return res.status(401).json({
      error: 'يجب تسجيل الدخول أو تقديم رمز جلسة صالح للوصول للفصل الافتراضي',
    });
  }
  (req as any).classroomActor = actor;
  next();
}

export function requireRoomModerator(req: Request, res: Response, next: NextFunction) {
  const actor = extractClassroomActor(req);
  if (!actor) {
    return res.status(401).json({ error: 'غير مصرح لك بالوصول — يرجى تسجيل الدخول' });
  }
  if (!canCreateOrConfigureRoom(actor.role)) {
    return res.status(403).json({
      error: 'هذه الصلاحية متاحة للمعلم أو المساعد أو المشرف العام فقط',
    });
  }
  (req as any).classroomActor = actor;
  next();
}
