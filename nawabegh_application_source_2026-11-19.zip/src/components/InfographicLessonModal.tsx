import React, { useState, useEffect } from 'react';
import { X, Layers, Save, Printer } from 'lucide-react';
import { Lesson, InfographicData, Language, Teacher } from '../types';
import { InfographicStudioPanel, TEMPLATE_CATALOG } from './InfographicStudioPanel';

interface InfographicLessonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveLesson: (lessonData: {
    id?: string;
    title: string;
    subject: string;
    grade: string;
    teacherId: string;
    teacherName: string;
    unit: string;
    description: string;
    format: 'infographic';
    durationOrPages: string;
    infographicData: InfographicData;
  }) => void;
  teachers: Teacher[];
  language: Language;
  initialLesson?: Lesson | null;
}

const DEFAULT_INFOGRAPHIC_DATA: InfographicData = {
  template: 'steps',
  themeColor: 'emerald',
  surfaceStyle: 'modern',
  columns: 2,
  showNumbers: true,
  summary:
    'ملخص بصري تفاعلي شامل يختصر أهم القوانين والمراحل التطبيقية في صورة بصرية مبسطة وسريعة الاستيعاب للطلاب.',
  sections: [
    {
      id: 'sec-1',
      title: 'المرحلة 1: الدالة والثوابت',
      description: 'مشتقة أي مقدار ثابت f(x) = c تساوي صفراً تماماً، لأن معدل التغير الأفقي منعدم.',
      value: "f'(x) = 0",
      color: '#059669',
      iconName: 'book',
    },
    {
      id: 'sec-2',
      title: 'المرحلة 2: مشتقة القوى والأسس',
      description: "نضرب المعامل في الأس ونطرح واحداً من الأس القديم: f'(x) = n · xⁿ⁻¹.",
      value: "f'(x) = n xⁿ⁻¹",
      color: '#2563eb',
      iconName: 'calc',
    },
    {
      id: 'sec-3',
      title: 'المرحلة 3: قاعدة السلسلة (Chain Rule)',
      description: 'مشتقة الدالة المركبة هي حاصل ضرب مشتقة الدالة الخارجية في مشتقة ما بداخل القوس.',
      value: 'dy/dx = (dy/du)·(du/dx)',
      color: '#d97706',
      iconName: 'zap',
    },
    {
      id: 'sec-4',
      title: 'المرحلة 4: التطبيقات العظمى والصغرى',
      description: "نساوي المشتقة بالصفر f'(x) = 0 لإيجاد النقاط الحرجة وتحديد القيم القصوى.",
      value: "f'(x) = 0",
      color: '#7c3aed',
      iconName: 'award',
    },
  ],
};

export const InfographicLessonModal: React.FC<InfographicLessonModalProps> = ({
  isOpen,
  onClose,
  onSaveLesson,
  teachers,
  language,
  initialLesson,
}) => {
  const isAr = language === 'ar';

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('الرياضيات');
  const [grade, setGrade] = useState('الصف الثالث الثانوي');
  const [teacherId, setTeacherId] = useState(teachers[0]?.id || '');
  const [unit, setUnit] = useState('الوحدة الأولى');
  const [infographicData, setInfographicData] = useState<InfographicData>(DEFAULT_INFOGRAPHIC_DATA);
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setValidationError(null);
    if (initialLesson) {
      setTitle(initialLesson.title || '');
      setSubject(initialLesson.subject || 'الرياضيات');
      setGrade(initialLesson.grade || 'الصف الثالث الثانوي');
      setTeacherId(initialLesson.teacherId || teachers[0]?.id || '');
      setUnit(initialLesson.unit || 'الوحدة الأولى');
      setInfographicData(
        initialLesson.infographicData
          ? {
              ...DEFAULT_INFOGRAPHIC_DATA,
              ...initialLesson.infographicData,
              sections: initialLesson.infographicData.sections?.length
                ? initialLesson.infographicData.sections
                : DEFAULT_INFOGRAPHIC_DATA.sections,
            }
          : DEFAULT_INFOGRAPHIC_DATA
      );
    } else {
      setTitle('انفوجرافيك: خارطة طريق قواعد الاشتقاق وتطبيقاتها الهندسية');
      setSubject('الرياضيات');
      setGrade('الصف الثالث الثانوي');
      setTeacherId(teachers[0]?.id || '');
      setUnit('الوحدة الأولى: التفاضل');
      setInfographicData(DEFAULT_INFOGRAPHIC_DATA);
    }
  }, [isOpen, initialLesson, teachers]);

  if (!isOpen) return null;

  const teacherName = teachers.find((t) => t.id === teacherId)?.name || 'مدرس المادة';

  const handleSave = () => {
    if (!title.trim()) {
      setValidationError(
        isAr ? 'يرجى كتابة عنوان لدرس الانفوجرافيك أولاً' : 'Please enter an infographic title'
      );
      return;
    }
    const tplLabel =
      TEMPLATE_CATALOG.find((t) => t.id === infographicData.template)?.labelAr || '';
    onSaveLesson({
      id: initialLesson?.id,
      title: title.trim(),
      subject,
      grade,
      teacherId,
      teacherName,
      unit: unit.trim() || 'الوحدة الأولى',
      description: infographicData.summary.trim() || title.trim(),
      format: 'infographic',
      durationOrPages: `انفوجرافيك ${tplLabel} (${infographicData.sections.length} محطات)`,
      infographicData: {
        ...infographicData,
        authorName: infographicData.authorName || teacherName,
      },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-5 bg-slate-950/80 backdrop-blur-xs font-cairo">
      <div className="w-full max-w-6xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[96dvh] h-[94dvh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 md:p-5 bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border-b border-emerald-800 text-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-base md:text-lg">
                  {isAr ? 'استوديو تصميم الانفوجرافيك التفاعلي المتكامل' : 'Pro Visual Infographic Studio'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40 font-mono-numbers">
                  17 Templates · 8 Themes
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 font-tajawal">
                {isAr
                  ? '17 قالباً (مخطط دائري SVG، أعمدة بيانية، قمع، عظمة السمكة، مخطط فين، بطاقات استذكار، خرائط ذهنية...) مع تصدير HTML و PDF'
                  : '17 visual chart & infographic templates with 8 dynamic themes and HTML/PDF export'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs transition-all shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>{isAr ? 'تصدير PDF' : 'Export PDF'}</span>
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-sm cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>
                {initialLesson
                  ? isAr
                    ? 'حفظ التعديلات'
                    : 'Update Lesson'
                  : isAr
                  ? 'حفظ ونشر الدرس'
                  : 'Save & Publish'}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-emerald-200 hover:text-white hover:bg-white/10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {validationError && (
          <div className="px-5 py-2 bg-rose-50 dark:bg-rose-950/60 border-b border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-bold shrink-0">
            {validationError}
          </div>
        )}

        {/* Lesson Metadata Strip */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2 text-xs shrink-0">
          <div className="lg:col-span-2">
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'عنوان درس الانفوجرافيك *' : 'Infographic Title *'}
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setValidationError(null);
              }}
              className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-semibold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'المادة' : 'Subject'}
            </label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              <option value="الرياضيات">الرياضيات</option>
              <option value="الفيزياء">الفيزياء</option>
              <option value="الكيمياء">الكيمياء</option>
              <option value="الأحياء">الأحياء</option>
              <option value="اللغة العربية">اللغة العربية</option>
              <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
              <option value="الحاسب الآلي">الحاسب الآلي</option>
              <option value="التربية الإسلامية">التربية الإسلامية</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'المرحلة' : 'Grade'}
            </label>
            <select
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              <option value="الصف الأول الثانوي">الصف الأول الثانوي</option>
              <option value="الصف الثاني الثانوي">الصف الثاني الثانوي</option>
              <option value="الصف الثالث الثانوي">الصف الثالث الثانوي</option>
              <option value="الشهادة الإعدادية">الشهادة الإعدادية</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'المعلم المشرف' : 'Teacher'}
            </label>
            <select
              value={teacherId}
              onChange={(e) => setTeacherId(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              {teachers.length === 0 ? (
                <option value="">{isAr ? '-- بدون معلم مسجل --' : '-- No Teacher --'}</option>
              ) : (
                teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))
              )}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'الوحدة / الفصل' : 'Unit'}
            </label>
            <input
              type="text"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-tajawal"
            />
          </div>
        </div>

        {/* Full 17-Template Studio */}
        <InfographicStudioPanel
          title={title}
          subject={subject}
          grade={grade}
          authorName={teacherName}
          data={infographicData}
          onChange={setInfographicData}
          onApplyPresetMeta={(meta) => setTitle(meta.title)}
          language={language}
          printableId="infographic-print-area"
        />
      </div>
    </div>
  );
};
