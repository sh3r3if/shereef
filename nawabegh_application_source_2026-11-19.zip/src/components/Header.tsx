import React from 'react';
import {
  GraduationCap,
  Globe,
  Moon,
  Sun,
  Smartphone,
  Search,
  Menu,
  ShieldCheck,
  User,
  Users2,
  HeartHandshake,
  LayoutDashboard,
  Eye,
  LogIn,
  LogOut,
  Bell,
  Home,
  BookOpen,
  Compass,
} from 'lucide-react';
import { AppNotification, Language, SchoolSettings, CurrentUser } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  settings: SchoolSettings;
  currentUser: CurrentUser;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  isDark: boolean;
  onToggleDark: () => void;
  onOpenMobileSim: () => void;
  onOpenSidebar: () => void;
  unreadNotifsCount: number;
  onOpenNotifications: () => void;
  notifications?: AppNotification[];
  activeTab: string;
  onTabChange: (tab: string) => void;
  isPublicView: boolean;
  onTogglePublicView: (isPublic: boolean) => void;
  onOpenAuth: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  currentUser,
  language,
  onLanguageChange,
  isDark,
  onToggleDark,
  onOpenMobileSim,
  onOpenSidebar,
  unreadNotifsCount,
  onOpenNotifications,
  notifications = [],
  activeTab,
  onTabChange,
  isPublicView,
  onTogglePublicView,
  onOpenAuth,
  onLogout,
}) => {
  const isAr = language === 'ar';
  const [notifDropdownOpen, setNotifDropdownOpen] = React.useState(false);

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return { label: isAr ? 'مدير عام' : 'Admin', color: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300' };
      case 'secretary':
        return { label: isAr ? 'سكرتارية' : 'Secretary', color: 'bg-pink-100 text-pink-800 dark:bg-pink-950 dark:text-pink-300' };
      case 'supervisor':
        return { label: isAr ? 'مشرف' : 'Supervisor', color: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300' };
      case 'teacher':
        return { label: isAr ? 'معلم' : 'Teacher', color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' };
      case 'student':
        return { label: isAr ? 'طالب' : 'Student', color: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' };
      case 'female_student':
        return { label: isAr ? 'طالبة' : 'Female Student', color: 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300' };
      case 'parent':
        return { label: isAr ? 'ولي أمر' : 'Parent', color: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300' };
      default:
        return { label: isAr ? 'زائر' : 'Visitor', color: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300' };
    }
  };

  const badge = getRoleBadge(currentUser.role);

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-100 dark:border-slate-800 transition-colors">
      <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-2 sm:gap-4 px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5">
        
        {/* Zone 1: Brand Wordmark (Mortarboard in emerald circle + منصة الشريف) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0 min-w-0">
          {!isPublicView && (
            <button
              onClick={onOpenSidebar}
              className="lg:hidden min-w-[40px] min-h-[40px] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
              title={isAr ? 'فتح القائمة' : 'Open menu'}
              aria-label="Toggle menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <button
            onClick={() => onTogglePublicView(true)}
            className="flex items-center gap-2 sm:gap-2.5 text-right font-cairo font-black text-slate-900 dark:text-white tracking-tight hover:opacity-90 transition-opacity"
          >
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#0c3d36] text-white flex items-center justify-center shadow-xs shrink-0">
              <GraduationCap className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <span className="text-base sm:text-xl font-cairo font-black tracking-tight whitespace-nowrap">
              {isAr
                ? settings?.schoolName && settings.schoolName !== 'تعلّمنوفا'
                  ? settings.schoolName
                  : 'منصة الشريف'
                : settings?.schoolNameEn && !settings.schoolNameEn.includes('LearnNova')
                ? settings.schoolNameEn
                : 'Al-Sharif Platform'}
            </span>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Matching Screenshot: الرئيسية, الدورات, مسارات التعلم, المدربون) */}
        <nav className="hidden lg:flex items-center gap-5 xl:gap-7 text-sm font-cairo font-semibold text-slate-600 dark:text-slate-300">
          <button
            onClick={() => onTogglePublicView(true)}
            className={`inline-flex items-center gap-1.5 whitespace-nowrap transition-colors relative py-1 ${
              isPublicView
                ? 'text-[#0c3d36] dark:text-emerald-400 font-bold'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Home className="w-4 h-4 shrink-0" />
            <span>{isAr ? 'الرئيسية' : 'Home'}</span>
            {isPublicView && (
              <span className="absolute bottom-0 inset-x-0 h-0.5 bg-[#0c3d36] dark:bg-emerald-400 rounded-full" />
            )}
          </button>

          <a
            href="#courses-section"
            onClick={() => onTogglePublicView(true)}
            className="inline-flex items-center gap-1.5 whitespace-nowrap hover:text-[#0c3d36] dark:hover:text-emerald-400 transition-colors"
          >
            <BookOpen className="w-4 h-4 shrink-0" />
            <span>{isAr ? 'الدورات' : 'Courses'}</span>
          </a>

          <a
            href="#courses-section"
            onClick={() => onTogglePublicView(true)}
            className="inline-flex items-center gap-1.5 whitespace-nowrap hover:text-[#0c3d36] dark:hover:text-emerald-400 transition-colors"
          >
            <Compass className="w-4 h-4 shrink-0" />
            <span>{isAr ? 'مسارات التعلم' : 'Learning Tracks'}</span>
          </a>

          <button
            onClick={() => {
              if (currentUser.role === 'admin' || currentUser.role === 'supervisor') {
                onTogglePublicView(false);
                onTabChange('teachers');
              } else {
                onTogglePublicView(true);
              }
            }}
            className="inline-flex items-center gap-1.5 whitespace-nowrap hover:text-[#0c3d36] dark:hover:text-emerald-400 transition-colors"
          >
            <Users2 className="w-4 h-4 shrink-0" />
            <span>{isAr ? 'المدربون' : 'Instructors'}</span>
          </button>

          {/* Quick toggle to Dashboard if user has access */}
          {currentUser.role !== 'visitor' && (
            <button
              onClick={() => onTogglePublicView(false)}
              className={`inline-flex items-center gap-1.5 whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                !isPublicView
                  ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                  : 'text-slate-600 dark:text-slate-300 hover:text-[#0c3d36] dark:hover:text-emerald-400 hover:bg-slate-50 dark:hover:bg-slate-800/70'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5 shrink-0" />
              <span>
                {currentUser.role === 'admin'
                  ? isAr
                    ? 'لوحة تحكم الأدمن'
                    : 'Admin Dashboard'
                  : isAr
                  ? 'بوابتي التعليمية'
                  : 'My Portal'}
              </span>
            </button>
          )}
        </nav>

        {/* Zone 3: Search, EN, Sign In, and "ابدأ مجاناً" CTA button */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 lg:gap-3 shrink-0">
          {/* Quick Portal Button on Mobile/Tablet when logged in & viewing public site */}
          {currentUser.role !== 'visitor' && isPublicView && (
            <button
              onClick={() => onTogglePublicView(false)}
              className="lg:hidden inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-cairo font-bold text-[11px] border border-emerald-200 dark:border-emerald-800 whitespace-nowrap"
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>{currentUser.role === 'admin' ? (isAr ? 'لوحة التحكم' : 'Dashboard') : isAr ? 'بوابتي' : 'Portal'}</span>
            </button>
          )}

          {/* Search Icon */}
          <button
            onClick={() => {
              onTogglePublicView(true);
              const target = document.getElementById('courses-section');
              target?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hidden sm:flex p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg transition-colors"
            title={isAr ? 'بحث' : 'Search'}
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Language Switcher */}
          <button
            onClick={() => onLanguageChange(isAr ? 'en' : 'ar')}
            className="flex items-center gap-1 px-1.5 py-1.5 text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:text-slate-900 transition-colors"
            title={isAr ? 'Switch to English' : 'التحويل للعربية'}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isAr ? 'EN' : 'عربي'}</span>
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={onToggleDark}
            className="p-1.5 sm:p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors"
            title={isDark ? 'الوضع النهاري' : 'الوضع الليلي'}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Authentication & User State: Sign In vs Sign Out */}
          {currentUser.role === 'visitor' ? (
            /* Logged Out: Show "تسجيل الدخول" and "ابدأ مجاناً" */
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] sm:text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 hover:text-[#0c3d36] dark:hover:text-emerald-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all cursor-pointer whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{isAr ? 'تسجيل الدخول' : 'Sign In'}</span>
              </button>

              <button
                onClick={onOpenAuth}
                className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0c3d36] hover:bg-[#092e29] text-white font-cairo font-bold text-xs sm:text-sm shadow-xs transition-all hover:scale-105 cursor-pointer whitespace-nowrap"
              >
                <span>{isAr ? 'ابدأ مجاناً' : 'Get Started'}</span>
              </button>
            </div>
          ) : (
            /* Logged In: Show Notification Bell, User Info and "تسجيل الخروج" */
            <div className="flex items-center gap-1.5 sm:gap-3">
              {/* Live Notification Bell */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setNotifDropdownOpen((prev) => !prev)}
                  title={isAr ? 'الإشعارات الدورية والتنبيهات' : 'Notifications'}
                  className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Bell className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                  {unreadNotifsCount > 0 && (
                    <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-600 text-white text-[10px] font-cairo font-black flex items-center justify-center shadow-xs">
                      {unreadNotifsCount > 99 ? '99+' : unreadNotifsCount}
                    </span>
                  )}
                </button>

                {notifDropdownOpen && (
                  <div
                    className={`absolute ${
                      isAr ? 'left-0 sm:left-auto sm:right-0' : 'right-0'
                    } mt-2 w-80 max-w-[90vw] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl z-50 overflow-hidden`}
                  >
                    <div className="px-4 py-3 bg-emerald-900 text-white flex items-center justify-between">
                      <span className="font-cairo font-bold text-xs">
                        {isAr ? 'أحدث الإشعارات والتنبيهات' : 'Latest Notifications'}
                      </span>
                      <span className="text-[11px] font-mono-numbers bg-white/15 px-2 py-0.5 rounded-full">
                        {unreadNotifsCount} {isAr ? 'جديد' : 'unread'}
                      </span>
                    </div>

                    <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                      {notifications.length === 0 ? (
                        <div className="p-5 text-center text-xs text-slate-500 font-tajawal">
                          {isAr ? 'لا توجد إشعارات حالياً' : 'No notifications yet'}
                        </div>
                      ) : (
                        notifications.slice(0, 6).map((n) => (
                          <button
                            key={n.id}
                            type="button"
                            onClick={() => {
                              setNotifDropdownOpen(false);
                              if (n.relatedType === 'lesson') {
                                onTogglePublicView(false);
                                onTabChange('lessons');
                              } else if (n.relatedType === 'assignment') {
                                onTogglePublicView(false);
                                onTabChange('assignments');
                              } else if (
                                n.relatedType === 'quiz_weekly' ||
                                n.relatedType === 'quiz_monthly'
                              ) {
                                onTogglePublicView(false);
                                onTabChange('quizzes');
                              } else {
                                onOpenNotifications();
                              }
                            }}
                            className={`w-full text-right p-3 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer ${
                              !n.read ? 'bg-emerald-50/50 dark:bg-emerald-950/20' : ''
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2 mb-0.5">
                              <span className="font-cairo font-bold text-xs text-slate-900 dark:text-white truncate">
                                {n.title}
                              </span>
                              {!n.read && (
                                <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
                              )}
                            </div>
                            <p className="text-[11px] text-slate-600 dark:text-slate-300 font-tajawal line-clamp-2">
                              {n.message}
                            </p>
                            <span className="block text-[10px] text-slate-400 font-mono-numbers mt-1">
                              {n.createdAt}
                            </span>
                          </button>
                        ))
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setNotifDropdownOpen(false);
                        onOpenNotifications();
                      }}
                      className="w-full py-2.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-emerald-700 dark:text-emerald-300 font-cairo font-bold text-xs border-t border-slate-200 dark:border-slate-700 cursor-pointer"
                    >
                      {isAr ? 'فتح مركز الإشعارات بالكامل' : 'View All Notifications'}
                    </button>
                  </div>
                )}
              </div>

              {/* User Profile Badge (Clickable to switch accounts/roles) */}
              <button
                onClick={onOpenAuth}
                title={isAr ? 'تبديل الحساب أو استعراض الصلاحيات' : 'Switch account / view profile'}
                className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-all cursor-pointer text-right"
              >
                <div className="w-6 h-6 rounded-lg bg-emerald-700 text-white flex items-center justify-center text-[11px] font-bold font-cairo shrink-0">
                  {currentUser.name.slice(0, 1)}
                </div>
                <div className="hidden sm:block text-right leading-tight max-w-[130px] truncate">
                  <span className="block text-xs font-cairo font-bold text-slate-800 dark:text-slate-200 truncate">
                    {currentUser.name.split(' (')[0]}
                  </span>
                  <span className={`inline-block text-[10px] font-bold px-1 rounded-sm ${badge.color}`}>
                    {badge.label}
                  </span>
                </div>
              </button>

              {/* Prominent "تسجيل الخروج" Button */}
              <button
                onClick={onLogout}
                title={isAr ? 'تسجيل الخروج من المنظومة' : 'Sign Out'}
                className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 font-cairo font-bold text-[11px] sm:text-xs shadow-xs transition-all cursor-pointer whitespace-nowrap"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400 shrink-0" />
                <span className="hidden xs:inline sm:inline">{isAr ? 'خروج' : 'Out'}</span>
                <span className="hidden md:inline">{isAr ? 'من الحساب' : ''}</span>
              </button>
            </div>
          )}

          {/* PWA Install & Browser Push Notifications Button */}
          <PWAInstallButton language={language} currentUser={currentUser} />

          {/* Mobile Simulator CTA */}
          <button
            onClick={onOpenMobileSim}
            className="hidden sm:flex items-center gap-1 p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 text-xs font-cairo font-bold transition-colors"
            title={isAr ? 'معاينة تطبيق الموبايل' : 'Mobile Preview'}
          >
            <Smartphone className="w-4 h-4 text-emerald-600" />
          </button>
        </div>
      </div>
    </header>
  );
};
