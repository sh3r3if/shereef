import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  GraduationCap,
  Search,
  Play,
  ArrowUpRight,
  Star,
  Clock,
  BookOpen,
  Sparkles,
  Trophy,
  CheckCircle2,
  Calendar,
  Layers,
  Code2,
  TrendingUp,
  Megaphone,
  Palette,
  Briefcase,
  Users2,
  Award,
  ChevronDown,
  Quote,
  ShieldCheck,
  Send,
  ExternalLink,
  Database,
  X,
  Loader2,
  FileText,
  Video,
  HelpCircle,
  UserCheck,
  Edit3,
  Upload,
  Image as ImageIcon,
  Link as LinkIcon,
  Save,
  RotateCcw,
} from 'lucide-react';
import {
  Lesson,
  Teacher,
  Student,
  Certificate,
  TimetableSlot,
  FaqItem,
  SchoolSettings,
  Language,
  Quiz,
  Assignment,
  CurrentUser,
  HeroSliderConfig,
  DEFAULT_HERO_SLIDER_CONFIG,
} from '../types';

interface PublicSearchResponse {
  query: string;
  subject: string;
  lessons: Lesson[];
  teachers: Teacher[];
  quizzes: Quiz[];
  assignments: Assignment[];
  timetableSlots: TimetableSlot[];
  certificates: Certificate[];
  faqs: FaqItem[];
  availableSubjects: { subject: string; lessonCount: number }[];
  totalMatches: number;
  databaseTotals: {
    lessons: number;
    teachers: number;
    students: number;
    quizzes: number;
    assignments: number;
    timetableSlots: number;
    certificates: number;
  };
}

interface PublicWebsiteProps {
  settings: SchoolSettings;
  lessons: Lesson[];
  teachers: Teacher[];
  students: Student[];
  certificates: Certificate[];
  timetableSlots: TimetableSlot[];
  faqs: FaqItem[];
  currentUser?: CurrentUser;
  onUpdateSettings?: (newSettings: SchoolSettings) => void;
  onNavigateTab?: (tab: string) => void;
  onOpenAuth: () => void;
  onOpenLessonDetails: (lesson: Lesson) => void;
  onOpenCertificateDetails: (cert: Certificate) => void;
  language: Language;
}

const AnimatedStatValue: React.FC<{ value: string | number }> = ({ value }) => {
  const [displayValue, setDisplayValue] = useState<string>(String(value));
  const containerRef = useRef<HTMLSpanElement | null>(null);
  const hasAnimatedRef = useRef(false);

  useEffect(() => {
    const rawStr = String(value ?? '').trim();
    const match = rawStr.match(/^([^0-9]*)([0-9]+(?:[.,][0-9]+)*)(.*)$/);
    if (!match) {
      setDisplayValue(rawStr);
      return;
    }

    const prefix = match[1] || '';
    const numPart = match[2].replace(/,/g, '');
    const suffix = match[3] || '';
    const targetNum = parseFloat(numPart);

    if (isNaN(targetNum) || targetNum === 0) {
      setDisplayValue(rawStr);
      return;
    }

    const isDecimal = numPart.includes('.');
    const decimals = isDecimal ? (numPart.split('.')[1]?.length || 1) : 0;

    const runAnimation = () => {
      const duration = 1400;
      const startTime = performance.now();

      const step = (now: number) => {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        // Ease-out quartic curve
        const eased = 1 - Math.pow(1 - progress, 4);
        const current = targetNum * eased;

        const formatted = isDecimal
          ? current.toFixed(decimals)
          : Math.round(current).toLocaleString('en-US');

        setDisplayValue(`${prefix}${formatted}${suffix}`);

        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          setDisplayValue(rawStr);
        }
      };

      requestAnimationFrame(step);
    };

    if (hasAnimatedRef.current) {
      runAnimation();
      return;
    }

    const el = containerRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      hasAnimatedRef.current = true;
      runAnimation();
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !hasAnimatedRef.current) {
          hasAnimatedRef.current = true;
          runAnimation();
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);

  return (
    <span ref={containerRef} className="tabular-nums inline-block">
      {displayValue}
    </span>
  );
};

export const PublicWebsite: React.FC<PublicWebsiteProps> = ({
  settings,
  lessons,
  teachers,
  students,
  certificates,
  timetableSlots,
  faqs,
  currentUser,
  onUpdateSettings,
  onNavigateTab,
  onOpenAuth,
  onOpenLessonDetails,
  onOpenCertificateDetails,
  language,
}) => {
  const isAr = language === 'ar';
  const isAdminUser = Boolean(
    currentUser && (currentUser.role === 'admin' || currentUser.isSuperAdmin)
  );

  const slider: HeroSliderConfig = {
    ...DEFAULT_HERO_SLIDER_CONFIG,
    ...(settings.heroSlider || {}),
  };

  // Admin Slider Editor Modal State
  const [isSliderEditorOpen, setIsSliderEditorOpen] = useState(false);
  const [draftSlider, setDraftSlider] = useState<HeroSliderConfig>(slider);
  const [sliderSavedToast, setSliderSavedToast] = useState(false);
  const sliderFileInputRef = useRef<HTMLInputElement | null>(null);
  const whyFileInputRef = useRef<HTMLInputElement | null>(null);
  const testimonialFileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setDraftSlider({
      ...DEFAULT_HERO_SLIDER_CONFIG,
      ...(settings.heroSlider || {}),
    });
  }, [settings.heroSlider]);

  const handleSliderImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setDraftSlider((prev) => ({ ...prev, sliderImageUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleWhyImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setDraftSlider((prev) => ({ ...prev, whyImageUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleTestimonialAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setDraftSlider((prev) => ({ ...prev, testimonialAvatarUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveSliderConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    const updatedSettings: SchoolSettings = {
      ...settings,
      heroSlider: draftSlider,
    };
    if (onUpdateSettings) {
      onUpdateSettings(updatedSettings);
    } else {
      await fetch('/api/hero-slider', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(draftSlider),
      }).catch(console.warn);
    }
    setSliderSavedToast(true);
    setTimeout(() => {
      setSliderSavedToast(false);
      setIsSliderEditorOpen(false);
    }, 1200);
  };

  const handleSliderButtonClick = (link: string) => {
    const targetLink = (link || '').trim();
    if (!targetLink || targetLink === '#courses-section') {
      document.getElementById('courses-section')?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    if (targetLink === '#auth' || targetLink === 'portal' || targetLink === '#login') {
      onOpenAuth();
      return;
    }
    if (targetLink.startsWith('#tab:')) {
      const tabName = targetLink.replace('#tab:', '').trim();
      if (onNavigateTab && tabName) {
        onNavigateTab(tabName);
      } else {
        onOpenAuth();
      }
      return;
    }
    if (targetLink.startsWith('#')) {
      const el = document.getElementById(targetLink.slice(1));
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else {
        onOpenAuth();
      }
      return;
    }
    window.location.href = targetLink;
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedDay, setSelectedDay] = useState<string>('all');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Live Database Search State for Hero Slider Search Box
  const [dbSearchData, setDbSearchData] = useState<PublicSearchResponse | null>(null);
  const [isSearchingDb, setIsSearchingDb] = useState(false);
  const [isSearchPanelOpen, setIsSearchPanelOpen] = useState(false);
  const [activeSearchTab, setActiveSearchTab] = useState<
    'all' | 'lessons' | 'teachers' | 'quizzes' | 'timetable' | 'certificates'
  >('all');
  const searchContainerRef = useRef<HTMLDivElement | null>(null);

  const executeDatabaseSearch = useCallback(
    async (q: string, subj: string) => {
      setIsSearchingDb(true);
      try {
        const params = new URLSearchParams();
        if (q.trim()) params.set('q', q.trim());
        if (subj && subj !== 'all') params.set('subject', subj);
        const res = await fetch(`/api/public-search?${params.toString()}`);
        if (res.ok) {
          const data: PublicSearchResponse = await res.json();
          setDbSearchData(data);
        }
      } catch (err) {
        console.error('Database search error:', err);
      } finally {
        setIsSearchingDb(false);
      }
    },
    []
  );

  // Run live database search on mount, when query/subject changes, or when props update from DB
  useEffect(() => {
    const timer = setTimeout(() => {
      executeDatabaseSearch(searchQuery, selectedSubject);
    }, 180);
    return () => clearTimeout(timer);
  }, [searchQuery, selectedSubject, lessons.length, teachers.length, executeDatabaseSearch]);

  // Close search dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setIsSearchPanelOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Top students
  const topStudents = students.filter((s) => s.status === 'top' || s.overallScore >= 90);

  // Filter lessons directly from DB search response (with local prop fallback while loading)
  const filteredLessons = dbSearchData
    ? dbSearchData.lessons
    : lessons.filter((les) => {
        const matchesSubject = selectedSubject === 'all' || les.subject === selectedSubject;
        const matchesSearch =
          les.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          les.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (les.teacherName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
          (les.grade || '').toLowerCase().includes(searchQuery.toLowerCase());
        return matchesSubject && matchesSearch;
      });

  const dbSubjects = dbSearchData?.availableSubjects || [];

  const handleHeroSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSearchPanelOpen(true);
    executeDatabaseSearch(searchQuery, selectedSubject);
  };

  const daysList = [
    { key: 'all', ar: 'كافة الأيام' },
    { key: 'Saturday', ar: 'السبت' },
    { key: 'Sunday', ar: 'الأحد' },
    { key: 'Monday', ar: 'الاثنين' },
    { key: 'Tuesday', ar: 'الثلاثاء' },
    { key: 'Wednesday', ar: 'الأربعاء' },
    { key: 'Thursday', ar: 'الخميس' },
  ];

  const filteredSlots = timetableSlots.filter((slot) => {
    if (selectedDay === 'all') return true;
    return slot.day === selectedDay;
  });

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterSubscribed(true);
    setTimeout(() => {
      setNewsletterEmail('');
      setNewsletterSubscribed(false);
    }, 4000);
  };

  // Interactive 3D Hero Tilt & Scroll Progress State
  const [heroTilt, setHeroTilt] = useState<{ rx: number; ry: number; px: number; py: number }>({
    rx: 0,
    ry: 0,
    px: 0,
    py: 0,
  });
  const [scrollProgress, setScrollProgress] = useState(0);
  const homepageRootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const docHeight =
        document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (docHeight > 0) {
        setScrollProgress(Math.min(100, Math.max(0, (scrollTop / docHeight) * 100)));
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Scroll-Reveal IntersectionObserver for homepage sections
  useEffect(() => {
    const rootEl = homepageRootRef.current;
    if (!rootEl) return;
    const sections = rootEl.querySelectorAll('.hp-reveal-section');
    if (typeof IntersectionObserver === 'undefined') {
      sections.forEach((s) => s.classList.add('hp-is-visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('hp-is-visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );

    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, [filteredLessons.length, dbSubjects.length]);

  const handleHeroMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setHeroTilt({
      rx: -y * 9,
      ry: x * 9,
      px: x * 14,
      py: y * 14,
    });
  };

  const handleHeroMouseLeave = () => {
    setHeroTilt({ rx: 0, ry: 0, px: 0, py: 0 });
  };

  return (
    <div
      ref={homepageRootRef}
      className="relative overflow-x-clip space-y-10 sm:space-y-16 lg:space-y-24 pb-12 sm:pb-16 bg-[#fbfcfb] text-slate-900 dark:bg-slate-950 dark:text-slate-100 font-tajawal transition-colors"
    >
      {/* Top Interactive Reading / Scroll Progress Bar */}
      <div className="fixed top-0 inset-x-0 h-1 z-50 pointer-events-none bg-transparent">
        <div
          className="h-full bg-gradient-to-l from-[#0c3d36] via-emerald-500 to-amber-400 transition-transform duration-150 ease-out origin-right shadow-[0_0_12px_rgba(16,185,129,0.65)]"
          style={{ transform: `scaleX(${scrollProgress / 100})` }}
        />
      </div>

      {/* 1. HERO SECTION (Customizable by Admin + Live Database Search in Slider) */}
      <section className="relative pt-2 sm:pt-8 pb-8 sm:pb-12 overflow-visible">
        {/* Animated Aurora & Decorative Background Orbs */}
        <div className="absolute top-6 left-1/2 -translate-x-1/2 w-[min(740px,100vw)] h-[380px] sm:h-[520px] bg-gradient-to-tr from-emerald-200/45 via-teal-100/35 to-amber-100/30 dark:from-emerald-950/35 dark:via-teal-900/20 dark:to-amber-950/15 rounded-full blur-3xl -z-10 pointer-events-none hp-animate-aurora" />
        <div className="absolute top-8 left-12 w-16 h-16 rounded-full border-4 border-dashed border-emerald-300/60 dark:border-emerald-800/40 -z-10 pointer-events-none hidden lg:block hp-animate-ring-spin" />
        <div className="absolute bottom-6 right-10 w-24 h-24 rounded-full bg-amber-300/20 dark:bg-amber-500/10 blur-2xl -z-10 pointer-events-none hp-animate-float-delayed" />

        {/* Admin Quick-Edit Slider Bar */}
        {isAdminUser && (
          <div className="mb-5 p-3 rounded-2xl bg-emerald-950/95 text-white border border-emerald-700/60 shadow-lg flex flex-wrap items-center justify-between gap-3 hp-hero-enter">
            <div className="flex items-center gap-2 text-xs font-cairo font-bold">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                {isAr
                  ? 'وضع الأدمن: يمكنك تعديل نصوص السلايدر، نصوص وروابط الأزرار، وصورة السلايدر مباشرة'
                  : 'Admin Mode: Customize slider texts, button texts & links, and slider image'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs transition-all cursor-pointer shadow-xs hp-btn-shimmer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل السلايدر والروابط والصورة' : 'Edit Hero Slider'}</span>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Right Column: Copy & Search Action Deck */}
          <div className="lg:col-span-7 space-y-6 text-right">
            {/* Mint Kicker Pill */}
            <div className="hp-hero-enter inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50/90 dark:bg-emerald-950/80 border border-emerald-200/80 dark:border-emerald-800/70 text-emerald-800 dark:text-emerald-300 text-xs font-cairo font-bold shadow-2xs hover:shadow-md hover:scale-[1.02] transition-all">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 animate-spin [animation-duration:8s]" />
              <span>{isAr ? slider.badgeTextAr : slider.badgeTextEn}</span>
            </div>

            {/* Giant Bold Headline with Animated Gradient Accent */}
            <h1 className="hp-hero-enter hp-delay-100 text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-cairo font-black text-slate-900 dark:text-white tracking-tight leading-[1.2] text-balance">
              {isAr ? (
                <>
                  {slider.headlineLine1Ar}
                  <br />
                  <span className="hp-text-gradient-animated inline-block mt-1">
                    {slider.headlineLine2Ar}
                  </span>
                </>
              ) : (
                <>
                  {slider.headlineLine1En}{' '}
                  <span className="hp-text-gradient-animated inline-block">
                    {slider.headlineLine2En}
                  </span>
                </>
              )}
            </h1>

            {/* Subtitle */}
            <p className="hp-hero-enter hp-delay-200 max-w-xl text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed font-tajawal">
              {isAr ? slider.subtitleAr : slider.subtitleEn}
            </p>

            {/* LIVE DATABASE SEARCH BAR IN HERO SLIDER */}
            <div ref={searchContainerRef} className="hp-hero-enter hp-delay-300 relative max-w-xl z-30 space-y-2.5">
              <form
                onSubmit={handleHeroSearchSubmit}
                className="relative bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border-2 border-slate-200 dark:border-slate-800 focus-within:border-emerald-600 dark:focus-within:border-emerald-500 focus-within:shadow-[0_12px_32px_-8px_rgba(16,185,129,0.28)] shadow-md p-1.5 flex items-center gap-2 transition-all duration-300"
              >
                <Search className="w-5 h-5 text-emerald-700 dark:text-emerald-400 mr-2 shrink-0 transition-transform duration-300 group-focus-within:scale-110" />
                <input
                  type="text"
                  value={searchQuery}
                  onFocus={() => setIsSearchPanelOpen(true)}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSearchPanelOpen(true);
                  }}
                  placeholder={isAr ? slider.searchPlaceholderAr : slider.searchPlaceholderEn}
                  className="flex-1 bg-transparent px-2 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden font-tajawal"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      executeDatabaseSearch('', selectedSubject);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title={isAr ? 'مسح البحث' : 'Clear search'}
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="submit"
                  className="hp-btn-shimmer px-5 py-2.5 rounded-xl bg-[#0c3d36] hover:bg-[#092e29] text-white text-xs sm:text-sm font-cairo font-bold transition-all duration-200 hover:scale-[1.03] active:scale-95 shrink-0 shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {isSearchingDb ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Search className="w-3.5 h-3.5" />
                  )}
                  <span>{isAr ? slider.searchButtonTextAr : slider.searchButtonTextEn}</span>
                </button>
              </form>

              {/* Dynamic Database Quick-Filter Subject Pills */}
              <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-cairo">
                <span className="inline-flex items-center gap-1 text-slate-500 dark:text-slate-400 font-bold ml-1">
                  <Database className="w-3 h-3 text-emerald-600" />
                  {isAr ? 'بحث سريع من الداتا بيز:' : 'Live DB Filters:'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedSubject('all');
                    setIsSearchPanelOpen(true);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                    selectedSubject === 'all'
                      ? 'bg-[#0c3d36] text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/50'
                  }`}
                >
                  {isAr
                    ? `الكل (${dbSearchData?.databaseTotals.lessons ?? lessons.length})`
                    : `All (${dbSearchData?.databaseTotals.lessons ?? lessons.length})`}
                </button>
                {dbSubjects.map((item) => (
                  <button
                    key={item.subject}
                    type="button"
                    onClick={() => {
                      setSelectedSubject(item.subject);
                      setIsSearchPanelOpen(true);
                    }}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                      selectedSubject === item.subject
                        ? 'bg-emerald-600 text-white'
                        : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-emerald-500'
                    }`}
                  >
                    {item.subject} ({item.lessonCount})
                  </button>
                ))}
              </div>

              {/* LIVE DATABASE SEARCH RESULTS DROPDOWN PANEL */}
              {isSearchPanelOpen && (
                <div className="absolute right-0 left-0 top-full mt-2 rounded-2xl bg-white dark:bg-slate-900 border-2 border-emerald-600/30 dark:border-emerald-500/30 shadow-2xl overflow-hidden z-50">
                  {/* Panel Header */}
                  <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="text-xs font-cairo font-bold text-slate-800 dark:text-slate-100">
                        {isAr
                          ? 'نتائج البحث المباشر من قاعدة بيانات منصة الشريف'
                          : 'Live Al-Sharif Database Search Results'}
                      </span>
                      {dbSearchData && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-cairo font-bold">
                          {dbSearchData.totalMatches} {isAr ? 'نتيجة مطابقة' : 'matches'}
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsSearchPanelOpen(false)}
                      className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Category Filter Tabs inside Search Panel */}
                  {dbSearchData && (
                    <div className="px-4 py-2 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[11px] font-cairo font-bold">
                      {[
                        {
                          id: 'all',
                          label: isAr ? 'الكل' : 'All',
                          count: dbSearchData.totalMatches,
                        },
                        {
                          id: 'lessons',
                          label: isAr ? 'الدروس والمذكرات' : 'Lessons',
                          count: dbSearchData.lessons.length,
                        },
                        {
                          id: 'teachers',
                          label: isAr ? 'المعلمون' : 'Teachers',
                          count: dbSearchData.teachers.length,
                        },
                        {
                          id: 'quizzes',
                          label: isAr ? 'الاختبارات' : 'Quizzes',
                          count: dbSearchData.quizzes.length,
                        },
                        {
                          id: 'timetable',
                          label: isAr ? 'جدول الحصص' : 'Timetable',
                          count: dbSearchData.timetableSlots.length,
                        },
                        {
                          id: 'certificates',
                          label: isAr ? 'الشهادات' : 'Certificates',
                          count: dbSearchData.certificates.length,
                        },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setActiveSearchTab(tab.id as any)}
                          className={`px-2.5 py-1 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                            activeSearchTab === tab.id
                              ? 'bg-[#0c3d36] text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                          }`}
                        >
                          {tab.label} ({tab.count})
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Results Body */}
                  <div className="max-h-96 overflow-y-auto p-3 space-y-4 divide-y divide-slate-100 dark:divide-slate-800">
                    {isSearchingDb && !dbSearchData ? (
                      <div className="py-8 text-center space-y-2">
                        <Loader2 className="w-6 h-6 text-emerald-600 animate-spin mx-auto" />
                        <p className="text-xs text-slate-500 font-tajawal">
                          {isAr
                            ? 'جاري البحث في قاعدة بيانات منصة الشريف...'
                            : 'Querying Al-Sharif database...'}
                        </p>
                      </div>
                    ) : !dbSearchData || dbSearchData.totalMatches === 0 ? (
                      <div className="py-6 px-4 text-center space-y-2.5">
                        <BookOpen className="w-8 h-8 text-emerald-600/70 mx-auto" />
                        <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white">
                          {isAr
                            ? 'لا توجد نتائج مطابقة في قاعدة البيانات حالياً'
                            : 'No matching records found in the database'}
                        </h4>
                        <p className="text-xs text-slate-500 font-tajawal max-w-md mx-auto">
                          {searchQuery
                            ? isAr
                              ? `لم يتم العثور على نتائج تطابق "${searchQuery}" في قاعدة البيانات. يمكنك تجربة كلمة أخرى أو إضافة محتوى جديد من البوابة.`
                              : `No database records match "${searchQuery}".`
                            : isAr
                              ? 'قاعدة البيانات متصلة وجاهزة، ولكن لم يتم إضافة دروس أو مقررات بعد. سجّل الدخول لإضافة الدروس وستظهر فوراً في نتائج البحث.'
                              : 'Database is connected, but no lessons have been added yet.'}
                        </p>
                        <div className="pt-1 flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setIsSearchPanelOpen(false);
                              onOpenAuth();
                            }}
                            className="px-4 py-2 rounded-xl bg-[#0c3d36] hover:bg-[#092e29] text-white text-xs font-cairo font-bold cursor-pointer"
                          >
                            {isAr ? 'دخول البوابة لإضافة محتوى' : 'Sign In to Add Content'}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        {/* 1. LESSONS FROM DB */}
                        {(activeSearchTab === 'all' || activeSearchTab === 'lessons') &&
                          dbSearchData.lessons.length > 0 && (
                            <div className="pt-2 first:pt-0 space-y-2">
                              <div className="flex items-center justify-between px-1">
                                <span className="text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                                  <Video className="w-3.5 h-3.5" />
                                  {isAr
                                    ? `الدروس والمذكرات (${dbSearchData.lessons.length})`
                                    : `Lessons (${dbSearchData.lessons.length})`}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setIsSearchPanelOpen(false);
                                    document
                                      .getElementById('courses-section')
                                      ?.scrollIntoView({ behavior: 'smooth' });
                                  }}
                                  className="text-[11px] font-cairo font-bold text-slate-500 hover:text-emerald-700 cursor-pointer"
                                >
                                  {isAr ? 'عرض في قسم الدورات ↓' : 'View in section ↓'}
                                </button>
                              </div>
                              <div className="space-y-1.5">
                                {dbSearchData.lessons.slice(0, 6).map((lesson) => (
                                  <button
                                    key={lesson.id}
                                    type="button"
                                    onClick={() => {
                                      setIsSearchPanelOpen(false);
                                      onOpenLessonDetails(lesson);
                                    }}
                                    className="w-full p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50/70 dark:bg-slate-800/60 dark:hover:bg-emerald-950/40 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-3 text-right transition-colors cursor-pointer"
                                  >
                                    <div className="flex items-center gap-3 min-w-0">
                                      <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0 font-cairo font-bold text-xs">
                                        {lesson.format === 'video' ? (
                                          <Play className="w-4 h-4 fill-current" />
                                        ) : (
                                          <FileText className="w-4 h-4" />
                                        )}
                                      </div>
                                      <div className="min-w-0">
                                        <p className="text-xs font-cairo font-bold text-slate-900 dark:text-white truncate">
                                          {lesson.title}
                                        </p>
                                        <p className="text-[11px] text-slate-500 font-tajawal truncate">
                                          {lesson.subject} · {lesson.grade} · {lesson.teacherName}
                                        </p>
                                      </div>
                                    </div>
                                    <span className="px-2.5 py-1 rounded-lg bg-[#0c3d36] text-white text-[10px] font-cairo font-bold shrink-0">
                                      {isAr ? 'فتح الدرس' : 'Open'}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                        {/* 2. TEACHERS FROM DB */}
                        {(activeSearchTab === 'all' || activeSearchTab === 'teachers') &&
                          dbSearchData.teachers.length > 0 && (
                            <div className="pt-3 first:pt-0 space-y-2">
                              <span className="text-[11px] font-cairo font-bold text-blue-700 dark:text-blue-400 flex items-center gap-1 px-1">
                                <UserCheck className="w-3.5 h-3.5" />
                                {isAr
                                  ? `المعلمون والخبراء (${dbSearchData.teachers.length})`
                                  : `Teachers (${dbSearchData.teachers.length})`}
                              </span>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                                {dbSearchData.teachers.slice(0, 4).map((teacher) => (
                                  <div
                                    key={teacher.id}
                                    onClick={() => {
                                      setSelectedSubject(teacher.specialty);
                                      setIsSearchPanelOpen(false);
                                      document
                                        .getElementById('courses-section')
                                        ?.scrollIntoView({ behavior: 'smooth' });
                                    }}
                                    className="p-2.5 rounded-xl bg-slate-50 hover:bg-blue-50/60 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 cursor-pointer transition-colors"
                                  >
                                    <div className="min-w-0">
                                      <p className="text-xs font-cairo font-bold text-slate-900 dark:text-white truncate">
                                        {teacher.name}
                                      </p>
                                      <p className="text-[11px] text-slate-500 font-tajawal truncate">
                                        {teacher.specialty} · ★ {teacher.rating}
                                      </p>
                                    </div>
                                    <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                        {/* 3. QUIZZES FROM DB */}
                        {(activeSearchTab === 'all' || activeSearchTab === 'quizzes') &&
                          dbSearchData.quizzes.length > 0 && (
                            <div className="pt-3 first:pt-0 space-y-2">
                              <span className="text-[11px] font-cairo font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1 px-1">
                                <HelpCircle className="w-3.5 h-3.5" />
                                {isAr
                                  ? `الاختبارات والمسابقات (${dbSearchData.quizzes.length})`
                                  : `Quizzes (${dbSearchData.quizzes.length})`}
                              </span>
                              <div className="space-y-1.5">
                                {dbSearchData.quizzes.slice(0, 4).map((qz) => (
                                  <button
                                    key={qz.id}
                                    type="button"
                                    onClick={() => {
                                      setIsSearchPanelOpen(false);
                                      onOpenAuth();
                                    }}
                                    className="w-full p-2.5 rounded-xl bg-slate-50 hover:bg-amber-50/60 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-right cursor-pointer transition-colors"
                                  >
                                    <div className="min-w-0">
                                      <p className="text-xs font-cairo font-bold text-slate-900 dark:text-white truncate">
                                        {qz.title}
                                      </p>
                                      <p className="text-[11px] text-slate-500 font-tajawal truncate">
                                        {qz.subject} · {qz.grade} · {qz.durationMinutes}{' '}
                                        {isAr ? 'دقيقة' : 'min'}
                                      </p>
                                    </div>
                                    <span className="px-2 py-1 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[10px] font-cairo font-bold shrink-0">
                                      {isAr ? 'بدء الاختبار' : 'Start Quiz'}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                        {/* 4. TIMETABLE SLOTS FROM DB */}
                        {(activeSearchTab === 'all' || activeSearchTab === 'timetable') &&
                          dbSearchData.timetableSlots.length > 0 && (
                            <div className="pt-3 first:pt-0 space-y-2">
                              <span className="text-[11px] font-cairo font-bold text-purple-700 dark:text-purple-400 flex items-center gap-1 px-1">
                                <Calendar className="w-3.5 h-3.5" />
                                {isAr
                                  ? `جدول الحصص (${dbSearchData.timetableSlots.length})`
                                  : `Timetable (${dbSearchData.timetableSlots.length})`}
                              </span>
                              <div className="space-y-1.5">
                                {dbSearchData.timetableSlots.slice(0, 4).map((slot) => (
                                  <div
                                    key={slot.id}
                                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2"
                                  >
                                    <div className="min-w-0">
                                      <p className="text-xs font-cairo font-bold text-slate-900 dark:text-white truncate">
                                        {slot.subject} {slot.courseTitle ? `- ${slot.courseTitle}` : ''}
                                      </p>
                                      <p className="text-[11px] text-slate-500 font-tajawal truncate">
                                        {slot.dayAr} · {slot.time} · {slot.teacherName} ({slot.grade})
                                      </p>
                                    </div>
                                    <span className="text-[10px] font-cairo font-bold px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 shrink-0">
                                      {slot.roomOrLink}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                        {/* 5. CERTIFICATES FROM DB */}
                        {(activeSearchTab === 'all' || activeSearchTab === 'certificates') &&
                          dbSearchData.certificates.length > 0 && (
                            <div className="pt-3 first:pt-0 space-y-2">
                              <span className="text-[11px] font-cairo font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1 px-1">
                                <Award className="w-3.5 h-3.5" />
                                {isAr
                                  ? `الشهادات المعتمدة (${dbSearchData.certificates.length})`
                                  : `Certificates (${dbSearchData.certificates.length})`}
                              </span>
                              <div className="space-y-1.5">
                                {dbSearchData.certificates.slice(0, 4).map((cert) => (
                                  <button
                                    key={cert.id}
                                    type="button"
                                    onClick={() => {
                                      setIsSearchPanelOpen(false);
                                      onOpenCertificateDetails(cert);
                                    }}
                                    className="w-full p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50/70 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-right cursor-pointer"
                                  >
                                    <div className="min-w-0">
                                      <p className="text-xs font-cairo font-bold text-slate-900 dark:text-white truncate">
                                        {cert.studentName} — {cert.subjectOrTrack}
                                      </p>
                                      <p className="text-[11px] text-slate-500 font-tajawal truncate">
                                        {cert.studentGrade} · {cert.serialNumber} · {cert.score}%
                                      </p>
                                    </div>
                                    <span className="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-cairo font-bold shrink-0">
                                      {isAr ? 'عرض الشهادة' : 'View'}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Two Customizable Action Buttons */}
            <div className="hp-hero-enter hp-delay-400 flex flex-wrap items-center gap-3 pt-1">
              {slider.showPrimaryBtn !== false && (
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.primaryBtnLink)}
                  className="hp-btn-shimmer group flex items-center gap-2 px-6 py-3 rounded-xl bg-[#0c3d36] hover:bg-[#092e29] text-white font-cairo font-bold text-xs sm:text-sm shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
                >
                  <span>{isAr ? slider.primaryBtnTextAr : slider.primaryBtnTextEn}</span>
                  <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </button>
              )}

              {slider.showSecondaryBtn !== false && (
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.secondaryBtnLink)}
                  className="group flex items-center gap-2 px-6 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-emerald-500/60 hover:bg-emerald-50/40 dark:hover:bg-slate-800 font-cairo font-bold text-xs sm:text-sm transition-all duration-300 hover:-translate-y-0.5 shadow-xs hover:shadow-md cursor-pointer"
                >
                  <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                    <Play className="w-3 h-3 text-emerald-700 dark:text-emerald-400 fill-emerald-700 dark:fill-emerald-400 ml-0.5" />
                  </div>
                  <span>{isAr ? slider.secondaryBtnTextAr : slider.secondaryBtnTextEn}</span>
                </button>
              )}
            </div>

            {/* Social Proof Strip */}
            <div className="hp-hero-enter hp-delay-500 flex items-center gap-3 pt-2 text-xs text-slate-500 dark:text-slate-400 font-tajawal">
              <div className="flex -space-x-2 space-x-reverse">
                <img
                  src="/assets/images/avatar_teacher_male_1794403366117.jpg"
                  alt="Student"
                  className="w-7 h-7 rounded-full border-2 border-white dark:border-slate-900 object-cover transition-transform hover:scale-110 hover:z-10"
                />
                <img
                  src="/assets/images/avatar_teacher_female_1794403365703.jpg"
                  alt="Student"
                  className="w-7 h-7 rounded-full border-2 border-white dark:border-slate-900 object-cover transition-transform hover:scale-110 hover:z-10"
                />
                <div className="w-7 h-7 rounded-full bg-emerald-600 text-white font-mono-numbers text-[10px] font-bold flex items-center justify-center border-2 border-white dark:border-slate-900 shadow-xs">
                  <AnimatedStatValue value={dbSearchData?.databaseTotals.students ?? students.length} />
                </div>
              </div>
              <span className="font-mono-numbers">
                {isAr
                  ? `متصل بقاعدة بيانات منصة الشريف (${dbSearchData?.databaseTotals.lessons ?? lessons.length} درس · ${dbSearchData?.databaseTotals.students ?? students.length} طالب)`
                  : `Connected to Al-Sharif Database (${dbSearchData?.databaseTotals.lessons ?? lessons.length} lessons)`}
              </span>
            </div>
          </div>

          {/* Left Column: Organic Arch Image with Interactive 3D Parallax & Floating Badges */}
          <div
            onMouseMove={handleHeroMouseMove}
            onMouseLeave={handleHeroMouseLeave}
            className="lg:col-span-5 relative flex justify-center hp-hero-enter hp-delay-200"
          >
            {/* Subtle background decorative shapes */}
            <div className="absolute -bottom-4 -right-4 w-28 h-28 bg-amber-300/35 dark:bg-amber-900/20 rounded-full blur-2xl -z-10 hp-animate-aurora" />
            <div className="absolute top-1/2 -left-8 w-32 h-32 bg-emerald-200/50 dark:bg-emerald-950/40 rounded-full blur-xl -z-10 hp-animate-float-delayed" />

            {/* Arch-shaped container with 3D mouse-tilt + smooth floating */}
            <div className="hp-animate-float w-full max-w-[340px] sm:max-w-[380px]">
              <div
                style={{
                  transform: `perspective(1000px) rotateX(${heroTilt.rx}deg) rotateY(${heroTilt.ry}deg)`,
                  transition:
                    heroTilt.rx === 0 && heroTilt.ry === 0
                      ? 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)'
                      : 'transform 0.12s ease-out',
                }}
                className="relative w-full h-[300px] sm:h-[380px] lg:h-[440px] rounded-t-[100px] sm:rounded-t-[140px] rounded-b-[28px] sm:rounded-b-[36px] overflow-hidden border-4 border-white dark:border-slate-800 shadow-[0_25px_55px_-12px_rgba(12,61,54,0.28)] bg-gradient-to-b from-emerald-100 to-slate-100 group"
              >
                <img
                  src={slider.sliderImageUrl || '/assets/images/hero_school_platform_1794403365692.jpg'}
                  alt="Hero Slider"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
                />

                {/* Subtle glass highlight overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-white/10 opacity-60 group-hover:opacity-80 transition-opacity duration-500 pointer-events-none" />

                {isAdminUser && (
                  <button
                    type="button"
                    onClick={() => {
                      setDraftSlider(slider);
                      setIsSliderEditorOpen(true);
                    }}
                    className="absolute top-4 right-4 px-3 py-1.5 rounded-xl bg-slate-900/85 hover:bg-slate-900 text-amber-400 text-[11px] font-cairo font-bold flex items-center gap-1.5 shadow-lg cursor-pointer backdrop-blur-xs z-20"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>{isAr ? 'تغيير الصورة' : 'Change Image'}</span>
                  </button>
                )}

                {/* Floating Top-Left Card: Rating with opposite parallax offset */}
                <div
                  style={{
                    transform: `translate3d(${heroTilt.px}px, ${heroTilt.py}px, 30px)`,
                    transition: 'transform 0.2s ease-out',
                  }}
                  className="absolute top-8 left-4 p-2.5 rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-xl flex items-center gap-2 font-cairo hp-animate-float-delayed"
                >
                  <div className="w-7 h-7 rounded-xl bg-amber-50 dark:bg-amber-950 flex items-center justify-center text-amber-500 shadow-2xs">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-xs font-black font-mono-numbers text-slate-900 dark:text-white block">
                      <AnimatedStatValue value={slider.ratingBadgeScore} />
                    </span>
                    <span className="text-[10px] text-slate-500 font-tajawal block">
                      {isAr ? slider.ratingBadgeLabelAr : slider.ratingBadgeLabelEn}
                    </span>
                  </div>
                </div>

                {/* Floating Bottom Card: Interactive Course Progress Pill */}
                <div
                  style={{
                    transform: `translate3d(${-heroTilt.px * 0.7}px, ${-heroTilt.py * 0.7}px, 25px)`,
                    transition: 'transform 0.2s ease-out',
                  }}
                  className="absolute bottom-6 inset-x-4 p-3 rounded-2xl bg-slate-900/92 dark:bg-slate-950/92 backdrop-blur-md border border-white/15 text-white shadow-2xl flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-emerald-600/30 group-hover:scale-110 transition-transform">
                      <Play className="w-3.5 h-3.5 fill-white" />
                    </div>
                    <div>
                      <span className="text-[10px] text-emerald-300/90 block font-tajawal">
                        {isAr ? slider.floatingCardKickerAr : slider.floatingCardKickerEn}
                      </span>
                      <span className="text-xs font-bold font-cairo block truncate max-w-[150px]">
                        {(isAr ? slider.floatingCardTitleAr : slider.floatingCardTitleEn) ||
                          filteredLessons[0]?.title ||
                          (isAr ? 'دروس ومحاضرات تفاعلية' : 'Interactive Courses')}
                      </span>
                    </div>
                  </div>

                  <div className="text-left font-mono-numbers">
                    <span className="text-xs font-bold text-emerald-400">
                      <AnimatedStatValue value="100%" />
                    </span>
                    <div className="w-14 h-1.5 bg-slate-700 rounded-full mt-1 overflow-hidden">
                      <div className="w-full h-full bg-gradient-to-r from-emerald-400 to-teal-300 rounded-full hp-animate-progress" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ADMIN HERO SLIDER CUSTOMIZATION MODAL */}
        {isSliderEditorOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
            <div className="w-full max-w-3xl my-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden text-right">
              {/* Modal Header */}
              <div className="px-6 py-4 bg-[#0c3d36] text-white flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Edit3 className="w-5 h-5 text-amber-400" />
                  <div>
                    <h3 className="font-cairo font-black text-base sm:text-lg">
                      {isAr
                        ? 'لوحة تحكم الأدمن في السلايدر الرئيسي (النصوص · الأزرار والروابط · الصورة)'
                        : 'Admin Hero Slider Customizer (Texts, Buttons & Links, Image)'}
                    </h3>
                    <p className="text-[11px] text-emerald-200 font-tajawal">
                      {isAr
                        ? 'يتم حفظ كافة التعديلات مباشرة في قاعدة بيانات منصة الشريف وتحديثها فوراً للجميع'
                        : 'All changes are saved directly to the PostgreSQL database'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSliderEditorOpen(false)}
                  className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Form */}
              <form
                onSubmit={handleSaveSliderConfig}
                className="p-5 sm:p-6 max-h-[80vh] overflow-y-auto space-y-6 text-xs sm:text-sm font-tajawal"
              >
                {/* SECTION 1: SLIDER TEXTS */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4">
                  <h4 className="font-cairo font-black text-sm text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span>{isAr ? '1. نصوص وعناوين السلايدر' : '1. Slider Headlines & Texts'}</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص الشارة العلوية (عربي)' : 'Top Badge Text (Arabic)'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.badgeTextAr}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, badgeTextAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص الشارة العلوية (إنجليزي)' : 'Top Badge Text (English)'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.badgeTextEn}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, badgeTextEn: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العنوان الرئيسي - السطر الأول (عربي)' : 'Headline Line 1 (Ar)'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.headlineLine1Ar}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, headlineLine1Ar: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العنوان الرئيسي - السطر الثاني (عربي)' : 'Headline Line 2 (Ar)'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.headlineLine2Ar}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, headlineLine2Ar: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'الوصف الفرعي للسلايدر (عربي)' : 'Slider Subtitle (Arabic)'}
                    </label>
                    <textarea
                      rows={2}
                      value={draftSlider.subtitleAr}
                      onChange={(e) =>
                        setDraftSlider((p) => ({ ...p, subtitleAr: e.target.value }))
                      }
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص تلميح مربع البحث (Placeholder)' : 'Search Box Placeholder'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.searchPlaceholderAr}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, searchPlaceholderAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص زر البحث' : 'Search Button Label'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.searchButtonTextAr}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, searchButtonTextAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* SECTION 2: BUTTONS TEXTS & LINKS */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4">
                  <h4 className="font-cairo font-black text-sm text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                    <LinkIcon className="w-4 h-4" />
                    <span>{isAr ? '2. نصوص وروابط أزرار السلايدر' : '2. Slider Buttons Texts & Links'}</span>
                  </h4>

                  {/* Primary Button */}
                  <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-cairo font-bold text-xs text-slate-900 dark:text-white">
                        {isAr ? 'الزر الرئيسي الأول (الأخضر الداكن)' : 'Primary Button'}
                      </span>
                      <label className="flex items-center gap-1.5 text-xs font-cairo cursor-pointer">
                        <input
                          type="checkbox"
                          checked={draftSlider.showPrimaryBtn !== false}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, showPrimaryBtn: e.target.checked }))
                          }
                          className="accent-emerald-600"
                        />
                        <span>{isAr ? 'إظهار الزر' : 'Show Button'}</span>
                      </label>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'نص الزر الأول (عربي)' : 'Button 1 Text (Ar)'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.primaryBtnTextAr}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, primaryBtnTextAr: e.target.value }))
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                        />
                      </div>

                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'اختيار وجهة سريعة للرابط' : 'Quick Destination'}
                        </label>
                        <select
                          value={
                            [
                              '#courses-section',
                              '#auth',
                              '#tab:lessons',
                              '#tab:quizzes',
                              '#tab:flashcards',
                              '#tab:certificates',
                              '#tab:timetable',
                            ].includes(draftSlider.primaryBtnLink)
                              ? draftSlider.primaryBtnLink
                              : 'custom'
                          }
                          onChange={(e) => {
                            if (e.target.value !== 'custom') {
                              setDraftSlider((p) => ({ ...p, primaryBtnLink: e.target.value }));
                            }
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                        >
                          <option value="#courses-section">قسم الدورات (#courses-section)</option>
                          <option value="#auth">نافذة تسجيل الدخول / البوابة (#auth)</option>
                          <option value="#tab:lessons">صفحة الدروس والمحاضرات (#tab:lessons)</option>
                          <option value="#tab:quizzes">صفحة الاختبارات (#tab:quizzes)</option>
                          <option value="#tab:flashcards">الفلاش كارد ومسابقة الشريف (#tab:flashcards)</option>
                          <option value="#tab:certificates">الشهادات المعتمدة (#tab:certificates)</option>
                          <option value="#tab:timetable">جدول الحصص (#tab:timetable)</option>
                          <option value="custom">رابط خارجي أو مخصص...</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'رابط الزر الأول (URL أو #قسم)' : 'Button 1 URL / Link'}
                        </label>
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.primaryBtnLink}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, primaryBtnLink: e.target.value }))
                          }
                          placeholder="#courses-section or https://..."
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Secondary Button */}
                  <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-cairo font-bold text-xs text-slate-900 dark:text-white">
                        {isAr ? 'الزر الثانوي الثاني (الأبيض)' : 'Secondary Button'}
                      </span>
                      <label className="flex items-center gap-1.5 text-xs font-cairo cursor-pointer">
                        <input
                          type="checkbox"
                          checked={draftSlider.showSecondaryBtn !== false}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, showSecondaryBtn: e.target.checked }))
                          }
                          className="accent-emerald-600"
                        />
                        <span>{isAr ? 'إظهار الزر' : 'Show Button'}</span>
                      </label>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'نص الزر الثاني (عربي)' : 'Button 2 Text (Ar)'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.secondaryBtnTextAr}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, secondaryBtnTextAr: e.target.value }))
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                        />
                      </div>

                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'اختيار وجهة سريعة للرابط' : 'Quick Destination'}
                        </label>
                        <select
                          value={
                            [
                              '#courses-section',
                              '#auth',
                              '#tab:lessons',
                              '#tab:quizzes',
                              '#tab:flashcards',
                              '#tab:certificates',
                              '#tab:timetable',
                            ].includes(draftSlider.secondaryBtnLink)
                              ? draftSlider.secondaryBtnLink
                              : 'custom'
                          }
                          onChange={(e) => {
                            if (e.target.value !== 'custom') {
                              setDraftSlider((p) => ({ ...p, secondaryBtnLink: e.target.value }));
                            }
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                        >
                          <option value="#auth">نافذة تسجيل الدخول / البوابة (#auth)</option>
                          <option value="#courses-section">قسم الدورات (#courses-section)</option>
                          <option value="#tab:lessons">صفحة الدروس والمحاضرات (#tab:lessons)</option>
                          <option value="#tab:quizzes">صفحة الاختبارات (#tab:quizzes)</option>
                          <option value="#tab:flashcards">الفلاش كارد ومسابقة الشريف (#tab:flashcards)</option>
                          <option value="#tab:certificates">الشهادات المعتمدة (#tab:certificates)</option>
                          <option value="#tab:timetable">جدول الحصص (#tab:timetable)</option>
                          <option value="custom">رابط خارجي أو مخصص...</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                          {isAr ? 'رابط الزر الثاني (URL أو #قسم)' : 'Button 2 URL / Link'}
                        </label>
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.secondaryBtnLink}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, secondaryBtnLink: e.target.value }))
                          }
                          placeholder="#auth or https://..."
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* SECTION 3: SLIDER IMAGE & FLOATING CARDS */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4">
                  <h4 className="font-cairo font-black text-sm text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                    <ImageIcon className="w-4 h-4" />
                    <span>{isAr ? '3. صورة السلايدر والبطاقات العائمة' : '3. Slider Image & Badges'}</span>
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                    <div className="md:col-span-4 flex flex-col items-center gap-2">
                      <div className="w-36 h-44 rounded-t-[60px] rounded-b-2xl overflow-hidden border-2 border-emerald-500 shadow-md bg-slate-100">
                        <img
                          src={
                            draftSlider.sliderImageUrl ||
                            '/assets/images/hero_school_platform_1794403365692.jpg'
                          }
                          alt="Preview"
                          className="w-full h-full object-cover object-top"
                        />
                      </div>
                      <span className="text-[11px] text-slate-500 font-cairo">
                        {isAr ? 'معاينة صورة السلايدر' : 'Image Preview'}
                      </span>
                    </div>

                    <div className="md:col-span-8 space-y-3">
                      <div>
                        <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                          {isAr ? 'رابط صورة السلايدر (أو ارفع صورة من جهازك)' : 'Slider Image URL'}
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            dir="ltr"
                            value={draftSlider.sliderImageUrl}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, sliderImageUrl: e.target.value }))
                            }
                            placeholder="/assets/images/... or https://..."
                            className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs"
                          />
                          <input
                            ref={sliderFileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleSliderImageUpload}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => sliderFileInputRef.current?.click()}
                            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>{isAr ? 'رفع صورة من جهازك' : 'Upload Image'}</span>
                          </button>
                        </div>
                      </div>

                      {/* Quick Preset Gallery */}
                      <div>
                        <span className="block font-cairo font-bold text-[11px] text-slate-500 mb-1.5">
                          {isAr ? 'أو اختر من صور المنصة الجاهزة:' : 'Or choose a preset image:'}
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {[
                            {
                              label: 'الصورة الرئيسية للمنصة',
                              url: '/assets/images/hero_school_platform_1794403365692.jpg',
                            },
                            {
                              label: 'نموذج معلم أكاديمي',
                              url: '/assets/images/avatar_teacher_male_1794403366117.jpg',
                            },
                            {
                              label: 'نموذج معلمة أكاديمية',
                              url: '/assets/images/avatar_teacher_female_1794403365703.jpg',
                            },
                            {
                              label: 'شعار التميز الذهبي',
                              url: '/assets/images/certificate_crest_gold_1794403367581.jpg',
                            },
                          ].map((preset) => (
                            <button
                              key={preset.url}
                              type="button"
                              onClick={() =>
                                setDraftSlider((p) => ({ ...p, sliderImageUrl: preset.url }))
                              }
                              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-cairo font-bold border transition-all cursor-pointer ${
                                draftSlider.sliderImageUrl === preset.url
                                  ? 'bg-[#0c3d36] text-white border-[#0c3d36]'
                                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {preset.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                            {isAr ? 'رقم التقييم العائم' : 'Rating Score'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.ratingBadgeScore}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, ratingBadgeScore: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                            {isAr ? 'عنوان البطاقة السفلية' : 'Bottom Card Kicker'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.floatingCardKickerAr}
                            onChange={(e) =>
                              setDraftSlider((p) => ({
                                ...p,
                                floatingCardKickerAr: e.target.value,
                              }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                            {isAr ? 'النص الرئيسي للبطاقة السفلية' : 'Bottom Card Title'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.floatingCardTitleAr}
                            onChange={(e) =>
                              setDraftSlider((p) => ({
                                ...p,
                                floatingCardTitleAr: e.target.value,
                              }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* SECTION 4: DARK STATS STRIP (4 STATS NUMBERS & LABELS) */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="font-cairo font-black text-sm text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" />
                      <span>
                        {isAr
                          ? '4. تعديل شريط الإحصائيات الرباعي (الأرقام والنصوص تحت السلايدر)'
                          : '4. Stats Strip Numbers & Labels'}
                      </span>
                    </h4>
                    <span className="text-[11px] text-slate-500 font-tajawal">
                      {isAr
                        ? 'اترك حقل الرقم فارغاً ليقرأ العدد الفعلي تلقائياً من قاعدة البيانات، أو اكتب أي رقم/نص مخصص'
                        : 'Leave number empty to use live DB count, or enter a custom value'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Stat 1: Students */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 dark:text-emerald-400 block">
                        {isAr ? 'الخانة الأولى (الطلاب)' : 'Stat 1 (Students)'}
                      </span>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'الرقم المعروض' : 'Number / Value'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat1Value ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat1Value: e.target.value }))
                            }
                            placeholder={`${
                              dbSearchData?.databaseTotals.students ?? students.length
                            } (تلقائي من الداتا بيز)`}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'العنوان / النص' : 'Label'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat1LabelAr ?? 'طالب مسجل في قاعدة البيانات'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat1LabelAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Stat 2: Lessons */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 dark:text-emerald-400 block">
                        {isAr ? 'الخانة الثانية (الدروس والمحاضرات)' : 'Stat 2 (Lessons)'}
                      </span>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'الرقم المعروض' : 'Number / Value'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat2Value ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat2Value: e.target.value }))
                            }
                            placeholder={`${
                              dbSearchData?.databaseTotals.lessons ?? lessons.length
                            } (تلقائي من الداتا بيز)`}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'العنوان / النص' : 'Label'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat2LabelAr ?? 'درس ومحاضرة في قاعدة البيانات'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat2LabelAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Stat 3: Teachers */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 dark:text-emerald-400 block">
                        {isAr ? 'الخانة الثالثة (المعلمون والخبراء)' : 'Stat 3 (Teachers)'}
                      </span>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'الرقم المعروض' : 'Number / Value'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat3Value ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat3Value: e.target.value }))
                            }
                            placeholder={`${
                              dbSearchData?.databaseTotals.teachers ?? teachers.length
                            } (تلقائي من الداتا بيز)`}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'العنوان / النص' : 'Label'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat3LabelAr ?? 'معلم وخبير معتمد'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat3LabelAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Stat 4: Quizzes */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 dark:text-emerald-400 block">
                        {isAr ? 'الخانة الرابعة (الاختبارات والمسابقات)' : 'Stat 4 (Quizzes)'}
                      </span>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'الرقم المعروض' : 'Number / Value'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat4Value ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat4Value: e.target.value }))
                            }
                            placeholder={`${
                              dbSearchData?.databaseTotals.quizzes ?? 0
                            } (تلقائي من الداتا بيز)`}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                        <div>
                          <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                            {isAr ? 'العنوان / النص' : 'Label'}
                          </label>
                          <input
                            type="text"
                            value={draftSlider.stat4LabelAr ?? 'اختبار ومسابقة تفاعلية'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, stat4LabelAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 5. Featured Courses Section Texts */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '5. قسم دورات ودروس منصة الشريف (العناوين وحالة عدم وجود دورات)'
                        : '5. Featured Courses Section Texts'}
                    </span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الشارة العلوية لقسم الدورات' : 'Courses Kicker'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.coursesKickerAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, coursesKickerAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العنوان الرئيسي لقسم الدورات' : 'Courses Title'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.coursesTitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, coursesTitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الوصف الفرعي لقسم الدورات' : 'Courses Subtitle'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.coursesSubtitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, coursesSubtitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص زر عرض الكل' : 'View All Button Text'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.coursesViewAllBtnAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, coursesViewAllBtnAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2.5">
                    <span className="font-cairo font-bold text-xs text-emerald-700 dark:text-emerald-400 block">
                      {isAr
                        ? 'بيانات صندوق "لا توجد دورات مطابقة حالياً في قاعدة البيانات"'
                        : 'Empty Courses Box Texts'}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'عنوان عدم وجود دورات' : 'Empty State Title'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.coursesEmptyTitleAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, coursesEmptyTitleAr: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'نص زر إضافة الدروس' : 'Empty State Button Text'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.coursesEmptyBtnTextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, coursesEmptyBtnTextAr: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'وصف عدم وجود دورات' : 'Empty State Description'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.coursesEmptyDescAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, coursesEmptyDescAr: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'رابط زر إضافة الدروس (#auth أو رابط مخصص)' : 'Empty State Button Link'}
                        </label>
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.coursesEmptyBtnLink ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, coursesEmptyBtnLink: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 6. Tracks & Categories Section Texts */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '6. قسم اكتشف المواد الدراسية والمسارات'
                        : '6. Subject Tracks Section Texts'}
                    </span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الشارة العلوية للمسارات' : 'Tracks Kicker'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.tracksKickerAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, tracksKickerAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العنوان الرئيسي للمسارات' : 'Tracks Title'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.tracksTitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, tracksTitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'النص عند عدم وجود مسارات حالياً' : 'Empty Tracks Text'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.tracksEmptyDescAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, tracksEmptyDescAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                  </div>
                </div>

                {/* 7. Why Al-Sharif Value Proposition Section */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '7. قسم لماذا منصة الشريف؟ (العناوين · المميزات الأربعة · الصورة وبطاقة أحسنت)'
                        : '7. Why Al-Sharif Section'}
                    </span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الشارة العلوية (لماذا منصة الشريف؟)' : 'Kicker'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.whyKickerAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whyKickerAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العنوان الرئيسي' : 'Main Title'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.whyTitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whyTitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الوصف الفرعي' : 'Subtitle'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.whySubtitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whySubtitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                  </div>

                  {/* 4 Features Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Feature 1 */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 block">
                        {isAr ? 'الميزة الأولى (تعلم بمرونة)' : 'Feature 1'}
                      </span>
                      <div className="grid grid-cols-4 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-0.5">الأيقونة</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature1Icon ?? '📅'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature1Icon: e.target.value }))
                            }
                            className="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center text-xs"
                          />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-500 mb-0.5">العنوان</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature1TitleAr ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature1TitleAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                      </div>
                      <input
                        type="text"
                        value={draftSlider.whyFeature1DescAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whyFeature1DescAr: e.target.value }))
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>

                    {/* Feature 2 */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 block">
                        {isAr ? 'الميزة الثانية (خبراء حقيقيون)' : 'Feature 2'}
                      </span>
                      <div className="grid grid-cols-4 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-0.5">الأيقونة</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature2Icon ?? '🎓'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature2Icon: e.target.value }))
                            }
                            className="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center text-xs"
                          />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-500 mb-0.5">العنوان</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature2TitleAr ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature2TitleAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                      </div>
                      <input
                        type="text"
                        value={draftSlider.whyFeature2DescAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whyFeature2DescAr: e.target.value }))
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>

                    {/* Feature 3 */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 block">
                        {isAr ? 'الميزة الثالثة (تطبيق من اليوم الأول)' : 'Feature 3'}
                      </span>
                      <div className="grid grid-cols-4 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-0.5">الأيقونة</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature3Icon ?? '⚡'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature3Icon: e.target.value }))
                            }
                            className="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center text-xs"
                          />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-500 mb-0.5">العنوان</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature3TitleAr ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature3TitleAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                      </div>
                      <input
                        type="text"
                        value={draftSlider.whyFeature3DescAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whyFeature3DescAr: e.target.value }))
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>

                    {/* Feature 4 */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="font-cairo font-bold text-xs text-emerald-700 block">
                        {isAr ? 'الميزة الرابعة (تقدم يمكنك قياسه)' : 'Feature 4'}
                      </span>
                      <div className="grid grid-cols-4 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-0.5">الأيقونة</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature4Icon ?? '📊'}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature4Icon: e.target.value }))
                            }
                            className="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center text-xs"
                          />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] text-slate-500 mb-0.5">العنوان</label>
                          <input
                            type="text"
                            value={draftSlider.whyFeature4TitleAr ?? ''}
                            onChange={(e) =>
                              setDraftSlider((p) => ({ ...p, whyFeature4TitleAr: e.target.value }))
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                          />
                        </div>
                      </div>
                      <input
                        type="text"
                        value={draftSlider.whyFeature4DescAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, whyFeature4DescAr: e.target.value }))
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                  </div>

                  {/* Why Section Image & Trophy Card */}
                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex flex-col sm:flex-row gap-2 items-center">
                      <div className="flex-1 w-full">
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'صورة قسم لماذا منصة الشريف؟ (Students collaborating)' : 'Section Image URL'}
                        </label>
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.whyImageUrl ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, whyImageUrl: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                      </div>
                      <input
                        ref={whyFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleWhyImageUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => whyFileInputRef.current?.click()}
                        className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer self-end"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isAr ? 'رفع صورة' : 'Upload'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'نص بديل الصورة (Alt)' : 'Image Alt'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.whyImageAlt ?? 'Students collaborating'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, whyImageAlt: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'أيقونة الكأس' : 'Trophy Icon'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.whyTrophyIcon ?? '🏆'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, whyTrophyIcon: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'عنوان بطاقة الكأس (أحسنت!)' : 'Trophy Title'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.whyTrophyTitleAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, whyTrophyTitleAr: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="block font-cairo font-bold text-[11px] text-slate-500 mb-1">
                          {isAr ? 'وصف بطاقة الكأس' : 'Trophy Subtitle'}
                        </label>
                        <input
                          type="text"
                          value={draftSlider.whyTrophyDescAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, whyTrophyDescAr: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 8. Testimonial Section (قصص من مجتمعنا) */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Quote className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '8. قسم قصص من مجتمعنا (الاقتباس · الاسم · الوظيفة · الصورة الشخصية)'
                        : '8. Testimonial Section'}
                    </span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الشارة العلوية (قصص من مجتمعنا)' : 'Kicker'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.testimonialKickerAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, testimonialKickerAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العنوان الرئيسي' : 'Title'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.testimonialTitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, testimonialTitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص الاقتباس / القصة' : 'Quote Text'}
                      </label>
                      <textarea
                        rows={2}
                        value={draftSlider.testimonialQuoteAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, testimonialQuoteAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'اسم صاحب القصة (سارة خالد)' : 'Author Name'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.testimonialAuthorNameAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, testimonialAuthorNameAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'المسمى الوظيفي / الصفة' : 'Author Role'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.testimonialAuthorRoleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, testimonialAuthorRoleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div className="sm:col-span-2 flex flex-col sm:flex-row gap-2 items-center">
                      <div className="flex-1 w-full">
                        <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                          {isAr ? 'رابط الصورة الشخصية' : 'Avatar Image URL'}
                        </label>
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.testimonialAvatarUrl ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, testimonialAvatarUrl: e.target.value }))
                          }
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                      </div>
                      <input
                        ref={testimonialFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleTestimonialAvatarUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => testimonialFileInputRef.current?.click()}
                        className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer self-end"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isAr ? 'رفع صورة شخصية' : 'Upload Avatar'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 9. Newsletter CTA Section */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '9. قسم النشرة البريدية (خطوتك القادمة تبدأ من بريدك)'
                        : '9. Newsletter Section'}
                    </span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'عنوان النشرة البريدية' : 'Newsletter Title'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.newsletterTitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, newsletterTitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'وصف النشرة البريدية' : 'Newsletter Subtitle'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.newsletterSubtitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, newsletterSubtitleAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص حقل البريد الإلكتروني' : 'Email Input Placeholder'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.newsletterPlaceholderAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, newsletterPlaceholderAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص زر الاشتراك (اشترك الآن)' : 'Subscribe Button Text'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.newsletterBtnTextAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, newsletterBtnTextAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                  </div>
                </div>

                {/* 10. Footer Section (الفوتر السفلي بالكامل) */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4">
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-emerald-600" />
                    <span>
                      {isAr
                        ? '10. قسم الفوتر السفلي (الوصف · القوائم الثلاث وروابطها · حقوق الملكية)'
                        : '10. Footer Section'}
                    </span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'اسم المنصة في الفوتر' : 'Footer Brand Name'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerBrandNameAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerBrandNameAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'الوصف التعريفي تحت اسم المنصة في الفوتر' : 'Footer Brand Description'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerBrandDescAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerBrandDescAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                  </div>

                  {/* 3 Footer Columns */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
                    {/* Column 1: المنصة */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <label className="block font-cairo font-bold text-xs text-emerald-700">
                        {isAr ? 'العمود الأول (المنصة)' : 'Column 1'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerCol1TitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerCol1TitleAr: e.target.value }))
                        }
                        placeholder="عنوان العمود الأول"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                      <div className="grid grid-cols-2 gap-1.5">
                        <input
                          type="text"
                          value={draftSlider.footerCol1Link1TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol1Link1TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol1Link1Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol1Link1Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                        <input
                          type="text"
                          value={draftSlider.footerCol1Link2TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol1Link2TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol1Link2Url ?? '#courses-section'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol1Link2Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                        <input
                          type="text"
                          value={draftSlider.footerCol1Link3TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol1Link3TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol1Link3Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol1Link3Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                      </div>
                    </div>

                    {/* Column 2: الدعم */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <label className="block font-cairo font-bold text-xs text-emerald-700">
                        {isAr ? 'العمود الثاني (الدعم)' : 'Column 2'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerCol2TitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerCol2TitleAr: e.target.value }))
                        }
                        placeholder="عنوان العمود الثاني"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                      <div className="grid grid-cols-2 gap-1.5">
                        <input
                          type="text"
                          value={draftSlider.footerCol2Link1TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol2Link1TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol2Link1Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol2Link1Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                        <input
                          type="text"
                          value={draftSlider.footerCol2Link2TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol2Link2TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol2Link2Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol2Link2Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                        <input
                          type="text"
                          value={draftSlider.footerCol2Link3TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol2Link3TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol2Link3Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol2Link3Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                      </div>
                    </div>

                    {/* Column 3: قانوني وبوابات الدخول */}
                    <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                      <label className="block font-cairo font-bold text-xs text-emerald-700">
                        {isAr ? 'العمود الثالث (قانوني وبوابات الدخول)' : 'Column 3'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerCol3TitleAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerCol3TitleAr: e.target.value }))
                        }
                        placeholder="عنوان العمود الثالث"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                      <div className="grid grid-cols-2 gap-1.5">
                        <input
                          type="text"
                          value={draftSlider.footerCol3Link1TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol3Link1TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol3Link1Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol3Link1Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                        <input
                          type="text"
                          value={draftSlider.footerCol3Link2TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol3Link2TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol3Link2Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol3Link2Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                        <input
                          type="text"
                          value={draftSlider.footerCol3Link3TextAr ?? ''}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol3Link3TextAr: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <input
                          type="text"
                          dir="ltr"
                          value={draftSlider.footerCol3Link3Url ?? '#auth'}
                          onChange={(e) =>
                            setDraftSlider((p) => ({ ...p, footerCol3Link3Url: e.target.value }))
                          }
                          className="px-2 py-1 rounded bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Copyright & Bottom Tagline */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'نص حقوق الملكية السفلية' : 'Copyright Text'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerCopyrightAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerCopyrightAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                        {isAr ? 'العبارة الختامية اليسرى في الفوتر' : 'Bottom Tagline'}
                      </label>
                      <input
                        type="text"
                        value={draftSlider.footerTaglineAr ?? ''}
                        onChange={(e) =>
                          setDraftSlider((p) => ({ ...p, footerTaglineAr: e.target.value }))
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Modal Actions */}
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setDraftSlider(DEFAULT_HERO_SLIDER_CONFIG)}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-cairo font-bold text-xs hover:bg-slate-100 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{isAr ? 'استعادة القيم الافتراضية لجميع أقسام الصفحة' : 'Reset All Defaults'}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {sliderSavedToast && (
                      <span className="text-xs font-cairo font-bold text-emerald-600 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        {isAr ? 'تم الحفظ في قاعدة البيانات!' : 'Saved to DB!'}
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => setIsSliderEditorOpen(false)}
                      className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-cairo font-bold text-xs cursor-pointer"
                    >
                      {isAr ? 'إلغاء' : 'Cancel'}
                    </button>
                    <button
                      type="submit"
                      className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-[#0c3d36] hover:bg-[#092e29] text-white font-cairo font-bold text-xs shadow-md cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>
                        {isAr
                          ? 'حفظ تعديلات الصفحة الرئيسية بالكامل في قاعدة البيانات'
                          : 'Save All Homepage Changes'}
                      </span>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}
      </section>

      {/* 2. DARK STATS STRIP (Editable by Admin or Live Database Counts + Obsidian Teal: #092422) */}
      <section className="hp-reveal-section relative rounded-3xl bg-[#092422] text-white p-5 sm:p-8 shadow-xl font-mono-numbers overflow-hidden border border-emerald-500/15">
        {/* Ambient glowing mesh inside stats strip */}
        <div className="absolute -top-20 -right-20 w-56 h-56 rounded-full bg-emerald-500/15 blur-3xl pointer-events-none hp-animate-aurora" />
        <div className="absolute -bottom-20 -left-20 w-56 h-56 rounded-full bg-amber-400/10 blur-3xl pointer-events-none hp-animate-float-delayed" />

        {isAdminUser && (
          <div className="relative z-10 mb-4 pb-3 border-b border-white/10 flex items-center justify-between gap-2">
            <span className="text-xs font-cairo font-bold text-emerald-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              {isAr
                ? 'تحكم الأدمن في شريط الإحصائيات (الأرقام والعناوين الأربعة)'
                : 'Admin Control: Edit Stats Strip Numbers & Labels'}
            </span>
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل الأرقام والعناوين' : 'Edit Stats'}</span>
            </button>
          </div>
        )}

        <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 text-center md:divide-x md:divide-x-reverse divide-white/10">
          <div className="group p-3 sm:p-2 rounded-2xl bg-white/5 md:bg-transparent hover:bg-white/[0.06] transition-all duration-300 hover:-translate-y-1">
            <span className="text-2xl sm:text-3xl md:text-4xl font-black text-white group-hover:text-emerald-300 transition-colors font-cairo block">
              <AnimatedStatValue
                value={
                  slider.stat1Value && slider.stat1Value.trim() !== ''
                    ? slider.stat1Value
                    : (dbSearchData?.databaseTotals.students ?? students.length)
                }
              />
            </span>
            <span className="text-xs text-emerald-300/80 font-tajawal mt-1 block">
              {isAr
                ? slider.stat1LabelAr || 'طالب مسجل في قاعدة البيانات'
                : slider.stat1LabelEn || 'Registered Students in DB'}
            </span>
          </div>

          <div className="group p-3 sm:p-2 rounded-2xl bg-white/5 md:bg-transparent hover:bg-white/[0.06] transition-all duration-300 hover:-translate-y-1">
            <span className="text-2xl sm:text-3xl md:text-4xl font-black text-white group-hover:text-emerald-300 transition-colors font-cairo block">
              <AnimatedStatValue
                value={
                  slider.stat2Value && slider.stat2Value.trim() !== ''
                    ? slider.stat2Value
                    : (dbSearchData?.databaseTotals.lessons ?? lessons.length)
                }
              />
            </span>
            <span className="text-xs text-emerald-300/80 font-tajawal mt-1 block">
              {isAr
                ? slider.stat2LabelAr || 'درس ومحاضرة في قاعدة البيانات'
                : slider.stat2LabelEn || 'Lessons in Database'}
            </span>
          </div>

          <div className="group p-3 sm:p-2 rounded-2xl bg-white/5 md:bg-transparent hover:bg-white/[0.06] transition-all duration-300 hover:-translate-y-1">
            <span className="text-2xl sm:text-3xl md:text-4xl font-black text-white group-hover:text-emerald-300 transition-colors font-cairo block">
              <AnimatedStatValue
                value={
                  slider.stat3Value && slider.stat3Value.trim() !== ''
                    ? slider.stat3Value
                    : (dbSearchData?.databaseTotals.teachers ?? teachers.length)
                }
              />
            </span>
            <span className="text-xs text-emerald-300/80 font-tajawal mt-1 block">
              {isAr
                ? slider.stat3LabelAr || 'معلم وخبير معتمد'
                : slider.stat3LabelEn || 'Certified Instructors'}
            </span>
          </div>

          <div className="group p-3 sm:p-2 rounded-2xl bg-white/5 md:bg-transparent hover:bg-white/[0.06] transition-all duration-300 hover:-translate-y-1">
            <span className="text-2xl sm:text-3xl md:text-4xl font-black text-white group-hover:text-amber-300 transition-colors font-cairo block">
              <AnimatedStatValue
                value={
                  slider.stat4Value && slider.stat4Value.trim() !== ''
                    ? slider.stat4Value
                    : (dbSearchData?.databaseTotals.quizzes ?? 0)
                }
              />
            </span>
            <span className="text-xs text-emerald-300/80 font-tajawal mt-1 block">
              {isAr
                ? slider.stat4LabelAr || 'اختبار ومسابقة تفاعلية'
                : slider.stat4LabelEn || 'Interactive Quizzes'}
            </span>
          </div>
        </div>
      </section>

      {/* 3. FEATURED COURSES SECTION (دورات مختارة لك من قاعدة البيانات) */}
      <section id="courses-section" className="hp-reveal-section space-y-8 relative">
        {isAdminUser && (
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل نصوص قسم الدورات' : 'Edit Courses Section'}</span>
            </button>
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">
              {isAr
                ? slider.coursesKickerAr || 'دورات ودروس منصة الشريف (من قاعدة البيانات)'
                : 'Featured Courses from Database'}
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-cairo font-black text-slate-900 dark:text-white mt-1">
              {isAr
                ? slider.coursesTitleAr || 'ابدأ من حيث أنت، وتقدّم بطريقتك'
                : 'Start Where You Are, Advance Your Way'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 font-tajawal mt-1">
              {searchQuery || selectedSubject !== 'all'
                ? isAr
                  ? `عرض نتائج البحث المباشر من قاعدة البيانات (${filteredLessons.length} درس مطابق)`
                  : `Showing live database results (${filteredLessons.length} matching lessons)`
                : isAr
                  ? slider.coursesSubtitleAr ||
                    'محتوى تطبيقي محدث مرتبط مباشرة بقاعدة بيانات منصة الشريف.'
                  : 'Practical learning connected directly to Al-Sharif database.'}
            </p>
          </div>

          <button
            onClick={() => {
              setSelectedSubject('all');
              setSearchQuery('');
              executeDatabaseSearch('', 'all');
            }}
            className="group flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs hover:border-emerald-500 hover:bg-emerald-50/50 dark:hover:bg-slate-800 transition-all duration-300 hover:-translate-y-0.5 self-start sm:self-auto cursor-pointer"
          >
            <span>{isAr ? slider.coursesViewAllBtnAr || 'عرض كل الدورات' : 'View All'}</span>
            <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </button>
        </div>

        {/* Courses Cards from Database */}
        {filteredLessons.length === 0 ? (
          <div className="p-8 sm:p-10 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-3">
            <BookOpen className="w-10 h-10 text-emerald-600/70 mx-auto hp-animate-float" />
            <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
              {isAr
                ? slider.coursesEmptyTitleAr || 'لا توجد دورات مطابقة حالياً في قاعدة البيانات'
                : 'No matching courses found in database'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 font-tajawal max-w-md mx-auto">
              {isAr
                ? slider.coursesEmptyDescAr ||
                  'سجّل الدخول إلى البوابة التعليمية لإضافة الدروس والمقررات الدراسية وستظهر هنا وفي مربع البحث تلقائياً.'
                : 'Sign in to the educational portal to publish lessons and courses.'}
            </p>
            <button
              type="button"
              onClick={() => handleSliderButtonClick(slider.coursesEmptyBtnLink || '#auth')}
              className="hp-btn-shimmer inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#0c3d36] hover:bg-[#092e29] text-white text-xs font-cairo font-bold shadow-xs cursor-pointer transition-transform hover:scale-105"
            >
              <span>
                {isAr
                  ? slider.coursesEmptyBtnTextAr || 'دخول البوابة لإضافة دروس'
                  : 'Sign In to Add Courses'}
              </span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
            {filteredLessons.slice(0, 6).map((lesson, idx) => {
              const isFirst = idx === 0;
              const isSecond = idx === 1;

              return (
                <div
                  key={lesson.id}
                  style={{ transitionDelay: `${idx * 65}ms` }}
                  onClick={() => onOpenLessonDetails(lesson)}
                  className="hp-card-interactive group flex flex-col justify-between rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs cursor-pointer"
                >
                  {/* Course Card Thumbnail */}
                  <div className="relative aspect-video w-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <img
                      src={lesson.thumbnail || '/assets/images/hero_school_platform_1794403365692.jpg'}
                      alt={lesson.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                    />

                    {/* Hover Play Button Spotlight Scrim */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/65 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-emerald-600/95 text-white flex items-center justify-center shadow-xl transform scale-75 group-hover:scale-100 transition-transform duration-300">
                        <Play className="w-5 h-5 fill-white ml-0.5" />
                      </div>
                    </div>

                    {/* Top Badges */}
                    <div className="absolute top-3 inset-x-3 flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold bg-white/92 text-slate-800 dark:bg-slate-900/92 dark:text-white backdrop-blur-xs shadow-xs">
                        {lesson.subject}
                      </span>

                      {isFirst && (
                        <span className="px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold bg-amber-500 text-white shadow-xs">
                          {isAr ? 'مميز' : 'Featured'}
                        </span>
                      )}
                      {isSecond && (
                        <span className="px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold bg-amber-600 text-white shadow-xs">
                          {isAr ? 'الأكثر مشاهدة' : 'Popular'}
                        </span>
                      )}
                      {!isFirst && !isSecond && (
                        <span className="px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold bg-emerald-600 text-white shadow-xs">
                          {isAr ? 'جديد' : 'New'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      {/* Grade & Views row */}
                      <div className="flex items-center gap-1.5 text-xs text-amber-500 font-mono-numbers">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span className="font-bold">{lesson.grade}</span>
                        <span className="text-slate-400 font-tajawal text-[11px]">
                          ({lesson.viewsCount || 0} {isAr ? 'مشاهدة' : 'views'})
                        </span>
                      </div>

                      {/* Course Title */}
                      <h3 className="text-base font-cairo font-bold text-slate-900 dark:text-white mt-2 group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors leading-snug">
                        {lesson.title}
                      </h3>

                      {/* Teacher name */}
                      <p className="text-xs text-slate-500 font-tajawal mt-1">
                        {lesson.teacherName}
                      </p>

                      {/* Duration / Lessons Count */}
                      <div className="mt-3 flex items-center gap-3 text-xs text-slate-400 font-tajawal font-mono-numbers">
                        <span className="flex items-center gap-1">
                          <BookOpen className="w-3.5 h-3.5" />
                          {lesson.durationOrPages}
                        </span>
                        <span>·</span>
                        <span>{lesson.unit}</span>
                      </div>
                    </div>

                    {/* Card Bottom: Format & Detail Action */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400">
                        {isAr ? slider.footerBrandNameAr || 'منصة الشريف' : 'Al-Sharif'}
                      </span>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenLessonDetails(lesson);
                        }}
                        className="flex items-center gap-1 text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400 group-hover:text-emerald-800 transition-colors cursor-pointer"
                      >
                        <span>{isAr ? 'تفاصيل الدرس' : 'Details'}</span>
                        <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 4. TRACKS & CATEGORIES SECTION (مسارات المواد الدراسية من قاعدة البيانات) */}
      <section className="hp-reveal-section space-y-8 relative">
        {isAdminUser && (
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل نصوص قسم المسارات' : 'Edit Tracks Section'}</span>
            </button>
          </div>
        )}

        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">
            {isAr
              ? slider.tracksKickerAr || 'اكتشف المواد الدراسية في قاعدة البيانات'
              : 'Explore Subjects in Database'}
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-cairo font-black text-slate-900 dark:text-white">
            {isAr
              ? slider.tracksTitleAr || 'مسارات تبدأ بفضول وتنتهي بمهارة'
              : 'Tracks That Start with Curiosity'}
          </h2>
        </div>

        {dbSubjects.length === 0 ? (
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-xs sm:text-sm text-slate-500 font-tajawal">
            {isAr
              ? slider.tracksEmptyDescAr ||
                'ستظهر مسارات المواد الدراسية هنا تلقائياً فور إضافة الدروس في قاعدة البيانات.'
              : 'Subject tracks will appear automatically once lessons are added to the database.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {dbSubjects.map((item, idx) => {
              const icons = [Palette, Code2, TrendingUp, Megaphone];
              const IconComp = icons[idx % icons.length];
              return (
                <div
                  key={item.subject}
                  onClick={() => {
                    setSelectedSubject(item.subject);
                    document.getElementById('courses-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hp-card-interactive group p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 cursor-pointer shadow-xs flex flex-col justify-between relative overflow-hidden"
                >
                  <div className="absolute -top-10 -left-10 w-24 h-24 rounded-full bg-emerald-500/5 group-hover:bg-emerald-500/15 transition-colors duration-500 blur-xl pointer-events-none" />
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 group-hover:bg-[#0c3d36] group-hover:text-white flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 shadow-2xs">
                    <IconComp className="w-6 h-6" />
                  </div>

                  <div>
                    <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {item.subject}
                    </h3>
                    <div className="flex items-center justify-between text-xs text-slate-400 font-tajawal mt-1">
                      <span className="font-mono-numbers">
                        <AnimatedStatValue value={item.lessonCount} />{' '}
                        {isAr ? 'دروس في قاعدة البيانات' : 'lessons in DB'}
                      </span>
                      <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 5. VALUE PROPOSITION SPLIT (لماذا منصة الشريف؟ كل ما تحتاجه لتستمر في التقدّم) */}
      <section className="hp-reveal-section p-5 sm:p-8 lg:p-12 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
        <div className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-emerald-100/40 dark:bg-emerald-950/30 blur-3xl pointer-events-none hp-animate-aurora" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          {/* Right Column: Features List */}
          <div className="lg:col-span-7 space-y-6">
            <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">
              {isAr ? slider.whyKickerAr || 'لماذا منصة الشريف؟' : 'Why Al-Sharif Platform?'}
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-cairo font-black text-slate-900 dark:text-white leading-tight">
              {isAr
                ? slider.whyTitleAr || 'كل ما تحتاجه لتستمر في التقدّم'
                : 'Everything You Need to Keep Advancing'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 font-tajawal">
              {isAr
                ? slider.whySubtitleAr || 'نبني تجربة التعلّم حول وقتك وأهدافك، لا العكس.'
                : 'We build learning around your goals.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="hp-card-interactive group p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 hover:border-emerald-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 flex items-center justify-center text-sm transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                    {slider.whyFeature1Icon || '📅'}
                  </div>
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors">
                    {isAr ? slider.whyFeature1TitleAr || 'تعلم بمرونة' : 'Flexible Learning'}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal leading-relaxed">
                  {isAr
                    ? slider.whyFeature1DescAr ||
                      'دروس قصيرة ومنظمة يمكنك متابعتها في أي وقت ومن أي جهاز.'
                    : 'Bite-sized structured lessons accessible on any device.'}
                </p>
              </div>

              <div className="hp-card-interactive group p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 hover:border-blue-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-700 flex items-center justify-center text-sm transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                    {slider.whyFeature2Icon || '🎓'}
                  </div>
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400 transition-colors">
                    {isAr ? slider.whyFeature2TitleAr || 'خبراء حقيقيون' : 'Real Experts'}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal leading-relaxed">
                  {isAr
                    ? slider.whyFeature2DescAr ||
                      'تعلم من ممارسين ينقلون لك خبرة السوق، لا المعلومات النظرية فقط.'
                    : 'Learn from seasoned practitioners with actual market experience.'}
                </p>
              </div>

              <div className="hp-card-interactive group p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 hover:border-amber-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-700 flex items-center justify-center text-sm transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                    {slider.whyFeature3Icon || '⚡'}
                  </div>
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors">
                    {isAr
                      ? slider.whyFeature3TitleAr || 'تطبيق من اليوم الأول'
                      : 'Hands-on Practice'}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal leading-relaxed">
                  {isAr
                    ? slider.whyFeature3DescAr ||
                      'مشاريع واختبارات تفاعلية تساعدك على تحويل المعرفة إلى مهارة.'
                    : 'Interactive quizzes and projects translating theory into mastery.'}
                </p>
              </div>

              <div className="hp-card-interactive group p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 hover:border-purple-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-700 flex items-center justify-center text-sm transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                    {slider.whyFeature4Icon || '📊'}
                  </div>
                  <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white group-hover:text-purple-700 dark:group-hover:text-purple-400 transition-colors">
                    {isAr ? slider.whyFeature4TitleAr || 'تقدم يمكنك قياسه' : 'Measurable Growth'}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal leading-relaxed">
                  {isAr
                    ? slider.whyFeature4DescAr ||
                      'تابع إنجازك، حافظ على استمراريتك، واحتفل بكل مرحلة.'
                    : 'Track milestones, maintain discipline, and celebrate achievement.'}
                </p>
              </div>
            </div>
          </div>

          {/* Left Column: Image with Floating "أحسنت! حققت هدفك الأسبوعي" Trophy Card */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="group relative w-full max-w-[360px] h-[280px] sm:h-[340px] lg:h-[380px] rounded-3xl overflow-hidden shadow-xl border-4 border-white dark:border-slate-800">
              <img
                src={
                  slider.whyImageUrl ||
                  '/assets/images/hero_school_platform_1794403365692.jpg'
                }
                alt={slider.whyImageAlt || 'Students collaborating'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
              />

              {/* Floating Trophy Celebration Card */}
              <div className="hp-animate-float absolute bottom-6 left-4 p-3 rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center text-lg shadow-2xs">
                  {slider.whyTrophyIcon || '🏆'}
                </div>
                <div>
                  <h4 className="font-cairo font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                    {isAr ? slider.whyTrophyTitleAr || 'أحسنت!' : 'Well done!'}
                  </h4>
                  <p className="text-[11px] text-slate-500 font-tajawal">
                    {isAr ? slider.whyTrophyDescAr || 'حققت هدفك الأسبوعي' : 'Achieved weekly target'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. TESTIMONIAL SECTION (قصص من مجتمعنا - حين يتحوّل التعلّم إلى فرصة) */}
      <section className="hp-reveal-section space-y-8 text-center max-w-3xl mx-auto relative">
        {isAdminUser && (
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل قسم قصص من مجتمعنا' : 'Edit Testimonial Section'}</span>
            </button>
          </div>
        )}

        <div>
          <span className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">
            {isAr ? slider.testimonialKickerAr || 'قصص من مجتمعنا' : 'Student Stories'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-cairo font-black text-slate-900 dark:text-white mt-1">
            {isAr
              ? slider.testimonialTitleAr || 'حين يتحوّل التعلّم إلى فرصة'
              : 'When Learning Turns into Opportunity'}
          </h2>
        </div>

        {/* Testimonial Quote Card matching design */}
        <div className="hp-card-interactive p-5 sm:p-8 lg:p-10 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs relative overflow-hidden">
          <Quote className="w-10 h-10 text-emerald-100 dark:text-emerald-950 mx-auto mb-4 hp-animate-float" />

          <p className="text-base sm:text-lg text-slate-700 dark:text-slate-200 font-tajawal leading-relaxed">
            {isAr
              ? slider.testimonialQuoteAr ||
                '«لم تكن الدورة مجرد فيديوهات. المشاريع والتغذية الراجعة جعلتني أبني ملف أعمال حقيقياً، وبعد شهرين حصلت على أول فرصة في مجال تصميم المنتجات.»'
              : '«The course was not just passive videos. The feedback and projects enabled me to build a real portfolio and land my first role within two months.»'}
          </p>

          <div className="mt-6 flex flex-col items-center gap-1.5">
            <img
              src={
                slider.testimonialAvatarUrl ||
                '/assets/images/avatar_teacher_female_1794403365703.jpg'
              }
              alt={slider.testimonialAuthorNameAr || 'Sarah Khaled'}
              className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500 shadow-md transition-transform duration-300 hover:scale-110"
            />
            <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white mt-1">
              {isAr ? slider.testimonialAuthorNameAr || 'سارة خالد' : 'Sara Khaled'}
            </h4>
            <span className="text-xs text-slate-400 font-tajawal">
              {isAr
                ? slider.testimonialAuthorRoleAr || 'مصممة منتجات رقمية'
                : 'Digital Product Designer'}
            </span>

            {/* 5 Stars */}
            <div className="flex items-center gap-1 text-amber-400 mt-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className="w-4 h-4 fill-amber-400 text-amber-400 transition-transform hover:scale-125"
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 7. NEWSLETTER CTA BANNER (خطوتك القادمة تبدأ من بريدك) */}
      <section className="hp-reveal-section rounded-3xl bg-[#0c3d36] text-white p-6 sm:p-10 lg:p-12 shadow-xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-emerald-400/15 blur-3xl pointer-events-none hp-animate-aurora" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 rounded-full bg-amber-400/15 blur-3xl pointer-events-none hp-animate-float-delayed" />

        {isAdminUser && (
          <div className="relative z-10 mb-4 flex justify-end">
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل قسم النشرة البريدية' : 'Edit Newsletter Section'}</span>
            </button>
          </div>
        )}

        <div className="relative z-10 max-w-2xl mx-auto text-center space-y-4">
          <h2 className="text-2xl sm:text-3xl font-cairo font-black text-white">
            {isAr
              ? slider.newsletterTitleAr || 'خطوتك القادمة تبدأ من بريدك'
              : 'Your Next Step Starts in Your Inbox'}
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/90 font-tajawal leading-relaxed">
            {isAr
              ? slider.newsletterSubtitleAr ||
                'نشرة أسبوعية مختصرة: دورات جديدة، نصائح عملية، وفرص تستحق وقتك.'
              : 'Concise weekly digest: new courses, practical tips, and high-value opportunities.'}
          </p>

          {newsletterSubscribed ? (
            <div className="p-3 bg-emerald-800 text-emerald-100 rounded-xl text-xs font-bold font-cairo flex items-center justify-center gap-2 hp-hero-enter">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span>{isAr ? 'شكراً لاشتراكك! ستصلك رسالة الترحيب قريباً.' : 'Subscribed successfully!'}</span>
            </div>
          ) : (
            <form onSubmit={handleNewsletterSubmit} className="pt-2 flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
              <input
                type="email"
                required
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder={
                  isAr ? slider.newsletterPlaceholderAr || 'البريد الإلكتروني' : 'Enter your email'
                }
                className="flex-1 px-4 py-3 rounded-xl bg-white text-slate-900 placeholder:text-slate-400 text-xs sm:text-sm font-tajawal focus:outline-hidden focus:ring-2 focus:ring-amber-400 transition-shadow"
              />
              <button
                type="submit"
                className="hp-btn-shimmer px-6 py-3 rounded-xl bg-[#f59e0b] hover:bg-[#d97706] text-slate-950 font-cairo font-bold text-xs sm:text-sm transition-all duration-300 hover:-translate-y-0.5 shadow-md cursor-pointer"
              >
                {isAr ? slider.newsletterBtnTextAr || 'اشترك الآن' : 'Subscribe'}
              </button>
            </form>
          )}
        </div>
      </section>

      {/* 8. DARK OBSIDIAN FOOTER (Identical to Attached Design: #092422) */}
      <footer className="hp-reveal-section rounded-3xl bg-[#092422] text-white p-6 sm:p-10 lg:p-12 space-y-8 relative overflow-hidden">
        {isAdminUser && (
          <div className="pb-4 border-b border-white/10 flex items-center justify-between gap-2">
            <span className="text-xs font-cairo font-bold text-emerald-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              {isAr
                ? 'تحكم الأدمن في بيانات الفوتر والروابط وحقوق الملكية'
                : 'Admin Control: Edit Footer Brand, Links & Copyright'}
            </span>
            <button
              type="button"
              onClick={() => {
                setDraftSlider(slider);
                setIsSliderEditorOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isAr ? 'تعديل بيانات الفوتر' : 'Edit Footer'}</span>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {/* Brand Col */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-cairo font-black text-xl text-white">
                {isAr ? slider.footerBrandNameAr || 'منصة الشريف' : 'Al-Sharif Platform'}
              </span>
            </div>
            <p className="text-xs text-slate-300 font-tajawal leading-relaxed">
              {isAr
                ? slider.footerBrandDescAr ||
                  'تعلّم مستمر يصنع مستقبلاً أوسع. محتوى عربي احترافي لكل طموح عبر منصة الشريف.'
                : 'Continuous learning building wider horizons. Professional Arabic content for every ambition.'}
            </p>
          </div>

          {/* Links 1: Platform */}
          <div>
            <h4 className="font-cairo font-bold text-sm text-white mb-3">
              {isAr ? slider.footerCol1TitleAr || 'المنصة' : 'Platform'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-300 font-tajawal">
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol1Link1Url || '#auth')}
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol1Link1TextAr || 'عن منصة الشريف' : 'About Al-Sharif'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() =>
                    handleSliderButtonClick(slider.footerCol1Link2Url || '#courses-section')
                  }
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol1Link2TextAr || 'الدورات' : 'Courses'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol1Link3Url || '#auth')}
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol1Link3TextAr || 'المدربون' : 'Instructors'}
                </button>
              </li>
            </ul>
          </div>

          {/* Links 2: Support */}
          <div>
            <h4 className="font-cairo font-bold text-sm text-white mb-3">
              {isAr ? slider.footerCol2TitleAr || 'الدعم' : 'Support'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-300 font-tajawal">
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol2Link1Url || '#auth')}
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol2Link1TextAr || 'مركز المساعدة' : 'Help Center'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol2Link2Url || '#auth')}
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol2Link2TextAr || 'الأسئلة الشائعة' : 'FAQs'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol2Link3Url || '#auth')}
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol2Link3TextAr || 'تواصل معنا' : 'Contact Us'}
                </button>
              </li>
            </ul>
          </div>

          {/* Links 3: Legal & Portal Shortcuts */}
          <div>
            <h4 className="font-cairo font-bold text-sm text-white mb-3">
              {isAr ? slider.footerCol3TitleAr || 'قانوني وبوابات الدخول' : 'Legal & Portals'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-300 font-tajawal">
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol3Link1Url || '#auth')}
                  className="text-emerald-400 font-cairo font-bold hover:underline cursor-pointer"
                >
                  {isAr
                    ? slider.footerCol3Link1TextAr || 'دخول لوحة الأدمن (الداش بورد)'
                    : 'Admin Portal'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol3Link2Url || '#auth')}
                  className="hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol3Link2TextAr || 'بوابة المعلمين والطلاب' : 'User Portals'}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSliderButtonClick(slider.footerCol3Link3Url || '#auth')}
                  className="text-slate-400 hover:text-emerald-400 cursor-pointer"
                >
                  {isAr ? slider.footerCol3Link3TextAr || 'الخصوصية والشروط' : 'Privacy & Terms'}
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 font-tajawal gap-2">
          <p>
            {isAr
              ? slider.footerCopyrightAr || '© 2026 منصة الشريف. جميع الحقوق محفوظة.'
              : '© 2026 Al-Sharif Platform. All rights reserved.'}
          </p>
          <p>
            {isAr
              ? slider.footerTaglineAr || 'صممت لأفضل تجربة مستخدم تعليمية'
              : 'Crafted with premium UI/UX'}
          </p>
        </div>
      </footer>
    </div>
  );
};
