import express from 'express';
import {
  extractClassroomActor,
  requireClassroomActor,
  requireRoomModerator,
  signClassroomToken,
  signRoomInviteToken,
  verifyRoomInviteToken,
  type ClassroomRequestActor,
} from './authMiddleware.ts';
import { canCreateOrConfigureRoom, canModerateRoom, isLiveKitConfigured } from './config.ts';
import { allocateRoomMediaSession } from './livekitService.ts';
import { createExpressRateLimiter } from './rateLimiter.ts';
import { classroomRedis } from './redisClient.ts';
import * as roomRepo from './roomRepository.ts';
import { broadcastRoomSettingsUpdate, getRoomActiveParticipantCount } from './socketGateway.ts';
import type { ClassroomRole } from '../../src/types/classroom.ts';

export const classroomRouter = express.Router();

const generalRateLimiter = createExpressRateLimiter({
  maxRequests: 90,
  windowMs: 60_000,
  keyPrefix: 'classroom_api',
});

const joinRateLimiter = createExpressRateLimiter({
  maxRequests: 25,
  windowMs: 60_000,
  keyPrefix: 'classroom_join',
});

classroomRouter.use(generalRateLimiter);

// 1. Health & SFU / Redis Capability Diagnostics
classroomRouter.get('/health', async (_req, res) => {
  try {
    await roomRepo.ensureClassroomTables();
    res.json({
      ok: true,
      livekitConfigured: isLiveKitConfigured(),
      mediaMode: isLiveKitConfigured() ? 'livekit' : 'webrtc-p2p',
      redisConnected: classroomRedis.isRedisConnected(),
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// 2. List all live classroom sessions
classroomRouter.get('/rooms', async (_req, res) => {
  try {
    const rooms = await roomRepo.listLiveRooms();
    const enriched = rooms.map((r) => ({
      ...r,
      activeParticipantsCount: getRoomActiveParticipantCount(r.id),
    }));
    res.json({ rooms: enriched });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Get single room details by id or roomCode
classroomRouter.get('/rooms/:roomId', async (req, res) => {
  try {
    const room = await roomRepo.getLiveRoomByIdOrCode(req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'غرفة الفصل الافتراضي غير موجودة' });
    }
    res.json({
      room: {
        ...room,
        activeParticipantsCount: getRoomActiveParticipantCount(room.id),
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Create new live classroom (Teacher / Assistant / Admin only)
classroomRouter.post('/rooms', requireRoomModerator, async (req, res) => {
  try {
    const actor = (req as any).classroomActor as ClassroomRequestActor;
    const {
      title,
      subject,
      grade,
      waitingRoomEnabled = false,
      maxParticipants = 200,
      scheduledAt,
      startImmediately = true,
    } = req.body || {};

    if (!title || !String(title).trim()) {
      return res.status(400).json({ error: 'يرجى إدخال عنوان الحصة المباشرة' });
    }

    const room = await roomRepo.createLiveRoom({
      title: String(title).trim(),
      subject: String(subject || 'مادة عامة'),
      grade: String(grade || 'الثانوية العامة'),
      hostId: actor.userId,
      hostName: actor.userName,
      waitingRoomEnabled: Boolean(waitingRoomEnabled),
      maxParticipants: Number(maxParticipants || 200),
      scheduledAt: scheduledAt ? String(scheduledAt) : undefined,
      status: startImmediately ? 'live' : 'scheduled',
    });

    res.status(201).json({ ok: true, room });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Generate signed expiring room invite URL with JWT
classroomRouter.post('/rooms/:roomId/invite-link', requireRoomModerator, async (req, res) => {
  try {
    const actor = (req as any).classroomActor as ClassroomRequestActor;
    const room = await roomRepo.getLiveRoomByIdOrCode(req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'الغرفة غير موجودة' });
    }

    const requestedRole = String(req.body?.role || 'student') as ClassroomRole;
    const allowedRoles: ClassroomRole[] = ['student', 'assistant', 'teacher', 'admin'];
    const grantedRole: ClassroomRole = allowedRoles.includes(requestedRole)
      ? requestedRole
      : 'student';

    // Prevent assistant from minting admin invite links
    if (grantedRole === 'admin' && actor.role !== 'admin') {
      return res.status(403).json({ error: 'فقط المدير العام يمكنه إصدار رابط دعوة بدور Admin' });
    }

    const ttlMinutes = Math.max(5, Math.min(1440, Number(req.body?.ttlMinutes || 240)));
    const inviteToken = signRoomInviteToken(
      {
        roomId: room.id,
        roomCode: room.roomCode,
        grantedRole,
        issuedBy: actor.userId,
      },
      ttlMinutes * 60
    );

    const originHeader =
      req.headers.origin ||
      process.env.APP_URL ||
      `${req.protocol}://${req.get('host')}`;
    const cleanOrigin = originHeader.replace(/\/+$/, '');
    const inviteUrl = `${cleanOrigin}/?liveRoom=${encodeURIComponent(room.roomCode)}&invite=${encodeURIComponent(inviteToken)}`;

    res.json({
      ok: true,
      inviteToken,
      inviteUrl,
      grantedRole,
      expiresInMinutes: ttlMinutes,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Join Room (Validates signed invite token or platform actor, checks lock, issues JWT + LiveKit Token)
classroomRouter.post('/rooms/:roomId/join', joinRateLimiter, async (req, res) => {
  try {
    const room = await roomRepo.getLiveRoomByIdOrCode(req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'غرفة الفصل غير موجودة أو تم حذفها' });
    }
    if (room.status === 'ended') {
      return res.status(410).json({ error: 'انتهت هذه الحصة المباشرة بالفعل' });
    }

    const { inviteToken, guestName } = req.body || {};
    const actor = extractClassroomActor(req);

    let effectiveUserId = actor?.userId || '';
    let effectiveUserName = actor?.userName || '';
    let effectiveRole: ClassroomRole = actor?.role || 'student';

    if (inviteToken) {
      try {
        const verified = verifyRoomInviteToken(String(inviteToken));
        if (verified.roomId !== room.id && verified.roomCode !== room.roomCode) {
          return res.status(403).json({ error: 'رابط الدعوة لا يطابق هذه الغرفة' });
        }
        effectiveRole = verified.grantedRole;
        if (!effectiveUserId) {
          effectiveUserId = `inv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        }
        if (!effectiveUserName) {
          effectiveUserName = String(guestName || '').trim() || 'طالب مدعو';
        }
      } catch {
        return res.status(401).json({ error: 'رابط الدعوة منتهي الصلاحية أو غير صالح' });
      }
    } else if (!actor) {
      return res.status(401).json({
        error: 'يجب تسجيل الدخول في المنصة أو استخدام رابط دعوة موقّع للدخول إلى الفصل',
      });
    }

    const isModerator = canModerateRoom(effectiveRole);
    if (room.isLocked && !isModerator) {
      return res.status(403).json({
        error: 'تم قفل الغرفة من قِبل المعلم ولا يُسمح بدخول طلاب جدد حالياً',
      });
    }

    const activeCount = getRoomActiveParticipantCount(room.id);
    if (activeCount >= room.maxParticipants && !isModerator) {
      return res.status(429).json({
        error: 'وصلت الغرفة إلى الحد الأقصى للمشاركين، يمكنك المتابعة عبر البث التكيفي HLS',
        hlsStreamUrl: room.hlsStreamUrl || null,
      });
    }

    // Auto-transition scheduled room to live when host joins
    let currentRoom = room;
    if (room.status === 'scheduled' && canCreateOrConfigureRoom(effectiveRole)) {
      const updated = await roomRepo.updateLiveRoomSettings(room.id, { status: 'live' });
      if (updated) currentRoom = updated;
    }

    const roomToken = signClassroomToken({
      userId: effectiveUserId,
      userName: effectiveUserName,
      role: effectiveRole,
      roomId: currentRoom.id,
      roomCode: currentRoom.roomCode,
    });

    const mediaConfig = await allocateRoomMediaSession({
      roomCode: currentRoom.roomCode,
      userId: effectiveUserId,
      userName: effectiveUserName,
      role: effectiveRole,
      hlsStreamUrl: currentRoom.hlsStreamUrl,
    });

    res.json({
      ok: true,
      status: 'joined',
      room: currentRoom,
      roomToken,
      role: effectiveRole,
      user: {
        userId: effectiveUserId,
        userName: effectiveUserName,
        role: effectiveRole,
      },
      mediaConfig,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Update room flags / lifecycle (Lock, Waiting Room, Chat Mute, End Session)
classroomRouter.patch('/rooms/:roomId/settings', requireRoomModerator, async (req, res) => {
  try {
    const room = await roomRepo.getLiveRoomByIdOrCode(req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'الغرفة غير موجودة' });
    }

    const { status, isLocked, waitingRoomEnabled, chatMuted, hlsStreamUrl } = req.body || {};
    const updated = await roomRepo.updateLiveRoomSettings(room.id, {
      status,
      isLocked,
      waitingRoomEnabled,
      chatMuted,
      hlsStreamUrl,
    });

    if (updated) {
      broadcastRoomSettingsUpdate(room.id, updated);
    }

    res.json({ ok: true, room: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Delete room (Host / Admin only)
classroomRouter.delete('/rooms/:roomId', requireClassroomActor, async (req, res) => {
  try {
    const actor = (req as any).classroomActor as ClassroomRequestActor;
    const room = await roomRepo.getLiveRoomByIdOrCode(req.params.roomId);
    if (!room) {
      return res.status(404).json({ error: 'الغرفة غير موجودة' });
    }
    if (actor.role !== 'admin' && room.hostId !== actor.userId) {
      return res.status(403).json({ error: 'لا تملك صلاحية حذف هذه الغرفة' });
    }
    await roomRepo.deleteLiveRoom(room.id);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
