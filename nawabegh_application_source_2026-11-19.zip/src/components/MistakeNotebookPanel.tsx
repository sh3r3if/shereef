import React, { useMemo, useState } from 'react';
import {
  BookX,
  RotateCcw,
  CheckCircle2,
  Trash2,
  Filter,
  Sparkles,
  X,
  ArrowRight,
  HelpCircle,
} from 'lucide-react';
import type { StudentMistakeEntry } from '../types';
import { MCQ_QUESTION_BOX_CLASS, getMcqOptionSurfaceClass } from '../utils/mcqTheme';

interface MistakeNotebookPanelProps {
  mistakes: StudentMistakeEntry[];
  isLoading: boolean;
  onMarkMastered: (id: string, mastered: boolean) => Promise<void>;
  onDeleteMistake: (id: string) => Promise<void>;
  onRefresh: () => void;
}

export const MistakeNotebookPanel: React.FC<MistakeNotebookPanelProps> = ({
  mistakes,
  isLoading,
  onMarkMastered,
  onDeleteMistake,
  onRefresh,
}) => {
  const [subjectFilter, setSubjectFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'unmastered' | 'all'>('unmastered');

  // Re-test modal state
  const [isRetestOpen, setIsRetestOpen] = useState(false);
  const [retestItems, setRetestItems] = useState<StudentMistakeEntry[]>([]);
  const [retestIndex, setRetestIndex] = useState(0);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [checkedAnswer, setCheckedAnswer] = useState(false);
  const [retestStats, setRetestStats] = useState({ total: 0, masteredNow: 0 });
  const [isRetestFinished, setIsRetestFinished] = useState(false);

  const subjects = useMemo(() => {
    return Array.from(new Set(mistakes.map((m) => m.subject).filter(Boolean)));
  }, [mistakes]);

  const filteredMistakes = useMemo(() => {
    return mistakes.filter((m) => {
      if (statusFilter === 'unmastered' && m.mastered) return false;
      if (subjectFilter !== 'all' && m.subject !== subjectFilter) return false;
      return true;
    });
  }, [mistakes, statusFilter, subjectFilter]);

  const unmasteredCount = mistakes.filter((m) => !m.mastered).length;

  const handleStartMistakesRetest = () => {
    const pool = filteredMistakes.filter((m) => !m.mastered);
    const items = pool.length > 0 ? pool : filteredMistakes;
    if (items.length === 0) return;
    setRetestItems(items);
    setRetestIndex(0);
    setSelectedIdx(null);
    setCheckedAnswer(false);
    setRetestStats({ total: items.length, masteredNow: 0 });
    setIsRetestFinished(false);
    setIsRetestOpen(true);
  };

  const activeRetestQuestion = retestItems[retestIndex];

  const handleCheckRetestOption = async (optIdx: number) => {
    if (checkedAnswer || !activeRetestQuestion) return;
    setSelectedIdx(optIdx);
    setCheckedAnswer(true);
    if (optIdx === activeRetestQuestion.correctOptionIndex) {
      setRetestStats((prev) => ({ ...prev, masteredNow: prev.masteredNow + 1 }));
      if (!activeRetestQuestion.mastered) {
        await onMarkMastered(activeRetestQuestion.id, true);
      }
    }
  };

  const handleNextRetestQuestion = () => {
    if (retestIndex + 1 >= retestItems.length) {
      setIsRetestFinished(true);
    } else {
      setRetestIndex((i) => i + 1);
      setSelectedIdx(null);
      setCheckedAnswer(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="p-5 md:p-6 rounded-2xl bg-gradient-to-l from-rose-900 via-slate-900 to-emerald-950 text-white shadow-md flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-amber-300 text-xs font-bold font-cairo">
            <BookX className="w-3.5 h-3.5" />
            <span>دفتر الأخطاء الذكي التلقائي</span>
          </div>
          <h3 className="text-xl font-black font-cairo">
            مراجعة أخطاء الاختبارات والمسابقات لتثبيت المعلومة
          </h3>
          <p className="text-xs sm:text-sm text-slate-200 font-tajawal">
            يتم تجميع كل سؤال أخطأت فيه تلقائياً هنا مع التفسير، وعند الإجابة عليه صحيحاً في إعادة الاختبار ينتقل لحالة «تم الإتقان».
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0 font-cairo">
          <button
            type="button"
            disabled={filteredMistakes.length === 0}
            onClick={handleStartMistakesRetest}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-black text-sm shadow-lg transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>أعد اختباري في أخطائي فقط ({unmasteredCount || filteredMistakes.length})</span>
          </button>
          <button
            type="button"
            onClick={onRefresh}
            className="px-3.5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/15"
          >
            تحديث
          </button>
        </div>
      </div>

      {/* Filters Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 font-cairo text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-slate-500 font-bold flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            الحالة:
          </span>
          <button
            type="button"
            onClick={() => setStatusFilter('unmastered')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              statusFilter === 'unmastered'
                ? 'bg-rose-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            أخطاء تحتاج مراجعة ({unmasteredCount})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              statusFilter === 'all'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            كل السجل ({mistakes.length})
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-bold">المادة:</span>
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold text-slate-800 dark:text-white outline-none"
          >
            <option value="all">جميع المواد</option>
            {subjects.map((sub) => (
              <option key={sub} value={sub}>
                {sub}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Mistakes List */}
      {isLoading ? (
        <div className="p-8 text-center text-sm text-slate-500 font-cairo">
          جارٍ تحميل دفتر الأخطاء من قاعدة البيانات...
        </div>
      ) : filteredMistakes.length === 0 ? (
        <div className="p-10 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-center space-y-2">
          <Sparkles className="w-10 h-10 text-emerald-600 mx-auto" />
          <h4 className="font-black text-lg font-cairo text-emerald-900 dark:text-emerald-200">
            سجلك نظيف ومتميز!
          </h4>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 font-tajawal">
            لا توجد أسئلة خاطئة غير متقنة في هذا التصنيف حالياً. أي خطأ في الاختبارات أو المسابقات سيظهر هنا تلقائياً لمراجعته.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredMistakes.map((m) => (
            <div
              key={m.id}
              className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2 font-cairo text-xs">
                  <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
                    {m.subject}
                  </span>
                  {m.quizTitle && (
                    <span className="px-2.5 py-1 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 font-bold">
                      {m.quizTitle}
                    </span>
                  )}
                  <span className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-bold">
                    تكرار الخطأ: {m.wrongCount}
                  </span>
                  {m.mastered && (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> تم الإتقان
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 font-cairo text-xs">
                  <button
                    type="button"
                    onClick={() => onMarkMastered(m.id, !m.mastered)}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
                      m.mastered
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {m.mastered ? 'إعادة لقائمة المراجعة' : 'تحديد كمتقن ✓'}
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteMistake(m.id)}
                    className="p-1.5 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    title="حذف من الدفتر"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className={MCQ_QUESTION_BOX_CLASS}>
                <p className="font-bold text-sm sm:text-base font-cairo leading-relaxed">
                  {m.question}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {m.options.map((opt, idx) => {
                  const isCorrect = idx === m.correctOptionIndex;
                  const isUserWrong = idx === m.selectedOptionIndex && !isCorrect;
                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border text-xs sm:text-sm font-tajawal flex items-center justify-between gap-2 ${getMcqOptionSurfaceClass(
                        idx,
                        {
                          isChecked: true,
                          isCorrect,
                          isSelected: isUserWrong,
                          dimUnselectedWhenChecked: !isCorrect && !isUserWrong,
                        }
                      )}`}
                    >
                      <span>{opt}</span>
                      {isCorrect && <span className="text-[11px] font-black text-emerald-700 dark:text-emerald-300">✓ الإجابة الصحيحة</span>}
                      {isUserWrong && <span className="text-[11px] font-black text-rose-700 dark:text-rose-300">✗ اختيارك السابق</span>}
                    </div>
                  );
                })}
              </div>

              {m.explanation && (
                <div className="p-3 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 text-xs text-amber-950 dark:text-amber-200 font-tajawal flex items-start gap-2">
                  <HelpCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>التفسير العلمي:</strong> {m.explanation}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Re-test Mistakes Modal */}
      {isRetestOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 bg-gradient-to-l from-amber-600 to-emerald-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2 font-cairo">
                <RotateCcw className="w-5 h-5" />
                <h4 className="font-black text-base">اختبار تثبيت الأخطاء فقط</h4>
              </div>
              <button
                type="button"
                onClick={() => setIsRetestOpen(false)}
                className="p-1.5 rounded-xl bg-white/15 hover:bg-white/25"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 sm:p-6 space-y-5">
              {isRetestFinished ? (
                <div className="text-center space-y-4 py-4">
                  <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
                  <h5 className="text-xl font-black font-cairo text-slate-900 dark:text-white">
                    انتهى اختبار مراجعة الأخطاء!
                  </h5>
                  <p className="text-sm font-tajawal text-slate-600 dark:text-slate-300">
                    أجبت بشكل صحيح على{' '}
                    <strong className="text-emerald-600 font-mono-numbers">
                      {retestStats.masteredNow}
                    </strong>{' '}
                    من أصل{' '}
                    <strong className="font-mono-numbers">{retestStats.total}</strong> سؤالاً
                    وتم تحديث حالتها إلى «تم الإتقان».
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsRetestOpen(false)}
                    className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black font-cairo text-sm"
                  >
                    العودة لدفتر الأخطاء
                  </button>
                </div>
              ) : activeRetestQuestion ? (
                <>
                  <div className="flex items-center justify-between text-xs font-cairo text-slate-500">
                    <span className="font-bold text-emerald-700 dark:text-emerald-400">
                      المادة: {activeRetestQuestion.subject}
                    </span>
                    <span className="font-bold">
                      السؤال {retestIndex + 1} من {retestItems.length}
                    </span>
                  </div>

                  <div className={MCQ_QUESTION_BOX_CLASS}>
                    <p className="font-bold text-base font-cairo leading-relaxed">
                      {activeRetestQuestion.question}
                    </p>
                  </div>

                  <div className="space-y-2.5">
                    {activeRetestQuestion.options.map((opt, idx) => (
                      <button
                        key={idx}
                        type="button"
                        disabled={checkedAnswer}
                        onClick={() => handleCheckRetestOption(idx)}
                        className={`w-full text-right p-3.5 rounded-xl border font-tajawal text-sm transition-all ${getMcqOptionSurfaceClass(
                          idx,
                          {
                            isSelected: selectedIdx === idx,
                            isChecked: checkedAnswer,
                            isCorrect: idx === activeRetestQuestion.correctOptionIndex,
                            dimUnselectedWhenChecked: true,
                          }
                        )}`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>

                  {checkedAnswer && (
                    <div className="space-y-3">
                      {activeRetestQuestion.explanation && (
                        <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 text-xs font-tajawal text-amber-950 dark:text-amber-200">
                          <strong>التفسير:</strong> {activeRetestQuestion.explanation}
                        </div>
                      )}
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={handleNextRetestQuestion}
                          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black font-cairo text-sm"
                        >
                          <span>
                            {retestIndex + 1 >= retestItems.length ? 'عرض النتيجة' : 'السؤال التالي'}
                          </span>
                          <ArrowRight className="w-4 h-4 rotate-180" />
                        </button>
                      </div>
                    </div>
                  )}
                </>
              ) : null}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
