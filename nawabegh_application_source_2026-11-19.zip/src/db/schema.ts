import { boolean, integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

// 1. Members / Users table with RBAC and Permissions
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID or internal unique identifier
  email: text('email').notNull(),
  displayName: text('display_name').notNull(),
  displayNameEn: text('display_name_en'),
  username: text('username'),
  password: text('password').default('123456'),
  securityQuestion: text('security_question').default('ما هو اسم مدرستك الابتدائية؟'),
  securityAnswer: text('security_answer').default('نوابغ'),
  role: text('role').notNull().default('student'), // 'admin' | 'teacher' | 'student' | 'parent' | 'supervisor'
  roleTitle: text('role_title').default('عضو'),
  phone: text('phone'),
  permissions: text('permissions').default('[]'), // JSON array of granted permission keys
  isActive: boolean('is_active').default(true),
  avatar: text('avatar'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 2. Students table
export const students = pgTable('students', {
  id: text('id').primaryKey(),
  code: text('code').notNull(),
  name: text('name').notNull(),
  nameEn: text('name_en'),
  grade: text('grade').notNull(),
  type: text('type').notNull().default('online'), // 'online' | 'offline'
  parentName: text('parent_name'),
  parentPhone: text('parent_phone'),
  parentEmail: text('parent_email'),
  overallScore: integer('overall_score').default(85),
  attendanceRate: integer('attendance_rate').default(95),
  status: text('status').default('regular'), // 'top' | 'regular' | 'weak'
  notes: text('notes'),
  registeredDate: text('registered_date'),
  city: text('city'),
  avatar: text('avatar'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 3. Teachers table
export const teachers = pgTable('teachers', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  nameEn: text('name_en'),
  specialty: text('specialty').notNull(),
  specialtyEn: text('specialty_en'),
  email: text('email').notNull(),
  phone: text('phone'),
  avatar: text('avatar'),
  grades: text('grades').default('[]'), // JSON array of grades taught
  rating: text('rating').default('4.9'),
  totalStudents: integer('total_students').default(0),
  activeLessonsCount: integer('active_lessons_count').default(0),
  bio: text('bio'),
  joinedDate: text('joined_date'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 4. Lessons table
export const lessons = pgTable('lessons', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  titleEn: text('title_en'),
  subject: text('subject').notNull(),
  grade: text('grade').notNull(),
  teacherId: text('teacher_id'),
  teacherName: text('teacher_name').notNull(),
  format: text('format').notNull().default('video'), // 'video' | 'pdf' | 'word' | 'infographic'
  durationOrPages: text('duration_or_pages'),
  videoUrl: text('video_url'),
  documentUrl: text('document_url'),
  description: text('description'),
  viewsCount: integer('views_count').default(0),
  likesCount: integer('likes_count').default(0),
  thumbnail: text('thumbnail'),
  isPublished: boolean('is_published').default(true),
  unit: text('unit'),
  contentHtml: text('content_html'),
  infographicData: text('infographic_data'), // JSON string
  createdAt: timestamp('created_at').defaultNow(),
});

// 5. Quizzes table
export const quizzes = pgTable('quizzes', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  subject: text('subject').notNull(),
  grade: text('grade').notNull(),
  type: text('type').default('weekly'), // 'weekly' | 'monthly'
  durationMinutes: integer('duration_minutes').default(30),
  totalMarks: integer('total_marks').default(100),
  questions: text('questions').default('[]'), // JSON array of questions
  dueDate: text('due_date'),
  completedStudentsCount: integer('completed_students_count').default(0),
  averageScore: integer('average_score').default(80),
  teacherId: text('teacher_id').default(''),
  teacherName: text('teacher_name').default(''),
  createdAt: timestamp('created_at').defaultNow(),
});

// 5c. Assignments / Homework table (الواجبات المنزلية)
export const assignments = pgTable('assignments', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description').default(''),
  instructions: text('instructions').default(''),
  subject: text('subject').notNull(),
  grade: text('grade').notNull(),
  unit: text('unit').default(''),
  lessonId: text('lesson_id').default(''),
  lessonTitle: text('lesson_title').default(''),
  teacherId: text('teacher_id').default(''),
  teacherName: text('teacher_name').notNull(),
  attachmentUrl: text('attachment_url'),
  attachmentName: text('attachment_name'),
  dueDate: text('due_date').notNull(),
  maxMarks: integer('max_marks').notNull().default(20),
  isPublished: boolean('is_published').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// 5d. Assignment Submissions table (حلول وتسليمات الطلاب للواجبات)
export const assignmentSubmissions = pgTable('assignment_submissions', {
  id: text('id').primaryKey(),
  assignmentId: text('assignment_id').notNull(),
  studentId: text('student_id').notNull(),
  studentName: text('student_name').notNull(),
  studentCode: text('student_code').default(''),
  answerText: text('answer_text').default(''),
  attachmentUrl: text('attachment_url'),
  attachmentName: text('attachment_name'),
  score: integer('score'),
  feedback: text('feedback').default(''),
  status: text('status').notNull().default('submitted'), // 'submitted' | 'graded'
  submittedAt: text('submitted_at').notNull(),
  gradedAt: text('graded_at').default(''),
  createdAt: timestamp('created_at').defaultNow(),
});

// 5b. Quiz Attempts / Recorded Student Exam Scores table (درجات الامتحانات الأسبوعية والشهرية المسجلة)
export const quizAttempts = pgTable('quiz_attempts', {
  id: text('id').primaryKey(),
  quizId: text('quiz_id').notNull(),
  quizTitle: text('quiz_title').notNull(),
  quizType: text('quiz_type').notNull().default('weekly'), // 'weekly' | 'monthly'
  subject: text('subject').notNull(),
  grade: text('grade').notNull(),
  studentId: text('student_id').notNull(),
  studentName: text('student_name').notNull(),
  studentCode: text('student_code'),
  earnedMarks: integer('earned_marks').notNull().default(0),
  totalMarks: integer('total_marks').notNull().default(100),
  percentage: integer('percentage').notNull().default(0),
  correctCount: integer('correct_count').notNull().default(0),
  totalQuestions: integer('total_questions').notNull().default(1),
  takenDate: text('taken_date').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// 6. Certificates table
export const certificates = pgTable('certificates', {
  id: text('id').primaryKey(),
  studentId: text('student_id').notNull(),
  studentName: text('student_name').notNull(),
  studentGrade: text('student_grade').notNull(),
  type: text('type').notNull().default('excellence'), // 'excellence' | 'grades_report'
  subjectOrTrack: text('subject_or_track'),
  score: integer('score').default(100),
  issueDate: text('issue_date'),
  academicYear: text('academic_year'),
  principalName: text('principal_name'),
  notes: text('notes'),
  serialNumber: text('serial_number'),
  examPeriod: text('exam_period').default('all'), // 'weekly' | 'monthly' | 'all'
  weeklyAverage: integer('weekly_average'),
  monthlyAverage: integer('monthly_average'),
  examsCount: integer('exams_count').default(0),
  breakdownJson: text('breakdown_json').default('[]'),
  isAutoGenerated: boolean('is_auto_generated').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

// 7. System Backups table
export const backups = pgTable('backups', {
  id: text('id').primaryKey(),
  type: text('type').notNull(), // 'database' | 'application'
  filename: text('filename').notNull(),
  size: text('size').notNull(),
  recordCount: integer('record_count').default(0),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 8. System Audit Logs table
export const auditLogs = pgTable('audit_logs', {
  id: text('id').primaryKey(),
  action: text('action').notNull(),
  actionAr: text('action_ar').notNull(),
  entityType: text('entity_type').notNull(),
  entityName: text('entity_name').notNull(),
  performedBy: text('performed_by').notNull(),
  timestamp: text('timestamp').notNull(),
  details: text('details'),
  severity: text('severity').default('info'),
});

// 9. Timetable table (تنظيم وجدولة الحصص والمقررات الدراسية)
export const timetable = pgTable('timetable', {
  id: text('id').primaryKey(),
  day: text('day').notNull(),
  dayAr: text('day_ar').notNull(),
  time: text('time').notNull(),
  subject: text('subject').notNull(),
  courseTitle: text('course_title').default(''),
  teacherId: text('teacher_id').default(''),
  teacherName: text('teacher_name').notNull(),
  lessonId: text('lesson_id').default(''),
  lessonTitle: text('lesson_title').default(''),
  grade: text('grade').notNull(),
  semester: text('semester').default('الفصل الدراسي الأول'),
  type: text('type').notNull().default('online'), // 'online' | 'offline'
  roomOrLink: text('room_or_link').notNull(),
  status: text('status').notNull().default('scheduled'), // 'scheduled' | 'live' | 'completed' | 'cancelled'
  capacity: integer('capacity').default(30),
  notes: text('notes').default(''),
  createdAt: timestamp('created_at').defaultNow(),
});

// 10. Tuition Invoices table (منظومة الدفع الإلكتروني والرسوم الدراسية)
export const invoices = pgTable('invoices', {
  id: text('id').primaryKey(),
  invoiceNumber: text('invoice_number').notNull(),
  studentId: text('student_id').notNull(),
  studentName: text('student_name').notNull(),
  grade: text('grade').notNull(),
  amount: integer('amount').notNull(),
  currency: text('currency').default('SAR'),
  dueDate: text('due_date').notNull(),
  status: text('status').notNull().default('pending'), // 'paid' | 'pending' | 'overdue'
  paymentMethod: text('payment_method'), // 'mada' | 'visa' | 'apple_pay' | 'cash'
  paidDate: text('paid_date'),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 11. Notifications table (الإشعارات الدورية)
export const notifications = pgTable('notifications', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  message: text('message').notNull(),
  target: text('target').notNull().default('all'), // 'all' | 'students' | 'parents' | 'students_parents' | 'weak_students' | 'top_students'
  category: text('category').notNull().default('general'), // 'academic' | 'financial' | 'attendance' | 'general'
  relatedType: text('related_type').default('general'), // 'lesson' | 'assignment' | 'quiz_weekly' | 'quiz_monthly' | 'general'
  relatedId: text('related_id').default(''),
  createdAt: text('created_at').notNull(),
  read: boolean('read').default(false),
});

// 12. FAQ table (مركز الاستفسارات - الأسئلة الشائعة)
export const faqs = pgTable('faqs', {
  id: text('id').primaryKey(),
  questionAr: text('question_ar').notNull(),
  questionEn: text('question_en').notNull(),
  answerAr: text('answer_ar').notNull(),
  answerEn: text('answer_en').notNull(),
  category: text('category').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// 12b. Inquiries table (الاستفسارات المباشرة والردود الرسمية)
export const inquiries = pgTable('inquiries', {
  id: text('id').primaryKey(),
  senderName: text('sender_name').notNull(),
  senderRole: text('sender_role').notNull().default('student'), // 'student' | 'parent' | 'teacher' | 'visitor'
  senderContact: text('sender_contact').default(''),
  subject: text('subject').notNull(),
  message: text('message').notNull(),
  category: text('category').notNull().default('general'), // 'academic' | 'financial' | 'technical' | 'general'
  priority: text('priority').notNull().default('normal'), // 'low' | 'normal' | 'high' | 'urgent'
  status: text('status').notNull().default('pending'), // 'pending' | 'answered' | 'closed'
  replyText: text('reply_text').default(''),
  repliedBy: text('replied_by').default(''),
  repliedAt: text('replied_at').default(''),
  createdAt: text('created_at').notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 13. School Customization Settings table (تخصيص هوية المدرسة والأكاديمية)
export const schoolSettings = pgTable('school_settings', {
  id: text('id').primaryKey().default('main_school'),
  schoolName: text('school_name').notNull(),
  schoolNameEn: text('school_name_en'),
  tagline: text('tagline'),
  primaryColor: text('primary_color').default('#0f5132'),
  logoUrl: text('logo_url'),
  academicYear: text('academic_year').default('2026 - 2027'),
  enableInstantNotifications: boolean('enable_instant_notifications').default(true),
  enableRealtimeSync: boolean('enable_realtime_sync').default(true),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 14. Key-Value System Settings table
export const systemSettings = pgTable('system_settings', {
  key: text('key').primaryKey(),
  value: text('value').notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 15. Conversations & Groups table (منظومة الشات المنظم: طالب<->معلم، ولي أمر<->معلم، معلم<->إدارة، مجموعات خاصة وعامة)
export const parentConversations = pgTable('parent_conversations', {
  id: text('id').primaryKey(),
  channelType: text('channel_type').notNull().default('parent_teacher'), // 'student_teacher' | 'parent_teacher' | 'teacher_admin' | 'private_group' | 'public_group'
  title: text('title').default(''),
  description: text('description').default(''),
  studentId: text('student_id').notNull().default(''),
  studentName: text('student_name').notNull(),
  studentGrade: text('student_grade').default(''),
  teacherId: text('teacher_id').default(''),
  teacherName: text('teacher_name').default(''),
  adminName: text('admin_name').default(''),
  parentName: text('parent_name').notNull(),
  parentPhone: text('parent_phone').default(''),
  parentEmail: text('parent_email').default(''),
  createdById: text('created_by_id').default(''),
  createdByName: text('created_by_name').default(''),
  createdByRole: text('created_by_role').default('admin'),
  memberIds: text('member_ids').default('[]'), // JSON array of participant IDs
  memberNames: text('member_names').default('[]'), // JSON array of participant names
  targetAudience: text('target_audience').default('all'), // 'all' | 'students' | 'parents' | 'teachers' | 'staff'
  status: text('status').notNull().default('active'), // 'active' | 'needs_followup' | 'archived'
  warningCount: integer('warning_count').notNull().default(0),
  notes: text('notes').default(''),
  lastMessage: text('last_message').default(''),
  lastTimestamp: text('last_timestamp').default(''),
  unreadCount: integer('unread_count').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 16. Chat Messages table (الرسائل النصية والصوتية والملصقات والملفات وسجل المكالمات)
export const parentMessages = pgTable('parent_messages', {
  id: text('id').primaryKey(),
  conversationId: text('conversation_id').notNull(),
  sender: text('sender').notNull().default('teacher'), // 'student' | 'female_student' | 'teacher' | 'parent' | 'admin' | 'secretary' | 'supervisor'
  senderId: text('sender_id').default(''),
  senderName: text('sender_name').notNull(),
  senderRoleLabel: text('sender_role_label').default(''),
  messageType: text('message_type').notNull().default('text'), // 'text' | 'audio' | 'image' | 'video' | 'file' | 'sticker' | 'call_log'
  text: text('text').notNull().default(''),
  mediaUrl: text('media_url'),
  fileName: text('file_name'),
  fileSize: text('file_size'),
  mimeType: text('mime_type'),
  durationSeconds: integer('duration_seconds'),
  stickerKey: text('sticker_key'),
  stickerCategory: text('sticker_category'), // 'complaint' | 'suggestion' | 'rating' | 'congrats' | 'warning'
  stickerLabel: text('sticker_label'),
  timestamp: text('timestamp').notNull(),
  read: boolean('read').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// 17. Lesson Rating Surveys table (استبيانات تقييم الدروس بالنجوم من الطلاب)
export const lessonRatings = pgTable('lesson_ratings', {
  id: text('id').primaryKey(),
  lessonId: text('lesson_id').notNull(),
  lessonTitle: text('lesson_title').notNull(),
  subject: text('subject').notNull(),
  grade: text('grade').notNull(),
  teacherId: text('teacher_id').default(''),
  teacherName: text('teacher_name').default(''),
  studentId: text('student_id').notNull(),
  studentName: text('student_name').notNull(),
  rating: integer('rating').notNull().default(5),
  clarityRating: integer('clarity_rating').notNull().default(5),
  benefitRating: integer('benefit_rating').notNull().default(5),
  comment: text('comment').default(''),
  createdAt: text('created_at').notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 18. Web Push Subscriptions table (اشتراكات إشعارات المتصفح والتطبيق PWA)
export const pushSubscriptions = pgTable('push_subscriptions', {
  id: text('id').primaryKey(),
  endpoint: text('endpoint').notNull().unique(),
  p256dh: text('p256dh').notNull(),
  auth: text('auth').notNull(),
  userId: text('user_id').default(''),
  userRole: text('user_role').default('visitor'),
  userName: text('user_name').default(''),
  deviceLabel: text('device_label').default(''),
  createdAt: text('created_at').notNull(),
});

// 19. Live Classroom Rooms (غرف الفصول الافتراضية المباشرة)
export const liveRooms = pgTable('live_rooms', {
  id: text('id').primaryKey(),
  roomCode: text('room_code').notNull().unique(),
  title: text('title').notNull(),
  subject: text('subject').notNull(),
  grade: text('grade').notNull(),
  hostId: text('host_id').notNull(),
  hostName: text('host_name').notNull(),
  status: text('status').notNull().default('scheduled'), // 'scheduled' | 'live' | 'ended'
  isLocked: boolean('is_locked').notNull().default(false),
  waitingRoomEnabled: boolean('waiting_room_enabled').notNull().default(false),
  chatMuted: boolean('chat_muted').notNull().default(false),
  hlsStreamUrl: text('hls_stream_url'),
  maxParticipants: integer('max_participants').notNull().default(200),
  scheduledAt: text('scheduled_at'),
  startedAt: timestamp('started_at'),
  endedAt: timestamp('ended_at'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 20. Room Attendance Logs (سجل حضور وانصراف الطلاب التلقائي في الغرف)
export const roomAttendance = pgTable('room_attendance', {
  id: text('id').primaryKey(),
  roomId: text('room_id').notNull(),
  userId: text('user_id').notNull(),
  userName: text('user_name').notNull(),
  role: text('role').notNull(), // 'teacher' | 'assistant' | 'student' | 'admin'
  joinedAt: timestamp('joined_at').notNull().defaultNow(),
  leftAt: timestamp('left_at'),
  durationSeconds: integer('duration_seconds').notNull().default(0),
});

// 21. Room Chat Messages (رسائل الشات المباشر داخل الفصل الافتراضي)
export const roomChatMessages = pgTable('room_chat_messages', {
  id: text('id').primaryKey(),
  roomId: text('room_id').notNull(),
  senderId: text('sender_id').notNull(),
  senderName: text('sender_name').notNull(),
  senderRole: text('sender_role').notNull(),
  message: text('message').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// 22. Room Polls & Quick Quizzes (استطلاعات الرأي والاختبارات السريعة أثناء البث)
export const roomPolls = pgTable('room_polls', {
  id: text('id').primaryKey(),
  roomId: text('room_id').notNull(),
  question: text('question').notNull(),
  optionsJson: text('options_json').notNull(), // JSON array of strings
  correctOptionIndex: integer('correct_option_index'),
  votesJson: text('votes_json').notNull().default('{}'), // JSON Record<userId, optionIndex>
  isActive: boolean('is_active').notNull().default(true),
  createdBy: text('created_by').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// 23. Room Timeline Events for Synchronized Replay (أحداث السبورة والمؤشر المزامنة بالتوقيت لإعادة التشغيل)
export const roomTimelineEvents = pgTable('room_timeline_events', {
  id: text('id').primaryKey(),
  roomId: text('room_id').notNull(),
  recordingId: text('recording_id'),
  offsetMs: integer('offset_ms').notNull().default(0),
  eventType: text('event_type').notNull(), // 'stroke' | 'erase' | 'page_change' | 'clear' | 'poll' | 'chat'
  payloadJson: text('payload_json').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// 24. Room Session Recordings (تسجيلات الحصص المباشرة)
export const roomRecordings = pgTable('room_recordings', {
  id: text('id').primaryKey(),
  roomId: text('room_id').notNull(),
  roomTitle: text('room_title').notNull(),
  teacherName: text('teacher_name').notNull(),
  videoUrl: text('video_url'),
  durationSeconds: integer('duration_seconds').notNull().default(0),
  yjsSnapshotBase64: text('yjs_snapshot_base64'),
  eventsCount: integer('events_count').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});
