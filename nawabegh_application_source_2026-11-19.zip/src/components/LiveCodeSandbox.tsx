import React, { useState } from 'react';
import { Code2, Play, RotateCcw, Terminal, Globe, X, CheckCircle2, AlertTriangle } from 'lucide-react';
import { runSubjectCodeSandbox, type CodeExecutionResult } from '../utils/codeSandboxRunner';

export type SandboxTabLanguage = 'html' | 'css' | 'javascript' | 'python';

interface LiveCodeSandboxProps {
  title?: string;
  initialLanguage?: SandboxTabLanguage;
  onClose?: () => void;
  compact?: boolean;
}

const STARTER_CODE: Record<SandboxTabLanguage, string> = {
  html: `<div style="background:#ecfdf5;border:2px solid #10b981;border-radius:12px;padding:16px;text-align:center;">
  <h2 style="color:#065f46;margin:0 0 8px;">مرحباً بك في مختبر الأكواد المباشر!</h2>
  <p style="color:#334155;margin:0;">عدّل الوسوم هنا وشاهد النتيجة فوراً.</p>
</div>`,
  css: `/* اكتب تنسيقات CSS وسيتم تطبيقها على البطاقة التجريبية تلقائياً */
.card {
  background: linear-gradient(135deg, #065f46, #0f766e);
  color: #ffffff;
  padding: 20px;
  border-radius: 16px;
  text-align: center;
  box-shadow: 0 10px 25px rgba(6, 95, 70, 0.25);
}
.card h3 { margin: 0 0 8px; font-size: 20px; }
.card span { background: #fbbf24; color: #0f172a; padding: 4px 12px; border-radius: 8px; font-weight: bold; }`,
  javascript: `// اكتب كود JavaScript واضغط تشغيل
const studentName = "بطل منصة الشريف";
const scores = [92, 95, 98];
const avg = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
console.log("مرحباً", studentName);
console.log("متوسط درجاتك:", avg + "%");
return avg;`,
  python: `# اكتب كود Python واضغط تشغيل
name = "منصة الشريف"
print("أهلاً بك في", name)
for i in range(1, 5):
    print("الدرس رقم:", i)`,
};

export const LiveCodeSandbox: React.FC<LiveCodeSandboxProps> = ({
  title = 'مختبر الأكواد التفاعلي المباشر',
  initialLanguage = 'python',
  onClose,
  compact = false,
}) => {
  const [language, setLanguage] = useState<SandboxTabLanguage>(initialLanguage);
  const [codeByLang, setCodeByLang] = useState<Record<SandboxTabLanguage, string>>({
    ...STARTER_CODE,
  });
  const [result, setResult] = useState<CodeExecutionResult | null>(null);

  const handleRun = () => {
    const currentCode = codeByLang[language] || '';
    if (language === 'html') {
      setResult(runSubjectCodeSandbox({ code: currentCode, language: 'html_css' }));
      return;
    }
    if (language === 'css') {
      const wrapped = `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>body{font-family:sans-serif;padding:16px;margin:0;background:#f8fafc;}${currentCode}</style></head><body><div class="card"><h3>معاينة تنسيق CSS المباشرة</h3><p>هذا عنصر تجريبي بـ class="card"</p><span>مختبر الشريف</span></div></body></html>`;
      setResult({
        passed: true,
        logs: ['✓ تم تطبيق قواعد CSS على المعاينة بنجاح.'],
        returnedValue: 'CSS Applied',
        renderedHtml: wrapped,
        error: null,
        feedback: '✓ تم تطبيق تنسيقات CSS وعرض المعاينة الحية.',
      });
      return;
    }
    setResult(
      runSubjectCodeSandbox({
        code: currentCode,
        language: language === 'python' ? 'python' : 'javascript',
      })
    );
  };

  const handleReset = () => {
    setCodeByLang((prev) => ({ ...prev, [language]: STARTER_CODE[language] }));
    setResult(null);
  };

  return (
    <div className="rounded-2xl border-2 border-emerald-500/30 bg-slate-950 text-slate-100 shadow-xl overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-gradient-to-l from-emerald-900 via-slate-900 to-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 font-cairo">
          <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
            <Code2 className="w-4 h-4" />
          </div>
          <span className="font-black text-sm text-white">{title}</span>
          <span className="text-[11px] px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold">
            HTML / CSS / JS / Python
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 gap-1 font-cairo text-xs">
            {(
              [
                { id: 'html', label: 'HTML' },
                { id: 'css', label: 'CSS' },
                { id: 'javascript', label: 'JavaScript' },
                { id: 'python', label: 'Python' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setLanguage(tab.id);
                  setResult(null);
                }}
                className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                  language === tab.id
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
              title="إغلاق المختبر"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Editor + Output Grid */}
      <div className={`grid grid-cols-1 ${compact ? '' : 'lg:grid-cols-2'} divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-slate-800`}>
        {/* Code Editor */}
        <div className="p-3.5 space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-400 font-cairo">
            <span>محرر الكود ({language.toUpperCase()})</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>استعادة المثال</span>
              </button>
              <button
                type="button"
                onClick={handleRun}
                className="flex items-center gap-1.5 px-3.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>تشغيل الكود</span>
              </button>
            </div>
          </div>

          <textarea
            dir="ltr"
            value={codeByLang[language] || ''}
            onChange={(e) =>
              setCodeByLang((prev) => ({
                ...prev,
                [language]: e.target.value,
              }))
            }
            rows={compact ? 7 : 10}
            spellCheck={false}
            className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-emerald-300 font-mono text-xs sm:text-sm leading-relaxed outline-none focus:border-emerald-500 resize-y"
          />
        </div>

        {/* Live Output / Preview */}
        <div className="p-3.5 bg-slate-900/60 flex flex-col gap-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300 font-cairo">
            {language === 'html' || language === 'css' ? (
              <>
                <Globe className="w-4 h-4 text-sky-400" />
                <span>المعاينة الحية (Live Preview)</span>
              </>
            ) : (
              <>
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>شاشة المخرجات (Console Output)</span>
              </>
            )}
          </div>

          {!result ? (
            <div className="flex-1 min-h-[160px] rounded-xl border border-dashed border-slate-700 flex items-center justify-center text-xs text-slate-400 font-tajawal text-center p-4">
              اضغط على «تشغيل الكود» لمعاينة المخرجات فوراً دون مغادرة الدرس أو الاختبار.
            </div>
          ) : (
            <div className="space-y-2 flex-1 flex flex-col">
              <div
                className={`p-2.5 rounded-xl text-xs font-bold font-cairo flex items-center gap-2 ${
                  result.error
                    ? 'bg-rose-950/70 border border-rose-700 text-rose-200'
                    : 'bg-emerald-950/70 border border-emerald-700 text-emerald-200'
                }`}
              >
                {result.error ? (
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                )}
                <span>{result.error || result.feedback}</span>
              </div>

              {result.renderedHtml ? (
                <iframe
                  title="sandbox-preview"
                  sandbox="allow-scripts"
                  srcDoc={result.renderedHtml}
                  className="w-full flex-1 min-h-[175px] rounded-xl bg-white border border-slate-700"
                />
              ) : (
                <div
                  dir="ltr"
                  className="flex-1 min-h-[150px] p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-amber-200 space-y-1 overflow-auto"
                >
                  {result.logs.length > 0 ? (
                    result.logs.map((line, i) => (
                      <div key={i} className="whitespace-pre-wrap">
                        <span className="text-slate-500 select-none">&gt; </span>
                        {line}
                      </div>
                    ))
                  ) : (
                    <span className="text-slate-500">لا توجد مخرجات طباعة (استخدم print أو console.log).</span>
                  )}
                  {result.returnedValue && (
                    <div className="pt-1 mt-1 border-t border-slate-800 text-emerald-400">
                      return: {result.returnedValue}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
