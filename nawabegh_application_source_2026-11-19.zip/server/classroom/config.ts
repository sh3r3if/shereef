import crypto from 'crypto';
import type { ClassroomRole } from '../../src/types/classroom.ts';

const fallbackEphemeralSecret = crypto.randomBytes(32).toString('hex');

export const classroomConfig = {
  jwtSecret:
    process.env.JWT_SECRET && process.env.JWT_SECRET !== 'REPLACE_WITH_LONG_RANDOM_SECRET'
      ? process.env.JWT_SECRET
      : fallbackEphemeralSecret,
  usingEphemeralJwtSecret:
    !process.env.JWT_SECRET || process.env.JWT_SECRET === 'REPLACE_WITH_LONG_RANDOM_SECRET',
  redisUrl: process.env.REDIS_URL || '',
  livekitUrl: process.env.LIVEKIT_URL || '',
  livekitApiKey: process.env.LIVEKIT_API_KEY || '',
  livekitApiSecret: process.env.LIVEKIT_API_SECRET || '',
  defaultInviteTtlSeconds: 60 * 60 * 4, // 4 hours
  defaultSessionTtlSeconds: 60 * 60 * 6, // 6 hours
};

export function isLiveKitConfigured(): boolean {
  return Boolean(
    classroomConfig.livekitUrl &&
      classroomConfig.livekitApiKey &&
      classroomConfig.livekitApiSecret &&
      !classroomConfig.livekitApiKey.startsWith('MY_')
  );
}

export function canCreateOrConfigureRoom(role: ClassroomRole | string): boolean {
  return role === 'teacher' || role === 'assistant' || role === 'admin';
}

export function canModerateRoom(role: ClassroomRole | string): boolean {
  return role === 'teacher' || role === 'assistant' || role === 'admin';
}

export function canAdministerPlatformRooms(role: ClassroomRole | string): boolean {
  return role === 'admin';
}
