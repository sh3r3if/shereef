import type {
  CurriculumChapter,
  CurriculumSubject,
  EducationalStage,
} from '../../src/types/curriculum.ts';
import {
  sec1PracticalChapters,
  sec1TheoryChapters,
} from './sec1CurriculumData.ts';
import {
  sec2PracticalChapters,
  sec2TheoryChapters,
} from './sec2CurriculumData.ts';

export const DEFAULT_STAGES: EducationalStage[] = [
  {
    id: 'stage-prep-1',
    name: 'الصف الأول الإعدادي',
    gradeLabel: 'الكمبيوتر وتكنولوجيا المعلومات والاتصالات (الترمين 1 و 2)',
    description:
      'التكنولوجيا الخضراء، التحول الرقمي، أنظمة التشغيل، البريد والحوسبة السحابية، جوجل ميت، وقواعد البيانات والاستعلامات مع أسئلة مقالية وموضوعية وعملي.',
  },
  {
    id: 'stage-prep-2',
    name: 'الصف الثاني الإعدادي',
    gradeLabel: 'الحاسب الآلي والذكاء الاصطناعي وتصميم الويب (HTML & CSS)',
    description:
      'الأنظمة الذكية، التهديدات السيبرانية المتقدمة، البيانات الضخمة والذكاء الاصطناعي، ومشروع تصميم صفحات الويب UX/UI و HTML/CSS التفاعلي في المحرر.',
  },
  {
    id: 'stage-prep-3',
    name: 'الصف الثالث الإعدادي',
    gradeLabel: 'الذكاء الاصطناعي ولغات البرمجة (Python) والأمن السيبراني',
    description:
      'التفكير الحاسوبي، الخوارزميات، لغة بايثون (Strings, Lists, Functions, try/except)، نماذج التنبؤ، حقوق الملكية الفكرية، والتزييف العميق Deepfake.',
  },
  {
    id: 'stage-sec-1',
    name: 'الصف الأول الثانوي',
    gradeLabel: 'البرمجة والذكاء الاصطناعي (النظري + العملي QUREO / TOFAS)',
    description:
      'مساران متكاملان على الترمين: المسار النظري (أسئلة موضوعية ومقالية للوحدات 1–7) والمسار العملي (اختبارات 4 اختيارات كلها على أكواد JavaScript وTOFAS).',
  },
  {
    id: 'stage-sec-2',
    name: 'الصف الثاني الثانوي',
    gradeLabel: 'البرمجة والذكاء الاصطناعي — ثانية بكالوريا (النظري + العملي)',
    description:
      'منهج الوحدات 1–4 كاملاً (تطور AI وأخلاقياته، التشفير وأمن الشبكات والمخاطر، بنية وتقنيات الويب API/React، وتجربة المستخدم UX وPDCA): مسار نظري (موضوعي + مقالي) ومسار عملي (4 اختيارات كلها على أكواد).',
  },
];

function makeChapterReview(
  prefix: string,
  topicTitle: string,
  pairs: Array<{
    q: string;
    opts: [string, string, string, string];
    ans: number;
    exp: string;
  }>
) {
  return pairs.map((p, idx) => ({
    id: `${prefix}-rev-${idx + 1}`,
    question: `[مراجعة ${topicTitle}] ${p.q}`,
    options: p.opts,
    correctIndex: p.ans,
    explanation: p.exp,
  }));
}

function buildCumulativeMilestones(
  prefix: string,
  chapters: CurriculumChapter[]
): CurriculumSubject['cumulativeReviews'] {
  const term1Chapters = chapters.filter((c) => c.term === 1);
  const term2Chapters = chapters.filter((c) => c.term === 2);
  const milestones: CurriculumSubject['cumulativeReviews'] = [];

  if (term1Chapters.length >= 3) {
    const firstBlock = term1Chapters.slice(0, 3);
    const mergedQuestions = firstBlock.flatMap((c) => c.chapterReviewQuestions.slice(0, 2));
    milestones.push({
      id: `${prefix}-cum-t1-3`,
      term: 1,
      afterChapterOrder: firstBlock[firstBlock.length - 1].order,
      coversChapterOrders: firstBlock.map((c) => c.order),
      title: 'المراجعة التراكمية الشاملة — الترم الأول (بعد إتمام 3 فصول)',
      questions: mergedQuestions,
    });
  }

  if (term2Chapters.length >= 3) {
    const secondBlock = term2Chapters.slice(0, 3);
    const mergedQuestions = secondBlock.flatMap((c) => c.chapterReviewQuestions.slice(0, 2));
    milestones.push({
      id: `${prefix}-cum-t2-6`,
      term: 2,
      afterChapterOrder: secondBlock[secondBlock.length - 1].order,
      coversChapterOrders: secondBlock.map((c) => c.order),
      title: 'المراجعة التراكمية الشاملة — الترم الثاني (بعد إتمام 3 فصول)',
      questions: mergedQuestions,
    });
  }

  return milestones;
}

/* ============================================================================
 * 1) الصف الأول الإعدادي — الكمبيوتر وتكنولوجيا المعلومات (مذكرة أ. محمد الشريف)
 * ============================================================================ */
const prep1IctChapters: CurriculumChapter[] = [
  {
    id: 'p1-ict-t1-c1',
    order: 1,
    term: 1,
    title: 'الفصل الأول: التكنولوجيا الخضراء والتحول الرقمي وأنظمة التشغيل',
    description: 'دروس (1–3): التكنولوجيا الخضراء والطاقات المتجددة، التحول الرقمي ومنصة مصر الرقمية، وأنواع أنظمة التشغيل.',
    lessons: [
      {
        id: 'p1-ict-t1-c1-l1',
        order: 1,
        title: 'الدرس الأول: التكنولوجيا الخضراء (Green Technology)',
        durationMinutes: 18,
        summary:
          'التكنولوجيا الخضراء هي أدوات وتقنيات صديقة للبيئة تقلل التلوث والانبعاثات الضارة وتحافظ على الموارد الطبيعية، وتشمل السيارات الكهربائية والطاقات المتجددة والمباني الخضراء وإدارة النفايات ومعالجة المياه والزراعة الدقيقة بالحساسات (Sensors).',
        keyPoints: [
          'الطاقات المتجددة الخمسة: الطاقة الشمسية، طاقة الرياح، الطاقة المائية (السدود)، الطاقة الحرارية الأرضية، والطاقة الحيوية (Bioenergy).',
          'السيارات الكهربائية (EVs) تعتمد على الكهرباء والبطاريات القابلة لإعادة الشحن فتقلل التلوث الضوضائي وانبعاثات العوادم.',
          'المباني الخضراء توفر الطاقة بالمصابيح الموفرة وتدوير مياه الأمطار والألواح الشمسية والعزل الحراري الجيد.',
          'الحساسات (Sensors) تُستخدم في إدارة النفايات وفي الزراعة الدقيقة ومراقبة جودة المياه والري بالتنقيط لتقليل الهدر.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c1-l1-q1',
            question: 'أي من الآتي يُعد من مجالات التكنولوجيا الخضراء لإنتاج الكهرباء من حركة الهواء؟',
            options: ['الطاقة الحيوية', 'طاقة الرياح', 'الطاقة المائية', 'الطاقة الحرارية الأرضية'],
            correctIndex: 1,
            explanation: 'تُستخدم توربينات الهواء في طاقة الرياح لتوليد الكهرباء دون انبعاثات ضارة.',
          },
          {
            id: 'p1-c1-l1-q2',
            question: 'تُستخدم أجهزة الاستشعار (Sensors) في أنظمة الري الحديث بهدف:',
            options: [
              'زيادة استهلاك الوقود الأحفوري',
              'تقليل هدر المياه وتنفيذ الري بالتنقيط حسب حاجة التربة',
              'إزالة الألواح الشمسية من المباني',
              'زيادة الضوضاء في الحقول الزراعية',
            ],
            correctIndex: 1,
            explanation: 'تساعد الحساسات في مراقبة رطوبة التربة وضبط الري بالتنقيط لتوفير المياه.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c1-l1-tf1',
            statement: 'تساعد السيارات الكهربائية في تقليل التلوث الضوضائي مقارنة بالسيارات التقليدية التي تعمل بالوقود.',
            isTrue: true,
            explanation: 'صحيح — المحرك الكهربائي هادئ ولا ينتج عوادم ضارة.',
          },
          {
            id: 'p1-c1-l1-tf2',
            statement: 'الوقود الأحفوري (مثل الفحم والبترول) يُعد من مصادر الطاقة المتجددة النظيفة.',
            isTrue: false,
            explanation: 'خطأ — الوقود الأحفوري مصدر غير متجدد ومسبب رئيسي للتلوث والانبعاثات.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c1-l1-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: أدوات وتقنيات صديقة للبيئة تهدف إلى تقليل التأثير السلبي على البيئة وتوفير الموارد والحد من التلوث.',
            modelAnswer: 'التكنولوجيا الخضراء (Green Technology)',
            keywords: ['التكنولوجيا الخضراء', 'green technology'],
          },
          {
            id: 'p1-c1-l1-es2',
            questionType: 'essay',
            question: 'اذكر ثلاثة من مصادر الطاقة المتجددة المستخدمة في التكنولوجيا الخضراء.',
            modelAnswer: 'الطاقة الشمسية، طاقة الرياح، الطاقة المائية (ويمكن أيضاً الطاقة الحرارية الأرضية والطاقة الحيوية).',
            keywords: ['الشمس', 'الرياح', 'المائ'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c1-l1-code1',
            language: 'javascript',
            title: 'عملي الدرس 1: محاكاة حساس الرطوبة في الري الذكي بالتنقيط',
            prompt:
              'اكتب شرطاً برمجياً يفحص قراءة حساس رطوبة التربة soilMoisture = 25؛ إذا كانت أقل من 30 يطبع "تشغيل الري بالتنقيط" وإلا يطبع "التربة رطبة".',
            subjectContext: 'الصف الأول الإعدادي — تطبيق برمجي على الحساسات (Sensors)',
            starterCode: `const soilMoisture = 25;\nif (soilMoisture > 100) {\n  console.log("التربة رطبة");\n} else {\n  console.log("عدل الشرط لتشغيل الري");\n}`,
            hint: 'غيّر الشرط إلى (soilMoisture < 30) واجعل المخرج "تشغيل الري بالتنقيط".',
            expectedOutputContains: ['تشغيل الري بالتنقيط'],
          },
        ],
      },
      {
        id: 'p1-ict-t1-c1-l2',
        order: 2,
        title: 'الدرس الثاني: التحول الرقمي وأهميته',
        durationMinutes: 16,
        summary:
          'التحول الرقمي هو دمج التكنولوجيا الرقمية في جميع مجالات العمل والخدمات لتحسين الكفاءة وتوفير الوقت؛ ومن أمثلته في مصر منصة مصر الرقمية، بطاقات ميزة، وتطبيق إنستاباي (InstaPay) المعتمد من البنك المركزي المصري.',
        keyPoints: [
          'أهمية التحول الرقمي: تحسين جودة الخدمات، زيادة الإنتاجية، تعزيز الشفافية، وتوفير الوقت والمجهود.',
          'أمثلة الدفع والتعاملات في مصر: منصة مصر الرقمية، بطاقات الدفع الوطنية "ميزة"، وتطبيق InstaPay.',
          'أدوات التعلم والتواصل عن بُعد: Zoom و Google Meet.',
          'الربط بالتكنولوجيا الخضراء: المدن الذكية، الشبكات الذكية لتوزيع الكهرباء، والزراعة الدقيقة لتقليل استهلاك الورق والوقود.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c1-l2-q1',
            question: 'من التطبيقات المعتمدة من البنك المركزي المصري لإجراء التحويلات المالية اللحظية عبر الهاتف:',
            options: ['تطبيق Paint', 'تطبيق إنستاباي (InstaPay)', 'نظام Linux', 'برنامج Access'],
            correctIndex: 1,
            explanation: 'تطبيق InstaPay معتمد من البنك المركزي المصري للتحويلات المالية الفورية.',
          },
          {
            id: 'p1-c1-l2-q2',
            question: 'كيف يساهم التحول الرقمي في دعم التكنولوجيا الخضراء؟',
            options: [
              'زيادة طباعة الأوراق يومياً',
              'تقليل استهلاك الورق والوقود عبر الخدمات الإلكترونية والمدن الذكية',
              'إلغاء الاعتماد على الإنترنت',
              'تشغيل المصانع بالفحم فقط',
            ],
            correctIndex: 1,
            explanation: 'الخدمات الرقمية تقلل المعاملات الورقية وتخفض انتقالات السيارات واستهلاك الوقود.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c1-l2-tf1',
            statement: 'تُتيح منصة مصر الرقمية للمواطنين إنجاز خدمات حكومية إلكترونياً بسهولة وأمان.',
            isTrue: true,
            explanation: 'صحيح — منصة مصر الرقمية من أبرز تطبيقات التحول الرقمي في مصر.',
          },
          {
            id: 'p1-c1-l2-tf2',
            statement: 'الاستغناء عن السجلات الرقمية والعودة للتعامل الورقي يرفع كفاءة التحول الرقمي.',
            isTrue: false,
            explanation: 'خطأ — التحول الرقمي يعتمد على تحويل العمليات إلى أنظمة إلكترونية رقمية.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c1-l2-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: عملية دمج التكنولوجيا الرقمية في جميع جوانب العمل والخدمات لتحسين الكفاءة وتوفير الوقت.',
            modelAnswer: 'التحول الرقمي (Digital Transformation)',
            keywords: ['التحول الرقمي', 'digital'],
          },
          {
            id: 'p1-c1-l2-es2',
            questionType: 'complete',
            question: 'أكمل: من أمثلة الخدمات والمنصات الرقمية في مصر منصة ............... وبطاقات ............... وتطبيق ...............',
            modelAnswer: 'منصة مصر الرقمية، بطاقات ميزة، وتطبيق إنستاباي (InstaPay).',
            keywords: ['مصر الرقمية', 'ميزة', 'إنستاباي'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c1-l2-code1',
            language: 'javascript',
            title: 'عملي الدرس 2: حساب توفير الأوراق والوقت في التحول الرقمي',
            prompt:
              'إذا وفّرت الخدمة الرقمية 12 ورقة لكل معاملة ونُفذت 50 معاملة عبر مصر الرقمية، احسب savedSheets = sheetsPerRequest * requests واطبعه (600).',
            subjectContext: 'الصف الأول الإعدادي — أثر التحول الرقمي على البيئة',
            starterCode: `const sheetsPerRequest = 12;\nconst requests = 50;\nconst savedSheets = 0;\nconsole.log("الأوراق الموفرة =", savedSheets);`,
            hint: 'اكتب const savedSheets = sheetsPerRequest * requests;',
            expectedOutputContains: ['600'],
          },
        ],
      },
      {
        id: 'p1-ict-t1-c1-l3',
        order: 3,
        title: 'الدرس الثالث: أنظمة التشغيل (Operating Systems)',
        durationMinutes: 18,
        summary:
          'نظام التشغيل هو البرمجية الرئيسية التي تدير موارد الحاسوب وتشكل حلقة الوصل بين المستخدم والأجهزة والتطبيقات، وتتنوع الأنظمة لتناسب الحواسيب الشخصية والهواتف والخوادم والتلفزيونات الذكية والأنظمة المدمجة.',
        keyPoints: [
          'أجهزة الكمبيوتر الشخصية: Windows (مايكروسوفت)، macOS (أبل)، و Linux (مفتوح المصدر).',
          'الهواتف الذكية: Android (مفتوح المصدر) و iOS (لأجهزة آيفون/أبل).',
          'الخوادم (Servers): Linux و Windows Server؛ والتلفزيونات الذكية: Tizen و webOS و Android TV.',
          'الأنظمة المدمجة (Embedded Systems): في ماكينات ATM ونقاط البيع POS؛ وأنظمة التحكم الصناعية (ICS) في المصانع ومحطات الطاقة.',
          'مكونات الشاشة الافتتاحية (Desktop): الخلفية Background، الأيقونات Icons، والأشرطة Bars.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c1-l3-q1',
            question: 'أي من أنظمة التشغيل التالية يُعد نظاماً مفتوح المصدر يُستخدم بكثرة في الحواسيب والخوادم؟',
            options: ['macOS', 'iOS', 'Linux', 'Tizen'],
            correctIndex: 2,
            explanation: 'نظام Linux مفتوح المصدر وقابل للتعديل والتشغيل على الخوادم والحواسيب.',
          },
          {
            id: 'p1-c1-l3-q2',
            question: 'تُصنف أنظمة التشغيل الموجودة في ماكينات الصراف الآلي (ATM) ونقاط البيع (POS) ضمن:',
            options: [
              'أنظمة التلفزيونات الذكية',
              'الأنظمة المدمجة (Embedded Systems)',
              'أنظمة وحدات الألعاب فقط',
              'أنظمة تصميم الصور',
            ],
            correctIndex: 1,
            explanation: 'الأنظمة المدمجة مخصصة لأجهزة ذات مهام محددة مثل ATM و POS.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c1-l3-tf1',
            statement: 'تُستخدم أنظمة Tizen و webOS و Android TV في تشغيل أجهزة التلفزيون الذكية.',
            isTrue: true,
            explanation: 'صحيح — هذه أبرز أنظمة التشغيل لأجهزة Smart TVs.',
          },
          {
            id: 'p1-c1-l3-tf2',
            statement: 'تعمل أجهزة iPhone بنظام تشغيل Android كنظام أساسي من شركة أبل.',
            isTrue: false,
            explanation: 'خطأ — أجهزة آيفون تعمل بنظام iOS الخاص بشركة أبل.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c1-l3-es1',
            questionType: 'essay',
            question: 'اذكر المكونات الثلاثة الأساسية للشاشة الافتتاحية (Desktop) في أنظمة التشغيل الحديثة.',
            modelAnswer: '1) الخلفية (Background)، 2) الأيقونات (Icons)، 3) الأشرطة (Bars مثل شريط المهام).',
            keywords: ['الخلفية', 'الأيقونات', 'الأشرطة'],
          },
          {
            id: 'p1-c1-l3-es2',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: برنامج مسؤول عن إدارة موارد الحاسوب وربط المستخدم بالمكونات المادية والتطبيقات.',
            modelAnswer: 'نظام التشغيل (Operating System)',
            keywords: ['نظام التشغيل', 'operating system'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c1-l3-code1',
            language: 'javascript',
            title: 'عملي الدرس 3: مصنف أنظمة التشغيل حسب نوع الجهاز',
            prompt:
              'أكمل الدالة getOsType(device) بحيث إذا استقبلت "ATM" تعيد "Embedded System"، ثم اطبع نتيجة getOsType("ATM").',
            subjectContext: 'الصف الأول الإعدادي — تصنيف أنظمة التشغيل برمجياً',
            starterCode: `function getOsType(device) {\n  if (device === "ATM") {\n    return "غير معروف";\n  }\n  return "Desktop OS";\n}\nconsole.log(getOsType("ATM"));`,
            hint: 'غيّر القيمة المرجعة عند "ATM" إلى "Embedded System".',
            expectedOutputContains: ['Embedded System'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p1-c1', 'الفصل 1 (أولى إعدادي)', [
      { q: 'من الطاقات المتجددة التي تعتمد على باطن الأرض:', opts: ['الشمسية', 'الحرارية الأرضية', 'الرياح', 'الحيوية'], ans: 1, exp: 'الطاقة الحرارية الأرضية تستمد حرارتها من باطن الأرض.' },
      { q: 'يُستخدم تطبيق InstaPay في مصر من أجل:', opts: ['تحرير النصوص', 'التحويلات المالية اللحظية', 'تعريف الطابعات', 'مكالمات الفيديو فقط'], ans: 1, exp: 'إنستاباي تطبيق تحويلات بنكية لحظية.' },
      { q: 'من أنظمة التشغيل المخصصة لأجهزة iPhone:', opts: ['Linux', 'Windows', 'iOS', 'webOS'], ans: 2, exp: 'نظام iOS مخصص لهواتف أبل.' },
      { q: 'من أمثلة أنظمة تشغيل التلفزيونات الذكية:', opts: ['Tizen', 'Windows Server', 'MS-DOS', 'Oracle'], ans: 0, exp: 'Tizen و webOS و Android TV للتلفزيونات الذكية.' },
      { q: 'الأداة المستخدمة في الري بالتنقيط لقياس رطوبة التربة هي:', opts: ['الطابعة', 'الحساسات (Sensors)', 'الشاشة', 'الماسح الضوئي'], ans: 1, exp: 'الحساسات Sensors تقيس الرطوبة تلقائياً.' },
    ]),
  },
  {
    id: 'p1-ict-t1-c2',
    order: 2,
    term: 1,
    title: 'الفصل الثاني: البرامج والأجهزة الملحقة والبريد الإلكتروني والسحابة',
    description: 'دروس (4–6): تثبيت وإزالة البرامج والتعريفات Drivers، البريد الإلكتروني Gmail، والحوسبة السحابية.',
    lessons: [
      {
        id: 'p1-ict-t1-c2-l1',
        order: 1,
        title: 'الدرس الرابع: تثبيت وإزالة البرامج والأجهزة الملحقة',
        durationMinutes: 17,
        summary:
          'يتناول الدرس طرق تثبيت البرامج (من DVD عبر Setup.exe، أو بالتنزيل المباشر، أو فك الضغط)، وإزالتها بأمان من لوحة التحكم Control Panel، ومفهوم التوصيل والتشغيل Plug and Play وملفات التعريف Drivers ومنافذ الطابعة.',
        keyPoints: [
          'التثبيت يتم إما من قرص DVD عبر ملف Setup.exe أو ملف مضغوط أو تنزيل من الإنترنت.',
          'إزالة البرنامج الصحيح تتم من Control Panel -> Programs -> Uninstall a Program وليس بحذف الأيقونة من سطح المكتب.',
          'ميزة Plug and Play تتيح التعرف التلقائي على الجهاز؛ وقد نحتاج أحياناً ملف التعريف Driver بامتداد .inf أو .exe.',
          'منافذ توصيل الطابعة: منفذ LPT1 المتوازي (القديم) ومنفذ USB التسلسلي الحديث.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c2-l1-q1',
            question: 'ما هي الطريقة الصحيحة لإزالة برنامج غير مرغوب فيه من نظام Windows؟',
            options: [
              'حذف اختصار البرنامج من سطح المكتب فقط',
              'الدخول إلى Control Panel ثم اختيار Uninstall a Program',
              'فصل سلك الشاشة',
              'تغيير خلفية سطح المكتب',
            ],
            correctIndex: 1,
            explanation: 'حذف الاختصار لا يزيل ملفات البرنامج من القرص؛ الإزالة الصحيحة عبر لوحة التحكم.',
          },
          {
            id: 'p1-c2-l1-q2',
            question: 'تُسمى الخاصية التي تجعل نظام التشغيل يتعرف تلقائياً على الجهاز الملحق بمجرد توصيله:',
            options: ['LPT1 Port', 'Plug and Play', 'Uninstall', 'Spam Filter'],
            correctIndex: 1,
            explanation: 'Plug and Play (وصّل وشغّل) تتعرف تلقائياً على الأجهزة الجديدة.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c2-l1-tf1',
            statement: 'تتصل الطابعات الحديثة بالحاسوب غالباً عبر منفذ USB بينما اعتمدت القديمة على منفذ LPT1.',
            isTrue: true,
            explanation: 'صحيح — منفذ USB هو القياسي للطابعات الحديثة.',
          },
          {
            id: 'p1-c2-l1-tf2',
            statement: 'ملفات التعريف (Drivers) تأتي أحياناً بامتداد .inf وتعمل كوسيط بين نظام التشغيل والجهاز الملحق.',
            isTrue: true,
            explanation: 'صحيح — ملف التعريف يعرّف النظام بكيفية تشغيل الجهاز.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c2-l1-es1',
            questionType: 'essay',
            question: 'لماذا لا يُنصح بحذف أيقونة البرنامج من سطح المكتب بدلاً من إزالته من Control Panel؟',
            modelAnswer: 'لأن حذف الأيقونة يزيل الاختصار فقط بينما تظل ملفات البرنامج وإعداداته محفوظة وتستهلك مساحة القرص والذاكرة.',
            keywords: ['الاختصار', 'تبقى ملفات', 'لوحة التحكم'],
          },
          {
            id: 'p1-c2-l1-es2',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: برنامج صغير يعمل كحلقة وصل بين نظام التشغيل والجهاز الملحق مثل الطابعة لتمكينهما من العمل معاً.',
            modelAnswer: 'ملف التعريف (Driver)',
            keywords: ['التعريف', 'driver'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c2-l1-code1',
            language: 'javascript',
            title: 'عملي الدرس 4: فاحص جاهزية تثبيت الطابعة والتعريف',
            prompt:
              'أكمل المنطق الشرطي بحيث إذا كانت port === "USB" و hasDriver === true يطبع "الطابعة جاهزة للعمل".',
            subjectContext: 'الصف الأول الإعدادي — الأجهزة الملحقة والتعريفات',
            starterCode: `const port = "USB";\nconst hasDriver = true;\nif (port === "LPT1") {\n  console.log("تحتاج تعريف");\n} else {\n  console.log("اكمل الشرط");\n}`,
            hint: 'تحقق من (port === "USB" && hasDriver) واطبع "الطابعة جاهزة للعمل".',
            expectedOutputContains: ['الطابعة جاهزة للعمل'],
          },
        ],
      },
      {
        id: 'p1-ict-t1-c2-l2',
        order: 2,
        title: 'الدرس الخامس: البريد الإلكتروني (Electronic Mail - Gmail)',
        durationMinutes: 16,
        summary:
          'يتكون عنوان البريد الإلكتروني من اسم المستخدم Username ثم الرمز @ ثم اسم النطاق Domain Name (مثل Gmail)، وله مزايا عديدة في التواصل وإرفاق الملفات وسلبيات يجب الحذر منها مثل الرسائل المزعجة Spam والاحتيال.',
        keyPoints: [
          'أجزاء عنوان البريد الإلكتروني الثلاثة: Username + @ + Domain name.',
          'المزايا: مجاني وسريع، إرسال مرفقات (صور ومستندات)، الوصول من أي جهاز.',
          'السلبيات المحتملة: الرسائل المزعجة (Spam)، الفيروسات، ومحاولات الاختراق والاحتيال.',
          'في Gmail: تغيير اللغة يتم من Settings -> General -> Gmail display language ثم Save Changes، والخروج بـ Sign out.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c2-l2-q1',
            question: 'ما هو الترتيب الصحيح لمكونات عنوان البريد الإلكتروني؟',
            options: [
              'Domain @ Username',
              'Username @ Domain name',
              '@ Domain Username',
              'Password @ Gmail',
            ],
            correctIndex: 1,
            explanation: 'يتكون البريد من اسم المستخدم يليه الرمز @ ثم اسم النطاق مثل ahmed@gmail.com.',
          },
          {
            id: 'p1-c2-l2-q2',
            question: 'لتغيير لغة واجهة بريد Gmail إلى العربية نذهب إلى Settings ثم تبويب:',
            options: ['Inbox', 'General', 'Compose', 'Spam'],
            correctIndex: 1,
            explanation: 'يوجد إعداد Gmail display language داخل تبويب General بالإعدادات.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c2-l2-tf1',
            statement: 'يفصل الرمز @ (at) بين اسم المستخدم (Username) واسم النطاق (Domain Name).',
            isTrue: true,
            explanation: 'صحيح — @ تعني "لدى/في" وتفصل بين الاسم والنطاق.',
          },
          {
            id: 'p1-c2-l2-tf2',
            statement: 'يُنصح بترك حساب Gmail مفتوحاً على أجهزة المدرسة المشتركة دون الضغط على Sign out.',
            isTrue: false,
            explanation: 'خطأ — يجب تسجيل الخروج (Sign out) لحماية الحساب والخصوصية.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c2-l2-es1',
            questionType: 'complete',
            question: 'أكمل: يتكون عنوان البريد الإلكتروني من ثلاثة أجزاء رئيسية هي ............... ثم الرمز ............... ثم ...............',
            modelAnswer: 'اسم المستخدم (Username) ثم الرمز (@) ثم اسم النطاق (Domain name).',
            keywords: ['اسم المستخدم', '@', 'النطاق'],
          },
          {
            id: 'p1-c2-l2-es2',
            questionType: 'essay',
            question: 'اذكر اثنتين من مزايا استخدام البريد الإلكتروني، واثنتين من سلبياته المحتملة.',
            modelAnswer: 'المزايا: السرعة والمجانية وإرفاق الملفات. السلبيات: الرسائل المزعجة (Spam) ومخاطر الاختراق أو الفيروسات.',
            keywords: ['السرعة', 'مرفق', 'spam', 'اختراق'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c2-l2-code1',
            language: 'javascript',
            title: 'عملي الدرس 5: مدقق صيغة البريد الإلكتروني (@ و Domain)',
            prompt:
              'تحقق من أن المتغير email = "student@gmail.com" يحتوي على "@" ويحتوي على "." ثم اطبع اسم النطاق "gmail.com" عبر console.log.',
            subjectContext: 'الصف الأول الإعدادي — تحليل أجزاء البريد الإلكتروني',
            starterCode: `const email = "student@gmail.com";\nconst parts = email.split("@");\n// اطبع parts[1] إذا تحقق الشرط\nconsole.log(parts[0]);`,
            hint: 'اطبع parts[1] التي تمثل اسم النطاق gmail.com.',
            expectedOutputContains: ['gmail.com'],
          },
        ],
      },
      {
        id: 'p1-ict-t1-c2-l3',
        order: 3,
        title: 'الدرس السادس: الحوسبة السحابية (Cloud Computing)',
        durationMinutes: 17,
        summary:
          'الحوسبة السحابية هي نموذج يتيح توفير خدمات تقنية عبر الإنترنت مثل التخزين والبرمجيات والمعالجة من أي مكان دون الحاجة لأجهزة فائقة محلياً؛ وتشمل Google Drive و Google Docs ومزودي خدمات كبار مثل AWS و Azure و Google Cloud.',
        keyPoints: [
          'أبرز أنواع الخدمات: التخزين السحابي (Google Drive, OneDrive) والبرمجيات السحابية (Google Docs, Sheets, Classroom).',
          'مراحل معالجة البيانات السحابية الست: جمع البيانات -> الإرسال للسحابة -> المعالجة -> التخزين -> التحليل -> العرض للمستخدم.',
          'من أشهر مزودي خدمات الحوسبة السحابية: Amazon Web Services (AWS)، Microsoft Azure، و Google Cloud Platform.',
          'متطلبات الاستخدام: اتصال إنترنت مستقر واهتمام بأمان كلمات المرور والخصوصية.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c2-l3-q1',
            question: 'من أمثلة خدمات التخزين السحابي التي تتيح حفظ ومشاركة الملفات عبر الإنترنت:',
            options: ['Google Drive و OneDrive', 'Notepad و Paint', 'Setup.exe', 'منفذ LPT1'],
            correctIndex: 0,
            explanation: 'Google Drive و Microsoft OneDrive أشهر خدمات التخزين السحابي.',
          },
          {
            id: 'p1-c2-l3-q2',
            question: 'أي من التالية ليس من مزودي البنية التحتية للحوسبة السحابية عالمياً؟',
            options: ['AWS', 'Microsoft Azure', 'Google Cloud', 'مستند Word محلي'],
            correctIndex: 3,
            explanation: 'AWS و Azure و Google Cloud من أكبر مزودي السحابة في العالم.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c2-l3-tf1',
            statement: 'تتيح الحوسبة السحابية الوصول إلى ملفاتك والعمل عليها بشكل تعاوني مع زملائك عبر Google Docs في نفس اللحظة.',
            isTrue: true,
            explanation: 'صحيح — المشاركة الفورية من أهم مزايا البرمجيات السحابية.',
          },
          {
            id: 'p1-c2-l3-tf2',
            statement: 'يمكنك استخدام خدمات الحوسبة السحابية ومزامنة الملفات الجديدة دون وجود اتصال بالإنترنت مطلقاً.',
            isTrue: false,
            explanation: 'خطأ — المزامنة السحابية والوصول عبر السحابة يتطلبان اتصالاً بالإنترنت.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c2-l3-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: نموذج لتوفير خدمات الحوسبة (التخزين والبرمجيات والمعالجة) عبر الإنترنت في أي وقت ومن أي مكان.',
            modelAnswer: 'الحوسبة السحابية (Cloud Computing)',
            keywords: ['الحوسبة السحابية', 'cloud'],
          },
          {
            id: 'p1-c2-l3-es2',
            questionType: 'essay',
            question: 'اذكر ثلاثة من أشهر مزودي خدمات الحوسبة السحابية في العالم.',
            modelAnswer: 'Amazon Web Services (AWS)، و Microsoft Azure، و Google Cloud Platform.',
            keywords: ['aws', 'azure', 'google cloud'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c2-l3-code1',
            language: 'javascript',
            title: 'عملي الدرس 6: حساب السعة السحابية المتبقية في Google Drive',
            prompt:
              'إذا كانت السعة المجانية في Google Drive هي 15 جيجابايت واستهلكت 4.5 جيجابايت، احسب remaining = totalGB - usedGB واطبع 10.5.',
            subjectContext: 'الصف الأول الإعدادي — إدارة التخزين السحابي',
            starterCode: `const totalGB = 15;\nconst usedGB = 4.5;\nconst remaining = 0;\nconsole.log(remaining);`,
            hint: 'const remaining = totalGB - usedGB;',
            expectedOutputContains: ['10.5'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p1-c2', 'الفصل 2 (أولى إعدادي)', [
      { q: 'منفذ توصيل الطابعات القياسي الحديث هو:', opts: ['LPT1', 'USB', 'VGA', 'PS/2'], ans: 1, exp: 'منفذ USB هو القياسي حالياً.' },
      { q: 'الرمز الفاصل في كل بريد إلكتروني هو:', opts: ['#', '@', '$', '%'], ans: 1, exp: 'الرمز @ يفصل الاسم عن النطاق.' },
      { q: 'أداة سحابية من جوجل لكتابة المستندات ومشاركتها:', opts: ['Google Docs', 'Paint', 'Calculator', 'LPT1'], ans: 0, exp: 'Google Docs برنامج معالجة نصوص سحابي.' },
      { q: 'إزالة البرنامج بطريقة آمنة في ويندوز تتم عبر:', opts: ['سلة المحذوفات مباشرة', 'Uninstall a Program من Control Panel', 'إعادة التشغيل فقط', 'تغيير الاسم'], ans: 1, exp: 'Uninstall a Program يزيل البرنامج وكامل ملفاته.' },
      { q: 'يُطلق على البريد غير المرغوب فيه مصطلح:', opts: ['Drive', 'Spam', 'Driver', 'Cloud'], ans: 1, exp: 'Spam هي الرسائل المزعجة.' },
    ]),
  },
  {
    id: 'p1-ict-t1-c3',
    order: 3,
    term: 1,
    title: 'الفصل الثالث: جوجل ميت وقواعد البيانات والنماذج والاستعلامات',
    description: 'دروس (7–9): عقد الاجتماعات عبر Google Meet، تصميم الجداول والمفتاح الأساسي في Access، والنماذج Forms والاستعلامات Queries.',
    lessons: [
      {
        id: 'p1-ict-t1-c3-l1',
        order: 1,
        title: 'الدرس السابع: جوجل ميت وإدارة مشروعك (Google Meet)',
        durationMinutes: 15,
        summary:
          'خدمة مؤتمرات فيديو سحابية مجانية من Google تدعم إنشاء اجتماعات فورية أو مجدولة، ومشاركة الشاشة، والدردشة أثناء المكالمة، مع آداب واضحة لإدارة الاجتماع الرقمي بنجاح.',
        keyPoints: [
          'إنشاء اجتماع: عبر New Meeting -> Start an instant meeting (فوري) أو Create a meeting for later (مجدول لوقت لاحق).',
          'الانضمام لاجتماع: إدخال رمز الاجتماع في خانة Enter a code or link ثم Join.',
          'قواعد وآداب الاجتماع: كتم الميكروفون عند عدم التحدث، استخدام زر رفع اليد، ومشاركة العروض في In-call messages.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c3-l1-q1',
            question: 'لبدء اجتماع فوري مباشرة داخل تطبيق Google Meet نضغط New Meeting ثم نختار:',
            options: [
              'Sign out',
              'Start an instant meeting',
              'Uninstall',
              'Datasheet View',
            ],
            correctIndex: 1,
            explanation: 'الخيار Start an instant meeting يبدأ اجتماع الفيديو فوراً.',
          },
          {
            id: 'p1-c3-l1-q2',
            question: 'من القواعد السلوكية الصحيحة أثناء اجتماع Google Meet لتقليل الضوضاء:',
            options: [
              'ترك الميكروفون مفتوحاً طوال الوقت',
              'كتم الميكروفون (Mute) واستخدام زر رفع اليد عند الرغبة في التحدث',
              'مغادرة الاجتماع بدون إذن المعلم',
              'تشغيل ملفات عشوائية بصوت مرتفع',
            ],
            correctIndex: 1,
            explanation: 'كتم المايك ورفع اليد ينظمان الحوار ويمنعان التداخل الصوتي.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c3-l1-tf1',
            statement: 'يتيح خيار Create a meeting for later الحصول على رابط اجتماع لحفظه ومشاركته في موعد قادم.',
            isTrue: true,
            explanation: 'صحيح — يُنشئ رابطاً جاهزاً للجدولة لاحقاً.',
          },
          {
            id: 'p1-c3-l1-tf2',
            statement: 'لا يحتوي تطبيق Google Meet على نافذة لإرسال رسائل نصية أثناء المكالمة.',
            isTrue: false,
            explanation: 'خطأ — تتوفر خدمة In-call messages لإرسال الرسائل والروابط.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c3-l1-es1',
            questionType: 'essay',
            question: 'اذكر ثلاث قواعد تنظيمية يجب الالتزام بها أثناء المشاركة في اجتماع Google Meet.',
            modelAnswer: 'كتم الميكروفون عند عدم التحدث، رفع اليد لطلب الإذن بالكلام، والتركيز أثناء العرض وعدم التشتت.',
            keywords: ['كتم', 'رفع اليد', 'التركيز'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c3-l1-code1',
            language: 'javascript',
            title: 'عملي الدرس 7: منسّق رابط دعوة Google Meet',
            prompt:
              'اجمع domain = "https://meet.google.com/" مع code = "abc-defg-hij" واطبع الرابط الكامل.',
            subjectContext: 'الصف الأول الإعدادي — روابط الاجتماعات السحابية',
            starterCode: `const domain = "https://meet.google.com/";\nconst code = "abc-defg-hij";\nconst meetingLink = "";\nconsole.log(meetingLink);`,
            hint: 'const meetingLink = domain + code;',
            expectedOutputContains: ['https://meet.google.com/abc-defg-hij'],
          },
        ],
      },
      {
        id: 'p1-ict-t1-c3-l2',
        order: 2,
        title: 'الدرس الثامن: تصميم قواعد البيانات (Databases Design - Access)',
        durationMinutes: 20,
        summary:
          'قاعدة البيانات هي مجموعة منظمة من البيانات مرتبطة بموضوع معين في صورة جداول (Tables)؛ كل صف يُسمى سجلاً (Record) وكل عمود يُسمى حقلاً (Field)، ويُميز المفتاح الأساسي (Primary Key) كل سجل بقيمة فريدة لا تتكرر.',
        keyPoints: [
          'مقارنة: Word لكتابة النصوص، Excel للعمليات الحسابية على البيانات، و Access لإدارة قواعد البيانات الكبيرة والمترابطة.',
          'بنية الجدول: الصف = سجل (Record) يمثل شخصاً أو عنصراً واحداً، والعمود = حقل (Field) يمثل صفة واحدة.',
          'المفتاح الأساسي (Primary Key): حقل قيمته فريدة لا تتكرر ولا يُترك فارغاً (مثل ID بنوع AutoNumber).',
          'عرض التصميم Table Design لتعريف الحقول والأنواع، وعرض ورقة البيانات Datasheet View لإدخال السجلات.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c3-l2-q1',
            question: 'في جدول قاعدة البيانات، يُمثل الصف الواحد .......... بينما يُمثل العمود ..........:',
            options: [
              'حقلاً / سجلاً',
              'سجلاً (Record) / حقلاً (Field)',
              'استعلاماً / تقريراً',
              'نموذجاً / مفتاحاً',
            ],
            correctIndex: 1,
            explanation: 'كل صف سجل متكامل لطالب أو عنصر، وكل عمود حقل لصفة محددة مثل الاسم أو الدرجة.',
          },
          {
            id: 'p1-c3-l2-q2',
            question: 'ما الشرط الأساسي في حقل المفتاح الأساسي (Primary Key) مثل كود الطالب ID؟',
            options: [
              'أن يتكرر لجميع الطلاب',
              'أن تكون قيمته فريدة لا تتكرر وتُميز كل سجل',
              'أن يكون فارغاً دائماً',
              'أن يحتوي على صور فقط',
            ],
            correctIndex: 1,
            explanation: 'المفتاح الأساسي يمنع التكرار ويضمن تمييز كل سجل بدقة.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c3-l2-tf1',
            statement: 'يُفضل استخدام برنامج Microsoft Access بدلاً من Word عندما نحتاج لإدارة قاعدة بيانات ضخمة وجداول مترابطة.',
            isTrue: true,
            explanation: 'صحيح — Access مصمم لإدارة قواعد البيانات العلائقية الكبيرة.',
          },
          {
            id: 'p1-c3-l2-tf2',
            statement: 'نوع البيانات AutoNumber يقوم بترقيم السجلات تلقائياً دون تكرار.',
            isTrue: true,
            explanation: 'صحيح — AutoNumber يُستخدم بكثرة كـ Primary Key.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c3-l2-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: حقل في جدول قاعدة البيانات تُستخدم قيمته الفريدة غير المتكررة لتمييز كل سجل.',
            modelAnswer: 'المفتاح الأساسي (Primary Key)',
            keywords: ['المفتاح الأساسي', 'primary key'],
          },
          {
            id: 'p1-c3-l2-es2',
            questionType: 'essay',
            question: 'قارن باختصار بين استخدام Word و Excel و Access في التعامل مع البيانات.',
            modelAnswer: 'Word لكتابة وتنسيق النصوص، Excel لإجراء الحسابات والرسوم البيانية على الجداول، و Access لإنشاء وإدارة قواعد البيانات الكبيرة والمترابطة.',
            keywords: ['نصوص', 'حساب', 'قواعد البيانات'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c3-l2-code1',
            language: 'javascript',
            title: 'عملي الدرس 8: تمثيل سجل (Record) والتحقق من عدم تكرار Primary Key',
            prompt:
              'أكمل الكود للتحقق مما إذا كان newId = 102 موجوداً بالفعل في المصفوفة existingIds = [101, 102, 103]؛ يجب أن يطبع "خطأ: المفتاح الأساسي مكرر".',
            subjectContext: 'الصف الأول الإعدادي — قاعدة بيانات Access والمفتاح الأساسي',
            starterCode: `const existingIds = [101, 102, 103];\nconst newId = 102;\nif (!existingIds.includes(newId)) {\n  console.log("تم القبول");\n} else {\n  console.log("اكتب رسالة رفض التكرار");\n}`,
            hint: 'غيّر النص في else إلى "خطأ: المفتاح الأساسي مكرر".',
            expectedOutputContains: ['خطأ: المفتاح الأساسي مكرر'],
          },
        ],
      },
      {
        id: 'p1-ict-t1-c3-l3',
        order: 3,
        title: 'الدرس التاسع: النماذج والاستعلامات (Forms & Queries)',
        durationMinutes: 20,
        summary:
          'النموذج (Form) واجهة رسومية سهلة لإدخال وعرض البيانات سجلاً بسجل، بينما الاستعلام (Query) أداة لاستخلاص وتصفية بيانات محددة من الجدول باستخدام صف المعايير Criteria وزر التشغيل Run.',
        keyPoints: [
          'النموذج Form يتيح التنقل عبر أزرار First / Previous / Next / Last record وتعديل التصميم بـ Layout View.',
          'تصميم الاستعلام Query Design ينقسم إلى جزأين: الجزء العلوي يعرض جدول البيانات، والجزء السفلي شبكة التصميم.',
          'صف Show يحدد إظهار أو إخفاء الحقل في نتيجة الاستعلام.',
          'صف Criteria يُكتب فيه شرط التصفية (مثل > 18 أو "ياسمين") ثم نضغط Run لتنفيذ الاستعلام.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c3-l3-q1',
            question: 'لتحديد شرط تصفية البيانات أثناء تصميم الاستعلام (مثل درجة > 18)، نكتب الشرط في صف:',
            options: ['Table', 'Sort', 'Show', 'Criteria'],
            correctIndex: 3,
            explanation: 'صف Criteria مخصص لكتابة معايير وشروط الاستعلام في Access.',
          },
          {
            id: 'p1-c3-l3-q2',
            question: 'ينقسم إطار تصميم الاستعلام (Query Design) إلى جزأين؛ الجزء السفلي يُسمى:',
            options: [
              'سلة المحذوفات',
              'شبكة التصميم (Design Grid)',
              'منفذ LPT1',
              'ورقة العمل النصية',
            ],
            correctIndex: 1,
            explanation: 'الجزء العلوي به الجداول والجزء السفلي هو شبكة تصميم الاستعلام.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c3-l3-tf1',
            statement: 'يُستخدم النموذج (Form) لتسهيل إدخال وتصفح سجلات الجدول سجلاً بسجل بدلاً من التعامل المباشر مع الجدول الضخم.',
            isTrue: true,
            explanation: 'صحيح — النماذج واجهة منظمة لإدخال وعرض السجلات.',
          },
          {
            id: 'p1-c3-l3-tf2',
            statement: 'إزالة علامة الصح في صف Show داخل شبكة الاستعلام يحذف العمود نهائياً من الجدول الأصلي.',
            isTrue: false,
            explanation: 'خطأ — صف Show يخفي الحقل من نتيجة عرض الاستعلام فقط مع بقاء البيانات في الجدول الأصلي.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c3-l3-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: واجهة مصممة لإدخال وعرض وتعديل بيانات جدول قاعدة البيانات بطريقة منظمة ومريحة.',
            modelAnswer: 'النموذج (Form)',
            keywords: ['النموذج', 'form'],
          },
          {
            id: 'p1-c3-l3-es2',
            questionType: 'essay',
            question: 'اشرح وظيفة كل من صف Show وصف Criteria داخل شبكة تصميم الاستعلام (Query Design).',
            modelAnswer: 'صف Show لتحديد إظهار أو إخفاء الحقل في نتائج الاستعلام، وصف Criteria لوضع الشرط الذي يتم تصفية السجلات بناءً عليه.',
            keywords: ['إظهار', 'إخفاء', 'الشرط'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c3-l3-code1',
            language: 'javascript',
            title: 'عملي الدرس 9: تنفيذ شرط استعلام Criteria (درجة الإنجليزي > 18)',
            prompt:
              'نفّذ استعلاماً برمجياً على سجلات الطلاب بحيث يُخرج فقط أسماء الطلاب الذين حصلوا على درجة english > 18 (يجب أن يطبع ياسمين).',
            subjectContext: 'الصف الأول الإعدادي — محاكاة Query Design و Criteria',
            starterCode: `const records = [\n  { name: "أحمد", english: 16 },\n  { name: "ياسمين", english: 20 },\n  { name: "كريم", english: 18 }\n];\nconst result = records.filter(r => r.english > 25);\nconsole.log(result.map(r => r.name).join(", "));`,
            hint: 'عدّل الشرط inside filter إلى r.english > 18.',
            expectedOutputContains: ['ياسمين'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p1-c3', 'الفصل 3 (أولى إعدادي)', [
      { q: 'أداة تتيح عقد اجتماعات فيديو وتعليم عن بُعد من جوجل:', opts: ['Google Meet', 'MS Access', 'Setup.exe', 'Control Panel'], ans: 0, exp: 'Google Meet مخصص لاجتماعات الفيديو.' },
      { q: 'عرض السجل الأخير في النموذج يتم عبر زر:', opts: ['First record', 'Last record', 'Criteria', 'Show'], ans: 1, exp: 'Last record ينتقل لآخر سجل.' },
      { q: 'لتنفيذ الاستعلام وعرض النتائج نضغط على أيقونة:', opts: ['Run', 'Delete', 'Sign out', 'Mute'], ans: 0, exp: 'أداة Run تنفذ الاستعلام.' },
      { q: 'العمود الواحد داخل جدول قاعدة البيانات يُسمى:', opts: ['سجلاً Record', 'حقلاً Field', 'نموذجاً Form', 'تقريراً Report'], ans: 1, exp: 'العمود هو الحقل Field.' },
      { q: 'لإخفاء حقل من الظهور في نتائج الاستعلام نزيل علامة الصح من صف:', opts: ['Field', 'Criteria', 'Show', 'Sort'], ans: 2, exp: 'Show يتحكم في الإظهار والإخفاء.' },
    ]),
  },
  {
    id: 'p1-ict-t2-c4',
    order: 4,
    term: 2,
    title: 'الفصل الرابع (الترم الثاني): تطبيقات قواعد البيانات والأمان الرقمي',
    description: 'تطوير قواعد البيانات المترابطة، التقارير الاحترافية، وممارسات الحماية السحابية.',
    lessons: [
      {
        id: 'p1-ict-t2-c4-l1',
        order: 1,
        title: 'الدرس الأول (ترم 2): التقارير والعلاقات وحماية البيانات',
        durationMinutes: 16,
        summary:
          'التقارير (Reports) تخرج نتائج الجداول والاستعلامات بصورة جاهزة للطباعة والمشاركة، مع تأمين حسابات التخزين السحابي بكلمات مرور قوية.',
        keyPoints: [
          'التقارير Reports تعرض بيانات الاستعلام بشكل منظم للطباعة.',
          'كلمة المرور القوية تجمع حروفاً كبيرة وصغيرة وأرقاماً ورموزاً.',
        ],
        mcqQuestions: [
          {
            id: 'p1-c4-l1-q1',
            question: 'أي كائن في Access يُستخدم لإعداد البيانات للطباعة الرسمية بشكل منسق؟',
            options: ['التقرير (Report)', 'المجلد', 'الشاشة', 'الطابعة فقط'],
            correctIndex: 0,
            explanation: 'التقارير Reports مخصصة لتنسيق وطباعة المخرجات.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p1-c4-l1-tf1',
            statement: 'الاستعلام Query يمكن أن يكون مصدراً للبيانات عند إنشاء تقرير Report.',
            isTrue: true,
            explanation: 'صحيح — يُبنى التقرير من جدول أو استعلام.',
          },
        ],
        essayQuestions: [
          {
            id: 'p1-c4-l1-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: كائن في قواعد البيانات يُستخدم لعرض وطباعة البيانات في شكل منسق احترافي.',
            modelAnswer: 'التقرير (Report)',
            keywords: ['التقرير', 'report'],
          },
        ],
        codeChallenges: [
          {
            id: 'p1-c4-l1-code1',
            language: 'javascript',
            title: 'عملي الترم 2: فحص طول كلمة المرور السحابية',
            prompt: 'تحقق من أن طول pass = "Shereif#2025" لا يقل عن 8 أحرف واطبع "قوية".',
            subjectContext: 'الصف الأول الإعدادي — الأمان الرقمي',
            starterCode: `const pass = "Shereif#2025";\nif (pass.length >= 20) {\n  console.log("قوية");\n} else {\n  console.log("راجع شرط الطول >= 8");\n}`,
            hint: 'غيّر الشرط إلى (pass.length >= 8).',
            expectedOutputContains: ['قوية'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p1-c4', 'الفصل 4 (أولى إعدادي)', [
      { q: 'الكائن المخصص للطباعة المنسقة في Access هو:', opts: ['Table', 'Report', 'Driver', 'Meet'], ans: 1, exp: 'التقرير Report للطباعة.' },
      { q: 'أقوى كلمة مرور يجب أن تحتوي على:', opts: ['123456 فقط', 'حروف وأرقام ورموز خاصة', 'اسم الطالب فقط', 'تاريخ الميلاد فقط'], ans: 1, exp: 'التنوع يزيد صعوبة التخمين.' },
      { q: 'الرمز المستخدم لفصل أجزاء البريد الإلكتروني:', opts: ['@', '&', '*', '/'], ans: 0, exp: 'الرمز @ أساسي في كل بريد.' },
      { q: 'الأداة المجانية لعقد الدروس أونلاين من جوجل:', opts: ['Google Meet', 'Paint', 'WordPad', 'Calc'], ans: 0, exp: 'Google Meet.' },
      { q: 'خاصية Plug and Play خاصة بـ:', opts: ['تعرف النظام التلقائي على الأجهزة عند توصيلها', 'إرسال رسائل Spam', 'تصميم الشعارات', 'الري بالتنقيط'], ans: 0, exp: 'Plug and Play توصيل وتشغيل تلقائي.' },
    ]),
  },
];

/* ============================================================================
 * 2) الصف الثاني الإعدادي — الحاسب والذكاء الاصطناعي و HTML/CSS (مذكرة أ. محمد الشريف)
 * ============================================================================ */
const prep2IctChapters: CurriculumChapter[] = [
  {
    id: 'p2-ict-t1-c1',
    order: 1,
    term: 1,
    title: 'الوحدة الأولى (الفصل 1): الأنظمة الذكية والتهديدات السيبرانية المتقدمة',
    description: 'الدرس 1: الأنظمة الذكية (IoT + AI + Robotics) وتأثيرها المناخي | الدرس 2: برامج الفدية والهندسة الاجتماعية و DDoS.',
    lessons: [
      {
        id: 'p2-ict-t1-c1-l1',
        order: 1,
        title: 'الدرس الأول: الأنظمة الذكية وتأثيرها على التغيرات المناخية',
        durationMinutes: 18,
        summary:
          'تتكون الأنظمة الذكية من تكامل إنترنت الأشياء (IoT) والذكاء الاصطناعي (AI) والروبوتات (Robotics)؛ وتُستخدم في السيارات الذكية والمنازل الذكية والزراعة الذكية لمواجهة تحديات الاحتباس الحراري وتلوث الهواء والجفاف والفيضانات وذوبان الجليد.',
        keyPoints: [
          'المكونات الثلاثة للنظام الذكي المتكامل: IoT (جمع البيانات بالاستشعار) + AI (التحليل واتخاذ القرار) + Robotics (التنفيذ المادي).',
          'التطبيقات: السيارة الذكية GPS، المنزل الذكي (تحكم بالإضاءة والتكييف)، الزراعة الذكية، الروبوت المدرسي، والمساعد الصوتي.',
          'المشكلات المناخية التي تعالجها الأنظمة الذكية: الاحتباس الحراري، تلوث الهواء، نقص المياه والجفاف، الفيضانات والأمطار الغزيرة، وذوبان الجليد.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c1-l1-q1',
            question: 'يتكامل في النظام الذكي الحديث ثلاث تقنيات رئيسية هي:',
            options: [
              'Word و Excel و Paint',
              'إنترنت الأشياء (IoT) والذكاء الاصطناعي (AI) والروبوتات (Robotics)',
              'الطابعة والماوس والكيبورد فقط',
              'برامج الفدية و DDoS',
            ],
            correctIndex: 1,
            explanation: 'تجمع الأنظمة الذكية بين استشعار IoT وتحليل AI وتنفيذ Robotics.',
          },
          {
            id: 'p2-c1-l1-q2',
            question: 'كيف تساعد الأنظمة الذكية في مواجهة مشكلة الجفاف ونقص المياه؟',
            options: [
              'غمر الأراضي الزراعية عشوائياً بالمياه',
              'الري الذكي بناءً على بيانات حساسات رطوبة التربة والطقس',
              'إيقاف محطات تحلية المياه',
              'استهلاك طاقة كهربائية مضاعفة',
            ],
            correctIndex: 1,
            explanation: 'أنظمة الزراعة الذكية تقيس رطوبة التربة وتحدد كمية المياه الدقيقة.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c1-l1-tf1',
            statement: 'يستطيع المنزل الذكي التحكم في الإضاءة والتكييف تلقائياً لتقليل هدر الطاقة والحد من الاحتباس الحراري.',
            isTrue: true,
            explanation: 'صحيح — الأتمتة الذكية ترشّد استهلاك الكهرباء.',
          },
          {
            id: 'p2-c1-l1-tf2',
            statement: 'إنترنت الأشياء (IoT) يعني فقط تصفح المواقع عبر الكمبيوتر المكتبي ولا يشمل الحساسات.',
            isTrue: false,
            explanation: 'خطأ — IoT يربط الأجهزة والحساسات بالإنترنت لتبادل البيانات.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c1-l1-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: تقنية تربط الأجهزة المادية والحساسات بالإنترنت لجمع وتبادل البيانات دون تدخل بشري مباشر.',
            modelAnswer: 'إنترنت الأشياء (Internet of Things - IoT)',
            keywords: ['إنترنت الأشياء', 'iot'],
          },
          {
            id: 'p2-c1-l1-es2',
            questionType: 'essay',
            question: 'اذكر أربع مشكلات مناخية عالمية تساعد الأنظمة الذكية في مواجهتها أو الحد من آثارها.',
            modelAnswer: 'الاحتباس الحراري، تلوث الهواء، نقص المياه والجفاف، الفيضانات والأمطار الغزيرة، وذوبان الجليد.',
            keywords: ['الاحتباس الحراري', 'تلوث', 'الجفاف', 'الفيضانات'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c1-l1-code1',
            language: 'javascript',
            title: 'عملي الدرس 1: خوارزمية تحكم AI في التكييف الذكي لتقليل الطاقة',
            prompt:
              'أكمل المنطق البرمجي للنظام الذكي: إذا كانت roomTemp = 29 أعلى من 26 و peopleCount > 0 اطبع "تشغيل التبريد الاقتصادي".',
            subjectContext: 'الصف الثاني الإعدادي — المنزل الذكي وإنترنت الأشياء',
            starterCode: `const roomTemp = 29;\nconst peopleCount = 3;\nif (roomTemp > 40 && peopleCount > 0) {\n  console.log("تشغيل التبريد الاقتصادي");\n} else {\n  console.log("عدل الشرط لدرجة حرارة > 26");\n}`,
            hint: 'غيّر 40 إلى 26.',
            expectedOutputContains: ['تشغيل التبريد الاقتصادي'],
          },
        ],
      },
      {
        id: 'p2-ict-t1-c1-l2',
        order: 2,
        title: 'الدرس الثاني: التهديدات السيبرانية المتقدمة',
        durationMinutes: 19,
        summary:
          'يتناول الدرس أخطر الهجمات الإلكترونية الحديثة: برامج الفدية (Ransomware) التي تشفّر الملفات وتطلب فدية، وهجمات الهندسة الاجتماعية (التصيد الموجه Spear Phishing، انتحال الشخصية Pretexting، الاستدراج Baiting)، وهجمات حجب الخدمة الموزعة (DDoS) عبر شبكات Botnets.',
        keyPoints: [
          'برامج الفدية (Ransomware): خبيثة تشفر ملفات الضحية وتطلب مالاً لفك التشفير (الوقاية: نسخ احتياطي وعدم دفع الفدية).',
          'التصيد الموجه (Spear Phishing): رسائل مزيفة تستهدف شخصاً أو مؤسسة محددة باسمها وبياناتها.',
          'انتحال الشخصية (Pretexting): اختلاق قصة وهمية (مثل موظف دعم فني) لخداع الضحية والحصول على كلمات السر.',
          'الاستدراج (Baiting): وضع طعم مثل فلاشة USB مصابة في مكان عام أو عرض تحميل مجاني لإغراء الضحية.',
          'هجمات حجب الخدمة الموزعة (DDoS): إغراق خادم الموقع بطلبات هائلة من أجهزة مخترقة (Botnets) لتعطيله.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c1-l2-q1',
            question: 'أي نوع من الهندسة الاجتماعية يعتمد على ترك قرص USB مصاب أو تقديم عرض مغرٍ كطُعم للإيقاع بالضحية؟',
            options: ['Pretexting', 'Baiting (الاستدراج)', 'DDoS Attack', 'Green Tech'],
            correctIndex: 1,
            explanation: 'الاستدراج Baiting يستخدم طعماً مادياً أو رقمياً لإغراء الضحية بتوصيله أو تحميله.',
          },
          {
            id: 'p2-c1-l2-q2',
            question: 'شبكة من الأجهزة المخترقة يتحكم بها المهاجم عن بُعد لتنفيذ هجمات DDoS تُسمى:',
            options: ['Botnets', 'CSS Selectors', 'AutoNumber', 'Drivers'],
            correctIndex: 0,
            explanation: 'Botnets هي جيوش الأجهزة المخترقة المستخدمة لإغراق الخوادم في هجمات DDoS.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c1-l2-tf1',
            statement: 'التصيد الموجه (Spear Phishing) يتميز باستهداف ضحية أو جهة بعينها بعد جمع معلومات عنها.',
            isTrue: true,
            explanation: 'صحيح — على عكس التصيد العشوائي، التصيد الموجه يكون شخصياً ومخصصاً.',
          },
          {
            id: 'p2-c1-l2-tf2',
            statement: 'تُشفّر برامج الفدية (Ransomware) ملفات الجهاز وتضمن استعادتها دائماً عند دفع المال للمهاجم.',
            isTrue: false,
            explanation: 'خطأ — لا يُنصح أبداً بدفع الفدية ولا يوجد ضمان لفك التشفير، والحماية بالنسخ الاحتياطي.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c1-l2-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: برمجية خبيثة تقوم بتشفير ملفات المستخدم وتمنع الوصول إليها مقابل طلب مبلغ مالي.',
            modelAnswer: 'برامج الفدية (Ransomware)',
            keywords: ['الفدية', 'ransomware'],
          },
          {
            id: 'p2-c1-l2-es2',
            questionType: 'essay',
            question: 'فرّق بين انتحال الشخصية (Pretexting) وهجمات حجب الخدمة الموزعة (DDoS).',
            modelAnswer: 'Pretexting يعتمد على اختلاق قصة وهمية لخداع الضحية وسرقة بياناته، بينما DDoS هو إغراق خادم الموقع بطلبات هائلة عبر شبكات Botnets لتعطيله عن العمل.',
            keywords: ['قصة وهمية', 'إغراق', 'botnets'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c1-l2-code1',
            language: 'javascript',
            title: 'عملي الدرس 2: كاشف هجمات إغراق الخادم DDoS Rate Limiter',
            prompt:
              'أكمل الدالة لتكتشف ما إذا تجاوزت طلبات IP رقم 100 طلب في الثانية (requestsPerSec = 450) وتطبع "حظر: اشتباه هجوم DDoS".',
            subjectContext: 'الصف الثاني الإعدادي — الحماية من هجمات حجب الخدمة',
            starterCode: `const requestsPerSec = 450;\nif (requestsPerSec > 1000) {\n  console.log("حظر: اشتباه هجوم DDoS");\n} else {\n  console.log("طبيعي");\n}`,
            hint: 'عدّل الحد threshold إلى 100 ليتم رصد 450 طلباً.',
            expectedOutputContains: ['حظر: اشتباه هجوم DDoS'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p2-c1', 'الوحدة 1 ج1 (ثانية إعدادي)', [
      { q: 'تجمع الأنظمة الذكية بين IoT و Robotics و:', opts: ['الذكاء الاصطناعي AI', 'LPT1', 'Ransomware', 'Baiting'], ans: 0, exp: 'AI هي ركن التحليل والقرار.' },
      { q: 'اختلاق المهاجم لدور موظف بنك لسرقة كلمة المرور يسمى:', opts: ['DDoS', 'Pretexting', 'Ransomware', 'IoT'], ans: 1, exp: 'Pretexting يعني انتحال شخصية بقصة مختلقة.' },
      { q: 'تعمل هجمات DDoS غالباً عبر شبكة أجهزة مخترقة تسمى:', opts: ['Drivers', 'Botnets', 'Spam', 'Selectors'], ans: 1, exp: 'Botnets تنفذ الإغراق.' },
      { q: 'أفضل حماية استباقية ضد فقدان الملفات بسبب برامج الفدية:', opts: ['الاحتفاظ بنسخ احتياطية منتظمة معزولة', 'فتح كل الروابط الغريبة', 'إلغاء كلمة المرور', 'ترك فلاشة مجهولة بالجهاز'], ans: 0, exp: 'النسخ الاحتياطي يحمي البيانات من التشفير الابتزازي.' },
      { q: 'تُعد السيارة الذكية المزودة بـ GPS مثالاً على:', opts: ['الأنظمة الذكية', 'الهندسة الاجتماعية', 'التصميم الورقي', 'CSS فقط'], ans: 0, exp: 'السيارة الذكية نظام ذكي متكامل.' },
    ]),
  },
  {
    id: 'p2-ict-t1-c2',
    order: 2,
    term: 1,
    title: 'الوحدة الأولى (الفصل 2): البيانات الضخمة وعلاقتها بالذكاء الاصطناعي',
    description: 'الدرس 3: خصائص Big Data الـ 5Vs وأنواعها | الدرس 4: مراحل المعالجة الخمس و NLP و Computer Vision و Overfitting.',
    lessons: [
      {
        id: 'p2-ict-t1-c2-l1',
        order: 1,
        title: 'الدرس الثالث: البيانات الضخمة (Big Data - 5Vs)',
        durationMinutes: 17,
        summary:
          'البيانات الضخمة هي مجموعات بيانات هائلة ومتنوعة وسريعة التدفق تفوق قدرات الأدوات التقليدية، وتتميز بالخصائص الخمس (5Vs) وتنقسم إلى بيانات هيكلية وغير هيكلية وشبه هيكلية.',
        keyPoints: [
          'مصادر البيانات الضخمة الـ 7: أجهزة IoT، وسائل التواصل الاجتماعي، البيانات المالية، بيانات المواقع GPS، الأجهزة الذكية، البيانات الحكومية، والمحتوى الرقمي.',
          'الخصائص الخمس 5Vs: الحجم (Volume)، السرعة (Velocity)، التنوع (Variety)، الموثوقية (Veracity)، والقيمة (Value).',
          'الأنواع الثلاثة: هيكلية Structured (جداول منظمة)، غير هيكلية Unstructured (صور وفيديو ونصوص حرة)، وشبه هيكلية Semi-Structured (مثل رسائل البريد الإلكتروني التي تجمع رأساً منظماً ومحتوى نصياً حراً).',
        ],
        mcqQuestions: [
          {
            id: 'p2-c2-l1-q1',
            question: 'أي خاصية من خصائص البيانات الضخمة (5Vs) تعبّر عن دقة البيانات وخلوها من الأخطاء؟',
            options: ['Volume (الحجم)', 'Velocity (السرعة)', 'Veracity (الموثوقية)', 'Variety (التنوع)'],
            correctIndex: 2,
            explanation: 'Veracity تعني موثوقية ودقة وجودة البيانات.',
          },
          {
            id: 'p2-c2-l1-q2',
            question: 'تُصنف رسائل البريد الإلكتروني وملفات JSON غالباً على أنها بيانات:',
            options: [
              'هيكلية فقط (Structured)',
              'شبه هيكلية (Semi-Structured)',
              'ورقية تقليدية',
              'ثابتة غير رقمية',
            ],
            correctIndex: 1,
            explanation: 'البريد الإلكتروني شبه هيكلي لوجود حقول منظمة (المرسل، التاريخ) ومحتوى نصي غير منظم.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c2-l1-tf1',
            statement: 'تشمل خاصية التنوع (Variety) قدوم البيانات الضخمة في أشكال متعددة مثل نصوص وصور وفيديو وأرقام.',
            isTrue: true,
            explanation: 'صحيح — التنوع يعني اختلاف تنسيقات ومصادر البيانات.',
          },
          {
            id: 'p2-c2-l1-tf2',
            statement: 'الصور ومقاطع الفيديو المنشورة على منصات التواصل تُعد أمثلة على البيانات الهيكلية المرتبة في جداول.',
            isTrue: false,
            explanation: 'خطأ — الصور والفيديو بيانات غير هيكلية (Unstructured).',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c2-l1-es1',
            questionType: 'essay',
            question: 'اذكر الخصائص الخمس للبيانات الضخمة (5Vs) مع شرح مختصر لاثنتين منها.',
            modelAnswer: 'Volume (الحجم الهائل)، Velocity (السرعة العالية للتدفق)، Variety (التنوع في الأشكال)، Veracity (الموثوقية والدقة)، Value (القيمة المستخلصة منها).',
            keywords: ['volume', 'velocity', 'variety', 'veracity', 'value'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c2-l1-code1',
            language: 'javascript',
            title: 'عملي الدرس 3: حساب إجمالي سجل البيانات المتدفقة (Volume & Velocity)',
            prompt:
              'إذا أنتج كل جهاز من 1000 جهاز استشعار IoT حوالي 200 سجل في الساعة، احسب totalRecords = sensors * recordsPerHour واطبع 200000.',
            subjectContext: 'الصف الثاني الإعدادي — حساب حجم وسرعة البيانات الضخمة',
            starterCode: `const sensors = 1000;\nconst recordsPerHour = 200;\nconst totalRecords = 0;\nconsole.log(totalRecords);`,
            hint: 'const totalRecords = sensors * recordsPerHour;',
            expectedOutputContains: ['200000'],
          },
        ],
      },
      {
        id: 'p2-ict-t1-c2-l2',
        order: 2,
        title: 'الدرس الرابع: البيانات الضخمة وعلاقتها بالذكاء الاصطناعي',
        durationMinutes: 18,
        summary:
          'تُعد البيانات الضخمة الوقود الأساسي لتدريب نماذج الذكاء الاصطناعي عبر 5 مراحل معالجة، وتمكن تطبيقات مثل معالجة اللغات الطبيعية (NLP)، والرؤية الحاسوبية (Computer Vision)، والتحليلات التنبؤية مع تجنب ظاهرة فرط التخصيص (Overfitting).',
        keyPoints: [
          'المراحل الخمس لمعالجة البيانات الضخمة: 1) التجميع -> 2) التخزين -> 3) التنظيف -> 4) التحليل -> 5) استخلاص المعلومات.',
          'مشكلة Overfitting (فرط التخصيص): عندما يحفظ النموذج بيانات التدريب بدقة متناهية فيفشل عند اختبار بيانات جديدة مختلفة.',
          'معالجة اللغات الطبيعية (NLP): فهم وتوليد لغة البشر مثل نماذج GPT.',
          'الرؤية الحاسوبية (Computer Vision): تمييز الصور والفيديو مثل القيادة الذاتية والتعرف على الوجوه.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c2-l2-q1',
            question: 'يحدث خطأ فرط التخصيص (Overfitting) في تدريب نماذج الذكاء الاصطناعي عندما:',
            options: [
              'تكون البيانات نظيفة ومتنوعة',
              'يحفظ النموذج أمثلة التدريب حرفياً ولا يعمم على بيانات جديدة',
              'يزيد حجم الشاشة',
              'تُحفظ البيانات في ملف CSS',
            ],
            correctIndex: 1,
            explanation: 'Overfitting يجعل دقة التدريب عالية جداً بينما ينخفض الأداء على البيانات الجديدة.',
          },
          {
            id: 'p2-c2-l2-q2',
            question: 'الفرع المسؤول عن فهم وتحليل النصوص والكلام البشري في الذكاء الاصطناعي (مثل المساعد الصوتي وGPT) هو:',
            options: [
              'الري بالتنقيط',
              'معالجة اللغات الطبيعية (NLP)',
              'معالجة المياه',
              'التوصيل والتشغيل',
            ],
            correctIndex: 1,
            explanation: 'NLP (Natural Language Processing) تختص بفهم وإنتاج اللغات البشرية.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c2-l2-tf1',
            statement: 'تسبق مرحلة تنظيف البيانات (Data Cleaning) مرحلة تحليل البيانات واستخلاص المعلومات.',
            isTrue: true,
            explanation: 'صحيح — الترتيب: تجميع -> تخزين -> تنظيف -> تحليل -> استخلاص معلومات.',
          },
          {
            id: 'p2-c2-l2-tf2',
            statement: 'تُستخدم الرؤية الحاسوبية (Computer Vision) في تعرف الكاميرات على الإشارات والوجوه.',
            isTrue: true,
            explanation: 'صحيح — الرؤية الحاسوبية تحلل المدخلات البصرية من الصور والفيديو.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c2-l2-es1',
            questionType: 'essay',
            question: 'رتّب المراحل الخمس لمعالجة البيانات الضخمة واستخدامها في الذكاء الاصطناعي.',
            modelAnswer: '1) تجميع البيانات، 2) تخزين البيانات، 3) تنظيف البيانات، 4) تحليل البيانات، 5) استخلاص المعلومات.',
            keywords: ['تجميع', 'تخزين', 'تنظيف', 'تحليل', 'استخلاص'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c2-l2-code1',
            language: 'javascript',
            title: 'عملي الدرس 4: مرحلة تنظيف البيانات (Data Cleaning) قبل التدريب',
            prompt:
              'قم بتصفية المصفوفة rawAges = [14, -5, 13, 999, 15] لإبقاء الأعمار المنطقية بين 5 و 100 فقط، واطبع المصفوفة النظيفة (تتضمن 14 و 13 و 15).',
            subjectContext: 'الصف الثاني الإعدادي — تنظيف البيانات الضخمة للذكاء الاصطناعي',
            starterCode: `const rawAges = [14, -5, 13, 999, 15];\nconst cleaned = rawAges.filter(a => a > 0);\nconsole.log(cleaned);`,
            hint: 'أضف الشرط && a <= 100 و >= 5 ليُزال -5 و 999.',
            expectedOutputContains: ['[14,13,15]'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p2-c2', 'الوحدة 1 ج2 (ثانية إعدادي)', [
      { q: 'الخاصية التي تشير إلى سرعة توليد وتدفق البيانات الضخمة هي:', opts: ['Volume', 'Velocity', 'Veracity', 'Value'], ans: 1, exp: 'Velocity تعني السرعة.' },
      { q: 'تُعد جداول البيانات المنظمة في قواعد البيانات مثالاً على البيانات:', opts: ['الهيكلية Structured', 'غير الهيكلية', 'العشوائية', 'الصوتية فقط'], ans: 0, exp: 'الجداول ذات الأعمدة والصفوف الثابتة هيكلية.' },
      { q: 'تقنية AI التي تميز السيارات والمشاة في كاميرا القيادة الذاتية:', opts: ['Computer Vision', 'Spear Phishing', 'CSS', 'LPT1'], ans: 0, exp: 'الرؤية الحاسوبية تحلل الصور والفيديو.' },
      { q: 'تنظيف البيانات يأتي مباشرة قبل مرحلة:', opts: ['تحليل البيانات', 'إغلاق النظام', 'شراء القرص', 'توزيع الفلاشات'], ans: 0, exp: 'التنظيف يمهد للتحليل الدقيق.' },
      { q: 'حفظ النموذج لبيانات التدريب وفشله مع البيانات الجديدة يُعرف بـ:', opts: ['NLP', 'Overfitting', 'Volume', 'UI'], ans: 1, exp: 'Overfitting يعني فرط التخصيص.' },
    ]),
  },
  {
    id: 'p2-ict-t1-c3',
    order: 3,
    term: 1,
    title: 'الوحدة الثانية (الفصل 3): UX/UI وتصميم مواقع الويب بـ HTML & CSS',
    description: 'دروس (5–8): مبادئ UX/UI، لغة CSS ووسم link، مشروع مدرسة الشريف (school.htm & style.css) في المحرر، وبناء المواقع بالذكاء الاصطناعي.',
    lessons: [
      {
        id: 'p2-ict-t1-c3-l1',
        order: 1,
        title: 'الدرس الخامس: مبادئ تصميم واجهات احترافية (UX / UI)',
        durationMinutes: 16,
        summary:
          'تجربة المستخدم (UX) تركز على سهولة وسلاسة استخدام الموقع وتنقله، بينما واجهة المستخدم (UI) تركز على المظهر البصري الجذاب من ألوان متناسقة وخطوط واضحة وتخطيط منظم.',
        keyPoints: [
          'أهم مبادئ تجربة المستخدم UX: سهولة التنقل (Navigation)، الوضوح (Clarity)، والتناسق (Consistency) في كل الصفحات.',
          'أهم مبادئ واجهة المستخدم UI: اختيار لوحة ألوان متناسقة (2 إلى 3 ألوان أساسية)، الخطوط المناسبة (Fonts)، وتخطيط الصفحة (Layout).',
          'الهدف النهائي: صفحة مريحة للعين وسريعة الفهم للمستخدم على أي شاشة.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c3-l1-q1',
            question: 'أي مما يلي يركز على المظهر المرئي للموقع مثل الألوان والخطوط وتنسيق الأزرار؟',
            options: [
              'واجهة المستخدم (UI)',
              'حجم البيانات الضخمة',
              'نظام التشغيل فقط',
              'برامج الفدية',
            ],
            correctIndex: 0,
            explanation: 'UI (User Interface) تعني الشكل البصري والجمالي للواجهة.',
          },
          {
            id: 'p2-c3-l1-q2',
            question: 'العدد الموصى به للألوان الأساسية المتناسقة في تصميم واجهة موقع ويب مريحة للعين هو:',
            options: ['15 لوناً صارخاً', 'من 2 إلى 3 ألوان متناغمة', 'لون أسود فقط', '50 لوناً مختلفاً'],
            correctIndex: 1,
            explanation: 'اختيار 2–3 ألوان رئيسية يمنح الموقع مظهراً موحداً واحترافياً.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c3-l1-tf1',
            statement: 'التناسق (Consistency) في UX يعني أن الأزرار والقوائم تظهر بأسلوب ثابت ومألوف عبر جميع صفحات الموقع.',
            isTrue: true,
            explanation: 'صحيح — التناسق يقلل حيرة الزائر.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c3-l1-es1',
            questionType: 'essay',
            question: 'فرّق بين تجربة المستخدم (UX) وواجهة المستخدم (UI) مع ذكر مبدأين لكل منهما.',
            modelAnswer: 'UX تختص بسلاسة التفاعل وسهولة الاستخدام (مثل: سهولة التنقل والوضوح والتناسق)، بينما UI تختص بالشكل الجمالي البصري (مثل: الألوان المتناسقة والخطوط والتخطيط).',
            keywords: ['سهولة التنقل', 'الألوان', 'الخطوط'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c3-l1-code1',
            language: 'html_css',
            title: 'عملي الدرس 5 (HTML+CSS): بطاقة واجهة متناسقة بتطبيق مبادئ UI',
            prompt:
              'عدّل اللون الأزرق الداكن في الكود التالي ليصبح العنوان h1 باللون darkblue والخلفية lightcyan لعرض بطاقة UI احترافية في المعاينة الحية.',
            subjectContext: 'الصف الثاني الإعدادي — تطبيق عملي HTML & CSS لمبادئ UI',
            starterCode: `<style>\n  .ui-card { background-color: white; padding: 16px; border-radius: 10px; }\n  h1 { color: gray; }\n</style>\n<div class="ui-card">\n  <h1>واجهة مستخدم احترافية UI</h1>\n  <p>تناسق الألوان ووضوح الخط يرفعان جودة تجربة المستخدم.</p>\n</div>`,
            hint: 'استبدل white بـ lightcyan واستبدل gray بـ darkblue.',
            requiredCodeSnippets: ['lightcyan', 'darkblue'],
            expectedOutputContains: ['واجهة مستخدم احترافية UI'],
          },
        ],
      },
      {
        id: 'p2-ict-t1-c3-l2',
        order: 2,
        title: 'الدرس السادس: تنسيق صفحات الويب (HTML & CSS)',
        durationMinutes: 20,
        summary:
          'تُستخدم HTML لوصف محتوى صفحة الويب، بينما صممت منظمة W3C لغة CSS لفصل التنسيق الجمالي عن هيكل الصفحة؛ وتُكتب القاعدة بصيغة Selector {Property: Value;} ويمكن ربط ملف خارجي عبر وسم <link>.',
        keyPoints: [
          'قديماً استُخدم وسم <font> للتنسيق، لكنه أصبح مهجوراً وصعباً في الصيانة فظهرت CSS من منظمة W3C.',
          'بناء قاعدة CSS: Selector { property: value; } مثل body { background-color: lightblue; }.',
          'طرق كتابة CSS الثلاثة: Inline (داخل الوسم)، Internal (داخل <style>)، و External (ملف .css خارجي منفصل).',
          'وسم ربط ملف التنسيق الخارجي داخل <head>: <link rel="stylesheet" href="style.css">.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c3-l2-q1',
            question: 'ما هي الصيغة الصحيحة لربط ملف تنسيق خارجي style.css بصفحة الويب؟',
            options: [
              '<css src="style.css">',
              '<link rel="stylesheet" href="style.css">',
              '<font href="style.css">',
              '<style link="style.css">',
            ],
            correctIndex: 1,
            explanation: 'يُستخدم الوسم <link> مع rel="stylesheet" و href لاسم الملف.',
          },
          {
            id: 'p2-c3-l2-q2',
            question: 'الجهة العالمية التي ابتكرت لغة CSS لفصل المحتوى عن التنسيق هي:',
            options: ['W3C', 'FBI', 'USB', 'ATM'],
            correctIndex: 0,
            explanation: 'رابطة الشبكة العالمية W3C هي المطورة لمعايير HTML و CSS.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c3-l2-tf1',
            statement: 'التنسيق الخارجي (External CSS) يتيح التحكم في مظهر موقع كامل مكون من عشرات الصفحات بتعديل ملف CSS واحد.',
            isTrue: true,
            explanation: 'صحيح — هذه من أهم فوائد External Stylesheet.',
          },
          {
            id: 'p2-c3-l2-tf2',
            statement: 'في قاعدة CSS يُكتب اسم الخاصية Property بعد القوس { ويُفصل عن القيمة Value بعلامة النقطتين (:).',
            isTrue: true,
            explanation: 'صحيح — مثال: color: white;.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c3-l2-es1',
            questionType: 'essay',
            question: 'اذكر أربعاً من فوائد استخدام لغة CSS في تنسيق صفحات الويب.',
            modelAnswer: 'توفير الوقت والجهد، سهولة تعديل تصميم جميع الصفحات من ملف واحد، تناسق التصميم، وسرعة تحميل الصفحات مع صغر حجم الكود.',
            keywords: ['توفير الوقت', 'التعديل', 'تناسق', 'سرعة'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c3-l2-code1',
            language: 'html_css',
            title: 'عملي الدرس 6 (HTML+CSS): وسم link وقاعدة body',
            prompt:
              'اكتب في المحرر وسم الربط <link rel="stylesheet" href="style.css"> وقاعدة CSS تجعل لون خلفية body هو lightblue ولون الفقرة p هو darkblue.',
            subjectContext: 'الصف الثاني الإعدادي — أساسيات CSS وربط الملفات',
            starterCode: `<!-- أضف وسم link لملف style.css -->\n<link rel="stylesheet" href="style.css">\n<style>\n  body { background-color: white; }\n  p { color: black; font-size: 18px; }\n</style>\n<h2>أهلاً بكم في عالم CSS</h2>\n<p>يتم تنسيق هذا النص باستخدام لغة CSS.</p>`,
            hint: 'غيّر background-color إلى lightblue ولون p إلى darkblue.',
            requiredCodeSnippets: ['<link', 'stylesheet', 'lightblue', 'darkblue'],
            expectedOutputContains: ['<h2>'],
          },
        ],
      },
      {
        id: 'p2-ict-t1-c3-l3',
        order: 3,
        title: 'الدرس السابع: مشروعي الرقمي لمدرستي (school.htm & style.css)',
        durationMinutes: 22,
        summary:
          'تطبيق عملي متكامل لبناء صفحة موقع المدرسة باستخدام الوسوم الدلالية (<div class="container">, <header>, <section>, <footer>) وتنسيقها في style.css بحد سفلي border-bottom وهامش داخلي padding.',
        keyPoints: [
          'هيكل صفحة school.htm: حاوية container بعرض 80% وتوسيط margin: auto وخلفية lightcyan.',
          'ترويسة header بخلفية darkblue ولون خط white وحشو padding: 10px.',
          'عنوان القسم h2 بلون blue وخط سفلي بارز border-bottom: 5px solid blue مع padding-bottom: 10px.',
          'التذييل footer بخلفية black ولون نص white مع رمز حقوق النشر &copy;.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c3-l3-q1',
            question: 'لتحديد عنوان القسم h2 بخط سفلي أزرق بسمك 5 بكسل نستخدم الخاصية:',
            options: [
              'background-color: blue;',
              'border-bottom: 5px solid blue;',
              'margin: auto;',
              'href: blue;',
            ],
            correctIndex: 1,
            explanation: 'خاصية border-bottom ترسم الإطار السفلي بالسمك والنوع واللون المحدد.',
          },
          {
            id: 'p2-c3-l3-q2',
            question: 'الخاصية التي تضبط عرض الحاوية .container لتشغل 80% من عرض الصفحة مع توسيطها أفقياً هي:',
            options: [
              'width: 80%; margin: auto;',
              'padding: 5px;',
              'color: lightcyan;',
              'rel="stylesheet"',
            ],
            correctIndex: 0,
            explanation: 'width يحدد العرض و margin: auto يوسط الحاوية أفقياً.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c3-l3-tf1',
            statement: 'يُستخدم الرمز الكودي &copy; في HTML لعرض علامة حقوق النشر (©) داخل تذييل الصفحة <footer>.',
            isTrue: true,
            explanation: 'صحيح — &copy; هي الكيان القياسي لرمز حقوق الطبع والنشر.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c3-l3-es1',
            questionType: 'essay',
            question: 'اذكر وظيفة كل من الوسوم الدلالية الآتية في صفحة المدرسة: <header> و <section> و <footer>.',
            modelAnswer: '<header> لرأس الصفحة واسم المدرسة، <section> لأقسام المحتوى والمعلومات الأساسية، و <footer> لتذييل الصفحة وحقوق الملكية.',
            keywords: ['رأس', 'أقسام', 'تذييل'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c3-l3-code1',
            language: 'html_css',
            title: 'عملي الدرس 7 (مشروع كتاب المدرسة كامل): school.htm + style.css',
            prompt:
              'أكمل تنسيق ملف style.css المدمج لموقع مدرستك كما في الكتاب: اجعل header بخلفية darkblue ولون white، وأضف لـ h2 خاصية border-bottom: 5px solid blue; وشاهد المعاينة الحية.',
            subjectContext: 'الصف الثاني الإعدادي — المشروع العملي الكامل (school.htm)',
            starterCode: `<style>\n  .container { width: 80%; margin: auto; background-color: lightcyan; padding: 12px; }\n  header { background-color: lightgray; color: black; padding: 10px; }\n  h2 { color: blue; padding-bottom: 10px; }\n  footer { background-color: black; color: white; padding: 8px; text-align: center; }\n</style>\n<div class="container">\n  <header>\n    <h1>مدرسة الشريف الإعدادية الرقمية</h1>\n  </header>\n  <section>\n    <h2>معلومات أساسية</h2>\n    <p>نرحب بكم في بوابة المدرسة التعليمية والأنشطة الرقمية.</p>\n  </section>\n  <footer>\n    <p>&copy; 2025 بيانات المدرسة</p>\n  </footer>\n</div>`,
            hint: 'عدّل header إلى background-color: darkblue; color: white; وأضف لـ h2 السطر border-bottom: 5px solid blue;',
            requiredCodeSnippets: ['darkblue', 'border-bottom', '<header>', '<section>', '<footer>'],
            expectedOutputContains: ['&copy;'],
          },
        ],
      },
      {
        id: 'p2-ict-t1-c3-l4',
        order: 4,
        title: 'الدرس الثامن: إنشاء موقعك الإلكتروني بمساعدة الذكاء الاصطناعي',
        durationMinutes: 16,
        summary:
          'تتيح أدوات مثل wegic.ai و Jimdo Dolphin تصميم مواقع كاملة عبر كتابة أوامر نصية (Prompts) واختيار نمط التصميم ومعارض الصور المناسبة مع مراعاة قواعد الأمان ومشاركة الموقع عبر رمز QR.',
        keyPoints: [
          'منصات التصميم بالذكاء الاصطناعي: wegic.ai و Jimdo Dolphin.',
          'تُصمم الصفحات بكتابة Prompt واضح يصف فكرة الموقع وأسلوبه عبر 3 نوافذ إرشادية.',
          'الأنماط البصرية: Modern (حديث)، Playful (مرح)، Professional (احترافي)، Creative (إبداعي).',
          'أنواع معارض الصور: الشبكة (Grid)، عرض الشرائح (Slideshow)، البناء غير المتساوي (Masonry)، والنافذة المنبثقة (Lightbox).',
        ],
        mcqQuestions: [
          {
            id: 'p2-c3-l4-q1',
            question: 'أي نوع من معارض الصور يفتح الصورة بحجم كبير في نافذة فوق الصفحة عند النقر عليها؟',
            options: ['Grid', 'Lightbox', 'Masonry', 'Header'],
            correctIndex: 1,
            explanation: 'Lightbox يبرز الصورة المختارة في نافذة مكبرة بتعتيم الخلفية.',
          },
          {
            id: 'p2-c3-l4-q2',
            question: 'منصات شهيرة لبناء المواقع إلكترونياً عبر وصف نصي (Prompt) بالذكاء الاصطناعي:',
            options: ['wegic.ai و Jimdo Dolphin', 'LPT1 و INF', 'Paint و Calc', 'Ransomware'],
            correctIndex: 0,
            explanation: 'منصتا wegic.ai و Jimdo Dolphin تنشئان المواقع تلقائياً بالذكاء الاصطناعي.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c3-l4-tf1',
            statement: 'يُفضل عدم إدخال بيانات شخصية حساسة مثل رقم البطاقة عند كتابة Prompt في منصات بناء المواقع بالذكاء الاصطناعي.',
            isTrue: true,
            explanation: 'صحيح — للحفاظ على الأمان والخصوصية الرقمية.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c3-l4-es1',
            questionType: 'essay',
            question: 'اذكر أربعة من أنماط عرض معارض الصور المستخدمة في المواقع الحديثة.',
            modelAnswer: 'الشبكة (Grid)، عرض الشرائح (Slideshow)، الشبكة غير المتساوية (Masonry)، والنافذة المنبثقة (Lightbox).',
            keywords: ['grid', 'slideshow', 'masonry', 'lightbox'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c3-l4-code1',
            language: 'html_css',
            title: 'عملي الدرس 8 (HTML+CSS): معرض صور Grid + بطاقة مشاركة QR',
            prompt:
              'أضف خاصية display: grid; مع grid-template-columns: repeat(2, 1fr); للصف .gallery لعرض بطاقات المعرض في عمودين متناسقين.',
            subjectContext: 'الصف الثاني الإعدادي — تخطيط Grid في مواقع الويب',
            starterCode: `<style>\n  .gallery { display: block; gap: 10px; }\n  .card { background: #0f766e; color: white; padding: 12px; border-radius: 8px; }\n</style>\n<div class="gallery">\n  <div class="card">النمط الاحترافي</div>\n  <div class="card">مشاركة عبر QR Code</div>\n</div>`,
            hint: 'عدّل display: block; إلى display: grid; وأضف grid-template-columns: repeat(2, 1fr);.',
            requiredCodeSnippets: ['display: grid', 'grid-template-columns'],
            expectedOutputContains: ['QR Code'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p2-c3', 'الوحدة 2 الويب (ثانية إعدادي)', [
      { q: 'اللغة المسؤولة عن التنسيق البصري لصفحة HTML هي:', opts: ['CSS', 'Access', 'ATM', 'Pretexting'], ans: 0, exp: 'CSS تحدد الألوان والخطوط والتخطيط.' },
      { q: 'في مدرسة الشريف، الوسم <header> يوضع داخله:', opts: ['تذييل الحقوق', 'رأس الصفحة وعنوان المدرسة', 'بيانات الدفع فقط', 'جدول Access'], ans: 1, exp: '<header> لرأس الصفحة.' },
      { q: 'التجربة الكلية لسهولة استخدام الموقع والتنقل بين صفحاته تُسمى:', opts: ['UX (User Experience)', 'CPU', 'Botnet', 'Driver'], ans: 0, exp: 'UX تختص بتجربة المستخدم.' },
      { q: 'أمر CSS الذي يضبط المسافة الداخلية بين محتوى العنصر وحدوده:', opts: ['padding', 'href', 'alt', 'src'], ans: 0, exp: 'padding هو الحشو الداخلي.' },
      { q: 'لربط ملف تنسيق خارجي باسم mystyle.css داخل HTML نكتب:', opts: ['<link rel="stylesheet" href="mystyle.css">', '<css>mystyle.css</css>', '<body href="mystyle.css">', '<p src="mystyle.css">'], ans: 0, exp: 'وسم <link> القياسي.' },
    ]),
  },
  {
    id: 'p2-ict-t2-c4',
    order: 4,
    term: 2,
    title: 'الفصل الرابع (الترم الثاني): تطوير صفحات الطالب والنشر الرقمي الآمن',
    description: 'ربط صفحة الطالب student.htm مع school.htm بملف CSS موحد ونشر المشروع عبر الاستضافة ورمز QR.',
    lessons: [
      {
        id: 'p2-ict-t2-c4-l1',
        order: 1,
        title: 'الدرس الأول (ترم 2): ربط صفحات الموقع (student.htm + school.htm)',
        durationMinutes: 18,
        summary:
          'يتعلم الطالب إنشاء صفحة ثانية للبيانات الطلابية وربطها بالصفحة الرئيسية عبر الروابط التشعبية <a> ومشاركة نفس ملف style.css لضمان التناسق التام (Consistency).',
        keyPoints: [
          'استخدام وسم الرابط <a href="school.htm"> للعودة إلى صفحة المدرسة.',
          'إعادة استخدام style.css يوحد الألوان والخطوط عبر كل صفحات الموقع.',
        ],
        mcqQuestions: [
          {
            id: 'p2-c4-l1-q1',
            question: 'الوسم المسؤول عن إنشاء رابط تشعبي ينقل الزائر من صفحة student.htm إلى school.htm هو:',
            options: ['<a href="school.htm">', '<link href="school.htm">', '<section>', '<footer>'],
            correctIndex: 0,
            explanation: 'وسم المرساة <a> ينشئ روابط التنقل بين الصفحات.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p2-c4-l1-tf1',
            statement: 'ربط عدة صفحات HTML بملف CSS خارجي واحد يحقق مبدأ التناسق (Consistency) في UX.',
            isTrue: true,
            explanation: 'صحيح — توحيد الألوان والتخطيط عبر ملف واحد.',
          },
        ],
        essayQuestions: [
          {
            id: 'p2-c4-l1-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: مبدأ في تجربة المستخدم يضمن توحيد شكل الأزرار والألوان وتخطيط القوائم في كل صفحات الموقع.',
            modelAnswer: 'التناسق (Consistency)',
            keywords: ['التناسق', 'consistency'],
          },
        ],
        codeChallenges: [
          {
            id: 'p2-c4-l1-code1',
            language: 'html_css',
            title: 'عملي الترم 2 (HTML+CSS): صفحة الطالب والرابط التشعبي',
            prompt: 'أضف وسم رابط تشعبي <a href="school.htm">العودة لصفحة المدرسة</a> داخل صفحة الطالب.',
            subjectContext: 'الصف الثاني الإعدادي — ربط صفحات الموقع',
            starterCode: `<style>\n  body { background: #f8fafc; font-family: sans-serif; }\n  a { color: darkblue; font-weight: bold; }\n</style>\n<section>\n  <h2>بطاقة بيانات الطالب</h2>\n  <p>الاسم: محمد أحمد | الصف الثاني الإعدادي</p>\n  <!-- أضف الرابط التشعبي لصفحة school.htm هنا -->\n</section>`,
            hint: 'اكتب <a href="school.htm">العودة لصفحة المدرسة</a>.',
            requiredCodeSnippets: ['<a', 'href="school.htm"'],
            expectedOutputContains: ['بطاقة بيانات الطالب'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p2-c4', 'الفصل 4 (ثانية إعدادي)', [
      { q: 'وسم إنشاء رابط تشعبي بين صفحتي ويب:', opts: ['<a>', '<div>', '<h2>', '<style>'], ans: 0, exp: 'الوسم <a>.' },
      { q: 'توحيد التصميم عبر أكثر من صفحة يُحقق مبدأ:', opts: ['التناسق Consistency', 'التشتت', 'Overfitting', 'DDoS'], ans: 0, exp: 'Consistency.' },
      { q: 'أي خاصية تغير لون النص في CSS؟', opts: ['color', 'background-color', 'padding', 'width'], ans: 0, exp: 'color للون النص.' },
      { q: 'أي امتداد يُحفظ به ملف التنسيق الخارجي؟', opts: ['.css', '.txt', '.exe', '.inf'], ans: 0, exp: '.css.' },
      { q: 'الوسم الدلالي لتذييل الصفحة:', opts: ['<footer>', '<header>', '<nav>', '<aside>'], ans: 0, exp: '<footer> للتذييل.' },
    ]),
  },
];

/* ============================================================================
 * 3) الصف الثالث الإعدادي — الذكاء الاصطناعي و Python والأمن السيبراني (مذكرة أ. محمد الشريف)
 * ============================================================================ */
const prep3IctChapters: CurriculumChapter[] = [
  {
    id: 'p3-ict-t1-c1',
    order: 1,
    term: 1,
    title: 'الوحدة الأولى (الفصل 1): التفكير الحاسوبي وخوارزميات الذكاء الاصطناعي',
    description: 'الدرس 1: التفكير الحاسوبي وحل المشكلات بـ Python | الدرس 2: خرائط التدفق والخوارزميات الخمس وتعلم الآلة.',
    lessons: [
      {
        id: 'p3-ict-t1-c1-l1',
        order: 1,
        title: 'الدرس الأول: التفكير الحاسوبي وحل المشكلات في Python',
        durationMinutes: 20,
        summary:
          'التفكير الحاسوبي هو منهجية منطقية لصياغة وحل المشكلات عبر 4 أركان: التفكيك Decomposition، تمييز الأنماط Pattern Recognition، التجريد Abstraction، وتصميم الخوارزمية Algorithm، مع تطبيقات Python لحساب الزوجي/الفردي والمتوسط والمجموع التراكمي.',
        keyPoints: [
          'أركان التفكير الحاسوبي الأربعة: التفكيك (Decomposition)، التعرف على الأنماط (Pattern Recognition)، التجريد (Abstraction)، والخوارزميات (Algorithm).',
          'خطوات حل المشكلة: تحديد المشكلة -> تحليل المدخلات والمخرجات -> كتابة الخطوات -> اختبار الحل -> توثيق الحل.',
          'مثال من المنهج: مجموع الأعداد من 1 إلى 5 باستخدام حلقة for i in range(1, 6): sum += i ليطبع 15.',
          'اختبار نجاح الطالب: إذا كان المجموع >= 50 يطبع "ناجح" وإلا "راسب".',
        ],
        mcqQuestions: [
          {
            id: 'p3-c1-l1-q1',
            question: 'الركن الذي يهدف إلى التركيز على التفاصيل المهمة فقط وتجاهل التفاصيل غير المؤثرة في المشكلة يُسمى:',
            options: [
              'التجريد (Abstraction)',
              'التكرار (Loop)',
              'معالجة الأخطاء',
              'النشر الرقمي',
            ],
            correctIndex: 0,
            explanation: 'التجريد Abstraction يعزل التفاصيل الجوهرية للحل عن العناصر غير الضرورية.',
          },
          {
            id: 'p3-c1-l1-q2',
            question: 'ما ناتج تنفيذ كود بايثون التالي؟\ntotal = 0\nfor i in range(1, 6):\n    total += i\nprint(total)',
            options: ['10', '15', '21', '5'],
            correctIndex: 1,
            explanation: 'range(1, 6) يولد الأعداد 1، 2، 3، 4، 5 ومجموعها 15.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c1-l1-tf1',
            statement: 'تُعني عملية التفكيك (Decomposition) تقسيم المشكلة الكبيرة المعقدة إلى أجزاء صغيرة يسهل حلها.',
            isTrue: true,
            explanation: 'صحيح — التفكيك يبسط المشكلات الكبرى.',
          },
          {
            id: 'p3-c1-l1-tf2',
            statement: 'الدالة range(1, 6) في لغة Python تتوقف عند العدد 6 شاملاً الرقم 6 نفسه.',
            isTrue: false,
            explanation: 'خطأ — range(1, 6) تتوقف قبل 6 فتنتج 1، 2، 3، 4، 5 فقط.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c1-l1-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: تقسيم المشكلة المعقدة إلى أجزاء صغيرة يسهل التعامل معها وحلها بشكل منفصل.',
            modelAnswer: 'التفكيك (Decomposition)',
            keywords: ['التفكيك', 'decomposition'],
          },
          {
            id: 'p3-c1-l1-es2',
            questionType: 'essay',
            question: 'اذكر الأركان الأربعة للتفكير الحاسوبي.',
            modelAnswer: '1) التفكيك (Decomposition)، 2) تمييز الأنماط (Pattern Recognition)، 3) التجريد (Abstraction)، 4) الخوارزمية (Algorithm).',
            keywords: ['التفكيك', 'الأنماط', 'التجريد', 'الخوارزمي'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c1-l1-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 1): حساب مجموع الأعداد من 1 إلى 5 بحلقة for',
            prompt:
              'اكتب حلقة for i in range(1, 6): في Python لجمع الأعداد من 1 إلى 5 داخل المتغير sum ثم طباعة الناتج 15.',
            subjectContext: 'الصف الثالث الإعدادي — برمجة Python للتفكير الحاسوبي',
            starterCode: `sum = 0\nfor i in range(1, 4):\n    sum += i\nprint(sum)`,
            hint: 'عدّل range(1, 4) إلى range(1, 6) ليصبح المجموع 15.',
            requiredCodeSnippets: ['for', 'range(1, 6)'],
            expectedOutputContains: ['15'],
          },
        ],
      },
      {
        id: 'p3-ict-t1-c1-l2',
        order: 2,
        title: 'الدرس الثاني: خوارزميات الذكاء الاصطناعي وخرائط التدفق',
        durationMinutes: 20,
        summary:
          'تُترجم الخوارزميات رسومياً عبر خرائط التدفق (Flowcharts)، وتنقسم إلى 5 أنواع: تسلسلية، شرطية، تكرارية، البحث، والترتيب؛ كما يعتمد الذكاء الاصطناعي على تعلم الآلة (Machine Learning) والتعلم العميق (Deep Learning) بالشبكات العصبية.',
        keyPoints: [
          'أشكال خرائط التدفق الخمسة: البيضاوي (بداية/نهاية)، المستطيل (عملية/حساب)، متوازي الأضلاع (إدخال/إخراج)، المعين (اتخاذ قرار/شرط)، والأسهم (الاتجاه).',
          'الأنواع الخمسة للخوارزميات: التسلسلية، الشرطية (if/else)، التكرارية (for/while)، البحث (Search)، والترتيب (Sort).',
          'مثال بايثون للترتيب من الكتاب: numbers.sort() ثم print(numbers).',
          'تعلّم الآلة ML يتعلم من البيانات المصنفة (مثل كشف الرسائل المزعجة Spam)، والتعلم العميق DL يحاكي الشبكات العصبية للدماغ.',
        ],
        mcqQuestions: [
          {
            id: 'p3-c1-l2-q1',
            question: 'أي رمز في خرائط التدفق (Flowcharts) يُستخدم لاتخاذ القرار أو كتابة الشرط (مثل الدرجة >= 50)؟',
            options: ['المستطيل', 'المعين (Decision)', 'البيضاوي', 'متوازي الأضلاع'],
            correctIndex: 1,
            explanation: 'الشكل المعين يمثل نقطة اتخاذ القرار وتخرج منه أسهم نعم/لا.',
          },
          {
            id: 'p3-c1-l2-q2',
            question: 'الشكل المستخدم لتمثيل عمليتي الإدخال (Input) والإخراج (Output) في خريطة التدفق هو:',
            options: ['متوازي الأضلاع', 'البيضاوي', 'الدائرة الصغيرة', 'المعين'],
            correctIndex: 0,
            explanation: 'متوازي الأضلاع يمثل إدخال البيانات أو طباعة المخرجات.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c1-l2-tf1',
            statement: 'تُرتب الدالة numbers.sort() عناصر القائمة الرقمية في Python تصاعدياً من الأصغر إلى الأكبر.',
            isTrue: true,
            explanation: 'صحيح — الدالة sort() ترتب القائمة في موضعها.',
          },
          {
            id: 'p3-c1-l2-tf2',
            statement: 'يُستخدم الشكل البيضاوي داخل خريطة التدفق لإجراء العمليات الحسابية مثل sum = a + b.',
            isTrue: false,
            explanation: 'خطأ — العمليات الحسابية تُكتب في المستطيل، بينما البيضاوي للبداية والنهاية فقط.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c1-l2-es1',
            questionType: 'essay',
            question: 'اذكر وظيفة كل من الأشكال الآتية في خرائط التدفق: البيضاوي، المستطيل، متوازي الأضلاع، المعين.',
            modelAnswer: 'البيضاوي: البداية والنهاية، المستطيل: المعالجة والعمليات الحسابية، متوازي الأضلاع: الإدخال والإخراج، المعين: اتخاذ القرار والشرط.',
            keywords: ['البداية', 'العمليات', 'الإدخال', 'القرار'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c1-l2-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 2): خوارزمية ترتيب الدرجات numbers.sort() والبحث عن القيمة',
            prompt:
              'استخدم دالة .sort() لترتيب القائمة numbers = [40, 10, 30, 20] تصاعدياً ثم اطبعها لتظهر [10, 20, 30, 40].',
            subjectContext: 'الصف الثالث الإعدادي — خوارزميات الترتيب في Python',
            starterCode: `numbers = [40, 10, 30, 20]\n# استدعِ دالة الترتيب على numbers\nprint(numbers)`,
            hint: 'أضف السطر numbers.sort() قبل print(numbers).',
            requiredCodeSnippets: ['.sort()'],
            expectedOutputContains: ['[10, 20, 30, 40]'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p3-c1', 'الفصل 1 (ثالثة إعدادي)', [
      { q: 'الرمز المستخدم لبدء وإنهاء خريطة التدفق هو:', opts: ['الشكل البيضاوي', 'المستطيل', 'المعين', 'المثلث'], ans: 0, exp: 'البيضاوي Start / End.' },
      { q: 'عند البحث عن نمط متكرر بين المشكلات نطبق ركن:', opts: ['تمييز الأنماط Pattern Recognition', 'التجريد', 'حذف الملفات', 'try/except'], ans: 0, exp: 'Pattern Recognition يكتشف الأنماط المشتركة.' },
      { q: 'يعتمد التعلم العميق (Deep Learning) على محاكاة:', opts: ['الشبكات العصبية في الدماغ', 'أشكال المعين فقط', 'ملفات CSS', 'منفذ الطابعة'], ans: 0, exp: 'Deep Learning يعتمد على Neural Networks.' },
      { q: 'أي كود بايثون ينشئ حلقة تتكرر 5 مرات؟', opts: ['for i in range(5):', 'if i == 5:', 'def i():', 'numbers.sort()'], ans: 0, exp: 'range(5) ينفذ من 0 إلى 4 أي 5 مرات.' },
      { q: 'فرز الأسماء أو الدرجات من الأصغر للأكبر يندرج تحت خوارزمية:', opts: ['الترتيب (Sort)', 'التفكيك', 'كتم الصوت', 'الإخراج'], ans: 0, exp: 'خوارزمية Sort للترتيب.' },
    ]),
  },
  {
    id: 'p3-ict-t1-c2',
    order: 2,
    term: 1,
    title: 'الوحدة الأولى (الفصل 2): السلاسل النصية والقوائم والدوال ومعالجة الأخطاء في Python',
    description: 'الدرس 3: Strings & Lists | الدرس 4: الدوال def و return | الدرس 5: try/except مع ValueError و ZeroDivisionError.',
    lessons: [
      {
        id: 'p3-ict-t1-c2-l1',
        order: 1,
        title: 'الدرس الثالث: السلاسل النصية Strings والقوائم Lists في Python',
        durationMinutes: 22,
        summary:
          'النصوص (Strings) سلاسل ثابتة Immutable تدعم الفهرسة الإيجابية والسلبية [-1] ودوال len() و .upper() ومعامل البحث in؛ بينما القوائم (Lists) قابلة للتعديل Mutable وتدعم الإضافة .append() والحذف .remove() والتحويل list(text).',
        keyPoints: [
          'الوصول لأول حرف في النص text[0] وآخر حرف باستخدام الفهرس السالب text[-1].',
          'التحقق من وجود حرف أو كلمة داخل النص أو القائمة بمعامل in (مثل "@" in email).',
          'تحويل النص لحروف كبيرة بـ .upper() وفحص الأرقام بـ .isdigit() والأحرف الكبيرة بـ .isupper().',
          'القائمة List توضع بين قوسين مربعين [] وتُعدل بـ .append("Sara") و .remove("Ali").',
        ],
        mcqQuestions: [
          {
            id: 'p3-c2-l1-q1',
            question: 'ما ناتج تنفيذ الكود: word = "Python"; print(word[-1]) ؟',
            options: ['P', 'y', 'n', '6'],
            correctIndex: 2,
            explanation: 'الفهرس السالب [-1] يشير إلى آخر حرف في السلسلة وهو n.',
          },
          {
            id: 'p3-c2-l1-q2',
            question: 'لإضافة العنصر "Sara" إلى نهاية قائمة الأسماء names في لغة Python نستخدم:',
            options: [
              'names.append("Sara")',
              'names.upper("Sara")',
              'names.remove("Sara")',
              'len("Sara")',
            ],
            correctIndex: 0,
            explanation: 'دالة .append() تضيف العنصر الجديد إلى نهاية القائمة.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c2-l1-tf1',
            statement: 'القوائم (Lists) في لغة Python قابلة للتعديل (Mutable) حيث يمكن إضافة أو حذف أو تغيير عناصرها.',
            isTrue: true,
            explanation: 'صحيح — القوائم مرنة وقابلة للتعديل، بعكس النصوص الثابتة.',
          },
          {
            id: 'p3-c2-l1-tf2',
            statement: 'يرجع التعبير "@" in "ali@gmail.com" القيمة المنطقية False.',
            isTrue: false,
            explanation: 'خطأ — الرمز @ موجود داخل النص لذلك النتيجة True.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c2-l1-es1',
            questionType: 'complete',
            question: 'أكمل: الدالة التي تعيد طول النص أو عدد عناصر القائمة هي ............... بينما الدالة التي تحول النص لحروف كبيرة هي ...............',
            modelAnswer: 'len() ، و .upper()',
            keywords: ['len', 'upper'],
          },
          {
            id: 'p3-c2-l1-es2',
            questionType: 'essay',
            question: 'ما الفرق بين السلاسل النصية (Strings) والقوائم (Lists) من حيث قابلية التعديل؟',
            modelAnswer: 'السلاسل النصية غير قابلة للتعديل المباشر (Immutable)، بينما القوائم قابلة للتعديل (Mutable) عبر append و remove وتعديل الفهرس.',
            keywords: ['غير قابل', 'قابل للتعديل', 'mutable'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c2-l1-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 3): القوائم .append() والنصوص .upper() و الفهرس السالب',
            prompt:
              'أضف "Sara" إلى قائمة names باستخدام append، ثم اطبع القائمة، واطبع آخر حرف من word = "Python" باستخدام word[-1].upper().',
            subjectContext: 'الصف الثالث الإعدادي — معالجة القوائم والسلاسل النصية في Python',
            starterCode: `names = ["Ali", "Omar"]\n# أضف "Sara" هنا\nword = "Python"\nprint(names)\nprint(word[-1].upper())`,
            hint: 'اكتب names.append("Sara") في السطر الثاني.',
            requiredCodeSnippets: ['.append(', '[-1]'],
            expectedOutputContains: ['Sara', 'N'],
          },
        ],
      },
      {
        id: 'p3-ict-t1-c2-l2',
        order: 2,
        title: 'الدرس الرابع: الدوال ذات المعاملات في Python (Functions)',
        durationMinutes: 20,
        summary:
          'الدالة (Function) كتلة كود منظمة تُعرف بكلمة def وتستقبل معاملات (Parameters) عند التعريف وتمرر لها قيم (Arguments) عند الاستدعاء، وتعيد الناتج القابل لإعادة الاستخدام عبر return.',
        keyPoints: [
          'صيغة التعريف: def function_name(parameter): مع ترك مسافة بادئة لجسم الدالة.',
          'الفرق بين print و return: print للطباعة على الشاشة فقط، بينما return ترجع القيمة لاستخدامها في حسابات تالية.',
          'المثال المنهجي: def circle_area(radius): pi = 3.14; area = pi * radius * radius; return area (عند radius=5 الناتج 78.5).',
          'المتغيرات المعرفة داخل الدالة تُسمى متغيرات محلية (Local Variables) يقتصر نطاقها داخل الدالة.',
        ],
        mcqQuestions: [
          {
            id: 'p3-c2-l2-q1',
            question: 'أي كلمة مفتاحية في Python تُستخدم لتعريف دالة جديدة؟',
            options: ['function', 'def', 'define', 'return'],
            correctIndex: 1,
            explanation: 'كلمة def (اختصار define) تُستخدم لتعريف الدوال في بايثون.',
          },
          {
            id: 'p3-c2-l2-q2',
            question: 'ما مخرج استدعاء الدالة circle_area(5) إذا كانت pi = 3.14 و area = pi * radius * radius؟',
            options: ['15.7', '78.5', '31.4', '25'],
            correctIndex: 1,
            explanation: '3.14 × 5 × 5 = 3.14 × 25 = 78.5.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c2-l2-tf1',
            statement: 'استخدام return داخل الدالة يتيح تخزين ناتج الدالة في متغير آخر لإجراء عمليات إضافية عليه.',
            isTrue: true,
            explanation: 'صحيح — return تعيد القيمة البرمجية، على عكس print التي تعرضها كنص فقط.',
          },
          {
            id: 'p3-c2-l2-tf2',
            statement: 'المتغير المحلي (Local Variable) المُعرّف داخل الدالة يمكن قراءته بحرية من أي سطر خارج الدالة.',
            isTrue: false,
            explanation: 'خطأ — المتغير المحلي يعمل داخل نطاق الدالة فقط.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c2-l2-es1',
            questionType: 'essay',
            question: 'قارن بين print و return داخل الدوال في لغة بايثون.',
            modelAnswer: 'print تطبع الناتج على الشاشة للمستخدم فقط ولا تعيد قيمة، بينما return تنهي الدالة وترجع القيمة للبرنامج لإعادة استخدامها وتخزينها.',
            keywords: ['تطبع', 'ترجع', 'الشاشة', 'إعادة استخدام'],
          },
          {
            id: 'p3-c2-l2-es2',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: القيم الفعلية التي يتم تمريرها عند استدعاء الدالة لكي تحل محل المعاملات Parameters.',
            modelAnswer: 'الوسائط أو المعطيات (Arguments)',
            keywords: ['arguments', 'الوسائط'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c2-l2-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 4): دالة حساب مساحة الدائرة circle_area(radius)',
            prompt:
              'أكمل الدالة circle_area(radius) بالمعادلة area = pi * radius * radius وأعد area بـ return، ثم اطبع ناتج circle_area(5) ليظهر 78.5.',
            subjectContext: 'الصف الثالث الإعدادي — الدوال ذات المعاملات في Python',
            starterCode: `def circle_area(radius):\n    pi = 3.14\n    area = 0\n    return area\n\nresult = circle_area(5)\nprint(result)`,
            hint: 'اكتب area = pi * radius * radius داخل الدالة.',
            requiredCodeSnippets: ['def circle_area', 'return'],
            expectedOutputContains: ['78.5'],
          },
        ],
      },
      {
        id: 'p3-ict-t1-c2-l3',
        order: 3,
        title: 'الدرس الخامس: معالجة أخطاء مدخلات المستخدم في Python (try / except)',
        durationMinutes: 19,
        summary:
          'يتوقف البرنامج إذا أدخل المستخدم نصاً بدلاً من رقم (ValueError) أو حاول القسمة على صفر (ZeroDivisionError)؛ ولضمان استمرار البرنامج بأمان نستخدم بنية try / except.',
        keyPoints: [
          'كتلة try يوضع بداخلها الكود الذي قد يسبب خطأ وقت التشغيل (Runtime Error).',
          'ValueError يحدث عند محاولة تحويل نص غير رقمي مثل int("abc").',
          'ZeroDivisionError يحدث عند القسمة على الصفر مثل 10 / 0.',
          'الجمع بين حلقة while True و try / except مع break يضمن تكرار الطلب حتى يدخل المستخدم قيمة صحيحة.',
        ],
        mcqQuestions: [
          {
            id: 'p3-c2-l3-q1',
            question: 'ما نوع الاستثناء الذي تطلقه لغة Python عند تنفيذ int("Hello") ؟',
            options: [
              'ZeroDivisionError',
              'ValueError',
              'SyntaxClean',
              'AppendError',
            ],
            correctIndex: 1,
            explanation: 'تحويل نص غير صالح لعدد صحيح يسبب خطأ قيمة ValueError.',
          },
          {
            id: 'p3-c2-l3-q2',
            question: 'لمنع انهيار البرنامج عند القسمة على صفر نضع معادلة القسمة داخل try ونلتقط الخطأ بـ:',
            options: [
              'except ZeroDivisionError:',
              'return Zero:',
              'for Zero in range:',
              'def ValueError():',
            ],
            correctIndex: 0,
            explanation: 'except ZeroDivisionError تعالج محاولة القسمة على صفر بلطف دون توقف البرنامج.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c2-l3-tf1',
            statement: 'تساعد كتلة try / except على حماية البرنامج من التوقف المفاجئ وإظهار رسالة توضيحية للمستخدم.',
            isTrue: true,
            explanation: 'صحيح — هذه هي وظيفة Exception Handling.',
          },
          {
            id: 'p3-c2-l3-tf2',
            statement: 'حدوث قسمة على صفر (مثل 50 / 0) يُسبب خطأ ValueError في بايثون.',
            isTrue: false,
            explanation: 'خطأ — القسمة على صفر تسبب ZeroDivisionError.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c2-l3-es1',
            questionType: 'essay',
            question: 'متى يحدث كل من خطأ ValueError وخطأ ZeroDivisionError في لغة Python؟',
            modelAnswer: 'ValueError يحدث عند تمرير قيمة بنوع غير مناسب للتحويل مثل int("abc")، و ZeroDivisionError يحدث عند محاولة قسمة أي رقم على الصفر.',
            keywords: ['تحويل', 'نص', 'صفر'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c2-l3-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 5): التقاط ZeroDivisionError و ValueError بـ try/except',
            prompt:
              'أكمل الكود التالي لالتقاط الخطأ ZeroDivisionError عند قسمة 100 على 0 وطباعة رسالة "لا يمكن القسمة على صفر".',
            subjectContext: 'الصف الثالث الإعدادي — معالجة الأخطاء في Python',
            starterCode: `try:\n    total = 100 / 0\n    print(total)\nexcept ValueError:\n    print("خطأ في نوع البيانات")\n# أضف except ZeroDivisionError هنا`,
            hint: 'أضف except ZeroDivisionError: وتحتها بأربع مسافات print("لا يمكن القسمة على صفر").',
            requiredCodeSnippets: ['try:', 'except ZeroDivisionError:'],
            expectedOutputContains: ['لا يمكن القسمة على صفر'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p3-c2', 'الفصل 2 بايثون (ثالثة إعدادي)', [
      { q: 'ما نوع الخطأ عند تنفيذ a = 12 / 0 في Python؟', opts: ['ValueError', 'ZeroDivisionError', 'ListError', 'UpperError'], ans: 1, exp: 'القسمة على صفر تسبب ZeroDivisionError.' },
      { q: 'لحذف العنصر "Ali" من القائمة names نستخدم:', opts: ['names.remove("Ali")', 'names.append("Ali")', 'names.upper()', 'names[-1]'], ans: 0, exp: '.remove() تحذف العنصر المحدد.' },
      { q: 'الكلمة التي تعيد ناتجاً من الدالة def للبرنامج:', opts: ['return', 'break', 'try', 'for'], ans: 0, exp: 'return.' },
      { q: 'ما ناتج len(["AI", "ML", "DL"]) ؟', opts: ['2', '3', '4', '0'], ans: 1, exp: 'عدد العناصر 3.' },
      { q: 'لفحص احتواء النص على أرقام فقط نستخدم الدالة:', opts: ['.isdigit()', '.isupper()', '.sort()', '.append()'], ans: 0, exp: '.isdigit() تتحقق من الأرقام.' },
    ]),
  },
  {
    id: 'p3-ict-t1-c3',
    order: 3,
    term: 1,
    title: 'الوحدة الثانية (الفصل 3): التنبؤ بالذكاء الاصطناعي والملكية الفكرية والتزييف العميق',
    description: 'دروس (6–9): معادلة التنبؤ y = w*x + b في Python، حقوق الملكية الفكرية PII و TOS، الألعاب الخطرة، والـ Deepfake.',
    lessons: [
      {
        id: 'p3-ict-t1-c3-l1',
        order: 1,
        title: 'الدرس السادس: التنبؤ باستخدام نموذج الذكاء الاصطناعي (y = w*x + b)',
        durationMinutes: 20,
        summary:
          'يتنبأ نموذج التعلم الآلي الخطي بالنتائج وفق المعادلة y = w * x + b حيث x المدخل (مثل ساعات المذاكرة)، w الوزن، و b الانحياز، وبذلك يختلف عن البرمجة التقليدية التي تضع قواعد ثابتة يدوياً.',
        keyPoints: [
          'الفرق بين البرمجة التقليدية (Rule-Based: المبرمج يكتب القواعد والبيانات لتخرج النتيجة) وتعلّم الآلة (نعطي الجهاز البيانات والنتائج ليستنتج القواعد).',
          'معادلة الانحدار الخطي: y = w * x + b (x المدخل، w الوزن Weight، b الانحياز Bias).',
          'التطبيق البرمجي من الكتاب: دالة predict_grade(hours) بحيث w=5 و b=10 عند hours=3 تتنبأ بـ 25 درجة.',
        ],
        mcqQuestions: [
          {
            id: 'p3-c3-l1-q1',
            question: 'في معادلة نموذج التنبؤ الخطي y = w * x + b، يرمز الحرف b إلى:',
            options: [
              'الوزن (Weight)',
              'الانحياز أو القيمة الأساسية (Bias)',
              'الفهرس السالب',
              'التزييف العميق',
            ],
            correctIndex: 1,
            explanation: 'b هو معامل الانحياز Bias، و w هو الوزن Weight، و x هو المدخل.',
          },
          {
            id: 'p3-c3-l1-q2',
            question: 'إذا كان النموذج يستخدم w = 5 و b = 10 في predict_grade(hours)، ما الدرجة المتوقعة لطالب ذاكر 3 ساعات؟',
            options: ['15', '18', '25', '50'],
            correctIndex: 2,
            explanation: 'y = 5 × 3 + 10 = 15 + 10 = 25.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c3-l1-tf1',
            statement: 'في تعلم الآلة (Machine Learning) يستنتج النموذج القواعد والأنماط تلقائياً من أمثلة التدريب والنتائج التاريخية.',
            isTrue: true,
            explanation: 'صحيح — على عكس البرمجة التقليدية الثابتة.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c3-l1-es1',
            questionType: 'essay',
            question: 'قارن بين البرمجة التقليدية (Rule-Based) وتعلّم الآلة (Machine Learning) من حيث المدخلات والمخرجات.',
            modelAnswer: 'البرمجة التقليدية تأخذ (البيانات + القواعد المكتوبة يدوياً) لإخراج النتائج، بينما تعلّم الآلة يأخذ (البيانات + النتائج) ليستنتج القواعد والأنماط بنفسه.',
            keywords: ['القواعد', 'النتائج', 'يستنتج'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c3-l1-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 6): دالة نموذج التنبؤ الخطي predict_grade',
            prompt:
              'أكمل دالة التنبؤ الخطي predict_grade(hours) بمعادلة y = w * hours + b حيث w = 5 و b = 10 ثم اطبع ناتج predict_grade(3) ليظهر 25.',
            subjectContext: 'الصف الثالث الإعدادي — نموذج الذكاء الاصطناعي الخطي بـ Python',
            starterCode: `def predict_grade(hours):\n    w = 5\n    b = 10\n    y = 0\n    return y\n\nprint(predict_grade(3))`,
            hint: 'اكتب y = w * hours + b داخل الدالة.',
            requiredCodeSnippets: ['w * hours + b', 'return y'],
            expectedOutputContains: ['25'],
          },
        ],
      },
      {
        id: 'p3-ict-t1-c3-l2',
        order: 2,
        title: 'الدرس السابع: الذكاء الاصطناعي وحقوق الملكية الفكرية',
        durationMinutes: 15,
        summary:
          'يتطلب الاستخدام الأخلاقي لأدوات الذكاء الاصطناعي حماية البيانات الشخصية (PII)، ومراجعة شروط الاستخدام (TOS)، والالتزام بقاعدة المصادر الثلاثة وتجنب الانتحال الأدبي (Plagiarism).',
        keyPoints: [
          'البيانات الشخصية الحساسة PII (اسمك الكامل، هاتفك، عنوانك، الرقم القومي) لا يجب إدخالها في الدردشة مع AI.',
          'شروط الاستخدام (TOS): اشتراط السن المناسب (13+ غالباً)، توضيح ملكية المخرجات، وحق الحذف Clear Data.',
          'قاعدة المصادر الثلاثة: تحقق من صحة أي معلومة يولدها الذكاء الاصطناعي من 3 مصادر موثوقة مختلفة.',
          'الشفافية: الإشارة إلى استخدام أدوات AI وعدم نسبتها لنفسك لتفادي الانتحال (Plagiarism).',
        ],
        mcqQuestions: [
          {
            id: 'p3-c3-l2-q1',
            question: 'ماذا تعني "قاعدة المصادر الثلاثة" عند استخدام مخرجات الذكاء الاصطناعي في الأبحاث؟',
            options: [
              'الاعتماد على إجابة AI دون مراجعة',
              'التحقق من صحة المعلومة عبر ثلاثة مصادر موثوقة مختلفة',
              'نسخ نفس الجملة 3 مرات',
              'حفظ الملف بـ 3 أسماء',
            ],
            correctIndex: 1,
            explanation: 'لتفادي أخطاء وهلوسات الذكاء الاصطناعي نتحقق من 3 مصادر موثوقة.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c3-l2-tf1',
            statement: 'يمكن مشاركة الرقم القومي وكلمات المرور مع روبوتات الدردشة بالذكاء الاصطناعي دون أي خطورة.',
            isTrue: false,
            explanation: 'خطأ — البيانات الشخصية الحساسة PII يجب حمايتها تماماً.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c3-l2-es1',
            questionType: 'scientific_term',
            question: 'اكتب المصطلح العلمي: نسخ أعمال أو إجابات الآخرين أو نصوص الذكاء الاصطناعي ونسبتها لنفسك دون إشارة للمصدر.',
            modelAnswer: 'الانتحال العلمي أو الأدبي (Plagiarism)',
            keywords: ['الانتحال', 'plagiarism'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c3-l2-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 7): فاحص أمان النص قبل الإرسال لأداة AI (منع تسريب PII)',
            prompt:
              'تحقق مما إذا كان النص المدخل يحتوي على كلمة "رقم قومي" أو "كلمة سر" باستخدام معامل in؛ يجب أن يطبع "تحذير: يحتوي بيانات PII حساسة".',
            subjectContext: 'الصف الثالث الإعدادي — حماية الخصوصية و PII برمجياً',
            starterCode: `prompt_text = "هذه بياناتي وفيها رقم قومي خاص"\nif "اسم" in prompt_text:\n    print("آمن")\nelse:\n    print("عدّل الشرط لفحص كلمة رقم قومي")`,
            hint: 'غيّر الشرط إلى if "رقم قومي" in prompt_text: لطباعة "تحذير: يحتوي بيانات PII حساسة".',
            requiredCodeSnippets: ['in prompt_text'],
            expectedOutputContains: ['تحذير: يحتوي بيانات PII حساسة'],
          },
        ],
      },
      {
        id: 'p3-ict-t1-c3-l3',
        order: 3,
        title: 'الدرس الثامن والتاسع: الألعاب الخطرة والتزييف العميق (Deepfake GANs)',
        durationMinutes: 20,
        summary:
          'تكشف الألعاب الإلكترونية أحياناً عن أساليب خداع مثل Dark Patterns و Pay to Win و FOMO، بينما يعتمد التزييف العميق (Deepfake) على شبكات GANs (المولّد Generator والمميّز Discriminator) ويمكن رصده بعلامات وأدوات كشف متخصصة.',
        keyPoints: [
          'مفاهيم الألعاب الخطرة: الأنماط المظلمة (Dark Patterns)، ادفع لتفوز (Pay to Win)، صناديق الغنائم (Loot Boxes)، والخوف من فوات الفرصة (FOMO).',
          'الوقاية: الحد الأقصى الصحي للعب الأسبوعي، واستخدام الرقابة الأبوية مثل Google Family Link و Apple Screen Time.',
          'التزييف العميق (Deepfake): ينتج صور وفيديو وأصواتاً مزيفة عبر شبكات GANs (المولد Generator يحاكي الحقيقة، والمميز Discriminator يكشف التزييف).',
          'أدوات كشف التزييف: Deepware Scanner، Sensity AI، Hive Moderation، InVID، و Microsoft Video Authenticator.',
        ],
        mcqQuestions: [
          {
            id: 'p3-c3-l3-q1',
            question: 'يتكون نموذج الشبكات التوليدية التنافسية (GANs) المستخدم في Deepfake من عنصرين أساسيين هما:',
            options: [
              'المولّد (Generator) والمميّز (Discriminator)',
              'الطابعة والشاشة',
              'Word و Excel',
              'Header و Footer',
            ],
            correctIndex: 0,
            explanation: 'تعمل شبكة Generator على إنشاء التزييف وتعمل Discriminator على اكتشافه.',
          },
          {
            id: 'p3-c3-l3-q2',
            question: 'أداة ضغط نفسي في الألعاب تجعل اللاعب يشتري أو يدخل يومياً خوفاً من ضياع مكافأة مؤقتة تُسمى:',
            options: ['FOMO (الخوف من فوات الفرصة)', 'GANs', 'InVID', 'AutoNumber'],
            correctIndex: 0,
            explanation: 'FOMO: Fear Of Missing Out تستغل التوقيت المحدود لدفع اللاعب للشراء.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c3-l3-tf1',
            statement: 'من علامات كشف فيديو Deepfake عدم تزامن حركة الشفاه مع الصوت أو رمش العين بطريقة غير طبيعية.',
            isTrue: true,
            explanation: 'صحيح — هذه من أهم مؤشرات الكشف البصري للتزييف العميق.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c3-l3-es1',
            questionType: 'essay',
            question: 'اذكر ثلاثاً من الأدوات المتخصصة في كشف التزييف العميق (Deepfake).',
            modelAnswer: 'Deepware Scanner، Sensity AI، Hive Moderation، إضافة InVID، و Microsoft Video Authenticator.',
            keywords: ['deepware', 'sensity', 'hive', 'invid'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c3-l3-code1',
            language: 'python',
            title: 'عملي بايثون (الدرس 8-9): مراقب الرقابة الأبوية لساعات اللعب الأسبوعية',
            prompt:
              'اكتب دالة بالبايثون تفحص ساعات اللعب الأسبوعية weekly_hours = 5؛ إذا تجاوزت الحد الصحي (3 ساعات) تطبع "تنبيه: تجاوزت الحد الصحي للعب".',
            subjectContext: 'الصف الثالث الإعدادي — الوعي السيبراني والرقابة الأبوية بـ Python',
            starterCode: `weekly_hours = 5\nif weekly_hours > 10:\n    print("تنبيه: تجاوزت الحد الصحي للعب")\nelse:\n    print("وقت آمن")`,
            hint: 'عدّل الشرط إلى if weekly_hours > 3:.',
            requiredCodeSnippets: ['weekly_hours > 3'],
            expectedOutputContains: ['تنبيه: تجاوزت الحد الصحي للعب'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p3-c3', 'الوحدة 2 (ثالثة إعدادي)', [
      { q: 'معادلة التنبؤ الخطي في نموذج الذكاء الاصطناعي:', opts: ['y = w * x + b', 'x = a / 0', 'selector {color: b}', 'y = len(b)'], ans: 0, exp: 'y = w*x + b.' },
      { q: 'شبكات GANs تعتمد على التنافس بين:', opts: ['Generator و Discriminator', 'IoT و USB', 'Word و Excel', 'HTML و CSS'], ans: 0, exp: 'المولد والمميز.' },
      { q: 'من أدوات الرقابة الأبوية لضبط وقت الألعاب:', opts: ['Google Family Link و Apple Screen Time', 'Ransomware', 'Baiting', 'Pretexting'], ans: 0, exp: 'أدوات الرقابة الأبوية الرسمية.' },
      { q: 'من قواعد حماية الخصوصية مع الذكاء الاصطناعي عدم إدخال:', opts: ['البيانات الشخصية الحساسة PII', 'أسئلة العلوم', 'أمثلة Python', 'الألوان'], ans: 0, exp: 'حماية PII واجبة.' },
      { q: 'إضافة مشهورة للتحقق من مقاطع الفيديو المزيفة:', opts: ['InVID', 'Setup.exe', 'LPT1', 'Font'], ans: 0, exp: 'أداة InVID.' },
    ]),
  },
  {
    id: 'p3-ict-t2-c4',
    order: 4,
    term: 2,
    title: 'الفصل الرابع (الترم الثاني): مشروع بايثون المتكامل وتحليل البيانات والوعي السيبراني',
    description: 'دمج الدوال ومعالجة الأخطاء والقوائم لبناء مساعد تقييم طلابي متكامل بلغة Python.',
    lessons: [
      {
        id: 'p3-ict-t2-c4-l1',
        order: 1,
        title: 'الدرس الأول (ترم 2): بناء حاسبة ذكية محمية من الأخطاء بـ Python',
        durationMinutes: 20,
        summary:
          'في هذا الدرس نجمع بين الدوال (def) والقوائم (Lists) والـ try/except لبناء برنامج بايثون يحسب متوسط الدرجات ويعالج قائمة فارغة أو قسماً خاطئاً دون انهيار.',
        keyPoints: [
          'التحقق من طول القائمة عبر len(scores) لتجنب ZeroDivisionError.',
          'إرجاع الناتج بدالة return وتنسيق الطباعة.',
        ],
        mcqQuestions: [
          {
            id: 'p3-c4-l1-q1',
            question: 'لجلب عدد الدرجات داخل قائمة scores قبل القسمة لحساب المتوسط نستخدم:',
            options: ['len(scores)', 'scores.sort()', 'scores.upper()', 'def(scores)'],
            correctIndex: 0,
            explanation: 'len() تعيد عدد العناصر.',
          },
        ],
        trueFalseQuestions: [
          {
            id: 'p3-c4-l1-tf1',
            statement: 'حساب متوسط قائمة فارغة بدون حماية يسبب خطأ القسمة على صفر (ZeroDivisionError).',
            isTrue: true,
            explanation: 'صحيح — لأن المقام len(scores) يكون صفراً.',
          },
        ],
        essayQuestions: [
          {
            id: 'p3-c4-l1-es1',
            questionType: 'essay',
            question: 'كيف تمنع انهيار برنامج يحسب متوسط قائمة درجات قد تكون فارغة في Python؟',
            modelAnswer: 'بفحص len(scores) == 0 أو وضع عملية القسمة داخل كتلة try / except ZeroDivisionError.',
            keywords: ['len', 'try', 'ZeroDivisionError'],
          },
        ],
        codeChallenges: [
          {
            id: 'p3-c4-l1-code1',
            language: 'python',
            title: 'عملي بايثون (الترم 2): دالة حساب متوسط الدرجات مع حماية try/except',
            prompt:
              'أكمل دالة calc_average(scores) لجمع عناصر [80, 90, 100] وقسمتها على len(scores) داخل try/except وطباعة المتوسط 90.',
            subjectContext: 'الصف الثالث الإعدادي — مشروع بايثون التطبيقي',
            starterCode: `def calc_average(scores):\n    try:\n        total = 0\n        for s in scores:\n            total += s\n        return total / 1\n    except ZeroDivisionError:\n        return 0\n\nprint(calc_average([80, 90, 100]))`,
            hint: 'استبدل / 1 بـ / len(scores).',
            requiredCodeSnippets: ['len(scores)', 'try:', 'except ZeroDivisionError:'],
            expectedOutputContains: ['90'],
          },
        ],
      },
    ],
    chapterReviewQuestions: makeChapterReview('p3-c4', 'الفصل 4 (ثالثة إعدادي)', [
      { q: 'وظيفة len(list) هي:', opts: ['إرجاع عدد عناصر القائمة', 'حذف القائمة', 'ترتيب الحروف', 'رسم دائرة'], ans: 0, exp: 'len تعيد الطول.' },
      { q: 'لمعالجة قسمة غير متوقعة على 0 نستخدم:', opts: ['except ZeroDivisionError:', 'def', 'append', 'sort'], ans: 0, exp: 'ZeroDivisionError.' },
      { q: 'فحص أول عنصر في القائمة list_a يتم عبر:', opts: ['list_a[0]', 'list_a[-1]', 'list_a.len', 'list_a()'], ans: 0, exp: 'الفهرسة تبدأ من 0.' },
      { q: 'أداة للتحقق من الفيديوهات المزيفة:', opts: ['Deepware Scanner', 'LPT1', 'Padding', 'Font'], ans: 0, exp: 'Deepware Scanner.' },
      { q: 'الكلمة التي توقف الحلقة التكرارية مبكراً في بايثون:', opts: ['break', 'try', 'def', 'in'], ans: 0, exp: 'break.' },
    ]),
  },
];

export const DEFAULT_SUBJECTS: CurriculumSubject[] = [
  {
    id: 'subj-prep1-ict',
    stageId: 'stage-prep-1',
    name: 'الكمبيوتر وتكنولوجيا المعلومات (أولى إعدادي)',
    description:
      'المنهج الكامل (مذكرة أ. محمد الشريف): التكنولوجيا الخضراء، التحول الرقمي، أنظمة التشغيل، التعريفات، Gmail، السحابة، Google Meet، وقواعد البيانات Access (موضوعي + مقالي + عملي).',
    iconKey: 'code',
    accentColor: 'emerald',
    checkpointIntervalChapters: 3,
    chapters: prep1IctChapters,
    cumulativeReviews: buildCumulativeMilestones('p1-ict', prep1IctChapters),
  },
  {
    id: 'subj-prep2-ict',
    stageId: 'stage-prep-2',
    name: 'الحاسب والذكاء الاصطناعي وتصميم الويب (ثانية إعدادي)',
    description:
      'الأنظمة الذكية وتغير المناخ، التهديدات السيبرانية، البيانات الضخمة والـ AI، ومشروع تصميم الويب العملي بـ HTML و CSS في المحرر مع المعاينة الحية.',
    iconKey: 'code',
    accentColor: 'sky',
    checkpointIntervalChapters: 3,
    chapters: prep2IctChapters,
    cumulativeReviews: buildCumulativeMilestones('p2-ict', prep2IctChapters),
  },
  {
    id: 'subj-prep3-ict',
    stageId: 'stage-prep-3',
    name: 'الذكاء الاصطناعي و Python والأمن السيبراني (ثالثة إعدادي)',
    description:
      'التفكير الحاسوبي، الخوارزميات وخرائط التدفق، لغة Python 3 عملياً (Strings, Lists, Functions, try/except)، التنبؤ بـ AI، الملكية الفكرية، والتزييف العميق.',
    iconKey: 'code',
    accentColor: 'amber',
    checkpointIntervalChapters: 3,
    chapters: prep3IctChapters,
    cumulativeReviews: buildCumulativeMilestones('p3-ict', prep3IctChapters),
  },
  {
    id: 'subj-sec1-theory',
    stageId: 'stage-sec-1',
    name: 'البرمجة والذكاء الاصطناعي — النظري (أولى ثانوي)',
    description:
      'الوحدات 1–7 كاملة: دراسة المعلومات والأخلاقيات، حقوق البيانات والملكية الفكرية، أمن المعلومات والتشفير، المجتمع 5.0، الاتصالات، الأنظمة العددية والرقمنة، والدوائر المنطقية (موضوعي + مقالي).',
    iconKey: 'book',
    accentColor: 'amber',
    checkpointIntervalChapters: 3,
    chapters: sec1TheoryChapters,
    cumulativeReviews: buildCumulativeMilestones('sec1-theory', sec1TheoryChapters),
  },
  {
    id: 'subj-sec1-practical',
    stageId: 'stage-sec-1',
    name: 'البرمجة والذكاء الاصطناعي — العملي QUREO / TOFAS (أولى ثانوي)',
    description:
      'الفصول 1–17 ونماذج TOFAS العملية بنظام 4 اختيارات كلها على أكواد JavaScript: العمليات الحسابية، المتغيرات، الشروط، حلقات for، الدوال وMath، الأنواع، والمصفوفات.',
    iconKey: 'code',
    accentColor: 'emerald',
    checkpointIntervalChapters: 3,
    chapters: sec1PracticalChapters,
    cumulativeReviews: buildCumulativeMilestones('sec1-practical', sec1PracticalChapters),
  },
  {
    id: 'subj-sec2-theory',
    stageId: 'stage-sec-2',
    name: 'البرمجة والذكاء الاصطناعي — النظري (ثانية ثانوي)',
    description:
      'الوحدات 1–4 (14 درساً كاملاً): تطور AI وأخلاقياته، التشفير وأمن الشبكات والمخاطر، تطبيقات الويب وAPI وتقنيات الواجهة، والوسائط وUX وPDCA (أسئلة موضوعية + مقالي).',
    iconKey: 'book',
    accentColor: 'sky',
    checkpointIntervalChapters: 3,
    chapters: sec2TheoryChapters,
    cumulativeReviews: buildCumulativeMilestones('sec2-theory', sec2TheoryChapters),
  },
  {
    id: 'subj-sec2-practical',
    stageId: 'stage-sec-2',
    name: 'البرمجة والذكاء الاصطناعي — العملي والأكواد (ثانية ثانوي)',
    description:
      'اختبارات عملية بنظام 4 اختيارات كلها على الأكواد: أكواد Edge وANN وXAI، فحص 2FA/TLS وRisk Matrix، أكواد HTML5 الدلالية وCSS المتجاوب وReact، وAPI/JSON/CVR/A-B.',
    iconKey: 'code',
    accentColor: 'emerald',
    checkpointIntervalChapters: 3,
    chapters: sec2PracticalChapters,
    cumulativeReviews: buildCumulativeMilestones('sec2-practical', sec2PracticalChapters),
  },
];
