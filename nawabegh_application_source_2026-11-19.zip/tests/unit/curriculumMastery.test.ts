import { describe, expect, it } from 'vitest';
import {
  applyChapterReviewOutcome,
  computeDigitalAwardFromXp,
} from '../../server/curriculum/masteryEngine';
import { runSubjectCodeSandbox } from '../../src/utils/codeSandboxRunner';
import {
  DEFAULT_STAGES,
  DEFAULT_SUBJECTS,
} from '../../server/curriculum/defaultCurriculumData';
import type {
  CurriculumMcqQuestion,
  StudentSubjectProgress,
} from '../../src/types/curriculum';

const sampleQuestions: CurriculumMcqQuestion[] = [
  {
    id: 'q1',
    question: 'Q1',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 0,
    explanation: 'A',
  },
  {
    id: 'q2',
    question: 'Q2',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 1,
    explanation: 'B',
  },
  {
    id: 'q3',
    question: 'Q3',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 2,
    explanation: 'C',
  },
  {
    id: 'q4',
    question: 'Q4',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 3,
    explanation: 'D',
  },
  {
    id: 'q5',
    question: 'Q5',
    options: ['A', 'B', 'C', 'D'],
    correctIndex: 0,
    explanation: 'A',
  },
];

function createBaseProgress(): StudentSubjectProgress {
  return {
    completedLessonIds: ['l1', 'l2', 'other-chapter-lesson'],
    completedChapterIds: [],
    restudyRequiredChapterIds: [],
    passedCumulativeIds: [],
    chapterScores: {},
    cumulativeScores: {},
    totalXp: 20,
  };
}

describe('Curriculum Sequential Mastery & Subject Code Sandbox', () => {
  it('passes chapter review when missing 1 or 2 marks (في حالة نقصان درجة أو درجتين عادي)', () => {
    const progress = createBaseProgress();
    // Correct indices: [0, 1, 2, 3, 0]. Miss 2 answers -> score 3/5 (missedMarks = 2)
    const { updatedProgress, result } = applyChapterReviewOutcome({
      progress,
      chapterId: 'ch-1',
      chapterLessonIds: ['l1', 'l2'],
      questions: sampleQuestions,
      selectedAnswers: [0, 1, 2, 0, 1],
    });

    expect(result.score).toBe(3);
    expect(result.missedMarks).toBe(2);
    expect(result.passed).toBe(true);
    expect(result.mustRestudyChapter).toBe(false);
    expect(updatedProgress.completedChapterIds).toContain('ch-1');
    expect(updatedProgress.completedLessonIds).toContain('l1');
    expect(updatedProgress.completedLessonIds).toContain('l2');
    expect(updatedProgress.totalXp).toBeGreaterThan(20);
  });

  it('requires full chapter restudy from lesson 1 when missing > 2 marks', () => {
    const progress = createBaseProgress();
    // Miss 3 answers -> score 2/5 (missedMarks = 3 > 2)
    const { updatedProgress, result } = applyChapterReviewOutcome({
      progress,
      chapterId: 'ch-1',
      chapterLessonIds: ['l1', 'l2'],
      questions: sampleQuestions,
      selectedAnswers: [0, 1, 0, 0, 1],
    });

    expect(result.score).toBe(2);
    expect(result.missedMarks).toBe(3);
    expect(result.passed).toBe(false);
    expect(result.mustRestudyChapter).toBe(true);
    expect(updatedProgress.restudyRequiredChapterIds).toContain('ch-1');
    // Chapter lessons must be cleared so student restarts from lesson 1, while other chapters stay intact
    expect(updatedProgress.completedLessonIds).not.toContain('l1');
    expect(updatedProgress.completedLessonIds).not.toContain('l2');
    expect(updatedProgress.completedLessonIds).toContain('other-chapter-lesson');
  });

  it('upgrades student digital award tier as XP accumulates', () => {
    expect(computeDigitalAwardFromXp(10).tier).toBe('bronze');
    expect(computeDigitalAwardFromXp(60).tier).toBe('silver');
    expect(computeDigitalAwardFromXp(180).tier).toBe('gold');
    expect(computeDigitalAwardFromXp(320).tier).toBe('platinum');
  });

  it('executes subject-specific Try-the-Code physics and math calculations safely', () => {
    const physicsRun = runSubjectCodeSandbox({
      code: 'const I = 3, R = 12; const V = I * R; console.log(V);',
      expectedOutputContains: ['36'],
    });
    expect(physicsRun.passed).toBe(true);
    expect(physicsRun.logs).toEqual(['36']);

    const failedMathRun = runSubjectCodeSandbox({
      code: 'const a = 1, b = -5, c = 6; console.log(0);',
      expectedOutputContains: ['1'],
    });
    expect(failedMathRun.passed).toBe(false);

    const blockedRun = runSubjectCodeSandbox({
      code: 'fetch("https://example.com")',
    });
    expect(blockedRun.passed).toBe(false);
    expect(blockedRun.error).toBeTruthy();
  });

  it('executes 3rd Prep Python exercises (loops, lists, def functions, try/except ZeroDivisionError, linear AI model)', () => {
    const sumLoop = runSubjectCodeSandbox({
      language: 'python',
      code: `total = 0\nfor i in range(1, 6):\n    total += i\nprint(total)`,
      requiredCodeSnippets: ['for', 'range(1, 6)'],
      expectedOutputContains: ['15'],
    });
    expect(sumLoop.passed).toBe(true);
    expect(sumLoop.logs).toEqual(['15']);

    const fnRun = runSubjectCodeSandbox({
      language: 'python',
      code: `def circle_area(radius):\n    pi = 3.14\n    area = pi * radius * radius\n    return area\n\nprint(circle_area(5))`,
      requiredCodeSnippets: ['def circle_area', 'return'],
      expectedOutputContains: ['78.5'],
    });
    expect(fnRun.passed).toBe(true);
    expect(fnRun.logs).toEqual(['78.5']);

    const predictRun = runSubjectCodeSandbox({
      language: 'python',
      code: `def predict_grade(hours):\n    w = 5\n    b = 10\n    y = w * hours + b\n    return y\n\nprint(predict_grade(3))`,
      expectedOutputContains: ['25'],
    });
    expect(predictRun.passed).toBe(true);
    expect(predictRun.logs).toEqual(['25']);

    const tryExceptRun = runSubjectCodeSandbox({
      language: 'python',
      code: `try:\n    total = 100 / 0\n    print(total)\nexcept ZeroDivisionError:\n    print("لا يمكن القسمة على صفر")`,
      requiredCodeSnippets: ['try:', 'except ZeroDivisionError:'],
      expectedOutputContains: ['لا يمكن القسمة على صفر'],
    });
    expect(tryExceptRun.passed).toBe(true);
    expect(tryExceptRun.logs).toEqual(['لا يمكن القسمة على صفر']);

    const listStrRun = runSubjectCodeSandbox({
      language: 'python',
      code: `names = ["Ali", "Omar"]\nnames.append("Sara")\nword = "Python"\nprint(names)\nprint(word[-1].upper())`,
      expectedOutputContains: ['Sara', 'N'],
    });
    expect(listStrRun.passed).toBe(true);
  });

  it('validates and renders 2nd Prep HTML5 + CSS3 web design projects with live iframe output', () => {
    const htmlRes = runSubjectCodeSandbox({
      language: 'html_css',
      code: `<style>header{background-color:darkblue;color:white;}h2{border-bottom:5px solid blue;}</style><div class="container"><header><h1>مدرسة الشريف</h1></header><section><h2>معلومات</h2></section><footer>&copy; 2025</footer></div>`,
      requiredCodeSnippets: ['darkblue', 'border-bottom', '<header>', '<section>', '<footer>'],
      expectedOutputContains: ['&copy;'],
    });
    expect(htmlRes.passed).toBe(true);
    expect(htmlRes.renderedHtml).toContain('darkblue');
    expect(htmlRes.renderedHtml).toContain('<header>');
  });

  it('provides full Preparatory 1-3, 1st Secondary & 2nd Secondary (Theoretical objective+essay & Practical 4-choice code MCQs)', () => {
    const stageIds = DEFAULT_STAGES.map((s) => s.id);
    expect(stageIds).toEqual(
      expect.arrayContaining([
        'stage-prep-1',
        'stage-prep-2',
        'stage-prep-3',
        'stage-sec-1',
        'stage-sec-2',
      ])
    );

    const theory = DEFAULT_SUBJECTS.find((s) => s.id === 'subj-sec1-theory');
    const practical = DEFAULT_SUBJECTS.find((s) => s.id === 'subj-sec1-practical');
    expect(theory).toBeDefined();
    expect(practical).toBeDefined();

    // 1st Secondary Theoretical: Term 1 + Term 2, objective (MCQ + True/False) + essay (scientific_term/complete/essay)
    expect(theory!.chapters.some((c) => c.term === 1)).toBe(true);
    expect(theory!.chapters.some((c) => c.term === 2)).toBe(true);
    expect(theory!.cumulativeReviews.length).toBeGreaterThanOrEqual(2);
    for (const ch of theory!.chapters) {
      expect(ch.chapterReviewQuestions.length).toBeGreaterThanOrEqual(5);
      for (const l of ch.lessons) {
        expect(l.mcqQuestions.length).toBeGreaterThanOrEqual(4);
        expect(l.trueFalseQuestions?.length || 0).toBeGreaterThanOrEqual(1);
        expect(l.essayQuestions?.length || 0).toBeGreaterThanOrEqual(2);
      }
    }

    // 1st Secondary Practical: 100% 4-choice MCQs on code snippets, no sandbox or essay blockers
    expect(practical!.chapters.length).toBe(6);
    expect(practical!.cumulativeReviews.length).toBeGreaterThanOrEqual(2);
    for (const ch of practical!.chapters) {
      expect(ch.chapterReviewQuestions.length).toBeGreaterThanOrEqual(5);
      for (const q of ch.chapterReviewQuestions) {
        expect(q.options.length).toBe(4);
        expect(q.correctIndex).toBeGreaterThanOrEqual(0);
        expect(q.correctIndex).toBeLessThan(4);
      }
      for (const l of ch.lessons) {
        expect(l.codeChallenges.length).toBe(0);
        expect(l.trueFalseQuestions?.length || 0).toBe(0);
        expect(l.essayQuestions?.length || 0).toBe(0);
        expect(l.mcqQuestions.length).toBeGreaterThanOrEqual(4);
        for (const q of l.mcqQuestions) {
          expect(q.options.length).toBe(4);
        }
      }
    }

    // 2nd Secondary Theoretical: Units 1-4 (14 lessons total) with MCQ + True/False + Essay + Cumulative checkpoint
    const sec2Theory = DEFAULT_SUBJECTS.find((s) => s.id === 'subj-sec2-theory');
    const sec2Practical = DEFAULT_SUBJECTS.find((s) => s.id === 'subj-sec2-practical');
    expect(sec2Theory).toBeDefined();
    expect(sec2Practical).toBeDefined();
    expect(sec2Theory!.chapters.length).toBe(4);
    expect(sec2Theory!.chapters.reduce((acc, c) => acc + c.lessons.length, 0)).toBe(14);
    expect(sec2Theory!.cumulativeReviews.length).toBeGreaterThanOrEqual(1);
    for (const ch of sec2Theory!.chapters) {
      expect(ch.chapterReviewQuestions.length).toBeGreaterThanOrEqual(5);
      for (const l of ch.lessons) {
        expect(l.mcqQuestions.length).toBe(4);
        expect(l.trueFalseQuestions?.length || 0).toBe(2);
        expect(l.essayQuestions?.length || 0).toBeGreaterThanOrEqual(1);
      }
    }

    // 2nd Secondary Practical: 100% 4-choice MCQs on code snippets (no sandbox blockers, no true/false, no essay)
    expect(sec2Practical!.chapters.length).toBe(4);
    expect(sec2Practical!.cumulativeReviews.length).toBeGreaterThanOrEqual(1);
    for (const ch of sec2Practical!.chapters) {
      expect(ch.chapterReviewQuestions.length).toBe(5);
      for (const q of ch.chapterReviewQuestions) {
        expect(q.options.length).toBe(4);
        expect(q.correctIndex).toBeGreaterThanOrEqual(0);
        expect(q.correctIndex).toBeLessThan(4);
      }
      for (const l of ch.lessons) {
        expect(l.codeChallenges.length).toBe(0);
        expect(l.trueFalseQuestions?.length || 0).toBe(0);
        expect(l.essayQuestions?.length || 0).toBe(0);
        expect(l.mcqQuestions.length).toBe(4);
        for (const q of l.mcqQuestions) {
          expect(q.options.length).toBe(4);
          expect(q.correctIndex).toBeGreaterThanOrEqual(0);
          expect(q.correctIndex).toBeLessThan(4);
        }
      }
    }
  });
});


