import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  BookOpen,
  Trophy,
  Gift,
  Clock,
  Shuffle,
  CheckCircle2,
  XCircle,
  RotateCw,
  Plus,
  Trash2,
  Award,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  Lightbulb,
  Printer,
  Layers,
  Check,
  X,
  Database,
  RefreshCw,
  Zap,
  Users,
  ShoppingBag,
  Brain,
  Crown,
  Unlock,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Lesson, Quiz, Student, CurrentUser, Language, Teacher, WeeklyClassChallenge } from '../types';
import { getAuthHeaders, isStudentRole, isParentRole } from '../utils/rbac';
import { AlSharifWatermark } from './ScreenProtectionGuard';
import { realtimeSync } from '../services/realtimeSync';
import { getMcqOptionSurfaceClass, MCQ_QUESTION_BOX_CLASS } from '../utils/mcqTheme';

export interface FlashcardItem {
  id: string;
  subject: string;
  grade: string;
  lessonId?: string;
  lessonTitle?: string;
  category: 'lesson_derived' | 'question_card' | 'teacher_db_card';
  question: string;
  answer: string;
  explanation: string;
  hint?: string;
  options: string[];
  correctOptionIndex: number;
  difficulty: 'easy' | 'medium' | 'hard';
  createdBy?: string;
  createdAt?: string;
}

export interface DigitalGiftItem {
  id: string;
  studentId?: string;
  studentName: string;
  studentGrade?: string;
  giftTitle: string;
  giftTitleEn: string;
  giftType: 'sharif_shield' | 'gold_voucher' | 'bonus_grades' | 'excellence_stars' | 'homework_pass';
  pointsValue: number;
  badgeLabel: string;
  description: string;
  subject: string;
  competitionTitle: string;
  awardedBy: string;
  serialCode: string;
  awardedAt: string;
}

export interface CompetitionParticipant {
  id: string;
  name: string;
  grade: string;
  code?: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  streak: number;
  giftsWon: DigitalGiftItem[];
  lifelines: {
    fiftyFifty: boolean;
    extraTime: boolean;
    swapQuestion: boolean;
  };
}

export interface CompetitionDoorQuestion {
  doorNumber: number;
  questionId: string;
  subject: string;
  sourceLessonTitle?: string;
  questionText: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  points: number;
  hasMysteryGift: boolean;
  isOpened: boolean;
  answeredByStudentName?: string;
  wasCorrect?: boolean;
}

export interface CompetitionHistoryRecord {
  id: string;
  title: string;
  mode: 'sharif_doors' | 'rapid_arena';
  subject: string;
  grade: string;
  studentsCount: number;
  questionsCount: number;
  winnerName: string;
  winnerScore: number;
  participants: Array<{ name: string; score: number; correctCount: number; giftsCount: number }>;
  completedAt: string;
}

interface FlashcardsAndCompetitionsHubProps {
  lessons: Lesson[];
  quizzes: Quiz[];
  students: Student[];
  teachers?: Teacher[];
  currentUser: CurrentUser;
  language: Language;
  onNavigateToLessons?: () => void;
  onNavigateToStudents?: () => void;
}

const DIGITAL_GIFT_CATALOG: Array<{
  giftType: DigitalGiftItem['giftType'];
  giftTitle: string;
  giftTitleEn: string;
  pointsValue: number;
  badgeLabel: string;
  description: string;
}> = [
  {
    giftType: 'sharif_shield',
    giftTitle: 'وسام ودرع مسابقة الشريف الرقمي للتفوق العلمي — منصة الشريف',
    giftTitleEn: 'Al-Sharif Competition Excellence Digital Shield',
    pointsValue: 250,
    badgeLabel: 'درع منصة الشريف الذهبي',
    description:
      'يُمنح للمتسابق المتفوق تقديراً لسرعة البديهة والإجابة النموذجية من دروس قاعدة بيانات منصة الشريف.',
  },
  {
    giftType: 'gold_voucher',
    giftTitle: 'بطاقة التميز الذهبية الإلكترونية — منصة الشريف (+150 نقطة)',
    giftTitleEn: 'Al-Sharif Golden Excellence Digital Card (+150 Pts)',
    pointsValue: 150,
    badgeLabel: 'قسيمة نقاط ذهبية',
    description:
      'تُضاف نقاط هذه البطاقة الرقمية مباشرة إلى السجل الأكاديمي للطالب في لوحة شرف منصة الشريف.',
  },
  {
    giftType: 'bonus_grades',
    giftTitle: 'قسيمة درجات تشجيعية إضافية (+5 درجات أعمال سنة) — منصة الشريف',
    giftTitleEn: 'Al-Sharif Bonus Academic Credit Voucher (+5 Marks)',
    pointsValue: 200,
    badgeLabel: '+5 درجات إضافية',
    description:
      'هدية رقمية تشجيعية من منصة الشريف تمنح الطالب 5 درجات إضافية في تقييمات المادة الدراسية.',
  },
  {
    giftType: 'excellence_stars',
    giftTitle: 'صندوق نجوم منصة الشريف الرقمي للمتفوقين',
    giftTitleEn: 'Al-Sharif Star Chest Digital Reward',
    pointsValue: 120,
    badgeLabel: 'نجم مسابقة الشريف',
    description: 'وسام تشجيعي رقمي يوثق تفوق الطالب في مسابقة الشريف ويظهر في بوابة الطالب وولي الأمر.',
  },
  {
    giftType: 'homework_pass',
    giftTitle: 'بطاقة الإعفاء التشجيعية ومضاعفة نقاط مسابقة الشريف',
    giftTitleEn: 'Al-Sharif Double Score Digital Pass',
    pointsValue: 180,
    badgeLabel: 'مضاعفة النقاط ×2',
    description: 'بطاقة إلكترونية رقمية تمنح الطالب أولوية التكريم في التقرير الأسبوعي لمنصة الشريف.',
  },
];

function stripHtmlText(html?: string): string {
  if (!html) return '';
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Cryptographically-assisted Fisher-Yates shuffle to guarantee true random non-sequential ordering
function shuffleArrayRandomly<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    let randFloat = Math.random();
    if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
      const buf = new Uint32Array(1);
      window.crypto.getRandomValues(buf);
      randFloat = buf[0] / (0xffffffff + 1);
    }
    const j = Math.floor(randFloat * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export const FlashcardsAndCompetitionsHub: React.FC<FlashcardsAndCompetitionsHubProps> = ({
  lessons,
  quizzes,
  students,
  teachers = [],
  currentUser,
  language,
  onNavigateToLessons,
  onNavigateToStudents,
}) => {
  const isAr = language === 'ar';
  const isStudent = isStudentRole(currentUser.role);
  const isParent = isParentRole(currentUser.role);
  const canManage = !isStudent && !isParent && currentUser.role !== 'visitor';

  // Active sub-mode inside the Hub
  const [activeMode, setActiveMode] = useState<
    | 'sharif_competition'
    | 'live_challenge_rooms'
    | 'class_challenges'
    | 'rewards_store'
    | 'subject_flashcards'
    | 'question_flashcards'
    | 'digital_gifts_vault'
  >('sharif_competition');

  // Sound Effects toggle (Web Audio API)
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isSyncingDb, setIsSyncingDb] = useState<boolean>(false);

  // 100% Real Database State (synced from props + /api/flashcards-competitions)
  const [dbLessons, setDbLessons] = useState<Lesson[]>(lessons);
  const [dbQuizzes, setDbQuizzes] = useState<Quiz[]>(quizzes);
  const [dbStudents, setDbStudents] = useState<Student[]>(students);
  const [dbExtractedQuestions, setDbExtractedQuestions] = useState<any[]>([]);
  const [customFlashcards, setCustomFlashcards] = useState<FlashcardItem[]>([]);
  const [digitalGifts, setDigitalGifts] = useState<DigitalGiftItem[]>([]);
  const [competitionHistory, setCompetitionHistory] = useState<CompetitionHistoryRecord[]>([]);
  const [liveChallengeRooms, setLiveChallengeRooms] = useState<any[]>([]);
  const [activeChallengeRoomId, setActiveChallengeRoomId] = useState<string | null>(null);
  const [weeklyLeague, setWeeklyLeague] = useState<any[]>([]);
  const [storeCatalog, setStoreCatalog] = useState<any[]>([]);
  const [storeRedemptions, setStoreRedemptions] = useState<any[]>([]);
  const [studentBadges, setStudentBadges] = useState<Record<string, string>>({});
  const [spacedRepetitionMap, setSpacedRepetitionMap] = useState<Record<string, any>>({});
  const [sm2Map, setSm2Map] = useState<Record<string, any>>({});
  const [bonusPointsMap, setBonusPointsMap] = useState<Record<string, number>>({});
  const [onlySpacedReviewDue, setOnlySpacedReviewDue] = useState<boolean>(false);

  // Live Challenge Room Creator State
  const [roomMode, setRoomMode] = useState<'1v1' | 'teams'>('1v1');
  const [roomTitle, setRoomTitle] = useState<string>('بطولة الشريف المباشرة — الأسرع يربح الضعف ×2');
  const [roomSubject, setRoomSubject] = useState<string>('كل المواد');
  const [roomQuestionsCount, setRoomQuestionsCount] = useState<number>(6);
  const [sideAStudentName, setSideAStudentName] = useState<string>('');
  const [sideBStudentName, setSideBStudentName] = useState<string>('');
  const [joinRoomCodeInput, setJoinRoomCodeInput] = useState<string>('');

  // Store State
  const [selectedStoreStudentName, setSelectedStoreStudentName] = useState<string>(
    currentUser.name || ''
  );
  const [selectedUnlockLessonId, setSelectedUnlockLessonId] = useState<string>('');
  const [isRedeemingReward, setIsRedeemingReward] = useState<boolean>(false);

  // Weekly Class Challenges State
  const [classChallenges, setClassChallenges] = useState<WeeklyClassChallenge[]>([]);
  const [challengeTitle, setChallengeTitle] = useState<string>('تحدي العشرة الأوائل — تفوق الوحدة');
  const [challengeSubject, setChallengeSubject] = useState<string>('جميع المواد');
  const [challengeGrade, setChallengeGrade] = useState<string>('جميع الصفوف');
  const [challengeMinPct, setChallengeMinPct] = useState<number>(90);
  const [challengeMaxWinners, setChallengeMaxWinners] = useState<number>(10);
  const [challengeBadgeTitle, setChallengeBadgeTitle] = useState<string>('شارة التفوق الأسبوعي 🏆');
  const [challengeDeadline, setChallengeDeadline] = useState<string>(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );
  const [isSavingChallenge, setIsSavingChallenge] = useState<boolean>(false);

  const [statusBanner, setStatusBanner] = useState<{
    type: 'success' | 'warning' | 'error';
    text: string;
  } | null>(null);

  useEffect(() => {
    if (lessons.length > 0) setDbLessons(lessons);
  }, [lessons]);

  useEffect(() => {
    if (quizzes.length > 0) setDbQuizzes(quizzes);
  }, [quizzes]);

  useEffect(() => {
    if (students.length > 0) setDbStudents(students);
  }, [students]);

  const syncFromDatabase = async (showFeedback = false) => {
    setIsSyncingDb(true);
    try {
      const [res, chRes] = await Promise.all([
        fetch('/api/flashcards-competitions'),
        fetch('/api/class-challenges').catch(() => null),
      ]);
      if (chRes && chRes.ok) {
        const chData = await chRes.json();
        if (Array.isArray(chData?.challenges)) setClassChallenges(chData.challenges);
      }
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.customFlashcards)) setCustomFlashcards(data.customFlashcards);
        if (Array.isArray(data.digitalGifts)) setDigitalGifts(data.digitalGifts);
        if (Array.isArray(data.competitionHistory)) setCompetitionHistory(data.competitionHistory);
        if (Array.isArray(data.dbLessons) && data.dbLessons.length > 0) {
          setDbLessons(
            data.dbLessons.map((l: any) => ({
              ...l,
              infographicData:
                typeof l.infographicData === 'string' && l.infographicData.trim()
                  ? (() => {
                      try {
                        return JSON.parse(l.infographicData);
                      } catch {
                        return undefined;
                      }
                    })()
                  : l.infographicData || undefined,
            }))
          );
        }
        if (Array.isArray(data.dbQuizzes) && data.dbQuizzes.length > 0) {
          setDbQuizzes(
            data.dbQuizzes.map((q: any) => ({
              ...q,
              questions:
                typeof q.questions === 'string'
                  ? (() => {
                      try {
                        return JSON.parse(q.questions);
                      } catch {
                        return [];
                      }
                    })()
                  : Array.isArray(q.questions)
                  ? q.questions
                  : [],
            }))
          );
        }
        if (Array.isArray(data.dbStudents) && data.dbStudents.length > 0) {
          setDbStudents(data.dbStudents);
        }
        if (Array.isArray(data.dbLessonQuestions)) {
          setDbExtractedQuestions(data.dbLessonQuestions);
        }
        if (Array.isArray(data.liveChallengeRooms)) {
          setLiveChallengeRooms(data.liveChallengeRooms);
        }
        if (Array.isArray(data.weeklyLeague)) {
          setWeeklyLeague(data.weeklyLeague);
        }
        if (Array.isArray(data.storeCatalog)) {
          setStoreCatalog(data.storeCatalog);
        }
        if (Array.isArray(data.storeRedemptions)) {
          setStoreRedemptions(data.storeRedemptions);
        }
        if (data.studentBadges && typeof data.studentBadges === 'object') {
          setStudentBadges(data.studentBadges);
        }
        if (data.bonusPointsMap && typeof data.bonusPointsMap === 'object') {
          setBonusPointsMap(data.bonusPointsMap);
        }
        if (data.spacedRepetitionRecords && typeof data.spacedRepetitionRecords === 'object') {
          const stuKey = currentUser.studentId || currentUser.id || currentUser.name || 'default';
          setSpacedRepetitionMap(data.spacedRepetitionRecords[stuKey] || {});
        }
        const stuKey = currentUser.studentId || currentUser.id || currentUser.name || 'default';
        fetch(`/api/flashcards/sm2?studentId=${encodeURIComponent(stuKey)}`)
          .then((r) => (r.ok ? r.json() : null))
          .then((sm2Res) => {
            if (sm2Res?.records && typeof sm2Res.records === 'object') {
              setSm2Map(sm2Res.records);
            }
          })
          .catch(() => {});
        if (showFeedback) {
          setStatusBanner({
            type: 'success',
            text: `تمت المزامنة المباشرة من قاعدة بيانات منصة الشريف: ${
              data.dbLessons?.length || dbLessons.length
            } دروس و ${data.dbStudents?.length || dbStudents.length} طلاب مسجلين.`,
          });
        }
      }
    } catch {
      // ignore network error
    } finally {
      setIsSyncingDb(false);
    }
  };

  useEffect(() => {
    syncFromDatabase(false);
    const unsubRoom = realtimeSync.on('challenge_room:updated', (data: any) => {
      if (Array.isArray(data?.allRooms)) {
        setLiveChallengeRooms(data.allRooms);
      } else if (data?.room) {
        setLiveChallengeRooms((prev) =>
          prev.some((r) => r.id === data.room.id)
            ? prev.map((r) => (r.id === data.room.id ? data.room : r))
            : [data.room, ...prev]
        );
      }
    });
    const unsubLeague = realtimeSync.on('weekly_league:updated', (data: any) => {
      if (Array.isArray(data?.weeklyLeague)) {
        setWeeklyLeague(data.weeklyLeague);
      }
    });
    const unsubStore = realtimeSync.on('store:redeemed', (data: any) => {
      if (Array.isArray(data?.storeRedemptions)) {
        setStoreRedemptions(data.storeRedemptions);
      }
      if (data?.studentBadges) {
        setStudentBadges(data.studentBadges);
      }
    });
    const unsubBonus = realtimeSync.on('bonus_points:updated', (data: any) => {
      if (data?.bonusPointsMap) {
        setBonusPointsMap(data.bonusPointsMap);
      }
    });
    return () => {
      unsubRoom();
      unsubLeague();
      unsubStore();
      unsubBonus();
    };
  }, []);

  // Dynamically derive Subjects & Grades strictly from real Database Lessons & Quizzes
  const availableSubjects = useMemo<string[]>(() => {
    const set = new Set<string>();
    dbLessons.forEach((l) => {
      if (l.subject?.trim()) set.add(l.subject.trim());
    });
    dbQuizzes.forEach((q) => {
      if (q.subject?.trim()) set.add(q.subject.trim());
    });
    customFlashcards.forEach((c) => {
      if (c.subject?.trim()) set.add(c.subject.trim());
    });
    return Array.from(set);
  }, [dbLessons, dbQuizzes, customFlashcards]);

  const availableGrades = useMemo<string[]>(() => {
    const set = new Set<string>();
    dbLessons.forEach((l) => {
      if (l.grade?.trim()) set.add(l.grade.trim());
    });
    dbQuizzes.forEach((q) => {
      if (q.grade?.trim()) set.add(q.grade.trim());
    });
    dbStudents.forEach((s) => {
      if (s.grade?.trim()) set.add(s.grade.trim());
    });
    return ['كل المراحل', ...Array.from(set)];
  }, [dbLessons, dbQuizzes, dbStudents]);

  // Build 100% Database-Driven Flashcards & Questions Pool strictly from:
  // 1. Real Lessons in PostgreSQL (`dbLessons` — descriptions, units, infographicData sections, contentHtml sentences, attachments)
  // 2. Backend-extracted lesson questions (`dbExtractedQuestions` from `repo.generateQuizQuestionsFromDbLessons`)
  // 3. Real Quizzes in PostgreSQL (`dbQuizzes`)
  // 4. Teacher-saved flashcards in PostgreSQL (`customFlashcards`)
  const allDatabaseFlashcards = useMemo<FlashcardItem[]>(() => {
    const cards: FlashcardItem[] = [];
    const allLessonDescriptions = dbLessons
      .map((l) => (l.description || '').trim())
      .filter((d) => d.length >= 5);

    const buildDistractorsFromDb = (correctText: string, lessonSubject: string): string[] => {
      const sameSubjDescs = dbLessons
        .filter((l) => l.subject === lessonSubject && l.description?.trim() !== correctText)
        .map((l) => (l.description || '').trim())
        .filter(Boolean);
      const otherDescs = allLessonDescriptions.filter((d) => d !== correctText);
      const combined = Array.from(new Set([...sameSubjDescs, ...otherDescs]));
      const picked = shuffleArrayRandomly(combined).slice(0, 3);
      const otherLessonTitles = dbLessons
        .filter((l) => l.description?.trim() !== correctText)
        .map((l) => `مفهوم خاص بدرس: ${l.title} (${l.subject})`);
      for (const fallback of otherLessonTitles) {
        if (picked.length >= 3) break;
        if (fallback !== correctText && !picked.includes(fallback)) {
          picked.push(fallback);
        }
      }
      while (picked.length < 3) {
        picked.push(`خيار غير مطابق لمحتوى الدرس المسجل في قاعدة البيانات (${picked.length + 1})`);
      }
      return picked.slice(0, 3);
    };

    // A. Extract directly from every real Lesson in the Database
    dbLessons.forEach((les) => {
      const desc = (les.description || '').trim();
      const unitName = (les.unit || '').trim();

      // 1) Core Lesson Summary Flashcard
      if (desc) {
        const distractors = buildDistractorsFromDb(desc, les.subject);
        const rawOptions = [desc, ...distractors];
        const shuffledOpts = shuffleArrayRandomly(rawOptions);
        cards.push({
          id: `db-les-main-${les.id}`,
          subject: les.subject,
          grade: les.grade,
          lessonId: les.id,
          lessonTitle: les.title,
          category: 'lesson_derived',
          question: `ما هو المفهوم والمحتوى العلمي الأساسي الذي يتناوله درس «${les.title}» في مادة (${les.subject})؟`,
          answer: desc,
          explanation: `مستخرج مباشرة من درس «${les.title}» (${
            unitName ? `${unitName} · ` : ''
          }المعلم: ${les.teacherName}) المسجل في قاعدة بيانات منصة الشريف.`,
          hint: unitName ? `الوحدة الدراسية: ${unitName}` : `المعلم: ${les.teacherName}`,
          options: shuffledOpts,
          correctOptionIndex: Math.max(0, shuffledOpts.indexOf(desc)),
          difficulty: 'easy',
        });
      }

      // 2) Unit & Teacher Attribution Question from DB Lesson
      if (unitName) {
        const otherUnits = Array.from(
          new Set(
            dbLessons
              .map((l) => (l.unit || '').trim())
              .filter((u) => u && u !== unitName)
          )
        );
        while (otherUnits.length < 3) {
          otherUnits.push(`وحدة دراسية أخرى (${otherUnits.length + 1})`);
        }
        const rawOpts = [unitName, ...shuffleArrayRandomly(otherUnits).slice(0, 3)];
        const shuffledOpts = shuffleArrayRandomly(rawOpts);
        cards.push({
          id: `db-les-unit-${les.id}`,
          subject: les.subject,
          grade: les.grade,
          lessonId: les.id,
          lessonTitle: les.title,
          category: 'lesson_derived',
          question: `ضمن أي وحدة دراسية يندرج درس «${les.title}» في مادة (${les.subject} — ${les.grade})؟`,
          answer: unitName,
          explanation: `درس «${les.title}» مسجل في قاعدة البيانات ضمن «${unitName}» للمعلم ${les.teacherName}.`,
          hint: `راجع بيانات درس «${les.title}» في مادة ${les.subject}`,
          options: shuffledOpts,
          correctOptionIndex: Math.max(0, shuffledOpts.indexOf(unitName)),
          difficulty: 'easy',
        });
      }

      // 3) Infographic Sections from DB Lesson
      if (les.infographicData?.sections?.length) {
        les.infographicData.sections.forEach((sec, sIdx) => {
          const secTitle = (sec.title || '').trim();
          const secDesc = (sec.description || '').trim();
          if (!secTitle || !secDesc) return;
          const distractors = buildDistractorsFromDb(secDesc, les.subject);
          const rawOpts = [secDesc, ...distractors];
          const shuffledOpts = shuffleArrayRandomly(rawOpts);
          cards.push({
            id: `db-les-sec-${les.id}-${sIdx}`,
            subject: les.subject,
            grade: les.grade,
            lessonId: les.id,
            lessonTitle: les.title,
            category: 'lesson_derived',
            question: `في درس «${les.title}» (${les.subject})، ما هو الشرح العلمي لمحور «${secTitle}»؟`,
            answer: secDesc,
            explanation: `من محاور درس «${les.title}» المسجل في قاعدة بيانات منصة الشريف للمعلم ${les.teacherName}.`,
            hint: `من درس: ${les.title}`,
            options: shuffledOpts,
            correctOptionIndex: Math.max(0, shuffledOpts.indexOf(secDesc)),
            difficulty: 'medium',
          });
        });
      }

      // 4) Rich HTML Study Notes (`contentHtml`) from DB Lesson
      const plainHtml = stripHtmlText(les.contentHtml);
      if (plainHtml.length >= 20) {
        const sentences = plainHtml
          .split(/[.!؟\n]+/)
          .map((s) => s.trim())
          .filter((s) => s.length >= 18 && s.length <= 220);
        sentences.slice(0, 4).forEach((sentence, sentIdx) => {
          const distractors = buildDistractorsFromDb(sentence, les.subject);
          const rawOpts = [sentence, ...distractors];
          const shuffledOpts = shuffleArrayRandomly(rawOpts);
          cards.push({
            id: `db-les-html-${les.id}-${sentIdx}`,
            subject: les.subject,
            grade: les.grade,
            lessonId: les.id,
            lessonTitle: les.title,
            category: 'lesson_derived',
            question: `استناداً إلى مذكرة درس «${les.title}» (${les.subject})، أي العبارات العلمية التالية وردت في شرح الدرس؟`,
            answer: sentence,
            explanation: `عبارة مستخلصة مباشرة من مذكرة درس «${les.title}» في قاعدة بيانات منصة الشريف.`,
            hint: `مذكرة درس: ${les.title}`,
            options: shuffledOpts,
            correctOptionIndex: Math.max(0, shuffledOpts.indexOf(sentence)),
            difficulty: 'medium',
          });
        });
      }
    });

    // B. Include Backend-Extracted Questions from DB Lessons (`repo.generateQuizQuestionsFromDbLessons`)
    dbExtractedQuestions.forEach((dbQ, idx) => {
      if (!dbQ || !dbQ.question || !Array.isArray(dbQ.options) || dbQ.options.length < 2) return;
      const matchedLesson = dbLessons.find((l) => l.id === dbQ.sourceLessonId);
      const correctAns = dbQ.options[dbQ.correctOptionIndex ?? 0] || dbQ.options[0];
      cards.push({
        id: `db-gen-q-${dbQ.id || idx}`,
        subject: matchedLesson?.subject || 'الدروس المسجلة',
        grade: matchedLesson?.grade || 'كل المراحل',
        lessonId: dbQ.sourceLessonId,
        lessonTitle: dbQ.sourceLessonTitle || matchedLesson?.title,
        category: 'question_card',
        question: dbQ.question,
        answer: correctAns,
        explanation:
          dbQ.explanation ||
          `مستخرج من درس «${dbQ.sourceLessonTitle || matchedLesson?.title || ''}» في قاعدة البيانات.`,
        hint: dbQ.sourceLessonTitle ? `المصدر: درس ${dbQ.sourceLessonTitle}` : undefined,
        options: dbQ.options,
        correctOptionIndex: dbQ.correctOptionIndex ?? 0,
        difficulty: 'medium',
      });
    });

    // C. Include Questions from Real Quizzes stored in PostgreSQL (`dbQuizzes`)
    dbQuizzes.forEach((qz) => {
      (qz.questions || []).forEach((q, qIdx) => {
        if (!q.question || !Array.isArray(q.options) || q.options.length < 2) return;
        const correctAns = q.options[q.correctOptionIndex ?? 0] || q.options[0];
        cards.push({
          id: `db-qz-${qz.id}-${q.id || qIdx}`,
          subject: qz.subject,
          grade: qz.grade,
          lessonId: q.sourceLessonId,
          lessonTitle: q.sourceLessonTitle || qz.title,
          category: 'question_card',
          question: q.question,
          answer: correctAns,
          explanation:
            q.explanation ||
            `سؤال معتمد من اختبار «${qz.title}» في مادة ${qz.subject} بقاعدة بيانات منصة الشريف.`,
          hint: `من اختبار: ${qz.title}`,
          options: q.options,
          correctOptionIndex: q.correctOptionIndex ?? 0,
          difficulty: 'medium',
        });
      });
    });

    // D. Include Teacher-Added Flashcards stored in PostgreSQL (`customFlashcards`)
    customFlashcards.forEach((fc) => {
      if (!fc.question) return;
      cards.push({
        ...fc,
        category: 'teacher_db_card',
        options:
          Array.isArray(fc.options) && fc.options.length >= 2
            ? fc.options
            : [fc.answer, 'خيار بديل 1', 'خيار بديل 2', 'خيار بديل 3'],
        correctOptionIndex: fc.correctOptionIndex ?? 0,
      });
    });

    // Deduplicate by question text so each card is unique
    const seenQuestions = new Set<string>();
    return cards.filter((c) => {
      const key = `${c.subject}::${c.question.trim()}`;
      if (seenQuestions.has(key)) return false;
      seenQuestions.add(key);
      return true;
    });
  }, [dbLessons, dbExtractedQuestions, dbQuizzes, customFlashcards]);

  // Flashcards View Filters
  const [selectedSubject, setSelectedSubject] = useState<string>('كل المواد');
  const [selectedGrade, setSelectedGrade] = useState<string>('كل المراحل');
  const [selectedLessonFilter, setSelectedLessonFilter] = useState<string>('all');
  const [currentCardIndex, setCurrentCardIndex] = useState<number>(0);
  const [isCardFlipped, setIsCardFlipped] = useState<boolean>(false);
  const [showCardHint, setShowCardHint] = useState<boolean>(false);
  const [selectedFlashcardOption, setSelectedFlashcardOption] = useState<number | null>(null);
  const [masteryMap, setMasteryMap] = useState<Record<string, 'mastered' | 'review' | 'hard'>>(() => {
    try {
      const saved = localStorage.getItem('sharif_flashcard_mastery_v2');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [shuffledDeckSeed, setShuffledDeckSeed] = useState<number>(0);

  // Add New Flashcard directly linked to a DB Lesson
  const [isAddCardModalOpen, setIsAddCardModalOpen] = useState<boolean>(false);
  const [newCardLessonId, setNewCardLessonId] = useState<string>('');
  const [newCardQuestion, setNewCardQuestion] = useState<string>('');
  const [newCardAnswer, setNewCardAnswer] = useState<string>('');
  const [newCardExplanation, setNewCardExplanation] = useState<string>('');
  const [newCardDistractor1, setNewCardDistractor1] = useState<string>('');
  const [newCardDistractor2, setNewCardDistractor2] = useState<string>('');
  const [newCardDistractor3, setNewCardDistractor3] = useState<string>('');

  // Al-Sharif Competition Setup State (100% Real DB Lessons & DB Students)
  const [compTitle, setCompTitle] = useState<string>(
    'مسابقة الشريف التفاعلية الكبرى — منصة الشريف'
  );
  const [compStyle, setCompStyle] = useState<'sharif_doors' | 'rapid_arena'>('sharif_doors');
  const [compSubject, setCompSubject] = useState<string>('كل المواد');
  const [compGrade, setCompGrade] = useState<string>('كل المراحل');
  const [compSelectedLessonIds, setCompSelectedLessonIds] = useState<string[]>([]);
  const [targetStudentsCount, setTargetStudentsCount] = useState<number>(4);
  const [targetQuestionsCount, setTargetQuestionsCount] = useState<number>(10);
  const [timerSecondsPerQuestion, setTimerSecondsPerQuestion] = useState<number>(30);
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);

  // Live Competition Running State
  const [isCompetitionRunning, setIsCompetitionRunning] = useState<boolean>(false);
  const [isCompetitionFinished, setIsCompetitionFinished] = useState<boolean>(false);
  const [participants, setParticipants] = useState<CompetitionParticipant[]>([]);
  const [currentTurnIndex, setCurrentTurnIndex] = useState<number>(0);
  const [doorsBoard, setDoorsBoard] = useState<CompetitionDoorQuestion[]>([]);
  const [activeDoor, setActiveDoor] = useState<CompetitionDoorQuestion | null>(null);
  const [hiddenOptionIndices, setHiddenOptionIndices] = useState<number[]>([]);
  const [chosenAnswerIdx, setChosenAnswerIdx] = useState<number | null>(null);
  const [isDoorAnswerRevealed, setIsDoorAnswerRevealed] = useState<boolean>(false);
  const [doorTimeLeft, setDoorTimeLeft] = useState<number>(30);
  const [isTimerPaused, setIsTimerPaused] = useState<boolean>(false);

  // Mystery Gift Box & Printable Voucher Modals
  const [pendingGiftReward, setPendingGiftReward] = useState<{
    studentName: string;
    studentGrade: string;
    studentId?: string;
    isOpened: boolean;
    gift: DigitalGiftItem;
  } | null>(null);
  const [previewGiftVoucher, setPreviewGiftVoucher] = useState<DigitalGiftItem | null>(null);

  const timerRef = useRef<number | null>(null);

  // Synthesized Web Audio sound effects
  const playSoundEffect = (type: 'flip' | 'tick' | 'correct' | 'wrong' | 'gift' | 'victory') => {
    if (!soundEnabled || typeof window === 'undefined') return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      const makeTone = (
        freq: number,
        start: number,
        duration: number,
        wave: OscillatorType = 'sine',
        gainVal = 0.08
      ) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = wave;
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(gainVal, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration);
      };

      if (type === 'flip') {
        makeTone(520, now, 0.08, 'triangle', 0.05);
      } else if (type === 'tick') {
        makeTone(800, now, 0.04, 'sine', 0.03);
      } else if (type === 'correct') {
        makeTone(523.25, now, 0.12, 'triangle', 0.1);
        makeTone(659.25, now + 0.1, 0.14, 'triangle', 0.1);
        makeTone(783.99, now + 0.2, 0.25, 'triangle', 0.12);
      } else if (type === 'wrong') {
        makeTone(240, now, 0.18, 'sawtooth', 0.08);
        makeTone(180, now + 0.16, 0.25, 'sawtooth', 0.08);
      } else if (type === 'gift') {
        makeTone(587.33, now, 0.1, 'sine', 0.1);
        makeTone(783.99, now + 0.1, 0.12, 'sine', 0.1);
        makeTone(987.77, now + 0.2, 0.14, 'sine', 0.1);
        makeTone(1174.66, now + 0.32, 0.3, 'triangle', 0.12);
      } else if (type === 'victory') {
        makeTone(523.25, now, 0.14, 'triangle', 0.12);
        makeTone(659.25, now + 0.14, 0.14, 'triangle', 0.12);
        makeTone(783.99, now + 0.28, 0.14, 'triangle', 0.12);
        makeTone(1046.5, now + 0.42, 0.4, 'triangle', 0.14);
      }
    } catch {
      // Ignore audio errors
    }
  };

  // Spaced repetition due cards count (cards answered wrong or marked hard/review that are not yet 100% mastered)
  const spacedRepetitionDueCount = useMemo(() => {
    return allDatabaseFlashcards.filter((card) => {
      const rec = spacedRepetitionMap[card.id];
      const localLevel = masteryMap[card.id];
      if (rec && rec.status === 'due_daily_until_mastered' && (rec.masteryPercent || 0) < 100) {
        return true;
      }
      if (localLevel === 'hard' || localLevel === 'review') {
        return true;
      }
      return false;
    }).length;
  }, [allDatabaseFlashcards, spacedRepetitionMap, masteryMap]);

  // Filtered Flashcards for the current view (100% from DB + Spaced Repetition support)
  const filteredFlashcards = useMemo(() => {
    let list = allDatabaseFlashcards.filter((item) => {
      const subjectMatch =
        selectedSubject === 'كل المواد' || item.subject === selectedSubject;
      const gradeMatch =
        selectedGrade === 'كل المراحل' ||
        item.grade === 'كل المراحل' ||
        item.grade === selectedGrade;
      const lessonMatch =
        selectedLessonFilter === 'all' || item.lessonId === selectedLessonFilter;

      if (onlySpacedReviewDue) {
        const rec = spacedRepetitionMap[item.id];
        const sm2 = sm2Map[item.id];
        const localLevel = masteryMap[item.id];
        const sm2Due = sm2 && sm2.nextReviewAt ? new Date(sm2.nextReviewAt).getTime() <= Date.now() : false;
        const isDue =
          sm2Due ||
          (rec && rec.status === 'due_daily_until_mastered' && (rec.masteryPercent || 0) < 100) ||
          localLevel === 'hard' ||
          localLevel === 'review';
        if (!isDue) return false;
      }

      if (activeMode === 'question_flashcards') {
        return (
          subjectMatch &&
          gradeMatch &&
          lessonMatch &&
          Boolean(item.options && item.options.length >= 2)
        );
      }
      return subjectMatch && gradeMatch && lessonMatch;
    });

    // Prioritize due / hard SM2 cards first
    list = [...list].sort((a, b) => {
      const sa = sm2Map[a.id];
      const sb = sm2Map[b.id];
      const ta = sa?.nextReviewAt ? new Date(sa.nextReviewAt).getTime() : 0;
      const tb = sb?.nextReviewAt ? new Date(sb.nextReviewAt).getTime() : 0;
      return ta - tb;
    });

    if (shuffledDeckSeed > 0) {
      list = shuffleArrayRandomly(list);
    }
    return list;
  }, [
    allDatabaseFlashcards,
    selectedSubject,
    selectedGrade,
    selectedLessonFilter,
    activeMode,
    shuffledDeckSeed,
    onlySpacedReviewDue,
    spacedRepetitionMap,
    sm2Map,
    masteryMap,
  ]);

  useEffect(() => {
    setCurrentCardIndex(0);
    setIsCardFlipped(false);
    setShowCardHint(false);
    setSelectedFlashcardOption(null);
  }, [selectedSubject, selectedGrade, selectedLessonFilter, activeMode, shuffledDeckSeed, onlySpacedReviewDue]);

  const currentFlashcard = filteredFlashcards[currentCardIndex] || null;

  const recordSpacedRepetitionOutcome = async (
    card: FlashcardItem,
    outcome: 'wrong' | 'hard' | 'review' | 'correct' | 'mastered'
  ) => {
    const stuKey = currentUser.studentId || currentUser.id || currentUser.name || 'default';
    try {
      const res = await fetch('/api/flashcards-competitions/spaced-repetition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentKey: stuKey,
          cardId: card.id,
          outcome,
          question: card.question,
          subject: card.subject,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.studentRecords) {
          setSpacedRepetitionMap(data.studentRecords);
        }
      }
    } catch {
      // ignore network error
    }
  };

  const handleMarkMastery = (cardId: string, level: 'mastered' | 'review' | 'hard') => {
    const next = { ...masteryMap, [cardId]: level };
    setMasteryMap(next);
    try {
      localStorage.setItem('sharif_flashcard_mastery_v2', JSON.stringify(next));
    } catch {
      // ignore
    }
    const stuKey = currentUser.studentId || currentUser.id || currentUser.name || 'default';
    const sm2Quality = level === 'mastered' ? 'easy' : level === 'review' ? 'medium' : 'hard';
    fetch('/api/flashcards/sm2/review', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId: stuKey, cardId, quality: sm2Quality }),
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.records) setSm2Map(d.records);
      })
      .catch(() => {});

    const targetCard = allDatabaseFlashcards.find((c) => c.id === cardId);
    if (targetCard) {
      recordSpacedRepetitionOutcome(targetCard, level);
    }
    if (level === 'hard') {
      setStatusBanner({
        type: 'warning',
        text: 'تمت جدولة هذه البطاقة الصعبة بخوارزمية SM2 لتظهر بوتيرة أسرع حتى يتم إتقانها 100%.',
      });
    } else if (level === 'mastered') {
      setStatusBanner({
        type: 'success',
        text: 'ممتاز! باعدت خوارزمية SM2 موعد مراجعة هذه البطاقة المتقنة تلقائياً.',
      });
    }
    if (currentCardIndex < filteredFlashcards.length - 1) {
      setIsCardFlipped(false);
      setShowCardHint(false);
      setSelectedFlashcardOption(null);
      setCurrentCardIndex((prev) => prev + 1);
    }
  };

  const handleSaveNewFlashcard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardQuestion.trim() || !newCardAnswer.trim()) return;

    const targetLesson = dbLessons.find((l) => l.id === newCardLessonId) || dbLessons[0];
    const subjectName = targetLesson?.subject || availableSubjects[0] || 'عام';
    const gradeName = targetLesson?.grade || 'كل المراحل';

    const rawOptions = [
      newCardAnswer.trim(),
      newCardDistractor1.trim() || 'خيار غير مطابق لشرح الدرس (1)',
      newCardDistractor2.trim() || 'خيار غير مطابق لشرح الدرس (2)',
      newCardDistractor3.trim() || 'خيار غير مطابق لشرح الدرس (3)',
    ];
    const shuffledOptions = shuffleArrayRandomly(rawOptions);

    const payload: FlashcardItem = {
      id: `fc-${Date.now()}`,
      subject: subjectName,
      grade: gradeName,
      lessonId: targetLesson?.id,
      lessonTitle: targetLesson?.title,
      category: 'teacher_db_card',
      question: newCardQuestion.trim(),
      answer: newCardAnswer.trim(),
      explanation:
        newCardExplanation.trim() ||
        `مرتبط بدرس «${targetLesson?.title || subjectName}» في قاعدة بيانات منصة الشريف.`,
      hint: targetLesson ? `من درس: ${targetLesson.title}` : undefined,
      options: shuffledOptions,
      correctOptionIndex: Math.max(0, shuffledOptions.indexOf(newCardAnswer.trim())),
      difficulty: 'medium',
      createdBy: currentUser.name,
      createdAt: new Date().toISOString().split('T')[0],
    };

    try {
      const res = await fetch('/api/flashcards-competitions/flashcards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const saved = await res.json();
        setCustomFlashcards((prev) => [saved, ...prev]);
      } else {
        setCustomFlashcards((prev) => [payload, ...prev]);
      }
      setIsAddCardModalOpen(false);
      setNewCardQuestion('');
      setNewCardAnswer('');
      setNewCardExplanation('');
      setNewCardDistractor1('');
      setNewCardDistractor2('');
      setNewCardDistractor3('');
      setStatusBanner({
        type: 'success',
        text: 'تم حفظ بطاقة الفلاش كارد في قاعدة بيانات منصة الشريف وربطها بالدرس بنجاح.',
      });
    } catch {
      setCustomFlashcards((prev) => [payload, ...prev]);
      setIsAddCardModalOpen(false);
    }
  };

  const handleDeleteCustomFlashcard = async (id: string) => {
    setCustomFlashcards((prev) => prev.filter((c) => c.id !== id));
    try {
      await fetch(`/api/flashcards-competitions/flashcards/${id}`, { method: 'DELETE' });
    } catch {
      // ignore
    }
  };

  // ============================================================================
  // AL-SHARIF COMPETITION LOGIC (100% REAL DATABASE LESSONS & REAL DB STUDENTS)
  // ============================================================================

  useEffect(() => {
    if (!activeDoor || isDoorAnswerRevealed || isTimerPaused) {
      if (timerRef.current) window.clearInterval(timerRef.current);
      return;
    }

    timerRef.current = window.setInterval(() => {
      setDoorTimeLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) window.clearInterval(timerRef.current);
          playSoundEffect('wrong');
          setIsDoorAnswerRevealed(true);
          return 0;
        }
        if (prev <= 6) {
          playSoundEffect('tick');
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [activeDoor, isDoorAnswerRevealed, isTimerPaused, soundEnabled]);

  const eligibleDbStudents = useMemo(() => {
    if (compGrade === 'كل المراحل') return dbStudents;
    const filtered = dbStudents.filter((s) => s.grade === compGrade);
    return filtered.length > 0 ? filtered : dbStudents;
  }, [dbStudents, compGrade]);

  const eligibleDbLessons = useMemo(() => {
    return dbLessons.filter((l) => {
      const subOk = compSubject === 'كل المواد' || l.subject === compSubject;
      const grdOk = compGrade === 'كل المراحل' || l.grade === compGrade;
      return subOk && grdOk;
    });
  }, [dbLessons, compSubject, compGrade]);

  const handleRandomSelectDbStudents = () => {
    if (eligibleDbStudents.length === 0) {
      setStatusBanner({
        type: 'warning',
        text: 'لا يوجد طلاب مسجلون في قاعدة البيانات حالياً. يرجى إضافة طلاب من قسم إدارة الطلاب أولاً.',
      });
      return;
    }
    const count = Math.min(eligibleDbStudents.length, Math.max(1, targetStudentsCount));
    const picked = shuffleArrayRandomly(eligibleDbStudents)
      .slice(0, count)
      .map((s) => s.id);
    setSelectedStudentIds(picked);
  };

  const handleLaunchCompetition = async () => {
    // 1. Verify we have real lessons in the database
    if (dbLessons.length === 0 && allDatabaseFlashcards.length === 0) {
      setStatusBanner({
        type: 'error',
        text: 'لا توجد دروس مسجلة في قاعدة البيانات بعد لتوليد أسئلة المسابقة منها.',
      });
      return;
    }

    // 2. Verify we have real students in the database
    if (dbStudents.length === 0) {
      setStatusBanner({
        type: 'error',
        text: 'لا يوجد طلاب مسجلون في قاعدة البيانات بعد لبدء المسابقة بينهم.',
      });
      return;
    }

    const desiredStudentsCount = Math.max(
      1,
      Math.min(dbStudents.length, Number(targetStudentsCount) || 2)
    );

    let chosenStudents: Student[] = [];
    if (selectedStudentIds.length > 0) {
      chosenStudents = dbStudents
        .filter((s) => selectedStudentIds.includes(s.id))
        .slice(0, desiredStudentsCount);
    }

    if (chosenStudents.length < desiredStudentsCount) {
      const remainingDbPool = shuffleArrayRandomly(
        eligibleDbStudents.filter((s) => !chosenStudents.some((c) => c.id === s.id))
      );
      for (const stu of remainingDbPool) {
        if (chosenStudents.length >= desiredStudentsCount) break;
        chosenStudents.push(stu);
      }
    }

    if (chosenStudents.length < desiredStudentsCount) {
      const anyRemaining = shuffleArrayRandomly(
        dbStudents.filter((s) => !chosenStudents.some((c) => c.id === s.id))
      );
      for (const stu of anyRemaining) {
        if (chosenStudents.length >= desiredStudentsCount) break;
        chosenStudents.push(stu);
      }
    }

    const randomizedParticipants: CompetitionParticipant[] = shuffleArrayRandomly(
      chosenStudents
    ).map((s) => ({
      id: s.id,
      name: s.name,
      grade: s.grade,
      code: s.code,
      score: 0,
      correctCount: 0,
      wrongCount: 0,
      streak: 0,
      giftsWon: [],
      lifelines: { fiftyFifty: true, extraTime: true, swapQuestion: true },
    }));

    // 3. Request fresh DB-extracted questions from backend for selected lessons + merge with allDatabaseFlashcards
    let freshServerQuestions: FlashcardItem[] = [];
    try {
      const targetIds =
        compSelectedLessonIds.length > 0
          ? compSelectedLessonIds
          : eligibleDbLessons.map((l) => l.id);

      const res = await fetch('/api/flashcards-competitions/extract-from-lessons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lessonIds: targetIds,
          count: Math.max(targetQuestionsCount, 20),
          questionMix: 'mixed',
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data?.questions)) {
          freshServerQuestions = data.questions.map((q: any, idx: number) => {
            const matchedLesson = dbLessons.find((l) => l.id === q.sourceLessonId);
            return {
              id: `srv-comp-q-${q.id || idx}-${Date.now()}`,
              subject: matchedLesson?.subject || compSubject,
              grade: matchedLesson?.grade || compGrade,
              lessonId: q.sourceLessonId,
              lessonTitle: q.sourceLessonTitle || matchedLesson?.title,
              category: 'lesson_derived' as const,
              question: q.question,
              answer: q.options?.[q.correctOptionIndex ?? 0] || '',
              explanation: q.explanation || '',
              options: Array.isArray(q.options) ? q.options : [],
              correctOptionIndex: q.correctOptionIndex ?? 0,
              difficulty: 'medium' as const,
            };
          });
        }
      }
    } catch {
      // Fall back to already-loaded allDatabaseFlashcards from DB
    }

    const filteredLocalPool = allDatabaseFlashcards.filter((fc) => {
      if (compSelectedLessonIds.length > 0 && fc.lessonId) {
        return compSelectedLessonIds.includes(fc.lessonId);
      }
      const subOk = compSubject === 'كل المواد' || fc.subject === compSubject;
      const grdOk =
        compGrade === 'كل المراحل' || fc.grade === 'كل المراحل' || fc.grade === compGrade;
      return subOk && grdOk;
    });

    const combinedRealPool = [
      ...freshServerQuestions,
      ...(filteredLocalPool.length > 0 ? filteredLocalPool : allDatabaseFlashcards),
    ].filter((q) => Array.isArray(q.options) && q.options.length >= 2);

    if (combinedRealPool.length === 0) {
      setStatusBanner({
        type: 'error',
        text: 'لم يتم العثور على أسئلة مستخرجة من الدروس المحددة في قاعدة البيانات.',
      });
      return;
    }

    // Deduplicate by question text and shuffle completely without order
    const uniqueMap = new Map<string, FlashcardItem>();
    combinedRealPool.forEach((item) => {
      if (!uniqueMap.has(item.question)) {
        uniqueMap.set(item.question, item);
      }
    });

    const uniqueQuestions = shuffleArrayRandomly(Array.from(uniqueMap.values()));
    const desiredQuestionsCount = Math.max(
      1,
      Math.min(30, Number(targetQuestionsCount) || 10)
    );

    let finalQuestionsList: FlashcardItem[] = [];
    while (finalQuestionsList.length < desiredQuestionsCount) {
      finalQuestionsList = [
        ...finalQuestionsList,
        ...shuffleArrayRandomly(uniqueQuestions),
      ];
    }
    finalQuestionsList = finalQuestionsList.slice(0, desiredQuestionsCount);

    // Randomize option order inside each door question as well
    const generatedDoors: CompetitionDoorQuestion[] = finalQuestionsList.map((q, index) => {
      const rawOptions = q.options;
      const correctText = rawOptions[q.correctOptionIndex ?? 0] ?? rawOptions[0];
      const shuffledOpts = shuffleArrayRandomly(rawOptions);
      const newCorrectIndex = Math.max(0, shuffledOpts.indexOf(correctText));

      const pointTiers = [100, 150, 200];
      const points = pointTiers[index % pointTiers.length];
      const hasMysteryGift = index % 3 === 0 || index === desiredQuestionsCount - 1;

      return {
        doorNumber: index + 1,
        questionId: `${q.id}-door-${index + 1}`,
        subject: q.subject,
        sourceLessonTitle: q.lessonTitle,
        questionText: q.question,
        options: shuffledOpts,
        correctOptionIndex: newCorrectIndex,
        explanation: q.explanation || q.answer,
        points,
        hasMysteryGift,
        isOpened: false,
      };
    });

    setParticipants(randomizedParticipants);
    setDoorsBoard(generatedDoors);
    setCurrentTurnIndex(0);
    setActiveDoor(null);
    setIsCompetitionFinished(false);
    setIsCompetitionRunning(true);
    playSoundEffect('flip');
  };

  const handleOpenDoor = (door: CompetitionDoorQuestion) => {
    if (door.isOpened || activeDoor) return;
    setActiveDoor(door);
    setHiddenOptionIndices([]);
    setChosenAnswerIdx(null);
    setIsDoorAnswerRevealed(false);
    setIsTimerPaused(false);
    setDoorTimeLeft(timerSecondsPerQuestion);
    playSoundEffect('flip');
  };

  const handlePickRandomAvailableDoor = () => {
    const available = doorsBoard.filter((d) => !d.isOpened);
    if (available.length === 0) return;
    const picked = shuffleArrayRandomly(available)[0];
    handleOpenDoor(picked);
  };

  const handleUseFiftyFifty = () => {
    if (!activeDoor || isDoorAnswerRevealed) return;
    const currentStu = participants[currentTurnIndex];
    if (!currentStu?.lifelines.fiftyFifty) return;

    const wrongIndices = activeDoor.options
      .map((_, idx) => idx)
      .filter((idx) => idx !== activeDoor.correctOptionIndex);
    const toHide = shuffleArrayRandomly(wrongIndices).slice(0, Math.min(2, wrongIndices.length));
    setHiddenOptionIndices(toHide);

    setParticipants((prev) =>
      prev.map((p, idx) =>
        idx === currentTurnIndex
          ? { ...p, lifelines: { ...p.lifelines, fiftyFifty: false } }
          : p
      )
    );
  };

  const handleUseExtraTime = () => {
    if (!activeDoor || isDoorAnswerRevealed) return;
    const currentStu = participants[currentTurnIndex];
    if (!currentStu?.lifelines.extraTime) return;

    setDoorTimeLeft((prev) => prev + 15);
    setParticipants((prev) =>
      prev.map((p, idx) =>
        idx === currentTurnIndex
          ? { ...p, lifelines: { ...p.lifelines, extraTime: false } }
          : p
      )
    );
  };

  const handleUseSwapQuestion = () => {
    if (!activeDoor || isDoorAnswerRevealed) return;
    const currentStu = participants[currentTurnIndex];
    if (!currentStu?.lifelines.swapQuestion) return;

    const usedQuestions = new Set(doorsBoard.map((d) => d.questionText));
    const freshCandidates = shuffleArrayRandomly(
      allDatabaseFlashcards.filter(
        (fc) =>
          Array.isArray(fc.options) &&
          fc.options.length >= 2 &&
          !usedQuestions.has(fc.question)
      )
    );
    const replacement =
      freshCandidates[0] || shuffleArrayRandomly(allDatabaseFlashcards)[0];
    if (!replacement) return;

    const rawOpts = replacement.options;
    const correctTxt = rawOpts[replacement.correctOptionIndex ?? 0] ?? rawOpts[0];
    const shuffledOpts = shuffleArrayRandomly(rawOpts);

    const updatedDoor: CompetitionDoorQuestion = {
      ...activeDoor,
      subject: replacement.subject,
      sourceLessonTitle: replacement.lessonTitle,
      questionText: replacement.question,
      options: shuffledOpts,
      correctOptionIndex: Math.max(0, shuffledOpts.indexOf(correctTxt)),
      explanation: replacement.explanation || replacement.answer,
    };

    setActiveDoor(updatedDoor);
    setDoorsBoard((prev) =>
      prev.map((d) => (d.doorNumber === updatedDoor.doorNumber ? updatedDoor : d))
    );
    setHiddenOptionIndices([]);
    setDoorTimeLeft(timerSecondsPerQuestion);

    setParticipants((prev) =>
      prev.map((p, idx) =>
        idx === currentTurnIndex
          ? { ...p, lifelines: { ...p.lifelines, swapQuestion: false } }
          : p
      )
    );
  };

  const awardDigitalGiftToStudent = async (
    stu: CompetitionParticipant,
    subjectName: string
  ): Promise<DigitalGiftItem> => {
    const template = shuffleArrayRandomly(DIGITAL_GIFT_CATALOG)[0];
    const giftItem: DigitalGiftItem = {
      id: `gift-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      studentId: stu.id,
      studentName: stu.name,
      studentGrade: stu.grade,
      giftTitle: template.giftTitle,
      giftTitleEn: template.giftTitleEn,
      giftType: template.giftType,
      pointsValue: template.pointsValue,
      badgeLabel: template.badgeLabel,
      description: template.description,
      subject: subjectName,
      competitionTitle: compTitle,
      awardedBy: currentUser.name,
      serialCode: `SHARIF-${Math.floor(100000 + Math.random() * 900000)}`,
      awardedAt: new Date().toLocaleDateString('ar-EG', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      }),
    };

    setDigitalGifts((prev) => [giftItem, ...prev]);
    try {
      await fetch('/api/flashcards-competitions/gifts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(giftItem),
      });
    } catch {
      // ignore
    }
    return giftItem;
  };

  const handleSelectDoorOption = async (optIndex: number) => {
    if (!activeDoor || isDoorAnswerRevealed) return;
    if (timerRef.current) window.clearInterval(timerRef.current);

    setChosenAnswerIdx(optIndex);
    setIsDoorAnswerRevealed(true);

    const isCorrect = optIndex === activeDoor.correctOptionIndex;
    const currentStu = participants[currentTurnIndex];
    const speedBonus =
      isCorrect && doorTimeLeft >= Math.floor(timerSecondsPerQuestion * 0.6) ? 30 : 0;
    const earnedPoints = isCorrect ? activeDoor.points + speedBonus : 0;

    if (isCorrect) {
      playSoundEffect('correct');
      try {
        confetti({ particleCount: 55, spread: 65, origin: { y: 0.65 } });
      } catch {
        // ignore
      }
    } else {
      playSoundEffect('wrong');
      if (currentStu?.id) {
        fetch('/api/mistake-notebook/record', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
          body: JSON.stringify({
            studentId: currentStu.id,
            studentName: currentStu.name,
            mistakes: [
              {
                questionId: activeDoor.questionId,
                question: activeDoor.questionText,
                options: activeDoor.options,
                correctOptionIndex: activeDoor.correctOptionIndex,
                selectedOptionIndex: optIndex,
                explanation: activeDoor.explanation,
                subject: activeDoor.subject,
                sourceType: 'competition',
                quizId: `door-${activeDoor.doorNumber}`,
                quizTitle: compTitle || 'مسابقة الشريف التفاعلية',
              },
            ],
          }),
        }).catch(() => {});
      }
    }

    let wonGift: DigitalGiftItem | null = null;
    if (isCorrect && (activeDoor.hasMysteryGift || (currentStu && currentStu.streak + 1 >= 2))) {
      wonGift = await awardDigitalGiftToStudent(currentStu, activeDoor.subject);
    }

    setParticipants((prev) =>
      prev.map((p, idx) => {
        if (idx !== currentTurnIndex) return p;
        return {
          ...p,
          score: p.score + earnedPoints + (wonGift ? 50 : 0),
          correctCount: isCorrect ? p.correctCount + 1 : p.correctCount,
          wrongCount: !isCorrect ? p.wrongCount + 1 : p.wrongCount,
          streak: isCorrect ? p.streak + 1 : 0,
          giftsWon: wonGift ? [wonGift, ...p.giftsWon] : p.giftsWon,
        };
      })
    );

    setDoorsBoard((prev) =>
      prev.map((d) =>
        d.doorNumber === activeDoor.doorNumber
          ? {
              ...d,
              isOpened: true,
              answeredByStudentName: currentStu?.name,
              wasCorrect: isCorrect,
            }
          : d
      )
    );

    if (wonGift && currentStu) {
      setPendingGiftReward({
        studentName: currentStu.name,
        studentGrade: currentStu.grade,
        studentId: currentStu.id,
        isOpened: false,
        gift: wonGift,
      });
    }
  };

  const handleCloseDoorAndAdvanceTurn = async () => {
    setActiveDoor(null);
    const remainingDoors = doorsBoard.filter((d) => !d.isOpened);
    if (remainingDoors.length === 0) {
      await handleFinishCompetition();
      return;
    }
    setCurrentTurnIndex((prev) => (prev + 1) % participants.length);
  };

  const handleFinishCompetition = async () => {
    setActiveDoor(null);
    setIsCompetitionFinished(true);
    playSoundEffect('victory');
    try {
      confetti({ particleCount: 110, spread: 80, origin: { y: 0.55 } });
    } catch {
      // ignore
    }

    const sorted = [...participants].sort((a, b) => b.score - a.score);
    const topWinner = sorted[0];

    if (topWinner) {
      await awardDigitalGiftToStudent(topWinner, compSubject);
    }

    const historyRecord: CompetitionHistoryRecord = {
      id: `comp-${Date.now()}`,
      title: compTitle,
      mode: compStyle,
      subject: compSubject,
      grade: compGrade,
      studentsCount: participants.length,
      questionsCount: doorsBoard.length,
      winnerName: topWinner?.name || 'متسابق',
      winnerScore: topWinner?.score || 0,
      participants: sorted.map((p) => ({
        name: p.name,
        score: p.score,
        correctCount: p.correctCount,
        giftsCount: p.giftsWon.length,
      })),
      completedAt: new Date().toLocaleString('ar-EG', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setCompetitionHistory((prev) => [historyRecord, ...prev]);
    try {
      await fetch('/api/flashcards-competitions/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(historyRecord),
      });
    } catch {
      // ignore
    }
  };

  const masteredCount = useMemo(
    () => Object.values(masteryMap).filter((v) => v === 'mastered').length,
    [masteryMap]
  );

  // =========================================================================
  // 5. LIVE CHALLENGE ROOMS (1v1 / TEAMS) & WEEKLY LEAGUE HANDLERS
  // =========================================================================
  const activeChallengeRoom = useMemo(
    () =>
      liveChallengeRooms.find((r) => r.id === activeChallengeRoomId) ||
      liveChallengeRooms[0] ||
      null,
    [liveChallengeRooms, activeChallengeRoomId]
  );

  const handleCreateChallengeRoom = async () => {
    const pool = allDatabaseFlashcards.filter((fc) => {
      if (roomSubject !== 'كل المواد' && fc.subject !== roomSubject) return false;
      return true;
    });

    if (pool.length === 0) {
      setStatusBanner({
        type: 'error',
        text: 'لا توجد أسئلة مطابقة في قاعدة البيانات لإنشاء غرفة التحدي المباشر.',
      });
      return;
    }

    const defaultSideA =
      sideAStudentName.trim() ||
      (dbStudents[0]?.name ? dbStudents[0].name : currentUser.name || 'متسابق 1');
    const defaultSideB =
      sideBStudentName.trim() ||
      (dbStudents[1]?.name ? dbStudents[1].name : 'متحدي منصة الشريف 2');

    const selectedQuestions = shuffleArrayRandomly(pool)
      .slice(0, Math.min(pool.length, Math.max(2, roomQuestionsCount)))
      .map((q) => ({
        id: q.id,
        question: q.question,
        options:
          q.options && q.options.length >= 2
            ? q.options
            : [q.answer, 'إجابة بديلة 1', 'إجابة بديلة 2', 'إجابة بديلة 3'],
        correctOptionIndex: q.correctOptionIndex ?? 0,
        answer: q.answer,
        explanation: q.explanation,
        points: 100,
        subject: q.subject,
        lessonTitle: q.lessonTitle || q.subject,
      }));

    try {
      const res = await fetch('/api/flashcards-competitions/challenge-rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: roomTitle.trim() || 'تحدي الشريف المباشر (الأسرع ×2)',
          mode: roomMode,
          subject: roomSubject,
          grade: 'كل الصفوف',
          sideAName: defaultSideA,
          sideBName: defaultSideB,
          sideAMembers: [defaultSideA],
          sideBMembers: [defaultSideB],
          questions: selectedQuestions,
        }),
      });
      const data = await res.json();
      if (data?.ok && data.room) {
        setLiveChallengeRooms((prev) => [
          data.room,
          ...prev.filter((r) => r.id !== data.room.id),
        ]);
        setActiveChallengeRoomId(data.room.id);
        playSoundEffect('flip');
        setStatusBanner({
          type: 'success',
          text: `تم إنشاء غرفة التحدي المباشر «${data.room.title}» بنجاح! الأسرع في الإجابة الصحيحة يحصل على نقاط مضاعفة (×2).`,
        });
      }
    } catch {
      setStatusBanner({
        type: 'error',
        text: 'تعذر إنشاء غرفة التحدي المباشر.',
      });
    }
  };

  const handleSubmitChallengeAnswer = async (
    roomId: string,
    side: 'A' | 'B',
    selectedOptionIndex: number,
    playerName: string
  ) => {
    try {
      const res = await fetch(`/api/flashcards-competitions/challenge-rooms/${roomId}/answer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          side,
          selectedOptionIndex,
          playerName,
        }),
      });
      const data = await res.json();
      if (data?.ok && data.room) {
        setLiveChallengeRooms((prev) =>
          prev.map((r) => (r.id === data.room.id ? data.room : r))
        );
        if (Array.isArray(data.weeklyLeague)) {
          setWeeklyLeague(data.weeklyLeague);
        }
        if (data.isCorrect) {
          playSoundEffect('victory');
          setStatusBanner({
            type: 'success',
            text: data.fastestBonusApplied
              ? `⚡ إجابة صحيحة وسريعة! حصل ${playerName} على نقاط مضاعفة (×2) = +${data.pointsEarned} نقطة وتم تحديث الدوري الأسبوعي!`
              : `✓ إجابة صحيحة! +${data.pointsEarned} نقطة.`,
          });
        } else {
          playSoundEffect('wrong');
          setStatusBanner({
            type: 'error',
            text: `إجابة غير صحيحة من ${playerName} — الفرصة متاحة للطرف الآخر للإجابة وحصد النقاط المضاعفة!`,
          });
        }
      }
    } catch {
      // ignore
    }
  };

  const handleNextChallengeQuestion = async (roomId: string) => {
    try {
      const res = await fetch(`/api/flashcards-competitions/challenge-rooms/${roomId}/next`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data?.ok && data.room) {
        setLiveChallengeRooms((prev) =>
          prev.map((r) => (r.id === data.room.id ? data.room : r))
        );
        playSoundEffect('flip');
      }
    } catch {
      // ignore
    }
  };

  const handleDeleteChallengeRoom = async (roomId: string) => {
    try {
      await fetch(`/api/flashcards-competitions/challenge-rooms/${roomId}`, {
        method: 'DELETE',
      });
      setLiveChallengeRooms((prev) => prev.filter((r) => r.id !== roomId));
      if (activeChallengeRoomId === roomId) {
        setActiveChallengeRoomId(null);
      }
    } catch {
      // ignore
    }
  };

  // =========================================================================
  // 6. AL-SHARIF REWARDS STORE (استبدال النقاط) CALCULATIONS & HANDLERS
  // =========================================================================
  const effectiveStoreStudentName = useMemo(() => {
    if (selectedStoreStudentName.trim()) return selectedStoreStudentName.trim();
    if (isStudent && currentUser.name) return currentUser.name;
    if (dbStudents.length > 0) return dbStudents[0].name;
    return currentUser.name || 'طالب منصة الشريف';
  }, [selectedStoreStudentName, isStudent, currentUser.name, dbStudents]);

  const effectiveStoreStudentObj = useMemo(
    () =>
      dbStudents.find((s) => s.name === effectiveStoreStudentName) ||
      dbStudents[0] ||
      null,
    [dbStudents, effectiveStoreStudentName]
  );

  const studentPointsSummary = useMemo(() => {
    const stuName = effectiveStoreStudentName;
    // 1. Points from Digital Gifts won in Al-Sharif Competition
    const giftsPoints = digitalGifts
      .filter((g) => g.studentName === stuName)
      .reduce((acc, g) => acc + (Number(g.pointsValue) || 0), 0);

    // 2. Points from Competition History matches
    const historyPoints = competitionHistory.reduce((acc, h) => {
      const p = (h.participants || []).find((part) => part.name === stuName);
      return acc + (p ? Number(p.score) || 0 : 0);
    }, 0);

    // 3. Points from Weekly League / Live 1v1 & Team Challenges
    const leagueEntry = weeklyLeague.find((w) => w.studentName === stuName);
    const leaguePoints = leagueEntry ? Number(leagueEntry.points) || 0 : 0;

    // 4. Points from Attendance Commitment + Mastered Spaced Repetition Cards + Admin Bonus
    const masteredSpacedCount = Object.values(spacedRepetitionMap).filter(
      (r: any) => Number(r?.masteryPercent || 0) >= 100
    ).length;
    const attendanceAndBonus =
      (Number(bonusPointsMap[stuName]) || 0) +
      masteredSpacedCount * 25 +
      (effectiveStoreStudentObj ? 150 : 100);

    const totalEarned = giftsPoints + historyPoints + leaguePoints + attendanceAndBonus;

    const totalSpent = storeRedemptions
      .filter((r) => r.studentName === stuName)
      .reduce((acc, r) => acc + (Number(r.costPoints) || 0), 0);

    const availableBalance = Math.max(0, totalEarned - totalSpent);

    return {
      giftsPoints,
      historyPoints,
      leaguePoints,
      attendanceAndBonus,
      totalEarned,
      totalSpent,
      availableBalance,
    };
  }, [
    effectiveStoreStudentName,
    effectiveStoreStudentObj,
    digitalGifts,
    competitionHistory,
    weeklyLeague,
    spacedRepetitionMap,
    bonusPointsMap,
    storeRedemptions,
  ]);

  const handleRedeemStoreReward = async (reward: any) => {
    if (studentPointsSummary.availableBalance < reward.costPoints) {
      setStatusBanner({
        type: 'error',
        text: `رصيد النقاط المتاح للطالب (${studentPointsSummary.availableBalance} نقطة) غير كافٍ لاستبدال «${reward.title}» (${reward.costPoints} نقطة).`,
      });
      return;
    }

    const targetLesson =
      dbLessons.find((l) => l.id === selectedUnlockLessonId) || dbLessons[0] || null;

    try {
      const res = await fetch('/api/flashcards-competitions/store/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: effectiveStoreStudentObj?.id || currentUser.studentId || currentUser.id,
          studentName: effectiveStoreStudentName,
          studentGrade: effectiveStoreStudentObj?.grade || 'عام',
          rewardId: reward.id,
          rewardTitle: reward.title,
          rewardType: reward.rewardType,
          costPoints: reward.costPoints,
          badgeIcon: reward.badgeLabel,
          targetLessonId: targetLesson?.id || '',
          targetLessonTitle: targetLesson?.title || 'درس مجاني من اختيارك',
        }),
      });
      const data = await res.json();
      if (data?.ok && data.redemption) {
        setStoreRedemptions((prev) => [
          data.redemption,
          ...prev.filter((r) => r.id !== data.redemption.id),
        ]);
        if (data.studentBadges) {
          setStudentBadges(data.studentBadges);
        }
        playSoundEffect('victory');
        setStatusBanner({
          type: 'success',
          text: `🎉 مبروك! تم استبدال ${reward.costPoints} نقطة بـ «${reward.title}» للطالب ${effectiveStoreStudentName} — الكود/المرجع: ${data.redemption.generatedCode}`,
        });
      }
    } catch {
      setStatusBanner({
        type: 'error',
        text: 'حدث خطأ أثناء استبدال المكافأة من متجر منصة الشريف.',
      });
    }
  };

  const handleGrantBonusPoints = async (pointsToAdd: number, reason: string) => {
    try {
      const res = await fetch('/api/flashcards-competitions/store/bonus-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: effectiveStoreStudentName,
          points: pointsToAdd,
          reason,
        }),
      });
      const data = await res.json();
      if (data?.ok && data.bonusPointsMap) {
        setBonusPointsMap(data.bonusPointsMap);
        playSoundEffect('correct');
        setStatusBanner({
          type: 'success',
          text: `تم منح +${pointsToAdd} نقطة تشجيعية (${reason}) للطالب ${effectiveStoreStudentName}!`,
        });
      }
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6 font-cairo">
      {/* Top Executive Header */}
      <div className="relative rounded-2xl bg-slate-900 text-white p-6 md:p-8 border border-slate-800 shadow-xl overflow-hidden">
        <AlSharifWatermark extraLabel="الفلاش كارد ومسابقة الشريف التفاعلية" opacity="light" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs text-amber-400 font-bold">
              <Database className="w-4 h-4 shrink-0" />
              <span>منصة الشريف التعليمية</span>
              <span aria-hidden="true">·</span>
              <span>مرتبط 100% بالدروس والطلاب المسجلين في قاعدة البيانات</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white">
              {isAr
                ? 'الفلاش كارد الشامل ومسابقة الشريف التفاعلية'
                : 'Al-Sharif Database Flashcards & Interactive Competition'}
            </h1>
            <p className="text-xs md:text-sm text-slate-300 font-tajawal leading-relaxed">
              {isAr
                ? 'توليد مباشر لبطاقات الفلاش كارد والأسئلة العشوائية من الدروس المسجلة في قاعدة بيانات منصة الشريف فقط بدون أي بيانات وهمية، مع نظام مسابقة الشريف بالتايمر والأبواب المرقمة والهدايا الإلكترونية الرقمية التشجيعية.'
                : '100% database-driven flashcards and randomized competition questions extracted directly from Al-Sharif Platform lessons with countdown timers and digital rewards.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => syncFromDatabase(true)}
              disabled={isSyncingDb}
              className="px-3.5 py-2 rounded-xl bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 border border-emerald-600/50 text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncingDb ? 'animate-spin' : ''}`} />
              <span>مزامنة الدروس من قاعدة البيانات</span>
            </button>

            <button
              type="button"
              onClick={() => setSoundEnabled((prev) => !prev)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
              <span>{soundEnabled ? 'الصوت: مفعل' : 'الصوت: صامت'}</span>
            </button>

            {canManage && (
              <button
                type="button"
                onClick={() => {
                  if (dbLessons.length > 0 && !newCardLessonId) {
                    setNewCardLessonId(dbLessons[0].id);
                  }
                  setIsAddCardModalOpen(true);
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-sm transition-colors whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة بطاقة فلاش كارد لدرس</span>
              </button>
            )}
          </div>
        </div>

        {/* Summary KPI Strip strictly from Database */}
        <div className="relative z-10 mt-6 pt-5 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-slate-400 block font-tajawal">الدروس المسجلة في القاعدة</span>
            <strong className="text-lg md:text-xl font-black text-white font-mono-numbers tabular-nums">
              {dbLessons.length} درساً
            </strong>
          </div>
          <div>
            <span className="text-slate-400 block font-tajawal">بطاقات وأسئلة مستخرجة من الدروس</span>
            <strong className="text-lg md:text-xl font-black text-emerald-400 font-mono-numbers tabular-nums">
              {allDatabaseFlashcards.length} بطاقة وسؤال
            </strong>
          </div>
          <div>
            <span className="text-slate-400 block font-tajawal">الطلاب المسجلون في القاعدة</span>
            <strong className="text-lg md:text-xl font-black text-amber-400 font-mono-numbers tabular-nums">
              {dbStudents.length} طالباً
            </strong>
          </div>
          <div>
            <span className="text-slate-400 block font-tajawal">هدايا منصة الشريف الرقمية</span>
            <strong className="text-lg md:text-xl font-black text-sky-400 font-mono-numbers tabular-nums">
              {digitalGifts.length} هدية إلكترونية
            </strong>
          </div>
        </div>
      </div>

      {statusBanner && (
        <div
          className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 text-xs font-bold ${
            statusBanner.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
              : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{statusBanner.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusBanner(null)}
            className="p-1 rounded-lg hover:bg-black/5"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Mode Switcher Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <button
          type="button"
          onClick={() => setActiveMode('sharif_competition')}
          className={`flex-1 min-w-[200px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'sharif_competition'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Trophy className="w-4 h-4 shrink-0" />
          <span>مسابقة الشريف التفاعلية (من دروس قاعدة البيانات)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMode('subject_flashcards')}
          className={`flex-1 min-w-[180px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'subject_flashcards'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4 shrink-0" />
          <span>فلاش كارد المواد والدروس ({allDatabaseFlashcards.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMode('question_flashcards')}
          className={`flex-1 min-w-[180px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'question_flashcards'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4 shrink-0" />
          <span>نظام فلاش كارد للأسئلة</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMode('digital_gifts_vault')}
          className={`flex-1 min-w-[160px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'digital_gifts_vault'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Gift className="w-4 h-4 shrink-0" />
          <span>خزينة الهدايا ({digitalGifts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMode('live_challenge_rooms')}
          className={`flex-1 min-w-[200px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'live_challenge_rooms'
              ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Zap className="w-4 h-4 shrink-0" />
          <span>غرف التحدي المباشر (1 ضد 1 أو فرق) والدوري الأسبوعي</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMode('class_challenges')}
          className={`flex-1 min-w-[180px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'class_challenges'
              ? 'bg-emerald-700 text-white font-black shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Crown className="w-4 h-4 shrink-0" />
          <span>تحديات الصف الأسبوعية ({classChallenges.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMode('rewards_store')}
          className={`flex-1 min-w-[180px] px-4 py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
            activeMode === 'rewards_store'
              ? 'bg-purple-700 text-white font-black shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <ShoppingBag className="w-4 h-4 shrink-0" />
          <span>متجر جوائز منصة الشريف (استبدال النقاط)</span>
        </button>
      </div>

      {/* ======================================================================= */}
      {/* TAB 1 & 2: DATABASE SUBJECT FLASHCARDS & QUESTION FLASHCARDS SYSTEM     */}
      {/* ======================================================================= */}
      {(activeMode === 'subject_flashcards' || activeMode === 'question_flashcards') && (
        <div className="space-y-6">
          {/* Subject & Lesson Filter Bar derived strictly from DB */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                {['كل المواد', ...availableSubjects].map((subj) => (
                  <button
                    key={subj}
                    type="button"
                    onClick={() => {
                      setSelectedSubject(subj);
                      setSelectedLessonFilter('all');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
                      selectedSubject === subj
                        ? 'bg-slate-900 dark:bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {subj}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={selectedLessonFilter}
                  onChange={(e) => setSelectedLessonFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                >
                  <option value="all">كل الدروس المسجلة في القاعدة ({dbLessons.length})</option>
                  {dbLessons
                    .filter((l) => selectedSubject === 'كل المواد' || l.subject === selectedSubject)
                    .map((les) => (
                      <option key={les.id} value={les.id}>
                        درس: {les.title} ({les.subject})
                      </option>
                    ))}
                </select>

                <select
                  value={selectedGrade}
                  onChange={(e) => setSelectedGrade(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                >
                  {availableGrades.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => {
                    setShuffledDeckSeed((s) => s + 1);
                    playSoundEffect('flip');
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-800 dark:text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap"
                >
                  <Shuffle className="w-3.5 h-3.5" />
                  <span>خلط عشوائي للبطاقات</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setOnlySpacedReviewDue((prev) => !prev);
                    setCurrentCardIndex(0);
                  }}
                  className={`px-3.5 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                    onlySpacedReviewDue
                      ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                      : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800 hover:bg-rose-100'
                  }`}
                >
                  <Brain className="w-3.5 h-3.5" />
                  <span>
                    نظام المراجعة الذكية (Spaced Repetition): {spacedRepetitionDueCount} بطاقة مستحقة
                  </span>
                </button>
              </div>
            </div>

            {/* Spaced Repetition Smart Banner */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300 font-tajawal">
                <Brain className="w-4 h-4 text-rose-500 shrink-0" />
                <span>
                  <strong>نظام المراجعة الذكية (Spaced Repetition):</strong> البطاقات التي تخطئ فيها أو تصنفها «صعبة» تتكرر تلقائياً في جدول مراجعة اليوم التالي حتى تتقنها بنسبة <strong>100%</strong>.
                </span>
              </div>
              {onlySpacedReviewDue && (
                <span className="px-2.5 py-1 rounded-md bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 font-bold">
                  يتم الآن عرض بطاقات المراجعة الذكية غير المتقنة فقط ({filteredFlashcards.length})
                </span>
              )}
            </div>
          </div>

          {currentFlashcard ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Main Interactive Flashcard Deck (8 cols) */}
              <div className="lg:col-span-8 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex flex-wrap items-center gap-2 font-bold">
                    <span className="text-emerald-700 dark:text-emerald-400">
                      {currentFlashcard.subject}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{currentFlashcard.grade}</span>
                    {currentFlashcard.lessonTitle && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-700 dark:text-slate-300">
                          الدرس: {currentFlashcard.lessonTitle}
                        </span>
                      </>
                    )}
                  </div>
                  <span className="font-mono-numbers font-bold tabular-nums">
                    بطاقة {currentCardIndex + 1} من {filteredFlashcards.length} (متقن: {masteredCount})
                  </span>
                </div>

                {/* Flashcard Surface */}
                <div className="relative rounded-2xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-lg p-6 md:p-8 min-h-[360px] flex flex-col justify-between overflow-hidden">
                  <AlSharifWatermark
                    extraLabel={currentFlashcard.lessonTitle || currentFlashcard.subject}
                    opacity="light"
                  />

                  <div className="relative z-10 flex items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                      {!isCardFlipped
                        ? 'وجه البطاقة: السؤال المستخرج من الدرس'
                        : 'ظهر البطاقة: الإجابة النموذجية والشرح من الدرس'}
                    </span>

                    <div className="flex items-center gap-2">
                      {currentFlashcard.hint && !isCardFlipped && (
                        <button
                          type="button"
                          onClick={() => setShowCardHint((prev) => !prev)}
                          className="px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-xs font-bold flex items-center gap-1"
                        >
                          <Lightbulb className="w-3.5 h-3.5" />
                          <span>تلميح</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          setIsCardFlipped((prev) => !prev);
                          playSoundEffect('flip');
                        }}
                        className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                        <span>{isCardFlipped ? 'عرض السؤال' : 'اقلب البطاقة للإجابة'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Card Middle Content */}
                  <div className="relative z-10 py-6 space-y-5 my-auto">
                    {!isCardFlipped ? (
                      <>
                        <div className={MCQ_QUESTION_BOX_CLASS}>
                          <h2 className="text-lg md:text-2xl font-black text-slate-900 dark:text-slate-100 leading-relaxed">
                            {currentFlashcard.question}
                          </h2>
                        </div>

                        {showCardHint && currentFlashcard.hint && (
                          <div className="p-3.5 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 font-tajawal">
                            <strong>تلميح: </strong>
                            {currentFlashcard.hint}
                          </div>
                        )}

                        {currentFlashcard.options && currentFlashcard.options.length > 0 && (
                          <div className="space-y-2 pt-2">
                            <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                              اختبر إجابتك قبل قلب البطاقة:
                            </p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                              {currentFlashcard.options.map((opt, oIdx) => {
                                const isPicked = selectedFlashcardOption === oIdx;
                                const isRight =
                                  oIdx === (currentFlashcard.correctOptionIndex ?? 0);
                                const btnStyle = getMcqOptionSurfaceClass(oIdx, {
                                  isSelected: isPicked,
                                  isChecked: selectedFlashcardOption !== null && (isRight || isPicked),
                                  isCorrect: isRight,
                                });

                                return (
                                  <button
                                    key={oIdx}
                                    type="button"
                                    onClick={() => {
                                      setSelectedFlashcardOption(oIdx);
                                      if (oIdx === (currentFlashcard.correctOptionIndex ?? 0)) {
                                        playSoundEffect('correct');
                                        recordSpacedRepetitionOutcome(currentFlashcard, 'correct');
                                      } else {
                                        playSoundEffect('wrong');
                                        recordSpacedRepetitionOutcome(currentFlashcard, 'wrong');
                                      }
                                    }}
                                    className={`p-3 rounded-xl border text-right text-xs font-tajawal transition-all flex items-center justify-between gap-2 ${btnStyle}`}
                                  >
                                    <span>{opt}</span>
                                    {selectedFlashcardOption !== null && isRight && (
                                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                                    )}
                                    {selectedFlashcardOption === oIdx && !isRight && (
                                      <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="space-y-4">
                        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                          <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 block mb-1">
                            الإجابة الصحيحة من الدرس:
                          </span>
                          <p className="text-base md:text-xl font-black text-emerald-950 dark:text-white leading-relaxed">
                            {currentFlashcard.answer}
                          </p>
                        </div>

                        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                            توثيق الدرس في قاعدة بيانات منصة الشريف:
                          </span>
                          <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 font-tajawal leading-relaxed">
                            {currentFlashcard.explanation}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Card Footer */}
                  <div className="relative z-10 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={currentCardIndex === 0}
                        onClick={() => {
                          setCurrentCardIndex((p) => Math.max(0, p - 1));
                          setIsCardFlipped(false);
                          setSelectedFlashcardOption(null);
                        }}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold disabled:opacity-40 flex items-center gap-1 hover:bg-slate-50 dark:hover:bg-slate-800"
                      >
                        <ChevronRight className="w-4 h-4" />
                        <span>السابق</span>
                      </button>

                      <button
                        type="button"
                        disabled={currentCardIndex >= filteredFlashcards.length - 1}
                        onClick={() => {
                          setCurrentCardIndex((p) =>
                            Math.min(filteredFlashcards.length - 1, p + 1)
                          );
                          setIsCardFlipped(false);
                          setSelectedFlashcardOption(null);
                        }}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-bold disabled:opacity-40 flex items-center gap-1 hover:bg-slate-50 dark:hover:bg-slate-800"
                      >
                        <span>التالي</span>
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleMarkMastery(currentFlashcard.id, 'mastered')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          masteryMap[currentFlashcard.id] === 'mastered'
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                        }`}
                      >
                        سهلة (تباعد SM2)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMarkMastery(currentFlashcard.id, 'review')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          masteryMap[currentFlashcard.id] === 'review'
                            ? 'bg-amber-500 text-slate-950 border-amber-500'
                            : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                        }`}
                      >
                        متوسطة (مراجعة)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMarkMastery(currentFlashcard.id, 'hard')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          masteryMap[currentFlashcard.id] === 'hard'
                            ? 'bg-rose-600 text-white border-rose-600'
                            : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800'
                        }`}
                      >
                        صعبة (تظهر سريعاً)
                      </button>
                    </div>
                  </div>

                  {/* Spaced Repetition SM2 Mastery Progress Bar for Current Card */}
                  {(() => {
                    const srRec = spacedRepetitionMap[currentFlashcard.id];
                    const sm2Rec = sm2Map[currentFlashcard.id];
                    const masteryPct =
                      sm2Rec?.lastQuality === 'easy'
                        ? 100
                        : srRec?.masteryPercent ??
                          (masteryMap[currentFlashcard.id] === 'mastered' ? 100 : sm2Rec ? 50 : 0);
                    return (
                      <div className="relative z-10 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-[11px]">
                        <div className="flex flex-wrap items-center gap-2 text-slate-600 dark:text-slate-400">
                          <Brain className="w-3.5 h-3.5 text-emerald-600" />
                          <span>
                            إتقان البطاقة (SM2):{' '}
                            <strong className="font-mono-numbers text-slate-900 dark:text-white">
                              {masteryPct}%
                            </strong>
                          </span>
                          {sm2Rec && (
                            <span className="font-mono-numbers text-slate-500">
                              · الفاصل: {sm2Rec.intervalDays} يوم · معامل السهولة: {sm2Rec.easeFactor}
                            </span>
                          )}
                          {sm2Rec?.nextReviewAt ? (
                            <span className="px-2 py-0.5 rounded bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 font-bold">
                              المراجعة القادمة: {new Date(sm2Rec.nextReviewAt).toLocaleDateString('ar-EG')}
                            </span>
                          ) : srRec?.nextReviewDate && masteryPct < 100 ? (
                            <span className="px-2 py-0.5 rounded bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 font-bold">
                              موعد التكرار القادم: {srRec.nextReviewDate}
                            </span>
                          ) : null}
                          {masteryPct >= 100 && (
                            <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-bold">
                              ✓ متقنة 100%
                            </span>
                          )}
                        </div>
                        <div className="w-40 h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                          <div
                            className={`h-full transition-all duration-300 ${
                              masteryPct >= 100
                                ? 'bg-emerald-500'
                                : masteryPct >= 34
                                ? 'bg-amber-500'
                                : 'bg-rose-500'
                            }`}
                            style={{ width: `${Math.max(8, masteryPct)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* Right Column: Database Lesson Flashcards List (4 cols) */}
              <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    بطاقات الدروس في القاعدة ({filteredFlashcards.length})
                  </h3>
                  <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">
                    {selectedSubject}
                  </span>
                </div>

                <div className="max-h-[380px] overflow-y-auto space-y-2 pr-1">
                  {filteredFlashcards.map((fc, idx) => {
                    const status = masteryMap[fc.id];
                    const isCustom = fc.id.startsWith('fc-');
                    return (
                      <div
                        key={fc.id}
                        onClick={() => {
                          setCurrentCardIndex(idx);
                          setIsCardFlipped(false);
                          setSelectedFlashcardOption(null);
                        }}
                        className={`p-3 rounded-xl border text-xs cursor-pointer transition-colors flex items-start justify-between gap-2 ${
                          currentCardIndex === idx
                            ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-500'
                            : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                        }`}
                      >
                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                            <span className="font-mono-numbers font-bold">#{idx + 1}</span>
                            <span aria-hidden="true">·</span>
                            <span>{fc.subject}</span>
                            {fc.lessonTitle && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="truncate">{fc.lessonTitle}</span>
                              </>
                            )}
                            {status === 'mastered' && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-emerald-600 font-bold">متقنة</span>
                              </>
                            )}
                          </div>
                          <p className="font-bold text-slate-800 dark:text-slate-200 line-clamp-2">
                            {fc.question}
                          </p>
                        </div>

                        {canManage && isCustom && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteCustomFlashcard(fc.id);
                            }}
                            className="p-1 text-slate-400 hover:text-rose-600 shrink-0"
                            title="حذف البطاقة"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-10 text-center bg-white dark:bg-slate-900 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 space-y-3">
              <Database className="w-10 h-10 text-emerald-600 mx-auto" />
              <p className="text-sm md:text-base font-black text-slate-800 dark:text-slate-200">
                {dbLessons.length === 0
                  ? 'تم حذف جميع البيانات الوهمية — لا توجد دروس مسجلة في قاعدة البيانات بعد'
                  : 'لا توجد بطاقات مطابقة لهذا التصنيف في قاعدة البيانات حالياً'}
              </p>
              <p className="text-xs text-slate-500 font-tajawal max-w-lg mx-auto leading-relaxed">
                {dbLessons.length === 0
                  ? 'يعتمد نظام الفلاش كارد ومسابقة الشريف 100% على الدروس الحقيقية المسجلة في قاعدة بيانات منصة الشريف فقط بدون أي معلومات وهمية. أضف درساً من قسم إدارة الدروس ليتم توليد الفلاش كارد والأسئلة منه تلقائياً.'
                  : 'اختر «كل المواد» لعرض جميع بطاقات الدروس المسجلة في قاعدة البيانات.'}
              </p>
              {onNavigateToLessons && dbLessons.length === 0 && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={onNavigateToLessons}
                    className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black inline-flex items-center gap-2 shadow-sm"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>الانتقال إلى قسم الدروس لإضافة دروس حقيقية بقاعدة البيانات</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ======================================================================= */}
      {/* TAB 3: AL-SHARIF INTERACTIVE COMPETITION (100% FROM DB LESSONS)         */}
      {/* ======================================================================= */}
      {activeMode === 'sharif_competition' && (
        <div className="space-y-6">
          {!isCompetitionRunning ? (
            /* TEACHER / ORGANIZER COMPETITION CONFIGURATION PANEL */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6">
                <div className="border-b border-slate-200 dark:border-slate-800 pb-4 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-black text-slate-900 dark:text-white">
                      إعداد مسابقة الشريف التفاعلية بين الطلاب (من دروس قاعدة البيانات فقط)
                    </h2>
                    <p className="text-xs text-slate-500 font-tajawal mt-0.5">
                      تُستخرج جميع الأسئلة من الدروس المسجلة في قاعدة بيانات منصة الشريف وتُعرض عشوائية بدون ترتيب، مع اختيار الطلاب المسجلين في القاعدة ونظام التايمر والهدايا الإلكترونية الرقمية.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      عنوان مسابقة الشريف
                    </label>
                    <input
                      type="text"
                      value={compTitle}
                      onChange={(e) => setCompTitle(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      طراز ونظام المسابقة في منصة الشريف
                    </label>
                    <select
                      value={compStyle}
                      onChange={(e) =>
                        setCompStyle(e.target.value as 'sharif_doors' | 'rapid_arena')
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    >
                      <option value="sharif_doors">
                        نظام مسابقة الشريف الكبرى (لوحة الأبواب المرقمة + تايمر + هدايا رقمية)
                      </option>
                      <option value="rapid_arena">
                        مسابقة الشريف التنافسية السريعة بين الطلاب
                      </option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      المادة الدراسية (من دروس قاعدة البيانات)
                    </label>
                    <select
                      value={compSubject}
                      onChange={(e) => {
                        setCompSubject(e.target.value);
                        setCompSelectedLessonIds([]);
                      }}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    >
                      <option value="كل المواد">شامل كل مواد الدروس المسجلة ({availableSubjects.length})</option>
                      {availableSubjects.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      عدد الطلاب المشاركين من قاعدة البيانات ({targetStudentsCount} من أصل {dbStudents.length})
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={Math.max(1, dbStudents.length)}
                      value={targetStudentsCount}
                      onChange={(e) =>
                        setTargetStudentsCount(
                          Math.max(
                            1,
                            Math.min(Math.max(1, dbStudents.length), Number(e.target.value) || 2)
                          )
                        )
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers font-bold text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      عدد الأسئلة العشوائية المطلوبة ({targetQuestionsCount} سؤالاً)
                    </label>
                    <input
                      type="number"
                      min={2}
                      max={30}
                      value={targetQuestionsCount}
                      onChange={(e) =>
                        setTargetQuestionsCount(
                          Math.max(2, Math.min(30, Number(e.target.value) || 6))
                        )
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers font-bold text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      تايمر العد التنازلي لكل سؤال (بالثواني)
                    </label>
                    <select
                      value={timerSecondsPerQuestion}
                      onChange={(e) => setTimerSecondsPerQuestion(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers font-bold text-slate-900 dark:text-white"
                    >
                      <option value={15}>15 ثانية</option>
                      <option value={20}>20 ثانية</option>
                      <option value={30}>30 ثانية (معيار مسابقة الشريف)</option>
                      <option value={45}>45 ثانية</option>
                      <option value={60}>60 ثانية</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      المرحلة الدراسية
                    </label>
                    <select
                      value={compGrade}
                      onChange={(e) => setCompGrade(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    >
                      {availableGrades.map((g) => (
                        <option key={g} value={g}>
                          {g}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Database Lessons Selection for the Competition */}
                <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      تحديد دروس قاعدة البيانات الداخلة في المسابقة (
                      {compSelectedLessonIds.length === 0
                        ? `كل الدروس المتاحة: ${eligibleDbLessons.length}`
                        : `تم تحديد ${compSelectedLessonIds.length} درس`}
                      )
                    </label>
                    {compSelectedLessonIds.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setCompSelectedLessonIds([])}
                        className="text-xs text-emerald-600 dark:text-emerald-400 font-bold"
                      >
                        تضمين كل الدروس ({eligibleDbLessons.length})
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                    {eligibleDbLessons.map((les) => {
                      const isChecked = compSelectedLessonIds.includes(les.id);
                      return (
                        <button
                          key={les.id}
                          type="button"
                          onClick={() =>
                            setCompSelectedLessonIds((prev) =>
                              prev.includes(les.id)
                                ? prev.filter((id) => id !== les.id)
                                : [...prev, les.id]
                            )
                          }
                          className={`p-2 rounded-lg text-right text-xs flex items-center justify-between gap-2 border transition-colors ${
                            isChecked
                              ? 'bg-emerald-600 text-white border-emerald-600 font-bold'
                              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <span className="truncate">
                            {les.title} ({les.subject})
                          </span>
                          {isChecked && <Check className="w-3.5 h-3.5 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Real Database Student Selection Section */}
                <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      اختيار الطلاب المتسابقين من قاعدة البيانات ({selectedStudentIds.length} / {targetStudentsCount})
                    </label>
                    <button
                      type="button"
                      onClick={handleRandomSelectDbStudents}
                      className="px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-bold flex items-center gap-1.5"
                    >
                      <Shuffle className="w-3.5 h-3.5" />
                      <span>اختيار عشوائي لـ ({targetStudentsCount}) طلاب من القاعدة</span>
                    </button>
                  </div>

                  {dbStudents.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 max-h-44 overflow-y-auto p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                      {dbStudents.map((stu) => {
                        const checked = selectedStudentIds.includes(stu.id);
                        return (
                          <button
                            key={stu.id}
                            type="button"
                            onClick={() => {
                              setSelectedStudentIds((prev) =>
                                prev.includes(stu.id)
                                  ? prev.filter((id) => id !== stu.id)
                                  : prev.length < targetStudentsCount
                                  ? [...prev, stu.id]
                                  : prev
                              );
                            }}
                            className={`p-2 rounded-lg text-right text-xs flex items-center justify-between gap-2 border transition-colors ${
                              checked
                                ? 'bg-emerald-600 text-white border-emerald-600 font-bold'
                                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            <span className="truncate">
                              {stu.name} ({stu.grade})
                            </span>
                            {checked && <Check className="w-3.5 h-3.5 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex flex-wrap items-center justify-between gap-2">
                      <p className="text-xs text-amber-800 dark:text-amber-300 font-bold">
                        تم حذف البيانات الوهمية — لا يوجد طلاب مسجلون في قاعدة البيانات حالياً.
                      </p>
                      {onNavigateToStudents && (
                        <button
                          type="button"
                          onClick={onNavigateToStudents}
                          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black"
                        >
                          إضافة طلاب في قاعدة البيانات
                        </button>
                      )}
                    </div>
                  )}
                </div>

                <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
                  <div className="text-xs text-slate-500 font-tajawal">
                    تُولد الأسئلة مباشرة من دروس قاعدة بيانات منصة الشريف وتُخلط عشوائياً بلا ترتيب.
                  </div>

                  <button
                    type="button"
                    onClick={handleLaunchCompetition}
                    className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs md:text-sm flex items-center gap-2 shadow-md transition-colors whitespace-nowrap"
                  >
                    <Play className="w-4 h-4" />
                    <span>بدء مسابقة الشريف الآن ({targetQuestionsCount} سؤالاً من الدروس)</span>
                  </button>
                </div>
              </div>

              {/* Right Column: Rules & Recent Competitions Log (4 cols) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <Award className="w-4 h-4" />
                    <span>ضوابط مسابقة الشريف في منصة الشريف</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300 font-tajawal leading-relaxed">
                    <li>1. تعتمد المسابقة 100% على الدروس والطلاب الفعليين المسجلين في قاعدة بيانات منصة الشريف بدون أي بيانات وهمية.</li>
                    <li>2. لوحة الأبواب الذهبية المرقمة من 1 إلى {targetQuestionsCount}؛ كل باب يخفي سؤالاً عشوائياً غير مرتب مستخرجاً من الدروس.</li>
                    <li>3. تايمر عد تنازلي ({timerSecondsPerQuestion} ثانية) مع وسائل مساعدة (50/50، وقت إضافي، تبديل السؤال من الدروس).</li>
                    <li>4. هدايا إلكترونية رقمية تشجيعية معتمدة باسم منصة الشريف.</li>
                  </ul>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    سجل مسابقات الشريف الأخيرة ({competitionHistory.length})
                  </h3>
                  {competitionHistory.length === 0 ? (
                    <p className="text-xs text-slate-500 font-tajawal">
                      لم يتم تسجيل مسابقات سابقة بعد. ابدأ أول مسابقة الآن!
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {competitionHistory.slice(0, 6).map((rec) => (
                        <div
                          key={rec.id}
                          className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                            <span className="truncate">{rec.title}</span>
                            <span className="text-emerald-600 dark:text-emerald-400 shrink-0 font-mono-numbers">
                              {rec.winnerScore} نقطة
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                            <span>الفائز: {rec.winnerName}</span>
                            <span aria-hidden="true">·</span>
                            <span>{rec.subject}</span>
                            <span aria-hidden="true">·</span>
                            <span>{rec.studentsCount} طلاب</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* =================================================================== */
            /* ACTIVE AL-SHARIF COMPETITION STAGE                                  */
            /* =================================================================== */
            <div className="space-y-6">
              {/* Top Competition Control Bar */}
              <div className="bg-slate-900 text-white p-4 md:p-5 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs text-amber-400 font-bold">
                    <span>{compTitle}</span>
                    <span aria-hidden="true">·</span>
                    <span>{compSubject}</span>
                  </div>
                  <h2 className="text-base md:text-lg font-black mt-0.5">
                    {isCompetitionFinished
                      ? 'اكتملت مسابقة الشريف — إعلان النتائج النهائية والهدايا الرقمية'
                      : `الدور الآن على الطالب المتسابق: ${participants[currentTurnIndex]?.name}`}
                  </h2>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  {!isCompetitionFinished && !activeDoor && (
                    <button
                      type="button"
                      onClick={handlePickRandomAvailableDoor}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5"
                    >
                      <Shuffle className="w-4 h-4" />
                      <span>اختيار عشوائي لباب السؤال</span>
                    </button>
                  )}

                  {!isCompetitionFinished && (
                    <button
                      type="button"
                      onClick={handleFinishCompetition}
                      className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs"
                    >
                      إنهاء المسابقة وإعلان الفائزين
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setIsCompetitionRunning(false);
                      setActiveDoor(null);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold"
                  >
                    إعداد مسابقة جديدة
                  </button>
                </div>
              </div>

              {/* Live Scoreboard Strip for Competing DB Students */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {participants.map((stu, idx) => {
                  const isCurrentTurn = !isCompetitionFinished && idx === currentTurnIndex;
                  return (
                    <div
                      key={stu.id}
                      onClick={() => {
                        if (!activeDoor && !isCompetitionFinished) setCurrentTurnIndex(idx);
                      }}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                        isCurrentTurn
                          ? 'bg-emerald-50 dark:bg-emerald-950/50 border-2 border-emerald-600 shadow-sm'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-bold text-slate-500">
                          متسابق #{idx + 1} {isCurrentTurn ? '· دوره الآن' : ''}
                        </span>
                        <span className="font-mono-numbers font-black text-sm text-emerald-700 dark:text-emerald-400 tabular-nums">
                          {stu.score} نقطة
                        </span>
                      </div>

                      <h3 className="font-black text-sm text-slate-900 dark:text-white mt-1 truncate">
                        {stu.name}
                      </h3>

                      <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 font-mono-numbers">
                        <span>صحيحة: {stu.correctCount}</span>
                        <span>خاطئة: {stu.wrongCount}</span>
                        <span className="text-amber-600 dark:text-amber-400 font-bold">
                          هدايا: {stu.giftsWon.length}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Final Podium & Winners Screen when finished */}
              {isCompetitionFinished ? (
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 md:p-8 space-y-6">
                  <div className="text-center space-y-2">
                    <Trophy className="w-12 h-12 text-amber-500 mx-auto" />
                    <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                      لوحة شرف الفائزين في {compTitle}
                    </h2>
                    <p className="text-xs text-slate-500 font-tajawal">
                      تم منح الفائزين بطاقات الهدايا الإلكترونية الرقمية التشجيعية وتوثيقها في خزينة منصة الشريف.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[...participants]
                      .sort((a, b) => b.score - a.score)
                      .map((stu, rankIdx) => (
                        <div
                          key={stu.id}
                          className={`p-5 rounded-2xl border space-y-3 ${
                            rankIdx === 0
                              ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-400'
                              : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-black text-amber-700 dark:text-amber-400">
                              المركز #{rankIdx + 1}
                            </span>
                            <span className="font-mono-numbers font-black text-base text-slate-900 dark:text-white">
                              {stu.score} نقطة
                            </span>
                          </div>
                          <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap">
                            <span>{stu.name}</span>
                            {studentBadges[stu.name] && (
                              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-400/40 text-[11px] font-bold">
                                {studentBadges[stu.name]}
                              </span>
                            )}
                          </h3>
                          <div className="text-xs text-slate-500 flex items-center gap-2">
                            <span>إجابات صحيحة: {stu.correctCount}</span>
                            <span aria-hidden="true">·</span>
                            <span>هدايا رقمية: {stu.giftsWon.length}</span>
                          </div>
                          <button
                            type="button"
                            onClick={async () => {
                              const gift = await awardDigitalGiftToStudent(stu, compSubject);
                              setPreviewGiftVoucher(gift);
                            }}
                            className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                          >
                            <Gift className="w-3.5 h-3.5" />
                            <span>إصدار وعرض بطاقة هدية منصة الشريف الرقمية</span>
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              ) : (
                /* AL-SHARIF NUMBERED GOLDEN DOORS GRID */
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="font-black text-sm md:text-base text-slate-900 dark:text-white">
                        لوحة أبواب مسابقة الشريف المرقمة (أسئلة عشوائية من الدروس المسجلة في القاعدة)
                      </h3>
                      <p className="text-xs text-slate-500 font-tajawal">
                        اختر رقم الباب ليظهر السؤال المستخرج من الدروس عشوائياً بدون ترتيب مع تشغيل التايمر ({timerSecondsPerQuestion} ثانية).
                      </p>
                    </div>
                    <span className="text-xs font-mono-numbers font-bold text-slate-500">
                      المتبقي: {doorsBoard.filter((d) => !d.isOpened).length} من {doorsBoard.length}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                    {doorsBoard.map((door) => {
                      if (door.isOpened) {
                        return (
                          <div
                            key={door.doorNumber}
                            className={`p-4 rounded-t-3xl rounded-b-xl border text-center space-y-1.5 opacity-75 ${
                              door.wasCorrect
                                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800'
                                : 'bg-rose-50 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800'
                            }`}
                          >
                            <span className="font-mono-numbers text-lg font-black block text-slate-700 dark:text-slate-300">
                              باب #{door.doorNumber}
                            </span>
                            <span className="text-[11px] font-bold block truncate">
                              {door.answeredByStudentName}
                            </span>
                            <span className="text-[11px] font-bold block">
                              {door.wasCorrect ? `✓ +${door.points}` : '✗ لم يُصب'}
                            </span>
                          </div>
                        );
                      }

                      return (
                        <button
                          key={door.doorNumber}
                          type="button"
                          onClick={() => handleOpenDoor(door)}
                          className="group p-4 rounded-t-3xl rounded-b-xl bg-gradient-to-b from-amber-500/15 via-amber-500/5 to-slate-50 dark:from-amber-500/20 dark:via-slate-900 dark:to-slate-900 border-2 border-amber-500/50 hover:border-amber-500 hover:shadow-md transition-all text-center space-y-1.5"
                        >
                          <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400 block truncate">
                            {door.hasMysteryGift ? '★ بوابة هدية رقمية' : door.subject}
                          </span>
                          <span className="font-mono-numbers text-2xl font-black text-slate-900 dark:text-white block group-hover:scale-105 transition-transform">
                            {door.doorNumber}
                          </span>
                          <span className="text-xs font-mono-numbers font-bold text-emerald-700 dark:text-emerald-400 block">
                            {door.points} نقطة
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ======================================================================= */}
      {/* TAB 5: LIVE CHALLENGE ROOMS (1v1 / TEAMS) & WEEKLY LEAGUE               */}
      {/* ======================================================================= */}
      {activeMode === 'live_challenge_rooms' && (
        <div className="space-y-6">
          {/* Room Setup + Weekly League Header */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Create 1v1 or Team Room Card (5 cols) */}
            <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-500" />
                  <h2 className="text-base font-black text-slate-900 dark:text-white">
                    إنشاء غرفة تحدٍ مباشر (1 ضد 1 أو فرق)
                  </h2>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[11px] font-black">
                  الأسرع = نقاط ×2
                </span>
              </div>
              <p className="text-xs text-slate-500 font-tajawal leading-relaxed">
                يدخل طالبان أو فريقان في نفس اللحظة للإجابة على نفس السؤال العشوائي من بنك أسئلة الدروس، والأسرع في الإجابة الصحيحة يحصل على <strong>نقاط مضاعفة (×2)</strong> تضاف فوراً إلى الدوري الأسبوعي.
              </p>

              <div className="space-y-3 pt-1">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    عنوان غرفة التحدي أو البطولة الأسبوعية
                  </label>
                  <input
                    type="text"
                    value={roomTitle}
                    onChange={(e) => setRoomTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setRoomMode('1v1')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${
                      roomMode === '1v1'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>تحدي 1 ضد 1</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRoomMode('teams')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${
                      roomMode === 'teams'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>فريق ضد فريق</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {roomMode === '1v1' ? 'الطالب الأول (الطرف A)' : 'اسم الفريق الأول (A)'}
                    </label>
                    <input
                      type="text"
                      list="db-students-datalist"
                      value={sideAStudentName}
                      onChange={(e) => setSideAStudentName(e.target.value)}
                      placeholder={dbStudents[0]?.name || 'اختر أو اكتب اسم الطالب/الفريق'}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {roomMode === '1v1' ? 'الطالب الثاني (الطرف B)' : 'اسم الفريق الثاني (B)'}
                    </label>
                    <input
                      type="text"
                      list="db-students-datalist"
                      value={sideBStudentName}
                      onChange={(e) => setSideBStudentName(e.target.value)}
                      placeholder={dbStudents[1]?.name || 'اختر أو اكتب اسم المنافس'}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                    />
                  </div>
                </div>

                <datalist id="db-students-datalist">
                  {dbStudents.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.grade}
                    </option>
                  ))}
                </datalist>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      المادة من القاعدة
                    </label>
                    <select
                      value={roomSubject}
                      onChange={(e) => setRoomSubject(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                    >
                      <option value="كل المواد">كل المواد ({allDatabaseFlashcards.length})</option>
                      {availableSubjects.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      عدد أسئلة التحدي
                    </label>
                    <input
                      type="number"
                      min={2}
                      max={20}
                      value={roomQuestionsCount}
                      onChange={(e) =>
                        setRoomQuestionsCount(
                          Math.max(2, Math.min(20, Number(e.target.value) || 5))
                        )
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold font-mono-numbers"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCreateChallengeRoom}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
                >
                  <Zap className="w-4 h-4" />
                  <span>إطلاق غرفة التحدي المباشر الآن (أسئلة عشوائية من الدروس)</span>
                </button>
              </div>

              {/* Active Rooms List */}
              {liveChallengeRooms.length > 0 && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <span className="text-xs font-bold text-slate-500 block">
                    غرف التحدي النشطة والمكتملة ({liveChallengeRooms.length}):
                  </span>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {liveChallengeRooms.map((room) => (
                      <div
                        key={room.id}
                        onClick={() => setActiveChallengeRoomId(room.id)}
                        className={`p-3 rounded-xl border text-xs cursor-pointer flex items-center justify-between gap-2 ${
                          activeChallengeRoom?.id === room.id
                            ? 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-500'
                            : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 dark:text-white truncate">
                            {room.title}
                          </p>
                          <p className="text-[11px] text-slate-500 truncate">
                            {room.sideAName} ({room.sideAScore}) ضد {room.sideBName} ({room.sideBScore})
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              room.status === 'finished'
                                ? 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                                : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            }`}
                          >
                            {room.status === 'finished' ? 'مكتملة' : 'مباشر الآن'}
                          </span>
                          {canManage && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteChallengeRoom(room.id);
                              }}
                              className="p-1 rounded hover:bg-rose-100 text-rose-600"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Live Dual-Buzzer Challenge Arena (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              {activeChallengeRoom ? (
                <div className="bg-white dark:bg-slate-900 rounded-2xl border-2 border-amber-500/60 shadow-lg p-6 space-y-5 relative overflow-hidden">
                  <AlSharifWatermark extraLabel={activeChallengeRoom.title} opacity="light" />
                  <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-md bg-amber-500 text-slate-950 text-[11px] font-black">
                          {activeChallengeRoom.mode === '1v1' ? 'تحدي مباشر 1 ضد 1' : 'تحدي الفرق المباشر'}
                        </span>
                        <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                          {activeChallengeRoom.subject}
                        </span>
                      </div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1">
                        {activeChallengeRoom.title}
                      </h3>
                    </div>

                    <div className="text-left">
                      <span className="text-xs font-mono-numbers font-bold text-slate-500 block">
                        السؤال {activeChallengeRoom.currentQuestionIndex + 1} من{' '}
                        {activeChallengeRoom.questions.length}
                      </span>
                      <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
                        ⚡ الأسرع في الإجابة الصحيحة = نقاط مضاعفة (×2)
                      </span>
                    </div>
                  </div>

                  {/* Scoreboard VS Bar */}
                  <div className="relative z-10 grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 block">
                          الطرف الأول (A)
                        </span>
                        <strong className="text-sm md:text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap">
                          <span>{activeChallengeRoom.sideAName}</span>
                          {studentBadges[activeChallengeRoom.sideAName] && (
                            <span className="text-[11px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300">
                              {studentBadges[activeChallengeRoom.sideAName]}
                            </span>
                          )}
                        </strong>
                      </div>
                      <span className="font-mono-numbers text-2xl font-black text-emerald-700 dark:text-emerald-400">
                        {activeChallengeRoom.sideAScore}
                      </span>
                    </div>

                    <div className="p-4 rounded-2xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-300 dark:border-sky-800 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] font-bold text-sky-700 dark:text-sky-400 block">
                          الطرف الثاني (B)
                        </span>
                        <strong className="text-sm md:text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap">
                          <span>{activeChallengeRoom.sideBName}</span>
                          {studentBadges[activeChallengeRoom.sideBName] && (
                            <span className="text-[11px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300">
                              {studentBadges[activeChallengeRoom.sideBName]}
                            </span>
                          )}
                        </strong>
                      </div>
                      <span className="font-mono-numbers text-2xl font-black text-sky-700 dark:text-sky-400">
                        {activeChallengeRoom.sideBScore}
                      </span>
                    </div>
                  </div>

                  {/* Current Live Question or Final Result */}
                  {activeChallengeRoom.status === 'finished' ? (
                    <div className="relative z-10 p-6 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 text-center space-y-3">
                      <Crown className="w-10 h-10 text-amber-500 mx-auto" />
                      <h4 className="text-xl font-black text-slate-900 dark:text-white">
                        انتهت مواجهة التحدي المباشر!
                      </h4>
                      <p className="text-sm font-bold text-amber-800 dark:text-amber-300">
                        {activeChallengeRoom.sideAScore > activeChallengeRoom.sideBScore
                          ? `🏆 الفائز: ${activeChallengeRoom.sideAName} (${activeChallengeRoom.sideAScore} نقطة مقابل ${activeChallengeRoom.sideBScore})`
                          : activeChallengeRoom.sideBScore > activeChallengeRoom.sideAScore
                          ? `🏆 الفائز: ${activeChallengeRoom.sideBName} (${activeChallengeRoom.sideBScore} نقطة مقابل ${activeChallengeRoom.sideAScore})`
                          : `تعادل مثير بين الطرفين (${activeChallengeRoom.sideAScore} نقطة لكل طرف)`}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal">
                        تمت إضافة جميع النقاط المضاعفة إلى جدول الدوري الأسبوعي وإلى رصيد متجر جوائز منصة الشريف.
                      </p>
                    </div>
                  ) : (
                    (() => {
                      const q =
                        activeChallengeRoom.questions[
                          activeChallengeRoom.currentQuestionIndex
                        ];
                      if (!q) return null;
                      return (
                        <div className="relative z-10 space-y-4">
                          <div className={`${MCQ_QUESTION_BOX_CLASS} space-y-1.5`}>
                            <div className="flex items-center justify-between text-[11px] text-emerald-700 dark:text-amber-400 font-bold">
                              <span>الدرس: {q.lessonTitle || q.subject}</span>
                              <span>
                                النقاط الأساسية: {q.points} · للأسرع (×2): {q.points * 2} نقطة
                              </span>
                            </div>
                            <h4 className="text-base md:text-lg font-black leading-relaxed text-slate-900 dark:text-slate-100">
                              {q.question}
                            </h4>
                          </div>

                          {activeChallengeRoom.fastestWinnerName && (
                            <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-400 text-xs font-bold text-emerald-900 dark:text-emerald-200 flex items-center justify-between gap-2">
                              <span>
                                ⚡ حسمها الأسرع: <strong>{activeChallengeRoom.fastestWinnerName}</strong> وحصل على النقاط المضاعفة (×2)! — الإجابة الصحيحة: {q.answer}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  handleNextChallengeQuestion(activeChallengeRoom.id)
                                }
                                className="px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-black whitespace-nowrap"
                              >
                                السؤال التالي ←
                              </button>
                            </div>
                          )}

                          {!activeChallengeRoom.fastestWinnerName &&
                            activeChallengeRoom.sideAAnswered &&
                            activeChallengeRoom.sideBAnswered && (
                              <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-300 text-xs font-bold text-rose-900 dark:text-rose-200 flex items-center justify-between gap-2">
                                <span>
                                  لم يُصب الطرفان في هذا السؤال. الإجابة الصحيحة هي: {q.answer}
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleNextChallengeQuestion(activeChallengeRoom.id)
                                  }
                                  className="px-3.5 py-1.5 rounded-lg bg-slate-900 text-white font-black whitespace-nowrap"
                                >
                                  السؤال التالي ←
                                </button>
                              </div>
                            )}

                          {/* Simultaneous Dual Buzzer Panels for Side A and Side B */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Side A Options */}
                            <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-800/70 bg-emerald-50/30 dark:bg-slate-800/40 space-y-2.5">
                              <div className="flex items-center justify-between text-xs font-black text-emerald-800 dark:text-emerald-300">
                                <span>لوحة إجابة: {activeChallengeRoom.sideAName}</span>
                                {activeChallengeRoom.sideAAnswered && (
                                  <span className="text-[11px] text-slate-500">تم الإرسال</span>
                                )}
                              </div>
                              <div className="space-y-2">
                                {q.options.map((opt: string, idx: number) => (
                                  <button
                                    key={idx}
                                    type="button"
                                    disabled={
                                      Boolean(activeChallengeRoom.fastestWinnerName) ||
                                      Boolean(activeChallengeRoom.sideAAnswered)
                                    }
                                    onClick={() =>
                                      handleSubmitChallengeAnswer(
                                        activeChallengeRoom.id,
                                        'A',
                                        idx,
                                        activeChallengeRoom.sideAName
                                      )
                                    }
                                    className={`w-full p-2.5 rounded-xl border-2 text-right text-xs font-bold transition-all disabled:opacity-50 ${getMcqOptionSurfaceClass(idx)}`}
                                  >
                                    {opt}
                                  </button>
                                ))}
                              </div>
                            </div>

                            {/* Side B Options */}
                            <div className="p-4 rounded-xl border border-sky-200 dark:border-sky-800/70 bg-sky-50/30 dark:bg-slate-800/40 space-y-2.5">
                              <div className="flex items-center justify-between text-xs font-black text-sky-800 dark:text-sky-300">
                                <span>لوحة إجابة: {activeChallengeRoom.sideBName}</span>
                                {activeChallengeRoom.sideBAnswered && (
                                  <span className="text-[11px] text-slate-500">تم الإرسال</span>
                                )}
                              </div>
                              <div className="space-y-2">
                                {q.options.map((opt: string, idx: number) => (
                                  <button
                                    key={idx}
                                    type="button"
                                    disabled={
                                      Boolean(activeChallengeRoom.fastestWinnerName) ||
                                      Boolean(activeChallengeRoom.sideBAnswered)
                                    }
                                    onClick={() =>
                                      handleSubmitChallengeAnswer(
                                        activeChallengeRoom.id,
                                        'B',
                                        idx,
                                        activeChallengeRoom.sideBName
                                      )
                                    }
                                    className={`w-full p-2.5 rounded-xl border-2 text-right text-xs font-bold transition-all disabled:opacity-50 ${getMcqOptionSurfaceClass(idx)}`}
                                  >
                                    {opt}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })()
                  )}
                </div>
              ) : (
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3">
                  <Zap className="w-10 h-10 text-amber-500 mx-auto" />
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    لا توجد غرفة تحدٍ مباشر مفتوحة حالياً
                  </h3>
                  <p className="text-xs text-slate-500 font-tajawal max-w-md mx-auto">
                    أنشئ غرفة تحدٍ مباشر (1 ضد 1 أو فريقين) من القائمة الجانبية ليتم سحب أسئلة عشوائية من دروس قاعدة البيانات فوراً، والأسرع في الإجابة الصحيحة يحصل على نقاط مضاعفة (×2)!
                  </p>
                </div>
              )}

              {/* Weekly League Leaderboard */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-amber-500" />
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      ترتيب الدوري الأسبوعي المباشر — مسابقة الشريف
                    </h3>
                  </div>
                  <span className="text-xs text-slate-500 font-tajawal">
                    يتحدث لحظياً عبر الغرف المباشرة
                  </span>
                </div>

                {weeklyLeague.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-right text-xs">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                          <th className="py-2.5 px-3">المركز</th>
                          <th className="py-2.5 px-3">الطالب / الفريق والوسام</th>
                          <th className="py-2.5 px-3">الفوز السريع</th>
                          <th className="py-2.5 px-3">مرات الإجابة الأسرع (×2)</th>
                          <th className="py-2.5 px-3">إجمالي نقاط الدوري</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {weeklyLeague.map((entry, idx) => (
                          <tr key={entry.studentId || entry.studentName} className="font-bold">
                            <td className="py-2.5 px-3 font-mono-numbers">#{idx + 1}</td>
                            <td className="py-2.5 px-3 flex items-center gap-1.5 flex-wrap">
                              <span className="text-slate-900 dark:text-white">
                                {entry.studentName}
                              </span>
                              {(studentBadges[entry.studentName] || entry.badge) && (
                                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[11px]">
                                  {studentBadges[entry.studentName] || entry.badge}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 font-mono-numbers text-emerald-600">
                              {entry.wins} فوز
                            </td>
                            <td className="py-2.5 px-3 font-mono-numbers text-amber-600">
                              ⚡ {entry.fastestAnswers} مرة
                            </td>
                            <td className="py-2.5 px-3 font-mono-numbers text-sm font-black text-slate-900 dark:text-white">
                              {entry.points} نقطة
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 font-tajawal">
                    سيظهر ترتيب الطلاب والفرق في الدوري الأسبوعي فور الإجابة في غرف التحدي المباشر.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* TAB 7: WEEKLY CLASS CHALLENGES & HONOR BADGES (تحديات الصف الأسبوعية) */}
      {/* ======================================================================= */}
      {activeMode === 'class_challenges' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 text-xs font-black">
                  <Crown className="w-4 h-4 text-amber-500" />
                  <span>مسار التعلّم التعاوني وتحديات الصف الأسبوعية</span>
                </div>
                <h2 className="text-lg md:text-xl font-black text-slate-900 dark:text-white mt-1">
                  تحديات الأوائل على مستوى الصف — مع منح شارة التفوق في الشهادة ولوحة الشرف
                </h2>
              </div>
            </div>

            {canManage && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!challengeTitle.trim() || isSavingChallenge) return;
                  setIsSavingChallenge(true);
                  try {
                    const res = await fetch('/api/class-challenges', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json', ...getAuthHeaders(currentUser, teachers) },
                      body: JSON.stringify({
                        title: challengeTitle.trim(),
                        subject: challengeSubject,
                        grade: challengeGrade,
                        minPercentage: challengeMinPct,
                        maxWinners: challengeMaxWinners,
                        badgeTitle: challengeBadgeTitle.trim() || 'شارة التفوق الأسبوعي 🏆',
                        deadlineDate: challengeDeadline,
                      }),
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data?.error || 'تعذر إنشاء التحدي');
                    if (Array.isArray(data.challenges)) setClassChallenges(data.challenges);
                    setStatusBanner({
                      type: 'success',
                      text: `تم إطلاق تحدي الصف الأسبوعي «${challengeTitle.trim()}» واحتساب المتصدرين تلقائياً ✓`,
                    });
                  } catch (err: any) {
                    setStatusBanner({ type: 'error', text: err.message });
                  } finally {
                    setIsSavingChallenge(false);
                  }
                }}
                className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end"
              >
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    عنوان التحدي الأسبوعي *
                  </label>
                  <input
                    type="text"
                    required
                    value={challengeTitle}
                    onChange={(e) => setChallengeTitle(e.target.value)}
                    placeholder="مثال: أول 10 طلاب يتجاوزون 90% في اختبار التفاضل"
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    المادة
                  </label>
                  <select
                    value={challengeSubject}
                    onChange={(e) => setChallengeSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="جميع المواد">جميع المواد</option>
                    {availableSubjects.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    الصف المستهدف
                  </label>
                  <select
                    value={challengeGrade}
                    onChange={(e) => setChallengeGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  >
                    <option value="جميع الصفوف">جميع الصفوف</option>
                    {availableGrades
                      .filter((g) => g !== 'كل المراحل')
                      .map((g) => (
                        <option key={g} value={g}>
                          {g}
                        </option>
                      ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    نسبة النجاح المطلوبة (%)
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={100}
                    value={challengeMinPct}
                    onChange={(e) => setChallengeMinPct(Number(e.target.value) || 90)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    عدد المقاعد الفائزة
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={challengeMaxWinners}
                    onChange={(e) => setChallengeMaxWinners(Number(e.target.value) || 10)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-numbers"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    اسم الشارة الممنوحة في الشهادة
                  </label>
                  <input
                    type="text"
                    value={challengeBadgeTitle}
                    onChange={(e) => setChallengeBadgeTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSavingChallenge}
                  className="py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isSavingChallenge ? 'جاري النشر...' : 'إطلاق التحدي الأسبوعي'}</span>
                </button>
              </form>
            )}

            {classChallenges.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {classChallenges.map((ch) => (
                  <div
                    key={ch.id}
                    className="p-5 rounded-2xl border border-amber-300/70 dark:border-amber-700/60 bg-gradient-to-br from-amber-50/50 via-white to-emerald-50/40 dark:from-slate-900 dark:to-slate-800/80 space-y-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                          <span className="px-2 py-0.5 rounded-lg bg-amber-400 text-slate-950 font-black">
                            {ch.badgeTitle}
                          </span>
                          <span className="px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                            {ch.subject} · {ch.grade}
                          </span>
                        </div>
                        <h3 className="font-black text-sm md:text-base text-slate-900 dark:text-white">
                          {ch.title}
                        </h3>
                        <p className="text-[11px] text-slate-500 font-tajawal">
                          الشرط: تحقيق {ch.minPercentage}% فأكثر · المقاعد: {ch.winners.length}/{ch.maxWinners} · آخر موعد: {ch.deadlineDate}
                        </p>
                      </div>

                      {canManage && (
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={async () => {
                              const res = await fetch(`/api/class-challenges/${ch.id}/evaluate`, {
                                method: 'POST',
                                headers: getAuthHeaders(currentUser, teachers),
                              });
                              if (res.ok) {
                                const d = await res.json();
                                if (Array.isArray(d.challenges)) setClassChallenges(d.challenges);
                                setStatusBanner({
                                  type: 'success',
                                  text: `تم تحديث قائمة الفائزين ومنح الشارات لتحدي «${ch.title}» ✓`,
                                });
                              }
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold flex items-center gap-1"
                            title="تحديث الفائزين من نتائج الاختبارات"
                          >
                            <RefreshCw className="w-3 h-3" />
                            <span>تحديث الفائزين</span>
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              const res = await fetch(`/api/class-challenges/${ch.id}`, {
                                method: 'DELETE',
                                headers: getAuthHeaders(currentUser, teachers),
                              });
                              if (res.ok) {
                                const d = await res.json();
                                if (Array.isArray(d.challenges)) setClassChallenges(d.challenges);
                              }
                            }}
                            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5 text-amber-500" />
                        <span>لوحة الشرف والفائزون بالشارة ({ch.winners.length}):</span>
                      </h4>
                      {ch.winners.length > 0 ? (
                        <div className="space-y-1.5 max-h-48 overflow-y-auto">
                          {ch.winners.map((w) => (
                            <div
                              key={w.studentId}
                              className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 text-xs"
                            >
                              <div className="flex items-center gap-2">
                                <span className="w-6 h-6 rounded-lg bg-amber-400 text-slate-950 font-mono-numbers font-black text-[11px] flex items-center justify-center">
                                  #{w.seatNumber}
                                </span>
                                <span className="font-bold text-slate-900 dark:text-white">
                                  {w.studentName}
                                </span>
                              </div>
                              <span className="font-mono-numbers font-black text-emerald-600 dark:text-emerald-400">
                                {w.percentage}%
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500 font-tajawal p-3 rounded-xl bg-white/70 dark:bg-slate-900/50 border border-dashed border-slate-300 dark:border-slate-700">
                          لم يصل أي طالب إلى {ch.minPercentage}% في هذا التحدي بعد — الفرصة متاحة الآن!
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-1">
                <Crown className="w-9 h-9 text-amber-400 mx-auto" />
                <p className="font-bold text-xs text-slate-700 dark:text-slate-200">
                  لا توجد تحديات صف أسبوعية مضافة حالياً
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* TAB 6: AL-SHARIF REWARDS STORE (متجر جوائز منصة الشريف - استبدال النقاط) */}
      {/* ======================================================================= */}
      {activeMode === 'rewards_store' && (
        <div className="space-y-6">
          {/* Student Points Wallet & Selector */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-purple-700 dark:text-purple-400 text-xs font-black">
                  <ShoppingBag className="w-4 h-4" />
                  <span>متجر جوائز منصة الشريف — استبدال النقاط الفوري</span>
                </div>
                <h2 className="text-lg md:text-xl font-black text-slate-900 dark:text-white mt-1">
                  استبدل نقاط «مسابقة الشريف» والالتزام بالحضور بمكافآت تعليمية حقيقية
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  الطالب المستفيد من القاعدة:
                </label>
                <select
                  value={effectiveStoreStudentName}
                  onChange={(e) => setSelectedStoreStudentName(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {dbStudents.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name} ({s.grade})
                    </option>
                  ))}
                  {dbStudents.length === 0 && (
                    <option value={effectiveStoreStudentName}>
                      {effectiveStoreStudentName}
                    </option>
                  )}
                </select>

                {canManage && (
                  <button
                    type="button"
                    onClick={() =>
                      handleGrantBonusPoints(200, 'مكافأة التزام بالحضور وتفوق أسبوعي')
                    }
                    className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>منح +200 نقطة التزام بالحضور</span>
                  </button>
                )}
              </div>
            </div>

            {/* Points Breakdown Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-purple-50/80 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800">
                <span className="text-[11px] text-purple-700 dark:text-purple-300 font-bold block">
                  الرصيد المتاح للاستبدال الآن
                </span>
                <strong className="text-xl font-black font-mono-numbers text-purple-950 dark:text-white">
                  {studentPointsSummary.availableBalance} نقطة
                </strong>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block">نقاط مسابقة الشريف والهدايا</span>
                <strong className="text-base font-black font-mono-numbers text-slate-900 dark:text-white">
                  {studentPointsSummary.giftsPoints + studentPointsSummary.historyPoints} نقطة
                </strong>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block">نقاط غرف التحدي والدوري (×2)</span>
                <strong className="text-base font-black font-mono-numbers text-amber-600">
                  {studentPointsSummary.leaguePoints} نقطة
                </strong>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block">نقاط الحضور وإتقان البطاقات</span>
                <strong className="text-base font-black font-mono-numbers text-emerald-600">
                  {studentPointsSummary.attendanceAndBonus} نقطة
                </strong>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block">الوسام الفعال بجانب الاسم</span>
                <strong className="text-xs font-black text-amber-600 dark:text-amber-400 block mt-1 truncate">
                  {studentBadges[effectiveStoreStudentName] || 'لا يوجد وسام بعد'}
                </strong>
              </div>
            </div>

            {/* Target Lesson Selector for Free Lesson Unlock */}
            {dbLessons.length > 0 && (
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  الدرس المختار عند استبدال جائزة «فتح درس مجاني»:
                </span>
                <select
                  value={selectedUnlockLessonId || dbLessons[0]?.id || ''}
                  onChange={(e) => setSelectedUnlockLessonId(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  {dbLessons.map((les) => (
                    <option key={les.id} value={les.id}>
                      درس: {les.title} ({les.subject} — {les.grade})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Rewards Catalog Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {storeCatalog.map((reward) => {
              const canAfford = studentPointsSummary.availableBalance >= reward.costPoints;
              return (
                <div
                  key={reward.id}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col justify-between gap-4 shadow-xs hover:border-purple-500 transition-colors"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 text-xs font-black">
                        {reward.badgeLabel}
                      </span>
                      <span className="font-mono-numbers text-base font-black text-purple-700 dark:text-purple-400">
                        {reward.costPoints} نقطة
                      </span>
                    </div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      {reward.title}
                    </h3>
                    <p className="text-xs text-slate-500 font-tajawal leading-relaxed">
                      {reward.description}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRedeemStoreReward(reward)}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-colors ${
                      canAfford
                        ? 'bg-purple-700 hover:bg-purple-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    <Unlock className="w-4 h-4" />
                    <span>
                      {canAfford
                        ? `استبدال بـ ${reward.costPoints} نقطة الآن`
                        : `تحتاج ${reward.costPoints - studentPointsSummary.availableBalance} نقطة إضافية`}
                    </span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* Redemptions History Log */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              سجل جوائز ومكافآت متجر منصة الشريف المستبدلة ({storeRedemptions.length})
            </h3>
            {storeRedemptions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {storeRedemptions.map((red) => (
                  <div
                    key={red.id}
                    className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <p className="font-black text-slate-900 dark:text-white">
                        {red.rewardTitle} — للطالب: {red.studentName}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {red.targetLessonTitle ? `الدرس المفتوح: ${red.targetLessonTitle} · ` : ''}
                        الخصم: {red.costPoints} نقطة
                      </p>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono-numbers font-black">
                      {red.generatedCode}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 font-tajawal">
                لم يتم استبدال أي جوائز بعد — اختر جائزة من المتجر أعلاه لاستبدال النقاط فوراً.
              </p>
            )}
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* TAB 4: DIGITAL ENCOURAGING GIFTS VAULT                                  */}
      {/* ======================================================================= */}
      {activeMode === 'digital_gifts_vault' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-black text-slate-900 dark:text-white">
                  خزينة الهدايا الإلكترونية الرقمية التشجيعية — منصة الشريف
                </h2>
                <p className="text-xs text-slate-500 font-tajawal">
                  بطاقات وجوائز رقمية تشجيعية تُمنح للطلاب المسجلين في قاعدة البيانات عند التفوق في مسابقة الشريف.
                </p>
              </div>

              {canManage && dbStudents.length > 0 && (
                <button
                  type="button"
                  onClick={async () => {
                    const randomStu = shuffleArrayRandomly(dbStudents)[0];
                    const participantObj: CompetitionParticipant = {
                      id: randomStu.id,
                      name: randomStu.name,
                      grade: randomStu.grade,
                      score: 200,
                      correctCount: 5,
                      wrongCount: 0,
                      streak: 3,
                      giftsWon: [],
                      lifelines: { fiftyFifty: true, extraTime: true, swapQuestion: true },
                    };
                    const created = await awardDigitalGiftToStudent(
                      participantObj,
                      availableSubjects[0] || 'التفوق الأكاديمي'
                    );
                    setPreviewGiftVoucher(created);
                    playSoundEffect('gift');
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5"
                >
                  <Gift className="w-4 h-4" />
                  <span>منح هدية إلكترونية تشجيعية لطالب من القاعدة</span>
                </button>
              )}
            </div>

            {digitalGifts.length === 0 ? (
              <div className="p-10 text-center text-xs text-slate-500">
                لا توجد هدايا رقمية مسجلة بعد. ابدأ مسابقة الشريف أو امنح هدية تشجيعية الآن!
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {digitalGifts.map((gift) => (
                  <div
                    key={gift.id}
                    className="relative p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-4 overflow-hidden"
                  >
                    <AlSharifWatermark extraLabel={gift.serialCode} opacity="light" />
                    <div className="relative z-10 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-amber-700 dark:text-amber-400">
                          {gift.badgeLabel}
                        </span>
                        <span className="font-mono-numbers font-bold text-emerald-700 dark:text-emerald-400">
                          +{gift.pointsValue} نقطة
                        </span>
                      </div>
                      <h3 className="font-black text-sm text-slate-900 dark:text-white">
                        {gift.giftTitle}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-300 font-tajawal">
                        الطالب المستحق: <strong>{gift.studentName}</strong> ({gift.subject})
                      </p>
                      <p className="text-[11px] text-slate-500 font-mono-numbers">
                        كود البطاقة: {gift.serialCode} · {gift.awardedAt}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setPreviewGiftVoucher(gift)}
                      className="relative z-10 w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>معاينة وطباعة بطاقة الهدية الرقمية</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* MODAL 1: ACTIVE AL-SHARIF DOOR QUESTION STAGE WITH COUNTDOWN TIMER      */}
      {/* ======================================================================= */}
      {activeDoor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs font-cairo">
          <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border-2 border-amber-500/60 shadow-2xl overflow-hidden">
            <AlSharifWatermark extraLabel={`باب #${activeDoor.doorNumber}`} opacity="light" />

            {/* Modal Header with Timer */}
            <div className="relative z-10 p-4 md:p-5 bg-slate-900 text-white border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-amber-400 font-bold">
                  <span>مسابقة الشريف · الباب رقم #{activeDoor.doorNumber}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeDoor.subject}</span>
                  {activeDoor.sourceLessonTitle && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>درس: {activeDoor.sourceLessonTitle}</span>
                    </>
                  )}
                  <span aria-hidden="true">·</span>
                  <span>{activeDoor.points} نقطة</span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  الطالب المتسابق: <strong>{participants[currentTurnIndex]?.name}</strong>
                </p>
              </div>

              <div className="flex items-center gap-2">
                {!isDoorAnswerRevealed && (
                  <button
                    type="button"
                    onClick={() => setIsTimerPaused((p) => !p)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs"
                    title={isTimerPaused ? 'استئناف التايمر' : 'إيقاف مؤقت للتايمر'}
                  >
                    {isTimerPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  </button>
                )}

                <div
                  className={`px-3.5 py-1.5 rounded-xl font-mono-numbers font-black text-sm flex items-center gap-1.5 border ${
                    doorTimeLeft <= 7
                      ? 'bg-rose-600 text-white border-rose-400'
                      : 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  <span>{doorTimeLeft} ثانية</span>
                </div>
              </div>
            </div>

            {/* Timer Visual Bar */}
            <div className="w-full h-2 bg-slate-800 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  doorTimeLeft <= 7 ? 'bg-rose-500' : 'bg-amber-400'
                }`}
                style={{
                  width: `${Math.min(
                    100,
                    Math.round((doorTimeLeft / timerSecondsPerQuestion) * 100)
                  )}%`,
                }}
              />
            </div>

            {/* Question Body */}
            <div className="relative z-10 p-6 space-y-5">
              {!isDoorAnswerRevealed && participants[currentTurnIndex] && (
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800 text-xs">
                  <span className="font-bold text-slate-500">وسائل المساعدة في مسابقة الشريف:</span>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={!participants[currentTurnIndex].lifelines.fiftyFifty}
                      onClick={handleUseFiftyFifty}
                      className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold disabled:opacity-35 hover:bg-amber-500/20"
                    >
                      حذف إجابتين (50/50)
                    </button>
                    <button
                      type="button"
                      disabled={!participants[currentTurnIndex].lifelines.extraTime}
                      onClick={handleUseExtraTime}
                      className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold disabled:opacity-35 hover:bg-amber-500/20"
                    >
                      وقت إضافي (+15 ث)
                    </button>
                    <button
                      type="button"
                      disabled={!participants[currentTurnIndex].lifelines.swapQuestion}
                      onClick={handleUseSwapQuestion}
                      className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold disabled:opacity-35 hover:bg-amber-500/20"
                    >
                      تبديل بسؤال آخر من الدروس
                    </button>
                  </div>
                </div>
              )}

              <div className={MCQ_QUESTION_BOX_CLASS}>
                <h3 className="text-lg md:text-xl font-black text-slate-900 dark:text-slate-100 leading-relaxed">
                  {activeDoor.questionText}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {activeDoor.options.map((opt, idx) => {
                  if (hiddenOptionIndices.includes(idx)) {
                    return (
                      <div
                        key={idx}
                        className="p-3.5 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-xs text-slate-400 text-center"
                      >
                        تم استبعاد هذا الخيار (50/50)
                      </div>
                    );
                  }

                  const isCorrect = idx === activeDoor.correctOptionIndex;
                  const isPicked = chosenAnswerIdx === idx;
                  const cardCls = getMcqOptionSurfaceClass(idx, {
                    isSelected: isPicked,
                    isChecked: isDoorAnswerRevealed && (isCorrect || isPicked),
                    isCorrect,
                  });

                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={isDoorAnswerRevealed}
                      onClick={() => handleSelectDoorOption(idx)}
                      className={`p-4 rounded-xl border text-right text-xs md:text-sm font-tajawal transition-all flex items-center justify-between gap-2 ${cardCls}`}
                    >
                      <span>{opt}</span>
                      {isDoorAnswerRevealed && isCorrect && (
                        <CheckCircle2 className="w-5 h-5 shrink-0" />
                      )}
                      {isDoorAnswerRevealed && isPicked && !isCorrect && (
                        <XCircle className="w-5 h-5 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {isDoorAnswerRevealed && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                  <div className="font-black text-slate-900 dark:text-white">
                    {chosenAnswerIdx === activeDoor.correctOptionIndex
                      ? 'إجابة صحيحة وموفقة! بارك الله فيك.'
                      : doorTimeLeft === 0
                      ? 'انتهى الوقت المخصص للسؤال!'
                      : 'إجابة غير موفقة — الشرح من الدرس المسجل في القاعدة:'}
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 font-tajawal">
                    {activeDoor.explanation}
                  </p>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                {isDoorAnswerRevealed ? (
                  <button
                    type="button"
                    onClick={handleCloseDoorAndAdvanceTurn}
                    className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs"
                  >
                    الانتقال للدور التالي في مسابقة الشريف
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setActiveDoor(null)}
                    className="px-4 py-2 rounded-xl text-xs text-slate-500 hover:text-slate-700"
                  >
                    إلغاء وإغلاق الباب
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* MODAL 2: INTERACTIVE MYSTERY DIGITAL GIFT BOX                           */}
      {/* ======================================================================= */}
      {pendingGiftReward && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-md bg-slate-900 text-white rounded-2xl border-2 border-amber-400 p-6 text-center space-y-5 shadow-2xl">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center mx-auto">
              <Gift className="w-9 h-9 text-amber-400" />
            </div>

            {!pendingGiftReward.isOpened ? (
              <>
                <h3 className="text-xl font-black text-amber-400">
                  صندوق هدايا منصة الشريف الرقمية التشجيعية!
                </h3>
                <p className="text-xs text-slate-300 font-tajawal leading-relaxed">
                  أحسنت يا <strong>{pendingGiftReward.studentName}</strong>! لقد ربحت هدية إلكترونية رقمية تشجيعية في مسابقة الشريف. اضغط لفتح الصندوق الآن!
                </p>
                <button
                  type="button"
                  onClick={() => {
                    playSoundEffect('gift');
                    setPendingGiftReward((prev) => (prev ? { ...prev, isOpened: true } : null));
                    try {
                      confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
                    } catch {
                      // ignore
                    }
                  }}
                  className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm shadow-lg"
                >
                  افتح الهدية الرقمية الآن
                </button>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <span className="text-xs font-bold text-emerald-400 block">
                    {pendingGiftReward.gift.badgeLabel} · +{pendingGiftReward.gift.pointsValue} نقطة
                  </span>
                  <h3 className="text-lg font-black text-white">
                    {pendingGiftReward.gift.giftTitle}
                  </h3>
                  <p className="text-xs text-slate-300 font-tajawal">
                    {pendingGiftReward.gift.description}
                  </p>
                  <p className="text-xs font-mono-numbers text-amber-300 pt-1">
                    الكود الرقمي: {pendingGiftReward.gift.serialCode}
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      const gift = pendingGiftReward.gift;
                      setPendingGiftReward(null);
                      setPreviewGiftVoucher(gift);
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                  >
                    عرض وطباعة البطاقة
                  </button>
                  <button
                    type="button"
                    onClick={() => setPendingGiftReward(null)}
                    className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
                  >
                    متابعة المسابقة
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* MODAL 3: PRINTABLE DIGITAL GIFT VOUCHER                                 */}
      {/* ======================================================================= */}
      {previewGiftVoucher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl border-2 border-amber-500 shadow-2xl overflow-hidden">
            <div className="relative p-6 md:p-8 space-y-5 overflow-hidden">
              <AlSharifWatermark extraLabel={previewGiftVoucher.serialCode} opacity="medium" />

              <div className="relative z-10 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 block">
                    منصة الشريف التعليمية · مسابقة الشريف التفاعلية
                  </span>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">
                    بطاقة هدية إلكترونية رقمية تشجيعية معتمدة
                  </h3>
                </div>
                <Award className="w-10 h-10 text-amber-500 shrink-0" />
              </div>

              <div className="relative z-10 space-y-3 text-center py-3">
                <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                  {previewGiftVoucher.badgeLabel} (+{previewGiftVoucher.pointsValue} نقطة تفوق)
                </span>
                <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white">
                  {previewGiftVoucher.giftTitle}
                </h2>
                <p className="text-sm text-slate-700 dark:text-slate-300 font-tajawal">
                  تُمنح هذه الهدية الرقمية التشجيعية للطالب/ـة:{' '}
                  <strong className="text-emerald-700 dark:text-emerald-400">
                    {previewGiftVoucher.studentName}
                  </strong>
                </p>
                <p className="text-xs text-slate-500 font-tajawal max-w-md mx-auto">
                  {previewGiftVoucher.description}
                </p>
              </div>

              <div className="relative z-10 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2 text-xs font-mono-numbers">
                <span>الرقم التسلسلي: {previewGiftVoucher.serialCode}</span>
                <span>المادة: {previewGiftVoucher.subject}</span>
                <span>التاريخ: {previewGiftVoucher.awardedAt}</span>
              </div>

              <div className="relative z-10 flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة / حفظ PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewGiftVoucher(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* MODAL 4: ADD NEW FLASHCARD LINKED TO A REAL DATABASE LESSON             */}
      {/* ======================================================================= */}
      {isAddCardModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-cairo">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-black text-sm md:text-base text-slate-900 dark:text-white">
                إضافة بطاقة فلاش كارد مرتبطة بدرس من قاعدة البيانات
              </h3>
              <button
                type="button"
                onClick={() => setIsAddCardModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewFlashcard} className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block font-bold mb-1">اختر الدرس من قاعدة بيانات منصة الشريف</label>
                <select
                  value={newCardLessonId}
                  onChange={(e) => setNewCardLessonId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                >
                  {dbLessons.map((les) => (
                    <option key={les.id} value={les.id}>
                      {les.title} — ({les.subject} · {les.grade})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold mb-1">نص السؤال المستخلص من الدرس (وجه البطاقة)</label>
                <textarea
                  required
                  rows={2}
                  value={newCardQuestion}
                  onChange={(e) => setNewCardQuestion(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  placeholder="اكتب السؤال الدراسي المستخرج من الدرس..."
                />
              </div>

              <div>
                <label className="block font-bold mb-1 text-emerald-600">الإجابة النموذجية الصحيحة (ظهر البطاقة)</label>
                <input
                  type="text"
                  required
                  value={newCardAnswer}
                  onChange={(e) => setNewCardAnswer(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  placeholder="الإجابة الصحيحة..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block font-bold mb-1">خيار بديل 1</label>
                  <input
                    type="text"
                    value={newCardDistractor1}
                    onChange={(e) => setNewCardDistractor1(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">خيار بديل 2</label>
                  <input
                    type="text"
                    value={newCardDistractor2}
                    onChange={(e) => setNewCardDistractor2(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">خيار بديل 3</label>
                  <input
                    type="text"
                    value={newCardDistractor3}
                    onChange={(e) => setNewCardDistractor3(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">الشرح التفصيلي من الدرس</label>
                <textarea
                  rows={2}
                  value={newCardExplanation}
                  onChange={(e) => setNewCardExplanation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  placeholder="توضيح الإجابة من الدرس..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddCardModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black"
                >
                  حفظ في قاعدة البيانات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
