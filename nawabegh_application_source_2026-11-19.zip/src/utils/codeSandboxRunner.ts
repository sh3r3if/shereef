import type { CodeChallengeLanguage } from '../types/curriculum';

export interface CodeExecutionResult {
  passed: boolean;
  logs: string[];
  returnedValue: string;
  renderedHtml?: string;
  error: string | null;
  feedback: string;
}

function formatPyValue(val: unknown): string {
  if (val === true) return 'True';
  if (val === false) return 'False';
  if (val === null || val === undefined) return 'None';
  if (Array.isArray(val)) {
    return '[' + val.map((item) => (typeof item === 'string' ? `'${item}'` : formatPyValue(item))).join(', ') + ']';
  }
  return String(val);
}

/**
 * Lightweight educational Python-subset interpreter supporting:
 * variables, lists, strings, len/int/float/str/list/range, upper/lower/isdigit/isupper,
 * append/remove/sort, if/elif/else, for/while/break, def/return, try/except (ValueError & ZeroDivisionError).
 */
function executeEducationalPython(code: string): { logs: string[]; error: string | null } {
  const logs: string[] = [];

  // Runtime helper injected into sandboxed JS execution
  const pyHelpers = `
    function __pyPrint(...args) {
      __logs.push(args.map(a => {
        if (a === true) return 'True';
        if (a === false) return 'False';
        if (a === null || a === undefined) return 'None';
        if (Array.isArray(a)) return '[' + a.map(x => typeof x === 'string' ? "'" + x + "'" : String(x)).join(', ') + ']';
        return String(a);
      }).join(' '));
    }
    function len(v) { return v != null && v.length !== undefined ? v.length : 0; }
    function __pyInt(v) {
      if (typeof v === 'number') return Math.trunc(v);
      const s = String(v).trim();
      if (!/^-?\\d+(\\.\\d+)?$/.test(s)) {
        const e = new Error("ValueError: invalid literal for int(): '" + s + "'");
        e.pyType = 'ValueError';
        throw e;
      }
      return parseInt(s, 10);
    }
    function __pyFloat(v) {
      const n = Number(v);
      if (Number.isNaN(n)) {
        const e = new Error("ValueError: could not convert string to float");
        e.pyType = 'ValueError';
        throw e;
      }
      return n;
    }
    function __pyStr(v) { return String(v); }
    function __pyList(v) { return Array.isArray(v) ? [...v] : typeof v === 'string' ? v.split('') : []; }
    function range(start, stop, step = 1) {
      if (stop === undefined) { stop = start; start = 0; }
      const out = [];
      for (let i = start; step > 0 ? i < stop : i > stop; i += step) out.push(i);
      return out;
    }
    function __pyDiv(a, b) {
      if (Number(b) === 0) {
        const e = new Error("ZeroDivisionError: division by zero");
        e.pyType = 'ZeroDivisionError';
        throw e;
      }
      return a / b;
    }
    function __pyIn(needle, haystack) {
      if (typeof haystack === 'string' || Array.isArray(haystack)) return haystack.includes(needle);
      return false;
    }
    function __pyAt(col, idx) {
      if (idx < 0) return col[col.length + idx];
      return col[idx];
    }
    function input(promptText) { return "5"; }
    String.prototype.upper = function() { return this.toUpperCase(); };
    String.prototype.lower = function() { return this.toLowerCase(); };
    String.prototype.isdigit = function() { return /^\\d+$/.test(this); };
    String.prototype.isupper = function() { return this.length > 0 && this === this.toUpperCase() && this !== this.toLowerCase(); };
    Array.prototype.append = function(x) { this.push(x); };
    Array.prototype.remove = function(x) { const idx = this.indexOf(x); if (idx >= 0) this.splice(idx, 1); };
    const __origSort = Array.prototype.sort;
    Array.prototype.sort = function(fn) {
      if (fn) return __origSort.call(this, fn);
      return __origSort.call(this, (a, b) => (typeof a === 'number' && typeof b === 'number') ? a - b : String(a).localeCompare(String(b)));
    };
  `;

  // Split & translate indentation-based Python blocks into JS cleanly
  const rawLines = code.replace(/\r\n/g, '\n').split('\n');
  const outLines: string[] = [];
  const blockStack: Array<{ indent: number; kind: 'block' | 'try' | 'except' }> = [];

  const translateExpr = (expr: string): string => {
    let e = expr;
    // Strip trailing inline comments outside quotes
    let inSingle = false;
    let inDouble = false;
    for (let i = 0; i < e.length; i++) {
      const ch = e[i];
      if (ch === "'" && !inDouble) inSingle = !inSingle;
      else if (ch === '"' && !inSingle) inDouble = !inDouble;
      else if (ch === '#' && !inSingle && !inDouble) {
        e = e.slice(0, i);
        break;
      }
    }
    e = e.trim();
    if (!e) return '';

    // Support basic Python f-strings f"..." / f'...'
    e = e.replace(/\bf"([^"]*)"/g, (_, body) => '`' + body.replace(/\{([^}]+)\}/g, '${$1}') + '`');
    e = e.replace(/\bf'([^']*)'/g, (_, body) => '`' + body.replace(/\{([^}]+)\}/g, '${$1}') + '`');

    // Replace Python keywords inside expressions
    e = e
      .replace(/\bTrue\b/g, 'true')
      .replace(/\bFalse\b/g, 'false')
      .replace(/\bNone\b/g, 'null')
      .replace(/\band\b/g, '&&')
      .replace(/\bor\b/g, '||')
      .replace(/\bnot\s+/g, '!')
      .replace(/\bprint\s*\(/g, '__pyPrint(')
      .replace(/\bint\s*\(/g, '__pyInt(')
      .replace(/\bfloat\s*\(/g, '__pyFloat(')
      .replace(/\bstr\s*\(/g, '__pyStr(')
      .replace(/\blist\s*\(/g, '__pyList(');

    // Handle `x in col`
    e = e.replace(/(['"`][^'"`]+['"`]|[A-Za-z_]\w*)\s+in\s+(['"`][^'"`]+['"`]|[A-Za-z_]\w*)/g, '__pyIn($1, $2)');
    // Negative indexing like text[-1]
    e = e.replace(/([A-Za-z_]\w*)\[(-\d+)\]/g, '__pyAt($1, $2)');
    // Safe division by zero check for numeric/var division expressions not in quotes/comments
    if (!e.includes('"') && !e.includes("'") && !e.includes('`') && /\//.test(e) && !e.includes('//')) {
      e = e.replace(/([A-Za-z_0-9.()]+)\s*\/\s*([A-Za-z_0-9.()]+)/g, '__pyDiv($1, $2)');
    }
    return e;
  };

  for (let i = 0; i < rawLines.length; i++) {
    const rawLine = rawLines[i];
    const trimmed = rawLine.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    const indent = rawLine.search(/\S|$/);
    const isExcept = /^except(?:\s+([A-Za-z_]\w*))?:$/.test(trimmed);

    // Close blocks whose indent >= current line indent
    while (blockStack.length > 0 && indent <= blockStack[blockStack.length - 1].indent) {
      const top = blockStack[blockStack.length - 1];
      if (isExcept && top.indent === indent && (top.kind === 'try' || top.kind === 'except')) {
        break;
      }
      blockStack.pop();
      outLines.push('}');
      if (top.kind === 'except') {
        // Also close outer catch(__pyErr) block
        outLines.push('}');
      }
    }

    if (trimmed === 'try:') {
      outLines.push('try {');
      blockStack.push({ indent, kind: 'try' });
      continue;
    }

    if (isExcept) {
      const m = trimmed.match(/^except(?:\s+([A-Za-z_]\w*))?:$/);
      const errType = m?.[1];
      const top = blockStack[blockStack.length - 1];
      if (top && top.kind === 'try' && top.indent === indent) {
        blockStack.pop();
        outLines.push('} catch (__pyErr) {');
        if (errType) {
          outLines.push(`if (__pyErr && __pyErr.pyType === '${errType}') {`);
        } else {
          outLines.push('if (true) {');
        }
        blockStack.push({ indent, kind: 'except' });
      } else if (top && top.kind === 'except' && top.indent === indent) {
        if (errType) {
          outLines.push(`} else if (__pyErr && __pyErr.pyType === '${errType}') {`);
        } else {
          outLines.push('} else {');
        }
      }
      continue;
    }

    if (trimmed === 'else:') {
      outLines.push('else {');
      blockStack.push({ indent, kind: 'block' });
      continue;
    }

    if (trimmed.startsWith('elif ') && trimmed.endsWith(':')) {
      const cond = translateExpr(trimmed.slice(5, -1));
      outLines.push(`else if (${cond}) {`);
      blockStack.push({ indent, kind: 'block' });
      continue;
    }

    if (trimmed.startsWith('if ') && trimmed.endsWith(':')) {
      const cond = translateExpr(trimmed.slice(3, -1));
      outLines.push(`if (${cond}) {`);
      blockStack.push({ indent, kind: 'block' });
      continue;
    }

    if (trimmed.startsWith('for ') && trimmed.endsWith(':')) {
      const m = trimmed.slice(4, -1).match(/^([A-Za-z_]\w*)\s+in\s+(.+)$/);
      if (m) {
        const varName = m[1];
        const iter = translateExpr(m[2]);
        outLines.push(`for (let ${varName} of ${iter}) {`);
        blockStack.push({ indent, kind: 'block' });
        continue;
      }
    }

    if (trimmed.startsWith('while ') && trimmed.endsWith(':')) {
      const cond = translateExpr(trimmed.slice(6, -1));
      outLines.push(`let __guard_${i} = 0; while (${cond}) { if (++__guard_${i} > 500) break;`);
      blockStack.push({ indent, kind: 'block' });
      continue;
    }

    if (trimmed.startsWith('def ') && trimmed.endsWith(':')) {
      const sig = trimmed.slice(4, -1).trim();
      outLines.push(`function ${sig} {`);
      blockStack.push({ indent, kind: 'block' });
      continue;
    }

    if (trimmed === 'break') {
      outLines.push('break;');
      continue;
    }

    if (trimmed.startsWith('return ')) {
      outLines.push(`return ${translateExpr(trimmed.slice(7))};`);
      continue;
    }

    // Variable assignment `x = expr` (avoid ==, +=, -=)
    const assignMatch = trimmed.match(/^([A-Za-z_]\w*)\s*=\s*(?!=)(.+)$/);
    if (assignMatch) {
      const lhs = assignMatch[1];
      const rhs = translateExpr(assignMatch[2]);
      outLines.push(`var ${lhs} = ${rhs};`);
      continue;
    }

    outLines.push(`${translateExpr(trimmed)};`);
  }

  while (blockStack.length > 0) {
    const top = blockStack.pop()!;
    outLines.push('}');
    if (top.kind === 'except') {
      outLines.push('}');
    }
  }

  try {
    const fn = new Function('__logs', 'Math', `"use strict";\n${pyHelpers}\n${outLines.join('\n')}`);
    fn(logs, Math);
    return { logs: logs.map((l) => formatPyValue(l)), error: null };
  } catch (err: any) {
    return {
      logs,
      error: err?.message || 'خطأ في بناء جملة Python — راجع المسافات البادئة والأقواس',
    };
  }
}

/**
 * Safely executes student HTML+CSS, Python, or JavaScript/formula code
 * inside a constrained sandboxed evaluator.
 */
export function runSubjectCodeSandbox(opts: {
  code: string;
  language?: CodeChallengeLanguage;
  expectedOutputContains?: string[];
  requiredCodeSnippets?: string[];
  validationExpression?: string;
}): CodeExecutionResult {
  const trimmed = String(opts.code || '').trim();
  const lang: CodeChallengeLanguage = opts.language || 'javascript';

  if (!trimmed) {
    return {
      passed: false,
      logs: [],
      returnedValue: '',
      error: 'يرجى كتابة الكود أو إكماله أولاً قبل التشغيل.',
      feedback: 'المحرر فارغ — اكتب الكود المطلوب ثم اضغط تشغيل واختبار.',
    };
  }

  // HTML + CSS Web Design Live Mode (2nd Prep Web Lessons)
  if (lang === 'html_css') {
    const normalizedLower = trimmed.toLowerCase();
    const missingSnippets = (opts.requiredCodeSnippets || []).filter(
      (snip) => !normalizedLower.includes(snip.toLowerCase())
    );
    const missingExpected = (opts.expectedOutputContains || []).filter(
      (exp) => !trimmed.includes(exp) && !normalizedLower.includes(exp.toLowerCase())
    );

    const passed = missingSnippets.length === 0 && missingExpected.length === 0;
    const htmlDocument = trimmed.includes('<html')
      ? trimmed
      : `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>body{font-family:sans-serif;padding:12px;margin:0;}</style></head><body>${trimmed}</body></html>`;

    return {
      passed,
      logs: [passed ? '✓ تم بناء ومعاينة صفحة الويب بالتنسيقات بنجاح.' : 'راجع وسوم HTML أو خصائص CSS المطلوبة.'],
      returnedValue: passed ? 'HTML/CSS Verified' : '',
      renderedHtml: htmlDocument,
      error: null,
      feedback: passed
        ? '✓ أحسنت! كود HTML/CSS سليم وحقق جميع العناصر والتنسيقات المطلوبة.'
        : `تأكد من كتابة العناصر/الخصائص المطلوبة: (${[...missingSnippets, ...missingExpected].join(' , ')})`,
    };
  }

  // Block dangerous globals for script modes
  const forbiddenPattern =
    /\b(window|document|fetch|XMLHttpRequest|WebSocket|localStorage|sessionStorage|eval|Function|import|require|process|globalThis)\b/;
  if (forbiddenPattern.test(trimmed)) {
    return {
      passed: false,
      logs: [],
      returnedValue: '',
      error: 'الكود يحتوي على دوال غير مسموح بها داخل بيئة المحاكاة التعليمية.',
      feedback: 'استخدم فقط المتغيرات والعمليات والحلقات والدوال التعليمية.',
    };
  }

  // Python Educational Interpreter Mode (3rd Prep Python Lessons)
  if (lang === 'python') {
    const pyRes = executeEducationalPython(trimmed);
    if (pyRes.error) {
      return {
        passed: false,
        logs: pyRes.logs,
        returnedValue: '',
        error: pyRes.error,
        feedback: 'يوجد خطأ في تنفيذ كود Python — تأكد من النقطتين (:) والمسافات البادئة والأقواس.',
      };
    }

    const combinedOutput = pyRes.logs.join('\n');
    const missingItems = (opts.expectedOutputContains || []).filter(
      (exp) => !combinedOutput.includes(exp)
    );
    const missingSnippets = (opts.requiredCodeSnippets || []).filter(
      (snip) => !trimmed.includes(snip)
    );

    const passed = missingItems.length === 0 && missingSnippets.length === 0;
    return {
      passed,
      logs: pyRes.logs,
      returnedValue: pyRes.logs[pyRes.logs.length - 1] || '',
      error: null,
      feedback: passed
        ? '✓ ممتاز! كود Python نُفّذ بنجاح وحقق المخرجات المطلوبة.'
        : missingSnippets.length > 0
        ? `تأكد من استخدام الصيغة البرمجية المطلوبة: (${missingSnippets.join(' , ')})`
        : `تأكد من أن ناتج الطباعة print يتضمن: (${missingItems.join(' , ')})`,
    };
  }

  // JavaScript / Scientific Formula Mode
  const logs: string[] = [];
  const sandboxConsole = {
    log: (...args: unknown[]) => {
      logs.push(
        args
          .map((a) =>
            typeof a === 'object' && a !== null ? JSON.stringify(a) : String(a)
          )
          .join(' ')
      );
    },
  };

  try {
    const fn = new Function('console', 'Math', `"use strict";\n${trimmed}`);
    const result = fn(sandboxConsole, Math);
    const returnedStr =
      result === undefined
        ? ''
        : typeof result === 'object' && result !== null
        ? JSON.stringify(result)
        : String(result);

    const combinedOutput = [...logs, returnedStr].filter(Boolean).join('\n');

    let passed = true;
    const missingItems: string[] = [];

    if (opts.expectedOutputContains && opts.expectedOutputContains.length > 0) {
      for (const expected of opts.expectedOutputContains) {
        if (!combinedOutput.includes(expected)) {
          passed = false;
          missingItems.push(expected);
        }
      }
    }

    if (passed && opts.validationExpression) {
      const checkFn = new Function(
        'logs',
        'output',
        'returned',
        `"use strict"; return Boolean(${opts.validationExpression});`
      );
      passed = checkFn(logs, combinedOutput, result);
    }

    return {
      passed,
      logs,
      returnedValue: returnedStr,
      error: null,
      feedback: passed
        ? '✓ أحسنت! مخرجات الكود مطابقة تماماً للمطلوب العلمي في هذا الدرس.'
        : missingItems.length > 0
        ? `النتيجة غير مطابقة بعد — تأكد أن المخرجات تتضمن: (${missingItems.join(' , ')})`
        : 'مخرجات الكود لم تحقق شرط الاختبار العلمي بعد، راجع المعادلة أو الشرط وحاول مجدداً.',
    };
  } catch (err: any) {
    return {
      passed: false,
      logs,
      returnedValue: '',
      error: err?.message || 'خطأ برمجي أثناء تنفيذ الكود',
      feedback: 'يوجد خطأ صياغي (Syntax/Runtime Error) في الكود — راجع الأقواس وأسماء المتغيرات.',
    };
  }
}
