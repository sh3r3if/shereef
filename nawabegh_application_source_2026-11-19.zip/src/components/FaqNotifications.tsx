import React, { useState, useMemo } from 'react';
import {
  FileQuestion,
  Bell,
  Search,
  ChevronDown,
  Plus,
  Send,
  CheckCircle2,
  HelpCircle,
  MessageSquare,
  Edit,
  Trash2,
  Eye,
  X,
  Tag,
  Calendar,
  RefreshCw,
  Filter,
  RotateCcw,
  User,
  Phone,
  AlertCircle,
  CheckCheck,
  Clock,
  Sparkles,
  Inbox,
  ShieldAlert,
  Target,
  Users,
} from 'lucide-react';
import { FaqItem, AppNotification, InquiryItem, Language, CurrentUser } from '../types';
import { getAuthHeaders, isAdminStaffRole, isParentRole } from '../utils/rbac';

interface FaqNotificationsProps {
  faqs: FaqItem[];
  notifications: AppNotification[];
  inquiries: InquiryItem[];
  currentUserName?: string;
  currentUser?: CurrentUser | null;
  onAddFaq?: (faq: Omit<FaqItem, 'id'>) => Promise<any> | any;
  onUpdateFaq?: (faq: FaqItem) => Promise<any> | any;
  onDeleteFaq?: (id: string) => Promise<any> | any;
  onAddNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => Promise<any> | any;
  onUpdateNotification?: (notif: AppNotification) => Promise<any> | any;
  onDeleteNotification?: (id: string) => Promise<any> | any;
  onAddInquiry?: (inq: Omit<InquiryItem, 'id' | 'createdAt'>) => Promise<any> | any;
  onUpdateInquiry?: (inq: InquiryItem) => Promise<any> | any;
  onDeleteInquiry?: (id: string) => Promise<any> | any;
  onRefreshAll?: () => Promise<{
    faqs: FaqItem[];
    notifications: AppNotification[];
    inquiries: InquiryItem[];
  }>;
  language: Language;
}

type ActiveCenterTab = 'faqs' | 'inquiries' | 'notifications';

export const FaqNotifications: React.FC<FaqNotificationsProps> = ({
  faqs,
  notifications,
  inquiries,
  currentUserName = 'الإدارة الأكاديمية',
  currentUser = null,
  onAddFaq,
  onUpdateFaq,
  onDeleteFaq,
  onAddNotification,
  onUpdateNotification,
  onDeleteNotification,
  onAddInquiry,
  onUpdateInquiry,
  onDeleteInquiry,
  onRefreshAll,
  language,
}) => {
  const isAr = language === 'ar';
  const role = currentUser?.role;
  const canAdminManageCenter = currentUser
    ? Boolean(currentUser.isSuperAdmin) || isAdminStaffRole(role)
    : true;
  const isParent = isParentRole(role);
  const canSubmitInquiry = canAdminManageCenter || isParent;

  const [activeTab, setActiveTab] = useState<ActiveCenterTab>('faqs');
  const [searchQuery, setSearchQuery] = useState('');

  // Tab-specific filters
  const [faqCategoryFilter, setFaqCategoryFilter] = useState<string>('all');

  const [inquiryStatusFilter, setInquiryStatusFilter] = useState<string>('all');
  const [inquiryPriorityFilter, setInquiryPriorityFilter] = useState<string>('all');
  const [inquiryCategoryFilter, setInquiryCategoryFilter] = useState<string>('all');

  const [notifCategoryFilter, setNotifCategoryFilter] = useState<string>('all');
  const [notifTargetFilter, setNotifTargetFilter] = useState<string>('all');
  const [notifReadFilter, setNotifReadFilter] = useState<'all' | 'unread' | 'read'>('all');

  const [openFaqId, setOpenFaqId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    setTimeout(() => {
      setToast((prev) => (prev?.text === text ? null : prev));
    }, 4000);
  };

  // Quick Direct Inquiry Box (bottom of FAQs tab) — persisted to DB
  const [quickSenderName, setQuickSenderName] = useState(currentUser?.name || currentUserName || '');
  const [quickSenderRole, setQuickSenderRole] = useState<InquiryItem['senderRole']>(
    isParent ? 'parent' : 'student'
  );
  const [quickSenderContact, setQuickSenderContact] = useState('');
  const [quickSubject, setQuickSubject] = useState('');
  const [quickMessage, setQuickMessage] = useState('');
  const [quickCategory, setQuickCategory] = useState<InquiryItem['category']>(
    isParent ? 'complaint' : 'general'
  );
  const [quickPriority, setQuickPriority] = useState<InquiryItem['priority']>('normal');

  React.useEffect(() => {
    setQuickSenderName(currentUser?.name || currentUserName || '');
    if (isParent) {
      setQuickSenderRole('parent');
      setQuickCategory((prev) => (prev === 'general' ? 'complaint' : prev));
    }
  }, [currentUser?.name, currentUser?.role, currentUserName, isParent]);

  // FAQ Modals
  const [isFaqModalOpen, setIsFaqModalOpen] = useState(false);
  const [editingFaq, setEditingFaq] = useState<FaqItem | null>(null);
  const [viewingFaq, setViewingFaq] = useState<FaqItem | null>(null);
  const [deletingFaq, setDeletingFaq] = useState<FaqItem | null>(null);

  const [faqQuestionAr, setFaqQuestionAr] = useState('');
  const [faqQuestionEn, setFaqQuestionEn] = useState('');
  const [faqAnswerAr, setFaqAnswerAr] = useState('');
  const [faqAnswerEn, setFaqAnswerEn] = useState('');
  const [faqCategory, setFaqCategory] = useState('academic');

  // Inquiry Modals (Add / Edit / Official Reply / Details / Delete)
  const [isInquiryModalOpen, setIsInquiryModalOpen] = useState(false);
  const [editingInquiry, setEditingInquiry] = useState<InquiryItem | null>(null);
  const [viewingInquiry, setViewingInquiry] = useState<InquiryItem | null>(null);
  const [deletingInquiry, setDeletingInquiry] = useState<InquiryItem | null>(null);

  const [inqSenderName, setInqSenderName] = useState('');
  const [inqSenderRole, setInqSenderRole] = useState<InquiryItem['senderRole']>('parent');
  const [inqSenderContact, setInqSenderContact] = useState('');
  const [inqSubject, setInqSubject] = useState('');
  const [inqMessage, setInqMessage] = useState('');
  const [inqCategory, setInqCategory] = useState<InquiryItem['category']>('academic');
  const [inqPriority, setInqPriority] = useState<InquiryItem['priority']>('normal');
  const [inqStatus, setInqStatus] = useState<InquiryItem['status']>('pending');
  const [inqReplyText, setInqReplyText] = useState('');
  const [inqRepliedBy, setInqRepliedBy] = useState(currentUserName);

  // Notification Modals
  const [isBroadcastOpen, setIsBroadcastOpen] = useState(false);
  const [editingNotif, setEditingNotif] = useState<AppNotification | null>(null);
  const [viewingNotif, setViewingNotif] = useState<AppNotification | null>(null);
  const [deletingNotif, setDeletingNotif] = useState<AppNotification | null>(null);

  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifTarget, setNotifTarget] = useState<AppNotification['target']>('parents');
  const [notifCategory, setNotifCategory] = useState<AppNotification['category']>('academic');
  const [notifRead, setNotifRead] = useState(false);

  // Targeted Broadcast Campaign Metadata & Controls
  const [notifMetaMap, setNotifMetaMap] = useState<
    Record<
      string,
      {
        targetGrade?: string;
        targetSubject?: string;
        targetEnrollmentType?: string;
        targetCondition?: string;
        recipientsCount?: number;
      }
    >
  >({});
  const [isTargetedMode, setIsTargetedMode] = useState(false);
  const [campGrade, setCampGrade] = useState('all');
  const [campEnrollmentType, setCampEnrollmentType] = useState<'all' | 'online' | 'offline'>('all');
  const [campCondition, setCampCondition] = useState<'all' | 'expiring_codes' | 'at_risk'>('all');

  React.useEffect(() => {
    fetch('/api/notifications/targeted-meta')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.meta) setNotifMetaMap(data.meta);
      })
      .catch(() => {});
  }, [notifications.length]);

  // Live Stats
  const pendingInquiriesCount = useMemo(
    () => inquiries.filter((i) => i.status === 'pending').length,
    [inquiries]
  );
  const unreadNotifsCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  // Labels helpers
  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'academic':
        return isAr ? 'أكاديمي ومناهج' : 'Academic';
      case 'financial':
        return isAr ? 'مالي واشتراكات' : 'Financial';
      case 'technical':
        return isAr ? 'تقني ومنصة' : 'Technical';
      case 'attendance':
        return isAr ? 'حضور وغياب' : 'Attendance';
      case 'suggestion':
        return isAr ? 'اقتراح تطويري' : 'Suggestion';
      case 'complaint':
        return isAr ? 'شكوى رسمية' : 'Complaint';
      default:
        return isAr ? 'عام وإرشادي' : 'General';
    }
  };

  const getTargetLabel = (target: AppNotification['target']) => {
    switch (target) {
      case 'all':
        return isAr ? 'الجميع' : 'Everyone';
      case 'parents':
        return isAr ? 'أولياء الأمور' : 'Parents';
      case 'students':
        return isAr ? 'الطلاب' : 'Students';
      case 'students_parents':
        return isAr ? 'الطلاب والطالبات وأولياء الأمور' : 'Students & Parents';
      case 'weak_students':
        return isAr ? 'أولياء أمور الضعاف' : 'Weak Students Parents';
      case 'top_students':
        return isAr ? 'أولياء أمور الفائقين' : 'Top Students Parents';
      default:
        return target;
    }
  };

  const getRoleLabel = (role: InquiryItem['senderRole']) => {
    switch (role) {
      case 'parent':
        return isAr ? 'ولي أمر' : 'Parent';
      case 'teacher':
        return isAr ? 'معلم' : 'Teacher';
      case 'visitor':
        return isAr ? 'زائر' : 'Visitor';
      default:
        return isAr ? 'طالب' : 'Student';
    }
  };

  const getPriorityBadge = (priority: InquiryItem['priority']) => {
    switch (priority) {
      case 'urgent':
        return {
          label: isAr ? 'عاجل' : 'Urgent',
          cls: 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300 border-rose-200 dark:border-rose-800',
        };
      case 'high':
        return {
          label: isAr ? 'مرتفع' : 'High',
          cls: 'bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 border-amber-200 dark:border-amber-800',
        };
      case 'low':
        return {
          label: isAr ? 'منخفض' : 'Low',
          cls: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
        };
      default:
        return {
          label: isAr ? 'عادي' : 'Normal',
          cls: 'bg-sky-100 text-sky-700 dark:bg-sky-950/70 dark:text-sky-300 border-sky-200 dark:border-sky-800',
        };
    }
  };

  const getStatusBadge = (status: InquiryItem['status']) => {
    switch (status) {
      case 'answered':
        return {
          label: isAr ? 'تم الرد' : 'Answered',
          cls: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
        };
      case 'closed':
        return {
          label: isAr ? 'مغلق' : 'Closed',
          cls: 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-300 dark:border-slate-700',
        };
      default:
        return {
          label: isAr ? 'قيد الانتظار' : 'Pending',
          cls: 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border-amber-200 dark:border-amber-800',
        };
    }
  };

  // Filtered Lists
  const filteredFaqs = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return faqs.filter((f) => {
      if (faqCategoryFilter !== 'all' && f.category !== faqCategoryFilter) return false;
      if (!q) return true;
      return [f.questionAr, f.questionEn, f.answerAr, f.answerEn, f.category]
        .filter(Boolean)
        .some((val) => val.toLowerCase().includes(q));
    });
  }, [faqs, searchQuery, faqCategoryFilter]);

  const filteredInquiries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return inquiries.filter((inq) => {
      if (inquiryStatusFilter !== 'all' && inq.status !== inquiryStatusFilter) return false;
      if (inquiryPriorityFilter !== 'all' && inq.priority !== inquiryPriorityFilter) return false;
      if (inquiryCategoryFilter !== 'all' && inq.category !== inquiryCategoryFilter) return false;
      if (!q) return true;
      return [
        inq.senderName,
        inq.senderContact,
        inq.subject,
        inq.message,
        inq.replyText,
        inq.repliedBy,
        inq.category,
      ]
        .filter(Boolean)
        .some((val) => String(val).toLowerCase().includes(q));
    });
  }, [inquiries, searchQuery, inquiryStatusFilter, inquiryPriorityFilter, inquiryCategoryFilter]);

  const filteredNotifications = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return notifications.filter((notif) => {
      if (notifCategoryFilter !== 'all' && notif.category !== notifCategoryFilter) return false;
      if (notifTargetFilter !== 'all' && notif.target !== notifTargetFilter) return false;
      if (notifReadFilter === 'read' && !notif.read) return false;
      if (notifReadFilter === 'unread' && notif.read) return false;
      if (!q) return true;
      return [notif.title, notif.message, notif.target, notif.category, notif.createdAt]
        .filter(Boolean)
        .some((val) => val.toLowerCase().includes(q));
    });
  }, [notifications, searchQuery, notifCategoryFilter, notifTargetFilter, notifReadFilter]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setFaqCategoryFilter('all');
    setInquiryStatusFilter('all');
    setInquiryPriorityFilter('all');
    setInquiryCategoryFilter('all');
    setNotifCategoryFilter('all');
    setNotifTargetFilter('all');
    setNotifReadFilter('all');
  };

  const handleSyncDatabase = async () => {
    if (!onRefreshAll) return;
    setIsRefreshing(true);
    try {
      await onRefreshAll();
      showToast('success', isAr ? 'تم تحديث كافة البيانات من قاعدة البيانات بنجاح' : 'Synced with database');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر الاتصال بقاعدة البيانات' : 'Sync failed'));
    } finally {
      setIsRefreshing(false);
    }
  };

  // ---------------- Quick Inquiry Form Submit (persisted) ----------------
  const handleQuickInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onAddInquiry) return;
    if (!quickSubject.trim() || !quickMessage.trim()) {
      showToast('error', isAr ? 'يرجى إدخال عنوان الاستفسار والتفاصيل' : 'Subject and message required');
      return;
    }
    setIsSubmitting(true);
    try {
      await onAddInquiry({
        senderName: quickSenderName.trim() || currentUserName || 'مستخدم المنصة',
        senderRole: quickSenderRole,
        senderContact: quickSenderContact.trim(),
        subject: quickSubject.trim(),
        message: quickMessage.trim(),
        category: quickCategory,
        priority: quickPriority,
        status: 'pending',
        replyText: '',
        repliedBy: '',
        repliedAt: '',
      });
      setQuickSubject('');
      setQuickMessage('');
      setQuickSenderContact('');
      showToast('success', isAr ? 'تم تسجيل استفسارك وحفظه في قاعدة البيانات بنجاح' : 'Inquiry saved to database');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حفظ الاستفسار' : 'Failed to save inquiry'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // ---------------- FAQ Handlers ----------------
  const handleOpenAddFaq = () => {
    setEditingFaq(null);
    setFaqQuestionAr('');
    setFaqQuestionEn('');
    setFaqAnswerAr('');
    setFaqAnswerEn('');
    setFaqCategory('academic');
    setIsFaqModalOpen(true);
  };

  const handleOpenEditFaq = (faq: FaqItem) => {
    setEditingFaq(faq);
    setFaqQuestionAr(faq.questionAr);
    setFaqQuestionEn(faq.questionEn || '');
    setFaqAnswerAr(faq.answerAr);
    setFaqAnswerEn(faq.answerEn || '');
    setFaqCategory(faq.category || 'general');
    setIsFaqModalOpen(true);
  };

  const handleSaveFaq = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!faqQuestionAr.trim() || !faqAnswerAr.trim()) return;
    setIsSubmitting(true);
    try {
      if (editingFaq && onUpdateFaq) {
        const updated = await onUpdateFaq({
          ...editingFaq,
          questionAr: faqQuestionAr.trim(),
          questionEn: faqQuestionEn.trim() || faqQuestionAr.trim(),
          answerAr: faqAnswerAr.trim(),
          answerEn: faqAnswerEn.trim() || faqAnswerAr.trim(),
          category: faqCategory,
        });
        if (viewingFaq?.id === editingFaq.id && updated) {
          setViewingFaq(updated);
        }
        showToast('success', isAr ? 'تم تحديث السؤال الشائع في قاعدة البيانات' : 'FAQ updated');
      } else if (onAddFaq) {
        await onAddFaq({
          questionAr: faqQuestionAr.trim(),
          questionEn: faqQuestionEn.trim() || faqQuestionAr.trim(),
          answerAr: faqAnswerAr.trim(),
          answerEn: faqAnswerEn.trim() || faqAnswerAr.trim(),
          category: faqCategory,
        });
        showToast('success', isAr ? 'تمت إضافة السؤال الشائع وحفظه في قاعدة البيانات' : 'FAQ added');
      }
      setIsFaqModalOpen(false);
      setEditingFaq(null);
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'فشل حفظ السؤال الشائع' : 'Failed to save FAQ'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const confirmDeleteFaq = async () => {
    if (!deletingFaq || !onDeleteFaq) return;
    setIsSubmitting(true);
    try {
      await onDeleteFaq(deletingFaq.id);
      if (viewingFaq?.id === deletingFaq.id) setViewingFaq(null);
      setDeletingFaq(null);
      showToast('success', isAr ? 'تم حذف السؤال الشائع من قاعدة البيانات' : 'FAQ deleted');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حذف السؤال' : 'Failed to delete FAQ'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // ---------------- Inquiry Handlers ----------------
  const handleOpenAddInquiry = () => {
    setEditingInquiry(null);
    setInqSenderName(currentUser?.name || currentUserName || '');
    setInqSenderRole('parent');
    setInqSenderContact('');
    setInqSubject('');
    setInqMessage('');
    setInqCategory(isParent ? 'complaint' : 'academic');
    setInqPriority('normal');
    setInqStatus('pending');
    setInqReplyText('');
    setInqRepliedBy(currentUserName || 'الإدارة الأكاديمية');
    setIsInquiryModalOpen(true);
  };

  const handleOpenEditInquiry = (inq: InquiryItem) => {
    setEditingInquiry(inq);
    setInqSenderName(inq.senderName);
    setInqSenderRole(inq.senderRole);
    setInqSenderContact(inq.senderContact || '');
    setInqSubject(inq.subject);
    setInqMessage(inq.message);
    setInqCategory(inq.category);
    setInqPriority(inq.priority);
    setInqStatus(inq.status);
    setInqReplyText(inq.replyText || '');
    setInqRepliedBy(inq.repliedBy || currentUserName || 'الإدارة الأكاديمية');
    setIsInquiryModalOpen(true);
  };

  const handleSaveInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inqSubject.trim() || !inqMessage.trim()) return;
    setIsSubmitting(true);
    try {
      const hasReply = Boolean(inqReplyText.trim());
      const resolvedStatus: InquiryItem['status'] =
        hasReply && inqStatus === 'pending' ? 'answered' : inqStatus;

      if (editingInquiry && onUpdateInquiry) {
        const updated = await onUpdateInquiry({
          ...editingInquiry,
          senderName: inqSenderName.trim() || 'مستخدم المنصة',
          senderRole: inqSenderRole,
          senderContact: inqSenderContact.trim(),
          subject: inqSubject.trim(),
          message: inqMessage.trim(),
          category: inqCategory,
          priority: inqPriority,
          status: resolvedStatus,
          replyText: inqReplyText.trim(),
          repliedBy: hasReply ? inqRepliedBy.trim() || currentUserName : '',
        });
        if (viewingInquiry?.id === editingInquiry.id && updated) {
          setViewingInquiry(updated);
        }
        showToast('success', isAr ? 'تم حفظ التعديلات والرد الرسمي في قاعدة البيانات' : 'Inquiry updated');
      } else if (onAddInquiry) {
        await onAddInquiry({
          senderName: inqSenderName.trim() || currentUserName || 'مستخدم المنصة',
          senderRole: inqSenderRole,
          senderContact: inqSenderContact.trim(),
          subject: inqSubject.trim(),
          message: inqMessage.trim(),
          category: inqCategory,
          priority: inqPriority,
          status: resolvedStatus,
          replyText: inqReplyText.trim(),
          repliedBy: hasReply ? inqRepliedBy.trim() || currentUserName : '',
        });
        showToast('success', isAr ? 'تمت إضافة الاستفسار وحفظه في قاعدة البيانات' : 'Inquiry added');
      }
      setIsInquiryModalOpen(false);
      setEditingInquiry(null);
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حفظ الاستفسار' : 'Failed to save inquiry'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const confirmDeleteInquiry = async () => {
    if (!deletingInquiry || !onDeleteInquiry) return;
    setIsSubmitting(true);
    try {
      await onDeleteInquiry(deletingInquiry.id);
      if (viewingInquiry?.id === deletingInquiry.id) setViewingInquiry(null);
      setDeletingInquiry(null);
      showToast('success', isAr ? 'تم حذف الاستفسار من قاعدة البيانات' : 'Inquiry deleted');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حذف الاستفسار' : 'Failed to delete inquiry'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePromoteInquiryToFaq = async (inq: InquiryItem) => {
    if (!onAddFaq) return;
    if (!inq.replyText?.trim()) {
      showToast('error', isAr ? 'يرجى كتابة رد رسمي أولاً قبل التحويل إلى الأسئلة الشائعة' : 'Add a reply before promoting');
      return;
    }
    setIsSubmitting(true);
    try {
      await onAddFaq({
        questionAr: inq.subject,
        questionEn: inq.subject,
        answerAr: inq.replyText,
        answerEn: inq.replyText,
        category: inq.category === 'technical' || inq.category === 'financial' || inq.category === 'academic' ? inq.category : 'general',
      });
      showToast('success', isAr ? 'تم نشر الاستفسار وإجابته ضمن الأسئلة الشائعة بنجاح' : 'Promoted to FAQ');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر التحويل إلى سؤال شائع' : 'Promotion failed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // ---------------- Notification Handlers ----------------
  const handleOpenAddNotif = () => {
    setEditingNotif(null);
    setNotifTitle('');
    setNotifMessage('');
    setNotifTarget('parents');
    setNotifCategory('academic');
    setNotifRead(false);
    setIsTargetedMode(false);
    setCampGrade('all');
    setCampEnrollmentType('all');
    setCampCondition('all');
    setIsBroadcastOpen(true);
  };

  const handleOpenEditNotif = (notif: AppNotification) => {
    setEditingNotif(notif);
    setNotifTitle(notif.title);
    setNotifMessage(notif.message);
    setNotifTarget(notif.target);
    setNotifCategory(notif.category);
    setNotifRead(Boolean(notif.read));
    setIsBroadcastOpen(true);
  };

  const handleSaveBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifMessage.trim()) return;
    setIsSubmitting(true);
    try {
      if (editingNotif && onUpdateNotification) {
        const updated = await onUpdateNotification({
          ...editingNotif,
          title: notifTitle.trim(),
          message: notifMessage.trim(),
          target: notifTarget,
          category: notifCategory,
          read: notifRead,
        });
        if (viewingNotif?.id === editingNotif.id && updated) {
          setViewingNotif(updated);
        }
        showToast('success', isAr ? 'تم تحديث الإشعار الدوري في قاعدة البيانات' : 'Notification updated');
      } else if (isTargetedMode) {
        const res = await fetch('/api/notifications/targeted-campaign', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getAuthHeaders(currentUser, []),
          },
          body: JSON.stringify({
            title: notifTitle.trim(),
            message: notifMessage.trim(),
            target: notifTarget,
            category: notifCategory,
            targetGrade: campGrade,
            targetEnrollmentType: campEnrollmentType,
            targetCondition: campCondition,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'تعذر إطلاق الحملة المستهدفة');
        if (data.notification?.id) {
          setNotifMetaMap((prev) => ({
            ...prev,
            [data.notification.id]: {
              targetGrade: campGrade,
              targetEnrollmentType: campEnrollmentType,
              targetCondition: campCondition,
              recipientsCount: data.matchedCount,
            },
          }));
        }
        if (onRefreshAll) await onRefreshAll();
        showToast(
          'success',
          isAr
            ? `تم إرسال الحملة المستهدفة إلى ${data.matchedCount ?? 0} طالب مطابق للشروط وحفظها ✓`
            : `Targeted campaign sent to ${data.matchedCount ?? 0} recipients ✓`
        );
      } else {
        await onAddNotification({
          title: notifTitle.trim(),
          message: notifMessage.trim(),
          target: notifTarget,
          category: notifCategory,
        });
        showToast('success', isAr ? 'تم بث الإشعار وحفظه في قاعدة البيانات بنجاح' : 'Notification sent');
      }
      setNotifTitle('');
      setNotifMessage('');
      setIsBroadcastOpen(false);
      setEditingNotif(null);
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حفظ الإشعار' : 'Failed to save notification'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleNotifRead = async (notif: AppNotification) => {
    if (!onUpdateNotification) return;
    try {
      const updated = await onUpdateNotification({ ...notif, read: !notif.read });
      if (viewingNotif?.id === notif.id && updated) {
        setViewingNotif(updated);
      }
      showToast(
        'success',
        !notif.read
          ? isAr
            ? 'تم تحديد الإشعار كمقروء'
            : 'Marked as read'
          : isAr
          ? 'تم تحديد الإشعار كغير مقروء'
          : 'Marked as unread'
      );
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر تحديث حالة القراءة' : 'Failed to update'));
    }
  };

  const confirmDeleteNotif = async () => {
    if (!deletingNotif || !onDeleteNotification) return;
    setIsSubmitting(true);
    try {
      await onDeleteNotification(deletingNotif.id);
      if (viewingNotif?.id === deletingNotif.id) setViewingNotif(null);
      setDeletingNotif(null);
      showToast('success', isAr ? 'تم حذف الإشعار من قاعدة البيانات' : 'Notification deleted');
    } catch (err: any) {
      showToast('error', err?.message || (isAr ? 'تعذر حذف الإشعار' : 'Failed to delete notification'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2.5 font-cairo">
            <HelpCircle className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>{isAr ? 'مركز الاستفسارات والإشعارات الدورية' : 'Inquiries & Periodic Alerts Center'}</span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1 font-tajawal">
            {isAr
              ? 'إدارة متصلة مباشرة بقاعدة البيانات: إضافة، تعديل، حذف، بحث متقدم، ورد رسمي على الاستفسارات والإشعارات الدورية بدون أي بيانات وهمية'
              : 'Database-backed knowledge base, direct inquiries with official replies, and periodic notifications'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 font-cairo">
          {onRefreshAll && (
            <button
              onClick={handleSyncDatabase}
              disabled={isRefreshing}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-600' : ''}`} />
              <span>{isAr ? 'تحديث من الداتا بيز' : 'Sync DB'}</span>
            </button>
          )}

          {canAdminManageCenter && activeTab === 'faqs' && onAddFaq && (
            <button
              onClick={handleOpenAddFaq}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة سؤال شائع' : 'Add FAQ'}</span>
            </button>
          )}

          {canSubmitInquiry && activeTab === 'inquiries' && onAddInquiry && (
            <button
              onClick={handleOpenAddInquiry}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>
                {isParent
                  ? isAr
                    ? 'إرسال اقتراح أو شكوى للأدمن'
                    : 'Send Suggestion / Complaint'
                  : isAr
                  ? 'تسجيل استفسار جديد'
                  : 'New Inquiry'}
              </span>
            </button>
          )}

          {canAdminManageCenter && activeTab === 'notifications' && (
            <button
              onClick={handleOpenAddNotif}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs md:text-sm text-white bg-amber-600 hover:bg-amber-700 transition-colors shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إرسال إشعار دوري جديد' : 'Broadcast Alert'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div
          className={`flex items-center justify-between gap-3 px-4 py-3 rounded-xl border text-xs md:text-sm font-bold font-cairo shadow-xs ${
            toast.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
            )}
            <span>{toast.text}</span>
          </div>
          <button onClick={() => setToast(null)} className="p-1 opacity-70 hover:opacity-100 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Live Database KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => setActiveTab('faqs')}
          className={`text-right p-4 rounded-2xl border transition-all cursor-pointer ${
            activeTab === 'faqs'
              ? 'bg-indigo-50/70 dark:bg-indigo-950/30 border-indigo-300 dark:border-indigo-700 shadow-xs'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 font-cairo">
              {isAr ? 'الأسئلة الشائعة المعتمدة' : 'Knowledge Base FAQs'}
            </span>
            <FileQuestion className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1.5 font-mono">
            {faqs.length}
          </p>
        </button>

        <button
          onClick={() => setActiveTab('inquiries')}
          className={`text-right p-4 rounded-2xl border transition-all cursor-pointer ${
            activeTab === 'inquiries'
              ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-700 shadow-xs'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-emerald-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 font-cairo">
              {isAr ? 'الاستفسارات المباشرة' : 'Direct Inquiries'}
            </span>
            <Inbox className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2.5 mt-1.5">
            <p className="text-2xl font-black text-slate-900 dark:text-white font-mono">
              {inquiries.length}
            </p>
            {pendingInquiriesCount > 0 && (
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-cairo">
                {pendingInquiriesCount} {isAr ? 'بانتظار الرد' : 'pending'}
              </span>
            )}
          </div>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`text-right p-4 rounded-2xl border transition-all cursor-pointer ${
            activeTab === 'notifications'
              ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-300 dark:border-amber-700 shadow-xs'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-amber-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 font-cairo">
              {isAr ? 'الإشعارات الدورية' : 'Periodic Notifications'}
            </span>
            <Bell className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2.5 mt-1.5">
            <p className="text-2xl font-black text-slate-900 dark:text-white font-mono">
              {notifications.length}
            </p>
            {unreadNotifsCount > 0 && (
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 font-cairo">
                {unreadNotifsCount} {isAr ? 'غير مقروء' : 'unread'}
              </span>
            )}
          </div>
        </button>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit font-cairo">
        <button
          onClick={() => setActiveTab('faqs')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'faqs'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <FileQuestion className="w-4 h-4 text-indigo-500" />
          <span>{isAr ? 'الأسئلة الشائعة' : 'FAQs'}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-mono text-[11px]">
            {faqs.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('inquiries')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'inquiries'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <MessageSquare className="w-4 h-4 text-emerald-500" />
          <span>{isAr ? 'الاستفسارات المباشرة والردود' : 'Inquiries & Replies'}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-mono text-[11px]">
            {inquiries.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'notifications'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Bell className="w-4 h-4 text-amber-500" />
          <span>{isAr ? 'الإشعارات الدورية' : 'Notifications'}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 font-mono text-[11px]">
            {notifications.length}
          </span>
        </button>
      </div>

      {/* ==================== TAB 1: FAQs ==================== */}
      {activeTab === 'faqs' && (
        <div className="space-y-6">
          {/* Search + Category Filter Bar */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row gap-3 items-stretch md:items-center">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isAr ? 'ابحث في الأسئلة الشائعة، الأجوبة، أو التصنيف...' : 'Search FAQs...'}
                className="w-full pl-3 pr-9 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-tajawal"
              />
            </div>

            <div className="flex items-center gap-2 font-cairo">
              <Filter className="w-4 h-4 text-slate-400 shrink-0" />
              <select
                value={faqCategoryFilter}
                onChange={(e) => setFaqCategoryFilter(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
              >
                <option value="all">{isAr ? 'كل التصنيفات' : 'All Categories'}</option>
                <option value="academic">{isAr ? 'أكاديمي ومناهج' : 'Academic'}</option>
                <option value="general">{isAr ? 'عام وإرشادي' : 'General'}</option>
                <option value="technical">{isAr ? 'تقني ومنصة' : 'Technical'}</option>
                <option value="financial">{isAr ? 'مالي واشتراكات' : 'Financial'}</option>
              </select>

              {(searchQuery || faqCategoryFilter !== 'all') && (
                <button
                  onClick={handleResetFilters}
                  className="flex items-center gap-1 px-3 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إعادة تعيين' : 'Reset'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Accordion List */}
          <div className="space-y-3">
            {filteredFaqs.length === 0 ? (
              <div className="p-10 text-center rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 space-y-3 font-tajawal">
                <FileQuestion className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600" />
                <p className="font-bold text-sm font-cairo text-slate-700 dark:text-slate-300">
                  {faqs.length === 0
                    ? isAr
                      ? 'لا توجد أسئلة شائعة مسجلة في قاعدة البيانات بعد'
                      : 'No FAQs saved in database yet'
                    : isAr
                    ? 'لم يتم العثور على نتائج مطابقة في الأسئلة الشائعة'
                    : 'No matching FAQs found'}
                </p>
                {canAdminManageCenter && onAddFaq && (
                  <button
                    onClick={handleOpenAddFaq}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold font-cairo cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إضافة أول سؤال شائع' : 'Add First FAQ'}</span>
                  </button>
                )}
              </div>
            ) : (
              filteredFaqs.map((faq) => {
                const isOpen = openFaqId === faq.id;
                return (
                  <div
                    key={faq.id}
                    className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden transition-all shadow-xs"
                  >
                    <div className="w-full text-right p-4 md:p-5 flex items-center justify-between gap-3 hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                      <button
                        onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                        className="flex-1 flex items-center gap-3 text-right cursor-pointer min-w-0"
                      >
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0">
                          ؟
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="text-xs md:text-sm font-bold text-slate-900 dark:text-white text-right leading-snug font-cairo truncate">
                            {isAr ? faq.questionAr : faq.questionEn}
                          </h4>
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400 mt-0.5 font-tajawal">
                            <Tag className="w-3 h-3 text-indigo-500" />
                            {getCategoryLabel(faq.category)}
                          </span>
                        </div>
                      </button>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => setViewingFaq(faq)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors cursor-pointer"
                          title={isAr ? 'مشاهدة التفاصيل' : 'View Details'}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {canAdminManageCenter && onUpdateFaq && (
                          <button
                            onClick={() => handleOpenEditFaq(faq)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors cursor-pointer"
                            title={isAr ? 'تعديل' : 'Edit'}
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        {canAdminManageCenter && onDeleteFaq && (
                          <button
                            onClick={() => setDeletingFaq(faq)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title={isAr ? 'حذف' : 'Delete'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                          className="p-1 text-slate-400 cursor-pointer"
                        >
                          <ChevronDown
                            className={`w-4 h-4 transition-transform ${
                              isOpen ? 'rotate-180 text-indigo-600' : ''
                            }`}
                          />
                        </button>
                      </div>
                    </div>

                    {isOpen && (
                      <div className="px-5 pb-5 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs md:text-sm text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50/30 dark:bg-slate-800/20 font-tajawal space-y-2">
                        <p>{isAr ? faq.answerAr : faq.answerEn}</p>
                        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 pt-1">
                          <span>
                            {isAr ? 'التصنيف:' : 'Category:'} {getCategoryLabel(faq.category)}
                          </span>
                          <button
                            onClick={() => setViewingFaq(faq)}
                            className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer font-cairo"
                          >
                            {isAr ? 'فتح التفاصيل الكاملة' : 'Full Details'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Direct Inquiry / Parent Suggestion & Complaint Box — Real Cloud SQL Persistence */}
          {canSubmitInquiry && onAddInquiry && (
            <div className="p-5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900/60 shadow-xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                  <h3 className="font-bold text-indigo-950 dark:text-indigo-200 text-sm font-cairo">
                    {isParent
                      ? isAr
                        ? 'إرسال اقتراح أو شكوى مباشرة للأدمن'
                        : 'Send Suggestion or Complaint Directly to Admin'
                      : isAr
                      ? 'هل لديك استفسار مباشر؟ أرسله الآن ليُحفظ في قاعدة البيانات'
                      : 'Submit Direct Inquiry'}
                  </h3>
                  <p className="text-xs text-indigo-700/80 dark:text-indigo-300/80 font-tajawal">
                    {isParent
                      ? isAr
                        ? 'يُرفع اقتراحك أو شكواك مباشرة إلى إدارة المنصة والأدمن العام مع متابعة الرد الرسمي'
                        : 'Your suggestion or complaint is submitted directly to platform administration'
                      : isAr
                      ? 'يتم حفظ الاستفسار مباشرة في جدول الاستفسارات بقاعدة البيانات مع إتاحة متابعته والرد الرسمي عليه'
                      : 'Saved directly to database for official follow-up'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('inquiries')}
                  className="text-xs font-bold text-indigo-700 dark:text-indigo-300 hover:underline self-start sm:self-auto font-cairo cursor-pointer"
                >
                  {isAr ? `عرض سجل الاستفسارات (${inquiries.length})` : `View Inquiries (${inquiries.length})`}
                </button>
              </div>

              <form onSubmit={handleQuickInquirySubmit} className="space-y-3 font-tajawal text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <input
                    type="text"
                    value={quickSenderName}
                    onChange={(e) => setQuickSenderName(e.target.value)}
                    placeholder={isAr ? 'اسم المرسل' : 'Your name'}
                    className="px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white"
                  />
                  <select
                    value={isParent ? 'parent' : quickSenderRole}
                    disabled={isParent}
                    onChange={(e) => setQuickSenderRole(e.target.value as InquiryItem['senderRole'])}
                    className="px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white disabled:opacity-75"
                  >
                    <option value="student">{isAr ? 'طالب' : 'Student'}</option>
                    <option value="parent">{isAr ? 'ولي أمر' : 'Parent'}</option>
                    <option value="teacher">{isAr ? 'معلم' : 'Teacher'}</option>
                    <option value="visitor">{isAr ? 'زائر' : 'Visitor'}</option>
                  </select>
                  <input
                    type="text"
                    value={quickSenderContact}
                    onChange={(e) => setQuickSenderContact(e.target.value)}
                    placeholder={isAr ? 'رقم الجوال أو البريد (اختياري)' : 'Phone / Email (optional)'}
                    className="px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <input
                    type="text"
                    required
                    value={quickSubject}
                    onChange={(e) => setQuickSubject(e.target.value)}
                    placeholder={
                      isParent
                        ? isAr
                          ? 'عنوان الاقتراح أو الشكوى *'
                          : 'Suggestion / Complaint Subject *'
                        : isAr
                        ? 'عنوان / موضوع الاستفسار *'
                        : 'Inquiry Subject *'
                    }
                    className="sm:col-span-1 px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white"
                  />
                  <select
                    value={quickCategory}
                    onChange={(e) => setQuickCategory(e.target.value as InquiryItem['category'])}
                    className="px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="complaint">{isAr ? 'شكوى رسمية' : 'Complaint'}</option>
                    <option value="suggestion">{isAr ? 'اقتراح تطويري' : 'Suggestion'}</option>
                    <option value="academic">{isAr ? 'أكاديمي ومناهج' : 'Academic'}</option>
                    <option value="financial">{isAr ? 'مالي واشتراكات' : 'Financial'}</option>
                    <option value="technical">{isAr ? 'تقني ومنصة' : 'Technical'}</option>
                    <option value="general">{isAr ? 'عام وإرشادي' : 'General'}</option>
                  </select>
                  <select
                    value={quickPriority}
                    onChange={(e) => setQuickPriority(e.target.value as InquiryItem['priority'])}
                    className="px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="normal">{isAr ? 'أولوية عادية' : 'Normal Priority'}</option>
                    <option value="high">{isAr ? 'أولوية مرتفعة' : 'High Priority'}</option>
                    <option value="urgent">{isAr ? 'عاجل جداً' : 'Urgent'}</option>
                    <option value="low">{isAr ? 'أولوية منخفضة' : 'Low Priority'}</option>
                  </select>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="text"
                    required
                    value={quickMessage}
                    onChange={(e) => setQuickMessage(e.target.value)}
                    placeholder={
                      isParent
                        ? isAr
                          ? 'اكتب تفاصيل الاقتراح أو الشكوى الموجهة للأدمن... *'
                          : 'Write suggestion or complaint details... *'
                        : isAr
                        ? 'اكتب تفاصيل استفسارك هنا... *'
                        : 'Type inquiry details... *'
                    }
                    className="flex-1 px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 font-cairo cursor-pointer disabled:opacity-60"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>
                      {isParent
                        ? isAr
                          ? 'إرسال للأدمن'
                          : 'Send to Admin'
                        : isAr
                        ? 'حفظ وإرسال الاستفسار'
                        : 'Submit Inquiry'}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 2: DIRECT INQUIRIES ==================== */}
      {activeTab === 'inquiries' && (
        <div className="space-y-4">
          {/* Search + Multi-Filter Bar */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex flex-col lg:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    isAr
                      ? 'ابحث باسم المرسل، الموضوع، نص الاستفسار، الرد، أو وسيلة التواصل...'
                      : 'Search inquiries by sender, subject, reply...'
                  }
                  className="w-full pl-3 pr-9 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-tajawal"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2 font-cairo text-xs">
                <select
                  value={inquiryStatusFilter}
                  onChange={(e) => setInquiryStatusFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
                >
                  <option value="all">{isAr ? 'كل الحالات' : 'All Statuses'}</option>
                  <option value="pending">{isAr ? 'قيد الانتظار' : 'Pending'}</option>
                  <option value="answered">{isAr ? 'تم الرد' : 'Answered'}</option>
                  <option value="closed">{isAr ? 'مغلق' : 'Closed'}</option>
                </select>

                <select
                  value={inquiryPriorityFilter}
                  onChange={(e) => setInquiryPriorityFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
                >
                  <option value="all">{isAr ? 'كل الأولويات' : 'All Priorities'}</option>
                  <option value="urgent">{isAr ? 'عاجل' : 'Urgent'}</option>
                  <option value="high">{isAr ? 'مرتفع' : 'High'}</option>
                  <option value="normal">{isAr ? 'عادي' : 'Normal'}</option>
                  <option value="low">{isAr ? 'منخفض' : 'Low'}</option>
                </select>

                <select
                  value={inquiryCategoryFilter}
                  onChange={(e) => setInquiryCategoryFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
                >
                  <option value="all">{isAr ? 'كل التصنيفات' : 'All Categories'}</option>
                  <option value="complaint">{isAr ? 'شكوى رسمية' : 'Complaint'}</option>
                  <option value="suggestion">{isAr ? 'اقتراح تطويري' : 'Suggestion'}</option>
                  <option value="academic">{isAr ? 'أكاديمي ومناهج' : 'Academic'}</option>
                  <option value="financial">{isAr ? 'مالي واشتراكات' : 'Financial'}</option>
                  <option value="technical">{isAr ? 'تقني ومنصة' : 'Technical'}</option>
                  <option value="general">{isAr ? 'عام وإرشادي' : 'General'}</option>
                </select>

                {(searchQuery ||
                  inquiryStatusFilter !== 'all' ||
                  inquiryPriorityFilter !== 'all' ||
                  inquiryCategoryFilter !== 'all') && (
                  <button
                    onClick={handleResetFilters}
                    className="flex items-center gap-1 px-3 py-2 font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إعادة تعيين' : 'Reset'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {isParent && (
            <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h4 className="font-bold text-emerald-950 dark:text-emerald-200 text-sm font-cairo">
                  {isAr ? 'بوابة ولي الأمر: الاقتراحات والشكاوى للأدمن' : 'Parent Portal: Suggestions & Complaints'}
                </h4>
                <p className="text-xs text-emerald-800/80 dark:text-emerald-300/80 font-tajawal mt-0.5">
                  {isAr
                    ? 'يمكنك إرسال اقتراحات أو شكاوى مباشرة إلى المدير العام ومتابعة ردود الإدارة، مع عرض المنصة للقراءة فقط.'
                    : 'Submit suggestions or complaints directly to the Admin and follow official replies.'}
                </p>
              </div>
              {onAddInquiry && (
                <button
                  onClick={handleOpenAddInquiry}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold font-cairo cursor-pointer shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إرسال اقتراح / شكوى' : 'Send Suggestion / Complaint'}</span>
                </button>
              )}
            </div>
          )}

          {/* Inquiries List */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredInquiries.length === 0 ? (
              <div className="col-span-full p-10 text-center rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 space-y-3 font-tajawal">
                <Inbox className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600" />
                <p className="font-bold text-sm font-cairo text-slate-700 dark:text-slate-300">
                  {inquiries.length === 0
                    ? isAr
                      ? 'لا توجد استفسارات مسجلة في قاعدة البيانات بعد'
                      : 'No inquiries recorded in database yet'
                    : isAr
                    ? 'لا توجد استفسارات مطابقة لخيارات البحث والفلترة'
                    : 'No matching inquiries found'}
                </p>
                {canSubmitInquiry && onAddInquiry && (
                  <button
                    onClick={handleOpenAddInquiry}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold font-cairo cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>
                      {isParent
                        ? isAr
                          ? 'إرسال اقتراح أو شكوى للأدمن'
                          : 'Send Suggestion / Complaint'
                        : isAr
                        ? 'تسجيل أول استفسار'
                        : 'Create First Inquiry'}
                    </span>
                  </button>
                )}
              </div>
            ) : (
              filteredInquiries.map((inq) => {
                const statusBadge = getStatusBadge(inq.status);
                const priorityBadge = getPriorityBadge(inq.priority);

                return (
                  <div
                    key={inq.id}
                    className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-3">
                      {/* Header Badges */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-1.5 font-cairo">
                          <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${statusBadge.cls}`}>
                            {statusBadge.label}
                          </span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${priorityBadge.cls}`}>
                            {priorityBadge.label}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {getCategoryLabel(inq.category)}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {inq.createdAt}
                        </span>
                      </div>

                      {/* Sender Info */}
                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 font-tajawal">
                        <span className="inline-flex items-center gap-1 font-bold text-slate-700 dark:text-slate-200">
                          <User className="w-3.5 h-3.5 text-emerald-600" />
                          {inq.senderName} ({getRoleLabel(inq.senderRole)})
                        </span>
                        {inq.senderContact && (
                          <span className="inline-flex items-center gap-1 font-mono text-[11px]">
                            <Phone className="w-3 h-3 text-slate-400" />
                            {inq.senderContact}
                          </span>
                        )}
                      </div>

                      {/* Subject & Body */}
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm font-cairo leading-snug">
                          {inq.subject}
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed font-tajawal line-clamp-3">
                          {inq.message}
                        </p>
                      </div>

                      {/* Official Reply Preview */}
                      {inq.replyText && (
                        <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 space-y-1">
                          <div className="flex items-center justify-between text-[11px] text-emerald-700 dark:text-emerald-300 font-cairo font-bold">
                            <span>
                              {isAr ? 'الرد الرسمي:' : 'Official Reply:'} {inq.repliedBy || currentUserName}
                            </span>
                            {inq.repliedAt && <span className="font-mono font-normal">{inq.repliedAt}</span>}
                          </div>
                          <p className="text-xs text-emerald-900 dark:text-emerald-100 font-tajawal line-clamp-2">
                            {inq.replyText}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Actions Footer */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          onClick={() => setViewingInquiry(inq)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 hover:text-indigo-600 transition-colors font-cairo cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{isAr ? 'التفاصيل' : 'Details'}</span>
                        </button>

                        {canAdminManageCenter && onUpdateInquiry && (
                          <button
                            onClick={() => handleOpenEditInquiry(inq)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 transition-colors font-cairo cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5" />
                            <span>{inq.replyText ? (isAr ? 'تعديل / تحديث الرد' : 'Edit') : isAr ? 'رد وتعديل' : 'Reply'}</span>
                          </button>
                        )}

                        {canAdminManageCenter && inq.replyText && onAddFaq && (
                          <button
                            onClick={() => handlePromoteInquiryToFaq(inq)}
                            disabled={isSubmitting}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 transition-colors font-cairo cursor-pointer"
                            title={isAr ? 'نشر هذا الاستفسار وإجابته في الأسئلة الشائعة' : 'Promote to FAQ'}
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تحويل لسؤال شائع' : 'To FAQ'}</span>
                          </button>
                        )}
                      </div>

                      {canAdminManageCenter && onDeleteInquiry && (
                        <button
                          onClick={() => setDeletingInquiry(inq)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                          title={isAr ? 'حذف الاستفسار' : 'Delete Inquiry'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ==================== TAB 3: NOTIFICATIONS ==================== */}
      {activeTab === 'notifications' && (
        <div className="space-y-4">
          {/* Search + Filters */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isAr ? 'ابحث في الإشعارات بالعنوان، المحتوى، الجمهور، أو الفئة...' : 'Search alerts...'}
                className="w-full pl-3 pr-9 py-2 text-xs md:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 font-tajawal"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 font-cairo text-xs">
              <select
                value={notifCategoryFilter}
                onChange={(e) => setNotifCategoryFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
              >
                <option value="all">{isAr ? 'كل التصنيفات' : 'All Categories'}</option>
                <option value="academic">{isAr ? 'أكاديمي وتعليمي' : 'Academic'}</option>
                <option value="attendance">{isAr ? 'حضور وغياب' : 'Attendance'}</option>
                <option value="financial">{isAr ? 'مالي ورسوم' : 'Financial'}</option>
                <option value="general">{isAr ? 'عام وإداري' : 'General'}</option>
              </select>

              <select
                value={notifTargetFilter}
                onChange={(e) => setNotifTargetFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
              >
                <option value="all">{isAr ? 'كل الفئات المستهدفة' : 'All Targets'}</option>
                <option value="students_parents">
                  {isAr ? 'الطلاب والطالبات وأولياء الأمور' : 'Students & Parents'}
                </option>
                <option value="parents">{isAr ? 'أولياء الأمور' : 'Parents'}</option>
                <option value="students">{isAr ? 'الطلاب' : 'Students'}</option>
                <option value="weak_students">{isAr ? 'أولياء أمور الضعاف' : 'Weak Students'}</option>
                <option value="top_students">{isAr ? 'أولياء أمور الفائقين' : 'Top Students'}</option>
              </select>

              <select
                value={notifReadFilter}
                onChange={(e) => setNotifReadFilter(e.target.value as 'all' | 'unread' | 'read')}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
              >
                <option value="all">{isAr ? 'كل حالات القراءة' : 'All States'}</option>
                <option value="unread">{isAr ? 'غير مقروء فقط' : 'Unread'}</option>
                <option value="read">{isAr ? 'مقروء فقط' : 'Read'}</option>
              </select>

              {(searchQuery ||
                notifCategoryFilter !== 'all' ||
                notifTargetFilter !== 'all' ||
                notifReadFilter !== 'all') && (
                <button
                  onClick={handleResetFilters}
                  className="flex items-center gap-1 px-3 py-2 font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إعادة تعيين' : 'Reset'}</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredNotifications.length === 0 ? (
              <div className="col-span-full p-10 text-center rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 space-y-3 font-tajawal">
                <Bell className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600" />
                <p className="font-bold text-sm font-cairo text-slate-700 dark:text-slate-300">
                  {notifications.length === 0
                    ? isAr
                      ? 'لا توجد إشعارات دورية مسجلة في قاعدة البيانات بعد'
                      : 'No notifications in database yet'
                    : isAr
                    ? 'لا توجد إشعارات وتنبيهات متطابقة'
                    : 'No matching notifications found'}
                </p>
                {canAdminManageCenter && (
                  <button
                    onClick={handleOpenAddNotif}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold font-cairo cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إرسال أول إشعار دوري' : 'Send First Alert'}</span>
                  </button>
                )}
              </div>
            ) : (
              filteredNotifications.map((notif) => {
                const isAcademic = notif.category === 'academic';
                const isFinancial = notif.category === 'financial';
                const isAttendance = notif.category === 'attendance';

                return (
                  <div
                    key={notif.id}
                    className={`p-5 rounded-2xl border shadow-xs flex flex-col justify-between space-y-3 transition-all ${
                      notif.read
                        ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                        : 'bg-amber-50/40 dark:bg-amber-950/10 border-amber-200 dark:border-amber-800/70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 text-xs text-slate-400 mb-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold font-cairo ${
                              isAcademic
                                ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300'
                                : isFinancial
                                ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300'
                                : isAttendance
                                ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300'
                                : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                            }`}
                          >
                            {getCategoryLabel(notif.category)}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-cairo ${
                              notif.read
                                ? 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                                : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                            }`}
                          >
                            {notif.read ? (isAr ? 'مقروء' : 'Read') : isAr ? 'جديد / غير مقروء' : 'Unread'}
                          </span>
                        </div>
                        <span className="font-mono text-[11px]">{notif.createdAt}</span>
                      </div>

                      <h4 className="font-bold text-slate-900 dark:text-white text-sm leading-snug font-cairo">
                        {notif.title}
                      </h4>

                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed font-tajawal">
                        {notif.message}
                      </p>

                      {notifMetaMap[notif.id] && (
                        <div className="flex flex-wrap items-center gap-1.5 mt-2.5 text-[10px] font-cairo font-bold">
                          <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 flex items-center gap-1">
                            <Target className="w-3 h-3" />
                            <span>حملة مستهدفة</span>
                          </span>
                          {notifMetaMap[notif.id].targetGrade && notifMetaMap[notif.id].targetGrade !== 'all' && (
                            <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                              {notifMetaMap[notif.id].targetGrade}
                            </span>
                          )}
                          {notifMetaMap[notif.id].targetCondition === 'expiring_codes' && (
                            <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                              قاربت أكوادهم على الانتهاء
                            </span>
                          )}
                          {notifMetaMap[notif.id].targetCondition === 'at_risk' && (
                            <span className="px-2 py-0.5 rounded-lg bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                              الطلاب المحتاجون لدعم
                            </span>
                          )}
                          {notifMetaMap[notif.id].recipientsCount !== undefined && (
                            <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-mono-numbers flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              {notifMetaMap[notif.id].recipientsCount} مستفيد
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                      <span>
                        {isAr ? 'الفئة المستهدفة:' : 'Target:'}{' '}
                        <strong className="text-slate-700 dark:text-slate-300 font-cairo">
                          {getTargetLabel(notif.target)}
                        </strong>
                      </span>

                      <div className="flex items-center gap-1">
                        {onUpdateNotification && (
                          <button
                            onClick={() => handleToggleNotifRead(notif)}
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-bold font-cairo transition-colors cursor-pointer ${
                              notif.read
                                ? 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                                : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-300'
                            }`}
                            title={notif.read ? (isAr ? 'تحديد كغير مقروء' : 'Mark Unread') : isAr ? 'تحديد كمقروء' : 'Mark Read'}
                          >
                            <CheckCheck className="w-3.5 h-3.5" />
                            <span>{notif.read ? (isAr ? 'غير مقروء' : 'Unread') : isAr ? 'تمت القراءة' : 'Mark Read'}</span>
                          </button>
                        )}

                        <button
                          onClick={() => setViewingNotif(notif)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors cursor-pointer"
                          title={isAr ? 'مشاهدة التفاصيل' : 'Details'}
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {canAdminManageCenter && onUpdateNotification && (
                          <button
                            onClick={() => handleOpenEditNotif(notif)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors cursor-pointer"
                            title={isAr ? 'تعديل الإشعار' : 'Edit'}
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {canAdminManageCenter && onDeleteNotification && (
                          <button
                            onClick={() => setDeletingNotif(notif)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title={isAr ? 'حذف الإشعار' : 'Delete'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ==================== MODAL: ADD / EDIT NOTIFICATION ==================== */}
      {isBroadcastOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden p-6 space-y-4 text-xs md:text-sm font-tajawal">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base font-cairo">
                {editingNotif
                  ? isAr
                    ? 'تعديل الإشعار والتنبيه الدوري'
                    : 'Edit Periodic Alert'
                  : isAr
                  ? 'بث إشعار دوري وتنبيه جديد'
                  : 'Compose Periodic Broadcast'}
              </h3>
              <button
                onClick={() => {
                  setIsBroadcastOpen(false);
                  setEditingNotif(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBroadcast} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1 font-cairo">{isAr ? 'عنوان الإشعار' : 'Title'}</label>
                <input
                  type="text"
                  required
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  placeholder={isAr ? 'مثال: موعد الاختبار الشهري الشامل' : 'e.g. Monthly exam date'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'الجمهور المستهدف' : 'Target'}</label>
                  <select
                    value={notifTarget}
                    onChange={(e) => setNotifTarget(e.target.value as AppNotification['target'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="students_parents">
                      {isAr ? 'الطلاب والطالبات وأولياء الأمور' : 'Students & Parents'}
                    </option>
                    <option value="parents">{isAr ? 'أولياء الأمور' : 'Parents'}</option>
                    <option value="students">{isAr ? 'الطلاب' : 'Students'}</option>
                    <option value="weak_students">{isAr ? 'أولياء أمور الضعاف' : 'Weak Students Parents'}</option>
                    <option value="top_students">{isAr ? 'أولياء أمور الفائقين' : 'Top Students Parents'}</option>
                    <option value="all">{isAr ? 'الجميع (عام)' : 'Everyone'}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'تصنيف الإشعار' : 'Category'}</label>
                  <select
                    value={notifCategory}
                    onChange={(e) => setNotifCategory(e.target.value as AppNotification['category'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="academic">{isAr ? 'أكاديمي وتعليمي' : 'Academic'}</option>
                    <option value="attendance">{isAr ? 'حضور وغياب' : 'Attendance'}</option>
                    <option value="financial">{isAr ? 'مالي ورسوم' : 'Financial'}</option>
                    <option value="general">{isAr ? 'عام وإداري' : 'General'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">{isAr ? 'نص الرسالة والإشعار' : 'Message Body'}</label>
                <textarea
                  rows={3}
                  required
                  value={notifMessage}
                  onChange={(e) => setNotifMessage(e.target.value)}
                  placeholder={isAr ? 'اكتب تفاصيل التنبيه الدوري المراد حفظه وإرساله...' : 'Notification details...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              {!editingNotif && (
                <div className="p-3.5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 space-y-3">
                  <label className="flex items-center justify-between gap-2 cursor-pointer font-cairo font-bold text-xs text-indigo-900 dark:text-indigo-200">
                    <span className="flex items-center gap-1.5">
                      <Target className="w-4 h-4 text-indigo-600" />
                      <span>{isAr ? 'تخصيص حملة تنبيه مستهدفة لفئة محددة فقط' : 'Targeted Campaign Filters'}</span>
                    </span>
                    <input
                      type="checkbox"
                      checked={isTargetedMode}
                      onChange={(e) => setIsTargetedMode(e.target.checked)}
                      className="rounded border-indigo-300 text-indigo-600"
                    />
                  </label>

                  {isTargetedMode && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-cairo">
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-1">الصف الدراسي</label>
                        <select
                          value={campGrade}
                          onChange={(e) => setCampGrade(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-700 text-slate-900 dark:text-white"
                        >
                          <option value="all">جميع الصفوف</option>
                          <option value="الصف الثالث الثانوي">الصف الثالث الثانوي</option>
                          <option value="الصف الثاني الثانوي">الصف الثاني الثانوي</option>
                          <option value="الصف الأول الثانوي">الصف الأول الثانوي</option>
                          <option value="الصف الثالث المتوسط">الصف الثالث المتوسط</option>
                          <option value="الصف الثاني المتوسط">الصف الثاني المتوسط</option>
                          <option value="الصف الأول المتوسط">الصف الأول المتوسط</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] text-slate-500 mb-1">نظام الاشتراك</label>
                        <select
                          value={campEnrollmentType}
                          onChange={(e) => setCampEnrollmentType(e.target.value as 'all' | 'online' | 'offline')}
                          className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-700 text-slate-900 dark:text-white"
                        >
                          <option value="all">أونلاين وسنتر</option>
                          <option value="online">طلاب الأونلاين فقط</option>
                          <option value="offline">طلاب السنتر فقط</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] text-slate-500 mb-1">الشرط الذكي</label>
                        <select
                          value={campCondition}
                          onChange={(e) => setCampCondition(e.target.value as 'all' | 'expiring_codes' | 'at_risk')}
                          className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-700 text-slate-900 dark:text-white"
                        >
                          <option value="all">الكل حسب الصف</option>
                          <option value="expiring_codes">أكواد تفعيل قاربت على الانتهاء (5 أيام)</option>
                          <option value="at_risk">الطلاب المتراجعون / ضعاف الحضور</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {editingNotif && (
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer font-cairo">
                  <input
                    type="checkbox"
                    checked={notifRead}
                    onChange={(e) => setNotifRead(e.target.checked)}
                    className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>{isAr ? 'تحديد الإشعار كمقروء' : 'Mark notification as read'}</span>
                </label>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsBroadcastOpen(false);
                    setEditingNotif(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-cairo cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold font-cairo cursor-pointer disabled:opacity-60"
                >
                  {editingNotif
                    ? isAr
                      ? 'حفظ التعديلات'
                      : 'Save Changes'
                    : isAr
                    ? 'حفظ وإرسال الإشعار'
                    : 'Send Alert'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== MODAL: VIEW NOTIFICATION DETAILS ==================== */}
      {viewingNotif && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-500" />
                <span>{isAr ? 'تفاصيل الإشعار الدوري' : 'Notification Details'}</span>
              </h3>
              <button
                onClick={() => setViewingNotif(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm font-tajawal">
              <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'التاريخ والوقت' : 'Date & Time'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-mono text-xs">
                    {viewingNotif.createdAt}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'حالة القراءة' : 'Status'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-cairo">
                    {viewingNotif.read ? (isAr ? 'مقروء' : 'Read') : isAr ? 'غير مقروء' : 'Unread'}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'الفئة المستهدفة' : 'Target'}</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400 font-cairo">
                    {getTargetLabel(viewingNotif.target)}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'التصنيف' : 'Category'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-cairo">
                    {getCategoryLabel(viewingNotif.category)}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/40 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/60">
                <h4 className="font-bold font-cairo text-sm text-slate-900 dark:text-white mb-1.5">
                  {viewingNotif.title}
                </h4>
                <p className="text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {viewingNotif.message}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                {onUpdateNotification && (
                  <button
                    onClick={() => handleToggleNotifRead(viewingNotif)}
                    className="px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {viewingNotif.read ? (isAr ? 'تحديد كغير مقروء' : 'Mark Unread') : isAr ? 'تحديد كمقروء' : 'Mark Read'}
                  </button>
                )}
                {canAdminManageCenter && onUpdateNotification && (
                  <button
                    onClick={() => {
                      const target = viewingNotif;
                      setViewingNotif(null);
                      handleOpenEditNotif(target);
                    }}
                    className="px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {isAr ? 'تعديل' : 'Edit'}
                  </button>
                )}
                {canAdminManageCenter && onDeleteNotification && (
                  <button
                    onClick={() => {
                      const target = viewingNotif;
                      setViewingNotif(null);
                      setDeletingNotif(target);
                    }}
                    className="px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {isAr ? 'حذف' : 'Delete'}
                  </button>
                )}
              </div>

              <button
                onClick={() => setViewingNotif(null)}
                className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs font-cairo cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MODAL: DELETE NOTIFICATION CONFIRM ==================== */}
      {deletingNotif && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف الإشعار' : 'Delete Notification'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? `هل أنت متأكد من حذف الإشعار "${deletingNotif.title}" نهائياً من قاعدة البيانات؟`
                  : `Are you sure you want to delete "${deletingNotif.title}"?`}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingNotif(null)}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={confirmDeleteNotif}
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
              >
                {isAr ? 'نعم، حذف نهائياً' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MODAL: ADD / EDIT FAQ ==================== */}
      {isFaqModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden p-6 space-y-4 text-xs md:text-sm font-tajawal max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base font-cairo">
                {editingFaq ? (isAr ? 'تعديل السؤال الشائع' : 'Edit FAQ') : isAr ? 'إضافة سؤال شائع جديد' : 'Add New FAQ'}
              </h3>
              <button
                onClick={() => {
                  setIsFaqModalOpen(false);
                  setEditingFaq(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFaq} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1 font-cairo">
                  {isAr ? 'نص السؤال (بالعربية) *' : 'Question (Arabic) *'}
                </label>
                <input
                  type="text"
                  required
                  value={faqQuestionAr}
                  onChange={(e) => setFaqQuestionAr(e.target.value)}
                  placeholder={isAr ? 'مثال: كيف يمكنني التسجيل في الحصص الأسبوعية؟' : 'Question text'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">
                  {isAr ? 'نص السؤال بالإنجليزية (اختياري)' : 'Question (English - Optional)'}
                </label>
                <input
                  type="text"
                  value={faqQuestionEn}
                  onChange={(e) => setFaqQuestionEn(e.target.value)}
                  placeholder="Optional English question"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">{isAr ? 'تصنيف السؤال' : 'Category'}</label>
                <select
                  value={faqCategory}
                  onChange={(e) => setFaqCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                >
                  <option value="academic">{isAr ? 'أكاديمي ومناهج' : 'Academic'}</option>
                  <option value="general">{isAr ? 'عام وإرشادي' : 'General'}</option>
                  <option value="technical">{isAr ? 'تقني ومنصة' : 'Technical'}</option>
                  <option value="financial">{isAr ? 'مالي واشتراكات' : 'Financial'}</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">
                  {isAr ? 'الإجابة المعتمدة (بالعربية) *' : 'Official Answer (Arabic) *'}
                </label>
                <textarea
                  rows={4}
                  required
                  value={faqAnswerAr}
                  onChange={(e) => setFaqAnswerAr(e.target.value)}
                  placeholder={isAr ? 'اكتب الشرح التفصيلي للإجابة المعتمدة...' : 'Answer details...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">
                  {isAr ? 'الإجابة بالإنجليزية (اختياري)' : 'Answer (English - Optional)'}
                </label>
                <textarea
                  rows={2}
                  value={faqAnswerEn}
                  onChange={(e) => setFaqAnswerEn(e.target.value)}
                  placeholder="Optional English answer"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsFaqModalOpen(false);
                    setEditingFaq(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-cairo cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold font-cairo cursor-pointer disabled:opacity-60"
                >
                  {editingFaq ? (isAr ? 'حفظ التعديل' : 'Save Changes') : isAr ? 'حفظ السؤال' : 'Add Question'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== MODAL: VIEW FAQ DETAILS ==================== */}
      {viewingFaq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <FileQuestion className="w-5 h-5 text-indigo-500" />
                <span>{isAr ? 'تفاصيل السؤال الشائع' : 'FAQ Details'}</span>
              </h3>
              <button
                onClick={() => setViewingFaq(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm font-tajawal">
              <div className="p-3.5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 space-y-1.5">
                <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 block font-cairo">
                  {isAr ? 'السؤال المطروح (عربي):' : 'Question (AR):'}
                </span>
                <p className="font-bold text-slate-900 dark:text-white leading-snug">{viewingFaq.questionAr}</p>
                {viewingFaq.questionEn && viewingFaq.questionEn !== viewingFaq.questionAr && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 pt-1">{viewingFaq.questionEn}</p>
                )}
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 block font-cairo">
                  {isAr ? 'الإجابة المعتمدة:' : 'Official Answer:'}
                </span>
                <p className="text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {viewingFaq.answerAr}
                </p>
                {viewingFaq.answerEn && viewingFaq.answerEn !== viewingFaq.answerAr && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 pt-1 whitespace-pre-wrap">
                    {viewingFaq.answerEn}
                  </p>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 pt-1">
                <span className="inline-flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-indigo-500" />
                  {isAr ? 'التصنيف:' : 'Category:'}{' '}
                  <strong className="text-slate-700 dark:text-slate-300 font-cairo">
                    {getCategoryLabel(viewingFaq.category)}
                  </strong>
                </span>
                {viewingFaq.createdAt && (
                  <span className="inline-flex items-center gap-1 font-mono text-[11px]">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(viewingFaq.createdAt).toLocaleDateString('ar-EG')}
                  </span>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                {canAdminManageCenter && onUpdateFaq && (
                  <button
                    onClick={() => {
                      const target = viewingFaq;
                      setViewingFaq(null);
                      handleOpenEditFaq(target);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {isAr ? 'تعديل' : 'Edit'}
                  </button>
                )}
                {canAdminManageCenter && onDeleteFaq && (
                  <button
                    onClick={() => {
                      const target = viewingFaq;
                      setViewingFaq(null);
                      setDeletingFaq(target);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {isAr ? 'حذف' : 'Delete'}
                  </button>
                )}
              </div>

              <button
                onClick={() => setViewingFaq(null)}
                className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs font-cairo cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MODAL: DELETE FAQ CONFIRM ==================== */}
      {deletingFaq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف السؤال الشائع' : 'Delete FAQ'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? `هل أنت متأكد من حذف السؤال "${deletingFaq.questionAr}" من قاعدة البيانات؟`
                  : `Are you sure you want to delete "${deletingFaq.questionEn}"?`}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingFaq(null)}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={confirmDeleteFaq}
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
              >
                {isAr ? 'نعم، حذف نهائياً' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MODAL: ADD / EDIT / REPLY INQUIRY ==================== */}
      {isInquiryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-6 space-y-4 text-xs md:text-sm font-tajawal max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base font-cairo">
                {editingInquiry
                  ? isAr
                    ? 'تعديل الاستفسار وإضافة / تحديث الرد الرسمي'
                    : 'Edit & Reply to Inquiry'
                  : isParent
                  ? isAr
                    ? 'إرسال اقتراح أو شكوى للأدمن'
                    : 'Send Suggestion or Complaint to Admin'
                  : isAr
                  ? 'تسجيل استفسار مباشر جديد'
                  : 'Create New Inquiry'}
              </h3>
              <button
                onClick={() => {
                  setIsInquiryModalOpen(false);
                  setEditingInquiry(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveInquiry} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'اسم المرسل' : 'Sender Name'}</label>
                  <input
                    type="text"
                    required
                    value={inqSenderName}
                    onChange={(e) => setInqSenderName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'صفة المرسل' : 'Role'}</label>
                  <select
                    value={isParent ? 'parent' : inqSenderRole}
                    disabled={!canAdminManageCenter}
                    onChange={(e) => setInqSenderRole(e.target.value as InquiryItem['senderRole'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white disabled:opacity-75"
                  >
                    <option value="parent">{isAr ? 'ولي أمر' : 'Parent'}</option>
                    <option value="student">{isAr ? 'طالب' : 'Student'}</option>
                    <option value="teacher">{isAr ? 'معلم' : 'Teacher'}</option>
                    <option value="visitor">{isAr ? 'زائر' : 'Visitor'}</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'رقم الجوال / التواصل' : 'Contact'}</label>
                  <input
                    type="text"
                    value={inqSenderContact}
                    onChange={(e) => setInqSenderContact(e.target.value)}
                    placeholder={isAr ? 'اختياري' : 'Optional'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className={`grid grid-cols-1 ${canAdminManageCenter ? 'sm:grid-cols-3' : 'sm:grid-cols-2'} gap-3`}>
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'التصنيف' : 'Category'}</label>
                  <select
                    value={inqCategory}
                    onChange={(e) => setInqCategory(e.target.value as InquiryItem['category'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="complaint">{isAr ? 'شكوى رسمية' : 'Complaint'}</option>
                    <option value="suggestion">{isAr ? 'اقتراح تطويري' : 'Suggestion'}</option>
                    <option value="academic">{isAr ? 'أكاديمي ومناهج' : 'Academic'}</option>
                    <option value="financial">{isAr ? 'مالي واشتراكات' : 'Financial'}</option>
                    <option value="technical">{isAr ? 'تقني ومنصة' : 'Technical'}</option>
                    <option value="general">{isAr ? 'عام وإرشادي' : 'General'}</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1 font-cairo">{isAr ? 'الأولوية' : 'Priority'}</label>
                  <select
                    value={inqPriority}
                    onChange={(e) => setInqPriority(e.target.value as InquiryItem['priority'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="low">{isAr ? 'منخفض' : 'Low'}</option>
                    <option value="normal">{isAr ? 'عادي' : 'Normal'}</option>
                    <option value="high">{isAr ? 'مرتفع' : 'High'}</option>
                    <option value="urgent">{isAr ? 'عاجل' : 'Urgent'}</option>
                  </select>
                </div>
                {canAdminManageCenter && (
                  <div>
                    <label className="block font-semibold mb-1 font-cairo">{isAr ? 'حالة الاستفسار' : 'Status'}</label>
                    <select
                      value={inqStatus}
                      onChange={(e) => setInqStatus(e.target.value as InquiryItem['status'])}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                    >
                      <option value="pending">{isAr ? 'قيد الانتظار' : 'Pending'}</option>
                      <option value="answered">{isAr ? 'تم الرد' : 'Answered'}</option>
                      <option value="closed">{isAr ? 'مغلق' : 'Closed'}</option>
                    </select>
                  </div>
                )}
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">
                  {isParent ? (isAr ? 'عنوان الاقتراح أو الشكوى *' : 'Subject *') : isAr ? 'عنوان الاستفسار *' : 'Subject *'}
                </label>
                <input
                  type="text"
                  required
                  value={inqSubject}
                  onChange={(e) => setInqSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 font-cairo">
                  {isParent ? (isAr ? 'تفاصيل الاقتراح أو الشكوى *' : 'Message *') : isAr ? 'تفاصيل الاستفسار *' : 'Message *'}
                </label>
                <textarea
                  rows={3}
                  required
                  value={inqMessage}
                  onChange={(e) => setInqMessage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              {canAdminManageCenter && (
                <div className="p-3.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <label className="font-bold text-emerald-900 dark:text-emerald-200 font-cairo">
                      {isAr ? 'الرد الرسمي والإجراء المتخذ' : 'Official Reply'}
                    </label>
                    <input
                      type="text"
                      value={inqRepliedBy}
                      onChange={(e) => setInqRepliedBy(e.target.value)}
                      placeholder={isAr ? 'اسم المسؤول عن الرد' : 'Responder name'}
                      className="px-3 py-1.5 text-xs rounded-lg bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <textarea
                    rows={3}
                    value={inqReplyText}
                    onChange={(e) => setInqReplyText(e.target.value)}
                    placeholder={isAr ? 'اكتب الرد الرسمي هنا (سيتم حفظه وتحديث الحالة تلقائياً)...' : 'Type official reply...'}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-slate-900 dark:text-white"
                  />
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsInquiryModalOpen(false);
                    setEditingInquiry(null);
                  }}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-cairo cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold font-cairo cursor-pointer disabled:opacity-60"
                >
                  {editingInquiry
                    ? isAr
                      ? 'حفظ التعديلات والرد'
                      : 'Save Changes'
                    : isParent
                    ? isAr
                      ? 'إرسال للأدمن'
                      : 'Send to Admin'
                    : isAr
                    ? 'حفظ الاستفسار'
                    : 'Save Inquiry'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== MODAL: VIEW INQUIRY DETAILS ==================== */}
      {viewingInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-500" />
                <span>{isAr ? 'التفاصيل الكاملة للاستفسار' : 'Full Inquiry Details'}</span>
              </h3>
              <button
                onClick={() => setViewingInquiry(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm font-tajawal">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'المرسل' : 'Sender'}</span>
                  <span className="font-bold text-slate-900 dark:text-white font-cairo">
                    {viewingInquiry.senderName}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'الصفة' : 'Role'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-cairo">
                    {getRoleLabel(viewingInquiry.senderRole)}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'وسيلة التواصل' : 'Contact'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-mono text-xs">
                    {viewingInquiry.senderContact || (isAr ? 'غير مسجل' : 'N/A')}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'الحالة' : 'Status'}</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 font-cairo">
                    {getStatusBadge(viewingInquiry.status).label}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'الأولوية' : 'Priority'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-cairo">
                    {getPriorityBadge(viewingInquiry.priority).label}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">{isAr ? 'تاريخ الإرسال' : 'Created'}</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-mono text-xs">
                    {viewingInquiry.createdAt}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 block font-cairo">
                  {isAr ? 'موضوع ونص الاستفسار:' : 'Inquiry:'}
                </span>
                <h4 className="font-bold text-slate-900 dark:text-white font-cairo text-sm">
                  {viewingInquiry.subject}
                </h4>
                <p className="text-slate-700 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {viewingInquiry.message}
                </p>
              </div>

              <div
                className={`p-4 rounded-2xl border space-y-1.5 ${
                  viewingInquiry.replyText
                    ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/60'
                    : 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/60'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] font-cairo font-bold">
                  <span className={viewingInquiry.replyText ? 'text-emerald-700 dark:text-emerald-300' : 'text-amber-700 dark:text-amber-300'}>
                    {viewingInquiry.replyText
                      ? `${isAr ? 'الرد الرسمي بواسطة:' : 'Replied by:'} ${viewingInquiry.repliedBy || currentUserName}`
                      : isAr
                      ? 'لم يتم تسجيل رد رسمي بعد'
                      : 'No official reply yet'}
                  </span>
                  {viewingInquiry.repliedAt && (
                    <span className="font-mono font-normal text-emerald-700/80 dark:text-emerald-300/80">
                      {viewingInquiry.repliedAt}
                    </span>
                  )}
                </div>
                {viewingInquiry.replyText && (
                  <p className="text-emerald-950 dark:text-emerald-100 leading-relaxed whitespace-pre-wrap">
                    {viewingInquiry.replyText}
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex flex-wrap items-center gap-2">
                {canAdminManageCenter && onUpdateInquiry && (
                  <button
                    onClick={() => {
                      const target = viewingInquiry;
                      setViewingInquiry(null);
                      handleOpenEditInquiry(target);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs font-cairo cursor-pointer"
                  >
                    {viewingInquiry.replyText ? (isAr ? 'تعديل / تحديث الرد' : 'Edit / Update Reply') : isAr ? 'كتابة رد رسمي' : 'Write Reply'}
                  </button>
                )}
                {canAdminManageCenter && viewingInquiry.replyText && onAddFaq && (
                  <button
                    onClick={() => handlePromoteInquiryToFaq(viewingInquiry)}
                    className="px-3.5 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {isAr ? 'تحويل لسؤال شائع' : 'Promote to FAQ'}
                  </button>
                )}
                {canAdminManageCenter && onDeleteInquiry && (
                  <button
                    onClick={() => {
                      const target = viewingInquiry;
                      setViewingInquiry(null);
                      setDeletingInquiry(target);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold text-xs font-cairo cursor-pointer"
                  >
                    {isAr ? 'حذف' : 'Delete'}
                  </button>
                )}
              </div>

              <button
                onClick={() => setViewingInquiry(null)}
                className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs font-cairo cursor-pointer"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MODAL: DELETE INQUIRY CONFIRM ==================== */}
      {deletingInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                {isAr ? 'تأكيد حذف الاستفسار' : 'Delete Inquiry'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {isAr
                  ? `هل أنت متأكد من حذف استفسار "${deletingInquiry.subject}" نهائياً من قاعدة البيانات؟`
                  : `Are you sure you want to delete "${deletingInquiry.subject}"?`}
              </p>
            </div>
            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingInquiry(null)}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={confirmDeleteInquiry}
                disabled={isSubmitting}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-60"
              >
                {isAr ? 'نعم، حذف نهائياً' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
