import React, { useState } from 'react';
import {
  X,
  Lock,
  User,
  UserPlus,
  ShieldCheck,
  Briefcase,
  Eye,
  GraduationCap,
  UserCheck,
  HeartHandshake,
  LogIn,
  KeyRound,
  HelpCircle,
  AlertCircle,
  CheckCircle2,
  EyeOff,
  ArrowRight,
  ArrowLeft,
  Loader2,
  Check,
  Clock,
  Mail,
  Phone,
  Users2,
} from 'lucide-react';
import { UserRole, CurrentUser, Language } from '../types';
import { getOrCreateClientDeviceInfo } from './ScreenProtectionGuard';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: CurrentUser) => void;
  language: Language;
}

const REGISTRATION_ROLES: {
  value: Exclude<UserRole, 'visitor'>;
  labelAr: string;
  labelEn: string;
  descAr: string;
  descEn: string;
  icon: any;
  color: string;
}[] = [
  {
    value: 'admin',
    labelAr: 'مدير عام',
    labelEn: 'General Admin',
    descAr: 'صلاحيات الإدارة العليا وتفعيل الحسابات',
    descEn: 'Full executive & member activation access',
    icon: ShieldCheck,
    color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-800',
  },
  {
    value: 'secretary',
    labelAr: 'سكرتارية',
    labelEn: 'Secretary',
    descAr: 'شؤون الطلاب والشهادات والجداول والمالية',
    descEn: 'Students, certificates, timetable & billing',
    icon: Briefcase,
    color: 'text-pink-600 bg-pink-50 dark:bg-pink-950/60 border-pink-200 dark:border-pink-800',
  },
  {
    value: 'supervisor',
    labelAr: 'مشرفين',
    labelEn: 'Supervisor',
    descAr: 'الإشراف الأكاديمي، الاختبارات، والتقارير',
    descEn: 'Academic supervision, quizzes & triage',
    icon: Eye,
    color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800',
  },
  {
    value: 'teacher',
    labelAr: 'معلم',
    labelEn: 'Teacher',
    descAr: 'الدروس، السبورة، الاختبارات، وتواصل الأولياء',
    descEn: 'Lessons, whiteboard, quizzes & parent chat',
    icon: Users2,
    color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800',
  },
  {
    value: 'student',
    labelAr: 'طالب',
    labelEn: 'Student (Male)',
    descAr: 'الدروس، الاختبارات، السبورة، والشهادات',
    descEn: 'Lessons, exams, whiteboard & certificates',
    icon: GraduationCap,
    color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800',
  },
  {
    value: 'female_student',
    labelAr: 'طالبة',
    labelEn: 'Student (Female)',
    descAr: 'الدروس، الاختبارات، السبورة، والشهادات',
    descEn: 'Lessons, exams, whiteboard & certificates',
    icon: UserCheck,
    color: 'text-teal-600 bg-teal-50 dark:bg-teal-950/60 border-teal-200 dark:border-teal-800',
  },
  {
    value: 'parent',
    labelAr: 'ولي أمر',
    labelEn: 'Parent / Guardian',
    descAr: 'متابعة الأبناء، الشهادات، والرسوم والتواصل',
    descEn: 'Track progress, certificates, fees & chat',
    icon: HeartHandshake,
    color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800',
  },
];

const PRESET_SECURITY_QUESTIONS = [
  'ما هو اسم مدرستك الابتدائية الأولى؟',
  'ما هو اسم أول معلم درّسك في الصغر؟',
  'ما هو كتابك أو مقررك المفضل؟',
  'ما هو اسم المدينة التي ولدت بها؟',
  'ما هو اسم صديق طفولتك المفضل؟',
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  language,
}) => {
  const isAr = language === 'ar';

  const [mode, setMode] = useState<
    'login' | 'register' | 'register_pending' | 'forgot_step1' | 'forgot_step2' | 'forgot_success'
  >('login');

  // Login inputs
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Registration inputs
  const [regDisplayName, setRegDisplayName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRole, setRegRole] = useState<Exclude<UserRole, 'visitor'>>('student');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regSecurityQuestion, setRegSecurityQuestion] = useState(PRESET_SECURITY_QUESTIONS[0]);
  const [regSecurityAnswer, setRegSecurityAnswer] = useState('');
  const [registeredPendingUser, setRegisteredPendingUser] = useState<{
    displayName: string;
    username: string;
    roleTitle: string;
  } | null>(null);

  // Forgot password inputs
  const [forgotIdentifier, setForgotIdentifier] = useState('');
  const [securityQuestion, setSecurityQuestion] = useState('');
  const [foundDisplayName, setFoundDisplayName] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);

  // Status & feedback
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [pendingWarningMessage, setPendingWarningMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const resetMessages = () => {
    setErrorMessage(null);
    setPendingWarningMessage(null);
    setSuccessMessage(null);
  };

  const mapDbUserToCurrentUser = (dbUser: any): CurrentUser => {
    let parsedPermissions: string[] = [];
    try {
      if (typeof dbUser.permissions === 'string') {
        parsedPermissions = JSON.parse(dbUser.permissions || '[]');
      } else if (Array.isArray(dbUser.permissions)) {
        parsedPermissions = dbUser.permissions;
      }
    } catch {
      parsedPermissions = [];
    }

    const isSuper =
      dbUser.uid === 'usr-super-admin' ||
      dbUser.username?.toLowerCase() === 'mo-newfolder' ||
      dbUser.role === 'admin';

    return {
      id: dbUser.uid || `usr-${dbUser.id}`,
      name: dbUser.displayName || dbUser.name || 'مستخدم المنظومة',
      nameEn: dbUser.displayNameEn || dbUser.nameEn || dbUser.displayName || 'User',
      username: dbUser.username || dbUser.email,
      email: dbUser.email || '',
      role: (dbUser.role as UserRole) || 'student',
      roleTitle: dbUser.roleTitle || undefined,
      isActive: dbUser.isActive !== false,
      isSuperAdmin: isSuper,
      permissions: isSuper && parsedPermissions.length === 0 ? ['*'] : parsedPermissions,
      avatar:
        dbUser.avatar ||
        (isSuper ? '/assets/images/certificate_crest_gold_1794403367581.jpg' : undefined),
      studentId: dbUser.studentId || undefined,
      teacherId: dbUser.teacherId || undefined,
      phone: dbUser.phone || undefined,
    };
  };

  // Real DB Login Verification against /api/auth/login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    const cleanId = identifier.trim();
    const cleanPw = password.trim();

    if (!cleanId) {
      setErrorMessage(isAr ? 'يرجى إدخال اسم المستخدم أو البريد الإلكتروني' : 'Please enter username or email');
      return;
    }
    if (!cleanPw) {
      setErrorMessage(isAr ? 'يرجى إدخال كلمة المرور' : 'Please enter password');
      return;
    }

    setIsLoading(true);
    try {
      const deviceInfo = getOrCreateClientDeviceInfo();
      const clientTimezone =
        typeof Intl !== 'undefined'
          ? Intl.DateTimeFormat().resolvedOptions().timeZone
          : undefined;
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: cleanId,
          password: cleanPw,
          clientTimezone,
          ...deviceInfo,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        if (
          data.deviceBlocked ||
          data.deviceLimitBlocked ||
          data.ipMismatchBlocked ||
          data.geoMismatchBlocked
        ) {
          setErrorMessage(
            data.error ||
              (isAr
                ? 'غير مسموح بفتح الحساب على جهاز إضافي أو بعد تغيير الـ IP أو الموقع الجغرافي إلا بالتفعيل من قبل الأدمن.'
                : 'Account access blocked pending Admin activation.')
          );
        } else if (res.status === 403 || data.pendingApproval) {
          setPendingWarningMessage(
            data.error ||
              (isAr
                ? 'حسابك غير مفعل حالياً — لا يمكنك الدخول إلا بعد موافقة وتفعيل الحساب من قِبل المدير العام (الأدمن).'
                : 'Your account is pending Admin activation.')
          );
        } else {
          setErrorMessage(data.error || (isAr ? 'بيانات الدخول غير صحيحة' : 'Invalid login credentials'));
        }
        setIsLoading(false);
        return;
      }

      const mappedUser = mapDbUserToCurrentUser(data.user);
      setSuccessMessage(isAr ? 'تم التحقق من الحساب بنجاح! مرحباً بك' : 'Verified successfully! Welcome');

      setTimeout(() => {
        onLogin(mappedUser);
        onClose();
      }, 350);
    } catch (err: any) {
      setErrorMessage(err.message || (isAr ? 'فشل الاتصال بقاعدة البيانات' : 'Database connection error'));
    } finally {
      setIsLoading(false);
    }
  };

  // Real DB Registration against /api/auth/register (always starts inactive until Admin activates)
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!regDisplayName.trim()) {
      setErrorMessage(isAr ? 'يرجى إدخال الاسم الكامل' : 'Full name is required');
      return;
    }
    if (!regUsername.trim() || regUsername.trim().length < 3) {
      setErrorMessage(isAr ? 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل' : 'Username must be at least 3 chars');
      return;
    }
    if (/\s/.test(regUsername.trim())) {
      setErrorMessage(
        isAr ? 'اسم المستخدم يجب أن لا يحتوي على مسافات' : 'Username must not contain spaces'
      );
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setErrorMessage(isAr ? 'يرجى إدخال بريد إلكتروني صحيح' : 'Valid email is required');
      return;
    }
    if (!regPassword.trim() || regPassword.trim().length < 4) {
      setErrorMessage(isAr ? 'كلمة المرور يجب أن لا تقل عن 4 خانات' : 'Password must be at least 4 chars');
      return;
    }
    if (regPassword.trim() !== regConfirmPassword.trim()) {
      setErrorMessage(isAr ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match');
      return;
    }
    if (!regSecurityAnswer.trim()) {
      setErrorMessage(isAr ? 'يرجى كتابة الإجابة على السؤال السري' : 'Security answer is required');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName: regDisplayName.trim(),
          username: regUsername.trim(),
          email: regEmail.trim().toLowerCase(),
          phone: regPhone.trim(),
          role: regRole,
          password: regPassword.trim(),
          securityQuestion: regSecurityQuestion,
          securityAnswer: regSecurityAnswer.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setErrorMessage(data.error || (isAr ? 'تعذر تسجيل الحساب في قاعدة البيانات' : 'Registration failed'));
        setIsLoading(false);
        return;
      }

      const roleInfo = REGISTRATION_ROLES.find((r) => r.value === regRole);
      setRegisteredPendingUser({
        displayName: regDisplayName.trim(),
        username: regUsername.trim(),
        roleTitle: isAr ? roleInfo?.labelAr || regRole : roleInfo?.labelEn || regRole,
      });

      // Clear form inputs and move to pending confirmation view
      setIdentifier(regUsername.trim());
      setPassword('');
      setRegDisplayName('');
      setRegUsername('');
      setRegEmail('');
      setRegPhone('');
      setRegPassword('');
      setRegConfirmPassword('');
      setRegSecurityAnswer('');
      setMode('register_pending');
    } catch (err: any) {
      setErrorMessage(err.message || (isAr ? 'فشل الاتصال بالخادم' : 'Network error'));
    } finally {
      setIsLoading(false);
    }
  };

  // Step 1: Lookup User Security Question
  const handleFindSecurityQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    const cleanId = forgotIdentifier.trim();
    if (!cleanId) {
      setErrorMessage(isAr ? 'يرجى كتابة اسم المستخدم أو البريد المسجل' : 'Please provide username or registered email');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password/question', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: cleanId }),
      });

      const data = await res.json();
      if (!res.ok || !data.found) {
        setErrorMessage(data.error || (isAr ? 'لم يتم العثور على هذا الحساب في قاعدة البيانات' : 'User account not found'));
        setIsLoading(false);
        return;
      }

      setSecurityQuestion(data.securityQuestion || (isAr ? 'ما هو اسم مدرستك الابتدائية؟' : 'Primary school name?'));
      setFoundDisplayName(data.displayName || cleanId);
      setMode('forgot_step2');
      setSecurityAnswer('');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (err: any) {
      setErrorMessage(err.message || (isAr ? 'تعذر جلب بيانات السؤال السري' : 'Failed to retrieve question'));
    } finally {
      setIsLoading(false);
    }
  };

  // Step 2: Verify Answer & Reset Password
  const handleVerifyAnswerAndReset = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!securityAnswer.trim()) {
      setErrorMessage(isAr ? 'يرجى كتابة الإجابة على السؤال السري' : 'Please provide the answer');
      return;
    }
    if (!newPassword || newPassword.length < 4) {
      setErrorMessage(isAr ? 'يجب أن لا تقل كلمة المرور عن 4 خانات' : 'Password must be at least 4 characters');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setErrorMessage(isAr ? 'كلمتا المرور غير متطابقتين، يرجى المطابقة' : 'Passwords do not match');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: forgotIdentifier.trim(),
          securityAnswer: securityAnswer.trim(),
          newPassword: newPassword.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setErrorMessage(data.error || (isAr ? 'الإجابة على السؤال السري غير صحيحة' : 'Incorrect security answer'));
        setIsLoading(false);
        return;
      }

      if (data.pendingApproval || !data.user) {
        setPendingWarningMessage(
          data.message ||
            (isAr
              ? 'تم تحديث كلمة المرور بنجاح، ولكن الحساب ما زال بانتظار التفعيل من قِبل المدير العام.'
              : 'Password updated, but account is still pending Admin activation.')
        );
        setMode('login');
        setIdentifier(forgotIdentifier.trim());
        return;
      }

      setMode('forgot_success');
      const mappedUser = mapDbUserToCurrentUser(data.user);

      setTimeout(() => {
        onLogin(mappedUser);
        onClose();
      }, 1600);
    } catch (err: any) {
      setErrorMessage(err.message || (isAr ? 'فشلت عملية التحقق' : 'Verification failed'));
    } finally {
      setIsLoading(false);
    }
  };

  const isRegPasswordsMatch = Boolean(
    regPassword && regConfirmPassword && regPassword === regConfirmPassword
  );
  const isRegPasswordsMismatch = Boolean(
    regPassword && regConfirmPassword && regPassword !== regConfirmPassword
  );

  const isForgotPasswordsMatch = Boolean(
    newPassword && confirmNewPassword && newPassword === confirmNewPassword
  );
  const isForgotPasswordsMismatch = Boolean(
    newPassword && confirmNewPassword && newPassword !== confirmNewPassword
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs font-tajawal">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[94vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 md:p-6 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-11 h-11 rounded-2xl flex items-center justify-center shadow-sm text-white ${
                mode === 'register' || mode === 'register_pending'
                  ? 'bg-emerald-700'
                  : mode === 'login'
                  ? 'bg-blue-700'
                  : 'bg-amber-600'
              }`}
            >
              {mode === 'register' || mode === 'register_pending' ? (
                <UserPlus className="w-5 h-5" />
              ) : mode === 'login' ? (
                <Lock className="w-5 h-5" />
              ) : (
                <KeyRound className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-cairo font-bold text-slate-900 dark:text-white text-base md:text-lg">
                {mode === 'login'
                  ? isAr
                    ? 'تسجيل الدخول للمنصة'
                    : 'Platform Sign In'
                  : mode === 'register'
                  ? isAr
                    ? 'إنشاء حساب جديد واختيار الصلاحية'
                    : 'Register New Account & Role'
                  : mode === 'register_pending'
                  ? isAr
                    ? 'تم تسجيل الطلب — بانتظار تفعيل الأدمن'
                    : 'Registration Saved — Pending Activation'
                  : isAr
                  ? 'استعادة الحساب عبر السؤال السري'
                  : 'Account Recovery via Security Question'}
              </h3>
              <p className="text-xs text-slate-500 font-tajawal">
                {mode === 'login'
                  ? isAr
                    ? 'الدخول باسم المستخدم وكلمة المرور المسجلة والمفعلة في قاعدة البيانات'
                    : 'Authenticate using your active username and password in database'
                  : mode === 'register'
                  ? isAr
                    ? 'مدير عام · سكرتارية · مشرفين · معلم · طالب · طالبة · ولي أمر'
                    : 'Admin · Secretary · Supervisor · Teacher · Student · Parent'
                  : mode === 'register_pending'
                  ? isAr
                    ? 'حسابك مسجل في قاعدة البيانات ويحتاج موافقة الإدارة'
                    : 'Your account awaits Administrator activation'
                  : isAr
                  ? 'الإجابة على السؤال السري المحدد لتعيين كلمة مرور جديدة'
                  : 'Answer your registered security question to reset password'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switcher Tabs (Login vs Register) */}
        {(mode === 'login' || mode === 'register') && (
          <div className="px-6 pt-4">
            <div className="grid grid-cols-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  resetMessages();
                }}
                className={`py-2.5 px-4 rounded-xl font-cairo font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  mode === 'login'
                    ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                <LogIn className="w-4 h-4" />
                <span>{isAr ? 'تسجيل الدخول' : 'Sign In'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  resetMessages();
                }}
                className={`py-2.5 px-4 rounded-xl font-cairo font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  mode === 'register'
                    ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>{isAr ? 'إنشاء حساب جديد' : 'Create Account'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Global Pending Approval Warning */}
        {pendingWarningMessage && (
          <div className="mx-6 mt-4 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border-2 border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 text-xs flex items-start gap-3">
            <Clock className="w-5 h-5 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
            <div className="space-y-1">
              <p className="font-cairo font-black text-sm">
                {isAr ? 'الحساب بانتظار تفعيل الأدمن' : 'Pending Admin Activation'}
              </p>
              <p className="font-semibold leading-relaxed">{pendingWarningMessage}</p>
            </div>
          </div>
        )}

        {/* Global Error Alert */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 text-rose-800 dark:text-rose-200 text-xs flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-600 dark:text-rose-400" />
            <span className="font-semibold">{errorMessage}</span>
          </div>
        )}

        {/* Global Success Alert */}
        {successMessage && (
          <div className="mx-6 mt-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
            <span className="font-semibold">{successMessage}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* ================= MODE: LOGIN ================= */}
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Username / Email Field */}
              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'اسم المستخدم (Username) أو البريد الإلكتروني *' : 'Username or Email *'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute top-3.5 right-3.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder={isAr ? 'أدخل اسم المستخدم المسجل في النظام' : 'Enter your registered username or email'}
                    className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-semibold focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Password Field */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                    {isAr ? 'كلمة المرور (Password) *' : 'Password *'}
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot_step1');
                      setForgotIdentifier(identifier);
                      resetMessages();
                    }}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>{isAr ? 'نسيت كلمة المرور؟' : 'Forgot password?'}</span>
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute top-3.5 right-3.5 text-slate-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute top-3 left-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Activation Requirement Notice */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  {isAr
                    ? 'يتم التحقق مباشرة من قاعدة البيانات: لا يُسمح بتسجيل الدخول إلا للحسابات المفعّلة من قِبل المدير العام (الأدمن).'
                    : 'Verified directly against database: only Admin-activated accounts are allowed to sign in.'}
                </span>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 flex items-center justify-center gap-2 py-3 px-6 rounded-2xl bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white font-cairo font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{isAr ? 'جارِ التحقق من الحساب...' : 'Verifying credentials...'}</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>{isAr ? 'تسجيل الدخول والتحقق' : 'Sign In & Verify'}</span>
                  </>
                )}
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    resetMessages();
                  }}
                  className="text-xs font-cairo font-bold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer"
                >
                  {isAr ? 'ليس لديك حساب؟ أنشئ حسابك الجديد الآن ←' : "Don't have an account? Create one now →"}
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: REGISTER ================= */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {/* Role Selection Grid */}
              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-2">
                  {isAr ? 'اختر نوع الحساب / الصلاحية المطلوبة *' : 'Select Account Role *'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {REGISTRATION_ROLES.map((r) => {
                    const Icon = r.icon;
                    const isSelected = regRole === r.value;
                    return (
                      <button
                        key={r.value}
                        type="button"
                        onClick={() => setRegRole(r.value)}
                        className={`p-2.5 rounded-2xl border text-right transition-all flex flex-col gap-1 cursor-pointer ${
                          isSelected
                            ? 'border-emerald-600 bg-emerald-50/80 dark:bg-emerald-950/60 ring-2 ring-emerald-500/40'
                            : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <div
                            className={`w-7 h-7 rounded-lg flex items-center justify-center border ${r.color}`}
                          >
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
                        </div>
                        <p className="font-cairo font-bold text-xs text-slate-900 dark:text-white mt-0.5">
                          {isAr ? r.labelAr : r.labelEn}
                        </p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-snug line-clamp-2">
                          {isAr ? r.descAr : r.descEn}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Name & Username */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'الاسم الكامل *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={regDisplayName}
                    onChange={(e) => setRegDisplayName(e.target.value)}
                    placeholder={isAr ? 'مثال: سارة محمد العتيبي' : 'Full Name'}
                    className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم المستخدم للدخول (Username) *' : 'Login Username *'}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={regUsername}
                      onChange={(e) => setRegUsername(e.target.value)}
                      placeholder="e.g. sara_2026"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Email & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'البريد الإلكتروني *' : 'Email Address *'}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="user@nawabegh.edu"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'رقم الجوال' : 'Phone Number'}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute top-2.5 right-3 text-slate-400" />
                    <input
                      type="text"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+966 50 000 0000"
                      className="w-full pl-3 pr-9 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Password & Confirm Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      {isAr ? 'كلمة المرور *' : 'Password *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="text-[11px] text-slate-500 hover:text-emerald-600 flex items-center gap-1 cursor-pointer"
                    >
                      {showRegPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showRegPassword ? (isAr ? 'إخفاء' : 'Hide') : (isAr ? 'إظهار' : 'Show')}</span>
                    </button>
                  </div>
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    minLength={4}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      {isAr ? 'تأكيد كلمة المرور *' : 'Confirm Password *'}
                    </label>
                    {isRegPasswordsMatch && (
                      <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                        <Check className="w-3 h-3" /> {isAr ? 'متطابقة' : 'Match'}
                      </span>
                    )}
                    {isRegPasswordsMismatch && (
                      <span className="text-[10px] text-rose-600 font-bold">
                        {isAr ? 'غير متطابقة' : 'Mismatch'}
                      </span>
                    )}
                  </div>
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    minLength={4}
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-white dark:bg-slate-800 border text-slate-900 dark:text-white font-mono focus:outline-hidden ${
                      isRegPasswordsMatch
                        ? 'border-emerald-500 ring-1 ring-emerald-500'
                        : isRegPasswordsMismatch
                        ? 'border-rose-500 ring-1 ring-rose-500'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  />
                </div>
              </div>

              {/* Security Question & Answer */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'سؤال الأمان لاستعادة الحساب *' : 'Security Question *'}
                  </label>
                  <select
                    value={regSecurityQuestion}
                    onChange={(e) => setRegSecurityQuestion(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden cursor-pointer"
                  >
                    {PRESET_SECURITY_QUESTIONS.map((q) => (
                      <option key={q} value={q}>
                        {q}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'الإجابة السرية *' : 'Secret Answer *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={regSecurityAnswer}
                    onChange={(e) => setRegSecurityAnswer(e.target.value)}
                    placeholder={isAr ? 'اكتب إجابتك السرية هنا' : 'Your secret answer'}
                    className="w-full px-3 py-2 text-xs md:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Admin Activation Notice */}
              <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span className="font-semibold leading-relaxed">
                  {isAr
                    ? 'تنبيه هام: يتم تسجيل الحساب بحالة (قيد التفعيل)، ولن تتمكن من تسجيل الدخول إلا بعد مراجعة الحساب وتفعيله من قِبل المدير العام (الأدمن).'
                    : 'Notice: Newly registered accounts start inactive and cannot sign in until activated by the General Admin.'}
                </span>
              </div>

              <button
                type="submit"
                disabled={isLoading || isRegPasswordsMismatch}
                className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white font-cairo font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{isAr ? 'جارِ حفظ الحساب في قاعدة البيانات...' : 'Saving account...'}</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>{isAr ? 'تسجيل الحساب وإرساله للتفعيل' : 'Register & Submit for Approval'}</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* ================= MODE: REGISTER PENDING APPROVAL ================= */}
          {mode === 'register_pending' && (
            <div className="py-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto shadow-sm border border-amber-200 dark:border-amber-800">
                <Clock className="w-8 h-8" />
              </div>

              <div className="space-y-1.5">
                <h4 className="font-cairo font-black text-lg text-slate-900 dark:text-white">
                  {isAr ? 'تم استلام طلب تسجيل حسابك بنجاح!' : 'Account Registration Submitted!'}
                </h4>
                <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 font-tajawal max-w-md mx-auto leading-relaxed">
                  {isAr
                    ? 'تم حفظ بياناتك في قاعدة البيانات بنجاح. الحساب الآن في انتظار التفعيل من قِبل المدير العام (الأدمن)، ولن تستطيع تسجيل الدخول قبل تفعيله.'
                    : 'Your account is saved in the database. An Administrator must activate it before you can sign in.'}
                </p>
              </div>

              {registeredPendingUser && (
                <div className="max-w-sm mx-auto p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-right space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'الاسم:' : 'Name:'}</span>
                    <span className="font-bold text-slate-900 dark:text-white">
                      {registeredPendingUser.displayName}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'اسم المستخدم:' : 'Username:'}</span>
                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                      @{registeredPendingUser.username}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'الصلاحية:' : 'Role:'}</span>
                    <span className="font-bold text-emerald-700 dark:text-emerald-400">
                      {registeredPendingUser.roleTitle}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{isAr ? 'حالة التفعيل:' : 'Status:'}</span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[11px]">
                      {isAr ? 'بانتظار تفعيل الأدمن' : 'Pending Activation'}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    resetMessages();
                  }}
                  className="px-6 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-cairo font-bold text-xs md:text-sm shadow-sm cursor-pointer"
                >
                  {isAr ? 'الانتقال لصفحة تسجيل الدخول' : 'Go to Sign In'}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-cairo font-bold text-xs md:text-sm cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          )}

          {/* ================= MODE: FORGOT PASSWORD STEP 1 ================= */}
          {mode === 'forgot_step1' && (
            <form onSubmit={handleFindSecurityQuestion} className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50">
                <h4 className="font-cairo font-bold text-xs text-amber-900 dark:text-amber-200 mb-1 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-600" />
                  <span>{isAr ? 'خطوة 1 من 2: تحديد الحساب' : 'Step 1 of 2: Identify Account'}</span>
                </h4>
                <p className="text-xs text-amber-800 dark:text-amber-300">
                  {isAr
                    ? 'أدخل اسم المستخدم أو البريد الإلكتروني المسجل في المنظومة لاسترجاع السؤال السري الخاص بك.'
                    : 'Enter your registered username or email to retrieve your security question.'}
                </p>
              </div>

              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'اسم المستخدم أو البريد الإلكتروني *' : 'Username or Email *'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute top-3.5 right-3.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={forgotIdentifier}
                    onChange={(e) => setForgotIdentifier(e.target.value)}
                    placeholder={isAr ? 'اسم المستخدم أو البريد الإلكتروني' : 'Username or email'}
                    className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    resetMessages();
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {isAr ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                  <span>{isAr ? 'الرجوع للدخول' : 'Back to Login'}</span>
                </button>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white font-cairo font-bold text-xs md:text-sm shadow-md transition-all cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{isAr ? 'جارِ البحث...' : 'Searching...'}</span>
                    </>
                  ) : (
                    <>
                      <HelpCircle className="w-4 h-4" />
                      <span>{isAr ? 'عرض السؤال السري' : 'Show Security Question'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: FORGOT PASSWORD STEP 2 ================= */}
          {mode === 'forgot_step2' && (
            <form onSubmit={handleVerifyAnswerAndReset} className="space-y-4">
              <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/50">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 font-cairo">
                    {isAr ? 'الحساب المطلوب:' : 'Account:'} {foundDisplayName}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-200 dark:bg-blue-900 text-blue-800 dark:text-blue-200 font-bold">
                    {isAr ? 'خطوة 2 من 2' : 'Step 2 of 2'}
                  </span>
                </div>
                <div className="flex items-start gap-2.5 pt-1">
                  <HelpCircle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-200 font-cairo">
                      {isAr ? 'السؤال السري المسجل في حسابك:' : 'Registered Security Question:'}
                    </p>
                    <p className="text-sm font-black text-blue-900 dark:text-blue-200 mt-1 font-cairo">
                      "{securityQuestion}"
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-cairo font-bold text-xs text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'الإجابة على السؤال السري *' : 'Security Answer *'}
                </label>
                <input
                  type="text"
                  required
                  value={securityAnswer}
                  onChange={(e) => setSecurityAnswer(e.target.value)}
                  placeholder={isAr ? 'اكتب إجابتك السرية هنا...' : 'Enter your secret answer...'}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      {isAr ? 'كلمة المرور الجديدة *' : 'New Password *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="text-slate-400 hover:text-slate-600 text-xs flex items-center gap-1 cursor-pointer"
                    >
                      {showNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    minLength={4}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-mono-numbers focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-cairo font-bold text-xs text-slate-700 dark:text-slate-300">
                      {isAr ? 'تأكيد كلمة المرور *' : 'Confirm Password *'}
                    </label>
                    {isForgotPasswordsMatch && (
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-0.5">
                        <Check className="w-3 h-3" /> {isAr ? 'متطابقة' : 'Match'}
                      </span>
                    )}
                    {isForgotPasswordsMismatch && (
                      <span className="text-[10px] text-rose-600 dark:text-rose-400 font-bold">
                        {isAr ? 'غير متطابقة' : 'Mismatch'}
                      </span>
                    )}
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    minLength={4}
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border text-slate-900 dark:text-white font-mono-numbers focus:outline-hidden ${
                      isForgotPasswordsMatch
                        ? 'border-emerald-500 ring-1 ring-emerald-500'
                        : isForgotPasswordsMismatch
                        ? 'border-rose-500 ring-1 ring-rose-500'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('forgot_step1');
                    resetMessages();
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {isAr ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                  <span>{isAr ? 'السابق' : 'Previous'}</span>
                </button>

                <button
                  type="submit"
                  disabled={isLoading || isForgotPasswordsMismatch}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-cairo font-bold text-xs md:text-sm shadow-md transition-all cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{isAr ? 'جارِ التحقق وتعيين كلمة المرور...' : 'Verifying & resetting...'}</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isAr ? 'التحقق وتعيين الباسورد والدخول' : 'Verify, Reset & Sign In'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: FORGOT SUCCESS ================= */}
          {mode === 'forgot_success' && (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-cairo font-black text-lg text-slate-900 dark:text-white">
                  {isAr ? 'تم التحقق وتحديث كلمة المرور بنجاح!' : 'Password Reset Successfully!'}
                </h4>
                <p className="text-xs text-slate-500 font-tajawal mt-1">
                  {isAr
                    ? 'تم حفظ كلمة المرور الجديدة في قاعدة البيانات وسيتم توجيهك الآن للمنظومة مباشرة...'
                    : 'Your new password is saved. Redirecting to platform...'}
                </p>
              </div>
              <div className="flex items-center justify-center gap-2 text-xs text-blue-600 font-bold">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{isAr ? 'جارِ الدخول...' : 'Logging in...'}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
