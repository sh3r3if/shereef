import type http from 'http';
import { Server as SocketIOServer, type Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { classroomRedis } from './redisClient.ts';
import { verifyClassroomToken } from './authMiddleware.ts';
import { canModerateRoom } from './config.ts';
import { SlidingWindowRateLimiter } from './rateLimiter.ts';
import * as roomRepo from './roomRepository.ts';
import type {
  ClassroomParticipant,
  ClassroomRole,
  ConnectionQualityLevel,
} from '../../src/types/classroom.ts';

interface RoomRuntimeState {
  participants: Map<string, ClassroomParticipant>; // keyed by socketId
}

const roomStates = new Map<string, RoomRuntimeState>();
let ioInstance: SocketIOServer | null = null;

function getOrCreateRoomState(roomId: string): RoomRuntimeState {
  let state = roomStates.get(roomId);
  if (!state) {
    state = { participants: new Map() };
    roomStates.set(roomId, state);
  }
  return state;
}

export function getRoomActiveParticipantCount(roomId: string): number {
  const state = roomStates.get(roomId);
  return state ? state.participants.size : 0;
}

export function getRoomParticipantsList(roomId: string): ClassroomParticipant[] {
  const state = roomStates.get(roomId);
  return state ? Array.from(state.participants.values()) : [];
}

export function broadcastRoomSettingsUpdate(roomId: string, roomPayload: any) {
  if (!ioInstance) return;
  ioInstance.of('/classroom').to(`room:${roomId}`).emit('classroom:room_updated', roomPayload);
}

export async function initClassroomSocketGateway(httpServer: http.Server): Promise<SocketIOServer> {
  if (ioInstance) return ioInstance;

  await classroomRedis.initialize();

  const io = new SocketIOServer(httpServer, {
    path: '/socket.io-classroom',
    cors: {
      origin: true,
      credentials: true,
    },
    pingInterval: 15000,
    pingTimeout: 20000,
  });

  const redisClients = classroomRedis.getAdapterClients();
  if (redisClients) {
    io.adapter(createAdapter(redisClients.pubClient, redisClients.subClient));
    console.log('⚡ [LiveClassroom] Socket.IO Redis Adapter attached for horizontal scaling.');
  }

  const socketLimiter = new SlidingWindowRateLimiter(120, 10_000);
  const namespace = io.of('/classroom');

  // JWT Handshake Auth Middleware
  namespace.use((socket, next) => {
    try {
      const token =
        String(socket.handshake.auth?.token || '') ||
        String(socket.handshake.query?.token || '');
      if (!token) {
        return next(new Error('AUTH_REQUIRED'));
      }
      const decoded = verifyClassroomToken(token);
      (socket.data as any).auth = decoded;
      return next();
    } catch {
      return next(new Error('INVALID_OR_EXPIRED_TOKEN'));
    }
  });

  namespace.on('connection', async (socket: Socket) => {
    const auth = (socket.data as any).auth as {
      userId: string;
      userName: string;
      role: ClassroomRole;
      roomId: string;
    };

    const roomId = auth.roomId;
    const roomChannel = `room:${roomId}`;
    const state = getOrCreateRoomState(roomId);
    const isModerator = canModerateRoom(auth.role);

    await socket.join(roomChannel);

    const participant: ClassroomParticipant = {
      userId: auth.userId,
      socketId: socket.id,
      userName: auth.userName,
      role: auth.role,
      isMicEnabled: false,
      isCamEnabled: false,
      isScreenSharing: false,
      canDraw: isModerator,
      canSpeak: isModerator,
      handRaised: false,
      connectionQuality: 'excellent',
      joinedAt: Date.now(),
    };

    // Remove duplicate stale sockets for the same userId inside the room
    for (const [oldSocketId, existing] of state.participants.entries()) {
      if (existing.userId === auth.userId && oldSocketId !== socket.id) {
        state.participants.delete(oldSocketId);
      }
    }
    state.participants.set(socket.id, participant);

    // Send initial authoritative room snapshot to joining/reconnecting client
    const roomInfo = await roomRepo.getLiveRoomByIdOrCode(roomId);
    socket.emit('classroom:state_sync', {
      room: roomInfo,
      self: participant,
      participants: Array.from(state.participants.values()),
      serverTime: Date.now(),
    });

    // Notify everyone else of updated roster
    socket.to(roomChannel).emit('classroom:participant_joined', participant);

    // Broadcast active media state changes (Mic / Cam / ScreenShare)
    socket.on(
      'media:state_changed',
      (payload: {
        isMicEnabled?: boolean;
        isCamEnabled?: boolean;
        isScreenSharing?: boolean;
      }) => {
        if (!socketLimiter.check(`${socket.id}:media`).allowed) return;
        const current = state.participants.get(socket.id);
        if (!current) return;

        if (typeof payload.isMicEnabled === 'boolean') {
          // Enforce server RBAC: students can unmute only if permitted or room allows
          current.isMicEnabled = payload.isMicEnabled;
        }
        if (typeof payload.isCamEnabled === 'boolean') {
          current.isCamEnabled = payload.isCamEnabled;
        }
        if (typeof payload.isScreenSharing === 'boolean') {
          current.isScreenSharing = canModerateRoom(current.role)
            ? payload.isScreenSharing
            : false;
        }

        namespace.to(roomChannel).emit('classroom:participant_updated', current);
      }
    );

    // Connection quality telemetry per user
    socket.on('media:quality_report', (payload: { quality: ConnectionQualityLevel }) => {
      if (!socketLimiter.check(`${socket.id}:quality`).allowed) return;
      const current = state.participants.get(socket.id);
      if (!current) return;
      current.connectionQuality = payload.quality || 'unknown';
      namespace.to(roomChannel).emit('classroom:participant_updated', current);
    });

    // WebRTC P2P fallback signaling for camera/mic/screen when external LiveKit SFU isn't running
    socket.on('webrtc:peer_ready', () => {
      socket.to(roomChannel).emit('webrtc:peer_ready', {
        fromSocketId: socket.id,
        userId: auth.userId,
        userName: auth.userName,
        role: auth.role,
      });
    });

    socket.on(
      'webrtc:offer',
      (payload: { targetSocketId: string; sdp: RTCSessionDescriptionInit }) => {
        if (!payload?.targetSocketId || !payload?.sdp) return;
        namespace.to(payload.targetSocketId).emit('webrtc:offer', {
          fromSocketId: socket.id,
          userId: auth.userId,
          userName: auth.userName,
          role: auth.role,
          sdp: payload.sdp,
        });
      }
    );

    socket.on(
      'webrtc:answer',
      (payload: { targetSocketId: string; sdp: RTCSessionDescriptionInit }) => {
        if (!payload?.targetSocketId || !payload?.sdp) return;
        namespace.to(payload.targetSocketId).emit('webrtc:answer', {
          fromSocketId: socket.id,
          sdp: payload.sdp,
        });
      }
    );

    socket.on(
      'webrtc:ice_candidate',
      (payload: { targetSocketId: string; candidate: RTCIceCandidateInit }) => {
        if (!payload?.targetSocketId || !payload?.candidate) return;
        namespace.to(payload.targetSocketId).emit('webrtc:ice_candidate', {
          fromSocketId: socket.id,
          candidate: payload.candidate,
        });
      }
    );

    socket.on('disconnect', () => {
      const removed = state.participants.get(socket.id);
      state.participants.delete(socket.id);
      if (removed) {
        namespace.to(roomChannel).emit('classroom:participant_left', {
          socketId: socket.id,
          userId: removed.userId,
        });
      }
      if (state.participants.size === 0) {
        roomStates.delete(roomId);
      }
    });
  });

  ioInstance = io;
  console.log('✅ [LiveClassroom] Socket.IO Gateway mounted at /socket.io-classroom (namespace /classroom)');
  return io;
}
