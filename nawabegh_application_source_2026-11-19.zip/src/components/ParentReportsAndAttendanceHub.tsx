import React, { useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import {
  QrCode,
  MessageCircle,
  CheckCircle2,
  XCircle,
  Clock,
  Camera,
  CameraOff,
  Download,
  Copy,
  Check,
  Search,
  RefreshCw,
  BookOpenCheck,
  Award,
  CalendarX2,
  Timer,
  Plus,
  Send,
  Users,
  Sparkles,
  ScanLine,
  Building2,
  Wifi,
  Save,
  UserCheck,
  AlertCircle,
  Mail,
} from 'lucide-react';
import {
  CenterAttendanceSession,
  CurrentUser,
  Language,
  Lesson,
  QrAttendanceRecord,
  Quiz,
  QuizAttempt,
  SchoolSettings,
  Student,
  Teacher,
  WeeklyParentReportSummary,
} from '../types';
import {
  getAuthHeaders,
  isAdminStaffRole,
  isParentRole,
  isStudentRole,
  isTeacherRole,
  resolveMatchedStudent,
} from '../utils/rbac';
import {
  getSafeAvatarUrl,
  handleImageErrorToTeacherAvatar,
} from '../utils/avatarFallback';

interface ParentReportsAndAttendanceHubProps {
  students: Student[];
  lessons: Lesson[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  teachers?: Teacher[];
  settings: SchoolSettings;
  currentUser: CurrentUser;
  language: Language;
  onStudentUpdated?: (updatedStudent: Student) => void;
}

function normalizePhoneForWhatsapp(rawPhone: string): string {
  const digits = String(rawPhone || '').replace(/[^\d]/g, '');
  if (!digits) return '';
  if (digits.startsWith('00')) return digits.slice(2);
  // Egyptian mobile: 010, 011, 012, 015 (11 digits) -> 201...
  if (digits.length === 11 && digits.startsWith('01')) {
    return `2${digits}`;
  }
  // Saudi mobile: 05xxxxxxxx (10 digits) -> 9665xxxxxxxx
  if (digits.length === 10 && digits.startsWith('05')) {
    return `966${digits.slice(1)}`;
  }
  if (digits.startsWith('0')) {
    return digits.slice(1);
  }
  return digits;
}

export const ParentReportsAndAttendanceHub: React.FC<ParentReportsAndAttendanceHubProps> = ({
  students,
  teachers = [],
  settings,
  currentUser,
  language,
  onStudentUpdated,
}) => {
  const isAr = language === 'ar';
  const isStudent = isStudentRole(currentUser.role);
  const isParent = isParentRole(currentUser.role);
  const isStaff = isAdminStaffRole(currentUser.role) || isTeacherRole(currentUser.role);

  const [subTab, setSubTab] = useState<'reports' | 'qr_attendance'>(
    isStudent ? 'qr_attendance' : 'reports'
  );

  // Weekly Parent Reports state
  const [reports, setReports] = useState<WeeklyParentReportSummary[]>([]);
  const [weekLabel, setWeekLabel] = useState<string>('');
  const [isLoadingReports, setIsLoadingReports] = useState<boolean>(true);
  const [selectedReportStudentId, setSelectedReportStudentId] = useState<string>('');
  const [reportSearch, setReportSearch] = useState<string>('');
  const [reportTypeFilter, setReportTypeFilter] = useState<'all' | 'offline' | 'online'>('all');

  // Teacher note & optional calibration state
  const [customNoteInput, setCustomNoteInput] = useState<string>('');
  const [manualHoursInput, setManualHoursInput] = useState<string>('');
  const [manualAbsenceInput, setManualAbsenceInput] = useState<string>('');
  const [overridePhoneInput, setOverridePhoneInput] = useState<string>('');
  const [isSavingReportLog, setIsSavingReportLog] = useState<boolean>(false);
  const [copiedReport, setCopiedReport] = useState<boolean>(false);

  // QR Attendance state
  const [sessions, setSessions] = useState<CenterAttendanceSession[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<QrAttendanceRecord[]>([]);
  const [qrStudents, setQrStudents] = useState<Student[]>(students);
  const [isLoadingQr, setIsLoadingQr] = useState<boolean>(true);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [selectedCardStudentId, setSelectedCardStudentId] = useState<string>('');
  const [qrCardDataUrl, setQrCardDataUrl] = useState<string>('');
  const [manualQrInput, setManualQrInput] = useState<string>('');
  const [rosterSearch, setRosterSearch] = useState<string>('');
  const [isCheckingIn, setIsCheckingIn] = useState<boolean>(false);

  // Create Center Session form
  const [showNewSessionForm, setShowNewSessionForm] = useState<boolean>(false);
  const [newSessTitle, setNewSessTitle] = useState<string>('');
  const [newSessSubject, setNewSessSubject] = useState<string>('');
  const [newSessGrade, setNewSessGrade] = useState<string>('الصف الثالث الثانوي');
  const [newSessHall, setNewSessHall] = useState<string>('قاعة السنتر الرئيسية');
  const [newSessDate, setNewSessDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [isCreatingSession, setIsCreatingSession] = useState<boolean>(false);

  // Live Camera QR Scanner
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const lastScanCooldownRef = useRef<{ value: string; time: number }>({ value: '', time: 0 });
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [barcodeDetectorSupported, setBarcodeDetectorSupported] = useState<boolean>(true);

  const [toast, setToast] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(
    null
  );

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 4000);
  };

  const matchedOwnStudent = useMemo(
    () => resolveMatchedStudent(currentUser, qrStudents.length > 0 ? qrStudents : students),
    [currentUser, qrStudents, students]
  );

  useEffect(() => {
    if (students.length > 0) {
      setQrStudents(students);
    }
  }, [students]);

  const fetchWeeklyReports = async () => {
    setIsLoadingReports(true);
    try {
      const res = await fetch('/api/parent-reports/weekly');
      if (res.ok) {
        const data = await res.json();
        setWeekLabel(data.weekLabel || '');
        const list: WeeklyParentReportSummary[] = Array.isArray(data.reports) ? data.reports : [];
        setReports(list);
        if (list.length > 0) {
          setSelectedReportStudentId((prev) => {
            if (prev && list.some((r) => r.studentId === prev)) return prev;
            if ((isStudent || isParent) && matchedOwnStudent) {
              const own = list.find((r) => r.studentId === matchedOwnStudent.id);
              if (own) return own.studentId;
            }
            return list[0].studentId;
          });
        }
      }
    } catch (err) {
      console.warn('Error fetching weekly parent reports:', err);
    } finally {
      setIsLoadingReports(false);
    }
  };

  const fetchQrAttendanceState = async () => {
    setIsLoadingQr(true);
    try {
      const res = await fetch('/api/attendance/qr-state');
      if (res.ok) {
        const data = await res.json();
        const loadedSessions: CenterAttendanceSession[] = Array.isArray(data.sessions)
          ? data.sessions
          : [];
        const loadedRecords: QrAttendanceRecord[] = Array.isArray(data.records)
          ? data.records
          : [];
        const loadedStudents: Student[] = Array.isArray(data.students) ? data.students : students;

        setSessions(loadedSessions);
        setAttendanceRecords(loadedRecords);
        setQrStudents(loadedStudents);

        if (loadedSessions.length > 0) {
          setSelectedSessionId((prev) =>
            prev && loadedSessions.some((s) => s.id === prev) ? prev : loadedSessions[0].id
          );
        } else {
          setSelectedSessionId(`daily-${new Date().toISOString().split('T')[0]}`);
        }

        if (loadedStudents.length > 0) {
          setSelectedCardStudentId((prev) => {
            if (prev && loadedStudents.some((s) => s.id === prev)) return prev;
            if ((isStudent || isParent) && matchedOwnStudent) return matchedOwnStudent.id;
            const centerFirst = loadedStudents.find((s) => s.type === 'offline');
            return (centerFirst || loadedStudents[0]).id;
          });
        }
      }
    } catch (err) {
      console.warn('Error fetching QR attendance state:', err);
    } finally {
      setIsLoadingQr(false);
    }
  };

  useEffect(() => {
    fetchWeeklyReports();
    fetchQrAttendanceState();
  }, []);

  // Scoped reports (students & parents only see their own report; staff see all filtered)
  const visibleReports = useMemo(() => {
    let base = reports;
    if (isStudent || isParent) {
      if (matchedOwnStudent) {
        base = reports.filter((r) => r.studentId === matchedOwnStudent.id);
      } else {
        const emailLower = (currentUser.email || '').trim().toLowerCase();
        const nameLower = (currentUser.name || '').trim().toLowerCase();
        base = reports.filter(
          (r) =>
            r.studentName.trim().toLowerCase() === nameLower ||
            (emailLower && r.parentName.trim().toLowerCase() === nameLower)
        );
      }
      return base;
    }

    return base.filter((r) => {
      const matchesType = reportTypeFilter === 'all' || r.studentType === reportTypeFilter;
      const q = reportSearch.trim().toLowerCase();
      const matchesQ =
        !q ||
        r.studentName.toLowerCase().includes(q) ||
        r.studentCode.toLowerCase().includes(q) ||
        r.parentName.toLowerCase().includes(q) ||
        r.parentPhone.toLowerCase().includes(q);
      return matchesType && matchesQ;
    });
  }, [reports, isStudent, isParent, matchedOwnStudent, currentUser, reportTypeFilter, reportSearch]);

  const activeReport = useMemo(() => {
    if (visibleReports.length === 0) return null;
    return (
      visibleReports.find((r) => r.studentId === selectedReportStudentId) || visibleReports[0]
    );
  }, [visibleReports, selectedReportStudentId]);

  useEffect(() => {
    if (!activeReport) return;
    setCustomNoteInput(activeReport.customTeacherNote || '');
    setManualHoursInput(String(activeReport.studyHours ?? 0));
    setManualAbsenceInput(String(activeReport.absenceDays ?? 0));
    setOverridePhoneInput(activeReport.parentPhone || '');
  }, [activeReport?.studentId]);

  // Build formatted WhatsApp report message
  const formattedWhatsappText = useMemo(() => {
    if (!activeReport) return '';
    const platformName = settings.schoolName || 'منصة الشريف التعليمية';
    const lessonsLine =
      activeReport.completedLessonTitles.length > 0
        ? activeReport.completedLessonTitles.slice(0, 6).join('، ')
        : 'لم يتم إنهاء دروس جديدة هذا الأسبوع بعد';

    const examsLines =
      activeReport.examDetails.length > 0
        ? activeReport.examDetails
            .slice(0, 4)
            .map((ex) => `   • ${ex.title} (${ex.subject}): ${ex.scoreText} (${ex.percentage}%)`)
            .join('\n')
        : `   • التقييم التراكمي العام: ${activeReport.averageExamScore}%`;

    const lines = [
      `🎓 *${platformName}* — *بطاقة التقرير الأسبوعي الذكي لولي الأمر*`,
      `السلام عليكم ورحمة الله وبركاته ولي أمر الطالب/ة الفاضل: *${activeReport.parentName}*`,
      ``,
      `👤 *بيانات الطالب:* ${activeReport.studentName} (${activeReport.studentCode})`,
      `📚 *الصف الدراسي:* ${activeReport.studentGrade}`,
      `📅 *الفترة:* ${activeReport.weekLabel}`,
      ``,
      `📊 *ملخص الأداء الأسبوعي:*`,
      `⏱️ *ساعات المذاكرة:* ${activeReport.studyHours} ساعة`,
      `✅ *الدروس المنجزة:* ${activeReport.completedLessonsCount} درس (${lessonsLine})`,
      `📝 *الاختبارات (${activeReport.examsCount}):* متوسط ${activeReport.averageExamScore}%`,
      examsLines,
      `📌 *الحضور والغياب:* ${activeReport.absenceDays} أيام غياب | ${activeReport.attendanceDays} أيام حضور (نسبة الالتزام ${activeReport.attendanceRate}%)`,
      `📂 *الواجبات المسلمة:* ${activeReport.assignmentsSubmittedCount} واجب`,
    ];

    if (activeReport.weakestSubject) {
      lines.push(
        `🎯 *أكثر مادة يحتاج الطالب دعماً فيها:* ${activeReport.weakestSubject}${
          activeReport.weakestSubjectScore !== null && activeReport.weakestSubjectScore !== undefined
            ? ` (متوسط ${activeReport.weakestSubjectScore}%)`
            : ''
        }`
      );
    }

    if (customNoteInput.trim()) {
      lines.push(``, `💬 *ملاحظة المعلم والإدارة:* ${customNoteInput.trim()}`);
    }

    lines.push(``, `مع تمنيات *${platformName}* بدوام التوفيق والتميز 🌟`);
    return lines.join('\n');
  }, [activeReport, settings.schoolName, customNoteInput]);

  const effectiveWhatsappPhone = normalizePhoneForWhatsapp(
    overridePhoneInput || activeReport?.parentPhone || ''
  );

  const whatsappHref = useMemo(() => {
    const encoded = encodeURIComponent(formattedWhatsappText);
    if (effectiveWhatsappPhone) {
      return `https://wa.me/${effectiveWhatsappPhone}?text=${encoded}`;
    }
    return `https://wa.me/?text=${encoded}`;
  }, [effectiveWhatsappPhone, formattedWhatsappText]);

  const handleSaveReportMetadata = async (markSentViaWhatsapp = false) => {
    if (!activeReport || !isStaff) return;
    setIsSavingReportLog(true);
    try {
      const res = await fetch('/api/parent-reports/weekly/log', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          studentId: activeReport.studentId,
          studentName: activeReport.studentName,
          customTeacherNote: customNoteInput,
          manualStudyHours: manualHoursInput !== '' ? Number(manualHoursInput) : undefined,
          manualAbsenceDays: manualAbsenceInput !== '' ? Number(manualAbsenceInput) : undefined,
          markSentViaWhatsapp,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'تعذر حفظ التقرير في قاعدة البيانات');
      }
      await fetchWeeklyReports();
      showToast(
        markSentViaWhatsapp
          ? `تم فتح واتساب وتوثيق إرسال تقرير (${activeReport.studentName}) في قاعدة البيانات ✓`
          : `تم حفظ التعديلات وملاحظة المعلم للطالب (${activeReport.studentName}) ✓`,
        'success'
      );
    } catch (err: any) {
      showToast(err.message || 'حدث خطأ أثناء الحفظ', 'error');
    } finally {
      setIsSavingReportLog(false);
    }
  };

  const handleCopyReportText = async () => {
    try {
      await navigator.clipboard.writeText(formattedWhatsappText);
      setCopiedReport(true);
      showToast('تم نسخ بطاقة التقرير الأسبوعي بنجاح ✓', 'info');
      setTimeout(() => setCopiedReport(false), 2500);
    } catch {
      showToast('تعذر النسخ التلقائي — يرجى تحديد النص ونسخه يدوياً', 'error');
    }
  };

  // ================= QR STUDENT ID CARD GENERATION =================
  const activeCardStudent = useMemo(() => {
    if ((isStudent || isParent) && matchedOwnStudent) return matchedOwnStudent;
    return qrStudents.find((s) => s.id === selectedCardStudentId) || qrStudents[0] || null;
  }, [isStudent, isParent, matchedOwnStudent, qrStudents, selectedCardStudentId]);

  useEffect(() => {
    if (!activeCardStudent) {
      setQrCardDataUrl('');
      return;
    }
    const payload = `ALSHARIF-ATTEND:${activeCardStudent.id}:${activeCardStudent.code}`;
    QRCode.toDataURL(payload, {
      width: 280,
      margin: 2,
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then((url) => setQrCardDataUrl(url))
      .catch((err) => console.warn('QR generation error:', err));
  }, [activeCardStudent?.id, activeCardStudent?.code]);

  const handleDownloadStudentQrCard = async () => {
    if (!activeCardStudent || !qrCardDataUrl) return;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 720;
      canvas.height = 960;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Top Header Gradient Bar
      const grad = ctx.createLinearGradient(0, 0, canvas.width, 190);
      grad.addColorStop(0, '#065f46');
      grad.addColorStop(1, '#0f766e');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, 190);

      // Platform Title
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.font = 'bold 34px sans-serif';
      ctx.fillText(settings.schoolName || 'منصة الشريف التعليمية', 360, 75);
      ctx.fillStyle = '#a7f3d0';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText('بطاقة الطالب الرقمية للحضور بالـ QR Code (السنتر)', 360, 128);

      // Student Details
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 34px sans-serif';
      ctx.fillText(activeCardStudent.name, 360, 265);

      ctx.fillStyle = '#475569';
      ctx.font = '24px sans-serif';
      ctx.fillText(
        `${activeCardStudent.grade}  |  ${
          activeCardStudent.type === 'offline' ? 'طالب سنتر حضوري' : 'طالب أونلاين'
        }`,
        360,
        312
      );

      ctx.fillStyle = '#065f46';
      ctx.font = 'bold 28px monospace';
      ctx.fillText(`CODE: ${activeCardStudent.code}`, 360, 360);

      // Draw QR Code Image centered
      const qrImg = new Image();
      qrImg.src = qrCardDataUrl;
      await new Promise<void>((resolve) => {
        qrImg.onload = () => resolve();
        qrImg.onerror = () => resolve();
      });

      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 4;
      ctx.strokeRect(180, 395, 360, 360);
      ctx.drawImage(qrImg, 200, 415, 320, 320);

      // Footer Instructions
      ctx.fillStyle = '#334155';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText('يُمسح هذا الرمز بكاميرا المعلم أو المشرف عند دخول القاعة', 360, 825);
      ctx.fillStyle = '#64748b';
      ctx.font = '18px monospace';
      ctx.fillText(`ALSHARIF-ATTEND:${activeCardStudent.id}:${activeCardStudent.code}`, 360, 875);

      const link = document.createElement('a');
      link.download = `qr-card-${activeCardStudent.code}.png`;
      link.href = canvas.toDataURL('image/png');
      document.body.appendChild(link);
      link.click();
      link.remove();
      showToast(`تم تنزيل بطاقة QR للطالب (${activeCardStudent.name}) بصيغة PNG ✓`, 'success');
    } catch {
      showToast('تعذر تصدير البطاقة حالياً', 'error');
    }
  };

  // ================= CENTER SESSIONS & QR CHECK-IN =================
  const activeSession = useMemo(() => {
    if (sessions.length > 0) {
      return sessions.find((s) => s.id === selectedSessionId) || sessions[0];
    }
    const today = new Date().toISOString().split('T')[0];
    return {
      id: `daily-${today}`,
      title: `حصة السنتر اليومية (${today})`,
      subject: 'المتابعة الحضورية',
      grade: 'جميع الصفوف',
      hallName: 'القاعة الرئيسية',
      sessionDate: today,
      createdBy: currentUser.name,
      createdAt: new Date().toISOString(),
    };
  }, [sessions, selectedSessionId, currentUser.name]);

  const handleCreateSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSessTitle.trim() || !isStaff) return;
    setIsCreatingSession(true);
    try {
      const res = await fetch('/api/attendance/sessions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          title: newSessTitle.trim(),
          subject: newSessSubject.trim() || 'عام',
          grade: newSessGrade,
          hallName: newSessHall.trim() || 'قاعة السنتر',
          sessionDate: newSessDate,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر إنشاء الحصة الحضورية');
      if (Array.isArray(data.sessions)) setSessions(data.sessions);
      if (data.session?.id) setSelectedSessionId(data.session.id);
      setNewSessTitle('');
      setNewSessSubject('');
      setShowNewSessionForm(false);
      showToast(`تم إنشاء حصة السنتر (${data.session.title}) بنجاح ✓`, 'success');
    } catch (err: any) {
      showToast(err.message || 'تعذر إنشاء الحصة', 'error');
    } finally {
      setIsCreatingSession(false);
    }
  };

  const playScanBeep = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = 880;
      gain.gain.value = 0.08;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.14);
    } catch {
      // ignore audio context failures
    }
  };

  const submitQrCheckIn = async (
    qrPayloadOrCode: string,
    status: 'present' | 'late' | 'absent' = 'present',
    method: 'qr_camera' | 'qr_manual' | 'quick_roster' = 'qr_manual'
  ) => {
    if (!isStaff || !qrPayloadOrCode.trim()) return;
    setIsCheckingIn(true);
    try {
      const res = await fetch('/api/attendance/qr-checkin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders(currentUser, teachers),
        },
        body: JSON.stringify({
          qrPayloadOrCode: qrPayloadOrCode.trim(),
          sessionId: activeSession.id,
          sessionTitle: activeSession.title,
          sessionDate: activeSession.sessionDate,
          status,
          method,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر تسجيل الحضور');

      if (Array.isArray(data.records)) setAttendanceRecords(data.records);
      if (data.updatedStudent) {
        setQrStudents((prev) =>
          prev.map((s) => (s.id === data.updatedStudent.id ? data.updatedStudent : s))
        );
        onStudentUpdated?.(data.updatedStudent);
      }
      playScanBeep();
      setManualQrInput('');
      showToast(data.message || 'تم تسجيل الحضور بالـ QR Code فوراً ✓', 'success');
      fetchWeeklyReports();
    } catch (err: any) {
      showToast(err.message || 'فشل قراءة الكود أو تسجيل الحضور', 'error');
    } finally {
      setIsCheckingIn(false);
    }
  };

  // Stop camera helper
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCameraScanner = async () => {
    setCameraError(null);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError(
        'المتصفح الحالي لا يدعم تشغيل الكاميرا مباشرة داخل الإطار. يمكنك استخدام قارئ الباركود USB أو الإدخال السريع بالأسفل.'
      );
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      streamRef.current = stream;
      setIsCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }, 60);

      const hasDetector = typeof (window as any).BarcodeDetector === 'function';
      setBarcodeDetectorSupported(hasDetector);
    } catch (err: any) {
      setCameraError(
        err?.name === 'NotAllowedError'
          ? 'تم رفض إذن الكاميرا. يرجى السماح بالوصول للكاميرا أو استخدام خانة كود الطالب وقارئ الباركود بالأسفل.'
          : 'تعذر فتح الكاميرا على هذا الجهاز حالياً. يمكنك استخدام قارئ الباركود أو تسجيل الحضور السريع من القائمة.'
      );
      setIsCameraActive(false);
    }
  };

  // Poll BarcodeDetector frames when camera is live
  useEffect(() => {
    if (!isCameraActive || !barcodeDetectorSupported) return;
    const DetectorClass = (window as any).BarcodeDetector;
    if (!DetectorClass) return;

    let detector: any;
    try {
      detector = new DetectorClass({ formats: ['qr_code'] });
    } catch {
      setBarcodeDetectorSupported(false);
      return;
    }

    const timer = window.setInterval(async () => {
      const video = videoRef.current;
      if (!video || video.readyState < 2) return;
      try {
        const barcodes = await detector.detect(video);
        if (Array.isArray(barcodes) && barcodes.length > 0) {
          const rawVal = String(barcodes[0].rawValue || '').trim();
          const now = Date.now();
          if (
            rawVal &&
            (rawVal !== lastScanCooldownRef.current.value ||
              now - lastScanCooldownRef.current.time > 4000)
          ) {
            lastScanCooldownRef.current = { value: rawVal, time: now };
            submitQrCheckIn(rawVal, 'present', 'qr_camera');
          }
        }
      } catch {
        // ignore transient frame read errors
      }
    }, 500);

    return () => window.clearInterval(timer);
  }, [isCameraActive, barcodeDetectorSupported, activeSession.id]);

  const sessionRecords = useMemo(
    () => attendanceRecords.filter((r) => r.sessionId === activeSession.id),
    [attendanceRecords, activeSession.id]
  );

  const visibleRosterStudents = useMemo(() => {
    const q = rosterSearch.trim().toLowerCase();
    return qrStudents
      .filter((s) => {
        if (!q) return true;
        return (
          s.name.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          s.grade.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        // Prioritize offline/center students first
        if (a.type === 'offline' && b.type !== 'offline') return -1;
        if (a.type !== 'offline' && b.type === 'offline') return 1;
        return a.name.localeCompare(b.name, 'ar');
      });
  }, [qrStudents, rosterSearch]);

  const ownAttendanceHistory = useMemo(() => {
    if (!activeCardStudent) return [];
    return attendanceRecords.filter(
      (r) =>
        r.studentId === activeCardStudent.id ||
        r.studentCode === activeCardStudent.code
    );
  }, [attendanceRecords, activeCardStudent]);

  return (
    <div className="space-y-6 font-tajawal animate-in fade-in duration-200">
      {/* Floating Toast */}
      {toast && (
        <div
          className={`fixed bottom-5 left-5 z-50 px-4 py-3 rounded-2xl shadow-2xl border text-xs font-cairo font-bold flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-3 ${
            toast.type === 'success'
              ? 'bg-emerald-900 text-white border-emerald-500'
              : toast.type === 'error'
              ? 'bg-rose-900 text-white border-rose-500'
              : 'bg-slate-900 text-white border-indigo-500'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
          <span>{toast.text}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="rounded-3xl bg-gradient-to-l from-emerald-950 via-emerald-900 to-teal-900 text-white p-6 md:p-7 shadow-xl border border-emerald-700/40 relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 relative z-10">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-emerald-200 text-[11px] font-cairo font-bold">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>
                {isAr
                  ? 'القسم 4 · متابعة أولياء الأمور والتقارير الذكية + الحضور بالـ QR'
                  : 'Parent Smart Weekly Reports & Center QR Attendance'}
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-black font-cairo text-white">
              {isAr
                ? 'التقرير الأسبوعي الذكي لولي الأمر ونظام الحضور بالـ QR Code'
                : 'Smart Parent Weekly Report & Center QR Attendance'}
            </h1>
            <p className="text-xs md:text-sm text-emerald-100/90 max-w-2xl leading-relaxed">
              {isAr
                ? 'ملخص أسبوعي فوري محسوب من قاعدة البيانات (ساعات المذاكرة، الدروس المنجزة، الاختبارات، الغياب) يُرسل إلى واتساب ولي الأمر بضغطة زر، مع بطاقة طالب رقمية وماسح QR لتسجيل حضور السنتر لحظياً.'
                : 'Live weekly report calculated from database records with one-click WhatsApp dispatch, plus Digital Student QR ID cards and live hall attendance scanner.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSubTab('reports')}
              className={`px-4 py-2.5 rounded-2xl font-cairo font-bold text-xs flex items-center gap-2 transition-all cursor-pointer border ${
                subTab === 'reports'
                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-lg'
                  : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
              }`}
            >
              <MessageCircle className="w-4 h-4" />
              <span>
                {isAr ? 'التقرير الأسبوعي الذكي (واتساب)' : 'Smart Weekly Report (WhatsApp)'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSubTab('qr_attendance')}
              className={`px-4 py-2.5 rounded-2xl font-cairo font-bold text-xs flex items-center gap-2 transition-all cursor-pointer border ${
                subTab === 'qr_attendance'
                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-lg'
                  : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>
                {isStudent
                  ? isAr
                    ? 'بطاقتي الرقمية (QR السنتر)'
                    : 'My Digital QR Card'
                  : isAr
                  ? 'الحضور بالـ QR للسنتر وبطاقة الطالب'
                  : 'Center QR Attendance & ID Cards'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* ================= SUB-TAB 1: SMART WEEKLY PARENT REPORT & WHATSAPP DISPATCH ================= */}
      {subTab === 'reports' && (
        <div className="space-y-5">
          {/* Staff Filter & Student Picker Bar */}
          {isStaff && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-xs">
              <div className="flex flex-1 flex-wrap items-center gap-2.5">
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={reportSearch}
                    onChange={(e) => setReportSearch(e.target.value)}
                    placeholder={
                      isAr
                        ? 'ابحث باسم الطالب أو كوده أو هاتف ولي الأمر...'
                        : 'Search student, code, or parent phone...'
                    }
                    className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-tajawal focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-[11px] font-cairo font-bold">
                  {[
                    { id: 'all', label: 'الكل' },
                    { id: 'offline', label: 'طلاب السنتر' },
                    { id: 'online', label: 'طلاب الأونلاين' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setReportTypeFilter(f.id as any)}
                      className={`px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors ${
                        reportTypeFilter === f.id
                          ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 shadow-xs'
                          : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={activeReport?.studentId || ''}
                  onChange={(e) => setSelectedReportStudentId(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-cairo font-bold text-slate-800 dark:text-slate-100 min-w-[220px]"
                >
                  {visibleReports.map((r) => (
                    <option key={r.studentId} value={r.studentId}>
                      {r.studentName} ({r.studentCode}) — {r.studentGrade}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={fetchWeeklyReports}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                  title="تحديث من قاعدة البيانات"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoadingReports ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>
          )}

          {isLoadingReports && !activeReport ? (
            <div className="p-10 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-sm font-cairo text-slate-500">
              جارِ تجميع إحصائيات التقرير الأسبوعي من قاعدة البيانات...
            </div>
          ) : !activeReport ? (
            <div className="p-10 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-2">
              <Users className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="font-cairo font-bold text-slate-700 dark:text-slate-200">
                لا توجد بيانات طلاب مطابقة لعرض التقرير الأسبوعي
              </p>
              <p className="text-xs text-slate-500">
                تأكد من تسجيل الطلاب في قاعدة البيانات أو تعديل كلمات البحث.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
              {/* Smart Report Card (7 cols) */}
              <div className="xl:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border-2 border-emerald-500/30 shadow-sm overflow-hidden">
                <div className="p-5 bg-gradient-to-l from-emerald-800 to-teal-700 text-white flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={getSafeAvatarUrl(activeReport.studentAvatar)}
                      alt={activeReport.studentName}
                      onError={handleImageErrorToTeacherAvatar}
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-white/40 shadow-md bg-white"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="font-cairo font-black text-lg text-white">
                          {activeReport.studentName}
                        </h2>
                        <span className="px-2 py-0.5 rounded-full bg-white/15 text-[11px] font-mono-numbers">
                          {activeReport.studentCode}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-cairo font-black">
                          {activeReport.studentType === 'offline' ? 'سنتر حضوري' : 'أونلاين'}
                        </span>
                      </div>
                      <p className="text-xs text-emerald-100 mt-0.5">
                        {activeReport.studentGrade} · ولي الأمر: {activeReport.parentName} (
                        <span className="font-mono-numbers" dir="ltr">
                          {activeReport.parentPhone || 'غير مسجل'}
                        </span>
                        )
                      </p>
                    </div>
                  </div>

                  <div className="text-left">
                    <span className="text-[11px] text-emerald-200 block">نطاق التقرير</span>
                    <strong className="font-cairo text-xs text-white">
                      {weekLabel || activeReport.weekLabel}
                    </strong>
                  </div>
                </div>

                <div className="p-5 space-y-5">
                  {/* 4 Core KPI Boxes requested by user */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/70">
                      <div className="flex items-center justify-between text-indigo-700 dark:text-indigo-300 mb-1">
                        <span className="text-[11px] font-cairo font-bold">ساعات المذاكرة</span>
                        <Timer className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-black font-mono-numbers text-indigo-950 dark:text-white">
                        {activeReport.studyHours}{' '}
                        <span className="text-xs font-cairo font-semibold">ساعة</span>
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/70">
                      <div className="flex items-center justify-between text-emerald-700 dark:text-emerald-300 mb-1">
                        <span className="text-[11px] font-cairo font-bold">الدروس المنجزة</span>
                        <BookOpenCheck className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-black font-mono-numbers text-emerald-950 dark:text-white">
                        {activeReport.completedLessonsCount}{' '}
                        <span className="text-xs font-cairo font-semibold">درس</span>
                      </p>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/70">
                      <div className="flex items-center justify-between text-amber-700 dark:text-amber-300 mb-1">
                        <span className="text-[11px] font-cairo font-bold">متوسط الاختبارات</span>
                        <Award className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-black font-mono-numbers text-amber-950 dark:text-white">
                        {activeReport.averageExamScore}%
                      </p>
                      <span className="text-[10px] text-amber-700 dark:text-amber-300">
                        من {activeReport.examsCount} اختبار
                      </span>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/70">
                      <div className="flex items-center justify-between text-rose-700 dark:text-rose-300 mb-1">
                        <span className="text-[11px] font-cairo font-bold">أيام الغياب</span>
                        <CalendarX2 className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-black font-mono-numbers text-rose-950 dark:text-white">
                        {activeReport.absenceDays}{' '}
                        <span className="text-xs font-cairo font-semibold">يوم</span>
                      </p>
                      <span className="text-[10px] text-slate-600 dark:text-slate-300">
                        حضور {activeReport.attendanceDays} يوم ({activeReport.attendanceRate}%)
                      </span>
                    </div>
                  </div>

                  {activeReport.weakestSubject && (
                    <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2 font-cairo font-bold text-amber-950 dark:text-amber-200">
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>
                          أكثر مادة يحتاج فيها الطالب إلى دعم إضافي:{' '}
                          <strong className="text-rose-700 dark:text-rose-300">
                            {activeReport.weakestSubject}
                          </strong>
                        </span>
                      </div>
                      {activeReport.weakestSubjectScore !== null &&
                        activeReport.weakestSubjectScore !== undefined && (
                          <span className="px-2.5 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 font-mono-numbers font-black">
                            متوسط {activeReport.weakestSubjectScore}%
                          </span>
                        )}
                    </div>
                  )}

                  {/* Completed Lessons */}
                  <div className="space-y-2">
                    <h3 className="text-xs font-cairo font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>الدروس التي أنهاها الطالب ({activeReport.completedLessonsCount})</span>
                    </h3>
                    {activeReport.completedLessonTitles.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {activeReport.completedLessonTitles.map((title, idx) => (
                          <span
                            key={idx}
                            className="px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-[11px] font-cairo font-semibold text-emerald-800 dark:text-emerald-200"
                          >
                            ✓ {title}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                        لم يكمل الطالب دروساً مسجلة في نظام التتابع بعد (يُحتسب تلقائياً فور مشاهدة الدرس أو اجتياز اختباره).
                      </p>
                    )}
                  </div>

                  {/* Exam Results */}
                  <div className="space-y-2">
                    <h3 className="text-xs font-cairo font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-amber-500" />
                      <span>درجاته في الاختبارات المسجلة</span>
                    </h3>
                    {activeReport.examDetails.length > 0 ? (
                      <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
                        <table className="w-full text-right text-xs">
                          <thead className="bg-slate-50 dark:bg-slate-800/70 text-slate-500 font-cairo">
                            <tr>
                              <th className="py-2.5 px-3">الاختبار</th>
                              <th className="py-2.5 px-3">المادة</th>
                              <th className="py-2.5 px-3">الدرجة</th>
                              <th className="py-2.5 px-3">النسبة</th>
                              <th className="py-2.5 px-3">التاريخ</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                            {activeReport.examDetails.map((ex, idx) => (
                              <tr key={idx}>
                                <td className="py-2.5 px-3 font-bold text-slate-800 dark:text-slate-100">
                                  {ex.title}
                                </td>
                                <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                                  {ex.subject}
                                </td>
                                <td className="py-2.5 px-3 font-mono-numbers">{ex.scoreText}</td>
                                <td className="py-2.5 px-3">
                                  <span
                                    className={`px-2 py-0.5 rounded-lg font-mono-numbers font-bold text-[11px] ${
                                      ex.percentage >= 85
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : ex.percentage >= 60
                                        ? 'bg-amber-100 text-amber-800'
                                        : 'bg-rose-100 text-rose-800'
                                    }`}
                                  >
                                    {ex.percentage}%
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 font-mono-numbers text-slate-400">
                                  {ex.date || '—'}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                        لا توجد محاولات اختبارات حديثة مسجلة — المتوسط التراكمي الحالي في ملف الطالب:{' '}
                        <strong className="font-mono-numbers">{activeReport.averageExamScore}%</strong>
                      </p>
                    )}
                  </div>

                  {/* Staff Calibration & Teacher Note */}
                  {isStaff && (
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                      <h4 className="text-xs font-cairo font-bold text-slate-800 dark:text-slate-200">
                        تخصيص ملاحظة المعلم ومعايرة التقرير قبل الإرسال
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[11px] font-bold text-slate-500 block mb-1">
                            تعديل ساعات المذاكرة (اختياري)
                          </label>
                          <input
                            type="number"
                            step="0.5"
                            min="0"
                            value={manualHoursInput}
                            onChange={(e) => setManualHoursInput(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] font-bold text-slate-500 block mb-1">
                            تعديل أيام الغياب (اختياري)
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={manualAbsenceInput}
                            onChange={(e) => setManualAbsenceInput(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          ملاحظة موجهة لولي الأمر داخل رسالة واتساب
                        </label>
                        <textarea
                          rows={2}
                          value={customNoteInput}
                          onChange={(e) => setCustomNoteInput(e.target.value)}
                          placeholder="مثال: نرجو متابعة حل الواجب الأسبوعي القادم، مستوى الطالب في تحسن مستمر..."
                          className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-tajawal"
                        />
                      </div>

                      <div className="flex justify-end">
                        <button
                          type="button"
                          disabled={isSavingReportLog}
                          onClick={() => handleSaveReportMetadata(false)}
                          className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>{isSavingReportLog ? 'جارِ الحفظ...' : 'حفظ التعديلات في قاعدة البيانات'}</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* WhatsApp Preview & One-Click Dispatch Card (5 cols) */}
              <div className="xl:col-span-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-sm">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-sm">
                      <MessageCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-cairo font-black text-sm text-slate-900 dark:text-white">
                        إرسال فوري عبر واتساب بضغطة زر
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        رسالة منسقة جاهزة للإرسال المباشر لرقم ولي الأمر
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">
                    رقم واتساب ولي الأمر المستهدف
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={overridePhoneInput}
                    onChange={(e) => setOverridePhoneInput(e.target.value)}
                    placeholder="مثال: 01012345678 أو 0501234567"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono-numbers"
                  />
                  {!effectiveWhatsappPhone && (
                    <p className="text-[11px] text-amber-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>لم يُضف رقم هاتف بعد — سيفتح واتساب لاختيار جهة الاتصال مباشرة.</span>
                    </p>
                  )}
                </div>

                {/* WhatsApp Chat Bubble Preview */}
                <div className="p-4 rounded-2xl bg-[#e7ffdb] dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-slate-900 dark:text-emerald-50 text-xs leading-relaxed whitespace-pre-wrap max-h-[340px] overflow-y-auto shadow-inner">
                  {formattedWhatsappText}
                </div>

                {activeReport.lastSentViaWhatsappAt && (
                  <div className="px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-[11px] text-emerald-800 dark:text-emerald-200 flex items-center justify-between">
                    <span>✓ آخر إرسال مسجل لولي الأمر:</span>
                    <strong className="font-mono-numbers">
                      {activeReport.lastSentViaWhatsappAt}
                    </strong>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
                  <a
                    href={whatsappHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      if (isStaff) handleSaveReportMetadata(true);
                    }}
                    className="flex-1 py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#1fb958] text-slate-950 font-cairo font-black text-xs flex items-center justify-center gap-2 shadow-md transition-transform active:scale-[0.99]"
                  >
                    <Send className="w-4 h-4" />
                    <span>إرسال التقرير عبر واتساب بضغطة زر</span>
                  </a>

                  <a
                    href={`mailto:${encodeURIComponent(activeReport.parentEmail || '')}?subject=${encodeURIComponent(
                      `التقرير الأسبوعي للطالب ${activeReport.studentName} - ${settings.schoolName || 'منصة الشريف'}`
                    )}&body=${encodeURIComponent(formattedWhatsappText.replace(/\*/g, ''))}`}
                    className="px-4 py-3 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                    title={
                      activeReport.parentEmail
                        ? `إرسال بالبريد الإلكتروني إلى ${activeReport.parentEmail}`
                        : 'إرسال عبر البريد الإلكتروني لولي الأمر'
                    }
                  >
                    <Mail className="w-4 h-4" />
                    <span>إرسال بالبريد</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleCopyReportText}
                    className="px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedReport ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>نسخ النص</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= SUB-TAB 2: CENTER QR CODE ATTENDANCE SYSTEM ================= */}
      {subTab === 'qr_attendance' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* Digital Student QR ID Card (Left / 4 cols, full width if Student/Parent) */}
          <div className={isStaff ? 'xl:col-span-4 space-y-4' : 'xl:col-span-12 max-w-xl mx-auto w-full space-y-4'}>
            <div className="bg-white dark:bg-slate-900 rounded-3xl border-2 border-slate-200 dark:border-slate-800 overflow-hidden shadow-md">
              <div className="p-4 bg-gradient-to-l from-slate-900 via-emerald-950 to-teal-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <QrCode className="w-5 h-5 text-amber-300" />
                  <span className="font-cairo font-bold text-xs">
                    بطاقة الطالب الرقمية (حضور السنتر QR)
                  </span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/15 font-cairo">
                  {settings.schoolName}
                </span>
              </div>

              {isStaff && qrStudents.length > 0 && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">
                    اختر طالباً لعرض أو طباعة بطاقة QR الخاصة به:
                  </label>
                  <select
                    value={activeCardStudent?.id || ''}
                    onChange={(e) => setSelectedCardStudentId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-cairo font-bold"
                  >
                    {qrStudents.map((stu) => (
                      <option key={stu.id} value={stu.id}>
                        {stu.name} ({stu.code}) — {stu.type === 'offline' ? 'سنتر' : 'أونلاين'}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {activeCardStudent ? (
                <div className="p-5 text-center space-y-4">
                  <div className="flex items-center gap-3 text-right p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                    <img
                      src={getSafeAvatarUrl(activeCardStudent.avatar)}
                      alt={activeCardStudent.name}
                      onError={handleImageErrorToTeacherAvatar}
                      className="w-12 h-12 rounded-2xl object-cover border border-emerald-300 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-cairo font-black text-sm text-slate-900 dark:text-white truncate">
                        {activeCardStudent.name}
                      </h3>
                      <p className="text-[11px] text-slate-500 truncate">
                        {activeCardStudent.grade}
                      </p>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="text-[10px] font-mono-numbers font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                          {activeCardStudent.code}
                        </span>
                        <span className="text-[10px] font-cairo font-bold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 inline-flex items-center gap-1">
                          {activeCardStudent.type === 'offline' ? (
                            <>
                              <Building2 className="w-3 h-3" /> سنتر حضوري
                            </>
                          ) : (
                            <>
                              <Wifi className="w-3 h-3" /> أونلاين
                            </>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* QR Code Image */}
                  <div className="inline-flex flex-col items-center p-4 rounded-3xl bg-white border-2 border-dashed border-emerald-400 shadow-xs">
                    {qrCardDataUrl ? (
                      <img
                        src={qrCardDataUrl}
                        alt={`QR-${activeCardStudent.code}`}
                        className="w-48 h-48 object-contain"
                      />
                    ) : (
                      <div className="w-48 h-48 flex items-center justify-center text-xs text-slate-400">
                        جارِ توليد رمز QR...
                      </div>
                    )}
                    <span className="text-[10px] font-mono text-slate-500 mt-1" dir="ltr">
                      ALSHARIF-ATTEND:{activeCardStudent.id}:{activeCardStudent.code}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed">
                    يُظهر الطالب هذه البطاقة للمعلم أو المشرف عند بوابة القاعة لمسحها بالكاميرا وتسجيل الحضور لحظياً.
                  </p>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleDownloadStudentQrCard}
                      className="flex-1 py-2.5 px-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      <Download className="w-4 h-4" />
                      <span>تحميل البطاقة (PNG)</span>
                    </button>
                  </div>

                  {/* Student's Recent QR Attendance Log */}
                  <div className="text-right pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs font-cairo font-bold">
                      <span className="text-slate-700 dark:text-slate-200">
                        نسبة الحضور الحالية:
                      </span>
                      <span className="font-mono-numbers text-emerald-600">
                        {activeCardStudent.attendanceRate}%
                      </span>
                    </div>
                    {ownAttendanceHistory.length > 0 && (
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {ownAttendanceHistory.slice(0, 5).map((rec) => (
                          <div
                            key={rec.id}
                            className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-[11px]"
                          >
                            <span className="font-bold text-slate-700 dark:text-slate-200 truncate">
                              {rec.sessionTitle}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full font-cairo font-bold shrink-0 ${
                                rec.status === 'present'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : rec.status === 'late'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {rec.status === 'present'
                                ? 'حاضر ✓'
                                : rec.status === 'late'
                                ? 'متأخر ⏱'
                                : 'غائب ✗'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center text-xs text-slate-500">
                  لا توجد بيانات طالب مرتبطة لعرض البطاقة الرقمية.
                </div>
              )}
            </div>
          </div>

          {/* Teacher / Supervisor QR Scanner & Hall Session Controls (Right / 8 cols) */}
          {isStaff && (
            <div className="xl:col-span-8 space-y-5">
              {/* Session Picker & Creation */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-cairo font-black text-sm text-slate-900 dark:text-white">
                      1) اختيار أو فتح حصة / مجموعة حضورية (السنتر)
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      تُسجَّل عمليات مسح الـ QR داخل الحصة المحددة وتُحدّث نسبة حضور الطالب فوراً في قاعدة البيانات.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowNewSessionForm((v) => !v)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{showNewSessionForm ? 'إخفاء النموذج' : 'حصة سنتر جديدة'}</span>
                  </button>
                </div>

                {showNewSessionForm && (
                  <form
                    onSubmit={handleCreateSession}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"
                  >
                    <input
                      type="text"
                      required
                      value={newSessTitle}
                      onChange={(e) => setNewSessTitle(e.target.value)}
                      placeholder="اسم المجموعة / الحصة (مثال: مجموعة السبت 3م)"
                      className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                    />
                    <input
                      type="text"
                      value={newSessSubject}
                      onChange={(e) => setNewSessSubject(e.target.value)}
                      placeholder="المادة (مثال: الفيزياء)"
                      className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                    />
                    <input
                      type="text"
                      value={newSessHall}
                      onChange={(e) => setNewSessHall(e.target.value)}
                      placeholder="اسم القاعة (مثال: قاعة A1)"
                      className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                    />
                    <input
                      type="text"
                      value={newSessGrade}
                      onChange={(e) => setNewSessGrade(e.target.value)}
                      placeholder="الصف الدراسي"
                      className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                    />
                    <input
                      type="date"
                      value={newSessDate}
                      onChange={(e) => setNewSessDate(e.target.value)}
                      className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono-numbers"
                    />
                    <button
                      type="submit"
                      disabled={isCreatingSession}
                      className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-emerald-600 text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-50"
                    >
                      {isCreatingSession ? 'جارِ الحفظ...' : 'حفظ وبدء التسجيل'}
                    </button>
                  </form>
                )}

                <div className="flex flex-wrap items-center gap-3">
                  <select
                    value={activeSession.id}
                    onChange={(e) => setSelectedSessionId(e.target.value)}
                    className="flex-1 min-w-[240px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-cairo font-bold"
                  >
                    {sessions.length === 0 && (
                      <option value={activeSession.id}>{activeSession.title}</option>
                    )}
                    {sessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.title} · {s.hallName} ({s.sessionDate})
                      </option>
                    ))}
                  </select>

                  <div className="px-3.5 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs font-cairo font-bold text-emerald-800 dark:text-emerald-200">
                    تم تحضير{' '}
                    <span className="font-mono-numbers">
                      {sessionRecords.filter((r) => r.status !== 'absent').length}
                    </span>{' '}
                    طالب في هذه الحصة
                  </div>
                </div>
              </div>

              {/* Live Camera Scanner + Manual / USB Scanner Input */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center">
                      <ScanLine className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-cairo font-black text-sm text-slate-900 dark:text-white">
                        2) ماسح الكاميرا المباشر للـ QR وقارئ الباركود السريع
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        وجّه الكاميرا لبطاقة الطالب أو امسح بقارئ الباركود / أدخل كود الطالب لتسجيله فوراً.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={isCameraActive ? stopCamera : startCameraScanner}
                    className={`px-4 py-2.5 rounded-xl font-cairo font-bold text-xs flex items-center gap-2 cursor-pointer ${
                      isCameraActive
                        ? 'bg-rose-600 hover:bg-rose-700 text-white'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    }`}
                  >
                    {isCameraActive ? (
                      <>
                        <CameraOff className="w-4 h-4" />
                        <span>إيقاف الكاميرا</span>
                      </>
                    ) : (
                      <>
                        <Camera className="w-4 h-4" />
                        <span>تشغيل كاميرا مسح QR</span>
                      </>
                    )}
                  </button>
                </div>

                {cameraError && (
                  <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 text-amber-800 dark:text-amber-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{cameraError}</span>
                  </div>
                )}

                {isCameraActive && (
                  <div className="relative rounded-2xl overflow-hidden bg-slate-950 border-2 border-indigo-500 max-w-md mx-auto">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                      <div className="w-44 h-44 border-2 border-emerald-400 rounded-2xl shadow-[0_0_0_9999px_rgba(0,0,0,0.35)]" />
                    </div>
                    <div className="p-2.5 bg-slate-900/95 text-center text-[11px] text-emerald-300 font-cairo font-bold">
                      {barcodeDetectorSupported
                        ? 'الكاميرا نشطة — وجّه بطاقة الـ QR داخل المربع الأخضر للمسح التلقائي...'
                        : 'الكاميرا مفتوحة — المتصفح لا يدعم BarcodeDetector التلقائي، استخدم خانة الكود بالأسفل أو جهاز الماسح.'}
                    </div>
                  </div>
                )}

                {/* Manual / USB Barcode Gun Input */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    submitQrCheckIn(manualQrInput, 'present', 'qr_manual');
                  }}
                  className="flex flex-col sm:flex-row gap-2.5"
                >
                  <input
                    type="text"
                    value={manualQrInput}
                    onChange={(e) => setManualQrInput(e.target.value)}
                    placeholder="امسح بقارئ USB أو اكتب كود الطالب (مثال: STU-1001 أو ALSHARIF-ATTEND:...)"
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono-numbers"
                  />
                  <button
                    type="submit"
                    disabled={isCheckingIn || !manualQrInput.trim()}
                    className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{isCheckingIn ? 'جارِ التسجيل...' : 'تسجيل الحضور بالـ QR'}</span>
                  </button>
                </form>
              </div>

              {/* Quick Center Roster + Live Attendance Log */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h3 className="font-cairo font-black text-sm text-slate-900 dark:text-white">
                    3) كشف تحضير طلاب المجموعة الحضورية وسجل المسح المباشر
                  </h3>
                  <div className="relative min-w-[220px]">
                    <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={rosterSearch}
                      onChange={(e) => setRosterSearch(e.target.value)}
                      placeholder="بحث سريع عن طالب..."
                      className="w-full pr-9 pl-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                    />
                  </div>
                </div>

                {isLoadingQr ? (
                  <p className="text-xs text-slate-500 text-center py-6">جارِ تحميل سجل الطلاب والحضور...</p>
                ) : (
                  <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 max-h-80">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-cairo sticky top-0">
                        <tr>
                          <th className="py-2.5 px-3">الطالب</th>
                          <th className="py-2.5 px-3">النوع</th>
                          <th className="py-2.5 px-3">حالة الحصة</th>
                          <th className="py-2.5 px-3 text-center">تسجيل سريع</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {visibleRosterStudents.map((stu) => {
                          const existingRec = sessionRecords.find((r) => r.studentId === stu.id);
                          return (
                            <tr key={stu.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                              <td className="py-2.5 px-3">
                                <div className="font-cairo font-bold text-slate-900 dark:text-white">
                                  {stu.name}
                                </div>
                                <div className="text-[11px] font-mono-numbers text-slate-400">
                                  {stu.code} · {stu.grade}
                                </div>
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[10px] font-cairo font-bold">
                                  {stu.type === 'offline' ? 'سنتر' : 'أونلاين'}
                                </span>
                              </td>
                              <td className="py-2.5 px-3">
                                {existingRec ? (
                                  <span
                                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-cairo font-bold ${
                                      existingRec.status === 'present'
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : existingRec.status === 'late'
                                        ? 'bg-amber-100 text-amber-800'
                                        : 'bg-rose-100 text-rose-800'
                                    }`}
                                  >
                                    {existingRec.status === 'present'
                                      ? 'حاضر ✓'
                                      : existingRec.status === 'late'
                                      ? 'متأخر ⏱'
                                      : 'غائب ✗'}
                                  </span>
                                ) : (
                                  <span className="text-slate-400 text-[11px]">لم يُسجّل</span>
                                )}
                              </td>
                              <td className="py-2.5 px-3">
                                <div className="flex items-center justify-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => submitQrCheckIn(stu.id, 'present', 'quick_roster')}
                                    className="px-2 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-cairo font-bold text-[11px] cursor-pointer"
                                  >
                                    حاضر
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => submitQrCheckIn(stu.id, 'late', 'quick_roster')}
                                    className="px-2 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-800 font-cairo font-bold text-[11px] cursor-pointer"
                                  >
                                    متأخر
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => submitQrCheckIn(stu.id, 'absent', 'quick_roster')}
                                    className="px-2 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 font-cairo font-bold text-[11px] cursor-pointer"
                                  >
                                    غائب
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Recent Scanned Check-ins */}
                {sessionRecords.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <h4 className="text-xs font-cairo font-bold text-slate-700 dark:text-slate-200">
                      سجل المسح الفوري لهذه الحصة ({sessionRecords.length})
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {sessionRecords.slice(0, 12).map((rec) => (
                        <div
                          key={rec.id}
                          className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="min-w-0">
                            <p className="font-cairo font-bold text-slate-800 dark:text-slate-100 truncate">
                              {rec.studentName}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono-numbers">
                              {rec.checkedInAt} ·{' '}
                              {rec.method === 'qr_camera'
                                ? 'كاميرا QR'
                                : rec.method === 'qr_manual'
                                ? 'قارئ/كود'
                                : 'تحضير سريع'}
                            </p>
                          </div>
                          {rec.status === 'present' ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          ) : rec.status === 'late' ? (
                            <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
