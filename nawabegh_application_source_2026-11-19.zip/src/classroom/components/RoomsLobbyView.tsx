import React, { useState } from 'react';
import {
  Video,
  Plus,
  Link2,
  Copy,
  Check,
  Lock,
  Unlock,
  Users,
  Radio,
  LogIn,
  Shield,
  Trash2,
} from 'lucide-react';
import type { ClassroomRole, LiveRoomInfo } from '../../types/classroom';

interface RoomsLobbyViewProps {
  rooms: LiveRoomInfo[];
  loading: boolean;
  userRole: ClassroomRole;
  mediaMode: 'livekit' | 'webrtc-p2p';
  redisConnected: boolean;
  onCreateRoom: (payload: {
    title: string;
    subject: string;
    grade: string;
    waitingRoomEnabled: boolean;
    maxParticipants: number;
  }) => Promise<void>;
  onSelectRoomToJoin: (room: LiveRoomInfo) => void;
  onJoinByCode: (roomCode: string) => void;
  onGenerateInviteLink: (roomId: string, role: ClassroomRole, ttlMinutes: number) => Promise<string | null>;
  onToggleLockRoom: (room: LiveRoomInfo) => Promise<void>;
  onDeleteRoom: (roomId: string) => Promise<void>;
}

export const RoomsLobbyView: React.FC<RoomsLobbyViewProps> = ({
  rooms,
  loading,
  userRole,
  mediaMode,
  redisConnected,
  onCreateRoom,
  onSelectRoomToJoin,
  onJoinByCode,
  onGenerateInviteLink,
  onToggleLockRoom,
  onDeleteRoom,
}) => {
  const canHost = userRole === 'teacher' || userRole === 'assistant' || userRole === 'admin';

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('الرياضيات');
  const [grade, setGrade] = useState('الصف الثالث الثانوي');
  const [maxParticipants, setMaxParticipants] = useState(200);
  const [waitingRoomEnabled, setWaitingRoomEnabled] = useState(false);
  const [creating, setCreating] = useState(false);

  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [inviteModalRoom, setInviteModalRoom] = useState<LiveRoomInfo | null>(null);
  const [inviteRole, setInviteRole] = useState<ClassroomRole>('student');
  const [inviteTtl, setInviteTtl] = useState(240);
  const [generatedUrl, setGeneratedUrl] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setCreating(true);
    try {
      await onCreateRoom({
        title: title.trim(),
        subject,
        grade,
        waitingRoomEnabled,
        maxParticipants,
      });
      setTitle('');
    } finally {
      setCreating(false);
    }
  };

  const handleGenerateInvite = async () => {
    if (!inviteModalRoom) return;
    const url = await onGenerateInviteLink(inviteModalRoom.id, inviteRole, inviteTtl);
    if (url) {
      setGeneratedUrl(url);
      setCopiedUrl(false);
    }
  };

  const handleCopyInvite = async () => {
    if (!generatedUrl) return;
    await navigator.clipboard.writeText(generatedUrl);
    setCopiedUrl(true);
    window.setTimeout(() => setCopiedUrl(false), 2500);
  };

  return (
    <div className="space-y-6 font-tajawal" dir="rtl">
      {/* Header Banner */}
      <div className="rounded-2xl bg-slate-900 text-white p-6 border border-slate-800 shadow-lg flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-cairo font-extrabold text-xl">
                الفصول الافتراضية المباشرة — منصة الشريف
              </h2>
              <p className="text-xs text-slate-300">
                بث فيديو وصوت بزمن تأخير منخفض، مشاركة شاشة، وصلاحيات غرف موقّعة بـ JWT
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          <span className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 font-cairo font-bold">
            محرك البث: {mediaMode === 'livekit' ? 'LiveKit SFU (Simulcast)' : 'WebRTC P2P Mesh'}
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 font-cairo font-bold">
            الحالة الموزّعة: {redisConnected ? 'Redis Pub/Sub متصل' : 'Single-Node Ready'}
          </span>
        </div>
      </div>

      {/* Quick Join by Code + Host Creation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {canHost && (
          <form
            onSubmit={handleCreateSubmit}
            className="lg:col-span-7 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs"
          >
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <Plus className="w-5 h-5 text-emerald-600" />
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                إنشاء غرفة فصل مباشر جديدة
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  عنوان الحصة المباشرة
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: المراجعة النهائية — التفاضل والتكامل"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  المادة الدراسية
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  الصف الدراسي
                </label>
                <input
                  type="text"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 mb-1">
                  السعة القصوى (قبل التحويل لـ HLS)
                </label>
                <input
                  type="number"
                  min={10}
                  max={2000}
                  value={maxParticipants}
                  onChange={(e) => setMaxParticipants(Number(e.target.value || 200))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div className="flex items-end">
                <label className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={waitingRoomEnabled}
                    onChange={(e) => setWaitingRoomEnabled(e.target.checked)}
                    className="w-4 h-4 accent-emerald-600"
                  />
                  <span className="text-xs font-cairo font-bold text-slate-700 dark:text-slate-200">
                    تفعيل غرفة الانتظار للمنضمين
                  </span>
                </label>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={creating}
                className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white text-xs font-cairo font-bold flex items-center gap-2 shadow-sm cursor-pointer"
              >
                <Video className="w-4 h-4" />
                <span>{creating ? 'جارِ تجهيز الغرفة...' : 'إنشاء وبدء الغرفة المباشرة'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Join via Room Code Card */}
        <div
          className={`${
            canHost ? 'lg:col-span-5' : 'lg:col-span-12'
          } rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between space-y-4 shadow-xs`}
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <LogIn className="w-5 h-5 text-sky-600" />
              <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
                دخول سريع برمز الغرفة
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              أدخل رمز الفصل المباشر المرسل من المعلم (مثال: <span className="font-mono">SHF-482910</span>) للانتقال مباشرة لفحص الصوت والكاميرا.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={joinCodeInput}
              onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
              placeholder="SHF-XXXXXX"
              className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-mono text-slate-900 dark:text-white"
            />
            <button
              type="button"
              onClick={() => joinCodeInput.trim() && onJoinByCode(joinCodeInput.trim())}
              className="px-4 py-2.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-cairo font-bold cursor-pointer shrink-0"
            >
              دخول الآن
            </button>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex items-center gap-2.5 text-xs text-slate-600 dark:text-slate-300">
            <Shield className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>الدخول محمي بروابط موقّعة محدودة الصلاحية وتحقق خادمي للأدوار (RBAC).</span>
          </div>
        </div>
      </div>

      {/* Rooms Directory List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
            الغرف النشطة والمجدولة ({rooms.length})
          </h3>
        </div>

        {loading ? (
          <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-sm text-slate-500">
            جارِ تحميل الفصول الافتراضية من قاعدة البيانات...
          </div>
        ) : rooms.length === 0 ? (
          <div className="p-10 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-2">
            <Video className="w-9 h-9 mx-auto text-slate-400" />
            <p className="font-cairo font-bold text-sm text-slate-700 dark:text-slate-200">
              لا توجد فصول مباشرة منشأة حالياً
            </p>
            <p className="text-xs text-slate-500">
              {canHost
                ? 'استخدم النموذج أعلاه لإنشاء أول فصل مباشر ومشاركة رابط الدخول مع طلابك.'
                : 'بمجرد بدء المعلم للحصة ستظهر الغرفة هنا فوراً.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {rooms.map((room) => (
              <div
                key={room.id}
                className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between gap-4 shadow-xs hover:border-emerald-500/50 transition-colors"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                      {room.roomCode}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {room.isLocked && (
                        <span className="px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-[10px] font-cairo font-bold">
                          مقفلة
                        </span>
                      )}
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${
                          room.status === 'live'
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                            : room.status === 'ended'
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700'
                            : 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800'
                        }`}
                      >
                        {room.status === 'live'
                          ? 'مباشر الآن'
                          : room.status === 'ended'
                          ? 'انتهت'
                          : 'مجدولة'}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-cairo font-bold text-sm text-slate-900 dark:text-white line-clamp-1">
                      {room.title}
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {room.subject} • {room.grade}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 pt-1">
                    <span>المعلم: {room.hostName}</span>
                    <span className="inline-flex items-center gap-1 font-mono font-bold text-emerald-700 dark:text-emerald-400">
                      <Users className="w-3.5 h-3.5" />
                      {room.activeParticipantsCount || 0} / {room.maxParticipants}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                  <button
                    type="button"
                    disabled={room.status === 'ended'}
                    onClick={() => onSelectRoomToJoin(room)}
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-xs font-cairo font-bold cursor-pointer"
                  >
                    دخول الفصل
                  </button>

                  {canHost && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          setInviteModalRoom(room);
                          setGeneratedUrl(null);
                          setCopiedUrl(false);
                        }}
                        title="إنشاء رابط دعوة موقّع"
                        aria-label="إنشاء رابط دعوة موقّع"
                        className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Link2 className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onToggleLockRoom(room)}
                        title={room.isLocked ? 'فتح الغرفة' : 'قفل الغرفة'}
                        aria-label={room.isLocked ? 'فتح الغرفة' : 'قفل الغرفة'}
                        className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        {room.isLocked ? (
                          <Unlock className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <Lock className="w-4 h-4 text-amber-600" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteRoom(room.id)}
                        title="حذف الغرفة"
                        aria-label="حذف الغرفة"
                        className="p-2 rounded-xl border border-rose-200 dark:border-rose-900/50 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Signed Invite Link Modal */}
      {inviteModalRoom && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-2xl">
            <h3 className="font-cairo font-bold text-base text-slate-900 dark:text-white">
              رابط دعوة موقّع (JWT) — {inviteModalRoom.title}
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                  دور المدعو
                </label>
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as ClassroomRole)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                >
                  <option value="student">طالب</option>
                  <option value="assistant">مساعد معلم</option>
                  <option value="teacher">معلم</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-cairo font-bold text-slate-600 dark:text-slate-300 mb-1">
                  صلاحية الرابط (دقائق)
                </label>
                <input
                  type="number"
                  min={5}
                  max={1440}
                  value={inviteTtl}
                  onChange={(e) => setInviteTtl(Number(e.target.value || 240))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {generatedUrl && (
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2">
                <p className="text-[11px] font-mono break-all text-slate-700 dark:text-slate-200" dir="ltr">
                  {generatedUrl}
                </p>
                <button
                  type="button"
                  onClick={handleCopyInvite}
                  className="w-full py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-cairo font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {copiedUrl ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedUrl ? 'تم نسخ الرابط الموقّع!' : 'نسخ رابط الدعوة'}</span>
                </button>
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setInviteModalRoom(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-cairo font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                إغلاق
              </button>
              <button
                type="button"
                onClick={handleGenerateInvite}
                className="px-4 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-cairo font-bold cursor-pointer"
              >
                توليد رابط موقّع
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
