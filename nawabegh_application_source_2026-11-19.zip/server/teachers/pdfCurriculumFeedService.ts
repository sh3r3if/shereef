import { GoogleGenAI, Type } from '@google/genai';
import type {
  CurriculumChapter,
  CurriculumLesson,
  CurriculumMcqQuestion,
  CurriculumTrueFalseQuestion,
} from '../../src/types/curriculum.ts';

export interface TeacherPdfMetadata {
  id: string;
  teacherId: string;
  fileName: string;
  fileSizeBytes: number;
  subject: string;
  grade: string;
  uploadedAt: string;
  uploadedBy: string;
  status: 'uploaded_pending' | 'fed';
  fedAt?: string;
  fedLessonsCount?: number;
  fedQuizId?: string;
  fedQuestionsCount?: number;
  fedChapterId?: string;
}

export interface ExtractedPdfLesson {
  title: string;
  titleEn: string;
  summary: string;
  keyPoints: string[];
  durationMinutes: number;
  pageRange: string;
}

export interface ExtractedPdfQuestion {
  questionType: 'mcq' | 'true_false';
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  sourceLessonIndex: number;
  sourcePdfPage: number;
}

export interface ExtractedPdfCurriculumPayload {
  unitTitle: string;
  lessons: ExtractedPdfLesson[];
  questions: ExtractedPdfQuestion[];
}

export class PdfFeedApiError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 500, code = 'PDF_FEED_ERROR') {
    super(message);
    this.name = 'PdfFeedApiError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

export function stripDataUrlBase64(input: string): string {
  const trimmed = String(input || '').trim();
  const commaIdx = trimmed.indexOf(',');
  if (trimmed.startsWith('data:') && commaIdx !== -1) {
    return trimmed.slice(commaIdx + 1).replace(/\s+/g, '');
  }
  return trimmed.replace(/\s+/g, '');
}

export function validatePdfPayloadOrThrow(base64Data: string, fileName: string): string {
  const clean = stripDataUrlBase64(base64Data);
  if (!clean || clean.length < 32) {
    throw new PdfFeedApiError(
      `ملف PDF (${fileName}) فارغ أو غير مكتمل البيانات.`,
      400,
      'INVALID_PDF_DATA'
    );
  }
  const buffer = Buffer.from(clean, 'base64');
  // PDF header usually starts with %PDF- (allow BOM/leading whitespace within first 1024 bytes)
  const headText = buffer.subarray(0, Math.min(1024, buffer.length)).toString('latin1');
  if (!headText.includes('%PDF')) {
    throw new PdfFeedApiError(
      `الملف المرفوع (${fileName}) ليس ملف PDF صالحاً.`,
      400,
      'NOT_A_VALID_PDF'
    );
  }
  return clean;
}

export function buildFormattedLessonHtml(params: {
  title: string;
  unit: string;
  summary: string;
  keyPoints: string[];
  pageRange: string;
  fileName: string;
}): string {
  const esc = (s: string) =>
    String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  const pointsHtml = params.keyPoints
    .map((pt) => `<li>${esc(pt)}</li>`)
    .join('\n');

  return `<div dir="rtl" class="auto-pdf-lesson">
  <h3>${esc(params.title)}</h3>
  <p><strong>الوحدة / المصدر:</strong> ${esc(params.unit)} (${esc(params.fileName)}${
    params.pageRange ? ` · ${esc(params.pageRange)}` : ''
  })</p>
  <p>${esc(params.summary)}</p>
  ${pointsHtml ? `<h4>النقاط والأفكار الرئيسية:</h4><ul>${pointsHtml}</ul>` : ''}
</div>`;
}

export function mapGradeToCurriculumSubjectId(grade: string): string | null {
  const g = String(grade || '').trim();
  if (!g) return null;
  if (g.includes('الأول الإعدادي') || g.includes('أولى إعدادي')) return 'subj-prep1-ict';
  if (g.includes('الثاني الإعدادي') || g.includes('ثانية إعدادي')) return 'subj-prep2-ict';
  if (g.includes('الثالث الإعدادي') || g.includes('ثالثة إعدادي')) return 'subj-prep3-ict';
  if (g.includes('الأول الثانوي') || g.includes('أولى ثانوي')) return 'subj-sec1-theory';
  if (g.includes('الثاني الثانوي') || g.includes('ثانية ثانوي')) return 'subj-sec2-theory';
  return null;
}

export function normalizeExtractedPayload(
  raw: any,
  fileName: string
): ExtractedPdfCurriculumPayload {
  const fallbackUnit = fileName.replace(/\.pdf$/i, '').trim() || 'وحدة مستخرجة من PDF';
  const unitTitle =
    typeof raw?.unitTitle === 'string' && raw.unitTitle.trim()
      ? raw.unitTitle.trim()
      : fallbackUnit;

  const rawLessons = Array.isArray(raw?.lessons) ? raw.lessons : [];
  const lessons: ExtractedPdfLesson[] = rawLessons
    .filter((l: any) => l && (l.title || l.summary))
    .map((l: any, idx: number) => {
      const title = String(l.title || `الدرس ${idx + 1}: ${fallbackUnit}`).trim();
      const titleEn = String(l.titleEn || title).trim();
      const summary = String(l.summary || `ملخص تعليمي مستخرج آلياً من ${fileName}.`).trim();
      const keyPoints = Array.isArray(l.keyPoints)
        ? l.keyPoints.map((p: any) => String(p || '').trim()).filter(Boolean).slice(0, 6)
        : [];
      const durationMinutes = Math.max(5, Math.min(90, Number(l.durationMinutes) || 20));
      const pageRange = String(l.pageRange || '').trim();
      return {
        title,
        titleEn,
        summary,
        keyPoints: keyPoints.length > 0 ? keyPoints : [summary],
        durationMinutes,
        pageRange,
      };
    });

  if (lessons.length === 0) {
    throw new PdfFeedApiError(
      `لم يتم استخراج دروس واضحة من ملف PDF (${fileName}). تأكد من وضوح النص والمحتوى داخل الملف.`,
      422,
      'EMPTY_EXTRACTED_LESSONS'
    );
  }

  const rawQuestions = Array.isArray(raw?.questions) ? raw.questions : [];
  const questions: ExtractedPdfQuestion[] = [];

  for (const q of rawQuestions) {
    if (!q || !q.question) continue;
    const isTf = q.questionType === 'true_false';
    if (isTf) {
      const idx = Number(q.correctOptionIndex) === 1 ? 1 : 0;
      questions.push({
        questionType: 'true_false',
        question: String(q.question).trim(),
        options: ['صح', 'خطأ'],
        correctOptionIndex: idx,
        explanation: String(q.explanation || 'إجابة مستخلصة من نص ملف PDF.').trim(),
        sourceLessonIndex: Math.max(
          0,
          Math.min(lessons.length - 1, Number(q.sourceLessonIndex) || 0)
        ),
        sourcePdfPage: Math.max(1, Number(q.sourcePdfPage) || 1),
      });
    } else {
      const opts = Array.isArray(q.options)
        ? q.options.map((o: any) => String(o || '').trim()).filter(Boolean)
        : [];
      if (opts.length < 4) continue;
      const fourOpts = opts.slice(0, 4);
      const ans = Number(q.correctOptionIndex);
      const safeAns = ans >= 0 && ans < 4 ? ans : 0;
      questions.push({
        questionType: 'mcq',
        question: String(q.question).trim(),
        options: fourOpts,
        correctOptionIndex: safeAns,
        explanation: String(q.explanation || 'تفسير الإجابة من مادة ملف PDF.').trim(),
        sourceLessonIndex: Math.max(
          0,
          Math.min(lessons.length - 1, Number(q.sourceLessonIndex) || 0)
        ),
        sourcePdfPage: Math.max(1, Number(q.sourcePdfPage) || 1),
      });
    }
  }

  if (questions.length === 0) {
    throw new PdfFeedApiError(
      `لم يتم استخراج أسئلة اختبارات صالحة من ملف PDF (${fileName}).`,
      422,
      'EMPTY_EXTRACTED_QUESTIONS'
    );
  }

  return { unitTitle, lessons, questions };
}

export function buildCurriculumChapterFromExtracted(opts: {
  chapterId: string;
  order: number;
  term: 1 | 2;
  pdfName: string;
  extracted: ExtractedPdfCurriculumPayload;
}): CurriculumChapter {
  const { chapterId, order, term, pdfName, extracted } = opts;

  const curriculumLessons: CurriculumLesson[] = extracted.lessons.map((les, idx) => {
    const lessonQuestions = extracted.questions.filter((q) => q.sourceLessonIndex === idx);
    const mcqsForLesson = lessonQuestions.filter((q) => q.questionType === 'mcq');
    const tfsForLesson = lessonQuestions.filter((q) => q.questionType === 'true_false');

    // Guarantee at least one MCQ per lesson if all MCQs were assigned to other lesson indices
    const poolMcqs =
      mcqsForLesson.length > 0
        ? mcqsForLesson
        : extracted.questions.filter((q) => q.questionType === 'mcq').slice(0, 2);

    const mcqQuestions: CurriculumMcqQuestion[] = poolMcqs.map((q, qIdx) => ({
      id: `${chapterId}-l${idx + 1}-mcq-${qIdx + 1}`,
      question: q.question,
      options: [q.options[0], q.options[1], q.options[2], q.options[3]] as [
        string,
        string,
        string,
        string,
      ],
      correctIndex: q.correctOptionIndex,
      explanation: q.explanation,
    }));

    const trueFalseQuestions: CurriculumTrueFalseQuestion[] = tfsForLesson.map((q, qIdx) => ({
      id: `${chapterId}-l${idx + 1}-tf-${qIdx + 1}`,
      statement: q.question,
      isTrue: q.correctOptionIndex === 0,
      explanation: q.explanation,
    }));

    return {
      id: `${chapterId}-l${idx + 1}`,
      order: idx + 1,
      title: les.title,
      durationMinutes: les.durationMinutes,
      summary: les.summary,
      keyPoints: les.keyPoints,
      mcqQuestions,
      trueFalseQuestions,
      codeChallenges: [],
    };
  });

  const allMcqs = extracted.questions.filter((q) => q.questionType === 'mcq');
  const chapterReviewQuestions: CurriculumMcqQuestion[] = allMcqs
    .slice(0, 5)
    .map((q, idx) => ({
      id: `${chapterId}-rev-${idx + 1}`,
      question: q.question,
      options: [q.options[0], q.options[1], q.options[2], q.options[3]] as [
        string,
        string,
        string,
        string,
      ],
      correctIndex: q.correctOptionIndex,
      explanation: q.explanation,
    }));

  return {
    id: chapterId,
    order,
    term,
    title: extracted.unitTitle,
    description: `فصل مولد تلقائياً من ملف المعلم (${pdfName}) — يشمل ${curriculumLessons.length} دروس و${extracted.questions.length} سؤال تقييم.`,
    lessons: curriculumLessons,
    chapterReviewQuestions,
  };
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function extractCurriculumAndQuizFromPdf(params: {
  pdfBase64: string;
  fileName: string;
  teacherName: string;
  subject: string;
  grade: string;
  lessonCount?: number;
  questionsCount?: number;
}): Promise<ExtractedPdfCurriculumPayload> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new PdfFeedApiError(
      'مفتاح GEMINI_API_KEY غير متوفر في بيئة الخادم. يرجى ضبطه في إعدادات الأسرار (Settings > Secrets) لتشغيل التغذية التلقائية من ملفات PDF.',
      400,
      'GEMINI_API_KEY_MISSING'
    );
  }

  const cleanBase64 = validatePdfPayloadOrThrow(params.pdfBase64, params.fileName);
  const desiredLessons = Math.max(2, Math.min(8, Number(params.lessonCount) || 4));
  const desiredQuestions = Math.max(4, Math.min(20, Number(params.questionsCount) || 10));

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const pdfPart = {
    inlineData: {
      mimeType: 'application/pdf',
      data: cleanBase64,
    },
  };

  const promptText = `أنت خبير مناهج تعليمية متخصص في إعداد الدروس وبنوك الأسئلة للمعلمين.
حلّل ملف الـ PDF المرفق (${params.fileName}) الخاص بمادة "${params.subject}" للمرحلة "${params.grade}" (المعلم: ${params.teacherName}) بدقة بالغة، واستخرج منه مباشرةً بدون تأليف خارجي:
1. عنوان الوحدة/الفصل الرئيسي (unitTitle) باللغة العربية الواضحة.
2. قائمة من ${desiredLessons} دروس مرتبة منطقياً تغطي محتوى الملف (lessons):
   - title: عنوان الدرس بالعربية
   - titleEn: عنوان إنجليزي مختصر للدرس
   - summary: ملخص شرح وافٍ ودقيق مستند إلى محتوى PDF (3-5 جمل تعليمية)
   - keyPoints: مصفوفة من 3 إلى 5 نقاط وأفكار رئيسية لكل درس
   - durationMinutes: المدة التقديرية بالدقائق (رقم صحيح بين 10 و45)
   - pageRange: أرقام الصفحات في الملف إن وُجدت (مثل: ص 1 - ص 5)
3. مجموعة من ${desiredQuestions} سؤال اختبار متنوع ومباشر من محتوى الدروس المستخرجة (questions):
   - اجعل ثلثي الأسئلة تقريباً اختيار من متعدد (questionType = "mcq") بـ 4 اختيارات متكافئة ومميزة، وcorrectOptionIndex من 0 إلى 3.
   - واجعل الثلث المتبقي أسئلة صح وخطأ (questionType = "true_false") بخيارين ثابتين هما ["صح", "خطأ"] وcorrectOptionIndex = 0 لـ صح أو 1 لـ خطأ.
   - أضف explanation توضيحياً دقيقاً لكل إجابة، وsourceLessonIndex (فهرس الدرس المرتبط 0..${desiredLessons - 1})، وsourcePdfPage (رقم الصفحة في PDF).`;

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      unitTitle: {
        type: Type.STRING,
        description: 'عنوان الوحدة أو الفصل المستخرج من الملف',
      },
      lessons: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            titleEn: { type: Type.STRING },
            summary: { type: Type.STRING },
            keyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            durationMinutes: { type: Type.INTEGER },
            pageRange: { type: Type.STRING },
          },
          required: ['title', 'titleEn', 'summary', 'keyPoints', 'durationMinutes', 'pageRange'],
        },
      },
      questions: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            questionType: { type: Type.STRING },
            question: { type: Type.STRING },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            correctOptionIndex: { type: Type.INTEGER },
            explanation: { type: Type.STRING },
            sourceLessonIndex: { type: Type.INTEGER },
            sourcePdfPage: { type: Type.INTEGER },
          },
          required: [
            'questionType',
            'question',
            'options',
            'correctOptionIndex',
            'explanation',
            'sourceLessonIndex',
            'sourcePdfPage',
          ],
        },
      },
    },
    required: ['unitTitle', 'lessons', 'questions'],
  };

  let lastErr: any = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: { parts: [pdfPart, { text: promptText }] },
        config: {
          systemInstruction:
            'أجب دائماً بـ JSON صحيح مطابق للـ responseSchema فقط بدون أي مقدمات نصية، واستخرج الدروس والأسئلة بأمانة من ملف PDF المرفق.',
          responseMimeType: 'application/json',
          responseSchema,
        },
      });

      const rawText = (response.text ?? '{}').trim();
      const parsed = JSON.parse(rawText);
      return normalizeExtractedPayload(parsed, params.fileName);
    } catch (err: any) {
      lastErr = err;
      const msg = String(err?.message || err || '');
      const status = Number(err?.status || err?.statusCode || 0);

      // Non-retryable client/key/quota errors -> surface clearly immediately
      if (
        status === 400 ||
        status === 401 ||
        status === 403 ||
        msg.includes('API_KEY_INVALID') ||
        msg.includes('PERMISSION_DENIED')
      ) {
        throw new PdfFeedApiError(
          'تعذر التحقق من مفتاح Gemini API (تأكد من صلاحية المفتاح في Settings > Secrets).',
          403,
          'GEMINI_AUTH_ERROR'
        );
      }
      if (status === 429 || msg.includes('RESOURCE_EXHAUSTED')) {
        throw new PdfFeedApiError(
          'تم تجاوز حد الطلبات المسموح لخدمة التحليل الذكي حالياً؛ يرجى المحاولة بعد لحظات.',
          429,
          'GEMINI_RATE_LIMIT'
        );
      }
      if (err instanceof PdfFeedApiError) {
        throw err;
      }

      if (attempt < 2) {
        await sleep(600 * Math.pow(2, attempt));
        continue;
      }
    }
  }

  throw new PdfFeedApiError(
    `فشل تحليل ملف PDF (${params.fileName}): ${String(lastErr?.message || lastErr || 'خطأ غير متوقع')}`,
    502,
    'GEMINI_UPSTREAM_ERROR'
  );
}
